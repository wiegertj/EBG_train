
#include "header.h"

void predict_unit9(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5828162941871858349) ) ) {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004879500000000001024) ) ) {
      result[0] += -0.022043020552624658;
    } else {
      result[0] += 0.0037053112435283743;
    }
  } else {
    result[0] += 0.01279935183513949;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9504576888574564064) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.02980624349803203885) ) ) {
      result[0] += -0.10918159751052897;
    } else {
      result[0] += -0.00017772705447121137;
    }
  } else {
    result[0] += 0.09847017624836475;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9504576888574564064) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1316283809119187798) ) ) {
      result[0] += -0.10236266629772917;
    } else {
      result[0] += -0.00011372292856366669;
    }
  } else {
    result[0] += 0.09632846949374423;
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2669585275879397535) ) ) {
    result[0] += 0.06289000308823228;
  } else {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5981753503490724322) ) ) {
      result[0] += -0.018419824997426244;
    } else {
      result[0] += 0.0033822093267232255;
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
    result[0] += 0.02998080623573023;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002137500000000000511) ) ) {
      result[0] += -0.02806007641652393;
    } else {
      result[0] += 0.00455679583199217;
    }
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.02980624349803203885) ) ) {
    result[0] += -0.10708069465546981;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
      result[0] += 0.03297378789294698;
    } else {
      result[0] += -0.0022335497875907227;
    }
  }
}

