
#include "header.h"

void predict_unit9(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3310097201537537948) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1313656708211964064) ) ) {
      result[0] += -0.054573648719584374;
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3565697080904522975) ) ) {
        result[0] += 0.03608981353616174;
      } else {
        result[0] += -0.027031839570024155;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8257976220666124467) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6213841400436609375) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09500000000000001499) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1350000000000000366) ) ) {
            result[0] += 0;
          } else {
            result[0] += 0.05476620493434774;
          }
        } else {
          result[0] += -0.008212022688421274;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9024131424400998469) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
            result[0] += 0.012721011850166183;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0006765000000000001264) ) ) {
              result[0] += -0.013592029083089804;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.194581012612933923) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6869304497989950908) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5508018452917812224) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.555096866909547848) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5425490666834171805) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5392639039447236771) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.51855191273869361) ) ) {
                            result[0] += 0.00046390354623825563;
                          } else {
                            result[0] += 0.015193662606899621;
                          }
                        } else {
                          result[0] += -0.026997348786628784;
                        }
                      } else {
                        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.04908445857219279757) ) ) {
                          result[0] += 0.05007924252049441;
                        } else {
                          result[0] += 0.0021894932382201357;
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5910501547487437835) ) ) {
                        result[0] += -0.011613639599827457;
                      } else {
                        result[0] += 0.0025940664067233294;
                      }
                    }
                  } else {
                    result[0] += -0.020429185013144505;
                  }
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7750000000000001332) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02843150000000000191) ) ) {
                      result[0] += 0.048127558694977986;
                    } else {
                      result[0] += 0.011308020723125646;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7242520756532664361) ) ) {
                      result[0] += 0.02161575949221396;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7889021474406031631) ) ) {
                        result[0] += -0.01020034922563109;
                      } else {
                        result[0] += 0.009913508077407368;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.012398908520997102;
              }
            }
          }
        } else {
          result[0] += 0.008866150727287915;
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9446153469900331334) ) ) {
        result[0] += 0.029318743385436503;
      } else {
        result[0] += 0.050077261388903616;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3881589449934809699) ) ) {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1313656708211964064) ) ) {
      result[0] += -0.05441397599657596;
    } else {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
        result[0] += -0.00922829866640379;
      } else {
        result[0] += -0.02939670256639762;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8442376020855621999) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5818191821885695392) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004774500000000000098) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += 0.0008796811230657988;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0007145000000000001827) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9250000000000001554) ) ) {
                result[0] += -0.03431436289847651;
              } else {
                result[0] += 0.014148163454773753;
              }
            } else {
              result[0] += -0.007290626381604765;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2548135000000000816) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006340500000000001517) ) ) {
              result[0] += 0.011858711599032254;
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.5708656043828381765) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.323165429195979903) ) ) {
                  result[0] += 0.006466485084728083;
                } else {
                  result[0] += -0.029993095011740186;
                }
              } else {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3245459035486191746) ) ) {
                  if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3763018001168558224) ) ) {
                    if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4588909872322206041) ) ) {
                      result[0] += 0.017402140775831423;
                    } else {
                      result[0] += -0.021846401106369838;
                    }
                  } else {
                    result[0] += 0.03437970937714201;
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4838161673366834781) ) ) {
                    result[0] += -0.012635621488851122;
                  } else {
                    if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.01051018765715429869) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5499504253266332965) ) ) {
                        result[0] += 0.005180279847826298;
                      } else {
                        result[0] += 0.046429927135883016;
                      }
                    } else {
                      result[0] += -0.003562904269065625;
                    }
                  }
                }
              }
            }
          } else {
            result[0] += 0.02393148991770578;
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.736034375232267446) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9250000000000001554) ) ) {
            result[0] += 0.017560178549486136;
          } else {
            result[0] += 0.002547317985543821;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9108935748982122105) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002914500000000000424) ) ) {
              result[0] += 0.038901582087009876;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
                result[0] += 0.03813433799640285;
              } else {
                result[0] += 0.008156693789570011;
              }
            }
          } else {
            result[0] += -0.02576372732976654;
          }
        }
      }
    } else {
      result[0] += 0.04003227227377774;
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2727691064925280018) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1313656708211964064) ) ) {
      result[0] += -0.05424973368234924;
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += 0.018449662638327705;
      } else {
        result[0] += -0.03278143880650176;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8442376020855621999) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5755371229009215162) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6285027855690678011) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02962100000000000496) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.482877277201360311) ) ) {
              result[0] += -0.010974930100350954;
            } else {
              result[0] += 0.011551362902873712;
            }
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1866571336964587269) ) ) {
              result[0] += -0.018447164475765023;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5025045207286433779) ) ) {
                result[0] += 0.0502910943903392;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03588532983514210878) ) ) {
                  result[0] += -0.026993088621393175;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5663601276130654227) ) ) {
                    result[0] += 0.07989064122711065;
                  } else {
                    result[0] += -0.001104418491813564;
                  }
                }
              }
            }
          }
        } else {
          result[0] += -0.01980302544342628;
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6486987125073885307) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
            result[0] += 0.010990882594045783;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001793500000000000172) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5508018452917812224) ) ) {
                result[0] += -0.003286262820761256;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9570114589738922817) ) ) {
                  result[0] += -0.032239252843416895;
                } else {
                  result[0] += -0.0022985910961477083;
                }
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6984575981658293076) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6462201978140704739) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6186550572613066512) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5910501547487437835) ) ) {
                        result[0] += 0.0002599561232064518;
                      } else {
                        result[0] += 0.018099363290867754;
                      }
                    } else {
                      result[0] += -0.018096358197844192;
                    }
                  } else {
                    result[0] += 0.02339576168060249;
                  }
                } else {
                  result[0] += -0.017250816374274433;
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7293493725076146683) ) ) {
                  result[0] += 0.03385437286162392;
                } else {
                  result[0] += 0.003419595246184023;
                }
              }
            }
          }
        } else {
          result[0] += 0.008762242233717391;
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9673254386414430472) ) ) {
        result[0] += 0.03276973785562594;
      } else {
        result[0] += 0.05424736407872469;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2727691064925280018) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1313656708211964064) ) ) {
      result[0] += -0.05408049624517586;
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += 0.01715126834679985;
      } else {
        result[0] += -0.03196755825612495;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8502789422115718532) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5755371229009215162) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7355897138442212269) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02962100000000000496) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                result[0] += -0.0019591190606443073;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0007145000000000001827) ) ) {
                  result[0] += -0.042600697203777016;
                } else {
                  result[0] += -0.012117413398983246;
                }
              }
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1525559854953426886) ) ) {
                result[0] += -0.01597966388896109;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5352759199748745589) ) ) {
                  result[0] += 0.04466659739186012;
                } else {
                  result[0] += 0.0042296825660140406;
                }
              }
            }
          } else {
            result[0] += 0.040815626797957305;
          }
        } else {
          result[0] += -0.022371961153627308;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9024131424400998469) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
            result[0] += 0.011449214029624602;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0006765000000000001264) ) ) {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.181114681928726734) ) ) {
                result[0] += 0;
              } else {
                result[0] += -0.02260519980067804;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.194581012612933923) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.038112519465065331) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.555096866909547848) ) ) {
                    result[0] += 0.0026947545199743567;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5910501547487437835) ) ) {
                      result[0] += -0.012260847114793666;
                    } else {
                      result[0] += 0.0010355676007644116;
                    }
                  }
                } else {
                  result[0] += 0.02016898781162646;
                }
              } else {
                result[0] += -0.011252190920694327;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6669784622613067482) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5508018452917812224) ) ) {
              result[0] += 0.007494046530834919;
            } else {
              result[0] += -0.020286347848754053;
            }
          } else {
            result[0] += 0.02081659470202775;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9673254386414430472) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5140962685175880509) ) ) {
          result[0] += 0.020942878065931286;
        } else {
          result[0] += 0.043014815507900324;
        }
      } else {
        result[0] += 0.054012883478839466;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2727691064925280018) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1313656708211964064) ) ) {
      result[0] += -0.053905835016893236;
    } else {
      if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2302999793555680907) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.05801046241977435292) ) ) {
          result[0] += 0.08475656372917667;
        } else {
          result[0] += -0.029059860380966744;
        }
      } else {
        result[0] += -0.03167874149796608;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8502789422115718532) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5678833582154496629) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7355897138442212269) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01278300000000000096) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                result[0] += -0.0012466512534016973;
              } else {
                result[0] += -0.01827594265751984;
              }
            } else {
              result[0] += 0.0032255723399569076;
            }
          } else {
            result[0] += 0.03883338537852065;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01401950000000000245) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9111514820863041431) ) ) {
              result[0] += -0.04189464985763813;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5050000000000001155) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3310097201537537948) ) ) {
                  result[0] += -0.03289023726724799;
                } else {
                  result[0] += 0.01875291197407865;
                }
              } else {
                result[0] += -0.03120495161209314;
              }
            }
          } else {
            result[0] += -0.0425573926657128;
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6486987125073885307) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2548135000000000816) ) ) {
            result[0] += -8.921316574684462e-05;
          } else {
            result[0] += 0.0208449655813867;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.09838300000000001211) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9650000000000000799) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9803163499134560643) ) ) {
                if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8115313189803874394) ) ) {
                  result[0] += 0.004870505465292083;
                } else {
                  result[0] += 0.03194657797189131;
                }
              } else {
                result[0] += 0.035724129951256345;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.536797523216080541) ) ) {
                result[0] += 0.006204738349172031;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5910501547487437835) ) ) {
                  result[0] += -0.06640862649173708;
                } else {
                  result[0] += 0;
                }
              }
            }
          } else {
            result[0] += 0.02257226151453011;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9673254386414430472) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5140962685175880509) ) ) {
          result[0] += 0.020177884975187896;
        } else {
          result[0] += 0.04234436731639517;
        }
      } else {
        result[0] += 0.05377360550701772;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2727691064925280018) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1313656708211964064) ) ) {
      result[0] += -0.053725336755552654;
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += 0.016941012696938967;
      } else {
        result[0] += -0.030403290105137558;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8502789422115718532) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5897839699588115492) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6285027855690678011) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.08024597504165288664) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3044402794723619077) ) ) {
              result[0] += 0.024847113030563202;
            } else {
              result[0] += -0.014190076886184606;
            }
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.04908445857219279757) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004774500000000000098) ) ) {
                result[0] += 0;
              } else {
                result[0] += 0.09264296335384821;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3550761912678883081) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6014274169849246343) ) ) {
                  result[0] += -0.0032724534026706037;
                } else {
                  result[0] += -0.028668733149834702;
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3650000000000000466) ) ) {
                  result[0] += 0.01858479642244629;
                } else {
                  result[0] += -0.010912712317930062;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9036370584454770372) ) ) {
            result[0] += -0.03105956158391761;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.051391296366422923) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.038112519465065331) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.966590843157139501) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4604805625892014476) ) ) {
                    result[0] += -0.018825463886300076;
                  } else {
                    result[0] += 0.04516220732471733;
                  }
                } else {
                  result[0] += -0.0409535926175177;
                }
              } else {
                result[0] += 0.06681191230883965;
              }
            } else {
              result[0] += -0.021917381119214138;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.736034375232267446) ) ) {
          result[0] += 0.0008982872852213086;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002788500000000000614) ) ) {
            result[0] += 0.036734807668065965;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
              result[0] += 0.03736392257113094;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.09516200000000001047) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0308805000000000017) ) ) {
                  result[0] += 0.007721907883486325;
                } else {
                  result[0] += -0.014052412927958155;
                }
              } else {
                result[0] += 0.03192050529150175;
              }
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9673254386414430472) ) ) {
        result[0] += 0.031054576426084158;
      } else {
        result[0] += 0.05352893813452408;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2727691064925280018) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1313656708211964064) ) ) {
      result[0] += -0.053538563748922935;
    } else {
      result[0] += -0.025845402500888945;
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8442376020855621999) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6589536398896721492) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7383710406281408511) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.02448774902434403) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6059045152763820052) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5910501547487437835) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5663601276130654227) ) ) {
                    if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.07583587458330973141) ) ) {
                      result[0] += -0.00878103409381973;
                    } else {
                      if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.04908445857219279757) ) ) {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00813650000000000137) ) ) {
                          result[0] += 0.011153722709978543;
                        } else {
                          result[0] += 0.08226618360820276;
                        }
                      } else {
                        result[0] += -0.0019199665722209418;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1520807814967988503) ) ) {
                      result[0] += -0.0386959510215796;
                    } else {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0008485000000000001872) ) ) {
                        result[0] += 0.05020832875096659;
                      } else {
                        result[0] += -0.021504945693452193;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3749834515475459207) ) ) {
                    result[0] += 0.013641914205062769;
                  } else {
                    result[0] += 0.07441543812910832;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3722591415898431344) ) ) {
                  result[0] += -0.026828741331917212;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0004715000000000000766) ) ) {
                    result[0] += 0.008179464538839882;
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.52031910737473408) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6480364325376885004) ) ) {
                        result[0] += -0.0207792051938786;
                      } else {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009469500000000000486) ) ) {
                          result[0] += -0.008925909651280853;
                        } else {
                          result[0] += 0.0547387840447442;
                        }
                      }
                    } else {
                      result[0] += -0.020902742683047114;
                    }
                  }
                }
              }
            } else {
              result[0] += 0.03318889182665084;
            }
          } else {
            result[0] += 0.04778896478350381;
          }
        } else {
          result[0] += -0.015744299665356894;
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.736034375232267446) ) ) {
          result[0] += 0.0013056320975475967;
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9108935748982122105) ) ) {
            result[0] += 0.01367372285789864;
          } else {
            result[0] += -0.024732773978523855;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9673254386414430472) ) ) {
        result[0] += 0.029493987042258654;
      } else {
        result[0] += 0.053278292432331495;
      }
    }
  }
}

