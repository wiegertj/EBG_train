
#include "header.h"

void predict_unit9(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7903724875956132934) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4225046379504136529) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.202212609002558108) ) ) {
        result[0] += -0.07762060299911518;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.25000000000000131e-05) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.254492193637797959) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5881074671461999914) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)125.5000000000000142) ) ) {
                result[0] += -0.03237632911495556;
              } else {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.0841877145549009831) ) ) {
                  result[0] += -0.04580824446564307;
                } else {
                  result[0] += 0.04011505626768049;
                }
              }
            } else {
              result[0] += -0.05745722020100017;
            }
          } else {
            result[0] += 0.03084977668992731;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03356779836971720415) ) ) {
            result[0] += -0.05430565167035679;
          } else {
            result[0] += -0.015656616024709878;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5903541535616282365) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5963654365793032985) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4450000000000000622) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.016561434387754259) ) ) {
              result[0] += 0.07059255902554219;
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.07409325127878772788) ) ) {
                if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5049068309452714454) ) ) {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3565697080904522975) ) ) {
                    result[0] += 0.01613158938770981;
                  } else {
                    result[0] += -0.05864487038362071;
                  }
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4093335132160804135) ) ) {
                    result[0] += -0.03931497132033241;
                  } else {
                    result[0] += 0.0005635656289744772;
                  }
                }
              } else {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.0491948752242571466) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)157.5000000000000284) ) ) {
                    result[0] += 0.140169118892985;
                  } else {
                    result[0] += -0.02213150870166984;
                  }
                } else {
                  if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.2475169621399765651) ) ) {
                    result[0] += 0.02623126713885448;
                  } else {
                    result[0] += -0.01802606053175669;
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5002776212835359226) ) ) {
              result[0] += -0.0604140152354547;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)52.50000000000000711) ) ) {
                if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.3299616490858839901) ) ) {
                  result[0] += 0.06537543708165965;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002532500000000000463) ) ) {
                    result[0] += -0.03766165032577092;
                  } else {
                    result[0] += 0.0028113330325501653;
                  }
                }
              } else {
                result[0] += -0.03159452033536729;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8950000000000001288) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8099155601256282644) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.966590843157139501) ) ) {
                result[0] += -0.00025934207904163107;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008514500000000002969) ) ) {
                  result[0] += 0.01027352901165093;
                } else {
                  result[0] += -0.06018070764180978;
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.194581012612933923) ) ) {
                result[0] += 0.06325462709310452;
              } else {
                result[0] += -0.010242034686041618;
              }
            }
          } else {
            if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5509197063102150294) ) ) {
              result[0] += -0.039617521765094685;
            } else {
              result[0] += -0.009227952469130529;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7583373477169182975) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8550000000000000933) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7156546188693468924) ) ) {
              result[0] += 0.01116811569382848;
            } else {
              result[0] += 0.06496632996018402;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
              result[0] += 0.033668292556160294;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7801862323115579256) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.92531357823258642) ) ) {
                  result[0] += 0.002724430846466711;
                } else {
                  result[0] += 0.033470198385432366;
                }
              } else {
                if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6497002368027441355) ) ) {
                  result[0] += -0.03244943247807779;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03539403715159186031) ) ) {
                    result[0] += 0.027874387488828454;
                  } else {
                    result[0] += -0.019161077477305794;
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001671500000000000243) ) ) {
            result[0] += 0.0533317325555369;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9050000000000001377) ) ) {
              result[0] += 0.0601863908128997;
            } else {
              result[0] += 0.01507030742631075;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9071228288109037807) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9573774901653852032) ) ) {
        result[0] += 0.04824824574672982;
      } else {
        result[0] += -0.01850872038325629;
      }
    } else {
      result[0] += 0.07995807903918928;
    }
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7903724875956132934) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3944417379768624943) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.202212609002558108) ) ) {
        result[0] += -0.07691856132804535;
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
          result[0] += 0.04475976887865235;
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0001660383056237000384) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)108.5000000000000142) ) ) {
              result[0] += -0.04161108995559027;
            } else {
              result[0] += -0.006376009410741184;
            }
          } else {
            result[0] += -0.05201901145165538;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.4905089628645931121) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5346753968654129885) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3650000000000000466) ) ) {
            if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.1946989117759076737) ) ) {
              result[0] += 0.030453074876117155;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3722591415898431344) ) ) {
                if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4593394921096751182) ) ) {
                  result[0] += -0.04182637310674628;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3450000000000000289) ) ) {
                    result[0] += 0;
                  } else {
                    result[0] += -0.06519849018018505;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6411603019421380223) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6574014915075377941) ) ) {
                    result[0] += 0;
                  } else {
                    result[0] += 0.08201741884731284;
                  }
                } else {
                  result[0] += -0.017301886785207294;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4435662465829146028) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4093335132160804135) ) ) {
                result[0] += -0.044649398550113926;
              } else {
                result[0] += 0.06450200436103332;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03676404066182115821) ) ) {
                if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5263851654176683326) ) ) {
                  result[0] += -0.056741015085874064;
                } else {
                  result[0] += -0.002027552164021048;
                }
              } else {
                result[0] += 0;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6850000000000001643) ) ) {
            result[0] += -0.00411635618392649;
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)86.50000000000001421) ) ) {
              result[0] += -0.007795938967844698;
            } else {
              result[0] += -0.03324101264160078;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9021581204195773251) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002115500000000000626) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
              result[0] += 0.021285468067821646;
            } else {
              if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5861769322017787998) ) ) {
                result[0] += -0.016613109831307926;
              } else {
                result[0] += 0;
              }
            }
          } else {
            if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5065718031653879683) ) ) {
              result[0] += 0.022408132578101786;
            } else {
              if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5452475257179970614) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4093335132160804135) ) ) {
                  result[0] += -0.044719704334415473;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)336.5000000000000568) ) ) {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)129.5000000000000284) ) ) {
                      result[0] += -0.011159137509296058;
                    } else {
                      result[0] += 0.027960438225152092;
                    }
                  } else {
                    result[0] += -0.04035669169438566;
                  }
                }
              } else {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.8537219630417757221) ) ) {
                  result[0] += 0.04225413131884849;
                } else {
                  if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5026146189546180088) ) ) {
                    result[0] += 0.021088593447244446;
                  } else {
                    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5150099700527622781) ) ) {
                      result[0] += -0.025217963662403597;
                    } else {
                      result[0] += 0.00459609358490749;
                    }
                  }
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9550000000000000711) ) ) {
            if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6140748412273120405) ) ) {
              result[0] += -0.0012335112109625832;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
                result[0] += 0.03618107899505883;
              } else {
                if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6569165541141283038) ) ) {
                  result[0] += -0.013688337169281473;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001454500000000000281) ) ) {
                    result[0] += 0.06142881801714384;
                  } else {
                    result[0] += 0.017173956223243945;
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04081810486678760785) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03151750000000001078) ) ) {
                result[0] += -0.016918540998659803;
              } else {
                result[0] += 0.04082764151481053;
              }
            } else {
              result[0] += -0.0536300777550044;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9071228288109037807) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9573774901653852032) ) ) {
        result[0] += 0.046260804724814586;
      } else {
        result[0] += -0.016891997628138564;
      }
    } else {
      result[0] += 0.07923101654284614;
    }
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7903724875956132934) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3944417379768624943) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.202212609002558108) ) ) {
        result[0] += -0.07618660684128095;
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
          result[0] += 0.04006235543094626;
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0001660383056237000384) ) ) {
            result[0] += -0.026427614210228587;
          } else {
            result[0] += -0.050190342681708;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6335148768279005305) ) ) {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.016561434387754259) ) ) {
          result[0] += 0.03745695522966453;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04544449598667580498) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001290117952834850213) ) ) {
              result[0] += -0.004042589893519546;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)179.5000000000000284) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002154500000000000599) ) ) {
                  result[0] += -0.03808493074440436;
                } else {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6487823756783920315) ) ) {
                      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6059238433417085679) ) ) {
                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0183110725056909035) ) ) {
                          if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.3944328354552520399) ) ) {
                            result[0] += -0.007767407425693402;
                          } else {
                            if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.3864019812289589129) ) ) {
                              result[0] += 0.061238901436507696;
                            } else {
                              result[0] += -0.01468958998353609;
                            }
                          }
                        } else {
                          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.07409325127878772788) ) ) {
                            result[0] += -0.045951761173364754;
                          } else {
                            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03378350000000000103) ) ) {
                              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007147500000000000207) ) ) {
                                result[0] += 0.020657304583134754;
                              } else {
                                result[0] += -0.05710041778421271;
                              }
                            } else {
                              result[0] += 0.041341094136075694;
                            }
                          }
                        }
                      } else {
                        result[0] += -0.04489376366845085;
                      }
                    } else {
                      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6635233717587941671) ) ) {
                        result[0] += 0.05616614733372145;
                      } else {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006483500000000000547) ) ) {
                          result[0] += 0.04485142075329187;
                        } else {
                          result[0] += -0.04037328051931912;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005037500000000001178) ) ) {
                      result[0] += 0;
                    } else {
                      result[0] += -0.06583732331422615;
                    }
                  }
                }
              } else {
                result[0] += -0.03829646303452655;
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)102.5000000000000142) ) ) {
              result[0] += -0.006479254217076856;
            } else {
              result[0] += 0.05578927706093547;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.652066519749839979) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)986.5000000000001137) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)605.5000000000001137) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.13900392495124092) ) ) {
                result[0] += 0.03161321210134321;
              } else {
                result[0] += 0.00041678996277425776;
              }
            } else {
              result[0] += -0.022212905743584456;
            }
          } else {
            result[0] += 0.029692630531026176;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09441796717006176176) ) ) {
            if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8721600553667344657) ) ) {
              if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8334151879459361645) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.194581012612933923) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6784611311055277483) ) ) {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
                      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.08110515786938453375) ) ) {
                        result[0] += 0.045965385241284226;
                      } else {
                        result[0] += 0.013237127561278208;
                      }
                    } else {
                      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6552470062311558374) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1685362591553855871) ) ) {
                          result[0] += 0.004147165754230188;
                        } else {
                          result[0] += 0.029556344757291072;
                        }
                      } else {
                        result[0] += -0.028841755350591913;
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7218051716834171794) ) ) {
                      result[0] += 0.064825426280171;
                    } else {
                      result[0] += 0.01218695562101308;
                    }
                  }
                } else {
                  result[0] += -0.025102594269564866;
                }
              } else {
                result[0] += 0.041085129031903124;
              }
            } else {
              result[0] += -0.02181257694534002;
            }
          } else {
            if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6859815657019552315) ) ) {
              result[0] += -0.04051713196841833;
            } else {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9497059879396164694) ) ) {
                result[0] += 0.03845783278122575;
              } else {
                result[0] += -0.011999689101816502;
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9071228288109037807) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
        result[0] += 0.051987919225767634;
      } else {
        result[0] += 0.024811638531247796;
      }
    } else {
      result[0] += 0.07848748985783903;
    }
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7903724875956132934) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3363340570929463369) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1326198720340577564) ) ) {
        result[0] += -0.08171107705393028;
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0001660383056237000384) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += 0.03428197191008385;
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)341.5000000000000568) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1850000000000000255) ) ) {
                result[0] += -0.047041067876205295;
              } else {
                result[0] += 0.007805159873691721;
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)593.5000000000001137) ) ) {
                result[0] += 0.046262858240494885;
              } else {
                result[0] += -0.047605342300383914;
              }
            }
          }
        } else {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.5170510649617241494) ) ) {
            result[0] += 0.015253041601181091;
          } else {
            result[0] += -0.061092870884267354;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6335148768279005305) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001121963940922750215) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)11.50000000000000178) ) ) {
            result[0] += -0.035914155975174125;
          } else {
            result[0] += 0;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004640500000000001395) ) ) {
            if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.3995393181459643839) ) ) {
              result[0] += -0.04246550022988293;
            } else {
              result[0] += -0.020409720120614386;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.695627306227387554) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.08835747683243963535) ) ) {
                if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.144651564651768455) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4578754035427136104) ) ) {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3044402794723619077) ) ) {
                      result[0] += 0.03068412571714876;
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4050000000000000822) ) ) {
                        result[0] += -0.053745249994533575;
                      } else {
                        result[0] += 0.004893256436598998;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4814085394974874643) ) ) {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2750000000000000777) ) ) {
                        result[0] += 0.09257618993977737;
                      } else {
                        result[0] += 0.013017536230692175;
                      }
                    } else {
                      result[0] += -0.030620377058267714;
                    }
                  }
                } else {
                  result[0] += -0.07333083213883043;
                }
              } else {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.0491948752242571466) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02197600000000000595) ) ) {
                    result[0] += 0.12704945064344808;
                  } else {
                    result[0] += 0.0024055438675743583;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4250000000000000444) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1224820000000000214) ) ) {
                      result[0] += -0.025044813523782627;
                    } else {
                      result[0] += 0.04131536161171031;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2750000000000000777) ) ) {
                      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5223131059347717597) ) ) {
                        result[0] += 0;
                      } else {
                        result[0] += 0.08400764706606743;
                      }
                    } else {
                      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.3741670680264105875) ) ) {
                        result[0] += -0.041441267203922;
                      } else {
                        result[0] += 0.0058275313423548376;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.286140606976293066) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02759537094404265409) ) ) {
                  result[0] += -0.06335606250839183;
                } else {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8158067323869347964) ) ) {
                    result[0] += -0.041368904365172356;
                  } else {
                    result[0] += 0.052573125485878676;
                  }
                }
              } else {
                result[0] += 0.03485848881267271;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9021581204195773251) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)909.5000000000001137) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)605.5000000000001137) ) ) {
              result[0] += 0.0008837560114573145;
            } else {
              result[0] += -0.021076749491005825;
            }
          } else {
            result[0] += 0.028919173082400156;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9450000000000000622) ) ) {
            if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6670562257123778815) ) ) {
              result[0] += -0.013973523254053093;
            } else {
              result[0] += 0.019059317043254264;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04081810486678760785) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03151750000000001078) ) ) {
                result[0] += -0.012725260178112404;
              } else {
                result[0] += 0.038474280197715066;
              }
            } else {
              result[0] += -0.05152339545834702;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9071228288109037807) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
        result[0] += 0.05005663097745099;
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09148849557171551128) ) ) {
          result[0] += 0.03191928796702487;
        } else {
          result[0] += -0.04433365711669053;
        }
      }
    } else {
      result[0] += 0.07772376648650542;
    }
  }
}

