
#include "header.h"

void predict_unit11(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2296243883448841061) ) ) {
    if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2302999793555680907) ) ) {
      if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4356613041208446946) ) ) {
        result[0] += -0.03899205851344861;
      } else {
        result[0] += 0.055404821378734405;
      }
    } else {
      result[0] += -0.04278481329382747;
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8502789422115718532) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4429728266653536473) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02500000000000000486) ) ) {
          result[0] += 0.03023168391499574;
        } else {
          result[0] += -0.011634962122295126;
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3073450000000000348) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5668346010835486615) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4073174598994975804) ) ) {
              if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4314418144595498217) ) ) {
                result[0] += -0.0063176424274691235;
              } else {
                result[0] += -0.032934095387044726;
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4141149047989949872) ) ) {
                result[0] += 0.026531442349007273;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.25500000000000006) ) ) {
                  result[0] += 0.011052422294397166;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5243242856675894847) ) ) {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3141736113237109662) ) ) {
                      result[0] += 0;
                    } else {
                      result[0] += -0.02955371942983219;
                    }
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8950000000000001288) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7002474625125628682) ) ) {
                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1295212041281339765) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5926917132914574227) ) ) {
                            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5596867406532665123) ) ) {
                              if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.08835747683243963535) ) ) {
                                result[0] += -0.0035348741625077164;
                              } else {
                                result[0] += 0.010229384820505614;
                              }
                            } else {
                              result[0] += -0.015962034688333834;
                            }
                          } else {
                            result[0] += 0.03498375682961075;
                          }
                        } else {
                          result[0] += -0.007865833936231246;
                        }
                      } else {
                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.051391296366422923) ) ) {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5650000000000000577) ) ) {
                            result[0] += 0.007030131073315398;
                          } else {
                            result[0] += 0.034176735000354556;
                          }
                        } else {
                          result[0] += -0.00777146579555727;
                        }
                      }
                    } else {
                      result[0] += -0.007984900448463438;
                    }
                  }
                }
              }
            }
          } else {
            result[0] += 0.002961513522619107;
          }
        } else {
          result[0] += 0.023472493009068708;
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9673254386414430472) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5140962685175880509) ) ) {
          result[0] += 0.009601766575389165;
        } else {
          result[0] += 0.036708108982505226;
        }
      } else {
        result[0] += 0.051180404436421356;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2252215573829355333) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1313656708211964064) ) ) {
      result[0] += -0.05165759609646771;
    } else {
      if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3750409390474713223) ) ) {
        result[0] += 0.044079796242843174;
      } else {
        result[0] += -0.02697603689017404;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8902231111662372021) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6589536398896721492) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3044402794723619077) ) ) {
          result[0] += 0.028149564330726448;
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3991687150000000073) ) ) {
            result[0] += -0.019661444422392756;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4141149047989949872) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5678833582154496629) ) ) {
                result[0] += 0;
              } else {
                result[0] += 0.04707404564713572;
              }
            } else {
              result[0] += -0.004521498854310244;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7560518798657903661) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.8085344187842374852) ) ) {
            result[0] += -0.012262389334610617;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3315854282412060705) ) ) {
              result[0] += 0.02766009761191743;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3622054098241206943) ) ) {
                result[0] += -0.024353006892472603;
              } else {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4627502129294571165) ) ) {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.5708656043828381765) ) ) {
                    result[0] += -0.0027190936469116953;
                  } else {
                    result[0] += 0.021671599178081053;
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4141149047989949872) ) ) {
                    result[0] += -0.020173716077375607;
                  } else {
                    if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.251590827778069126) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4743305372864322078) ) ) {
                        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3763018001168558224) ) ) {
                          result[0] += -0.008319395197610076;
                        } else {
                          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0118835000000000017) ) ) {
                            result[0] += 0.01151074894455629;
                          } else {
                            result[0] += 0.04066607842534794;
                          }
                        }
                      } else {
                        result[0] += -0.014747431958141374;
                      }
                    } else {
                      if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1866571336964587269) ) ) {
                        result[0] += -0.012394873998311406;
                      } else {
                        result[0] += 0.001199932090914277;
                      }
                    }
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
            result[0] += 0.03200694570537868;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6669784622613067482) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9987334191040063702) ) ) {
                result[0] += 0.0039043076701556793;
              } else {
                result[0] += -0.034989466227224764;
              }
            } else {
              result[0] += 0.028875166721508593;
            }
          }
        }
      }
    } else {
      result[0] += 0.034615915593602664;
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1313656708211964064) ) ) {
    result[0] += -0.0513899028323291;
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.919425862722463072) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4429728266653536473) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3315854282412060705) ) ) {
          result[0] += 0.06906416170330772;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
            result[0] += -0.0026790427752987913;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7156546188693468924) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2642961365573822663) ) ) {
                  result[0] += -0.04048002182703255;
                } else {
                  result[0] += -0.010966630520860825;
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006980500000000001461) ) ) {
                  result[0] += -0.005761590862342169;
                } else {
                  result[0] += 0.06475834380458466;
                }
              }
            } else {
              result[0] += -0.038905611999642674;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7560518798657903661) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00271850000000000043) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
              result[0] += 0.004902859681510281;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8450000000000000844) ) ) {
                result[0] += -0.014897310146000653;
              } else {
                result[0] += -0.0018587431333494783;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.219097262499394541) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8158067323869347964) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7890731911809046872) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6984575981658293076) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.52031910737473408) ) ) {
                      result[0] += 0.0017886188436979649;
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01676750000000000462) ) ) {
                        result[0] += -0.0011070438422957395;
                      } else {
                        result[0] += -0.03826618661060694;
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6461954822149375) ) ) {
                      result[0] += 0.05703972330920612;
                    } else {
                      result[0] += 0.007854321318649148;
                    }
                  }
                } else {
                  result[0] += -0.028080420157330036;
                }
              } else {
                result[0] += 0.03394722955891313;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.480405183437169869) ) ) {
                result[0] += -0.025816336323228106;
              } else {
                result[0] += 0.015351319218384488;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
            result[0] += 0.030550758293933465;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6669784622613067482) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002657500000000000574) ) ) {
                result[0] += 0.027443933716841003;
              } else {
                result[0] += -0.0012292386279647144;
              }
            } else {
              result[0] += 0.03119081771760106;
            }
          }
        }
      }
    } else {
      result[0] += 0.03837588024682797;
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1313656708211964064) ) ) {
    result[0] += -0.051111248941855036;
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8622565274156744897) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3881589449934809699) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
          result[0] += 0;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7242520756532664361) ) ) {
              result[0] += -0.019101101801471763;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006980500000000001461) ) ) {
                result[0] += -0.02686733028371012;
              } else {
                result[0] += 0.0818189275672554;
              }
            }
          } else {
            result[0] += -0.0441067018334827;
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3073450000000000348) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5717030637423591299) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4073174598994975804) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3315854282412060705) ) ) {
                result[0] += 0.004075396328445445;
              } else {
                result[0] += -0.016160901550027293;
              }
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2091302419391287415) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003306500000000000411) ) ) {
                  result[0] += -0.003490338188849754;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4583473626633166043) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4305635934924623709) ) ) {
                      result[0] += 0.02350365142112447;
                    } else {
                      result[0] += -0.009648634317256755;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4743305372864322078) ) ) {
                      result[0] += 0.04200573415350443;
                    } else {
                      result[0] += 0.009331258135870981;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4899381758793970865) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05194950000000000262) ) ) {
                    if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1472443616828482127) ) ) {
                      result[0] += -0.04265836098521504;
                    } else {
                      result[0] += -0.009649540298579905;
                    }
                  } else {
                    result[0] += 0.003361604139585016;
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5041457217085428821) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.499023329447236208) ) ) {
                      result[0] += 0;
                    } else {
                      result[0] += 0.04125656763068855;
                    }
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8950000000000001288) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7170565711177164792) ) ) {
                        result[0] += -0.002548115247150029;
                      } else {
                        result[0] += 0.005492165123673524;
                      }
                    } else {
                      result[0] += -0.008814297560276225;
                    }
                  }
                }
              }
            }
          } else {
            result[0] += 0.0027654870987617775;
          }
        } else {
          result[0] += 0.02199314580506817;
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9673254386414430472) ) ) {
        result[0] += 0.02223134573207315;
      } else {
        result[0] += 0.05037413206890399;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1313656708211964064) ) ) {
    result[0] += -0.050821199277691576;
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.919425862722463072) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3881589449934809699) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
          result[0] += 0;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7242520756532664361) ) ) {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.03659918966571634041) ) ) {
                if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.07175569222910598011) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02500000000000000486) ) ) {
                    result[0] += 0.035377789765228825;
                  } else {
                    result[0] += -0.02360075692239825;
                  }
                } else {
                  result[0] += 0.05904347643173162;
                }
              } else {
                result[0] += -0.026426805608297393;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006980500000000001461) ) ) {
                result[0] += -0.02608376889458923;
              } else {
                result[0] += 0.07197202456014422;
              }
            }
          } else {
            result[0] += -0.043507754377071155;
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7881101830206976855) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1988654957757923225) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.005763347306157399173) ) ) {
              result[0] += -0.0027020310224040783;
            } else {
              result[0] += 0.042569926125012675;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4604805625892014476) ) ) {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2295059026793999646) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0004715000000000000766) ) ) {
                  result[0] += -0.024326592126667188;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6574014915075377941) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5221522817587941345) ) ) {
                      result[0] += 0.009530253840012309;
                    } else {
                      result[0] += -0.023448267059102672;
                    }
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01458750000000000151) ) ) {
                      result[0] += 0.09330653998619028;
                    } else {
                      result[0] += 0;
                    }
                  }
                }
              } else {
                result[0] += -0.031633660262252006;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2548135000000000816) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7823171070351759848) ) ) {
                  result[0] += 0.0005949585348476894;
                } else {
                  result[0] += -0.007470722766669996;
                }
              } else {
                result[0] += 0.015168384785492324;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9950000000000001066) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              result[0] += 0.03798022601795797;
            } else {
              result[0] += 0.011756775672670385;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03808300000000000574) ) ) {
              result[0] += -0.04692498799390864;
            } else {
              result[0] += 0.007887622695538008;
            }
          }
        }
      }
    } else {
      result[0] += 0.0369750525779494;
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1313656708211964064) ) ) {
    result[0] += -0.05051930538199413;
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.919425862722463072) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4429728266653536473) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3315854282412060705) ) ) {
          result[0] += 0.06247941445531908;
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.464974115402010113) ) ) {
            result[0] += -0.03023589405463276;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.578780523307733108) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5642589213209130428) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4827419593969848877) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3746814056271836058) ) ) {
                    result[0] += 0.06954870001824802;
                  } else {
                    result[0] += -0.02087074630346341;
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1450000000000000455) ) ) {
                    result[0] += -0.021249255690772156;
                  } else {
                    result[0] += 0.001266228125859376;
                  }
                }
              } else {
                result[0] += 0.08636868314957287;
              }
            } else {
              result[0] += -0.019714045463591002;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.736034375232267446) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002853500000000000567) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
                result[0] += 0.002093392491259745;
              } else {
                result[0] += 0.03376506303999301;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0003975000000000000668) ) ) {
                result[0] += -0.02768228257348449;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5243242856675894847) ) ) {
                  result[0] += -0.027382300664060184;
                } else {
                  result[0] += -0.0029904276577558766;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.219097262499394541) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8158067323869347964) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7890731911809046872) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6984575981658293076) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.52031910737473408) ) ) {
                      result[0] += 0.001559571942823439;
                    } else {
                      result[0] += -0.019770056368459184;
                    }
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7293493725076146683) ) ) {
                      result[0] += 0.03838008761794667;
                    } else {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8722100575184922322) ) ) {
                        result[0] += -0.01399947882303994;
                      } else {
                        result[0] += 0.01854644224742561;
                      }
                    }
                  }
                } else {
                  result[0] += -0.02622089573664972;
                }
              } else {
                result[0] += 0.0307930183008107;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.480405183437169869) ) ) {
                result[0] += -0.02449910143784719;
              } else {
                result[0] += 0.01708128086228272;
              }
            }
          }
        } else {
          result[0] += 0.008728460955894683;
        }
      }
    } else {
      result[0] += 0.03622004356263148;
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1313656708211964064) ) ) {
    result[0] += -0.05020511829550088;
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.919425862722463072) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3881589449934809699) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
          result[0] += 7.0139906581427e-05;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00587150000000000085) ) ) {
              result[0] += -0.025997365748301405;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7242520756532664361) ) ) {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.06765554132556478306) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4731422897738694067) ) ) {
                    result[0] += -0.010125064329647908;
                  } else {
                    result[0] += 0.07144458886208647;
                  }
                } else {
                  result[0] += -0.020257683274241052;
                }
              } else {
                result[0] += 0.058425019843974926;
              }
            }
          } else {
            result[0] += -0.04260954396833026;
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7881101830206976855) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1850000000000000255) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01779450000000000129) ) ) {
              result[0] += 0.03309001219672447;
            } else {
              result[0] += 0;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5205725315881680748) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2682576517146198491) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7753767533919598831) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3550000000000000377) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2582081601689767969) ) ) {
                      result[0] += -0.004693483032051989;
                    } else {
                      result[0] += 0.04554674275647653;
                    }
                  } else {
                    result[0] += -0.036756272073693884;
                  }
                } else {
                  result[0] += 0.037035165065768476;
                }
              } else {
                result[0] += -0.01730946490950884;
              }
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.8085344187842374852) ) ) {
                result[0] += -0.01064295591295874;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3315854282412060705) ) ) {
                  result[0] += 0.021414485765979308;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3622054098241206943) ) ) {
                    result[0] += -0.019690924771471413;
                  } else {
                    if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4627502129294571165) ) ) {
                      result[0] += 0.009842978201455466;
                    } else {
                      result[0] += -7.322374851001803e-05;
                    }
                  }
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9950000000000001066) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              result[0] += 0.036977129863494475;
            } else {
              result[0] += 0.010817429264728475;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03808300000000000574) ) ) {
              result[0] += -0.04332019918853056;
            } else {
              result[0] += 0.007082844611860668;
            }
          }
        }
      }
    } else {
      result[0] += 0.035454957467641025;
    }
  }
}

