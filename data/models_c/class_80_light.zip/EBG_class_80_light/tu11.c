
#include "header.h"

void predict_unit11(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9532041455015286546) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.02980624349803203885) ) ) {
      result[0] += -0.10357059482895749;
    } else {
      result[0] += -0.0001107368599975326;
    }
  } else {
    result[0] += 0.09176211870361954;
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7889403666860613784) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
      result[0] += 0.023300182472911848;
    } else {
      result[0] += -0.005092361922382132;
    }
  } else {
    result[0] += 0.02163913816132864;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.395269004515127198) ) ) {
    result[0] += -0.028586711803482524;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3650000000000000466) ) ) {
      result[0] += 0.035403479303705424;
    } else {
      result[0] += -0.0008117131668448323;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5981753503490724322) ) ) {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5650000000000000577) ) ) {
      result[0] += -0.003236815688664275;
    } else {
      result[0] += -0.061037199669193715;
    }
  } else {
    result[0] += 0.003639652805415643;
  }
  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.212199032544347022) ) ) {
    result[0] += 0.08292427579199801;
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.0183365983644377499) ) ) {
      result[0] += -0.10180475772640156;
    } else {
      result[0] += -0.00016093413283158037;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9532041455015286546) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
      result[0] += 0.020470607780593657;
    } else {
      result[0] += -0.002615385390087159;
    }
  } else {
    result[0] += 0.08837048894316896;
  }
}

