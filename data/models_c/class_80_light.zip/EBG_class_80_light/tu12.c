
#include "header.h"

void predict_unit12(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8747476225597411448) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2692173444281812933) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.03553482468997491012) ) ) {
        result[0] += -0.07889705187652833;
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          result[0] += 0.019555881218225536;
        } else {
          result[0] += -0.04382240265187689;
        }
      }
    } else {
      if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5861769322017787998) ) ) {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.15279672222658669) ) ) {
          result[0] += 0.05024869627278925;
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5002776212835359226) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3850000000000000644) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
                result[0] += -0.030224702150041725;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06940500000000000835) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02101337656308150184) ) ) {
                    result[0] += -0.0086017717827449;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.038112519465065331) ) ) {
                      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.03659918966571634041) ) ) {
                        result[0] += 0.10018315892733079;
                      } else {
                        result[0] += -0.002013548164490621;
                      }
                    } else {
                      result[0] += 0.11790666578013391;
                    }
                  }
                } else {
                  result[0] += -0.05499534324767752;
                }
              }
            } else {
              result[0] += -0.043363687588211436;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002343500000000000531) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.741213767082058619e-06) ) ) {
                result[0] += 0.008732450018229499;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4148598843808023462) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6242692027386935738) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5926917132914574227) ) ) {
                      result[0] += -0.015018574596822494;
                    } else {
                      result[0] += 0.0266472686594991;
                    }
                  } else {
                    result[0] += -0.05537280825318852;
                  }
                } else {
                  result[0] += 0;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001290117952834850213) ) ) {
                  result[0] += 0.03884357775803428;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.966590843157139501) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7358111703768844825) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.003316849482376700402) ) ) {
                        result[0] += -0.025344765206448794;
                      } else {
                        result[0] += 0.0010423676330897531;
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8411352666870987038) ) ) {
                        result[0] += 0.07565875993500586;
                      } else {
                        result[0] += 0;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8158067323869347964) ) ) {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1272695000000000076) ) ) {
                        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)113.5000000000000142) ) ) {
                          result[0] += -0.0012405639341577825;
                        } else {
                          result[0] += -0.05432793953843484;
                        }
                      } else {
                        result[0] += -0.08239860197327754;
                      }
                    } else {
                      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04634976090840010887) ) ) {
                          result[0] += 0.012332316977364607;
                        } else {
                          result[0] += 0.08377709002833551;
                        }
                      } else {
                        result[0] += -0.048019489965513404;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.025531071503683448;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8043140244282375173) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8950000000000001288) ) ) {
            result[0] += 0.02364443572004667;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01242558176632585151) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)27.50000000000000355) ) ) {
                result[0] += 0.025093043621368553;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0007215000000000000276) ) ) {
                  result[0] += -0.012498166060312902;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3099638191016706457) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7850000000000001421) ) ) {
                      result[0] += 0.026264306228991462;
                    } else {
                      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.652066519749839979) ) ) {
                        result[0] += -0.02477228495582442;
                      } else {
                        result[0] += 0.01915759365599564;
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001518500000000000101) ) ) {
                      result[0] += -0.03323980754305998;
                    } else {
                      result[0] += 0.004849166563846529;
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05814900000000000624) ) ) {
                result[0] += -0.005535376678460815;
              } else {
                result[0] += 0.017814056696611003;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003711500000000000389) ) ) {
            result[0] += 0.04302768605820466;
          } else {
            result[0] += 0.010963482447872049;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.948323453850665854) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5933854157035177712) ) ) {
        result[0] += 0.02818628078115146;
      } else {
        result[0] += 0.07540578941417339;
      }
    } else {
      result[0] += 0.07880655248451775;
    }
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8747476225597411448) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2194568116175419636) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1149663930196826306) ) ) {
        result[0] += -0.07935919247347227;
      } else {
        result[0] += -0.04415651743331386;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5540771664276676889) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2669585275879397535) ) ) {
          result[0] += 0.06108333774594382;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6411603019421380223) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.09500000000000001499) ) ) {
              result[0] += -0.037057532558706856;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04922519882226530918) ) ) {
                if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.08640936174704526296) ) ) {
                  if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.07308240583429688464) ) ) {
                    result[0] += 0;
                  } else {
                    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2646231565526572238) ) ) {
                      result[0] += 0;
                    } else {
                      result[0] += 0.13422839234174366;
                    }
                  }
                } else {
                  result[0] += -0.011296357824416995;
                }
              } else {
                if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.2295223687972280657) ) ) {
                  result[0] += 0.10255227425139407;
                } else {
                  result[0] += 0.009961520165211978;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8694659837631845134) ) ) {
              result[0] += -0.051530044508826964;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0186305000000000047) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
                  result[0] += -0.037963324883950524;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0237702400863027026) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)66.50000000000001421) ) ) {
                      result[0] += 0.05572096461730043;
                    } else {
                      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)105.5000000000000142) ) ) {
                        result[0] += -0.07092508839912266;
                      } else {
                        result[0] += 0.0016221935765226333;
                      }
                    }
                  } else {
                    result[0] += 0.09175713677475306;
                  }
                }
              } else {
                result[0] += -0.05468178931524113;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7341068085871017557) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8158067323869347964) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7801862323115579256) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8786021260481619022) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7295070658487954329) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002115500000000000626) ) ) {
                    result[0] += -0.004045690336871681;
                  } else {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6717423563567840317) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5508018452917812224) ) ) {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1556300000000000183) ) ) {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1325525000000000453) ) ) {
                            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02715150000000000549) ) ) {
                              result[0] += -0.00013487115412595907;
                            } else {
                              result[0] += 0.008375419876450754;
                            }
                          } else {
                            result[0] += -0.030656465866101917;
                          }
                        } else {
                          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5108901463567839807) ) ) {
                            result[0] += 0;
                          } else {
                            result[0] += 0.04662153129667811;
                          }
                        }
                      } else {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01115867171317260105) ) ) {
                          result[0] += 0.023093098866410207;
                        } else {
                          result[0] += -0.0613038684087621;
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6156410786045318773) ) ) {
                        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6903550358291458133) ) ) {
                          result[0] += 0.02930138187357102;
                        } else {
                          result[0] += -0.03348577997223539;
                        }
                      } else {
                        result[0] += 0.040936924075108815;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)368.5000000000000568) ) ) {
                    result[0] += -0.027215266254305506;
                  } else {
                    result[0] += 0.01884008084330304;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.009958500000000002073) ) ) {
                  result[0] += 0.040507093546814865;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9508668078567351634) ) ) {
                    result[0] += 0.02376809659394273;
                  } else {
                    result[0] += -0.030069773450394816;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03378350000000000103) ) ) {
                result[0] += -0.011625443066223456;
              } else {
                result[0] += -0.07095720656194068;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8168185667587940513) ) ) {
              result[0] += 0.09195306010346596;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1376275000000000415) ) ) {
                result[0] += -0.011115115397990637;
              } else {
                result[0] += 0.031963212066848636;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001454500000000000281) ) ) {
            result[0] += 0.057328385369836525;
          } else {
            result[0] += 0.012305423983599965;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.948323453850665854) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5933854157035177712) ) ) {
        result[0] += 0.026600335042856357;
      } else {
        result[0] += 0.07456492845033505;
      }
    } else {
      result[0] += 0.07826791644806304;
    }
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.891804912653853199) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2194568116175419636) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.03553482468997491012) ) ) {
        result[0] += -0.0779418301094768;
      } else {
        result[0] += -0.04126560767846875;
      }
    } else {
      if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5861769322017787998) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4225046379504136529) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)103.5000000000000142) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.635094393806739921e-06) ) ) {
                result[0] += -0.06356569062239008;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3250000000000000666) ) ) {
                  result[0] += -0.014689236122734246;
                } else {
                  result[0] += 0.0492552993131323;
                }
              }
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2315209029506543892) ) ) {
                result[0] += -0.049212142673826405;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5881074671461999914) ) ) {
                  result[0] += 0.04808478401760969;
                } else {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8019656772613066309) ) ) {
                    result[0] += -0.042131711209551115;
                  } else {
                    result[0] += 0.05055292873057096;
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004536500000000001469) ) ) {
              result[0] += -0.04971643204713902;
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.0491948752242571466) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4732638062311557703) ) ) {
                  result[0] += -0.02209332111933001;
                } else {
                  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.1495568471360887719) ) ) {
                    result[0] += 0;
                  } else {
                    result[0] += 0.1123226986721958;
                  }
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03356779836971720415) ) ) {
                  result[0] += -0.03965715513938317;
                } else {
                  result[0] += 0.005167361893255626;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.15279672222658669) ) ) {
            result[0] += 0.0428504933886244;
          } else {
            if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.2475169621399765651) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01066013304459604953) ) ) {
                result[0] += -0.015606701576825834;
              } else {
                result[0] += 0.039254393401419334;
              }
            } else {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4910439224693378679) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8066186623115578769) ) ) {
                  result[0] += -0.02977214163035612;
                } else {
                  result[0] += 0.03172565670306955;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002343500000000000531) ) ) {
                  result[0] += -0.008226774362742465;
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.316125881950671872) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.003618129605269550502) ) ) {
                      result[0] += 0.07381454956330648;
                    } else {
                      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4573000492713568677) ) ) {
                        result[0] += -0.0008477003561249146;
                      } else {
                        result[0] += 0.04079447077276974;
                      }
                    }
                  } else {
                    if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.08835747683243963535) ) ) {
                      result[0] += -0.017682290887612796;
                    } else {
                      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.0722510271427987405) ) ) {
                        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                          result[0] += 0.09175514313597168;
                        } else {
                          result[0] += 0.0014243608816266078;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07110500000000001541) ) ) {
                          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2750000000000000777) ) ) {
                            result[0] += 0.038183812136502814;
                          } else {
                            result[0] += 0.0010063109332178188;
                          }
                        } else {
                          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8687710690772928457) ) ) {
                            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)53.50000000000000711) ) ) {
                              if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.3959690607845650079) ) ) {
                                result[0] += -0.008033217829634405;
                              } else {
                                result[0] += 0.051231993094536035;
                              }
                            } else {
                              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)909.5000000000001137) ) ) {
                                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03472535815988600505) ) ) {
                                  result[0] += -0.05061164445993025;
                                } else {
                                  result[0] += -0.004193010722433266;
                                }
                              } else {
                                result[0] += 0.025761057996734876;
                              }
                            }
                          } else {
                            result[0] += -0.04788197636653426;
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7903724875956132934) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8950000000000001288) ) ) {
            result[0] += 0.02193483843198612;
          } else {
            result[0] += 0.0031881238506956907;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += 0.03336523610755014;
          } else {
            if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9401337961119743403) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
                result[0] += 0.03577100416332667;
              } else {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1009128553429559788) ) ) {
                  result[0] += -0.08472905049465707;
                } else {
                  result[0] += 0.008197588450022355;
                }
              }
            } else {
              result[0] += -0.0773679866615537;
            }
          }
        }
      }
    }
  } else {
    result[0] += 0.06389314296828409;
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8859917940727212171) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2194568116175419636) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1149663930196826306) ) ) {
        result[0] += -0.07851996327979574;
      } else {
        result[0] += -0.04046763863890412;
      }
    } else {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5452475257179970614) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3944417379768624943) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)108.5000000000000142) ) ) {
              result[0] += -0.020159648808220947;
            } else {
              if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.10222538506609119) ) ) {
                if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.08788950221151013709) ) ) {
                  result[0] += 0;
                } else {
                  result[0] += 0.133810822833801;
                }
              } else {
                result[0] += 0.004203251668480648;
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1450000000000000455) ) ) {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3077928457995839362) ) ) {
                result[0] += -0.04435951997542269;
              } else {
                result[0] += 0.004995299279391688;
              }
            } else {
              result[0] += -0.059709066590299585;
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)420.5000000000000568) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8950000000000001288) ) ) {
              if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.1946989117759076737) ) ) {
                result[0] += 0.03795303659859819;
              } else {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.08835747683243963535) ) ) {
                  if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.121863051132545086) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)21.50000000000000355) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5850000000000000755) ) ) {
                        result[0] += -0.0406687021493398;
                      } else {
                        result[0] += 0;
                      }
                    } else {
                      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)24.50000000000000355) ) ) {
                        result[0] += 0.05894570298280537;
                      } else {
                        result[0] += 0;
                      }
                    }
                  } else {
                    result[0] += -0.04994242020111625;
                  }
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.0491948752242571466) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)17.50000000000000355) ) ) {
                      result[0] += 0.089213680414766;
                    } else {
                      if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05227730674148379358) ) ) {
                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04307579058463605753) ) ) {
                          result[0] += -0.025558369720151186;
                        } else {
                          result[0] += 0.061061349354750466;
                        }
                      } else {
                        result[0] += 0.07298297120705395;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08814650000000001651) ) ) {
                      result[0] += 0;
                    } else {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07287111975896176652) ) ) {
                        result[0] += -0.03614901499955722;
                      } else {
                        result[0] += 0.014171831080031304;
                      }
                    }
                  }
                }
              }
            } else {
              result[0] += -0.03132402514612238;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5850000000000000755) ) ) {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5002776212835359226) ) ) {
                result[0] += -0.05066168448481614;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3650000000000000466) ) ) {
                  result[0] += 0.04395865388696341;
                } else {
                  result[0] += -0.0024289072271736446;
                }
              }
            } else {
              result[0] += -0.0382114791783605;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7528363226160118549) ) ) {
          if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.4839807590921524905) ) ) {
            result[0] += 0.025718213197193023;
          } else {
            if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5561723236404935156) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02337959905314275152) ) ) {
                result[0] += -0.0030974192066407654;
              } else {
                result[0] += -0.04962192616099594;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6450000000000001288) ) ) {
                result[0] += 0.03416000462962293;
              } else {
                result[0] += 0.0019107696706419238;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01184850000000000139) ) ) {
            result[0] += 0.03005434583139735;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
              result[0] += 0.027057554416614497;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6690536170100503943) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06916375701194471537) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)63.50000000000000711) ) ) {
                    result[0] += 0.026095328978815516;
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)125.5000000000000142) ) ) {
                      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5408295445477387942) ) ) {
                        result[0] += -0.12190115466509938;
                      } else {
                        result[0] += -0.0035009041167663856;
                      }
                    } else {
                      result[0] += 0.010475919249033344;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03692650000000000793) ) ) {
                    result[0] += 0.02623039790381559;
                  } else {
                    result[0] += -0.10155148297815483;
                  }
                }
              } else {
                result[0] += 0.04557000484981703;
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.948323453850665854) ) ) {
      result[0] += 0.03956569072715987;
    } else {
      result[0] += 0.07721931600073763;
    }
  }
}

