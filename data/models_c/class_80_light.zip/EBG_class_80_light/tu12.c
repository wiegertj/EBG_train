
#include "header.h"

void predict_unit12(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1313656708211964064) ) ) {
    result[0] += -0.04987821004152972;
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.919425862722463072) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4429728266653536473) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3315854282412060705) ) ) {
          result[0] += 0.0562257280909558;
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.464974115402010113) ) ) {
            result[0] += -0.02928887314787477;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.578780523307733108) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5664498681879840403) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4827419593969848877) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1350000000000000366) ) ) {
                    result[0] += 0.059180565005075965;
                  } else {
                    result[0] += -0.025558261331317837;
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1450000000000000455) ) ) {
                    result[0] += -0.020270779599288254;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2326999203141443262) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02684081951049300391) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5485006052512563235) ) ) {
                          result[0] += -0.0020985782812362693;
                        } else {
                          result[0] += 0.04357774945496426;
                        }
                      } else {
                        result[0] += -0.02351273998649615;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6148066793467338309) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.590212735175879577) ) ) {
                          result[0] += 0.006027173680851463;
                        } else {
                          result[0] += 0.07931331360437674;
                        }
                      } else {
                        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3350000000000000755) ) ) {
                          result[0] += 0.010692670184314166;
                        } else {
                          result[0] += -0.03794562567459852;
                        }
                      }
                    }
                  }
                }
              } else {
                result[0] += 0.0944271647184114;
              }
            } else {
              result[0] += -0.01861752227906863;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7881101830206976855) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2060867271409693446) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04165966230720380414) ) ) {
              result[0] += -0.0023923697328821747;
            } else {
              result[0] += 0.026342685319039574;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4997404627345643502) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
                result[0] += -0.0025138022070503364;
              } else {
                result[0] += -0.031135094369155212;
              }
            } else {
              result[0] += 0.00026822466350064723;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9950000000000001066) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              result[0] += 0.03615707079655917;
            } else {
              result[0] += 0.010314512220837775;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03808300000000000574) ) ) {
              result[0] += -0.039377756850628456;
            } else {
              result[0] += 0.006736277075620382;
            }
          }
        }
      }
    } else {
      result[0] += 0.03468064698648812;
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1313656708211964064) ) ) {
    result[0] += -0.04953816622856692;
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8902231111662372021) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3881589449934809699) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
          result[0] += 0.0005266299945053853;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00587150000000000085) ) ) {
              result[0] += -0.024953248108037493;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7242520756532664361) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006851500000000000819) ) ) {
                  result[0] += 0.048175491133935176;
                } else {
                  result[0] += -0.014538165859518363;
                }
              } else {
                result[0] += 0.05432689151003791;
              }
            }
          } else {
            result[0] += -0.041691809745652335;
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3073450000000000348) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5668346010835486615) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4073174598994975804) ) ) {
              if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4314418144595498217) ) ) {
                result[0] += -0.005412067733025486;
              } else {
                result[0] += -0.029936204385985044;
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4141149047989949872) ) ) {
                result[0] += 0.024241762991904486;
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1988654957757923225) ) ) {
                  result[0] += 0.022404460253775623;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8950000000000001288) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6480364325376885004) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6186550572613066512) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5910501547487437835) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5811189422864322385) ) ) {
                            result[0] += -6.583315694350219e-05;
                          } else {
                            result[0] += -0.025531731055453647;
                          }
                        } else {
                          result[0] += 0.011827029852090852;
                        }
                      } else {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3595998346489175934) ) ) {
                          result[0] += -0.04021449668627384;
                        } else {
                          result[0] += -0.004981940463769698;
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3892782419974109565) ) ) {
                        result[0] += 0.034747580642573675;
                      } else {
                        result[0] += 0.002664408115469012;
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6161319161557790025) ) ) {
                      result[0] += 0.00019864669377661452;
                    } else {
                      result[0] += -0.014798509119309413;
                    }
                  }
                }
              }
            }
          } else {
            result[0] += 0.0024284533203809194;
          }
        } else {
          result[0] += 0.020599252814133526;
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9673254386414430472) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.512422281582914696) ) ) {
          result[0] += 0.00407649089702891;
        } else {
          result[0] += 0.03469990566398845;
        }
      } else {
        result[0] += 0.04894162908644477;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1313656708211964064) ) ) {
    result[0] += -0.04918457374851129;
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.919425862722463072) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4604805625892014476) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3315854282412060705) ) ) {
          result[0] += 0.04783159028607995;
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4642381624371859083) ) ) {
            result[0] += -0.02862106051836479;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5296250784170855042) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3050000000000000488) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02500000000000000486) ) ) {
                  result[0] += 0.05382399303294607;
                } else {
                  result[0] += -0.000614222481065992;
                }
              } else {
                result[0] += 0.05969272382941527;
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5477977269597991139) ) ) {
                result[0] += -0.0393367720418042;
              } else {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.05751864358971629093) ) ) {
                  result[0] += 0.04052816438634643;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1950000000000000344) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2067761146441342568) ) ) {
                        result[0] += -0.012333576979182682;
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7538378520100503799) ) ) {
                          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.578780523307733108) ) ) {
                            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6357510373366835887) ) ) {
                              result[0] += 0.006812472502636042;
                            } else {
                              result[0] += 0.07975176365667548;
                            }
                          } else {
                            result[0] += -0.033144790013518825;
                          }
                        } else {
                          result[0] += 0.07724393061042388;
                        }
                      }
                    } else {
                      result[0] += -0.01045014206135264;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3930944169495623197) ) ) {
                      result[0] += -0.023056031974413898;
                    } else {
                      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2295059026793999646) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6574014915075377941) ) ) {
                          result[0] += -0.0021928808344665483;
                        } else {
                          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02012550000000000103) ) ) {
                            result[0] += 0.0704675520684142;
                          } else {
                            result[0] += 0;
                          }
                        }
                      } else {
                        result[0] += -0.029409463692847138;
                      }
                    }
                  }
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.736034375232267446) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002853500000000000567) ) ) {
            result[0] += -0.002469377950971574;
          } else {
            result[0] += 0.0012202842629093988;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8850000000000001199) ) ) {
            result[0] += 0.029197346419666047;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
              result[0] += 0.03006932711141643;
            } else {
              result[0] += 0.0028786825790227217;
            }
          }
        }
      }
    } else {
      result[0] += 0.03319623084257982;
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1313656708211964064) ) ) {
    result[0] += -0.048817039738331014;
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9375437694740959005) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3356592091331648819) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3315854282412060705) ) ) {
          result[0] += 0.050503401707800856;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0003975000000000000668) ) ) {
            result[0] += -0.0021178717260964233;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.741770399346733833) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7242520756532664361) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02237600000000000353) ) ) {
                  result[0] += -0.028796792652640367;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5352759199748745589) ) ) {
                    result[0] += 0.04454179190225576;
                  } else {
                    result[0] += -0.014572967109298897;
                  }
                }
              } else {
                result[0] += 0.03399757362080654;
              }
            } else {
              result[0] += -0.04644882055024612;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7946879440622868218) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1350000000000000366) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.120255588936453009) ) ) {
              result[0] += 0.06379903272395063;
            } else {
              result[0] += 0.002893009381054511;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1450000000000000455) ) ) {
              result[0] += -0.02621470415914568;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4073174598994975804) ) ) {
                if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4025583117277176659) ) ) {
                  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5510744084463640169) ) ) {
                    result[0] += -0.008348272763811483;
                  } else {
                    result[0] += 0.006162801684984664;
                  }
                } else {
                  result[0] += -0.025348452826725897;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4394533747236181176) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7350000000000000977) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5250000000000001332) ) ) {
                      result[0] += 0.0018427303324369676;
                    } else {
                      result[0] += -0.03579608748053072;
                    }
                  } else {
                    result[0] += 0.01808659489718588;
                  }
                } else {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3763018001168558224) ) ) {
                    result[0] += -0.027487261753802884;
                  } else {
                    if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3439225837886180082) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01122900000000000113) ) ) {
                        result[0] += 0.01028056292684248;
                      } else {
                        result[0] += 0.04606134278684601;
                      }
                    } else {
                      result[0] += -0.00021986535730341398;
                    }
                  }
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9950000000000001066) ) ) {
            result[0] += 0.014717158384841304;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04096050000000000385) ) ) {
              result[0] += -0.02625037605303735;
            } else {
              result[0] += 0.01018942034067537;
            }
          }
        }
      }
    } else {
      result[0] += 0.035920090338708965;
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1313656708211964064) ) ) {
    result[0] += -0.04843519560175047;
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9375437694740959005) ) ) {
      if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.394173313988213314) ) ) {
        result[0] += 0.03742628702769527;
      } else {
        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.8085344187842374852) ) ) {
          result[0] += -0.01717788641715781;
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3315854282412060705) ) ) {
            result[0] += 0.02638894927511853;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1450000000000000455) ) ) {
              result[0] += -0.015244318151792939;
            } else {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6690753303250667194) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8450000000000000844) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.276839473796588853) ) ) {
                    result[0] += -0.024164798579605663;
                  } else {
                    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.120255588936453009) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3076535050425012741) ) ) {
                        result[0] += -0.0012014309717054141;
                      } else {
                        result[0] += 0.04875199987493117;
                      }
                    } else {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002853500000000000567) ) ) {
                        result[0] += -0.0030221292240097024;
                      } else {
                        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.5708656043828381765) ) ) {
                          result[0] += -0.015464836109136891;
                        } else {
                          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4627502129294571165) ) ) {
                            result[0] += 0.026517405214947033;
                          } else {
                            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4073174598994975804) ) ) {
                              result[0] += -0.016882064837681197;
                            } else {
                              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2091302419391287415) ) ) {
                                result[0] += 0.011285463380742784;
                              } else {
                                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4899381758793970865) ) ) {
                                  result[0] += -0.018391773678292193;
                                } else {
                                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.04908445857219279757) ) ) {
                                    result[0] += 0.014492986830988396;
                                  } else {
                                    result[0] += -0.00037712191800031466;
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                } else {
                  result[0] += -0.019689356728455887;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6669784622613067482) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1295212041281339765) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1027559661512248146) ) ) {
                      result[0] += 0.003878534441953143;
                    } else {
                      result[0] += 0.02963741991463644;
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.09838300000000001211) ) ) {
                      result[0] += -0.010597266136430156;
                    } else {
                      result[0] += 0.030600319583672812;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7293493725076146683) ) ) {
                    result[0] += 0.03717552850793972;
                  } else {
                    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7729377599117425168) ) ) {
                      result[0] += -0.0026873102364270676;
                    } else {
                      result[0] += 0.026938383107625006;
                    }
                  }
                }
              }
            }
          }
        }
      }
    } else {
      result[0] += 0.035157932938733975;
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1313656708211964064) ) ) {
    result[0] += -0.0480386850365792;
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9446153469900331334) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5818191821885695392) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004774500000000000098) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7704717287437187201) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7156546188693468924) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5449349093854115589) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6148066793467338309) ) ) {
                    if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.05227730674148379358) ) ) {
                      result[0] += -0.004943508501484318;
                    } else {
                      result[0] += 0.01132755910202833;
                    }
                  } else {
                    result[0] += -0.01711906749049059;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.578780523307733108) ) ) {
                    result[0] += 0.07036843183503559;
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3150000000000000577) ) ) {
                      result[0] += -0.03634106111252266;
                    } else {
                      result[0] += 0.04481395896741604;
                    }
                  }
                }
              } else {
                result[0] += -0.021109171678050178;
              }
            } else {
              result[0] += 0.01985203233539352;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4806185349221548386) ) ) {
              result[0] += -0.02491006509286628;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0007145000000000001827) ) ) {
                result[0] += -0.019631850105606644;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0009635000000000000552) ) ) {
                  result[0] += 0.014746645142313523;
                } else {
                  result[0] += -0.005269289311556613;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006340500000000001517) ) ) {
            result[0] += 0.01148938780760167;
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9050000000000001377) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2802420000000000466) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.089430082328138649) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.02448774902434403) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9570114589738922817) ) ) {
                      result[0] += 0.0004556449300020368;
                    } else {
                      result[0] += -0.02697251165049308;
                    }
                  } else {
                    result[0] += 0.05508756092035568;
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6750000000000001554) ) ) {
                    result[0] += -0.02992281265664596;
                  } else {
                    result[0] += 0.0014148468340723732;
                  }
                }
              } else {
                result[0] += 0.023568554138680236;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.7050000000000000711) ) ) {
                if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5564233291784753677) ) ) {
                  result[0] += -0.012887121715964003;
                } else {
                  result[0] += 0.019084620466788882;
                }
              } else {
                result[0] += -0.025697102802630285;
              }
            }
          }
        }
      } else {
        result[0] += 0.002834736181155706;
      }
    } else {
      result[0] += 0.03645461661821181;
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1313656708211964064) ) ) {
    result[0] += -0.04762718555237804;
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8502789422115718532) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4429728266653536473) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3315854282412060705) ) ) {
          result[0] += 0.0446400096563702;
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4731422897738694067) ) ) {
            result[0] += -0.025646812405402605;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4795216591959799435) ) ) {
              result[0] += 0.07870522267316622;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.578780523307733108) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5664498681879840403) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2252215573829355333) ) ) {
                    result[0] += -0.029543432910135222;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3550761912678883081) ) ) {
                      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1645254211347557949) ) ) {
                        result[0] += 0;
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5140962685175880509) ) ) {
                          result[0] += 0.015259467437323907;
                        } else {
                          result[0] += -0.031052883961881883;
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3892782419974109565) ) ) {
                        result[0] += 0.052573865270878276;
                      } else {
                        result[0] += 0.0028185679726833116;
                      }
                    }
                  }
                } else {
                  result[0] += 0.07798098971904718;
                }
              } else {
                result[0] += -0.016277324746162208;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3073450000000000348) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.8085344187842374852) ) ) {
            result[0] += -0.009952344785711734;
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.7078191309122573438) ) ) {
              result[0] += 0.021617940082207254;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3622054098241206943) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3454233478894472853) ) ) {
                  result[0] += 0.0010908527846499674;
                } else {
                  result[0] += -0.03252481656281888;
                }
              } else {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4627502129294571165) ) ) {
                  result[0] += 0.008252479439860757;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4141149047989949872) ) ) {
                    result[0] += -0.01680348613803164;
                  } else {
                    result[0] += 0.0003127644736556627;
                  }
                }
              }
            }
          }
        } else {
          result[0] += 0.018458422168072645;
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9673254386414430472) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5140962685175880509) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5002620384924624242) ) ) {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9571120492262563673) ) ) {
              result[0] += 0.012898476165895142;
            } else {
              result[0] += -0.046219317992263455;
            }
          } else {
            result[0] += -0.05366729890745655;
          }
        } else {
          result[0] += 0.030676696412989105;
        }
      } else {
        result[0] += 0.047288825844917566;
      }
    }
  }
}

