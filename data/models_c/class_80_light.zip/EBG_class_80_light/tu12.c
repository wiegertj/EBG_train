
#include "header.h"

void predict_unit12(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003250500000000000351) ) ) {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
      result[0] += 0.017801245597252754;
    } else {
      result[0] += -0.017639118187274722;
    }
  } else {
    result[0] += 0.0052557740839494415;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.476940556467977228) ) ) {
    result[0] += -0.020469855357770694;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.545000000000000151) ) ) {
      result[0] += 0.024453882074568542;
    } else {
      result[0] += -0.0013620825926073605;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6338667615763527996) ) ) {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.625000000000000111) ) ) {
      result[0] += -0.00195913136467001;
    } else {
      result[0] += -0.05324311366521733;
    }
  } else {
    result[0] += 0.003820972808326032;
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.01777245248711925227) ) ) {
    result[0] += -0.11228195717862664;
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2669585275879397535) ) ) {
      result[0] += 0.044727236815310795;
    } else {
      result[0] += -0.0005390904918636295;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9532041455015286546) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.01777245248711925227) ) ) {
      result[0] += -0.11158440225196821;
    } else {
      result[0] += -0.00015429319440308148;
    }
  } else {
    result[0] += 0.08525912718330995;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6435024531842806761) ) ) {
    result[0] += -0.0031252104526753653;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9650000000000000799) ) ) {
      result[0] += 0.06458843097447475;
    } else {
      result[0] += 0.0051756416583720105;
    }
  }
}

