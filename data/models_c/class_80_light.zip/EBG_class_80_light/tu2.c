
#include "header.h"

void predict_unit2(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7622764819475024156) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5373923050813967928) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2727691064925280018) ) ) {
        result[0] += -0.06538914140511758;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4429728266653536473) ) ) {
          result[0] += -0.05712924728684281;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1850000000000000255) ) ) {
            result[0] += -0.020535124440399555;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3650000000000000466) ) ) {
              result[0] += -0.0437034965335341;
            } else {
              result[0] += -0.05650030119051946;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6972829280248278305) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.25500000000000006) ) ) {
          result[0] += 0.0008092602510612265;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5897839699588115492) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3931461612883267454) ) ) {
              result[0] += -0.030919358727524705;
            } else {
              result[0] += -0.052482870688933175;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6850000000000001643) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
                result[0] += 0;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002467500000000000509) ) ) {
                  result[0] += -0.044874703006819325;
                } else {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.01414472145045409836) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4936490898241205905) ) ) {
                      result[0] += -0.01707663801605451;
                    } else {
                      result[0] += 0.0204729005192038;
                    }
                  } else {
                    result[0] += -0.023833178266009447;
                  }
                }
              }
            } else {
              result[0] += -0.03306652341092081;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4750000000000000333) ) ) {
          result[0] += 0.014834347586068063;
        } else {
          result[0] += -0.004840218595992312;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9024131424400998469) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8436766892707049381) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7998185917227689234) ) ) {
          result[0] += 0.010729435123597227;
        } else {
          result[0] += 0.02304456564649117;
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6170632793331903843) ) ) {
          result[0] += 0.03131911909185934;
        } else {
          result[0] += 0.044622594674823234;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7946879440622868218) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6869614610244983988) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6486987125073885307) ) ) {
              result[0] += 0.05056973589304814;
            } else {
              result[0] += 0.07239177037929945;
            }
          } else {
            result[0] += 0.03738795498283471;
          }
        } else {
          result[0] += 0.06331491498739503;
        }
      } else {
        result[0] += 0.0765010178422923;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7423774199879572544) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5373923050813967928) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2727691064925280018) ) ) {
        result[0] += -0.0646492112531182;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4429728266653536473) ) ) {
          result[0] += -0.05606060469483207;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1850000000000000255) ) ) {
            result[0] += -0.019641663738504976;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3650000000000000466) ) ) {
              result[0] += -0.042417660755978755;
            } else {
              result[0] += -0.05537785729135237;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6589536398896721492) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5250000000000001332) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.25500000000000006) ) ) {
            result[0] += 0;
          } else {
            result[0] += -0.024597674923712315;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5798905718019149447) ) ) {
            result[0] += -0.04922565769956216;
          } else {
            result[0] += -0.033453428684613935;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7068923547583354505) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4336191825501565789) ) ) {
            result[0] += 0.0055724796051434275;
          } else {
            result[0] += -0.021696988739391906;
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4803596738785403941) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1347820638606622157) ) ) {
              result[0] += -0.009091835879404321;
            } else {
              result[0] += 0.014265291957074763;
            }
          } else {
            result[0] += -0.011707956441290367;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9024131424400998469) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8146542383663726294) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6450000000000001288) ) ) {
          result[0] += 0.017394667808051576;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7875939310552765305) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9450000000000000622) ) ) {
              result[0] += -0.0006219298930913049;
            } else {
              result[0] += 0.013812902678813258;
            }
          } else {
            result[0] += -0.0180580841006305;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8664403834689663464) ) ) {
          result[0] += 0.0259576650397283;
        } else {
          result[0] += 0.04079460287077929;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7946879440622868218) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6869614610244983988) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6486987125073885307) ) ) {
              result[0] += 0.0483408952287475;
            } else {
              result[0] += 0.06961158092610663;
            }
          } else {
            result[0] += 0.03561296368886878;
          }
        } else {
          result[0] += 0.061091057036240015;
        }
      } else {
        result[0] += 0.07461664504465448;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7423774199879572544) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5373923050813967928) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2727691064925280018) ) ) {
        result[0] += -0.0639548744542069;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4429728266653536473) ) ) {
          result[0] += -0.0550213788158204;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1850000000000000255) ) ) {
            result[0] += -0.01877877917175533;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3650000000000000466) ) ) {
              result[0] += -0.041159278446195324;
            } else {
              result[0] += -0.05428612805239336;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6589536398896721492) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5250000000000001332) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.25500000000000006) ) ) {
            result[0] += 0;
          } else {
            result[0] += -0.023534553439988656;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5798905718019149447) ) ) {
            result[0] += -0.04796632713615659;
          } else {
            result[0] += -0.03220004227049546;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7068923547583354505) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4336191825501565789) ) ) {
            result[0] += 0.0052490283174021985;
          } else {
            result[0] += -0.020703185327820853;
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4803596738785403941) ) ) {
            result[0] += 0.006288307257384891;
          } else {
            result[0] += -0.01110103803860889;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9024131424400998469) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8146542383663726294) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7803782188884571536) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4627502129294571165) ) ) {
            result[0] += 0.025673501073451406;
          } else {
            result[0] += 0.0016349120915940742;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6750000000000001554) ) ) {
            result[0] += 0.024615312765757368;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9350000000000001643) ) ) {
              result[0] += -0.008805257862537974;
            } else {
              result[0] += 0.015306904721318038;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8664403834689663464) ) ) {
          result[0] += 0.024521248782193087;
        } else {
          result[0] += 0.03876901697623365;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7946879440622868218) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7149490869166016394) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6413546906794281854) ) ) {
              result[0] += 0.045610210871375116;
            } else {
              result[0] += 0.062031196842302704;
            }
          } else {
            result[0] += 0.03871813282558553;
          }
        } else {
          result[0] += 0.060662092520432996;
        }
      } else {
        result[0] += 0.07289135574479601;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7277004308735181004) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5373923050813967928) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2727691064925280018) ) ) {
        result[0] += -0.06330154937997157;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4604805625892014476) ) ) {
          result[0] += -0.05352377966158538;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1850000000000000255) ) ) {
            result[0] += -0.01055338570536448;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3650000000000000466) ) ) {
              result[0] += -0.03638126424368768;
            } else {
              result[0] += -0.05300456802227983;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6589536398896721492) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5250000000000001332) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.25500000000000006) ) ) {
            result[0] += 0;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5845852065869253655) ) ) {
              result[0] += -0.028589138192133764;
            } else {
              result[0] += -0.013314198383183193;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5798905718019149447) ) ) {
            result[0] += -0.046734358843116296;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003040500000000000234) ) ) {
              result[0] += -0.03804019963724098;
            } else {
              result[0] += -0.023320723602796935;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4470670498171123719) ) ) {
          result[0] += -0.0047633268889404985;
        } else {
          result[0] += -0.01995687016416831;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9024131424400998469) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8098966366947321083) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.07738700000000002521) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0003555000000000000759) ) ) {
            result[0] += 0.0280702516098532;
          } else {
            result[0] += 0.0040837820398236906;
          }
        } else {
          result[0] += 0.028126495501999405;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8664403834689663464) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.5708656043828381765) ) ) {
            result[0] += 0.0022792794891959797;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5259885771356785922) ) ) {
              result[0] += 0.03422833628322971;
            } else {
              result[0] += 0.019723727402338794;
            }
          }
        } else {
          result[0] += 0.036859620623744184;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8257976220666124467) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7149490869166016394) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6486987125073885307) ) ) {
              result[0] += 0.04418192977580143;
            } else {
              result[0] += 0.06054321131819128;
            }
          } else {
            result[0] += 0.03701515570906216;
          }
        } else {
          result[0] += 0.05983137746569691;
        }
      } else {
        result[0] += 0.07230661122094545;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7277004308735181004) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5373923050813967928) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2727691064925280018) ) ) {
        result[0] += -0.06268513088794316;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4429728266653536473) ) ) {
          result[0] += -0.05302355178942224;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1850000000000000255) ) ) {
            result[0] += -0.016759183912682205;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
              result[0] += -0.03908089508714225;
            } else {
              result[0] += -0.05248997770025954;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6589536398896721492) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.346441672365271125) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5997198625535415939) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
              result[0] += -0.0069160584550972464;
            } else {
              result[0] += -0.028180634286843892;
            }
          } else {
            result[0] += -0.00642058313467492;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5897839699588115492) ) ) {
            result[0] += -0.04727707230677648;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6750000000000001554) ) ) {
              result[0] += -0.018208395931009456;
            } else {
              result[0] += -0.03473451522672672;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4470670498171123719) ) ) {
          result[0] += -0.0045045690235696175;
        } else {
          result[0] += -0.01902096150070723;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6690753303250667194) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.849950209132393053) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7803782188884571536) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5379554743138220685) ) ) {
            result[0] += 0.014583366760683171;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009307500000000001536) ) ) {
              result[0] += 0.0010735835965932665;
            } else {
              result[0] += -0.018123284859532726;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.07540250000000001118) ) ) {
            result[0] += 0.014993803390803024;
          } else {
            result[0] += 0.03607826435638038;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9465473169870071146) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002033500000000000151) ) ) {
            result[0] += 0.01031323689225598;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004578500000000000104) ) ) {
              result[0] += 0.051577650986044866;
            } else {
              result[0] += 0.031138087375069224;
            }
          }
        } else {
          result[0] += 0.05327290850971952;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8257976220666124467) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7149490869166016394) ) ) {
          result[0] += 0.04667524277681447;
        } else {
          result[0] += 0.058043891097518674;
        }
      } else {
        result[0] += 0.07086595905942956;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7277004308735181004) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5373923050813967928) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2727691064925280018) ) ) {
        result[0] += -0.06210191521261277;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4604805625892014476) ) ) {
          result[0] += -0.05154210612097187;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1850000000000000255) ) ) {
            result[0] += -0.009201164865610968;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3650000000000000466) ) ) {
              result[0] += -0.03389117822931728;
            } else {
              result[0] += -0.050922255895026504;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6589536398896721492) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.346441672365271125) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5997198625535415939) ) ) {
            result[0] += -0.02347839772838453;
          } else {
            result[0] += -0.006080052974896588;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5897839699588115492) ) ) {
            result[0] += -0.046106798656286245;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4384970621937981927) ) ) {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.009014249010710599294) ) ) {
                result[0] += 0.003209638538342881;
              } else {
                result[0] += -0.025939476841822406;
              }
            } else {
              result[0] += -0.03199176556110762;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4470670498171123719) ) ) {
          result[0] += -0.004259460712807922;
        } else {
          result[0] += -0.01812328712214299;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6690753303250667194) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8664403834689663464) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7803782188884571536) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8450000000000000844) ) ) {
            result[0] += 0.012167623054205014;
          } else {
            result[0] += -0.0029739891713066865;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6750000000000001554) ) ) {
            result[0] += 0.024522124822622834;
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.596398030554127434) ) ) {
              result[0] += 0.005773118771213994;
            } else {
              result[0] += 0.019064909640864294;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9465473169870071146) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3687216492462311868) ) ) {
            result[0] += 0.011562462086343045;
          } else {
            result[0] += 0.03428008177946925;
          }
        } else {
          result[0] += 0.05121738963495888;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8257976220666124467) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7149490869166016394) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += 0.05940032499881792;
          } else {
            result[0] += 0.04025143381385503;
          }
        } else {
          result[0] += 0.05632076575553323;
        }
      } else {
        result[0] += 0.06953422996749622;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7277004308735181004) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5089951851639061831) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2727691064925280018) ) ) {
        result[0] += -0.06154855927156497;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += -0.040904106731468166;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004774500000000000098) ) ) {
            result[0] += -0.0571910856631365;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -0.042951660921447095;
            } else {
              result[0] += -0.058320493065824056;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.626047238333421352) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
          result[0] += -0.00904609310283506;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4550000000000000711) ) ) {
              result[0] += -0.025377642019676114;
            } else {
              result[0] += 0.007974343661635467;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002467500000000000509) ) ) {
              result[0] += -0.04639009364072994;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5798905718019149447) ) ) {
                result[0] += -0.040861807234031246;
              } else {
                result[0] += -0.02230889833516668;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7050000000000000711) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6487823756783920315) ) ) {
            result[0] += -0.00891157318262346;
          } else {
            result[0] += 0.011613500855749088;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7068923547583354505) ) ) {
            result[0] += -0.023572805065847403;
          } else {
            result[0] += -0.002470244173859368;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6690753303250667194) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8250070987435854653) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.07540250000000001118) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0003555000000000000759) ) ) {
            result[0] += 0.02642351183789018;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7889021474406031631) ) ) {
              result[0] += 0.0011574165358499602;
            } else {
              result[0] += 0.010794543877687898;
            }
          }
        } else {
          result[0] += 0.025049747374649035;
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.882048175975067239) ) ) {
          result[0] += 0.02128895741914828;
        } else {
          result[0] += 0.03622077476587815;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8442376020855621999) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7149490869166016394) ) ) {
          result[0] += 0.04299537665747493;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += 0.057246584312527306;
          } else {
            result[0] += 0.037529763084913924;
          }
        }
      } else {
        result[0] += 0.06892034875952449;
      }
    }
  }
}

