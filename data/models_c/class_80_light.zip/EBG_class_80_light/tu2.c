
#include "header.h"

void predict_unit2(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8411472854784498576) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5246343807191508057) ) ) {
      result[0] += -0.11268720127420295;
    } else {
      result[0] += -0.008109572500402552;
    }
  } else {
    result[0] += 0.09950191339416173;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5981753503490724322) ) ) {
    result[0] += -0.09848375315841648;
  } else {
    if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7506159827274054841) ) ) {
      result[0] += 0.015751686245238438;
    } else {
      result[0] += 0.12651724051625207;
    }
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.556308630788158287) ) ) {
    result[0] += -0.10118793155619837;
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8179529620996692785) ) ) {
      result[0] += 0.011144140667544945;
    } else {
      result[0] += 0.12174658183990035;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6765778261593717868) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5036672824508469093) ) ) {
      result[0] += -0.1056493765819838;
    } else {
      result[0] += -0.005490183356649229;
    }
  } else {
    result[0] += 0.09207156934663747;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5246343807191508057) ) ) {
    result[0] += -0.09986086091631174;
  } else {
    if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7506159827274054841) ) ) {
      result[0] += 0.006366571798640857;
    } else {
      result[0] += 0.11592241365519103;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8411472854784498576) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4467417962507087004) ) ) {
      result[0] += -0.1058025576063643;
    } else {
      result[0] += -0.010556496400331305;
    }
  } else {
    result[0] += 0.0752185863389759;
  }
}

