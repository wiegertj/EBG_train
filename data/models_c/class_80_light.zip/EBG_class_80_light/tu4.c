
#include "header.h"

void predict_unit4(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5081850788976483013) ) ) {
    result[0] += -0.07731031572011199;
  } else {
    if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8166103485750532132) ) ) {
      result[0] += 0.0038942590079599974;
    } else {
      result[0] += 0.1047124181711433;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.798343720186302952) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2753139374759779323) ) ) {
      result[0] += -0.10545111142596697;
    } else {
      result[0] += -0.001457797423184799;
    }
  } else {
    result[0] += 0.09837421325291698;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8885060243296197813) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2753139374759779323) ) ) {
      result[0] += -0.1033658368228916;
    } else {
      result[0] += -0.008347902948515371;
    }
  } else {
    result[0] += 0.055762260317275526;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8509059882457595814) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2898514409486858123) ) ) {
      result[0] += -0.09896608635512276;
    } else {
      result[0] += -0.0007240316907652389;
    }
  } else {
    result[0] += 0.10439919461780398;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8643592654933326402) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2753139374759779323) ) ) {
      result[0] += -0.09892559788001154;
    } else {
      result[0] += -0.0006503052115564054;
    }
  } else {
    result[0] += 0.10492388125743272;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8708183926421412258) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2310845981254020243) ) ) {
      result[0] += -0.10377249329984568;
    } else {
      result[0] += -0.0009884749513143077;
    }
  } else {
    result[0] += 0.10403370727531182;
  }
}

