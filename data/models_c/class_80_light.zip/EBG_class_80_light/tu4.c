
#include "header.h"

void predict_unit4(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7019812713501991652) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4806185349221548386) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2642961365573822663) ) ) {
        result[0] += -0.05810688682646065;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += -0.03409870665498878;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005066500000000000691) ) ) {
            result[0] += -0.05243792572513986;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -0.035857038451893836;
            } else {
              result[0] += -0.05448632092826277;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5640404622805753609) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2879158236070033516) ) ) {
          result[0] += -0.018281656730365286;
        } else {
          result[0] += -0.03855169709636105;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
          if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.01051018765715429869) ) ) {
            result[0] += 0.014050961748393744;
          } else {
            result[0] += -0.015317128307261048;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6491668737719177296) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4384970621937981927) ) ) {
              result[0] += -0.014616906251316284;
            } else {
              result[0] += -0.028611918424207714;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5138750625816285167) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0308805000000000017) ) ) {
                result[0] += -0.00032958109697915394;
              } else {
                result[0] += -0.02402286178912578;
              }
            } else {
              result[0] += -0.020782298836109415;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7149490869166016394) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8620911151915734427) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 0.03299505983792278;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7998185917227689234) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4850000000000000422) ) ) {
              result[0] += 0.013431204469050924;
            } else {
              result[0] += -0.0009623440860383606;
            }
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.5708656043828381765) ) ) {
              result[0] += -0.008378054944638167;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5618750333550593945) ) ) {
                result[0] += 0.030445352565518554;
              } else {
                result[0] += 0.010409914348354131;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9221644235475580098) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6170632793331903843) ) ) {
            result[0] += 0.012915952077716853;
          } else {
            result[0] += 0.026673373287125258;
          }
        } else {
          result[0] += 0.03344373756402006;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8502789422115718532) ) ) {
        result[0] += 0.04479534462616646;
      } else {
        result[0] += 0.06181219997827829;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7019812713501991652) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4429728266653536473) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2296243883448841061) ) ) {
        result[0] += -0.05851060091848779;
      } else {
        result[0] += -0.044470054886926985;
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5640404622805753609) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2060867271409693446) ) ) {
          result[0] += -0.0059932915477310805;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4997404627345643502) ) ) {
            result[0] += -0.04422446608742092;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.07175569222910598011) ) ) {
                result[0] += -0.02467399993744506;
              } else {
                result[0] += 0.009089948618811974;
              }
            } else {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2798871519643466033) ) ) {
                result[0] += -0.01789912460220649;
              } else {
                result[0] += -0.03775822782445611;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02962100000000000496) ) ) {
            result[0] += 0.02247940464438065;
          } else {
            result[0] += -0.00860630481714329;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6491668737719177296) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4650000000000000244) ) ) {
                result[0] += -0.021231944383816603;
              } else {
                result[0] += 0.013329087887787977;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001003500000000000269) ) ) {
                result[0] += -0.045129008178996045;
              } else {
                result[0] += -0.02032476829871154;
              }
            }
          } else {
            result[0] += -0.010032973192862412;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7149490869166016394) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8664403834689663464) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7803782188884571536) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4518709121403587381) ) ) {
            result[0] += 0.020685195695321252;
          } else {
            result[0] += -0.0008537892042609444;
          }
        } else {
          result[0] += 0.00992899460228755;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9221644235475580098) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.5458327589225927534) ) ) {
            result[0] += 0.0012172564589498346;
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6170632793331903843) ) ) {
              result[0] += 0.014167599052618288;
            } else {
              result[0] += 0.0284932217896058;
            }
          }
        } else {
          result[0] += 0.03211866512355684;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8442376020855621999) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
          result[0] += 0.045234391192119854;
        } else {
          result[0] += 0.023722959023759215;
        }
      } else {
        result[0] += 0.06088615756533773;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7068923547583354505) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4429728266653536473) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2642961365573822663) ) ) {
        result[0] += -0.0573516345237952;
      } else {
        result[0] += -0.04247525254327617;
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5640404622805753609) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2060867271409693446) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.05035649857444463723) ) ) {
            result[0] += -0.023079322336033374;
          } else {
            result[0] += 0.0035614000880668985;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4997404627345643502) ) ) {
            result[0] += -0.04329336539731936;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.07175569222910598011) ) ) {
                result[0] += -0.02368245290483011;
              } else {
                result[0] += 0.008530548088518535;
              }
            } else {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2798871519643466033) ) ) {
                result[0] += -0.017116164116162094;
              } else {
                result[0] += -0.036742870391445734;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7050000000000000711) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.626047238333421352) ) ) {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.346441672365271125) ) ) {
              result[0] += -0.006643777952942437;
            } else {
              result[0] += -0.023372974801873315;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6425364825628142595) ) ) {
              result[0] += -0.005405572474603396;
            } else {
              result[0] += 0.014719669307341475;
            }
          }
        } else {
          result[0] += -0.018541000949406188;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7149490869166016394) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8664403834689663464) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7803782188884571536) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8450000000000000844) ) ) {
            result[0] += 0.005611243481217749;
          } else {
            result[0] += -0.003299867243575462;
          }
        } else {
          result[0] += 0.009377758697082454;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9221644235475580098) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3687216492462311868) ) ) {
            result[0] += 0;
          } else {
            result[0] += 0.02159589626464434;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8950000000000001288) ) ) {
            result[0] += 0.034103360095816805;
          } else {
            result[0] += 0.009699337873539549;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8502789422115718532) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7881101830206976855) ) ) {
            result[0] += 0.03891120078494639;
          } else {
            result[0] += 0.051193101324099564;
          }
        } else {
          result[0] += 0.02667413251993586;
        }
      } else {
        result[0] += 0.060433637026379314;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6972829280248278305) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4429728266653536473) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2296243883448841061) ) ) {
        result[0] += -0.05784587136809046;
      } else {
        result[0] += -0.042697653982694844;
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5373923050813967928) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2060867271409693446) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.05035649857444463723) ) ) {
            result[0] += -0.024630770860877296;
          } else {
            result[0] += 0.004339958030989197;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004774500000000000098) ) ) {
            result[0] += -0.04521504597148091;
          } else {
            result[0] += -0.026213284839966555;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
          result[0] += 0.005100469010957246;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6213841400436609375) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.346441672365271125) ) ) {
              result[0] += -0.012085941051210611;
            } else {
              result[0] += -0.029359768638555103;
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8850000000000001199) ) ) {
              result[0] += -0.007555449833520568;
            } else {
              result[0] += -0.025920358360271848;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7149490869166016394) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8620911151915734427) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 0.03186166505575314;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7622764819475024156) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4518709121403587381) ) ) {
              result[0] += 0.016260332721240573;
            } else {
              result[0] += -0.004022834029534335;
            }
          } else {
            result[0] += 0.006863636783541381;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9221644235475580098) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6869304497989950908) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6170632793331903843) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1529448915625084837) ) ) {
                result[0] += 0.013942730033025956;
              } else {
                result[0] += -0.011432740743729495;
              }
            } else {
              result[0] += 0.020815152384011583;
            }
          } else {
            result[0] += 0.031817187535975816;
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.03668671385521792;
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6818507002937542749) ) ) {
              result[0] += 0.004762338028040624;
            } else {
              result[0] += 0.03425190258620905;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8442376020855621999) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
          result[0] += 0.042834692950860294;
        } else {
          result[0] += 0.021650171960117277;
        }
      } else {
        result[0] += 0.05954524640989665;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6972829280248278305) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4429728266653536473) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2296243883448841061) ) ) {
        result[0] += -0.0575241519995674;
      } else {
        result[0] += -0.04181668091432051;
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5373923050813967928) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2060867271409693446) ) ) {
          result[0] += -0.005108818671212234;
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004774500000000000098) ) ) {
            result[0] += -0.04432433290106879;
          } else {
            result[0] += -0.025266191038965165;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
          result[0] += 0.004801889980894893;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5897839699588115492) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3931461612883267454) ) ) {
              result[0] += -0.012427949313392648;
            } else {
              result[0] += -0.03587923950755074;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
              result[0] += 0.005312991871034442;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002246500000000000666) ) ) {
                result[0] += -0.023217413345634725;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8950000000000001288) ) ) {
                  result[0] += -0.007636528407432545;
                } else {
                  result[0] += -0.03429695555853227;
                }
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7149490869166016394) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8436766892707049381) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 0.030030206000254762;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7622764819475024156) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4750000000000000333) ) ) {
              result[0] += 0.011017567387775803;
            } else {
              result[0] += -0.004438295700793306;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6750000000000001554) ) ) {
              result[0] += 0.011156673370531594;
            } else {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5914390031270969628) ) ) {
                result[0] += -0.00720628265463779;
              } else {
                result[0] += 0.006208882953045739;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0008485000000000001872) ) ) {
          result[0] += -0.008230123984936357;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9297295038086662577) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6170632793331903843) ) ) {
              result[0] += 0.011414061292241748;
            } else {
              result[0] += 0.0233307615850348;
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9650000000000000799) ) ) {
              result[0] += 0.038501556029240304;
            } else {
              result[0] += 0.018864675213942573;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8502789422115718532) ) ) {
        result[0] += 0.039981462543605774;
      } else {
        result[0] += 0.059159871422282705;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6875734944390267112) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4429728266653536473) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2642961365573822663) ) ) {
        result[0] += -0.05627469095673527;
      } else {
        result[0] += -0.0397030573392045;
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5373923050813967928) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2060867271409693446) ) ) {
          result[0] += -0.004841668547276777;
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004774500000000000098) ) ) {
            result[0] += -0.0434333830091003;
          } else {
            result[0] += -0.024338066247424777;
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5250000000000001332) ) ) {
          result[0] += -0.00599509067586296;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5798905718019149447) ) ) {
            result[0] += -0.03134657551547394;
          } else {
            result[0] += -0.014561232788686942;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7149490869166016394) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8250070987435854653) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 0.026529753723171443;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0005635000000000000902) ) ) {
            result[0] += -0.016433844455612148;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7381191551631117731) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4518709121403587381) ) ) {
                result[0] += 0.015168601064614857;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6705625264070352864) ) ) {
                  result[0] += -0.011338433389685152;
                } else {
                  result[0] += 0.0035590196072459853;
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6450000000000001288) ) ) {
                result[0] += 0.010389069133157488;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7875939310552765305) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9450000000000000622) ) ) {
                    result[0] += -0.0050322658960192035;
                  } else {
                    result[0] += 0.007446771377427542;
                  }
                } else {
                  result[0] += -0.023671835701810313;
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0007525000000000000222) ) ) {
          result[0] += -0.012516008801457219;
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6486987125073885307) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.882048175975067239) ) ) {
              result[0] += 0.010118955833898385;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9250000000000001554) ) ) {
                result[0] += 0.028550015284640875;
              } else {
                result[0] += 0.012159990117718114;
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
              result[0] += 0.041433071467887835;
            } else {
              result[0] += 0.020902389395245705;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8622565274156744897) ) ) {
        result[0] += 0.03952710502694238;
      } else {
        result[0] += 0.05905102524889172;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6875734944390267112) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3881589449934809699) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2296243883448841061) ) ) {
        result[0] += -0.05690576216157168;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02500000000000000486) ) ) {
          result[0] += -0.0023765006300336877;
        } else {
          result[0] += -0.04360687207840423;
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5373923050813967928) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1850000000000000255) ) ) {
          result[0] += -0.008848419258105238;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3650000000000000466) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4604805625892014476) ) ) {
              result[0] += -0.03628214858995598;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2682576517146198491) ) ) {
                result[0] += -0.004849267134279014;
              } else {
                result[0] += -0.02750843275901594;
              }
            }
          } else {
            result[0] += -0.040897374871884634;
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5250000000000001332) ) ) {
          result[0] += -0.005679425117887339;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5798905718019149447) ) ) {
            result[0] += -0.03034249645960978;
          } else {
            result[0] += -0.01387734096087122;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.736034375232267446) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8664403834689663464) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8098966366947321083) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += 0.022255742216345808;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4850000000000000422) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.519576616407035341) ) ) {
                result[0] += -0.0005693854775086228;
              } else {
                result[0] += 0.021348608314197028;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7423774199879572544) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4305635934924623709) ) ) {
                  result[0] += -0.026153123790509925;
                } else {
                  result[0] += -0.004468538438815532;
                }
              } else {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4627502129294571165) ) ) {
                  result[0] += 0.016253765767146718;
                } else {
                  result[0] += -0.00030875480686539747;
                }
              }
            }
          }
        } else {
          result[0] += 0.009668820328193363;
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6690753303250667194) ) ) {
          result[0] += 0.016841932213982978;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9150000000000001465) ) ) {
            result[0] += 0.029384942298264553;
          } else {
            result[0] += 0;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8622565274156744897) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9850000000000000977) ) ) {
          result[0] += 0.042124726099237605;
        } else {
          result[0] += 0.02184549343263277;
        }
      } else {
        result[0] += 0.05848041112180195;
      }
    }
  }
}

