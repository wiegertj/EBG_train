
#include "header.h"

void predict_unit4(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7345825791375740765) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5223131059347717597) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2692173444281812933) ) ) {
        result[0] += -0.08903047617630713;
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0003097882605641000503) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4317260786397597028) ) ) {
            result[0] += -0.06319839977928554;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3550000000000000377) ) ) {
              result[0] += -0.02347530807478103;
            } else {
              result[0] += -0.06999357575443507;
            }
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3044402794723619077) ) ) {
            result[0] += -0.010760761772331486;
          } else {
            result[0] += -0.07412096673180966;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6335148768279005305) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.625000000000000111) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.0442771331626926e-05) ) ) {
            result[0] += -0.016524546242261653;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002465500000000000243) ) ) {
              result[0] += -0.05812524481695906;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)177.5000000000000284) ) ) {
                result[0] += -0.024309474571172825;
              } else {
                result[0] += -0.047771795716163426;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03606792155040580705) ) ) {
            result[0] += -0.057809121052222495;
          } else {
            result[0] += -0.016406424113719058;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004834500000000001123) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += 0.004230326435455059;
          } else {
            if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5268343718203251091) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8950000000000001288) ) ) {
                result[0] += -0.028967919729614416;
              } else {
                result[0] += -0.06258793826049362;
              }
            } else {
              result[0] += -0.011039874842606384;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5508018452917812224) ) ) {
            result[0] += -0.0031956518046761064;
          } else {
            result[0] += -0.03193612712128949;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7787197788111503982) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8624925176218337652) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7962310954155430442) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4036106884780860105) ) ) {
            result[0] += 0.009165498114105356;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6730556337437186842) ) ) {
              result[0] += -0.03211364892764503;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
                result[0] += 0.018727782278585445;
              } else {
                result[0] += -0.013444563042835476;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5150000000000001243) ) ) {
            result[0] += 0.04956369421774275;
          } else {
            if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5736856762879515292) ) ) {
              result[0] += -0.011219447995472347;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7650000000000001243) ) ) {
                result[0] += 0.048582566955967785;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02607700000000000295) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.000758500000000000168) ) ) {
                    result[0] += -0.0025102821098105387;
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.002292485544475100345) ) ) {
                      result[0] += -0.005940439751646685;
                    } else {
                      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3750409390474713223) ) ) {
                        result[0] += 0.0494235067169991;
                      } else {
                        if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6064509334668474194) ) ) {
                          result[0] += -0.0091703683814538;
                        } else {
                          result[0] += 0.024274074083735327;
                        }
                      }
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)94.50000000000001421) ) ) {
                    result[0] += 0.023365482574082948;
                  } else {
                    result[0] += -0.02293474405683676;
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6431914325303583757) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9750000000000000888) ) ) {
            if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5647100539952510934) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)47.50000000000000711) ) ) {
                result[0] += -0.008697297861704553;
              } else {
                result[0] += 0.036153770976488926;
              }
            } else {
              result[0] += 0.04420435192618412;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)24.50000000000000355) ) ) {
              result[0] += 0.03431082392131696;
            } else {
              result[0] += -0.010346945800800162;
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.06489052400978723;
          } else {
            result[0] += 0.04321584510569895;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8320474816531334694) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
          if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7341068085871017557) ) ) {
            result[0] += 0.06031829529880356;
          } else {
            result[0] += 0.07907208375942777;
          }
        } else {
          result[0] += 0.04700423499424841;
        }
      } else {
        result[0] += 0.09614080355463304;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7244058930400819607) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5002776212835359226) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2692173444281812933) ) ) {
        result[0] += -0.0880454423079543;
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0001660383056237000384) ) ) {
          result[0] += -0.055114155400782454;
        } else {
          result[0] += -0.07349527838163938;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5963654365793032985) ) ) {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.2677549912511515973) ) ) {
          if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.3257634786623919143) ) ) {
            result[0] += -0.02978884813082591;
          } else {
            result[0] += 0.006591397296750586;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02711386111807555233) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6106749517839197283) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001290117952834850213) ) ) {
                result[0] += -0.014734945741131288;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005468000000000000638) ) ) {
                  result[0] += -0.06196564262412716;
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.08835747683243963535) ) ) {
                    result[0] += -0.0553088851415013;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.07172822906307056712) ) ) {
                      result[0] += 0.013432388492990978;
                    } else {
                      result[0] += -0.04479368887277982;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.07023659554246586;
            }
          } else {
            result[0] += -0.03055793637063291;
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7550000000000001155) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)745.5000000000001137) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05835789545007314533) ) ) {
                result[0] += -0.024889457259962583;
              } else {
                result[0] += 0.034919691296454246;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002291500000000000568) ) ) {
                result[0] += -0.05159004676469882;
              } else {
                result[0] += -0.012761144914203342;
              }
            }
          } else {
            result[0] += 0.023464796763782728;
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6562355446042661411) ) ) {
            result[0] += -0.047010227399899816;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5361772370603016258) ) ) {
              result[0] += -0.0036260315643627827;
            } else {
              if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5968698006270367618) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.004869514427752750889) ) ) {
                  result[0] += -0.050466701612438644;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.009328104046003550184) ) ) {
                    result[0] += 0.004113868064486148;
                  } else {
                    result[0] += -0.02914513983832592;
                  }
                }
              } else {
                result[0] += 0.008588302054996375;
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7787197788111503982) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8527347970710045244) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7962310954155430442) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4036106884780860105) ) ) {
            result[0] += 0.0074818707097435225;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6730556337437186842) ) ) {
              result[0] += -0.030953581006710296;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
                result[0] += 0.02697263363913866;
              } else {
                result[0] += -0.009349143000988021;
              }
            }
          }
        } else {
          result[0] += 0.01617837061177663;
        }
      } else {
        if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7019284603958083624) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9350000000000001643) ) ) {
            if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6118109021115948343) ) ) {
              result[0] += 0.00572490449911176;
            } else {
              result[0] += 0.040907767021079136;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03356779836971720415) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)53.50000000000000711) ) ) {
                result[0] += 0.044653386879570836;
              } else {
                result[0] += 0.006200913875010365;
              }
            } else {
              result[0] += -0.008010834948504313;
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
            if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6225346164046366981) ) ) {
              result[0] += 0.017912677222998403;
            } else {
              result[0] += 0.06362820119175945;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07287111975896176652) ) ) {
              if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6569165541141283038) ) ) {
                result[0] += 0.019019739402639232;
              } else {
                result[0] += 0.04696369960211637;
              }
            } else {
              result[0] += 0.004399183574889594;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8255177083825077089) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7341068085871017557) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9150000000000001465) ) ) {
              result[0] += 0.06339974716888581;
            } else {
              result[0] += 0.029694673423802685;
            }
          } else {
            result[0] += 0.07439855224242913;
          }
        } else {
          result[0] += 0.024295344073227594;
        }
      } else {
        result[0] += 0.09400105482641537;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7244058930400819607) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5002776212835359226) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2692173444281812933) ) ) {
        result[0] += -0.08711192598365547;
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0001660383056237000384) ) ) {
          result[0] += -0.05283868645159679;
        } else {
          result[0] += -0.07162600380472045;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5963654365793032985) ) ) {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.2677549912511515973) ) ) {
          result[0] += -0.02263777215282046;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02711386111807555233) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6106749517839197283) ) ) {
              result[0] += -0.043067693713871404;
            } else {
              result[0] += -0.06799130237677496;
            }
          } else {
            result[0] += -0.028647194944669177;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004934500000000000518) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05835789545007314533) ) ) {
              result[0] += -0.019324574029573747;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6750000000000001554) ) ) {
                result[0] += 0.04338476530282265;
              } else {
                result[0] += -0.008838187841839786;
              }
            }
          } else {
            if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5268343718203251091) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002343500000000000531) ) ) {
                result[0] += -0.04454340681797132;
              } else {
                result[0] += -0.023712351956779423;
              }
            } else {
              result[0] += -0.009092818959418717;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.695627306227387554) ) ) {
            result[0] += -0.006545151638960711;
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8099155601256282644) ) ) {
              result[0] += -0.04786026651440698;
            } else {
              result[0] += -0.001997993456597125;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7787197788111503982) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8477341880899419424) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 0.03939887576344765;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001819500000000000154) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.00257563127332165057) ) ) {
                result[0] += -0.042053011014264646;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0008055000000000001178) ) ) {
                  result[0] += -0.0341726818536193;
                } else {
                  result[0] += 0.003547107125059193;
                }
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)56.50000000000000711) ) ) {
                result[0] += 0.02253895668916734;
              } else {
                result[0] += -0.007866548463209815;
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)13.50000000000000178) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6375391159296482924) ) ) {
                result[0] += -0.020111946108651687;
              } else {
                result[0] += 0.028669658834643164;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7295070658487954329) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6984575981658293076) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4036106884780860105) ) ) {
                    result[0] += 0.01659979433487808;
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02101337656308150184) ) ) {
                      result[0] += 0.01836874309930297;
                    } else {
                      result[0] += -0.026458588393545583;
                    }
                  }
                } else {
                  result[0] += 0.05490097077914281;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04012095772361360529) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01406500000000000285) ) ) {
                    result[0] += 0.007490594225259382;
                  } else {
                    result[0] += -0.04147798162271724;
                  }
                } else {
                  result[0] += 0.018550680772955724;
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7019284603958083624) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.04446937286580055632) ) ) {
            result[0] += 0.03385957072006666;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01655300000000000174) ) ) {
              if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6771941146806593759) ) ) {
                result[0] += -0.028483400561516388;
              } else {
                result[0] += 0.018890234200360855;
              }
            } else {
              result[0] += 0.02275328597113934;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
            result[0] += 0.04729197163422793;
          } else {
            result[0] += 0.029372502238175627;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8320474816531334694) ) ) {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7341068085871017557) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9150000000000001465) ) ) {
            result[0] += 0.06029546026011194;
          } else {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9721145574699906478) ) ) {
              result[0] += 0.04749356604319837;
            } else {
              result[0] += -0.005885478311033717;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += 0.07344771425243579;
          } else {
            result[0] += 0.04668319931233904;
          }
        }
      } else {
        result[0] += 0.09258839019723894;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7190376324068391556) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5002776212835359226) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2692173444281812933) ) ) {
        result[0] += -0.08622092980571307;
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0001660383056237000384) ) ) {
          result[0] += -0.05059321690953074;
        } else {
          result[0] += -0.06976245902346635;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5963654365793032985) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.625000000000000111) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001290117952834850213) ) ) {
            result[0] += -0.02011312467265736;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3350000000000000755) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01289333490204290153) ) ) {
                result[0] += 0.011249111110714947;
              } else {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.07409325127878772788) ) ) {
                  result[0] += -0.05576487941673341;
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.009506291499886947854) ) ) {
                    result[0] += 0.039762067238719;
                  } else {
                    result[0] += -0.028127818204127703;
                  }
                }
              }
            } else {
              result[0] += -0.05140865451653813;
            }
          }
        } else {
          result[0] += -0.060991169783397685;
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7550000000000001155) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6983922411789055262) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)745.5000000000001137) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)153.5000000000000284) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5250000000000001332) ) ) {
                  result[0] += -0.00417298579808269;
                } else {
                  result[0] += -0.0303986410820908;
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02108150000000000301) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01074176809375445261) ) ) {
                    result[0] += -0.03392337049256365;
                  } else {
                    result[0] += 0.01134567413925985;
                  }
                } else {
                  result[0] += -0.05214070115473936;
                }
              }
            } else {
              result[0] += 0.023514647542647843;
            }
          } else {
            result[0] += 0.007209931129939106;
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6562355446042661411) ) ) {
            result[0] += -0.04285851067146827;
          } else {
            result[0] += -0.017949874702540135;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7787197788111503982) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8319610793798176696) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 0.03335475533012147;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001671500000000000243) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)15.50000000000000178) ) ) {
              result[0] += 0.02254007278005126;
            } else {
              result[0] += -0.01210380778691789;
            }
          } else {
            if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5452475257179970614) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4148598843808023462) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5193865869095478649) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)121.5000000000000142) ) ) {
                    result[0] += -0.02658755897275056;
                  } else {
                    result[0] += 0.010680453347262106;
                  }
                } else {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5511625663567840672) ) ) {
                    result[0] += 0.04482860010410791;
                  } else {
                    result[0] += 0.0010457712322148097;
                  }
                }
              } else {
                result[0] += -0.029295250189887823;
              }
            } else {
              if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5026146189546180088) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01462200000000000132) ) ) {
                  result[0] += 0.0704966205353664;
                } else {
                  result[0] += 0.015909627344909246;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7250000000000000888) ) ) {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
                    result[0] += 0.018185842766258203;
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8050000000000001599) ) ) {
                      result[0] += 0.029070361103467366;
                    } else {
                      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5326995889949749374) ) ) {
                        result[0] += -0.03200244843821251;
                      } else {
                        result[0] += -0.0009480299547052099;
                      }
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5861769322017787998) ) ) {
                    result[0] += -0.0001400460959541056;
                  } else {
                    result[0] += 0.04119590854896145;
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6618962921466065019) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8050000000000001599) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0433285000000000059) ) ) {
              result[0] += 0.006181691656693045;
            } else {
              result[0] += 0.04793848069936174;
            }
          } else {
            result[0] += 0.008533036880599415;
          }
        } else {
          result[0] += 0.03509734766655304;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8255177083825077089) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7341068085871017557) ) ) {
            result[0] += 0.0501213956512287;
          } else {
            result[0] += 0.06885339366501932;
          }
        } else {
          result[0] += 0.019924429379078484;
        }
      } else {
        result[0] += 0.09067569042700971;
      }
    }
  }
}

