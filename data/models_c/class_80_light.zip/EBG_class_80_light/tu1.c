
#include "header.h"

void predict_unit1(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.767064450770027606) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5897839699588115492) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4429728266653536473) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2642961365573822663) ) ) {
          result[0] += -0.07241929807965847;
        } else {
          result[0] += -0.06598872216007495;
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5414094579173949207) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2060867271409693446) ) ) {
              result[0] += -0.03976519379929101;
            } else {
              result[0] += -0.05623374480002714;
            }
          } else {
            result[0] += -0.03351055644491904;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5373923050813967928) ) ) {
            result[0] += -0.06469663433173861;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2850000000000000866) ) ) {
              result[0] += -0.02353822055636697;
            } else {
              result[0] += -0.054374329305410495;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7019812713501991652) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6850000000000001643) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
            result[0] += -0.004200070800014127;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002981500000000000209) ) ) {
              result[0] += -0.05168814928338558;
            } else {
              result[0] += -0.022034431728724435;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6491668737719177296) ) ) {
            result[0] += -0.05089658410872334;
          } else {
            result[0] += -0.034587394346002616;
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4470670498171123719) ) ) {
          result[0] += 0.012137124572721585;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7227354901093919759) ) ) {
            result[0] += -0.02046615832307843;
          } else {
            result[0] += -0.001991789600357171;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9024131424400998469) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8436766892707049381) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7998185917227689234) ) ) {
          result[0] += 0.017645021429422644;
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5557532160049157843) ) ) {
            result[0] += 0.058937416644921366;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4241846244472362026) ) ) {
              result[0] += 0.010662964164091756;
            } else {
              result[0] += 0.034878074486609456;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6170632793331903843) ) ) {
          result[0] += 0.048678611395377706;
        } else {
          result[0] += 0.0633822978158018;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7946879440622868218) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6869614610244983988) ) ) {
          result[0] += 0.07209435678439054;
        } else {
          result[0] += 0.08522005955434209;
        }
      } else {
        result[0] += 0.09709177797243561;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7622764819475024156) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5640404622805753609) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3881589449934809699) ) ) {
        result[0] += -0.06969326372000562;
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4806185349221548386) ) ) {
            result[0] += -0.057723952212817106;
          } else {
            result[0] += -0.042677148288504795;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5089951851639061831) ) ) {
            result[0] += -0.06751300797243658;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03992900000000000615) ) ) {
              result[0] += -0.05734604572172548;
            } else {
              result[0] += -0.031253194982790757;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7019812713501991652) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6589536398896721492) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.346441672365271125) ) ) {
            result[0] += -0.026110140068407853;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6213841400436609375) ) ) {
              result[0] += -0.05147808031901774;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8850000000000001199) ) ) {
                result[0] += -0.03479649689263284;
              } else {
                result[0] += -0.05829308564465848;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3798172842595056165) ) ) {
            result[0] += -0.001027994464817253;
          } else {
            result[0] += -0.03053196314837402;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4750000000000000333) ) ) {
          result[0] += 0.022743728733950593;
        } else {
          result[0] += -0.005422102448868693;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8889371422142716694) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8146542383663726294) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7847910031909549611) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03154350000000000903) ) ) {
            result[0] += 0.017886950704140866;
          } else {
            result[0] += 0.03717063007110175;
          }
        } else {
          result[0] += -0.0028007656720847023;
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6887015468287406295) ) ) {
          result[0] += 0.03971846815501328;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002033500000000000151) ) ) {
            result[0] += 0.0396848863383911;
          } else {
            result[0] += 0.06472478140571326;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.736034375232267446) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6869614610244983988) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1368445000000000078) ) ) {
            result[0] += 0.06373057659017597;
          } else {
            result[0] += 0.08454542652574146;
          }
        } else {
          result[0] += 0.07702976246116844;
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8442376020855621999) ) ) {
          result[0] += 0.08527767590341867;
        } else {
          result[0] += 0.09404451193744169;
        }
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7622764819475024156) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5640404622805753609) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3881589449934809699) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2642961365573822663) ) ) {
          result[0] += -0.07005828565260432;
        } else {
          result[0] += -0.06410103445849165;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4806185349221548386) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2254577915071873384) ) ) {
            result[0] += -0.05372633241563672;
          } else {
            result[0] += -0.0671764336248425;
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2879158236070033516) ) ) {
            result[0] += -0.04177672181926282;
          } else {
            result[0] += -0.05907770430032658;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7019812713501991652) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5650000000000000577) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6213841400436609375) ) ) {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.346441672365271125) ) ) {
              result[0] += -0.025449598610218022;
            } else {
              result[0] += -0.04930882334417192;
            }
          } else {
            result[0] += -0.01160705206728759;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6491668737719177296) ) ) {
            result[0] += -0.045236381124099174;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7850000000000001421) ) ) {
              result[0] += -0.01892359456306628;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.555096866909547848) ) ) {
                result[0] += -0.021997194995998944;
              } else {
                result[0] += -0.04196986283608859;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4305892766871174948) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7277004308735181004) ) ) {
            result[0] += 0.003584699005611327;
          } else {
            result[0] += 0.031328956202779236;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7227354901093919759) ) ) {
            result[0] += -0.016084944771164827;
          } else {
            result[0] += -0.002898435289013499;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9024131424400998469) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.849950209132393053) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7998185917227689234) ) ) {
          result[0] += 0.014613971319508687;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6350000000000001199) ) ) {
            result[0] += 0.04893502146543389;
          } else {
            result[0] += 0.02801860881159602;
          }
        }
      } else {
        result[0] += 0.05152660338836821;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7881101830206976855) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6869614610244983988) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8650000000000001021) ) ) {
            result[0] += 0.06767756765030314;
          } else {
            result[0] += 0.047804530418862734;
          }
        } else {
          result[0] += 0.07712765569865358;
        }
      } else {
        result[0] += 0.08922287991265072;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7622764819475024156) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5640404622805753609) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3881589449934809699) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2642961365573822663) ) ) {
          result[0] += -0.06900299034246184;
        } else {
          result[0] += -0.06283769830491433;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5089951851639061831) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2060867271409693446) ) ) {
            result[0] += -0.04892228242853542;
          } else {
            result[0] += -0.06167835292028828;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2850000000000000866) ) ) {
            result[0] += -0.02834862995730367;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4850000000000000422) ) ) {
              result[0] += -0.04474609654741139;
            } else {
              result[0] += -0.0600370573327939;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7019812713501991652) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6589536398896721492) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.346441672365271125) ) ) {
            result[0] += -0.023765891934744304;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6213841400436609375) ) ) {
              result[0] += -0.04846411500990957;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8850000000000001199) ) ) {
                result[0] += -0.03193387629172764;
              } else {
                result[0] += -0.055494860978827186;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3798172842595056165) ) ) {
            result[0] += -0.00018511602397244082;
          } else {
            result[0] += -0.027999691045512604;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4750000000000000333) ) ) {
          result[0] += 0.020653342537988985;
        } else {
          result[0] += -0.0049288525079630935;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9024131424400998469) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8436766892707049381) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7998185917227689234) ) ) {
          result[0] += 0.01374801600455172;
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5557532160049157843) ) ) {
            result[0] += 0.05065252272532886;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4241846244472362026) ) ) {
              result[0] += 0.006644098428235507;
            } else {
              result[0] += 0.028995541737290537;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6170632793331903843) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.882048175975067239) ) ) {
            result[0] += 0.03458407200909278;
          } else {
            result[0] += 0.05281473143600943;
          }
        } else {
          result[0] += 0.05383599451784071;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7946879440622868218) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6869614610244983988) ) ) {
          result[0] += 0.06160618913835904;
        } else {
          result[0] += 0.07406653967455427;
        }
      } else {
        result[0] += 0.08621074619699366;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.767064450770027606) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5640404622805753609) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3881589449934809699) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2642961365573822663) ) ) {
          result[0] += -0.06802682144897393;
        } else {
          result[0] += -0.06163637456251872;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4806185349221548386) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2254577915071873384) ) ) {
            result[0] += -0.0509214009064803;
          } else {
            result[0] += -0.06483918831824743;
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2719359470653786581) ) ) {
            result[0] += -0.03622321164873991;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
              result[0] += -0.031659987802726886;
            } else {
              result[0] += -0.05709115322515423;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7019812713501991652) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6850000000000001643) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6105085814565057722) ) ) {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.346441672365271125) ) ) {
              result[0] += -0.02487998002895932;
            } else {
              result[0] += -0.04667784347886696;
            }
          } else {
            result[0] += -0.015366553071937412;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6491668737719177296) ) ) {
            result[0] += -0.04561196758071718;
          } else {
            result[0] += -0.029339431579309308;
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8350000000000000755) ) ) {
          result[0] += 0.007768334339887641;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7423774199879572544) ) ) {
            result[0] += -0.014401409187854755;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6550000000000001377) ) ) {
              result[0] += 0.009076461605081618;
            } else {
              result[0] += -0.013694034864892774;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9024131424400998469) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.849950209132393053) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7998185917227689234) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6750000000000001554) ) ) {
            result[0] += 0.020389606950375522;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9350000000000001643) ) ) {
              result[0] += -0.013150638724321628;
            } else {
              result[0] += 0.012384108417870245;
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8350000000000000755) ) ) {
            result[0] += 0.04267791264366384;
          } else {
            result[0] += 0.024230246867386677;
          }
        }
      } else {
        result[0] += 0.04612228868410078;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7946879440622868218) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6869614610244983988) ) ) {
          result[0] += 0.058643969001134284;
        } else {
          result[0] += 0.07104511852639082;
        }
      } else {
        result[0] += 0.0833808949869618;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7622764819475024156) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5640404622805753609) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3881589449934809699) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2296243883448841061) ) ) {
          result[0] += -0.06747460054338017;
        } else {
          result[0] += -0.06128437193849334;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5089951851639061831) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
            result[0] += -0.04984864533600769;
          } else {
            result[0] += -0.06292014193357466;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2850000000000000866) ) ) {
            result[0] += -0.02559748478397243;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4850000000000000422) ) ) {
              result[0] += -0.04175340260548357;
            } else {
              result[0] += -0.057462392557291374;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6972829280248278305) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6850000000000001643) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6105085814565057722) ) ) {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.346441672365271125) ) ) {
              result[0] += -0.023769613498818704;
            } else {
              result[0] += -0.04523607237888281;
            }
          } else {
            result[0] += -0.014778121235831443;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6491668737719177296) ) ) {
            result[0] += -0.04416604044660187;
          } else {
            result[0] += -0.029302778439184305;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4750000000000000333) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5312527455527639164) ) ) {
            result[0] += 0.0006658377714249439;
          } else {
            result[0] += 0.032635619915000844;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7277004308735181004) ) ) {
            result[0] += -0.012265951266441822;
          } else {
            result[0] += -0.00023839759806128184;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9024131424400998469) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8250070987435854653) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6450000000000001288) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7998185917227689234) ) ) {
            result[0] += 0.0184215701947812;
          } else {
            result[0] += 0.04319381997711822;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7753767533919598831) ) ) {
            result[0] += 0.014669698216266574;
          } else {
            result[0] += -0.0066714285532697955;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8664403834689663464) ) ) {
          result[0] += 0.03217693474529332;
        } else {
          result[0] += 0.04725948517627473;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7881101830206976855) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6869614610244983988) ) ) {
          result[0] += 0.0559004170476759;
        } else {
          result[0] += 0.0679782118236163;
        }
      } else {
        result[0] += 0.08067344042215567;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7622764819475024156) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5640404622805753609) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3881589449934809699) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2642961365573822663) ) ) {
          result[0] += -0.06628276210354223;
        } else {
          result[0] += -0.05937461543228662;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5089951851639061831) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2682576517146198491) ) ) {
            result[0] += -0.0474245631555458;
          } else {
            result[0] += -0.060332928669949035;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
            result[0] += -0.021046303812926534;
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2639245547049151042) ) ) {
              result[0] += -0.031612368963319946;
            } else {
              result[0] += -0.052712372313442925;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6972829280248278305) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
          if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.01051018765715429869) ) ) {
            result[0] += 0.0023705307413826515;
          } else {
            result[0] += -0.027681408946945884;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6491668737719177296) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4650000000000000244) ) ) {
                result[0] += -0.03629526531543949;
              } else {
                result[0] += 0.002162384595365562;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002033500000000000151) ) ) {
                result[0] += -0.05056906750182306;
              } else {
                result[0] += -0.03424913158968011;
              }
            }
          } else {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4470670498171123719) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0308805000000000017) ) ) {
                result[0] += -0.007954759909020614;
              } else {
                result[0] += -0.03169330880325958;
              }
            } else {
              result[0] += -0.03423777034596671;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4750000000000000333) ) ) {
          result[0] += 0.015768037595529746;
        } else {
          result[0] += -0.00511906877517163;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9024131424400998469) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.849950209132393053) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7998185917227689234) ) ) {
          result[0] += 0.01139357523905571;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8350000000000000755) ) ) {
            result[0] += 0.03842795175017103;
          } else {
            result[0] += 0.021440635590014835;
          }
        }
      } else {
        result[0] += 0.041453863774296926;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7946879440622868218) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6869614610244983988) ) ) {
          result[0] += 0.05334564244805012;
        } else {
          result[0] += 0.06569340691601776;
        }
      } else {
        result[0] += 0.0785695821134075;
      }
    }
  }
}

