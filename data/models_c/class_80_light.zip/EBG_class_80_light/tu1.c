
#include "header.h"

void predict_unit1(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6918155867375320733) ) ) {
    result[0] += -0.1166914368678871;
  } else {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8573515767927758491) ) ) {
      result[0] += 0.023187071170623175;
    } else {
      result[0] += 0.14600791913847505;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6447674635257691911) ) ) {
    result[0] += -0.11811628391579287;
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7889403666860613784) ) ) {
      result[0] += 0.03945182512339322;
    } else {
      result[0] += 0.15326242390056083;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8156981107015612853) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5411232180154271765) ) ) {
      result[0] += -0.1251363069234528;
    } else {
      result[0] += -0.011811277183334938;
    }
  } else {
    result[0] += 0.1212972841412464;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6396792576769586569) ) ) {
    result[0] += -0.10936437496468658;
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7228837903784830488) ) ) {
      result[0] += 0.030011792542718223;
    } else {
      result[0] += 0.14111019413620507;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8209563422381512821) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5246343807191508057) ) ) {
      result[0] += -0.11945262955789189;
    } else {
      result[0] += -0.01095193176563744;
    }
  } else {
    result[0] += 0.10781322282573597;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5981753503490724322) ) ) {
    result[0] += -0.10630026793174842;
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8179529620996692785) ) ) {
      result[0] += 0.02161818532782082;
    } else {
      result[0] += 0.1339542556059842;
    }
  }
}

