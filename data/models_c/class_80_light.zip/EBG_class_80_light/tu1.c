
#include "header.h"

void predict_unit1(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7765936419225654141) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5963654365793032985) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5002776212835359226) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2984949881764770718) ) ) {
          result[0] += -0.1100310912912386;
        } else {
          result[0] += -0.10004886783459571;
        }
      } else {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.2891310748198975267) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5346753968654129885) ) ) {
            result[0] += -0.08186406297727296;
          } else {
            result[0] += -0.055591434358721145;
          }
        } else {
          result[0] += -0.08819022595106389;
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6983922411789055262) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.545000000000000151) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01427628620366660182) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003049500000000000561) ) ) {
              result[0] += -0.028870150404310263;
            } else {
              result[0] += 0.009779429088001699;
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.0491948752242571466) ) ) {
              if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1878414568672973628) ) ) {
                result[0] += -0.041920924315734624;
              } else {
                result[0] += 0;
              }
            } else {
              result[0] += -0.05589296141552817;
            }
          }
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6562355446042661411) ) ) {
            if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.4174801190604223167) ) ) {
              result[0] += -0.0369793961668303;
            } else {
              result[0] += -0.07455941336736885;
            }
          } else {
            if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5220717678210960999) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02957950000000000509) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4750000000000000333) ) ) {
                  result[0] += 0;
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01066013304459604953) ) ) {
                    result[0] += -0.058000518161723275;
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.003760302226300550436) ) ) {
                      result[0] += -0.05695863347437953;
                    } else {
                      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.495979586219741253) ) ) {
                        result[0] += -0.04001067164889384;
                      } else {
                        result[0] += 0.004807226837683054;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.06728362340919396;
              }
            } else {
              result[0] += -0.06633067772532815;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7345825791375740765) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8350000000000000755) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)277.5000000000000568) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4348268365326633522) ) ) {
                result[0] += -0.033876117412683274;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02008391570334735338) ) ) {
                  result[0] += 0.028705309386175642;
                } else {
                  result[0] += -0.008735266993792443;
                }
              }
            } else {
              result[0] += -0.04162375595740963;
            }
          } else {
            if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5903541535616282365) ) ) {
              result[0] += -0.04393412428458747;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2832250324983362488) ) ) {
                result[0] += 0.013919770084181934;
              } else {
                result[0] += -0.026060600954370718;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8650000000000001021) ) ) {
            result[0] += 0.01869289920639216;
          } else {
            result[0] += -0.0029433353888951635;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7362391952976967691) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8372609372025714425) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8052728383663535494) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6950000000000000622) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6479278833417086991) ) ) {
              if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5268343718203251091) ) ) {
                if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.465729079252185707) ) ) {
                  result[0] += 0.05918217159657941;
                } else {
                  result[0] += 0.01432877444534773;
                }
              } else {
                result[0] += 0.06743124876270283;
              }
            } else {
              result[0] += 0.00725026683778689;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.006675038360450900356) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.111965421064566098) ) ) {
                result[0] += 0.0014209769547454813;
              } else {
                result[0] += 0.04217358948168343;
              }
            } else {
              result[0] += -0.013564397102359762;
            }
          }
        } else {
          result[0] += 0.04642150554182085;
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8687710690772928457) ) ) {
          result[0] += 0.07247876060522071;
        } else {
          result[0] += 0.09525583678522154;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7528363226160118549) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
          result[0] += 0.13674819969152902;
        } else {
          if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7583373477169182975) ) ) {
            result[0] += 0.09578893120991562;
          } else {
            result[0] += 0.12182228902099942;
          }
        }
      } else {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8574845066336775901) ) ) {
          result[0] += 0.14055854071282267;
        } else {
          result[0] += 0.15122845200189797;
        }
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7681116375709841071) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5963654365793032985) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5002776212835359226) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2984949881764770718) ) ) {
          result[0] += -0.10695943140936454;
        } else {
          result[0] += -0.09656997095272973;
        }
      } else {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.2677549912511515973) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5346753968654129885) ) ) {
            result[0] += -0.07461929262491639;
          } else {
            result[0] += -0.04748334937022548;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02711386111807555233) ) ) {
            result[0] += -0.08669591487925292;
          } else {
            result[0] += -0.0665211734892581;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6983922411789055262) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.545000000000000151) ) ) {
          result[0] += -0.029301449031938053;
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6562355446042661411) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002365000000000000294) ) ) {
              result[0] += -0.022968993516010873;
            } else {
              result[0] += -0.06999483099179714;
            }
          } else {
            if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5277382668411586542) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4356007332828459866) ) ) {
                result[0] += -0.0031548772484315045;
              } else {
                if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.4750935042900945038) ) ) {
                  result[0] += -0.06364981592592348;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.00000001800250948e-35) ) ) {
                    result[0] += -0.05682108982040144;
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002195500000000000403) ) ) {
                      result[0] += -0.04849086299053486;
                    } else {
                      result[0] += -0.004661671665220703;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.06423720572002611;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 0.05183632641776525;
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7244058930400819607) ) ) {
            result[0] += -0.024722434243212632;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6150000000000001021) ) ) {
              result[0] += 0.011753803478663997;
            } else {
              if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6140748412273120405) ) ) {
                result[0] += -0.018948770662185383;
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6402694681155779444) ) ) {
                  result[0] += 0.03619486312949241;
                } else {
                  result[0] += -0.012741066719909353;
                }
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7362391952976967691) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8319610793798176696) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.786764172562814168) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)51.50000000000000711) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002115500000000000626) ) ) {
                result[0] += -0.0216707488633126;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.875000000000000111) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03085950000000000151) ) ) {
                    result[0] += -0.00848832360917608;
                  } else {
                    result[0] += 0.0404053205970508;
                  }
                } else {
                  result[0] += 0.03855181316701395;
                }
              }
            } else {
              result[0] += 0.04766223415232378;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001671500000000000243) ) ) {
              if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.605952719611926427) ) ) {
                result[0] += 0.04293532500551224;
              } else {
                result[0] += 0.006726888759249884;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01685450000000000489) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
                  result[0] += 0.06133390821756309;
                } else {
                  result[0] += 0.023688123488077976;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3830383354773237436) ) ) {
                  result[0] += 0.0392293548481045;
                } else {
                  result[0] += 0;
                }
              }
            }
          }
        } else {
          result[0] += -0.004928846661019106;
        }
      } else {
        if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6618962921466065019) ) ) {
          if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5848953917334175356) ) ) {
            result[0] += 0.017988391228760958;
          } else {
            if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.0491948752242571466) ) ) {
              result[0] += 0.07720598451551869;
            } else {
              result[0] += 0.046587379599323506;
            }
          }
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8974826944165169573) ) ) {
            result[0] += 0.07873065157429256;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
              result[0] += 0.10279330920041047;
            } else {
              result[0] += 0.06065246662548873;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7903724875956132934) ) ) {
        if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7787197788111503982) ) ) {
          result[0] += 0.10331841451667793;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
            result[0] += 0.12395306116455536;
          } else {
            result[0] += 0.07135406855908653;
          }
        }
      } else {
        result[0] += 0.13992836434891961;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7681116375709841071) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5963654365793032985) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5002776212835359226) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2692173444281812933) ) ) {
          result[0] += -0.10468341793815655;
        } else {
          result[0] += -0.09405676223514062;
        }
      } else {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.2891310748198975267) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5346753968654129885) ) ) {
            result[0] += -0.0747565000328086;
          } else {
            result[0] += -0.04876943145518877;
          }
        } else {
          result[0] += -0.0809668653424316;
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6983922411789055262) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.625000000000000111) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.918998912310483176e-06) ) ) {
            result[0] += -0.0004323529841712849;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5233231360301507928) ) ) {
              if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.111965421064566098) ) ) {
                result[0] += -0.03199160070451654;
              } else {
                result[0] += 0.011149558595233243;
              }
            } else {
              result[0] += -0.04708932480070522;
            }
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6519664152643053212) ) ) {
            result[0] += -0.06844407372832936;
          } else {
            if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5277382668411586542) ) ) {
              if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.4905089628645931121) ) ) {
                result[0] += -0.053467218190347277;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5250000000000001332) ) ) {
                  result[0] += 0.007809905178382145;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)85.50000000000001421) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3099638191016706457) ) ) {
                      result[0] += -0.07171390122360852;
                    } else {
                      result[0] += -0.016526614188118904;
                    }
                  } else {
                    result[0] += -0.012329644136827219;
                  }
                }
              }
            } else {
              result[0] += -0.0616255597898781;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 0.046922665734658676;
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7345825791375740765) ) ) {
            result[0] += -0.019464982128683035;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8050000000000001599) ) ) {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7526242738429421708) ) ) {
                result[0] += 0.001214518976227913;
              } else {
                result[0] += 0.03574642854125357;
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5400401558291457738) ) ) {
                if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6169663040644358665) ) ) {
                  result[0] += -0.004160931555745186;
                } else {
                  result[0] += 0.039862115724991244;
                }
              } else {
                result[0] += -0.01613978351848229;
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7362391952976967691) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8477341880899419424) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8102659665622439222) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7801862323115579256) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6950000000000000622) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)183.5000000000000284) ) ) {
                if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5268343718203251091) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5950000000000000844) ) ) {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)77.50000000000001421) ) ) {
                      result[0] += 0.042602586891058676;
                    } else {
                      result[0] += 0;
                    }
                  } else {
                    result[0] += -0.01442026517823025;
                  }
                } else {
                  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7765936419225654141) ) ) {
                    result[0] += 0.009323532756325262;
                  } else {
                    result[0] += 0.047663933594892384;
                  }
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)318.5000000000000568) ) ) {
                  result[0] += 0.08258789170608036;
                } else {
                  result[0] += 0.026411919385800915;
                }
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)92.50000000000001421) ) ) {
                result[0] += -0.0005760740744434686;
              } else {
                result[0] += 0.029668196292906724;
              }
            }
          } else {
            result[0] += -0.012430828382165795;
          }
        } else {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.5757484439148531363) ) ) {
            result[0] += 0.011063016749238019;
          } else {
            if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.652066519749839979) ) ) {
              result[0] += 0.0423203724782424;
            } else {
              result[0] += 0.07365533228429567;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9208995247894758984) ) ) {
          result[0] += 0.07175529989640053;
        } else {
          result[0] += 0.09399289085923053;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7903724875956132934) ) ) {
        if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7787197788111503982) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.11531632005372597;
          } else {
            result[0] += 0.08810030772703278;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
            result[0] += 0.11568685577824674;
          } else {
            result[0] += 0.06590522367647288;
          }
        }
      } else {
        result[0] += 0.13195466029141872;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7681116375709841071) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5963654365793032985) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5002776212835359226) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2984949881764770718) ) ) {
          result[0] += -0.10186671288266033;
        } else {
          result[0] += -0.09041877971304514;
        }
      } else {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.2891310748198975267) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5346753968654129885) ) ) {
            result[0] += -0.0714567320679541;
          } else {
            result[0] += -0.04580313378961187;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02666563385037100387) ) ) {
            result[0] += -0.08169175712386709;
          } else {
            result[0] += -0.059714955297249295;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6983922411789055262) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.625000000000000111) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.918998912310483176e-06) ) ) {
            result[0] += -0.00039720871028852133;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5233231360301507928) ) ) {
              if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.111965421064566098) ) ) {
                result[0] += -0.029741971497168916;
              } else {
                result[0] += 0.010197738477090096;
              }
            } else {
              result[0] += -0.04409265875213521;
            }
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6519664152643053212) ) ) {
            result[0] += -0.06501947249200359;
          } else {
            if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.4839807590921524905) ) ) {
              if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.4905089628645931121) ) ) {
                result[0] += -0.05028064208008828;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5150000000000001243) ) ) {
                  result[0] += 0.013259751899804955;
                } else {
                  result[0] += -0.030280742930319186;
                }
              }
            } else {
              result[0] += -0.05829810184035221;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 0.04258018124537321;
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7244058930400819607) ) ) {
            result[0] += -0.02140839641473762;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6150000000000001021) ) ) {
              result[0] += 0.01076383133492435;
            } else {
              if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6140748412273120405) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002115500000000000626) ) ) {
                  result[0] += -0.030687599380568212;
                } else {
                  result[0] += -0.005943080990946052;
                }
              } else {
                result[0] += 0.009793897147841953;
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7362391952976967691) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8477341880899419424) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8052728383663535494) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)53.50000000000000711) ) ) {
            result[0] += 0.006273821302476724;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3905483718502500978) ) ) {
              result[0] += 0.03397403262188792;
            } else {
              result[0] += 0.006912846831287978;
            }
          }
        } else {
          if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.652066519749839979) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9808239647505231362) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002721500000000000394) ) ) {
                result[0] += 0.017997375397701725;
              } else {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6965142823366835545) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01719150000000000192) ) ) {
                    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6064509334668474194) ) ) {
                      result[0] += 0.01429046814128081;
                    } else {
                      result[0] += 0.05785948718644498;
                    }
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03609650000000001052) ) ) {
                      result[0] += 0.003912206182908105;
                    } else {
                      result[0] += 0.044311866416171256;
                    }
                  }
                } else {
                  result[0] += 0.07852445724885065;
                }
              }
            } else {
              result[0] += 0;
            }
          } else {
            result[0] += 0.06411704377733729;
          }
        }
      } else {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5701039805841723318) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8050000000000001599) ) ) {
            result[0] += 0.07024836986118639;
          } else {
            result[0] += 0.03094883258698694;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8739450231822561976) ) ) {
              result[0] += 0.06291116520255702;
            } else {
              result[0] += 0.08384223091398968;
            }
          } else {
            result[0] += 0.05456257256257332;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7528363226160118549) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
          result[0] += 0.1112036741082611;
        } else {
          if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7583373477169182975) ) ) {
            result[0] += 0.07359095129279045;
          } else {
            if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6859815657019552315) ) ) {
              result[0] += 0.06724881678548315;
            } else {
              result[0] += 0.1002199235638773;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8574845066336775901) ) ) {
          result[0] += 0.11576499310206355;
        } else {
          result[0] += 0.12702658795944025;
        }
      }
    }
  }
}

