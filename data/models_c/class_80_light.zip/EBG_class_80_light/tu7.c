
#include "header.h"

void predict_unit7(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5089951851639061831) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2296243883448841061) ) ) {
      result[0] += -0.05238552766512854;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3881589449934809699) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
            result[0] += -0.015457259206677818;
          } else {
            result[0] += -0.03578901249311053;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2682576517146198491) ) ) {
            result[0] += -0.004758487082828749;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4806185349221548386) ) ) {
              result[0] += -0.04669856293545164;
            } else {
              result[0] += -0.005074032155268155;
            }
          }
        }
      } else {
        result[0] += -0.03824763422005264;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7946879440622868218) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5818191821885695392) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002350500000000000592) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
            result[0] += 0;
          } else {
            result[0] += -0.015179986593420385;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.219097262499394541) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.038112519465065331) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4073174598994975804) ) ) {
                result[0] += -0.01054326360637995;
              } else {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2091302419391287415) ) ) {
                  result[0] += 0.01270133697296798;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4899381758793970865) ) ) {
                    result[0] += -0.02027566042206471;
                  } else {
                    if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.04908445857219279757) ) ) {
                      result[0] += 0.017999721976920662;
                    } else {
                      result[0] += -0.002500447645887721;
                    }
                  }
                }
              }
            } else {
              result[0] += 0.027937172610501645;
            }
          } else {
            result[0] += -0.01823664565285674;
          }
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9024131424400998469) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4418673924623115479) ) ) {
            result[0] += 0.016944350732253054;
          } else {
            result[0] += 0.0028757360406597;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9803163499134560643) ) ) {
              result[0] += 0.019064254090295357;
            } else {
              result[0] += 0.04683053897474663;
            }
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6818507002937542749) ) ) {
              result[0] += -0.006574431351688834;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9350000000000001643) ) ) {
                result[0] += 0.018301816999851752;
              } else {
                result[0] += -0.004401609048995073;
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8622565274156744897) ) ) {
        result[0] += 0.030500842487064257;
      } else {
        result[0] += 0.05077907857430996;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4806185349221548386) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2252215573829355333) ) ) {
      result[0] += -0.052265716511760464;
    } else {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
        result[0] += -0.013035617419436943;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005066500000000000691) ) ) {
          result[0] += -0.04038834133545767;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7242520756532664361) ) ) {
              result[0] += -0.01948162902335923;
            } else {
              result[0] += 0.027418432329581223;
            }
          } else {
            result[0] += -0.044399976465425414;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7946879440622868218) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.767064450770027606) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6213841400436609375) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6750000000000001554) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3750000000000000555) ) ) {
              result[0] += -0.0025321682590219393;
            } else {
              result[0] += -0.013452917527647762;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001716500000000000361) ) ) {
              result[0] += -0.03980493983327148;
            } else {
              result[0] += -0.012370194032736561;
            }
          }
        } else {
          result[0] += -0.0018384625049907312;
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6486987125073885307) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6750000000000001554) ) ) {
            result[0] += 0.010105610554345173;
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5862977461025268289) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9036370584454770372) ) ) {
                result[0] += -0.007921541107138198;
              } else {
                result[0] += 0.020225412679009014;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9350000000000001643) ) ) {
                result[0] += 0.02229388147150855;
              } else {
                result[0] += 0.0017275862458270533;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += 0.027540601421606987;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0007525000000000000222) ) ) {
              result[0] += -0.014728826901233196;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001274500000000000242) ) ) {
                result[0] += 0.042995631956748784;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9350000000000001643) ) ) {
                  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7149490869166016394) ) ) {
                    result[0] += 0.007373329829521291;
                  } else {
                    result[0] += 0.02170230198832193;
                  }
                } else {
                  result[0] += -0.0034449243858834366;
                }
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8622565274156744897) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9108935748982122105) ) ) {
          result[0] += 0.03411256050519106;
        } else {
          result[0] += 0.0038345299798361113;
        }
      } else {
        result[0] += 0.05025497342973228;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4806185349221548386) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2296243883448841061) ) ) {
      result[0] += -0.051702724541077764;
    } else {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
        result[0] += -0.012414462407613713;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005066500000000000691) ) ) {
          result[0] += -0.03947086812237642;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7242520756532664361) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3930944169495623197) ) ) {
                result[0] += -0.02828142561405504;
              } else {
                if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1675106646999162952) ) ) {
                  result[0] += 0.019977959336797604;
                } else {
                  result[0] += -0.014329480239346213;
                }
              }
            } else {
              result[0] += 0.026200931786008137;
            }
          } else {
            result[0] += -0.04350670996039364;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7946879440622868218) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7803782188884571536) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.626047238333421352) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4850000000000000422) ) ) {
            result[0] += -0.003289753340306018;
          } else {
            result[0] += -0.014747727081851339;
          }
        } else {
          result[0] += -0.0012888818308815692;
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6616950502373190046) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6750000000000001554) ) ) {
            result[0] += 0.01090527751748003;
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.596398030554127434) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9550000000000000711) ) ) {
                if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5818191821885695392) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6959555468592965033) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.7050000000000000711) ) ) {
                      result[0] += 0.00517298862787365;
                    } else {
                      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8650000000000001021) ) ) {
                        result[0] += 0;
                      } else {
                        result[0] += -0.021441505423599152;
                      }
                    }
                  } else {
                    result[0] += 0.012375027894715502;
                  }
                } else {
                  result[0] += 0.01375228175337537;
                }
              } else {
                result[0] += -0.02554820484132741;
              }
            } else {
              result[0] += 0.005991482633355218;
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += 0.03009145633449665;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3837516359296482826) ) ) {
              result[0] += -0.005305705436741156;
            } else {
              result[0] += 0.013671162547187766;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8622565274156744897) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9108935748982122105) ) ) {
          result[0] += 0.03317673399748387;
        } else {
          result[0] += 0.0036328289857539327;
        }
      } else {
        result[0] += 0.04972314010846039;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4806185349221548386) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2252215573829355333) ) ) {
      result[0] += -0.051585371728255544;
    } else {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
        result[0] += -0.01186363423317584;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005066500000000000691) ) ) {
          result[0] += -0.03882460360065883;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7242520756532664361) ) ) {
              result[0] += -0.017981149139303536;
            } else {
              result[0] += 0.02337071078756575;
            }
          } else {
            result[0] += -0.0430148660389202;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8257976220666124467) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9024131424400998469) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6972829280248278305) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.051391296366422923) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1850000000000000255) ) ) {
              result[0] += 0.021716807288748738;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4002876056281407524) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3565697080904522975) ) ) {
                  result[0] += -0.0014753119859057667;
                } else {
                  result[0] += -0.03054060095026846;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4141149047989949872) ) ) {
                  result[0] += 0.025224360903255964;
                } else {
                  result[0] += -0.005240099939619184;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1316270000000000218) ) ) {
              result[0] += -0.027363346980621536;
            } else {
              result[0] += 0.007363408110784448;
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += 0.018150478919409935;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0005635000000000000902) ) ) {
              result[0] += -0.016756194193873433;
            } else {
              result[0] += 0.0023531150782837794;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9803163499134560643) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9150000000000001465) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7822317346455099907) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8650000000000001021) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.512422281582914696) ) ) {
                  result[0] += 0.0021701112631739897;
                } else {
                  result[0] += 0.020820822558092925;
                }
              } else {
                result[0] += -0.010744225173432707;
              }
            } else {
              result[0] += 0.02257408308526541;
            }
          } else {
            result[0] += 0;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += 0.038102777423421746;
          } else {
            result[0] += 0;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.919425862722463072) ) ) {
        result[0] += 0.03691089481528291;
      } else {
        result[0] += 0.05241503645167638;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4604805625892014476) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2252215573829355333) ) ) {
      result[0] += -0.05123082920661019;
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02500000000000000486) ) ) {
        result[0] += 0.01570464571132869;
      } else {
        result[0] += -0.024617004380349073;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8257976220666124467) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8250070987435854653) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5897839699588115492) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2719359470653786581) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.051391296366422923) ) ) {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.07175569222910598011) ) ) {
                result[0] += -0.009903292332625028;
              } else {
                result[0] += 0.011089858465380348;
              }
            } else {
              result[0] += -0.0291711748029831;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.513213472667429782) ) ) {
              result[0] += -0.03590058210347648;
            } else {
              result[0] += -0.013398232059901307;
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
            result[0] += 0.013462035967900734;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0005635000000000000902) ) ) {
              result[0] += -0.015820644975309748;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.194581012612933923) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.038112519465065331) ) ) {
                  result[0] += -0.0008036575107244113;
                } else {
                  result[0] += 0.01923268900764192;
                }
              } else {
                result[0] += -0.01501279255192007;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9803163499134560643) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3837516359296482826) ) ) {
            if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.6269304705026225166) ) ) {
              result[0] += 0.005117536374169192;
            } else {
              result[0] += -0.034710726856493554;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4350073368341708657) ) ) {
              result[0] += 0.02388941529784092;
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4025583117277176659) ) ) {
                result[0] += -0.013944783662218777;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9024131424400998469) ) ) {
                  result[0] += 0.0044754083581848665;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2057245000000000323) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05056750000000000828) ) ) {
                      result[0] += 0.014601992124369629;
                    } else {
                      result[0] += 0;
                    }
                  } else {
                    result[0] += 0.040696035870166083;
                  }
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.03989986105136268;
          } else {
            result[0] += 0.00417389363740751;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.919425862722463072) ) ) {
        result[0] += 0.03603676116281131;
      } else {
        result[0] += 0.05198839185329327;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4429728266653536473) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2252215573829355333) ) ) {
      result[0] += -0.05086634934176451;
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02500000000000000486) ) ) {
        result[0] += 0.01463405852046048;
      } else {
        result[0] += -0.024908582871701234;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8257976220666124467) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5818191821885695392) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2548135000000000816) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.089430082328138649) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.038112519465065331) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.626047238333421352) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9774026691300493619) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1650000000000000355) ) ) {
                    result[0] += 0.015766110452102314;
                  } else {
                    result[0] += -0.009383991294637226;
                  }
                } else {
                  result[0] += -0.04810836537470476;
                }
              } else {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.8085344187842374852) ) ) {
                  result[0] += -0.023845900648875394;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.7050000000000000711) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7889021474406031631) ) ) {
                      if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.5170510649617241494) ) ) {
                        result[0] += 0.013784251162142928;
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4093335132160804135) ) ) {
                          result[0] += -0.029709341126100994;
                        } else {
                          result[0] += -0.0005365257979016124;
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4435662465829146028) ) ) {
                        result[0] += -0.00501461399238886;
                      } else {
                        result[0] += 0.012846883004058549;
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8650000000000001021) ) ) {
                      result[0] += 0.0018941034137885458;
                    } else {
                      result[0] += -0.01791897773607693;
                    }
                  }
                }
              }
            } else {
              result[0] += 0.0670912048287186;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.457260671080300662) ) ) {
              result[0] += -0.025793752608462964;
            } else {
              result[0] += 0.005309384972483135;
            }
          }
        } else {
          result[0] += 0.032289644135006366;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9803163499134560643) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8250070987435854653) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4642381624371859083) ) ) {
              result[0] += 0.015081353091307386;
            } else {
              result[0] += -0.001372606246371395;
            }
          } else {
            result[0] += 0.00941892899908673;
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
            result[0] += 0.04155798101523221;
          } else {
            result[0] += 0.0062354816567626835;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.919425862722463072) ) ) {
        result[0] += 0.035160018469897414;
      } else {
        result[0] += 0.05155519264190292;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4429728266653536473) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2252215573829355333) ) ) {
      result[0] += -0.05049131644081795;
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02500000000000000486) ) ) {
        result[0] += 0.01364967994999196;
      } else {
        result[0] += -0.02406823433761461;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8257976220666124467) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5818191821885695392) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2548135000000000816) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.089430082328138649) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.038112519465065331) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.626047238333421352) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.966590843157139501) ) ) {
                  result[0] += -0.007996472842387588;
                } else {
                  result[0] += -0.043524671204836315;
                }
              } else {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.8085344187842374852) ) ) {
                  result[0] += -0.022557902180463225;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.7050000000000000711) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7889021474406031631) ) ) {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8850000000000001199) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7392963230402010977) ) ) {
                          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4314418144595498217) ) ) {
                            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3904540419095477444) ) ) {
                              result[0] += -0.0032855010758760183;
                            } else {
                              result[0] += 0.02636699669469485;
                            }
                          } else {
                            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4394533747236181176) ) ) {
                              result[0] += -0.030588446857816125;
                            } else {
                              result[0] += -9.048338922164333e-05;
                            }
                          }
                        } else {
                          result[0] += 0.026081704306452888;
                        }
                      } else {
                        result[0] += -0.007545788773098979;
                      }
                    } else {
                      result[0] += 0.008313233084473081;
                    }
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8650000000000001021) ) ) {
                      result[0] += 0.00178918000065313;
                    } else {
                      result[0] += -0.016851551489062276;
                    }
                  }
                }
              }
            } else {
              result[0] += 0.06166495981870991;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.457260671080300662) ) ) {
              result[0] += -0.024663373171845547;
            } else {
              result[0] += 0.004999555190074439;
            }
          }
        } else {
          result[0] += 0.030377346773374336;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9803163499134560643) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8250070987435854653) ) ) {
            result[0] += 0.0013329332401654428;
          } else {
            result[0] += 0.008939344369415292;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
            result[0] += 0.04560696581504754;
          } else {
            result[0] += 0.010623182486814264;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.919425862722463072) ) ) {
        result[0] += 0.034281330600779994;
      } else {
        result[0] += 0.05111460186875625;
      }
    }
  }
}

