
#include "header.h"

void predict_unit7(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5963654365793032985) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2984949881764770718) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1326198720340577564) ) ) {
        result[0] += -0.08524952115933056;
      } else {
        result[0] += -0.06836678499894415;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5002776212835359226) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3850000000000000644) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4225046379504136529) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3250000000000000666) ) ) {
                result[0] += -0.036173732498043676;
              } else {
                result[0] += 0.03048373635475884;
              }
            } else {
              result[0] += -0.05492837285657757;
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.071894537606111239) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3678432009547739079) ) ) {
                result[0] += 0.007013674718281854;
              } else {
                result[0] += -0.06522614094399153;
              }
            } else {
              result[0] += -0.005120820365525421;
            }
          }
        } else {
          result[0] += -0.0677292755428625;
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6750000000000001554) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3750000000000000555) ) ) {
            result[0] += -0.012203262236827847;
          } else {
            if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.404687332281506329) ) ) {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5540771664276676889) ) ) {
                result[0] += -0.05871698242528453;
              } else {
                result[0] += -0.0229079335346277;
              }
            } else {
              result[0] += -0.007430852891043577;
            }
          }
        } else {
          result[0] += -0.05209104005149151;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7528363226160118549) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8259515021272411106) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7092351592339261046) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7550000000000001155) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8158067323869347964) ) ) {
              result[0] += -0.005102377352249271;
            } else {
              result[0] += 0.03746376351177483;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5777799923753693667) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4461239275072768073) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6302228576884423283) ) ) {
                  result[0] += -0.011164820796950586;
                } else {
                  result[0] += -0.05427156830055396;
                }
              } else {
                result[0] += 0.05971154062457199;
              }
            } else {
              result[0] += -0.03331081581810858;
            }
          }
        } else {
          result[0] += 0.0016940078034788334;
        }
      } else {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.652066519749839979) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5250000000000001332) ) ) {
            result[0] += 0.052233618283667446;
          } else {
            if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5848953917334175356) ) ) {
              result[0] += -0.039354140264895074;
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3245064132951274716) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
                  result[0] += 0.033522354332146655;
                } else {
                  result[0] += -0.007022523199135097;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4558178340201005097) ) ) {
                  result[0] += -0.03852134278061251;
                } else {
                  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9208995247894758984) ) ) {
                    result[0] += 0.0051543802216712205;
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)97.50000000000001421) ) ) {
                      result[0] += 0.04588758049092946;
                    } else {
                      result[0] += 0;
                    }
                  }
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.194581012612933923) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6784611311055277483) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5508018452917812224) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
                  if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7295796804147470782) ) ) {
                    result[0] += 0.006660600631552069;
                  } else {
                    result[0] += 0.046590203041433076;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.00534585034897470078) ) ) {
                    result[0] += 0.042485113729524106;
                  } else {
                    result[0] += 0.014008760776891746;
                  }
                }
              } else {
                result[0] += -0.030518427768496222;
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7210440605025126848) ) ) {
                result[0] += 0.07361846758801484;
              } else {
                result[0] += 0.028922872107399814;
              }
            }
          } else {
            result[0] += -0.01400231019487826;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.891804912653853199) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
          if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8255177083825077089) ) ) {
            result[0] += 0.04907279342945517;
          } else {
            result[0] += 0.07252946029059712;
          }
        } else {
          if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7903724875956132934) ) ) {
            result[0] += -0.012516727739586989;
          } else {
            if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9401337961119743403) ) ) {
              result[0] += 0.05066791064151033;
            } else {
              result[0] += -0.006760053258314114;
            }
          }
        }
      } else {
        result[0] += 0.08454366431491868;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5963654365793032985) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2984949881764770718) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1326198720340577564) ) ) {
        result[0] += -0.0848843290272574;
      } else {
        result[0] += -0.06693291393748033;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5002776212835359226) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3850000000000000644) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3944417379768624943) ) ) {
            result[0] += -0.04767335020981823;
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.071894537606111239) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3678432009547739079) ) ) {
                result[0] += 0;
              } else {
                result[0] += -0.053239699158999614;
              }
            } else {
              result[0] += -0.014738073399240357;
            }
          }
        } else {
          result[0] += -0.0661353059742189;
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6750000000000001554) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3750000000000000555) ) ) {
            result[0] += -0.011294565627228068;
          } else {
            if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.404687332281506329) ) ) {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.569064158510991791) ) ) {
                result[0] += -0.05008972360159162;
              } else {
                result[0] += -0.01262764185337045;
              }
            } else {
              result[0] += -0.006863678487603541;
            }
          }
        } else {
          result[0] += -0.04999581209144461;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7903724875956132934) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6950092425598650703) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7345825791375740765) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05835789545007314533) ) ) {
              result[0] += -0.011697430592404124;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7250000000000000888) ) ) {
                result[0] += 0.04293172740263617;
              } else {
                result[0] += -0.002061359300420216;
              }
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002786500000000000348) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0009302321760857001865) ) ) {
                result[0] += -0.057761131964486706;
              } else {
                if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5491908716579932959) ) ) {
                  result[0] += -0.02143403557298949;
                } else {
                  result[0] += 0.0056235978197390684;
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02245450000000000224) ) ) {
                result[0] += 0.0007730074347841356;
              } else {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.294841568336650095) ) ) {
                  result[0] += 0.022506879049937117;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03181695757404256336) ) ) {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)647.5000000000001137) ) ) {
                      result[0] += -0.03875164046876456;
                    } else {
                      result[0] += 0.0025317066065969683;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1306523025041242125) ) ) {
                      result[0] += 0.02640363964871341;
                    } else {
                      result[0] += -0.017311719647078658;
                    }
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.13900392495124092) ) ) {
            result[0] += 0.03479907534576207;
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.7835979262278595092) ) ) {
              if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5701039805841723318) ) ) {
                result[0] += -0.04739705863816161;
              } else {
                result[0] += 0.01236950306922548;
              }
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2850245757603476204) ) ) {
                result[0] += 0.015050298843113565;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8050000000000001599) ) ) {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.08835747683243963535) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05270200000000000579) ) ) {
                      result[0] += -0.03316667808431526;
                    } else {
                      result[0] += 0.015227266986190513;
                    }
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1063465000000000243) ) ) {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0433285000000000059) ) ) {
                        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)50.50000000000000711) ) ) {
                          result[0] += -0.014517031020623634;
                        } else {
                          result[0] += 0.028349369147594956;
                        }
                      } else {
                        result[0] += 0.05359999213553633;
                      }
                    } else {
                      result[0] += -0.0032823427469293375;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6219282818452492867) ) ) {
                    result[0] += -0.009155360326925531;
                  } else {
                    result[0] += 0.004558883760305508;
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7787197788111503982) ) ) {
          result[0] += 0.017832889684156826;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9550000000000000711) ) ) {
            result[0] += 0.039335427396024414;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03028402022170490274) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0120154081726181021) ) ) {
                result[0] += -9.360012738827634e-05;
              } else {
                result[0] += 0.05238707660654158;
              }
            } else {
              result[0] += -0.028058090859047185;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9071228288109037807) ) ) {
        result[0] += 0.060028493301367364;
      } else {
        result[0] += 0.08486153501259303;
      }
    }
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5654503268216671819) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2984949881764770718) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1326198720340577564) ) ) {
        result[0] += -0.08453225530570183;
      } else {
        result[0] += -0.06546175277864304;
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001290117952834850213) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4317260786397597028) ) ) {
          result[0] += -0.03222507866829724;
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5250000000000001332) ) ) {
            result[0] += -0.0028397286254009967;
          } else {
            result[0] += -0.054128892706484674;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002908500000000000495) ) ) {
          result[0] += -0.05856841351844761;
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4041232048486821937) ) ) {
            result[0] += -0.05251057039144668;
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)318.5000000000000568) ) ) {
              result[0] += -0.019962978902993617;
            } else {
              result[0] += -0.05830875516249166;
            }
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7903724875956132934) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8790620348987957522) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7244058930400819607) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2750000000000000777) ) ) {
            result[0] += 0.01092161005272565;
          } else {
            result[0] += -0.009893369764306319;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += 0.02727274565125285;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0005715000000000000678) ) ) {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7908432344530634817) ) ) {
                result[0] += -0.002611267453670068;
              } else {
                result[0] += -0.04721245071912442;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.002155313061765850528) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002115500000000000626) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001210500000000000204) ) ) {
                    result[0] += 0;
                  } else {
                    result[0] += -0.05213315333481897;
                  }
                } else {
                  result[0] += 0.009811851011670758;
                }
              } else {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.016561434387754259) ) ) {
                  result[0] += 0.036505696124215385;
                } else {
                  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.657270379803368221) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6450000000000001288) ) ) {
                      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3931761618090452437) ) ) {
                        result[0] += -0.016467813399937865;
                      } else {
                        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4795364038944723295) ) ) {
                          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7150000000000000799) ) ) {
                            result[0] += 0.00015373891318109148;
                          } else {
                            result[0] += 0.041035051858209194;
                          }
                        } else {
                          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5193865869095478649) ) ) {
                            result[0] += -0.0182513630396718;
                          } else {
                            result[0] += 0.012257036133995515;
                          }
                        }
                      }
                    } else {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02101337656308150184) ) ) {
                        if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6118109021115948343) ) ) {
                          result[0] += -0.005998718124359563;
                        } else {
                          result[0] += 0.011037153499632335;
                        }
                      } else {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02197600000000000595) ) ) {
                            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5758421811557790093) ) ) {
                              result[0] += -0.020473615464031238;
                            } else {
                              result[0] += 0.024735978475823477;
                            }
                          } else {
                            result[0] += -0.041296455624859923;
                          }
                        } else {
                          result[0] += -0.047956777903627144;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.009909582214883102744) ) ) {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)214.5000000000000284) ) ) {
                        result[0] += 0.017654351102632217;
                      } else {
                        result[0] += 0.057366746993899556;
                      }
                    } else {
                      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.294841568336650095) ) ) {
                        result[0] += -0.034111873919204276;
                      } else {
                        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)153.5000000000000284) ) ) {
                          result[0] += 0.015910069242341045;
                        } else {
                          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9750000000000000888) ) ) {
                            result[0] += 0.02189540462937629;
                          } else {
                            result[0] += -0.03606971775313794;
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7787197788111503982) ) ) {
          result[0] += 0.01642404404524838;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9550000000000000711) ) ) {
            result[0] += 0.03740241440030963;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03028402022170490274) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01828550000000000314) ) ) {
                result[0] += -0.008930140774269199;
              } else {
                result[0] += 0.04227903563216141;
              }
            } else {
              result[0] += -0.02533112939211377;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9071228288109037807) ) ) {
        if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9573774901653852032) ) ) {
          result[0] += 0.05960500601092245;
        } else {
          result[0] += 0;
        }
      } else {
        result[0] += 0.08413076684497654;
      }
    }
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5654503268216671819) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2984949881764770718) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1326198720340577564) ) ) {
        result[0] += -0.08419059933033697;
      } else {
        result[0] += -0.06395218600818924;
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001290117952834850213) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)14.50000000000000178) ) ) {
          result[0] += -0.04673678702918487;
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3850000000000000644) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3150000000000000577) ) ) {
              result[0] += -0.02380645158580351;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1750000000000000167) ) ) {
                result[0] += 0.06591794023157051;
              } else {
                result[0] += 0.005747129862582578;
              }
            }
          } else {
            result[0] += -0.03429057871805328;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002908500000000000495) ) ) {
          result[0] += -0.056682919368192024;
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4041232048486821937) ) ) {
            result[0] += -0.05059236007900197;
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)318.5000000000000568) ) ) {
              result[0] += -0.018623108142307526;
            } else {
              result[0] += -0.05632018697637531;
            }
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7903724875956132934) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6888851207273123389) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7092351592339261046) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7550000000000001155) ) ) {
            result[0] += -0.004486934717261103;
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.619628671453726132) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5596867406532665123) ) ) {
                result[0] += 0.0007111396287922536;
              } else {
                result[0] += -0.05940454355146656;
              }
            } else {
              result[0] += -0.011841996419285893;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001777500000000000217) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
              if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5268343718203251091) ) ) {
                result[0] += -0.003213569380408784;
              } else {
                result[0] += 0.04009064060604968;
              }
            } else {
              result[0] += -0.00961121782831946;
            }
          } else {
            if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5903541535616282365) ) ) {
              if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5026146189546180088) ) ) {
                if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5614739610281048732) ) ) {
                  result[0] += 0;
                } else {
                  result[0] += 0.043936348718830266;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02068044101058480119) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9250000000000001554) ) ) {
                    result[0] += 0.010570276746850822;
                  } else {
                    result[0] += -0.02261656514822995;
                  }
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)17.50000000000000355) ) ) {
                    result[0] += -0.05579024540132162;
                  } else {
                    result[0] += -0.008689060808641307;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7750000000000001332) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.625000000000000111) ) ) {
                  result[0] += 0.049510987888364555;
                } else {
                  result[0] += 0.00797151024036311;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02420030329452320383) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.002155313061765850528) ) ) {
                    result[0] += -0.01777092361394459;
                  } else {
                    result[0] += 0.01624409100090416;
                  }
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8950000000000001288) ) ) {
                    result[0] += 0.011937886045645609;
                  } else {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7605905273618090989) ) ) {
                      result[0] += -0.0019004384313937972;
                    } else {
                      result[0] += -0.035413290026782146;
                    }
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7653488716222877075) ) ) {
          result[0] += 0.013944676535188733;
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9820134369784404571) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9021581204195773251) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1306523025041242125) ) ) {
                result[0] += -0.030023143637030823;
              } else {
                result[0] += 0.029655444836763634;
              }
            } else {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9175023825236152675) ) ) {
                result[0] += 0.06295326075637318;
              } else {
                if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8334151879459361645) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.013855723816631915) ) ) {
                    result[0] += 0.026924891416454183;
                  } else {
                    result[0] += -0.023250785387173022;
                  }
                } else {
                  result[0] += 0.04797834532495708;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
              result[0] += 0.03027153878744941;
            } else {
              result[0] += -0.020133131330744316;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9071228288109037807) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
          result[0] += 0.06406713763011226;
        } else {
          result[0] += 0.04067141729694281;
        }
      } else {
        result[0] += 0.08341483619086816;
      }
    }
  }
}

