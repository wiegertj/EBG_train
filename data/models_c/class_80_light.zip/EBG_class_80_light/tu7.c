
#include "header.h"

void predict_unit7(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8166103485750532132) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1316283809119187798) ) ) {
      result[0] += -0.11069123688666024;
    } else {
      result[0] += -0.001494033295729473;
    }
  } else {
    result[0] += 0.06107996971609703;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9504576888574564064) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1316283809119187798) ) ) {
      result[0] += -0.10969729242765246;
    } else {
      result[0] += -0.00024109606373643082;
    }
  } else {
    result[0] += 0.10657533587089459;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6435024531842806761) ) ) {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02722700000000000467) ) ) {
      result[0] += -0.0142133794625036;
    } else {
      result[0] += 0.018963072469647055;
    }
  } else {
    result[0] += 0.02415454615179757;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9504576888574564064) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1316283809119187798) ) ) {
      result[0] += -0.10850484965519085;
    } else {
      result[0] += -0.0001765119834995298;
    }
  } else {
    result[0] += 0.104663697916216;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5036672824508469093) ) ) {
    result[0] += -0.03178941549201499;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.545000000000000151) ) ) {
      result[0] += 0.03927430168264241;
    } else {
      result[0] += -0.00018545112569513117;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9504576888574564064) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1316283809119187798) ) ) {
      result[0] += -0.10694818792849266;
    } else {
      result[0] += -0.00020330448989861922;
    }
  } else {
    result[0] += 0.10298140282219978;
  }
}

