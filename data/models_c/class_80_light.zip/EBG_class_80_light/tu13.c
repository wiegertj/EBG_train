
#include "header.h"

void predict_unit13(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1313656708211964064) ) ) {
    result[0] += -0.047200388266834765;
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9446153469900331334) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5818191821885695392) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004774500000000000098) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
            result[0] += 0.0018765199520116912;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4806185349221548386) ) ) {
              result[0] += -0.023840664942750497;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0007145000000000001827) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9050000000000001377) ) ) {
                  result[0] += -0.026855690432281;
                } else {
                  result[0] += 0.0031275494585761275;
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0009635000000000000552) ) ) {
                  result[0] += 0.013682871377099604;
                } else {
                  result[0] += -0.005004197940475743;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006340500000000001517) ) ) {
            result[0] += 0.010845071320911785;
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9050000000000001377) ) ) {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.5708656043828381765) ) ) {
                if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.6528670330614280148) ) ) {
                  result[0] += 0.0008911261561422297;
                } else {
                  result[0] += -0.02885538737814282;
                }
              } else {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3309607168382264208) ) ) {
                  if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3763018001168558224) ) ) {
                    if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4627502129294571165) ) ) {
                      result[0] += 0.024773232594445777;
                    } else {
                      result[0] += -0.010563859008595708;
                    }
                  } else {
                    result[0] += 0.034711949199760415;
                  }
                } else {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.08835747683243963535) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.566354131742045519) ) ) {
                      result[0] += -0.012545039210852815;
                    } else {
                      result[0] += 0.009508937467120431;
                    }
                  } else {
                    if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.04908445857219279757) ) ) {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01854050000000000489) ) ) {
                        result[0] += 0.05414796864121977;
                      } else {
                        result[0] += 0.011760923540256537;
                      }
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.711772222489803541) ) ) {
                        result[0] += -0.005056428311372353;
                      } else {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4950000000000000511) ) ) {
                          result[0] += 0.022879355171693018;
                        } else {
                          result[0] += 0.0006721905971194634;
                        }
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.7050000000000000711) ) ) {
                if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5564233291784753677) ) ) {
                  result[0] += -0.012199720984072801;
                } else {
                  result[0] += 0.018039024664462857;
                }
              } else {
                result[0] += -0.024107366573084963;
              }
            }
          }
        }
      } else {
        result[0] += 0.002618429282054591;
      }
    } else {
      result[0] += 0.03515041588707796;
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.09778100794021217512) ) ) {
    result[0] += -0.051439279864850404;
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9446153469900331334) ) ) {
      if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.394173313988213314) ) ) {
        result[0] += 0.03587058103839717;
      } else {
        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.8085344187842374852) ) ) {
          result[0] += -0.015407949179985907;
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3315854282412060705) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005503500000000000579) ) ) {
              result[0] += 0.007099931725088839;
            } else {
              result[0] += 0.03886553305938016;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1450000000000000455) ) ) {
              result[0] += -0.01428899160559332;
            } else {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7149490869166016394) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3622054098241206943) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00240550000000000052) ) ) {
                    result[0] += 0.0009686369290193241;
                  } else {
                    result[0] += -0.03656078784527433;
                  }
                } else {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.01051018765715429869) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5485006052512563235) ) ) {
                      result[0] += 0.00027037909522678035;
                    } else {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001050500000000000218) ) ) {
                        result[0] += -0.014537577750471082;
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5613540176884422861) ) ) {
                          result[0] += 0.06030885980414963;
                        } else {
                          result[0] += 0.005046400976830855;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5345516166834171079) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.51855191273869361) ) ) {
                        result[0] += -0.003358049286191982;
                      } else {
                        result[0] += 0.027155305128196257;
                      }
                    } else {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09115515568269431934) ) ) {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02546650000000000302) ) ) {
                          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0003975000000000000668) ) ) {
                            result[0] += 0.005821010274815587;
                          } else {
                            result[0] += -0.022476456069197116;
                          }
                        } else {
                          result[0] += 0.0009641905859913884;
                        }
                      } else {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09277402050424696234) ) ) {
                          result[0] += 0.02431446166167488;
                        } else {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1027559661512248146) ) ) {
                            result[0] += -0.034869170097983015;
                          } else {
                            result[0] += -0.0008399072814247281;
                          }
                        }
                      }
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8650000000000001021) ) ) {
                  result[0] += 0.027885677618828205;
                } else {
                  result[0] += 0.0038818333934001062;
                }
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.181114681928726734) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9673254386414430472) ) ) {
          result[0] += -0.02949915363979607;
        } else {
          result[0] += 0.04192073527781318;
        }
      } else {
        result[0] += 0.05140333881953641;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.09778100794021217512) ) ) {
    result[0] += -0.051177780706377664;
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8442376020855621999) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3310097201537537948) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3315854282412060705) ) ) {
          result[0] += 0.04806489449978436;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.051391296366422923) ) ) {
            result[0] += -0.007833339434678246;
          } else {
            result[0] += -0.033850026443062196;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09500000000000001499) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4899381758793970865) ) ) {
            result[0] += 0;
          } else {
            result[0] += 0.049549725928970154;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6722423356281408413) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.52031910737473408) ) ) {
              result[0] += -0.00018511718080124818;
            } else {
              result[0] += -0.01532321878189211;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6285027855690678011) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003910500000000001648) ) ) {
                result[0] += 0.0058840589640564225;
              } else {
                result[0] += 0.041370352596562805;
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6869304497989950908) ) ) {
                result[0] += -0.03687244812269642;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7273918420100503601) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6644777202348807199) ) ) {
                    result[0] += -0.01494557539667085;
                  } else {
                    result[0] += 0.027790181876531022;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8722100575184922322) ) ) {
                    result[0] += -0.01770358803551916;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7823171070351759848) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.762281072713567931) ) ) {
                        result[0] += 0;
                      } else {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001716500000000000361) ) ) {
                          result[0] += 0.00098813713202374;
                        } else {
                          result[0] += 0.0476077239338932;
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8158067323869347964) ) ) {
                        result[0] += -0.02277212056077927;
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8168185667587940513) ) ) {
                          result[0] += 0.0511353746730797;
                        } else {
                          result[0] += -0.00048495813410539456;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9673254386414430472) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5140962685175880509) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5002620384924624242) ) ) {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9571120492262563673) ) ) {
              result[0] += 0.012770027563211214;
            } else {
              result[0] += -0.043292884825593694;
            }
          } else {
            result[0] += -0.0534117081189369;
          }
        } else {
          result[0] += 0.027356511492658966;
        }
      } else {
        result[0] += 0.04599589393103735;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.09778100794021217512) ) ) {
    result[0] += -0.05090506248291664;
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9446153469900331334) ) ) {
      if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.394173313988213314) ) ) {
        result[0] += 0.033980599328789475;
      } else {
        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.8085344187842374852) ) ) {
          result[0] += -0.014570831408935966;
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3315854282412060705) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005503500000000000579) ) ) {
              result[0] += 0.006527750938961371;
            } else {
              result[0] += 0.03699466512010492;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1450000000000000455) ) ) {
              result[0] += -0.01346851755657213;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3837516359296482826) ) ) {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.6269304705026225166) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7326141283756987255) ) ) {
                    result[0] += -0.015906366175119497;
                  } else {
                    result[0] += 0.01733051911740456;
                  }
                } else {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.5708656043828381765) ) ) {
                    result[0] += -0.0475196770349627;
                  } else {
                    result[0] += -0.013327224963652587;
                  }
                }
              } else {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4627502129294571165) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4389499174623116007) ) ) {
                    result[0] += 0.014752880534744512;
                  } else {
                    result[0] += -0.008558041835698636;
                  }
                } else {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3763018001168558224) ) ) {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4230095078473000147) ) ) {
                      result[0] += -0.04154984409694421;
                    } else {
                      result[0] += -0.005608247657768843;
                    }
                  } else {
                    if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3439225837886180082) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4573000492713568677) ) ) {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7480372587188576228) ) ) {
                          result[0] += -0.022764581731628104;
                        } else {
                          result[0] += 0.018454868245137892;
                        }
                      } else {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007091500000000001448) ) ) {
                          result[0] += 0.009312908130442771;
                        } else {
                          result[0] += 0.058681477595002085;
                        }
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2548135000000000816) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7823171070351759848) ) ) {
                          result[0] += 0.00044110416000472805;
                        } else {
                          result[0] += -0.006503711447252955;
                        }
                      } else {
                        result[0] += 0.015254210312093138;
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.181114681928726734) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9673254386414430472) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4189166818844221596) ) ) {
            result[0] += 0;
          } else {
            result[0] += -0.07324152002008044;
          }
        } else {
          result[0] += 0.040599694850617936;
        }
      } else {
        result[0] += 0.05095272818426246;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.09778100794021217512) ) ) {
    result[0] += -0.05062072614181179;
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9446153469900331334) ) ) {
      if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.394173313988213314) ) ) {
        result[0] += 0.03223225690263545;
      } else {
        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.8085344187842374852) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5564233291784753677) ) ) {
            result[0] += -0.026524878202247748;
          } else {
            result[0] += -0.0033410655975275438;
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3315854282412060705) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005503500000000000579) ) ) {
              result[0] += 0.006156029817988741;
            } else {
              result[0] += 0.035237486839455504;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1450000000000000455) ) ) {
              result[0] += -0.012879154842971205;
            } else {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6690753303250667194) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8450000000000000844) ) ) {
                  result[0] += -0.00017747001226124038;
                } else {
                  result[0] += -0.0183343739639559;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6669784622613067482) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1295212041281339765) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1027559661512248146) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9450000000000000622) ) ) {
                        result[0] += 0.006933430096154933;
                      } else {
                        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7560518798657903661) ) ) {
                          result[0] += -0.06021101364827894;
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9898915035113978744) ) ) {
                            result[0] += -0.019758475022962064;
                          } else {
                            result[0] += 0.015027420004127622;
                          }
                        }
                      }
                    } else {
                      result[0] += 0.02823366086529038;
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.09838300000000001211) ) ) {
                      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6818507002937542749) ) ) {
                        result[0] += -0.036393125955936044;
                      } else {
                        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9108935748982122105) ) ) {
                          result[0] += -0.0014774347706849912;
                        } else {
                          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8442376020855621999) ) ) {
                            result[0] += -0.08942943921376866;
                          } else {
                            result[0] += 0;
                          }
                        }
                      }
                    } else {
                      result[0] += 0.02549912195924983;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7293493725076146683) ) ) {
                    result[0] += 0.03558767487207906;
                  } else {
                    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7729377599117425168) ) ) {
                      result[0] += -0.0028959496352066565;
                    } else {
                      result[0] += 0.025700063373329363;
                    }
                  }
                }
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.181114681928726734) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9673254386414430472) ) ) {
          result[0] += -0.023556516758316996;
        } else {
          result[0] += 0.03995341883328173;
        }
      } else {
        result[0] += 0.05064415032901306;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.09778100794021217512) ) ) {
    result[0] += -0.05032438028162025;
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9673254386414430472) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9803163499134560643) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8115313189803874394) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9150000000000001465) ) ) {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7149490869166016394) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3356592091331648819) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0003975000000000000668) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1850000000000000255) ) ) {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1550000000000000266) ) ) {
                      result[0] += -0.0011713300043248974;
                    } else {
                      result[0] += 0.03683024004053484;
                    }
                  } else {
                    result[0] += -0.017289342354977033;
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4827419593969848877) ) ) {
                    result[0] += 0.009899720867355188;
                  } else {
                    result[0] += -0.02288096417352108;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1550000000000000266) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01779450000000000129) ) ) {
                    result[0] += 0.02764213688587269;
                  } else {
                    result[0] += 0;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4565432367178989814) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.013855723816631915) ) ) {
                      result[0] += -0.015094766724861795;
                    } else {
                      result[0] += 0.018465366509412832;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6722423356281408413) ) ) {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.52031910737473408) ) ) {
                        result[0] += -0.00032691099438025335;
                      } else {
                        result[0] += -0.017354750897163863;
                      }
                    } else {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6285027855690678011) ) ) {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003910500000000001648) ) ) {
                          result[0] += 0.006124355629723914;
                        } else {
                          result[0] += 0.03547905454573042;
                        }
                      } else {
                        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8050000000000001599) ) ) {
                          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4470670498171123719) ) ) {
                            result[0] += 0.00227853353524863;
                          } else {
                            result[0] += 0.03754186792149506;
                          }
                        } else {
                          result[0] += -0.0037756564571107616;
                        }
                      }
                    }
                  }
                }
              }
            } else {
              result[0] += 0.009440142179968723;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9735377426793575539) ) ) {
              result[0] += -0.006711190207803411;
            } else {
              result[0] += -0.038729262832725896;
            }
          }
        } else {
          result[0] += 0.01932521461911566;
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
          result[0] += 0.03337852670081759;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6574014915075377941) ) ) {
            result[0] += 0.0006936540939805743;
          } else {
            result[0] += 0.03641285339989518;
          }
        }
      }
    } else {
      result[0] += 0.04445117542926411;
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.09778100794021217512) ) ) {
    result[0] += -0.05001564788840317;
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9673254386414430472) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9803163499134560643) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8115313189803874394) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9150000000000001465) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6213841400436609375) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7355897138442212269) ) ) {
                  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4153687836296520164) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                      if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3309607168382264208) ) ) {
                        result[0] += 0.10164757698936908;
                      } else {
                        result[0] += 0.00410276150002116;
                      }
                    } else {
                      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.07500000000000002498) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.516314698492462365) ) ) {
                          result[0] += 0;
                        } else {
                          result[0] += -0.032955653674487245;
                        }
                      } else {
                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.038112519465065331) ) ) {
                          result[0] += -0.0015878472934261914;
                        } else {
                          result[0] += 0.03820897164256861;
                        }
                      }
                    }
                  } else {
                    result[0] += -0.032834441705415884;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00253150000000000033) ) ) {
                    result[0] += -0.015449910516310698;
                  } else {
                    result[0] += 0.1459519658888968;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8842987317654950052) ) ) {
                  result[0] += -0.039031608244590024;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01886800000000000629) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003995500000000001654) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002296500000000000364) ) ) {
                        result[0] += 0;
                      } else {
                        result[0] += -0.04212805280585508;
                      }
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8158067323869347964) ) ) {
                        result[0] += 0;
                      } else {
                        result[0] += 0.06211224741336235;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.26324206362513769) ) ) {
                      result[0] += -0.050763794353065245;
                    } else {
                      result[0] += -0.00815608528140063;
                    }
                  }
                }
              }
            } else {
              result[0] += 0.0006836481783104451;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9735377426793575539) ) ) {
              result[0] += -0.006302661966309138;
            } else {
              result[0] += -0.03548144120046667;
            }
          }
        } else {
          result[0] += 0.018586574965378563;
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
          result[0] += 0.03248032947698431;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6574014915075377941) ) ) {
            result[0] += 0.0006551937869657947;
          } else {
            result[0] += 0.03559421214230068;
          }
        }
      }
    } else {
      result[0] += 0.043905354201482304;
    }
  }
}

