
#include "header.h"

void predict_unit13(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.741544944673366957) ) ) {
    result[0] += 0.002242001617910693;
  } else {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6586898319404412838) ) ) {
      result[0] += -0.04622373182598565;
    } else {
      result[0] += 0.0015029852423179438;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9893091152648634257) ) ) {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0005804544177222000336) ) ) {
      result[0] += 0.0164018530652296;
    } else {
      result[0] += -0.0023052370870347014;
    }
  } else {
    result[0] += 0.10410787074500812;
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002137500000000000511) ) ) {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
      result[0] += 0.015285607387516413;
    } else {
      result[0] += -0.0206995019445947;
    }
  } else {
    result[0] += 0.003941122192211934;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5934757458342058145) ) ) {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5250000000000001332) ) ) {
      result[0] += -0.001945026209179966;
    } else {
      result[0] += -0.04943471694494568;
    }
  } else {
    result[0] += 0.0029625834476327923;
  }
}

