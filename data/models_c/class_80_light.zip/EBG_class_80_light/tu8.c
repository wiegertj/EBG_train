
#include "header.h"

void predict_unit8(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4429728266653536473) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2252215573829355333) ) ) {
      if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3750409390474713223) ) ) {
        result[0] += 0;
      } else {
        result[0] += -0.0513883272671309;
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.578780523307733108) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3550761912678883081) ) ) {
          result[0] += -0.022105051666514355;
        } else {
          result[0] += 0.006314663005296037;
        }
      } else {
        result[0] += -0.032209258985002195;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8257976220666124467) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6486987125073885307) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6875734944390267112) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.25500000000000006) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.07175569222910598011) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3182472210765454057) ) ) {
                result[0] += -0.02076641022919329;
              } else {
                result[0] += 0.013720880572120626;
              }
            } else {
              result[0] += 0.01495249105938165;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5243242856675894847) ) ) {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2372036091469337526) ) ) {
                result[0] += -0.0005834761400698414;
              } else {
                result[0] += -0.029671500885307723;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08162500000000001699) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8254037945979900703) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5250000000000001332) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5664498681879840403) ) ) {
                      result[0] += -0.0013649492812934183;
                    } else {
                      result[0] += 0.031323274298945374;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5798905718019149447) ) ) {
                      result[0] += -0.019359126110460895;
                    } else {
                      result[0] += -0.004129202379040051;
                    }
                  }
                } else {
                  result[0] += -0.03037037161856517;
                }
              } else {
                result[0] += -0.02211416309499187;
              }
            }
          }
        } else {
          result[0] += 0.001657659680640983;
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.971489055395595269) ) ) {
            result[0] += 0.014305427958351042;
          } else {
            result[0] += 0.04130117445918382;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0007525000000000000222) ) ) {
            result[0] += -0.012627254847945754;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001142500000000000069) ) ) {
              result[0] += 0.04703288054788999;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08401200000000001722) ) ) {
                result[0] += 0.0074481676295430725;
              } else {
                result[0] += 0.026479649090936544;
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9375437694740959005) ) ) {
        result[0] += 0.03481499866626843;
      } else {
        result[0] += 0.05200873529716963;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3881589449934809699) ) ) {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1313656708211964064) ) ) {
      result[0] += -0.05545873332451836;
    } else {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3076535050425012741) ) ) {
          result[0] += -0.02361498628199516;
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1423128695048896664) ) ) {
            result[0] += 0.03894195501250965;
          } else {
            result[0] += -0.011317309176886475;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7242520756532664361) ) ) {
            result[0] += -0.031669321850323486;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006980500000000001461) ) ) {
              result[0] += -0.036743822942648954;
            } else {
              result[0] += 0.0566990411670274;
            }
          }
        } else {
          result[0] += -0.05015461111526565;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8257976220666124467) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7423774199879572544) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5566107632786835291) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1850000000000000255) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1645254211347557949) ) ) {
              result[0] += 0.030834378149773207;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4851016894037892269) ) ) {
                result[0] += -0.012732435314684485;
              } else {
                result[0] += 0.0225610619106965;
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6650000000000001465) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4565432367178989814) ) ) {
                result[0] += -0.02398182112275869;
              } else {
                result[0] += -0.009217616617715155;
              }
            } else {
              result[0] += -0.03975522239672668;
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4002876056281407524) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3565697080904522975) ) ) {
              result[0] += 0;
            } else {
              result[0] += -0.025565367057849807;
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8850000000000001199) ) ) {
              result[0] += 0.0003598337260541626;
            } else {
              result[0] += -0.009609824126252964;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6690753303250667194) ) ) {
          result[0] += 0.0026886632228378072;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005631500000000000221) ) ) {
              result[0] += -0.0037588871391127793;
            } else {
              result[0] += 0.03101025491957446;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9650000000000000799) ) ) {
              result[0] += 0.011669372280421359;
            } else {
              result[0] += -0.00892520362799267;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.919425862722463072) ) ) {
        result[0] += 0.032483383607833316;
      } else {
        result[0] += 0.05021867896178083;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3881589449934809699) ) ) {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1313656708211964064) ) ) {
      result[0] += -0.055317855027651346;
    } else {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3076535050425012741) ) ) {
          result[0] += -0.022807972595777416;
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1423128695048896664) ) ) {
            result[0] += 0.03554142800796911;
          } else {
            result[0] += -0.010800137379145315;
          }
        }
      } else {
        result[0] += -0.03302460647844272;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8257976220666124467) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7277004308735181004) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2365840000000000443) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.089430082328138649) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.038112519465065331) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5373923050813967928) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2389374995899939125) ) ) {
                  result[0] += 0;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4724009380560733606) ) ) {
                    result[0] += -0.03057755615339311;
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.25500000000000006) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5499504253266332965) ) ) {
                        result[0] += -0.009331280915039496;
                      } else {
                        result[0] += 0.02739501620990133;
                      }
                    } else {
                      result[0] += -0.018264749468219765;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05431350000000000761) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4002876056281407524) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3565697080904522975) ) ) {
                      result[0] += 0;
                    } else {
                      result[0] += -0.028831379324132073;
                    }
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3350000000000000755) ) ) {
                      result[0] += 0.01802225502799469;
                    } else {
                      result[0] += -0.0017203430866327783;
                    }
                  }
                } else {
                  result[0] += -0.017467064534255672;
                }
              }
            } else {
              result[0] += 0.05498349490935466;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.457260671080300662) ) ) {
              result[0] += -0.024926397651026878;
            } else {
              result[0] += 0;
            }
          }
        } else {
          result[0] += 0.028701285305135722;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9024131424400998469) ) ) {
          result[0] += 0.0019539921459450407;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9853835301935895963) ) ) {
            result[0] += 0.009317310861881381;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
              result[0] += 0.04734380126757456;
            } else {
              result[0] += 0.009004506569145547;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9375437694740959005) ) ) {
        result[0] += 0.03304868468672114;
      } else {
        result[0] += 0.051205606375072106;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3356592091331648819) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1313656708211964064) ) ) {
      result[0] += -0.055174863357083034;
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += 0.008803038338480658;
      } else {
        result[0] += -0.03024527813079653;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8257976220666124467) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7068923547583354505) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2548135000000000816) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8326679465075378372) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8158067323869347964) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7823171070351759848) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.038112519465065331) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4806185349221548386) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.26324206362513769) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1550000000000000266) ) ) {
                        result[0] += 0.0024391660940801946;
                      } else {
                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3550761912678883081) ) ) {
                          result[0] += -0.022654088089788926;
                        } else {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6411603019421380223) ) ) {
                            result[0] += 0.018307378238593883;
                          } else {
                            result[0] += -0.021483279775639637;
                          }
                        }
                      }
                    } else {
                      result[0] += -0.03469470646462557;
                    }
                  } else {
                    result[0] += -0.004165766946677868;
                  }
                } else {
                  result[0] += 0.02925481335799982;
                }
              } else {
                result[0] += -0.033811201901394174;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001510500000000000341) ) ) {
                result[0] += -0.005572589850035876;
              } else {
                result[0] += 0.0764651592124064;
              }
            }
          } else {
            result[0] += -0.025294727868353514;
          }
        } else {
          result[0] += 0.03811093370850853;
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6818507002937542749) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8450000000000000844) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9439246386423358892) ) ) {
              result[0] += 0.0021021983063074044;
            } else {
              result[0] += 0.024493493548168203;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
              result[0] += 0.006899113061459385;
            } else {
              result[0] += -0.027223841237099713;
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.839472575921198283) ) ) {
              result[0] += 0.016141414488164373;
            } else {
              result[0] += 0.04989995673838211;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9650000000000000799) ) ) {
              result[0] += 0.011613049644609404;
            } else {
              result[0] += -0.008382541444708479;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9446153469900331334) ) ) {
        result[0] += 0.03282470671478958;
      } else {
        result[0] += 0.05159847518412148;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3356592091331648819) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1313656708211964064) ) ) {
      result[0] += -0.05502935749155583;
    } else {
      result[0] += -0.027762964462805417;
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8442376020855621999) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5818191821885695392) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5755371229009215162) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09500000000000001499) ) ) {
            result[0] += 0.023853530904666846;
          } else {
            result[0] += -0.011126801345452245;
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8950000000000001288) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6722423356281408413) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.482877277201360311) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6480364325376885004) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6186550572613066512) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5910501547487437835) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5811189422864322385) ) ) {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005066500000000000691) ) ) {
                          result[0] += -0.007840927733117453;
                        } else {
                          result[0] += 0.003906016345523753;
                        }
                      } else {
                        result[0] += -0.0307808375918852;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6014274169849246343) ) ) {
                        result[0] += 0.04581501405566435;
                      } else {
                        result[0] += 0.0005742137196416726;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3595998346489175934) ) ) {
                      result[0] += -0.042429600237045055;
                    } else {
                      result[0] += -0.0011050672141453258;
                    }
                  }
                } else {
                  result[0] += 0.038360976142686666;
                }
              } else {
                result[0] += -0.02949092973601599;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.051391296366422923) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02843150000000000191) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7191325395287454514) ) ) {
                      result[0] += 0.030250268361466937;
                    } else {
                      result[0] += -0.003665742331977293;
                    }
                  } else {
                    result[0] += 0.055400939841892705;
                  }
                } else {
                  result[0] += -0.0001611734484584572;
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1316270000000000218) ) ) {
                  result[0] += -0.017153933018191507;
                } else {
                  result[0] += 0.02156301700030288;
                }
              }
            }
          } else {
            result[0] += -0.007521855733619369;
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.736034375232267446) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9250000000000001554) ) ) {
            result[0] += 0.018917699316168626;
          } else {
            result[0] += 0.0032043367596193886;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9067600986576694888) ) ) {
            result[0] += 0.01856191563550936;
          } else {
            result[0] += -0.018887149712423806;
          }
        }
      }
    } else {
      result[0] += 0.04284687714843089;
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3310097201537537948) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1313656708211964064) ) ) {
      result[0] += -0.05488092512042206;
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3622054098241206943) ) ) {
        result[0] += 0.03003619145231103;
      } else {
        result[0] += -0.028631231450413852;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8442376020855621999) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7068923547583354505) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2548135000000000816) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7383710406281408511) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9111514820863041431) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7190147863316583843) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5089951851639061831) ) ) {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3550000000000000377) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5499504253266332965) ) ) {
                        result[0] += -0.014289988365124916;
                      } else {
                        result[0] += 0.005605976701053015;
                      }
                    } else {
                      result[0] += -0.03079166148660704;
                    }
                  } else {
                    result[0] += -0.0031489858963478705;
                  }
                } else {
                  result[0] += -0.033754432130125286;
                }
              } else {
                result[0] += 0.027409910488077706;
              }
            } else {
              result[0] += 0.047207649708369555;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8842987317654950052) ) ) {
              result[0] += -0.03897579523245407;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01401950000000000245) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.051391296366422923) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003040500000000000234) ) ) {
                    result[0] += 0;
                  } else {
                    result[0] += 0.05131276359427032;
                  }
                } else {
                  result[0] += -0.013948422898646833;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.314196657149456993) ) ) {
                  result[0] += -0.03424065778991206;
                } else {
                  result[0] += 0.009438631491905736;
                }
              }
            }
          }
        } else {
          result[0] += 0.034998057294110686;
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7149490869166016394) ) ) {
          result[0] += 0.00224926130470362;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9803163499134560643) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003040500000000000234) ) ) {
                result[0] += 0.03084375684896519;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3837516359296482826) ) ) {
                  result[0] += -0.02846134336006261;
                } else {
                  result[0] += 0.010775700857716789;
                }
              }
            } else {
              result[0] += 0.03449583964626067;
            }
          } else {
            result[0] += -0.008236874380985202;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9673254386414430472) ) ) {
        result[0] += 0.03622458457520984;
      } else {
        result[0] += 0.055072253019550495;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3310097201537537948) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1313656708211964064) ) ) {
      result[0] += -0.05472915886851569;
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3622054098241206943) ) ) {
        result[0] += 0.027702979147480725;
      } else {
        result[0] += -0.027790241905539758;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8442376020855621999) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6589536398896721492) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 0.0005179281702629891;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001716500000000000361) ) ) {
            result[0] += -0.02464279946870136;
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.01051018765715429869) ) ) {
              if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.07583587458330973141) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3950000000000000733) ) ) {
                  result[0] += -0.017050919443601247;
                } else {
                  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4072821481552766354) ) ) {
                    result[0] += 0.009353381238787333;
                  } else {
                    result[0] += -0.02518069617003923;
                  }
                }
              } else {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.04908445857219279757) ) ) {
                  result[0] += 0.07834573327586211;
                } else {
                  result[0] += 0.0006039357365236137;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5345516166834171079) ) ) {
                result[0] += 0.011514324251234422;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5910501547487437835) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03154350000000000903) ) ) {
                    result[0] += -0.034365089626300124;
                  } else {
                    result[0] += 0.0020775879016568626;
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6059045152763820052) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3414117295455482703) ) ) {
                      result[0] += -0.0003898959320808481;
                    } else {
                      result[0] += 0.06443174760050546;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6462201978140704739) ) ) {
                      result[0] += -0.031411260809311115;
                    } else {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.45553739944690258) ) ) {
                        result[0] += 0.04506230137473638;
                      } else {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01278300000000000096) ) ) {
                          result[0] += 0;
                        } else {
                          result[0] += -0.016961223189790417;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6690753303250667194) ) ) {
          result[0] += 0.0011537873776083232;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9650000000000000799) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9820324513815327228) ) ) {
              result[0] += 0.010473643077898498;
            } else {
              result[0] += 0.03538185071823774;
            }
          } else {
            result[0] += -0.0035000391421236925;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9673254386414430472) ) ) {
        result[0] += 0.035407333400119714;
      } else {
        result[0] += 0.0548502938164548;
      }
    }
  }
}

