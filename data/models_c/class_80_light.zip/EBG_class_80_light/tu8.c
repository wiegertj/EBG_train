
#include "header.h"

void predict_unit8(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5828162941871858349) ) ) {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004989500000000000879) ) ) {
      result[0] += -0.024846351102429387;
    } else {
      result[0] += 0.004641373687703994;
    }
  } else {
    result[0] += 0.01442209299842674;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9504576888574564064) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
      result[0] += 0.035538005625609805;
    } else {
      result[0] += -0.004491971233595002;
    }
  } else {
    result[0] += 0.10090303316776204;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6235829596258417595) ) ) {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.625000000000000111) ) ) {
      result[0] += -0.006941502883276234;
    } else {
      result[0] += -0.0709182859601715;
    }
  } else {
    result[0] += 0.005977212519892023;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1316283809119187798) ) ) {
    result[0] += -0.1055744139853819;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
      result[0] += 0.04261802644116156;
    } else {
      result[0] += -0.002552640740644983;
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003250500000000000351) ) ) {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
      result[0] += 0.027044203959686042;
    } else {
      result[0] += -0.025052394527229294;
    }
  } else {
    result[0] += 0.007574547375165718;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5411232180154271765) ) ) {
    result[0] += -0.02417010827888968;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.545000000000000151) ) ) {
      result[0] += 0.03949101157672783;
    } else {
      result[0] += 0.00036817478067358933;
    }
  }
}

