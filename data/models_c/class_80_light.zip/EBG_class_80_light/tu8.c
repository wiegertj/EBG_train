
#include "header.h"

void predict_unit8(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5346753968654129885) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2692173444281812933) ) ) {
      result[0] += -0.0756903787777246;
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)13.50000000000000178) ) ) {
          result[0] += -0.06639807683733175;
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3850000000000000644) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3150000000000000577) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2150000000000000244) ) ) {
                result[0] += 0;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2650000000000000688) ) ) {
                  result[0] += -0.05020155088759709;
                } else {
                  result[0] += 0.0006913842291749909;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1750000000000000167) ) ) {
                result[0] += 0.05848000442522072;
              } else {
                result[0] += 0.0009687183847555523;
              }
            }
          } else {
            result[0] += -0.056418491472415;
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4041232048486821937) ) ) {
          result[0] += -0.05663407332118924;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04922519882226530918) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4650000000000000244) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06940500000000000835) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00958400000000000224) ) ) {
                    result[0] += -0.039593307061403064;
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)26.50000000000000355) ) ) {
                      result[0] += 0.044163531367315684;
                    } else {
                      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5000114811306534124) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01334817315459485218) ) ) {
                          result[0] += 0.09128210603922049;
                        } else {
                          result[0] += -0.03861351044550246;
                        }
                      } else {
                        result[0] += -0.03675073673637547;
                      }
                    }
                  }
                } else {
                  result[0] += 0.04677966030661245;
                }
              } else {
                result[0] += -0.06679432640196133;
              }
            } else {
              result[0] += -0.05697497483716024;
            }
          } else {
            result[0] += 0.005304700621073435;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7903724875956132934) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.657270379803368221) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6617384408086778302) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2450000000000000233) ) ) {
            result[0] += 0.020815348641546924;
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)143.5000000000000284) ) ) {
              result[0] += -0.008787771929788541;
            } else {
              result[0] += -0.023597086555073043;
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4750000000000000333) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4450000000000000622) ) ) {
              result[0] += 0.004380708932863665;
            } else {
              result[0] += 0.03314950491326085;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1272695000000000076) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.13900392495124092) ) ) {
                result[0] += 0.03193825412597426;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.075834742120705068) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.013855723816631915) ) ) {
                    if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5903541535616282365) ) ) {
                      result[0] += -0.005314936973008819;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007592500000000001158) ) ) {
                        result[0] += -0.0010633871629196039;
                      } else {
                        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)94.50000000000001421) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01629754728789850268) ) ) {
                            result[0] += 0.05270409976566356;
                          } else {
                            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9150000000000001465) ) ) {
                              result[0] += 0.02776985745730352;
                            } else {
                              result[0] += -0.0057713532916965765;
                            }
                          }
                        } else {
                          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01828550000000000314) ) ) {
                            result[0] += 0.019108929805085537;
                          } else {
                            result[0] += -0.013785782833797725;
                          }
                        }
                      }
                    }
                  } else {
                    result[0] += 0.05005412239085269;
                  }
                } else {
                  result[0] += -0.018623726072425267;
                }
              }
            } else {
              result[0] += -0.0305389586063921;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7583373477169182975) ) ) {
          result[0] += 0.010320802006113617;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001671500000000000243) ) ) {
            result[0] += 0.05844948869677085;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9050000000000001377) ) ) {
              result[0] += 0.06435576943118879;
            } else {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9820134369784404571) ) ) {
                if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6859815657019552315) ) ) {
                  result[0] += -0.0005044482182831712;
                } else {
                  result[0] += 0.027157373017128852;
                }
              } else {
                result[0] += -0.003942598618322538;
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.891804912653853199) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
          result[0] += 0.060441193392057155;
        } else {
          result[0] += 0.03281122574474183;
        }
      } else {
        result[0] += 0.08135998224265087;
      }
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8043140244282375173) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4676830380907958662) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2194568116175419636) ) ) {
        result[0] += -0.07838256462130337;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)108.5000000000000142) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3250000000000000666) ) ) {
              result[0] += -0.04285152498639292;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3450000000000000289) ) ) {
                result[0] += 0.050181224057459686;
              } else {
                result[0] += -0.0344577758357057;
              }
            }
          } else {
            result[0] += -0.003329708218512053;
          }
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3991986961566040271) ) ) {
            result[0] += -0.05849495976000126;
          } else {
            if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.2377493538478572255) ) ) {
              result[0] += -0.022323051470812507;
            } else {
              result[0] += -0.05586252157073999;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5903541535616282365) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5963654365793032985) ) ) {
          if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.2677549912511515973) ) ) {
            if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.3257634786623919143) ) ) {
              result[0] += -0.008962157486612691;
            } else {
              result[0] += 0.030656614122166515;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02711386111807555233) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6106749517839197283) ) ) {
                if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05227730674148379358) ) ) {
                  result[0] += -0.03218265268851492;
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.009506291499886947854) ) ) {
                    result[0] += 0.0618642671932194;
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)59.50000000000000711) ) ) {
                      result[0] += -0.04061115433910006;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1945214781124514347) ) ) {
                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.009909582214883102744) ) ) {
                          result[0] += -0.04479589760789573;
                        } else {
                          result[0] += 0.029150458459870316;
                        }
                      } else {
                        result[0] += 0.06059118900182199;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.049093876896621466;
              }
            } else {
              result[0] += -0.006352144678662708;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8950000000000001288) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)986.5000000000001137) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)455.5000000000000568) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1325525000000000453) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.121680358022378199) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7149244603266332598) ) ) {
                      result[0] += -0.0001569420412865729;
                    } else {
                      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7142421398313097969) ) ) {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01792500000000000343) ) ) {
                          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)104.5000000000000142) ) ) {
                            result[0] += 0;
                          } else {
                            result[0] += 0.05577262414248867;
                          }
                        } else {
                          result[0] += -0.03288983880300631;
                        }
                      } else {
                        result[0] += 0.054782730527061736;
                      }
                    }
                  } else {
                    result[0] += -0.0273417177991386;
                  }
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5511625663567840672) ) ) {
                    result[0] += 0.004638704473132804;
                  } else {
                    result[0] += -0.039752792949479476;
                  }
                }
              } else {
                if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5339411944729167692) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5550000000000001599) ) ) {
                    result[0] += 0.002735935727889556;
                  } else {
                    result[0] += -0.05999232117745953;
                  }
                } else {
                  result[0] += 0.00638567648987124;
                }
              }
            } else {
              result[0] += 0.03674149455076537;
            }
          } else {
            if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5509197063102150294) ) ) {
              result[0] += -0.0424906173638335;
            } else {
              result[0] += -0.009848317770931;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00284950000000000047) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)19.50000000000000355) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
              result[0] += 0.0005570810044070135;
            } else {
              result[0] += 0.03718748030348269;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7968587857286433263) ) ) {
              result[0] += -0.0007244877752206802;
            } else {
              result[0] += -0.03149163234433036;
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8550000000000000933) ) ) {
            result[0] += 0.023278277166649874;
          } else {
            result[0] += 0.009673181045512198;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8747476225597411448) ) ) {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003711500000000000389) ) ) {
        result[0] += 0.0614419333218011;
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8047940420101146186) ) ) {
            result[0] += 0.02812238739116127;
          } else {
            result[0] += 0.0505165249695965;
          }
        } else {
          result[0] += 0.0006904224663179221;
        }
      }
    } else {
      result[0] += 0.07870277360955125;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8043140244282375173) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4676830380907958662) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2194568116175419636) ) ) {
        result[0] += -0.07766882433841057;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)13.50000000000000178) ) ) {
            result[0] += -0.06329241237292244;
          } else {
            result[0] += -0.015996549210750468;
          }
        } else {
          result[0] += -0.04855813241076745;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6617384408086778302) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6059238433417085679) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5879208094472362367) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008664500000000002061) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001121963940922750215) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.000758500000000000168) ) ) {
                  result[0] += -0.0073705318714941195;
                } else {
                  result[0] += 0.05583551452995385;
                }
              } else {
                result[0] += -0.03118335927376095;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.006989228421098950955) ) ) {
                result[0] += 0.05704381686874167;
              } else {
                if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.08110515786938453375) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4814085394974874643) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4578754035427136104) ) ) {
                      result[0] += -0.02420989247256572;
                    } else {
                      result[0] += 0.028912968536497326;
                    }
                  } else {
                    result[0] += -0.050846218322605864;
                  }
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.0491948752242571466) ) ) {
                    result[0] += 0.047555441120644776;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3950000000000000733) ) ) {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02898350000000000579) ) ) {
                        result[0] += -0.04301753281662815;
                      } else {
                        result[0] += 0.011361638276474491;
                      }
                    } else {
                      result[0] += 0.0424140449754627;
                    }
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01184850000000000139) ) ) {
              result[0] += 0.06132007903416447;
            } else {
              result[0] += -0.0013513940010106444;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4950000000000000511) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.321871344966293327) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)54.50000000000000711) ) ) {
                result[0] += -0.01109433108486811;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)8.035778151532378251e-06) ) ) {
                  result[0] += -0.00465579336928351;
                } else {
                  result[0] += -0.04817499702933102;
                }
              }
            } else {
              result[0] += 0.02724945183876225;
            }
          } else {
            result[0] += -0.0006218447511011456;
          }
        }
      } else {
        if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6950092425598650703) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00186150000000000009) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
              if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.4280089947631364189) ) ) {
                result[0] += -0.013649837284158476;
              } else {
                result[0] += 0.029806041630226588;
              }
            } else {
              if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5268343718203251091) ) ) {
                result[0] += -0.030391441213752344;
              } else {
                result[0] += -0.005436976955948258;
              }
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.294841568336650095) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4014613332412060864) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0329228537576949018) ) ) {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.7983975536720421262) ) ) {
                    result[0] += 0.029876354113943897;
                  } else {
                    result[0] += -0.003634423121365101;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05445537647292691269) ) ) {
                    result[0] += -0.06415710750186922;
                  } else {
                    result[0] += 0.01672893174004219;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4177895562562814469) ) ) {
                  result[0] += 0.06419453464123219;
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3763018001168558224) ) ) {
                    result[0] += -0.00234682326193303;
                  } else {
                    result[0] += 0.0332159880056047;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4839721393467337207) ) ) {
                result[0] += -0.014734997539964247;
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
                  result[0] += 0.028607555460679737;
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5169807332160805124) ) ) {
                    result[0] += -0.017809550441680675;
                  } else {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.526309877462311726) ) ) {
                      result[0] += 0.05122412097672109;
                    } else {
                      result[0] += 0.002259997272881053;
                    }
                  }
                }
              }
            }
          }
        } else {
          result[0] += 0.014029406223450076;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8859917940727212171) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
        if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8255177083825077089) ) ) {
          result[0] += 0.035767806970750576;
        } else {
          result[0] += 0.063835621490232;
        }
      } else {
        result[0] += 0.018311215476688705;
      }
    } else {
      result[0] += 0.07912277015350686;
    }
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7528363226160118549) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4225046379504136529) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.202212609002558108) ) ) {
        result[0] += -0.07829572753080218;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.25000000000000131e-05) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.391940759496424596) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5881074671461999914) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.528850564864272954) ) ) {
                result[0] += -0.02449044377212887;
              } else {
                result[0] += 0.06876484010992566;
              }
            } else {
              result[0] += -0.05378481892917625;
            }
          } else {
            result[0] += 0.04844240997978293;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004536500000000001469) ) ) {
            result[0] += -0.06522711820687327;
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.0491948752242571466) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4732638062311557703) ) ) {
                result[0] += -0.03805050439596537;
              } else {
                if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.1495568471360887719) ) ) {
                  result[0] += -0.01715410039715368;
                } else {
                  result[0] += 0.09444823718668162;
                }
              }
            } else {
              result[0] += -0.05058550140694167;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6617384408086778302) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001121963940922750215) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001777500000000000217) ) ) {
            result[0] += -0.004794599021793265;
          } else {
            result[0] += 0.0438953055811021;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002721500000000000394) ) ) {
            if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.3995393181459643839) ) ) {
              result[0] += -0.050800433625947064;
            } else {
              result[0] += -0.022838791976913096;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7257460097487438144) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2157356523887877797) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.186440645537972044) ) ) {
                    if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.08835747683243963535) ) ) {
                      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4814085394974874643) ) ) {
                        if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.3589766235598074728) ) ) {
                          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)76.50000000000001421) ) ) {
                            result[0] += -0.05591343498003525;
                          } else {
                            result[0] += 0.011030605313474738;
                          }
                        } else {
                          if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.404687332281506329) ) ) {
                            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6058026752044970431) ) ) {
                              result[0] += 0;
                            } else {
                              result[0] += 0.0735933481553905;
                            }
                          } else {
                            result[0] += -0.012934167475196727;
                          }
                        }
                      } else {
                        result[0] += -0.055181402621851214;
                      }
                    } else {
                      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.499023329447236208) ) ) {
                          result[0] += 0;
                        } else {
                          result[0] += 0.1257717195782629;
                        }
                      } else {
                        result[0] += -0.010307653817549379;
                      }
                    }
                  } else {
                    result[0] += 0.10255081938137467;
                  }
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)54.50000000000000711) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3099638191016706457) ) ) {
                      result[0] += -0.052661154804557964;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4960533228876460865) ) ) {
                        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6479278833417086991) ) ) {
                          result[0] += 0.0036487777953883344;
                        } else {
                          result[0] += 0.10767215334210585;
                        }
                      } else {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02101337656308150184) ) ) {
                          result[0] += 0.015674615287201987;
                        } else {
                          result[0] += -0.0478592186446708;
                        }
                      }
                    }
                  } else {
                    result[0] += -0.038587740289668666;
                  }
                }
              } else {
                result[0] += 0.06267373291671977;
              }
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8158067323869347964) ) ) {
                result[0] += -0.05287329899322948;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01655300000000000174) ) ) {
                  result[0] += 0.08840924449480311;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02981321787079855082) ) ) {
                    result[0] += -0.06133856758684452;
                  } else {
                    result[0] += 0.009381242850605513;
                  }
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8790620348987957522) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)986.5000000000001137) ) ) {
            result[0] += 0.0007171117656144286;
          } else {
            result[0] += 0.033260646442022736;
          }
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9758523261981836283) ) ) {
            result[0] += 0.015692131222938933;
          } else {
            result[0] += -0.010388372149291206;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.891804912653853199) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
        if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8255177083825077089) ) ) {
          result[0] += 0.03488511801334542;
        } else {
          result[0] += 0.06211461508792281;
        }
      } else {
        result[0] += 0.017525128132434262;
      }
    } else {
      result[0] += 0.0789641604901642;
    }
  }
}

