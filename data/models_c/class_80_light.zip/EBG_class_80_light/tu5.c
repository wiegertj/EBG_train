
#include "header.h"

void predict_unit5(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6728666760660634294) ) ) {
    result[0] += -0.037348046340445085;
  } else {
    if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8708183926421412258) ) ) {
      result[0] += 0.010477613260167412;
    } else {
      result[0] += 0.10171121172521076;
    }
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5246343807191508057) ) ) {
    result[0] += -0.05558361037301892;
  } else {
    if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8708183926421412258) ) ) {
      result[0] += 0.004449779346265655;
    } else {
      result[0] += 0.09928656230800871;
    }
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2037479557077091219) ) ) {
    result[0] += -0.10574814103005703;
  } else {
    if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8708183926421412258) ) ) {
      result[0] += -0.0001453483677597161;
    } else {
      result[0] += 0.09674873987992202;
    }
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2037479557077091219) ) ) {
    result[0] += -0.10400671592883977;
  } else {
    if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8919550070487638482) ) ) {
      result[0] += 8.984508553326015e-05;
    } else {
      result[0] += 0.09951919826287638;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7717541733843751306) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2037479557077091219) ) ) {
      result[0] += -0.1021492795728378;
    } else {
      result[0] += -0.013374504988787858;
    }
  } else {
    result[0] += 0.022224537700788565;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2037479557077091219) ) ) {
    result[0] += -0.10016585954939594;
  } else {
    if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8919550070487638482) ) ) {
      result[0] += -0.0002970427504094039;
    } else {
      result[0] += 0.09653911001992203;
    }
  }
}

