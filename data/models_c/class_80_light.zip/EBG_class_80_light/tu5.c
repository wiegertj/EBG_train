
#include "header.h"

void predict_unit5(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7190376324068391556) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5002776212835359226) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2692173444281812933) ) ) {
        result[0] += -0.08536434889230568;
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0001660383056237000384) ) ) {
          result[0] += -0.048378705237797484;
        } else {
          result[0] += -0.06789856632763921;
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6335148768279005305) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.625000000000000111) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5618431930486085246) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3750000000000000555) ) ) {
              result[0] += -0.023292752842471957;
            } else {
              result[0] += -0.04636422273917398;
            }
          } else {
            if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.3365017545099452945) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.07683912189598927911) ) ) {
                if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.129092614560399721) ) ) {
                  result[0] += -0.01259261983821477;
                } else {
                  result[0] += -0.07408486305360654;
                }
              } else {
                result[0] += 0.006876819376127582;
              }
            } else {
              result[0] += -0.034366223153180664;
            }
          }
        } else {
          result[0] += -0.047292308165522434;
        }
      } else {
        if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.4595442724754187358) ) ) {
          if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.4905089628645931121) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6650000000000001465) ) ) {
              result[0] += -0.00444462674654203;
            } else {
              result[0] += -0.0302681983741238;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2970348483088716685) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)50.50000000000000711) ) ) {
                result[0] += -0.041918937007897464;
              } else {
                result[0] += 0.020108839159433244;
              }
            } else {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6788210396489747778) ) ) {
                result[0] += 0.004347885712111296;
              } else {
                result[0] += 0.06526819183107087;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5268343718203251091) ) ) {
            result[0] += -0.032415879435933145;
          } else {
            result[0] += -0.004283775893959153;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7982768737097182266) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6888851207273123389) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8372609372025714425) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += 0.030194397815341993;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001819500000000000154) ) ) {
              result[0] += -0.006671974093600484;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7150000000000000799) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)15.50000000000000178) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)6.500000000000000888) ) ) {
                    result[0] += 0.011202900560025389;
                  } else {
                    result[0] += -0.032443811707186083;
                  }
                } else {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5778807480402011754) ) ) {
                      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4795364038944723295) ) ) {
                        result[0] += 0.019522569025158892;
                      } else {
                        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1044543990012605922) ) ) {
                          result[0] += -0.02329495655934349;
                        } else {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02151600000000000387) ) ) {
                            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.04658055172941339556) ) ) {
                              result[0] += 0.0255672651571309;
                            } else {
                              result[0] += -0.025478198270670972;
                            }
                          } else {
                            result[0] += 0.02218656664014235;
                          }
                        }
                      }
                    } else {
                      result[0] += 0.0422175927323943;
                    }
                  } else {
                    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5339411944729167692) ) ) {
                      result[0] += -0.03587837023495245;
                    } else {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7750000000000001332) ) ) {
                        result[0] += 0.04657804796294952;
                      } else {
                        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7441823078140538117) ) ) {
                          result[0] += 0.024531614753429878;
                        } else {
                          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7962310954155430442) ) ) {
                            result[0] += -0.028480173675307904;
                          } else {
                            result[0] += 0.006284968010129484;
                          }
                        }
                      }
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5861769322017787998) ) ) {
                  result[0] += 0;
                } else {
                  result[0] += 0.03682500573191657;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.003163872696618950323) ) ) {
            result[0] += -0.015325818331150435;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9774026691300493619) ) ) {
              result[0] += 0.0266138636435963;
            } else {
              result[0] += -0.009809743085763975;
            }
          }
        }
      } else {
        result[0] += 0.036136829466074646;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8574845066336775901) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
          result[0] += 0.06837671303392366;
        } else {
          if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7654281038923281821) ) ) {
            result[0] += -0.0012653300725595168;
          } else {
            result[0] += 0.05540237044440756;
          }
        }
      } else {
        result[0] += 0.09080453538661865;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7092351592339261046) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5002776212835359226) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2692173444281812933) ) ) {
        result[0] += -0.08453480953100082;
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0001660383056237000384) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4317260786397597028) ) ) {
            result[0] += -0.052600732103924366;
          } else {
            if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.2031267017715874812) ) ) {
              result[0] += 0.031440695333207244;
            } else {
              result[0] += -0.038244118953964484;
            }
          }
        } else {
          result[0] += -0.06602952865235148;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5963654365793032985) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.625000000000000111) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3750000000000000555) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.785307290008498084e-06) ) ) {
              result[0] += 0;
            } else {
              result[0] += -0.026286424913229852;
            }
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5540771664276676889) ) ) {
              if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.3995393181459643839) ) ) {
                result[0] += -0.06774582316530708;
              } else {
                result[0] += -0.013272772199613434;
              }
            } else {
              result[0] += -0.027941519869542814;
            }
          }
        } else {
          result[0] += -0.05693469615616793;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 0.00672114069780905;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002786500000000000348) ) ) {
            if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5491908716579932959) ) ) {
              result[0] += -0.03805865071822942;
            } else {
              result[0] += 0.003669680860924903;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7220152799565817681) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6156410786045318773) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6276844434422111929) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5917931336432161737) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.25500000000000006) ) ) {
                      result[0] += 0.023253585004840947;
                    } else {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01475432539279020183) ) ) {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5550000000000001599) ) ) {
                          result[0] += 0.04109409471553477;
                        } else {
                          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)47.50000000000000711) ) ) {
                            result[0] += 0.028734863030355332;
                          } else {
                            if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.4905089628645931121) ) ) {
                              result[0] += -0.0390718550544366;
                            } else {
                              result[0] += 0.003841878435929525;
                            }
                          }
                        }
                      } else {
                        result[0] += -0.023657733207021244;
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6059238433417085679) ) ) {
                      result[0] += 0.056442481737431084;
                    } else {
                      result[0] += 0;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4305868785182659919) ) ) {
                    result[0] += -0.06162514326070213;
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)86.50000000000001421) ) ) {
                      result[0] += 0.03610324405683004;
                    } else {
                      result[0] += -0.04002182340477101;
                    }
                  }
                }
              } else {
                result[0] += 0.04208947082218769;
              }
            } else {
              result[0] += -0.03463245938871656;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7982768737097182266) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8624925176218337652) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7765936419225654141) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)6.500000000000000888) ) ) {
            result[0] += 0.024997105396930484;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)13.50000000000000178) ) ) {
              result[0] += -0.025799842275354066;
            } else {
              result[0] += -0.00041815093992980527;
            }
          }
        } else {
          result[0] += 0.011134556139099762;
        }
      } else {
        if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7362391952976967691) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
            if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5647100539952510934) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8050000000000001599) ) ) {
                result[0] += 0.026396713785603567;
              } else {
                result[0] += -0.01609322677380032;
              }
            } else {
              result[0] += 0.03126124524344303;
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1929621623179072765) ) ) {
              result[0] += -0.017113922183220952;
            } else {
              result[0] += 0.020794630805384635;
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2157356523887877797) ) ) {
              result[0] += 0.07516740529006477;
            } else {
              result[0] += 0.026851511366625253;
            }
          } else {
            result[0] += 0.03420919341847783;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8574845066336775901) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
          result[0] += 0.06583242856605762;
        } else {
          if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7771728203832865001) ) ) {
            result[0] += 3.2032929845980636e-05;
          } else {
            result[0] += 0.054998724534149175;
          }
        }
      } else {
        result[0] += 0.08948390644540222;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7092351592339261046) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5002776212835359226) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2692173444281812933) ) ) {
        result[0] += -0.08372553530636408;
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0001660383056237000384) ) ) {
          result[0] += -0.04406438603267452;
        } else {
          result[0] += -0.06415174545960266;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5963654365793032985) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.625000000000000111) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001290117952834850213) ) ) {
            result[0] += -0.015309605568524936;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003257500000000000413) ) ) {
              result[0] += -0.05622465356258033;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6635233717587941671) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.08835747683243963535) ) ) {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3366886552868456062) ) ) {
                    result[0] += -0.01057132326920394;
                  } else {
                    result[0] += -0.058530447678052204;
                  }
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.0491948752242571466) ) ) {
                    result[0] += 0.05394691150253596;
                  } else {
                    if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.3944328354552520399) ) ) {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02496956964338335402) ) ) {
                        result[0] += -0.05265355912261251;
                      } else {
                        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5926917132914574227) ) ) {
                          result[0] += -0.026694776218604856;
                        } else {
                          result[0] += 0.027273663055057917;
                        }
                      }
                    } else {
                      result[0] += 0.02868468765804451;
                    }
                  }
                }
              } else {
                result[0] += -0.05084263716705382;
              }
            }
          }
        } else {
          result[0] += -0.05471593096478491;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 0.006146510510529418;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002786500000000000348) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
              result[0] += -0.035207499621318424;
            } else {
              result[0] += 0.011017608782612192;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7220152799565817681) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6156410786045318773) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6276844434422111929) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5917931336432161737) ) ) {
                    result[0] += -0.008509308822760407;
                  } else {
                    result[0] += 0.02194451115309544;
                  }
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6446808271859297834) ) ) {
                    result[0] += -0.07338275091851149;
                  } else {
                    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6705060535127865817) ) ) {
                      result[0] += -0.031985653279823785;
                    } else {
                      result[0] += 0.02909364571772022;
                    }
                  }
                }
              } else {
                result[0] += 0.03779629996504641;
              }
            } else {
              result[0] += -0.032489080110745944;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7341068085871017557) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6950092425598650703) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.815153682875336405) ) ) {
          result[0] += 0.0019889447276935546;
        } else {
          if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5736856762879515292) ) ) {
            result[0] += -0.024774853121496354;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.795000000000000151) ) ) {
              result[0] += 0.036284908343602415;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9774026691300493619) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7002105688944724182) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)173.5000000000000284) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1228939484199982196) ) ) {
                      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5491908716579932959) ) ) {
                        result[0] += -0.006076348946549132;
                      } else {
                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04307579058463605753) ) ) {
                          result[0] += 0.03558259818062938;
                        } else {
                          if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6013415215327996277) ) ) {
                            result[0] += -0.013456954551862403;
                          } else {
                            result[0] += 0.03289322795563139;
                          }
                        }
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03692650000000000793) ) ) {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9550000000000000711) ) ) {
                          result[0] += -0.03447547328405451;
                        } else {
                          result[0] += 0.008626061278636844;
                        }
                      } else {
                        result[0] += 0.030602511864963378;
                      }
                    }
                  } else {
                    result[0] += -0.007469643894597559;
                  }
                } else {
                  result[0] += 0.05223789856066452;
                }
              } else {
                result[0] += -0.015319192480944996;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6310147675908469589) ) ) {
          result[0] += 0.010623790130221498;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.052908914146726015;
          } else {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9721145574699906478) ) ) {
              result[0] += 0.032015780566827315;
            } else {
              result[0] += 0;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8574845066336775901) ) ) {
        result[0] += 0.0614796685254607;
      } else {
        result[0] += 0.08823923706680299;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7092351592339261046) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4225046379504136529) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2194568116175419636) ) ) {
        result[0] += -0.08479678197212072;
      } else {
        result[0] += -0.06348236051842288;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5654503268216671819) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3750000000000000555) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001595664027398050301) ) ) {
            result[0] += -0.007985757796197316;
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1044543990012605922) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.6652304509807559496) ) ) {
                result[0] += 0;
              } else {
                result[0] += -0.06607160907026037;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01687386533759335436) ) ) {
                result[0] += -0.04335644983502699;
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.526309877462311726) ) ) {
                  result[0] += 0.042678853758181694;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07110500000000001541) ) ) {
                    result[0] += -0.00483312201827795;
                  } else {
                    result[0] += -0.056177272048597085;
                  }
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5223131059347717597) ) ) {
            result[0] += -0.06730153945577488;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003866500000000000579) ) ) {
              result[0] += -0.05156093821148756;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)143.5000000000000284) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.05444248035638010047) ) ) {
                  result[0] += 0.040510138879135175;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03181695757404256336) ) ) {
                    result[0] += -0.043622270067838594;
                  } else {
                    result[0] += 0.015846168566601326;
                  }
                }
              } else {
                result[0] += -0.05832154347262688;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2750000000000000777) ) ) {
          result[0] += 0.006239765042028554;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06261750000000000649) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004934500000000000518) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002365000000000000294) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05835789545007314533) ) ) {
                  result[0] += -0.021922229615925656;
                } else {
                  result[0] += 0.014474646629731826;
                }
              } else {
                if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5268343718203251091) ) ) {
                  result[0] += -0.03268534668959417;
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)64.50000000000001421) ) ) {
                    result[0] += 0.027576018011137227;
                  } else {
                    result[0] += -0.02314675509587276;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.695627306227387554) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.08835747683243963535) ) ) {
                  if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2044121788183031196) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02200300644874975467) ) ) {
                      result[0] += 0.014002329125342463;
                    } else {
                      result[0] += -0.03202998281739024;
                    }
                  } else {
                    result[0] += -0.05889871049493136;
                  }
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.0491948752242571466) ) ) {
                    result[0] += 0.07059166020185606;
                  } else {
                    if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.4704698897725880236) ) ) {
                      result[0] += -0.011975433089330901;
                    } else {
                      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5168249731787434298) ) ) {
                        result[0] += 0.03051391736038925;
                      } else {
                        result[0] += -0.010674549344982081;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.03357566173394105;
              }
            }
          } else {
            result[0] += -0.043015110854325043;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8043140244282375173) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6950092425598650703) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8372609372025714425) ) ) {
          result[0] += 0.0028450832842406275;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.04446937286580055632) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002195500000000000403) ) ) {
              result[0] += -0.006691740996116247;
            } else {
              result[0] += 0.026738715793835393;
            }
          } else {
            result[0] += 0.005344976808565679;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
          if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6225346164046366981) ) ) {
            result[0] += 0.00381967790085395;
          } else {
            result[0] += 0.05074126394272214;
          }
        } else {
          if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.652066519749839979) ) ) {
            result[0] += 0.0028867728236156723;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.00534585034897470078) ) ) {
              result[0] += 0.050337605225187765;
            } else {
              result[0] += 0.02602847001550332;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8574845066336775901) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
          result[0] += 0.06224666729706183;
        } else {
          if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7771728203832865001) ) ) {
            result[0] += 0;
          } else {
            result[0] += 0.04973706275913503;
          }
        }
      } else {
        result[0] += 0.08705730053006665;
      }
    }
  }
}

