
#include "header.h"

void predict_unit0(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7850594327768086744) ) ) {
    result[0] += -0.7386104238162499;
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7190409668845887392) ) ) {
      result[0] += -0.44953431978801295;
    } else {
      result[0] += -0.28436082661535084;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7615309295202301598) ) ) {
    result[0] += -0.14094886871908868;
  } else {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8743586088865268335) ) ) {
      result[0] += 0.08850581248419638;
    } else {
      result[0] += 0.24814781856999563;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7382938213642992187) ) ) {
    result[0] += -0.1365172937610192;
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6961702582086016777) ) ) {
      result[0] += 0.07784648136183729;
    } else {
      result[0] += 0.21693814099210593;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7237884561685795637) ) ) {
    result[0] += -0.13114010115793887;
  } else {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8623457690747273752) ) ) {
      result[0] += 0.050478187019016685;
    } else {
      result[0] += 0.18904249579106736;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6967472100160041482) ) ) {
    result[0] += -0.12824336640842413;
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7751037507677928096) ) ) {
      result[0] += 0.0671189452708433;
    } else {
      result[0] += 0.18548271916273346;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6918155867375320733) ) ) {
    result[0] += -0.12257442729546113;
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7552401522225963282) ) ) {
      result[0] += 0.053783062982488694;
    } else {
      result[0] += 0.16871540035000102;
    }
  }
}

