
#include "header.h"

void predict_unit0(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8052728383663535494) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6983922411789055262) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5346753968654129885) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2984949881764770718) ) ) {
          result[0] += -0.7215617742595976;
        } else {
          result[0] += -0.7106264464666274;
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6335148768279005305) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4850000000000000422) ) ) {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5963654365793032985) ) ) {
              if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.30555990092854729) ) ) {
                result[0] += -0.6671761603111557;
              } else {
                result[0] += -0.6922181848509361;
              }
            } else {
              if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.3365017545099452945) ) ) {
                result[0] += -0.6259170629995433;
              } else {
                result[0] += -0.6726237061298743;
              }
            }
          } else {
            result[0] += -0.6930091594306673;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.625000000000000111) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05527450000000001112) ) ) {
              if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.3671396943817185621) ) ) {
                result[0] += -0.601525365915916;
              } else {
                result[0] += -0.6361747506054635;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.02733191529475900369) ) ) {
                result[0] += -0.6189855840554092;
              } else {
                result[0] += -0.6733953683041011;
              }
            }
          } else {
            result[0] += -0.667094319807235;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7573813322891708166) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7244058930400819607) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7850000000000001421) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5850000000000000755) ) ) {
              result[0] += -0.617487211789561;
            } else {
              result[0] += -0.5668869882220865;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01404081753838025241) ) ) {
              result[0] += -0.6253689912742172;
            } else {
              result[0] += -0.6561389518851216;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2277026550521166759) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4014613332412060864) ) ) {
              result[0] += -0.6201621720252111;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01717013663891040279) ) ) {
                if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5861769322017787998) ) ) {
                  result[0] += -0.6082068563858317;
                } else {
                  result[0] += -0.5680439241134756;
                }
              } else {
                result[0] += -0.5658897211884983;
              }
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.005856183981500051421) ) ) {
              result[0] += -0.5865947671151088;
            } else {
              result[0] += -0.6174790339153404;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7801862323115579256) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7681116375709841071) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8150000000000000577) ) ) {
              result[0] += -0.5419029448572973;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002064500000000000363) ) ) {
                result[0] += -0.5681429001700705;
              } else {
                result[0] += -0.6265499671317101;
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6950000000000000622) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)183.5000000000000284) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
                  if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5561723236404935156) ) ) {
                    result[0] += -0.5706030093524604;
                  } else {
                    result[0] += -0.5277801033689723;
                  }
                } else {
                  result[0] += -0.57276866556554;
                }
              } else {
                result[0] += -0.5112366201915528;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.007169538957710850334) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2044121788183031196) ) ) {
                  result[0] += -0.5936297362589923;
                } else {
                  result[0] += -0.5450511436306507;
                }
              } else {
                result[0] += -0.5957441905295338;
              }
            }
          }
        } else {
          result[0] += -0.6092520189771481;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7583373477169182975) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8527347970710045244) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8319610793798176696) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7437931977386935678) ) ) {
            result[0] += -0.5243068851792905;
          } else {
            result[0] += -0.5629415615853376;
          }
        } else {
          if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.652066519749839979) ) ) {
            result[0] += -0.5072238533633764;
          } else {
            result[0] += -0.45572595119498027;
          }
        }
      } else {
        if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6618962921466065019) ) ) {
          result[0] += -0.4755547732228282;
        } else {
          result[0] += -0.43896145721284463;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7903724875956132934) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
          if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7982768737097182266) ) ) {
            result[0] += -0.40554064343131846;
          } else {
            result[0] += -0.3842876608163306;
          }
        } else {
          result[0] += -0.45617037398073385;
        }
      } else {
        result[0] += -0.36326784392430544;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7765936419225654141) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6335148768279005305) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5223131059347717597) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2984949881764770718) ) ) {
          result[0] += -0.12233913165373506;
        } else {
          result[0] += -0.11207962422613339;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4850000000000000422) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5963654365793032985) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3750000000000000555) ) ) {
              result[0] += -0.07336163821519018;
            } else {
              result[0] += -0.09446747966305966;
            }
          } else {
            if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.3222814422953775293) ) ) {
              result[0] += -0.024953653726954256;
            } else {
              result[0] += -0.06647574347357717;
            }
          }
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5963654365793032985) ) ) {
            result[0] += -0.1013525809542975;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5650000000000000577) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01427628620366660182) ) ) {
                result[0] += -0.027001541668394694;
              } else {
                result[0] += -0.07931306447262138;
              }
            } else {
              result[0] += -0.09042959749428875;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7092351592339261046) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.625000000000000111) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06261750000000000649) ) ) {
            result[0] += -0.022565606737358062;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5511625663567840672) ) ) {
              result[0] += -0.02872372298247199;
            } else {
              result[0] += -0.08035212635224842;
            }
          }
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6983922411789055262) ) ) {
            result[0] += -0.06894007181829195;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7850000000000001421) ) ) {
              result[0] += 0.0039932851353068136;
            } else {
              if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5268343718203251091) ) ) {
                result[0] += -0.07885972806563624;
              } else {
                result[0] += -0.02528110879348323;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7345825791375740765) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05022126916705735994) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)34.50000000000000711) ) ) {
              result[0] += -0.047495231247507944;
            } else {
              result[0] += -0.018725818438253928;
            }
          } else {
            result[0] += 0.00834356220459741;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8650000000000001021) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7526242738429421708) ) ) {
              result[0] += 0.008391257113131741;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05666650000000000159) ) ) {
                result[0] += 0.04925892041442769;
              } else {
                result[0] += 0.0007240306535902674;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7681116375709841071) ) ) {
                result[0] += -0.02225908355999855;
              } else {
                result[0] += 0.008874637751385294;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)33.50000000000000711) ) ) {
                result[0] += 0.04847193291981773;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.484933386852080317) ) ) {
                  result[0] += 0.010036577942457709;
                } else {
                  result[0] += -0.03092590209767992;
                }
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7362391952976967691) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8477341880899419424) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8259515021272411106) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001777500000000000217) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0009302321760857001865) ) ) {
              result[0] += 0.07137185167524825;
            } else {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8102659665622439222) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
                  result[0] += -0.015901131433183606;
                } else {
                  result[0] += 0.021011350178877897;
                }
              } else {
                result[0] += 0.04670456322410478;
              }
            }
          } else {
            if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6118109021115948343) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3905483718502500978) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)15.50000000000000178) ) ) {
                  result[0] += 0.013996527087956127;
                } else {
                  result[0] += 0.057939401922609504;
                }
              } else {
                result[0] += 0.004955369731665659;
              }
            } else {
              result[0] += 0.06836153882640067;
            }
          }
        } else {
          if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.652066519749839979) ) ) {
            result[0] += 0.0705194857929263;
          } else {
            result[0] += 0.11866427415482983;
          }
        }
      } else {
        if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6618962921466065019) ) ) {
          result[0] += 0.10343496183067928;
        } else {
          result[0] += 0.12957965112111486;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7528363226160118549) ) ) {
        result[0] += 0.16474440779766697;
      } else {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8320474816531334694) ) ) {
          result[0] += 0.18667210875083384;
        } else {
          result[0] += 0.20076782782842412;
        }
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7765936419225654141) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6335148768279005305) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5223131059347717597) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2984949881764770718) ) ) {
          result[0] += -0.11759954656257751;
        } else {
          result[0] += -0.10722325395130557;
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5650000000000000577) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5963654365793032985) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3750000000000000555) ) ) {
              result[0] += -0.0716091500237555;
            } else {
              result[0] += -0.09217810956841656;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.829025151058822677e-05) ) ) {
              result[0] += -0.010743177320749024;
            } else {
              result[0] += -0.05439019386259314;
            }
          }
        } else {
          result[0] += -0.09328351920385348;
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7092351592339261046) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.625000000000000111) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06261750000000000649) ) ) {
            result[0] += -0.0208441034265805;
          } else {
            result[0] += -0.054245011198443806;
          }
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6983922411789055262) ) ) {
            if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5220717678210960999) ) ) {
              result[0] += -0.05843335725059072;
            } else {
              result[0] += -0.07682791007399244;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7850000000000001421) ) ) {
              result[0] += 0.003666270310287813;
            } else {
              if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5268343718203251091) ) ) {
                result[0] += -0.0743909636141467;
              } else {
                result[0] += -0.023422734289432822;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7345825791375740765) ) ) {
          result[0] += -0.01944836712274446;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8650000000000001021) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7526242738429421708) ) ) {
              result[0] += 0.007678761669313542;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05666650000000000159) ) ) {
                result[0] += 0.04459294578370145;
              } else {
                result[0] += 0.0006651831405845458;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02068044101058480119) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)34.50000000000000711) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
                  result[0] += -0.0033951130372004636;
                } else {
                  result[0] += 0.060096211078000124;
                }
              } else {
                if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7681116375709841071) ) ) {
                  result[0] += -0.015363152599952017;
                } else {
                  result[0] += 0.024719297823404523;
                }
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.625000000000000111) ) ) {
                result[0] += -0.0019813009696069556;
              } else {
                result[0] += -0.04535146635050526;
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7362391952976967691) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8372609372025714425) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8102659665622439222) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001777500000000000217) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001595664027398050301) ) ) {
              result[0] += 0.05345202463796303;
            } else {
              result[0] += 0.0029656971859240984;
            }
          } else {
            if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5327503226426523186) ) ) {
              if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.4901385532776007525) ) ) {
                result[0] += 0.05421145855637562;
              } else {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5561410282412061479) ) ) {
                  result[0] += 0.028025287880733996;
                } else {
                  result[0] += -0.03220091397876925;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6950000000000000622) ) ) {
                result[0] += 0.0742684654970306;
              } else {
                result[0] += 0.03714794439784209;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6169663040644358665) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8050000000000001599) ) ) {
              result[0] += 0.06725606417763828;
            } else {
              result[0] += 0.02266834597867324;
            }
          } else {
            result[0] += 0.06879036108506152;
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8790620348987957522) ) ) {
          if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6618962921466065019) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.04446937286580055632) ) ) {
              result[0] += 0.09067829044673394;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04432750000000000579) ) ) {
                result[0] += 0.03693605013525989;
              } else {
                result[0] += 0.09201673538132842;
              }
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.294841568336650095) ) ) {
              result[0] += 0.06691321109917404;
            } else {
              result[0] += 0.11066100697098621;
            }
          }
        } else {
          result[0] += 0.11849852963199216;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7528363226160118549) ) ) {
        result[0] += 0.14688925414956971;
      } else {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8574845066336775901) ) ) {
          result[0] += 0.1680839793479245;
        } else {
          result[0] += 0.17961322339599098;
        }
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7765936419225654141) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5963654365793032985) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5002776212835359226) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2692173444281812933) ) ) {
          result[0] += -0.11391306002547258;
        } else {
          result[0] += -0.10451940310955757;
        }
      } else {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.2891310748198975267) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5346753968654129885) ) ) {
            result[0] += -0.08581570667084587;
          } else {
            result[0] += -0.059137599961599674;
          }
        } else {
          result[0] += -0.09226015229464432;
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6983922411789055262) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.545000000000000151) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01427628620366660182) ) ) {
            if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05035649857444463723) ) ) {
              result[0] += -0.03167460395241887;
            } else {
              result[0] += 0.008498122522717725;
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.0491948752242571466) ) ) {
              if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1878414568672973628) ) ) {
                result[0] += -0.04492218191718524;
              } else {
                result[0] += 0;
              }
            } else {
              result[0] += -0.05954402739485147;
            }
          }
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6562355446042661411) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002365000000000000294) ) ) {
              result[0] += -0.02941775543642672;
            } else {
              result[0] += -0.07774588725595784;
            }
          } else {
            if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5220717678210960999) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02957950000000000509) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)75.50000000000001421) ) ) {
                  result[0] += -0.04908070892774794;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.004712584303378800944) ) ) {
                    result[0] += -0.05132326360266661;
                  } else {
                    result[0] += 0.0022695086046135467;
                  }
                }
              } else {
                result[0] += -0.0712444884112193;
              }
            } else {
              result[0] += -0.07024892519226957;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7345825791375740765) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7250000000000000888) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5408295445477387942) ) ) {
              result[0] += -0.023673418601590463;
            } else {
              result[0] += 0.01903042489648179;
            }
          } else {
            result[0] += -0.027862348672646507;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8050000000000001599) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7526242738429421708) ) ) {
              result[0] += 0.0067196902282987995;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5792515097236182742) ) ) {
                result[0] += 0.01829737035432821;
              } else {
                result[0] += 0.07636287776686636;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3436166336222546414) ) ) {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7681116375709841071) ) ) {
                if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6358924549404499915) ) ) {
                  result[0] += -0.008903594382141496;
                } else {
                  result[0] += 0.03216238322171322;
                }
              } else {
                result[0] += 0.03018361675662444;
              }
            } else {
              result[0] += -0.01813195996297527;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7362391952976967691) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8477341880899419424) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8102659665622439222) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001777500000000000217) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001595664027398050301) ) ) {
              result[0] += 0.048524021047739625;
            } else {
              result[0] += 0.002718537074172279;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7273815826884423297) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)14.50000000000000178) ) ) {
                result[0] += 0.009429345321393718;
              } else {
                result[0] += 0.048978028596779744;
              }
            } else {
              result[0] += 0.005246272705207502;
            }
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3629614419597990138) ) ) {
            result[0] += 0.012581612519002588;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9808239647505231362) ) ) {
              result[0] += 0.0641700203273092;
            } else {
              result[0] += 0.02197234680412836;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5701039805841723318) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8050000000000001599) ) ) {
            result[0] += 0.09820642013157511;
          } else {
            result[0] += 0.054669754456589364;
          }
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9208995247894758984) ) ) {
            result[0] += 0.09816310155945471;
          } else {
            result[0] += 0.12447323428906586;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7903724875956132934) ) ) {
        if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7787197788111503982) ) ) {
          result[0] += 0.12316282248278757;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
            result[0] += 0.1456236928902151;
          } else {
            result[0] += 0.08952195450245024;
          }
        }
      } else {
        result[0] += 0.16202419611659039;
      }
    }
  }
}

