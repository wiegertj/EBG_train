
#include "header.h"

void predict_unit0(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7803782188884571536) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6589536398896721492) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5373923050813967928) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3310097201537537948) ) ) {
          result[0] += -0.7157849520574057;
        } else {
          result[0] += -0.7069057310875837;
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.346441672365271125) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5997198625535415939) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
              result[0] += -0.6598486639734353;
            } else {
              result[0] += -0.6870996587964647;
            }
          } else {
            result[0] += -0.6582590466778662;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5897839699588115492) ) ) {
            result[0] += -0.7048809728856531;
          } else {
            result[0] += -0.6881215713314418;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7068923547583354505) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6950000000000000622) ) ) {
          result[0] += -0.6457685555465047;
        } else {
          result[0] += -0.6761194583069795;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4850000000000000422) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.51855191273869361) ) ) {
            result[0] += -0.6160448999319021;
          } else {
            result[0] += -0.5782411657760269;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7423774199879572544) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8350000000000000755) ) ) {
              result[0] += -0.6289926573894572;
            } else {
              result[0] += -0.6515398767619185;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7471533970100503463) ) ) {
              result[0] += -0.618686407522787;
            } else {
              result[0] += -0.637880128762534;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9024131424400998469) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.849950209132393053) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7998185917227689234) ) ) {
          result[0] += -0.596740537043823;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6350000000000001199) ) ) {
            result[0] += -0.5484725042554985;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8194772770291881558) ) ) {
              result[0] += -0.5902045724117465;
            } else {
              result[0] += -0.5708653988558844;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6170632793331903843) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8889371422142716694) ) ) {
            result[0] += -0.5548621545020149;
          } else {
            result[0] += -0.5253373101966168;
          }
        } else {
          result[0] += -0.5251210192307761;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7881101830206976855) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6869614610244983988) ) ) {
          result[0] += -0.5116160326909471;
        } else {
          result[0] += -0.4911649251971003;
        }
      } else {
        result[0] += -0.47301240992594923;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7803782188884571536) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6589536398896721492) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5089951851639061831) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2727691064925280018) ) ) {
          result[0] += -0.08277581302771024;
        } else {
          result[0] += -0.07528700077408103;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5526627340532056509) ) ) {
            result[0] += -0.04524947324530927;
          } else {
            result[0] += -0.016180542118148556;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5798905718019149447) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2841175112709997674) ) ) {
              result[0] += -0.05356697990033544;
            } else {
              result[0] += -0.07067405823693564;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4384970621937981927) ) ) {
              result[0] += -0.03992550729927541;
            } else {
              result[0] += -0.05890931416078409;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7068923547583354505) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6950000000000000622) ) ) {
          result[0] += -0.013813980279227592;
        } else {
          result[0] += -0.04301928093690316;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4850000000000000422) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.51855191273869361) ) ) {
            result[0] += 0.014243417761720265;
          } else {
            result[0] += 0.04921727631206046;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7423774199879572544) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8350000000000000755) ) ) {
              result[0] += 0.0020834415559425933;
            } else {
              result[0] += -0.01932255172003466;
            }
          } else {
            result[0] += 0.008709824048398065;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9024131424400998469) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.849950209132393053) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8146542383663726294) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6750000000000001554) ) ) {
            result[0] += 0.05252325278112477;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9350000000000001643) ) ) {
              result[0] += 0.003690611063734655;
            } else {
              result[0] += 0.035809419545039155;
            }
          }
        } else {
          result[0] += 0.0577106351547463;
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6170632793331903843) ) ) {
          result[0] += 0.07661621306922445;
        } else {
          result[0] += 0.09709704322462903;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.736034375232267446) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6869614610244983988) ) ) {
          result[0] += 0.1090687559746272;
        } else {
          result[0] += 0.12314559212604172;
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8442376020855621999) ) ) {
          result[0] += 0.1332334612302564;
        } else {
          result[0] += 0.1444669295312089;
        }
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7803782188884571536) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6589536398896721492) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5373923050813967928) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3310097201537537948) ) ) {
          result[0] += -0.07991759488898664;
        } else {
          result[0] += -0.07103292818338404;
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.346441672365271125) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5997198625535415939) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
              result[0] += -0.02599130727034226;
            } else {
              result[0] += -0.05150975129580727;
            }
          } else {
            result[0] += -0.02397883895941476;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5897839699588115492) ) ) {
            result[0] += -0.06918860988825101;
          } else {
            result[0] += -0.05266510644729857;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7068923547583354505) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6950000000000000622) ) ) {
          result[0] += -0.013097737074288837;
        } else {
          result[0] += -0.04121116554261624;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4850000000000000422) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.51855191273869361) ) ) {
            result[0] += 0.013390468615829026;
          } else {
            result[0] += 0.04584421380849684;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7423774199879572544) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8350000000000000755) ) ) {
              result[0] += 0.0019653991535032;
            } else {
              result[0] += -0.018354623424875385;
            }
          } else {
            result[0] += 0.008198813841219222;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8889371422142716694) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.849950209132393053) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7998185917227689234) ) ) {
          result[0] += 0.029670115538286853;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6350000000000001199) ) ) {
            result[0] += 0.07207465115650541;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8194772770291881558) ) ) {
              result[0] += 0.03570625934675103;
            } else {
              result[0] += 0.05186781123819378;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6257603547126161514) ) ) {
          result[0] += 0.06569150488341707;
        } else {
          result[0] += 0.09010178359316229;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.736034375232267446) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6869614610244983988) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1368445000000000078) ) ) {
            result[0] += 0.0950994025504409;
          } else {
            result[0] += 0.11793343562592934;
          }
        } else {
          result[0] += 0.11160258376906584;
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8442376020855621999) ) ) {
          result[0] += 0.12228126363789699;
        } else {
          result[0] += 0.13239235758296297;
        }
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7803782188884571536) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6589536398896721492) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5089951851639061831) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2727691064925280018) ) ) {
          result[0] += -0.0785968330924225;
        } else {
          result[0] += -0.07098546808202136;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5526627340532056509) ) ) {
            result[0] += -0.04101577460536263;
          } else {
            result[0] += -0.014029467508030248;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5678833582154496629) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2719359470653786581) ) ) {
              result[0] += -0.04825607674052849;
            } else {
              result[0] += -0.06782242653810919;
            }
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.346441672365271125) ) ) {
              result[0] += -0.03424019812524457;
            } else {
              result[0] += -0.053667354237624754;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7068923547583354505) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6950000000000000622) ) ) {
          result[0] += -0.012416769104237143;
        } else {
          result[0] += -0.03948552444139454;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4850000000000000422) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.51855191273869361) ) ) {
            result[0] += 0.012592923661224002;
          } else {
            result[0] += 0.042786313613487524;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7423774199879572544) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8350000000000000755) ) ) {
              result[0] += 0.001854120087017786;
            } else {
              result[0] += -0.01743243754048618;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5511625663567840672) ) ) {
              result[0] += 0.016498266081501994;
            } else {
              result[0] += 0.0019295368130071817;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9024131424400998469) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.849950209132393053) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7998185917227689234) ) ) {
          result[0] += 0.027779886002654974;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8350000000000000755) ) ) {
            result[0] += 0.06567456977803829;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4241846244472362026) ) ) {
              result[0] += 0.020867180999527685;
            } else {
              result[0] += 0.044851424200539475;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6170632793331903843) ) ) {
          result[0] += 0.06576829318634579;
        } else {
          result[0] += 0.08278835267887652;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7881101830206976855) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6869614610244983988) ) ) {
          result[0] += 0.09321559898610586;
        } else {
          result[0] += 0.10797252583709963;
        }
      } else {
        result[0] += 0.12149749119617614;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7803782188884571536) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6491668737719177296) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5089951851639061831) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2727691064925280018) ) ) {
          result[0] += -0.07680081027622271;
        } else {
          result[0] += -0.0690798745024556;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5526627340532056509) ) ) {
            result[0] += -0.03935588904897027;
          } else {
            result[0] += -0.011463875245485507;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5640404622805753609) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2639245547049151042) ) ) {
              result[0] += -0.0466192174708888;
            } else {
              result[0] += -0.06590303056913342;
            }
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.346441672365271125) ) ) {
              result[0] += -0.03485861321207807;
            } else {
              result[0] += -0.053530106825510904;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7068923547583354505) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6950000000000000622) ) ) {
          result[0] += -0.014453128226040583;
        } else {
          result[0] += -0.03928155394540478;
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8350000000000000755) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4750000000000000333) ) ) {
            result[0] += 0.029293045472769657;
          } else {
            result[0] += 0.00821454622138643;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7423774199879572544) ) ) {
            result[0] += -0.016393630439015542;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7471533970100503463) ) ) {
              result[0] += 0.009484699061818555;
            } else {
              result[0] += -0.015834523769216284;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8889371422142716694) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8436766892707049381) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6750000000000001554) ) ) {
          result[0] += 0.04860884697642009;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8098966366947321083) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003180500000000000601) ) ) {
              result[0] += 0.02768271392350913;
            } else {
              result[0] += 0.0029487698106739294;
            }
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5914390031270969628) ) ) {
              result[0] += 0.026823467360739796;
            } else {
              result[0] += 0.048596573207575475;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6170632793331903843) ) ) {
          result[0] += 0.054190411979493244;
        } else {
          result[0] += 0.07589016770291815;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.736034375232267446) ) ) {
        result[0] += 0.08967735514453595;
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8502789422115718532) ) ) {
          result[0] += 0.10608371920567167;
        } else {
          result[0] += 0.11505193302664317;
        }
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7803782188884571536) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5897839699588115492) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4429728266653536473) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2642961365573822663) ) ) {
          result[0] += -0.07525659323955128;
        } else {
          result[0] += -0.06915584862529486;
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5414094579173949207) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2060867271409693446) ) ) {
              result[0] += -0.04285150171236977;
            } else {
              result[0] += -0.059601210948622065;
            }
          } else {
            result[0] += -0.036467558748803204;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5373923050813967928) ) ) {
            result[0] += -0.06795510416509436;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2850000000000000866) ) ) {
              result[0] += -0.025876436820117407;
            } else {
              result[0] += -0.05783243930287027;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7019812713501991652) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6850000000000001643) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
            result[0] += -0.004695403911858824;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002981500000000000209) ) ) {
              result[0] += -0.055248648395650815;
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.01414472145045409836) ) ) {
                result[0] += -0.014584292916033727;
              } else {
                result[0] += -0.031252777790189805;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6589536398896721492) ) ) {
            result[0] += -0.05262453675338281;
          } else {
            result[0] += -0.03612067302450207;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4850000000000000422) ) ) {
          result[0] += 0.024226287121189603;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7423774199879572544) ) ) {
            result[0] += -0.010772738395773883;
          } else {
            result[0] += 0.006949684018876884;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9024131424400998469) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.849950209132393053) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7998185917227689234) ) ) {
          result[0] += 0.02398963455686881;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8350000000000000755) ) ) {
            result[0] += 0.05824604366705909;
          } else {
            result[0] += 0.03634759892284119;
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6170632793331903843) ) ) {
          result[0] += 0.05730187227403502;
        } else {
          result[0] += 0.07199712010657106;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7946879440622868218) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6869614610244983988) ) ) {
          result[0] += 0.08124152813230799;
        } else {
          result[0] += 0.09512975063935424;
        }
      } else {
        result[0] += 0.10734898629012461;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.767064450770027606) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5897839699588115492) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4429728266653536473) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2642961365573822663) ) ) {
          result[0] += -0.0737739821098805;
        } else {
          result[0] += -0.06751978603899071;
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5414094579173949207) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2060867271409693446) ) ) {
              result[0] += -0.04128055232921694;
            } else {
              result[0] += -0.05787761785682385;
            }
          } else {
            result[0] += -0.03495973587268134;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5373923050813967928) ) ) {
            result[0] += -0.06627444417092555;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2850000000000000866) ) ) {
              result[0] += -0.024682045082413374;
            } else {
              result[0] += -0.05606337481198184;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7019812713501991652) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6850000000000001643) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
            result[0] += -0.004441035443165105;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002981500000000000209) ) ) {
              result[0] += -0.05342768670386267;
            } else {
              result[0] += -0.023129105827373642;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6491668737719177296) ) ) {
            result[0] += -0.05261193007185922;
          } else {
            result[0] += -0.03607422238809308;
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4470670498171123719) ) ) {
          result[0] += 0.012905339286266465;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7227354901093919759) ) ) {
            result[0] += -0.021510528550718944;
          } else {
            result[0] += -0.002108853532526537;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8889371422142716694) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8146542383663726294) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6750000000000001554) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03154350000000000903) ) ) {
            result[0] += 0.023956452441347247;
          } else {
            result[0] += 0.04393646388868118;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9350000000000001643) ) ) {
            result[0] += -0.0034742650751950514;
          } else {
            result[0] += 0.021915934582796778;
          }
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6887015468287406295) ) ) {
          result[0] += 0.045070142863897246;
        } else {
          result[0] += 0.06541678646965936;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7149490869166016394) ) ) {
        result[0] += 0.07691121835936128;
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8442376020855621999) ) ) {
          result[0] += 0.09334530946505602;
        } else {
          result[0] += 0.10287457150104617;
        }
      }
    }
  }
}

