
#include "header.h"

void predict_unit6(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5897839699588115492) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2727691064925280018) ) ) {
      result[0] += -0.05273346461919329;
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4604805625892014476) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
          result[0] += -0.01955014627793675;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005066500000000000691) ) ) {
            result[0] += -0.04345960273003156;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -0.022123423513958154;
            } else {
              result[0] += -0.04747097384013085;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2719359470653786581) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.051391296366422923) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02784750000000000072) ) ) {
              result[0] += -0.006785931608093335;
            } else {
              result[0] += 0.02028033946431972;
            }
          } else {
            result[0] += -0.03532966869868658;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.513213472667429782) ) ) {
            result[0] += -0.04218301751623363;
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3931461612883267454) ) ) {
              result[0] += -0.01216396769985266;
            } else {
              result[0] += -0.030033083575551837;
            }
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7881101830206976855) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.882048175975067239) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7277004308735181004) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4384970621937981927) ) ) {
            result[0] += 0.0019178529466944625;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6491668737719177296) ) ) {
              result[0] += -0.018121165276875868;
            } else {
              result[0] += -0.004725086560118059;
            }
          }
        } else {
          result[0] += 0.003799087196346809;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9820324513815327228) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9350000000000001643) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6869614610244983988) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8650000000000001021) ) ) {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.5708656043828381765) ) ) {
                  result[0] += -0.004178836936964109;
                } else {
                  result[0] += 0.0178640064889447;
                }
              } else {
                result[0] += -0.012978855760177793;
              }
            } else {
              result[0] += 0.023117440141136838;
            }
          } else {
            result[0] += -0.0071273792464553965;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9450000000000000622) ) ) {
            result[0] += 0.05127213507489222;
          } else {
            result[0] += 0.01018498691255204;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8622565274156744897) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
          result[0] += 0.041861641843805586;
        } else {
          result[0] += 0.01823456817767466;
        }
      } else {
        result[0] += 0.05431404563009329;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5640404622805753609) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2727691064925280018) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1313656708211964064) ) ) {
        result[0] += -0.05728818835355823;
      } else {
        result[0] += -0.045396888445635816;
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02190750000000000336) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += -0.013359041886549345;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004675500000000000836) ) ) {
              result[0] += -0.03680309636048919;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3881589449934809699) ) ) {
                result[0] += -0.035210129512427156;
              } else {
                result[0] += -0.014098446555745948;
              }
            }
          }
        } else {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1866571336964587269) ) ) {
            result[0] += -0.028955871207874167;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5345516166834171079) ) ) {
              result[0] += 0.030404502489321632;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4681209169133345172) ) ) {
                result[0] += -0.018548408043872828;
              } else {
                result[0] += 0.0061937146355653585;
              }
            }
          }
        }
      } else {
        result[0] += -0.03770023195347769;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7881101830206976855) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8146542383663726294) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6972829280248278305) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8950000000000001288) ) ) {
            result[0] += -0.005228098353395457;
          } else {
            result[0] += -0.021598475153366336;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += 0.02043717470042148;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0005635000000000000902) ) ) {
              result[0] += -0.015442833175637431;
            } else {
              result[0] += 0.0008949942241626795;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6616950502373190046) ) ) {
          result[0] += 0.008010906213160439;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += 0.03711801136587974;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9550000000000000711) ) ) {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7149490869166016394) ) ) {
                result[0] += 0.01127308583768106;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9150000000000001465) ) ) {
                  result[0] += 0.031015352444017687;
                } else {
                  result[0] += 0.010249649546086639;
                }
              }
            } else {
              result[0] += -0.007376885348863246;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8622565274156744897) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9108935748982122105) ) ) {
          result[0] += 0.03909862657999457;
        } else {
          result[0] += 0.008943605182720915;
        }
      } else {
        result[0] += 0.053815572042675335;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5640404622805753609) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2727691064925280018) ) ) {
      result[0] += -0.0519540203002857;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02962100000000000496) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += -0.012751222131828445;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004675500000000000836) ) ) {
              result[0] += -0.03591583291569363;
            } else {
              result[0] += -0.01865921990162063;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4299451362101003871) ) ) {
            result[0] += -0.018963728896184084;
          } else {
            result[0] += 0.007941288018255402;
          }
        }
      } else {
        result[0] += -0.03679808165690618;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7881101830206976855) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8664403834689663464) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7068923547583354505) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4336191825501565789) ) ) {
            result[0] += -0.00040356149975832715;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6105085814565057722) ) ) {
              result[0] += -0.025537145147657737;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02654500000000000262) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8550000000000000933) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7392963230402010977) ) ) {
                    result[0] += -0.005339758562894603;
                  } else {
                    result[0] += 0.029342702487129217;
                  }
                } else {
                  result[0] += -0.014216226969186634;
                }
              } else {
                result[0] += -0.028922569361964464;
              }
            }
          }
        } else {
          result[0] += 0.0024673906130050407;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9820324513815327228) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8108141154020102048) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6818507002937542749) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8650000000000001021) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9465473169870071146) ) ) {
                  result[0] += 0.00821545772635015;
                } else {
                  result[0] += 0.02897362498093573;
                }
              } else {
                result[0] += -0.01622947592245453;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9150000000000001465) ) ) {
                result[0] += 0.02213178994962969;
              } else {
                result[0] += 0.00047973701114883163;
              }
            }
          } else {
            result[0] += 0.037434991882809895;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9450000000000000622) ) ) {
            result[0] += 0.049760294869814266;
          } else {
            result[0] += 0.00960306470181875;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8622565274156744897) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
          result[0] += 0.04001806855831931;
        } else {
          result[0] += 0.01644614048960725;
        }
      } else {
        result[0] += 0.053316961239065465;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5373923050813967928) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2642961365573822663) ) ) {
      result[0] += -0.05203065601893212;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01401950000000000245) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += -0.014271092413777801;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7346206940954774778) ) ) {
              result[0] += -0.033048951441718245;
            } else {
              result[0] += 0.0021129275881325424;
            }
          }
        } else {
          result[0] += -0.007921518956468292;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
          result[0] += -0.017815394107236947;
        } else {
          result[0] += -0.044084471673226704;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7881101830206976855) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8146542383663726294) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6684601612579991192) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04928150000000000586) ) ) {
              result[0] += 0.010961954654832795;
            } else {
              result[0] += -0.009999711613631137;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4650000000000000244) ) ) {
                result[0] += -0.0111198274682825;
              } else {
                result[0] += 0.014351848992995603;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0007985000000000000561) ) ) {
                result[0] += -0.03744569762235376;
              } else {
                result[0] += -0.010677437730633371;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3749834515475459207) ) ) {
            result[0] += 0.01616081499695571;
          } else {
            result[0] += -0.0005406379195416705;
          }
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9024131424400998469) ) ) {
          result[0] += 0.006482891010107303;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9820324513815327228) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9150000000000001465) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6705625264070352864) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4167392046828135022) ) ) {
                  result[0] += 0.016518227619793636;
                } else {
                  result[0] += -0.006190305357315276;
                }
              } else {
                result[0] += 0.03321516546761707;
              }
            } else {
              result[0] += -0.00015145666164789262;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9450000000000000622) ) ) {
              result[0] += 0.04881307557744624;
            } else {
              result[0] += 0.009133448697844309;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8622565274156744897) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
          result[0] += 0.03907356184360257;
        } else {
          result[0] += 0.015736422989739495;
        }
      } else {
        result[0] += 0.05281691046183793;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5373923050813967928) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2727691064925280018) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1313656708211964064) ) ) {
        result[0] += -0.056867097234056536;
      } else {
        result[0] += -0.043219666905133035;
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01401950000000000245) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += -0.01245727865371506;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7346206940954774778) ) ) {
              result[0] += -0.032023085597726854;
            } else {
              result[0] += 0.0038061130213910143;
            }
          }
        } else {
          result[0] += -0.007399939483318805;
        }
      } else {
        result[0] += -0.037188494041655515;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7881101830206976855) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8098966366947321083) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6589536398896721492) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6750000000000001554) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08162500000000001699) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6002093903220061533) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
                  result[0] += 0.005956150978045731;
                } else {
                  result[0] += -0.00983409819872548;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5845852065869253655) ) ) {
                  result[0] += 5.354341141029606e-05;
                } else {
                  result[0] += 0.038145419756037795;
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2650000000000000688) ) ) {
                result[0] += 0;
              } else {
                result[0] += -0.03661836238125479;
              }
            }
          } else {
            result[0] += -0.01628086179063257;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5350000000000001421) ) ) {
            result[0] += 0.005811297427458922;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.089430082328138649) ) ) {
              result[0] += -0.0009131121678991167;
            } else {
              result[0] += -0.013526901956433465;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6616950502373190046) ) ) {
          result[0] += 0.006598305052501664;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += 0.034497094548290676;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9550000000000000711) ) ) {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7149490869166016394) ) ) {
                result[0] += 0.009362934768338134;
              } else {
                result[0] += 0.023421825259715146;
              }
            } else {
              result[0] += -0.007529640335152682;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8622565274156744897) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9108935748982122105) ) ) {
          result[0] += 0.036286531057736986;
        } else {
          result[0] += 0.006766576532174438;
        }
      } else {
        result[0] += 0.05231421156259167;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5205725315881680748) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2642961365573822663) ) ) {
      result[0] += -0.05125083365513871;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3881589449934809699) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05500000000000000722) ) ) {
            result[0] += -0.0001858694313672971;
          } else {
            result[0] += -0.031619078317416296;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1850000000000000255) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1645254211347557949) ) ) {
              result[0] += 0.027941960612389155;
            } else {
              result[0] += -0.006550745723778778;
            }
          } else {
            result[0] += -0.01650933824740972;
          }
        }
      } else {
        result[0] += -0.03617450881516068;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7946879440622868218) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8146542383663726294) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6828655451798409937) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.25500000000000006) ) ) {
            result[0] += 0.012333723128250063;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08162500000000001699) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8254037945979900703) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5250000000000001332) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5664498681879840403) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6343753668631807452) ) ) {
                      result[0] += -0.00798337050342228;
                    } else {
                      result[0] += 0.013524684095446734;
                    }
                  } else {
                    result[0] += 0.030138472042284866;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5798905718019149447) ) ) {
                    result[0] += -0.024045598984074053;
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003246500000000000687) ) ) {
                      result[0] += -0.012602151094128253;
                    } else {
                      result[0] += 0;
                    }
                  }
                }
              } else {
                result[0] += -0.033922841382646014;
              }
            } else {
              result[0] += -0.026689497818059557;
            }
          }
        } else {
          result[0] += 0.00043290000456506047;
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6616950502373190046) ) ) {
          result[0] += 0.0064005765282206676;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += 0.033684857828420046;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9450000000000000622) ) ) {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7149490869166016394) ) ) {
                result[0] += 0.009023484159504255;
              } else {
                result[0] += 0.02393591252304137;
              }
            } else {
              result[0] += -0.00460103146049981;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8622565274156744897) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9108935748982122105) ) ) {
          result[0] += 0.03681823346897745;
        } else {
          result[0] += 0.006016216242313323;
        }
      } else {
        result[0] += 0.05180771275795716;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5089951851639061831) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2296243883448841061) ) ) {
      result[0] += -0.05271595328870475;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3881589449934809699) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.29500000000000004) ) ) {
              result[0] += -0.0199493228863117;
            } else {
              result[0] += 0.01674040237263015;
            }
          } else {
            result[0] += -0.03663312866347323;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2682576517146198491) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4429728266653536473) ) ) {
              result[0] += -0.01353618529731702;
            } else {
              result[0] += 0.0049597477458042695;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4806185349221548386) ) ) {
              result[0] += -0.047367779297602226;
            } else {
              result[0] += -0.005348680434595794;
            }
          }
        }
      } else {
        result[0] += -0.03907715981232817;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7946879440622868218) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8098966366947321083) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.626047238333421352) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3509968631889735513) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6550000000000001377) ) ) {
              result[0] += -0.002882844558639875;
            } else {
              result[0] += -0.028952078601650597;
            }
          } else {
            result[0] += -0.0186058197507971;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4750000000000000333) ) ) {
            result[0] += 0.005869365381516012;
          } else {
            result[0] += -0.0019074108598254927;
          }
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9024131424400998469) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.5708656043828381765) ) ) {
            result[0] += -0.008935839135842236;
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3245459035486191746) ) ) {
              result[0] += 0.021184066126017868;
            } else {
              result[0] += 0.004446772830246787;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9803163499134560643) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9350000000000001643) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6669784622613067482) ) ) {
                result[0] += 0.01278351434787851;
              } else {
                result[0] += 0.028787078859845924;
              }
            } else {
              result[0] += -0.010356853778737556;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9450000000000000622) ) ) {
              result[0] += 0.046493824811577364;
            } else {
              result[0] += 0.0063405198651135;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8622565274156744897) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9108935748982122105) ) ) {
          result[0] += 0.035873399989483294;
        } else {
          result[0] += 0.005709732786584138;
        }
      } else {
        result[0] += 0.051296339518374916;
      }
    }
  }
}

