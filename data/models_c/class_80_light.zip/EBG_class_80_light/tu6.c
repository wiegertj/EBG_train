
#include "header.h"

void predict_unit6(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2037479557077091219) ) ) {
    result[0] += -0.0980478292108554;
  } else {
    if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.922904192998838524) ) ) {
      result[0] += 1.9553840504787416e-05;
    } else {
      result[0] += 0.10345089374486896;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8922896786758797161) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1316283809119187798) ) ) {
      result[0] += -0.11416106273229858;
    } else {
      result[0] += -0.006433244981821358;
    }
  } else {
    result[0] += 0.03319448142533217;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.922904192998838524) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1316283809119187798) ) ) {
      result[0] += -0.11343972515700969;
    } else {
      result[0] += -0.0005822101867101783;
    }
  } else {
    result[0] += 0.10077119035637513;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5981753503490724322) ) ) {
    result[0] += -0.029995656154535026;
  } else {
    if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.922904192998838524) ) ) {
      result[0] += 0.005743562866791216;
    } else {
      result[0] += 0.09860306598725171;
    }
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1316283809119187798) ) ) {
    result[0] += -0.11245398420512752;
  } else {
    if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.922904192998838524) ) ) {
      result[0] += -0.0002727524085900384;
    } else {
      result[0] += 0.09630052601582414;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7569354545110485999) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1316283809119187798) ) ) {
      result[0] += -0.111607216360262;
    } else {
      result[0] += -0.011648244531915238;
    }
  } else {
    result[0] += 0.01421356083993464;
  }
}

