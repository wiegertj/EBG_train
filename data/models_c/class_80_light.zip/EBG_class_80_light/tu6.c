
#include "header.h"

void predict_unit6(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6617384408086778302) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3944417379768624943) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2194568116175419636) ) ) {
        result[0] += -0.0841392241827966;
      } else {
        result[0] += -0.0638691142421857;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5346753968654129885) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3750000000000000555) ) ) {
          if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.2031267017715874812) ) ) {
            if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.1400469129038929561) ) ) {
              result[0] += -0.043369705426991485;
            } else {
              result[0] += 0.02726442751001456;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1945214781124514347) ) ) {
              result[0] += -0.048654644227183436;
            } else {
              result[0] += -0.016046809201362047;
            }
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4435662465829146028) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4093335132160804135) ) ) {
              result[0] += -0.06102256610252563;
            } else {
              result[0] += 0.028080965539745616;
            }
          } else {
            result[0] += -0.06498194146907188;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4850000000000000422) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9808239647505231362) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6852090990703517681) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2450000000000000233) ) ) {
                result[0] += 0.02424387294165017;
              } else {
                result[0] += -0.014606447521038925;
              }
            } else {
              result[0] += 0.030015960267292405;
            }
          } else {
            result[0] += -0.04702631935611777;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04645850000000000674) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005704000000000000736) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8158067323869347964) ) ) {
                result[0] += -0.03554072538704363;
              } else {
                result[0] += 0.009500709366536034;
              }
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6059238433417085679) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.08835747683243963535) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4795364038944723295) ) ) {
                    result[0] += -0.003135274990596796;
                  } else {
                    result[0] += -0.05952883550941299;
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3950000000000000733) ) ) {
                    result[0] += -0.010165661782306018;
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.009224000000000001295) ) ) {
                      result[0] += 0.010044989333414148;
                    } else {
                      result[0] += 0.08494908408265829;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.009725260822347701548) ) ) {
                  result[0] += -0.06344089607914936;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4650000000000000244) ) ) {
                    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.358279098130949436) ) ) {
                      result[0] += 0.001769222301327682;
                    } else {
                      result[0] += -0.053986857790064575;
                    }
                  } else {
                    result[0] += 0.02912850915967552;
                  }
                }
              }
            }
          } else {
            result[0] += -0.05955194452894498;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7341068085871017557) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8624925176218337652) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7681116375709841071) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4750000000000000333) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4450000000000000622) ) ) {
              result[0] += 8.61924906754943e-05;
            } else {
              result[0] += 0.03662758540894172;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.075834742120705068) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8932219825431284566) ) ) {
                result[0] += -0.007893248864469918;
              } else {
                if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7244058930400819607) ) ) {
                  result[0] += 0.006910770233788544;
                } else {
                  result[0] += 0.060057474307913535;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
                result[0] += -0.04701286285341381;
              } else {
                result[0] += 0;
              }
            }
          }
        } else {
          result[0] += 0.008179749893588972;
        }
      } else {
        if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7362391952976967691) ) ) {
          result[0] += 0.019544390726576717;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8950000000000001288) ) ) {
            result[0] += 0.04108440981776641;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
              result[0] += 0.038304791840260484;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)53.50000000000000711) ) ) {
                result[0] += -0.03850718013668358;
              } else {
                result[0] += 0.015785568344157622;
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8747476225597411448) ) ) {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7903724875956132934) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9550000000000000711) ) ) {
            result[0] += 0.053889147913501585;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03028402022170490274) ) ) {
              result[0] += 0.04300675682450207;
            } else {
              result[0] += -0.018885956104856338;
            }
          }
        } else {
          result[0] += 0.06683596741074274;
        }
      } else {
        result[0] += 0.08703053829630289;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6617384408086778302) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3944417379768624943) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2194568116175419636) ) ) {
        result[0] += -0.08349468622117301;
      } else {
        result[0] += -0.06205327253064539;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5346753968654129885) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3750000000000000555) ) ) {
          if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.2031267017715874812) ) ) {
            if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.1400469129038929561) ) ) {
              result[0] += -0.04148658313386842;
            } else {
              result[0] += 0.02450177313532467;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3722591415898431344) ) ) {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.463826699984686508) ) ) {
                result[0] += -0.05873758879163514;
              } else {
                result[0] += -0.029600888040422286;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6411603019421380223) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6574014915075377941) ) ) {
                  result[0] += -0.016237046184761142;
                } else {
                  result[0] += 0.05410539323009281;
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03861350000000000199) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8932219825431284566) ) ) {
                    result[0] += -0.0496581354806719;
                  } else {
                    result[0] += 0.016615299109745345;
                  }
                } else {
                  result[0] += -0.0684904468441338;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4435662465829146028) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4093335132160804135) ) ) {
              result[0] += -0.0591894078776415;
            } else {
              result[0] += 0.025374133003724476;
            }
          } else {
            result[0] += -0.06309368227888065;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4850000000000000422) ) ) {
          result[0] += -0.010195468924616374;
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)289.5000000000000568) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004107500000000000907) ) ) {
              result[0] += -0.030396602538518332;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6059238433417085679) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5705607401507538645) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01382944002431570236) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)46.50000000000000711) ) ) {
                      result[0] += 0.06007039417370534;
                    } else {
                      result[0] += -0.004059151263453722;
                    }
                  } else {
                    result[0] += -0.03863273916368461;
                  }
                } else {
                  result[0] += 0.04599157658206274;
                }
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)26.50000000000000355) ) ) {
                  result[0] += 0.019911865893536763;
                } else {
                  result[0] += -0.039497368736857726;
                }
              }
            }
          } else {
            result[0] += -0.046987305877170434;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7528363226160118549) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6950092425598650703) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7765936419225654141) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4750000000000000333) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4450000000000000622) ) ) {
              result[0] += 0;
            } else {
              result[0] += 0.03164819420858467;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.075834742120705068) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8932219825431284566) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5681735652491761712) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4305868785182659919) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6323035877889447987) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.09221743570336575491) ) ) {
                        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5400401558291457738) ) ) {
                          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7250000000000000888) ) ) {
                            result[0] += -0.022698027521283578;
                          } else {
                            result[0] += 0.006001752102377946;
                          }
                        } else {
                          result[0] += -0.03121015369607015;
                        }
                      } else {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2157356523887877797) ) ) {
                          result[0] += 0.03246306371170631;
                        } else {
                          result[0] += -0.014797646157712572;
                        }
                      }
                    } else {
                      result[0] += -0.0323037241800004;
                    }
                  } else {
                    result[0] += 0.025665815575908867;
                  }
                } else {
                  result[0] += -0.021892572699309925;
                }
              } else {
                result[0] += 0.027566606508589664;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
                result[0] += -0.045744720886399866;
              } else {
                result[0] += 0.009658343750154844;
              }
            }
          }
        } else {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.13900392495124092) ) ) {
            result[0] += 0.04237791098116205;
          } else {
            result[0] += 0.00803937096356359;
          }
        }
      } else {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6310147675908469589) ) ) {
          result[0] += 0.007317575667668795;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.04687247517649542;
          } else {
            result[0] += 0.026147478758508706;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8859917940727212171) ) ) {
        result[0] += 0.06004221585794125;
      } else {
        result[0] += 0.08679383905232665;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6335148768279005305) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3944417379768624943) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2194568116175419636) ) ) {
        result[0] += -0.0828583924385309;
      } else {
        result[0] += -0.0602182698671776;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5346753968654129885) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3750000000000000555) ) ) {
          if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.1946989117759076737) ) ) {
            result[0] += 0.013889221539652188;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3722591415898431344) ) ) {
              result[0] += -0.04030115414430021;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6411603019421380223) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6574014915075377941) ) ) {
                  result[0] += -0.018463542028151887;
                } else {
                  result[0] += 0.05358841465796095;
                }
              } else {
                result[0] += -0.027684577499909168;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5223131059347717597) ) ) {
            result[0] += -0.06374189040943402;
          } else {
            result[0] += -0.026722833536663475;
          }
        }
      } else {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.3267457399996808731) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9808239647505231362) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02957950000000000509) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.0442771331626926e-05) ) ) {
                result[0] += 0;
              } else {
                result[0] += -0.030546882782341078;
              }
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.07409325127878772788) ) ) {
                result[0] += -0.018093930136959716;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08561450000000002392) ) ) {
                  result[0] += 0.058460762222329536;
                } else {
                  result[0] += 0;
                }
              }
            }
          } else {
            result[0] += -0.04801775577565813;
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)137.5000000000000284) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002343500000000000531) ) ) {
              result[0] += -0.03806240876635612;
            } else {
              result[0] += -0.0074660589581332995;
            }
          } else {
            result[0] += -0.045594062175731045;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7528363226160118549) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8624925176218337652) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7396101162463498691) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2850000000000000866) ) ) {
            result[0] += 0.026032356438516164;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06940500000000000835) ) ) {
              if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.4595442724754187358) ) ) {
                if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.4905089628645931121) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.625000000000000111) ) ) {
                    if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.08835747683243963535) ) ) {
                      if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.294841568336650095) ) ) {
                        result[0] += 0.003379646998237244;
                      } else {
                        result[0] += -0.04545057000184724;
                      }
                    } else {
                      result[0] += 0.021988664985345675;
                    }
                  } else {
                    result[0] += -0.01831754193608952;
                  }
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)43.50000000000000711) ) ) {
                    result[0] += -0.006761100333250873;
                  } else {
                    result[0] += 0.026695057125896832;
                  }
                }
              } else {
                result[0] += -0.012696940675875377;
              }
            } else {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7092351592339261046) ) ) {
                result[0] += -0.04679800081285839;
              } else {
                result[0] += -0.0006339139875354761;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += 0.03296504569952855;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0005715000000000000678) ) ) {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7810696647307608931) ) ) {
                result[0] += 0.008331159426799843;
              } else {
                result[0] += -0.04754076210084282;
              }
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8168185667587940513) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1272695000000000076) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8786021260481619022) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07890600000000001779) ) ) {
                      result[0] += 0.005053148097644036;
                    } else {
                      result[0] += 0.03142887039465882;
                    }
                  } else {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7801862323115579256) ) ) {
                      result[0] += 0.052202488877611114;
                    } else {
                      result[0] += 0.004005736119866178;
                    }
                  }
                } else {
                  result[0] += -0.016392617068220705;
                }
              } else {
                result[0] += -0.02109350167012904;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6859815657019552315) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
            result[0] += 0.020302435346767744;
          } else {
            result[0] += -0.012465441467673383;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.05947323476771406;
          } else {
            result[0] += 0.029982708393231028;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.891804912653853199) ) ) {
        result[0] += 0.05830867120055864;
      } else {
        result[0] += 0.0862551817478325;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6335148768279005305) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3944417379768624943) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2194568116175419636) ) ) {
        result[0] += -0.08222581815062507;
      } else {
        result[0] += -0.05836415447697837;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5346753968654129885) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3750000000000000555) ) ) {
          if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.2031267017715874812) ) ) {
            result[0] += 0.005229106838208511;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1945214781124514347) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.7835979262278595092) ) ) {
                result[0] += 0.006290271548226288;
              } else {
                result[0] += -0.046499472735016735;
              }
            } else {
              result[0] += -0.01246474365016705;
            }
          }
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5223131059347717597) ) ) {
            result[0] += -0.061918446329448665;
          } else {
            result[0] += -0.02510291728020341;
          }
        }
      } else {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.3267457399996808731) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9808239647505231362) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02957950000000000509) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01947359100052300368) ) ) {
                result[0] += -0.006028185376844983;
              } else {
                result[0] += -0.04406052160632217;
              }
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.07409325127878772788) ) ) {
                result[0] += -0.016829245715507393;
              } else {
                result[0] += 0.030973818664413545;
              }
            }
          } else {
            result[0] += -0.04568606145435553;
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)137.5000000000000284) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002343500000000000531) ) ) {
              result[0] += -0.036029328918783694;
            } else {
              result[0] += -0.006885915799484936;
            }
          } else {
            result[0] += -0.04333186316999339;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7528363226160118549) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6888851207273123389) ) ) {
        if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5903541535616282365) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8950000000000001288) ) ) {
            result[0] += -0.0011885044985053396;
          } else {
            if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5509197063102150294) ) ) {
              result[0] += -0.04849526464149865;
            } else {
              result[0] += -0.013851594027763689;
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8550000000000000933) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6532207681155780543) ) ) {
              result[0] += 0.016389048657457845;
            } else {
              result[0] += 0.056540501621475996;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7801862323115579256) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.92531357823258642) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001777500000000000217) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6106563961814815977) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00108550000000000031) ) ) {
                      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)63.50000000000000711) ) ) {
                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.007686869795986750291) ) ) {
                          result[0] += 0.006809251488949741;
                        } else {
                          result[0] += 0.05231068855445042;
                        }
                      } else {
                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.005700571204593800866) ) ) {
                          result[0] += 0.008382824636867172;
                        } else {
                          result[0] += -0.03294474198975737;
                        }
                      }
                    } else {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01359922590329290179) ) ) {
                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.004869514427752750889) ) ) {
                          result[0] += -0.025781665558495915;
                        } else {
                          result[0] += 0.035782794251370834;
                        }
                      } else {
                        result[0] += -0.03447292655007749;
                      }
                    }
                  } else {
                    result[0] += -0.04605052655878301;
                  }
                } else {
                  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7485911169215263561) ) ) {
                    result[0] += 0.03873905420692125;
                  } else {
                    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7810696647307608931) ) ) {
                      result[0] += -0.012392820396217578;
                    } else {
                      result[0] += 0.011233502194397608;
                    }
                  }
                }
              } else {
                result[0] += 0.04312580624129784;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02135706956284560629) ) ) {
                result[0] += 0;
              } else {
                result[0] += -0.040231522179036104;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7583373477169182975) ) ) {
          result[0] += 0.018461607023737905;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9150000000000001465) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4072039767958984813) ) ) {
              result[0] += 0.06250721912246308;
            } else {
              result[0] += 0.03236267337155796;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
              result[0] += 0.0416170716029817;
            } else {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.969944568423787401) ) ) {
                result[0] += 0.0159783970467936;
              } else {
                result[0] += -0.040834932763890865;
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8859917940727212171) ) ) {
        result[0] += 0.055564740340777824;
      } else {
        result[0] += 0.0849687051628591;
      }
    }
  }
}

