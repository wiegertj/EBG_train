
#include "header.h"

void predict_unit3(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.647707183477113424) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4245462180442349243) ) ) {
      result[0] += -0.10532414303129946;
    } else {
      result[0] += -0.0067806779897266085;
    }
  } else {
    result[0] += 0.08504789134378331;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7364779706049739971) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4197538874958940958) ) ) {
      result[0] += -0.1030720501095764;
    } else {
      result[0] += -0.0015881752298511742;
    }
  } else {
    result[0] += 0.10454098867493548;
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8249420069443514913) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.395269004515127198) ) ) {
      result[0] += -0.10288168830073954;
    } else {
      result[0] += -0.001630301882675396;
    }
  } else {
    result[0] += 0.10450846451951004;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7640480773571086681) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4467417962507087004) ) ) {
      result[0] += -0.09434331846007642;
    } else {
      result[0] += 0.00038600820054874614;
    }
  } else {
    result[0] += 0.1035877142886998;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.798343720186302952) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.395269004515127198) ) ) {
      result[0] += -0.09758846255558933;
    } else {
      result[0] += -0.00017749292284215053;
    }
  } else {
    result[0] += 0.10701012008845777;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.798343720186302952) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3002165654826406405) ) ) {
      result[0] += -0.10584990953080284;
    } else {
      result[0] += -0.0018490640797331622;
    }
  } else {
    result[0] += 0.10415360029367526;
  }
}

