
#include "header.h"

void predict_unit3(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7277004308735181004) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5089951851639061831) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2727691064925280018) ) ) {
        result[0] += -0.06102202275459157;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += -0.03981088852958129;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004774500000000000098) ) ) {
            result[0] += -0.056385787589962814;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -0.041867875515380314;
            } else {
              result[0] += -0.05754590382910455;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.626047238333421352) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
          result[0] += -0.008583689438087823;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5947982060815187877) ) ) {
              result[0] += -0.023981547069768436;
            } else {
              result[0] += 0.009483304222682417;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004078000000000000895) ) ) {
              result[0] += -0.043216446859182175;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5798905718019149447) ) ) {
                result[0] += -0.038896441731174486;
              } else {
                result[0] += -0.019760864054863096;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7050000000000000711) ) ) {
          result[0] += -0.005006242977068689;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7068923547583354505) ) ) {
            result[0] += -0.022560476111962182;
          } else {
            result[0] += -0.002333931435172986;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6818507002937542749) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.849950209132393053) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7803782188884571536) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8450000000000000844) ) ) {
            result[0] += 0.011078808414801413;
          } else {
            result[0] += -0.002980357553350438;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.07540250000000001118) ) ) {
            result[0] += 0.012469310992893648;
          } else {
            result[0] += 0.03151962690535755;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9465473169870071146) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6869304497989950908) ) ) {
            result[0] += 0.02575593720807756;
          } else {
            result[0] += 0.041546133020030296;
          }
        } else {
          result[0] += 0.046970033691119815;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8442376020855621999) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.736034375232267446) ) ) {
          result[0] += 0.044543555980448526;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += 0.057092040500589976;
          } else {
            result[0] += 0.03753623320811846;
          }
        }
      } else {
        result[0] += 0.06778915640858232;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7277004308735181004) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5089951851639061831) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2727691064925280018) ) ) {
        result[0] += -0.060519531287943934;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += -0.03872986363402786;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004774500000000000098) ) ) {
            result[0] += -0.05559806975831926;
          } else {
            result[0] += -0.04433789090190631;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6589536398896721492) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.25500000000000006) ) ) {
          result[0] += -0.001653491550163579;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5678833582154496629) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2639245547049151042) ) ) {
              result[0] += -0.01738604551668289;
            } else {
              result[0] += -0.04170768394552963;
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7350000000000000977) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08162500000000001699) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6103182300228128243) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
                    result[0] += 0;
                  } else {
                    result[0] += -0.022826995442751997;
                  }
                } else {
                  result[0] += 0.006020351553944262;
                }
              } else {
                result[0] += -0.04333773207938017;
              }
            } else {
              result[0] += -0.034165008951783975;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4336191825501565789) ) ) {
          result[0] += 0.006761964768310074;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7068923547583354505) ) ) {
            result[0] += -0.01630622342156381;
          } else {
            result[0] += -0.0032336371147425953;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6818507002937542749) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8664403834689663464) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7889021474406031631) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4305892766871174948) ) ) {
            result[0] += 0.020711683210188896;
          } else {
            result[0] += 0.0011435820851900687;
          }
        } else {
          result[0] += 0.015352064835578348;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9465473169870071146) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6869304497989950908) ) ) {
            result[0] += 0.02593783927796619;
          } else {
            result[0] += 0.04526979329604302;
          }
        } else {
          result[0] += 0.045191218751340294;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8442376020855621999) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.736034375232267446) ) ) {
          result[0] += 0.042904772068034294;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += 0.055630118306075775;
          } else {
            result[0] += 0.03619685766838108;
          }
        }
      } else {
        result[0] += 0.06673447223861176;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7277004308735181004) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4806185349221548386) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2642961365573822663) ) ) {
        result[0] += -0.06021657943903599;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += -0.03923773436752278;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005066500000000000691) ) ) {
            result[0] += -0.055890520084257864;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -0.04120020147971169;
            } else {
              result[0] += -0.057633957920174506;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6213841400436609375) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4850000000000000422) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5373923050813967928) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1950000000000000344) ) ) {
              result[0] += 0;
            } else {
              result[0] += -0.0324871505118333;
            }
          } else {
            result[0] += -0.014978657257281812;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5640404622805753609) ) ) {
            result[0] += -0.044518935944442735;
          } else {
            result[0] += -0.029398903985344296;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
          result[0] += 0.009618711620061322;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002350500000000000592) ) ) {
            result[0] += -0.02344896437971186;
          } else {
            result[0] += -0.0088502677060079;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6869614610244983988) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8620911151915734427) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7803782188884571536) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5379554743138220685) ) ) {
            result[0] += 0.011577991870283107;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009307500000000001536) ) ) {
              result[0] += 0.0009128508106467741;
            } else {
              result[0] += -0.017609998925221127;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6750000000000001554) ) ) {
            result[0] += 0.0201392956243884;
          } else {
            result[0] += 0.010259891697943904;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6869304497989950908) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9465473169870071146) ) ) {
            result[0] += 0.024663740024395815;
          } else {
            result[0] += 0.04314823036866153;
          }
        } else {
          result[0] += 0.044056565551759345;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8442376020855621999) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.736034375232267446) ) ) {
          result[0] += 0.04196977857381212;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += 0.05422199590327682;
          } else {
            result[0] += 0.03489529833929623;
          }
        }
      } else {
        result[0] += 0.06574757139478123;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7277004308735181004) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4806185349221548386) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2642961365573822663) ) ) {
        result[0] += -0.05976316948342791;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += -0.038191789102578914;
        } else {
          result[0] += -0.04921409269794206;
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6213841400436609375) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4850000000000000422) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5373923050813967928) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1950000000000000344) ) ) {
              result[0] += 0;
            } else {
              result[0] += -0.031410655179331934;
            }
          } else {
            result[0] += -0.01426662718644445;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5640404622805753609) ) ) {
            result[0] += -0.043469474335907726;
          } else {
            result[0] += -0.02830244234224624;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
          result[0] += 0.00903795785890407;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002350500000000000592) ) ) {
            result[0] += -0.022442768666966824;
          } else {
            result[0] += -0.008389280564584798;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6869614610244983988) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.856673619660923702) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
          result[0] += 0.037911325878031706;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7998185917227689234) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05560150000000000509) ) ) {
              result[0] += 0.0005217661668887431;
            } else {
              result[0] += 0.016524240421369775;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5557532160049157843) ) ) {
              result[0] += 0.030901948829211604;
            } else {
              result[0] += 0.010890791881403298;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001543500000000000384) ) ) {
          result[0] += 0.005564163506805022;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9659202880558773741) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8450000000000000844) ) ) {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6690753303250667194) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3687216492462311868) ) ) {
                  result[0] += 0.00659368857103715;
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9250000000000001554) ) ) {
                    result[0] += 0.03795034369775873;
                  } else {
                    result[0] += 0.024019712750145653;
                  }
                }
              } else {
                result[0] += 0.04727790635731561;
              }
            } else {
              result[0] += 0.011416471091344945;
            }
          } else {
            result[0] += 0.05268384154201991;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8442376020855621999) ) ) {
        result[0] += 0.047382183293929195;
      } else {
        result[0] += 0.06482083189110693;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7068923547583354505) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4806185349221548386) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2642961365573822663) ) ) {
        result[0] += -0.05932728496035102;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4429728266653536473) ) ) {
            result[0] += -0.040813979714107544;
          } else {
            result[0] += -0.018329059364477276;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005066500000000000691) ) ) {
            result[0] += -0.05453287459955252;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -0.03890246904246803;
            } else {
              result[0] += -0.05639579098989291;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5897839699588115492) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2719359470653786581) ) ) {
          result[0] += -0.015248269644355203;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.25500000000000006) ) ) {
            result[0] += -0.009002910582893537;
          } else {
            result[0] += -0.03786473343716721;
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6850000000000001643) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6875734944390267112) ) ) {
            result[0] += -0.00937054131377465;
          } else {
            result[0] += 0.012099467595349588;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6491668737719177296) ) ) {
            result[0] += -0.030092614228915165;
          } else {
            result[0] += -0.016680050704394035;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6945966182929305122) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8620911151915734427) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7803782188884571536) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8450000000000000844) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.0841877145549009831) ) ) {
              result[0] += -0.0012247486826053576;
            } else {
              result[0] += 0.012427425322717534;
            }
          } else {
            result[0] += -0.0034978578855918495;
          }
        } else {
          result[0] += 0.011945500761837398;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9297295038086662577) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6869304497989950908) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6170632793331903843) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1529448915625084837) ) ) {
                result[0] += 0.01930883915117487;
              } else {
                result[0] += -0.006134037361864521;
              }
            } else {
              result[0] += 0.027879736316192408;
            }
          } else {
            result[0] += 0.041038249279749146;
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.045006737344013135;
          } else {
            result[0] += 0.02276349302663203;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8442376020855621999) ) ) {
        result[0] += 0.04652500217901013;
      } else {
        result[0] += 0.06394749421304229;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7068923547583354505) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4806185349221548386) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2727691064925280018) ) ) {
        result[0] += -0.05870713217758076;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += -0.03532577870518021;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005066500000000000691) ) ) {
            result[0] += -0.0537399729968115;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -0.03770677678530845;
            } else {
              result[0] += -0.055542941862767266;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5897839699588115492) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2719359470653786581) ) ) {
          result[0] += -0.014544812400150809;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.25500000000000006) ) ) {
            result[0] += -0.00854718680791525;
          } else {
            result[0] += -0.03676917752434654;
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6850000000000001643) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6875734944390267112) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
              result[0] += 0.006818575636351141;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002296500000000000364) ) ) {
                result[0] += -0.03674291861006271;
              } else {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.01414472145045409836) ) ) {
                  result[0] += 0.0015316525995302467;
                } else {
                  result[0] += -0.016192931451496955;
                }
              }
            }
          } else {
            result[0] += 0.01136705690595069;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6491668737719177296) ) ) {
            result[0] += -0.029006431544786045;
          } else {
            result[0] += -0.01590067406476281;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7149490869166016394) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8664403834689663464) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7803782188884571536) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5379554743138220685) ) ) {
            result[0] += 0.007074163074926301;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009307500000000001536) ) ) {
              result[0] += -6.980012536456586e-05;
            } else {
              result[0] += -0.01752787014092518;
            }
          }
        } else {
          result[0] += 0.011612073984705434;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9221644235475580098) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6170632793331903843) ) ) {
            result[0] += 0.015064790012143371;
          } else {
            result[0] += 0.029760907404259455;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8950000000000001288) ) ) {
            result[0] += 0.03953319221376095;
          } else {
            result[0] += 0.01435382920547554;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8502789422115718532) ) ) {
        result[0] += 0.04734708958387271;
      } else {
        result[0] += 0.06332793217952268;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7068923547583354505) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4806185349221548386) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2642961365573822663) ) ) {
        result[0] += -0.05850161517630636;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += -0.03510899592857091;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005066500000000000691) ) ) {
            result[0] += -0.05313067505064329;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -0.03686155668242166;
            } else {
              result[0] += -0.055114784406581296;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5897839699588115492) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2719359470653786581) ) ) {
          result[0] += -0.013867914054153838;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.25500000000000006) ) ) {
            result[0] += -0.008112553450159864;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5373923050813967928) ) ) {
              result[0] += -0.04433583821628677;
            } else {
              result[0] += -0.030221281537798208;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6850000000000001643) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6722423356281408413) ) ) {
            result[0] += -0.008806883341949743;
          } else {
            result[0] += 0.010197117555864053;
          }
        } else {
          result[0] += -0.019817420752386967;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7149490869166016394) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8664403834689663464) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7998185917227689234) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0003555000000000000759) ) ) {
            result[0] += 0.020811539078098535;
          } else {
            result[0] += 0.0010660627860560148;
          }
        } else {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.5708656043828381765) ) ) {
            result[0] += -0.002886353580904128;
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4197832226921585641) ) ) {
              result[0] += 0.033138948498842906;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7650000000000001243) ) ) {
                result[0] += 0.03125421853752716;
              } else {
                result[0] += 0.01046958725285904;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9221644235475580098) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6170632793331903843) ) ) {
            result[0] += 0.014287660897802734;
          } else {
            result[0] += 0.028449161005224106;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8950000000000001288) ) ) {
            result[0] += 0.03804291509555143;
          } else {
            result[0] += 0.013651176937353546;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8502789422115718532) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
          result[0] += 0.04790001533823085;
        } else {
          result[0] += 0.030573203346503836;
        }
      } else {
        result[0] += 0.06255111074810227;
      }
    }
  }
}

