
#include "header.h"

void predict_unit3(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7573813322891708166) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5346753968654129885) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2984949881764770718) ) ) {
        result[0] += -0.09304228731927018;
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.972562317465584913e-05) ) ) {
          result[0] += -0.06327121752702798;
        } else {
          result[0] += -0.07959867315763344;
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6617384408086778302) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.625000000000000111) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6058026752044970431) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.0442771331626926e-05) ) ) {
              result[0] += -0.024787202333335607;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003548500000000000439) ) ) {
                result[0] += -0.0676438803564243;
              } else {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6635233717587941671) ) ) {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.0841877145549009831) ) ) {
                    result[0] += -0.05228660886891284;
                  } else {
                    if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.03659918966571634041) ) ) {
                      result[0] += 0.041393977249152024;
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2850000000000000866) ) ) {
                        result[0] += 0;
                      } else {
                        if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.3944328354552520399) ) ) {
                          result[0] += -0.06562300186599923;
                        } else {
                          result[0] += -0.007195364340886289;
                        }
                      }
                    }
                  }
                } else {
                  result[0] += -0.06517978657640554;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)7.760552846435619852e-06) ) ) {
              result[0] += 0.019727688655773366;
            } else {
              result[0] += -0.02524930653237165;
            }
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5963654365793032985) ) ) {
            result[0] += -0.07229460126891545;
          } else {
            result[0] += -0.0482815707183364;
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7092351592339261046) ) ) {
          if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5220717678210960999) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06261750000000000649) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4750000000000000333) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5643033500753770193) ) ) {
                  result[0] += -0.000745219361535204;
                } else {
                  result[0] += 0.0443354810299309;
                }
              } else {
                if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6983922411789055262) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01119300000000000329) ) ) {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                      result[0] += -0.0298168370511383;
                    } else {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.003760302226300550436) ) ) {
                        result[0] += -0.02551199930203854;
                      } else {
                        result[0] += 0.0513266441265818;
                      }
                    }
                  } else {
                    result[0] += -0.05455248261368032;
                  }
                } else {
                  result[0] += 0.01587038648170109;
                }
              }
            } else {
              result[0] += -0.03876666507149271;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9150000000000001465) ) ) {
              result[0] += -0.056328145340002814;
            } else {
              result[0] += -0.022122634375485006;
            }
          }
        } else {
          result[0] += -0.0034365019641158906;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7583373477169182975) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8477341880899419424) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7962310954155430442) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3905483718502500978) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6050000000000000933) ) ) {
              result[0] += 0.029246983250657322;
            } else {
              if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6098670430554971045) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5736683320603016556) ) ) {
                  result[0] += -0.012526423012395259;
                } else {
                  result[0] += 0.030182517535342145;
                }
              } else {
                result[0] += 0.027857140253711676;
              }
            }
          } else {
            result[0] += -0.011284304370161632;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001383500000000000181) ) ) {
            result[0] += 0.0075118844786824825;
          } else {
            result[0] += 0.02754149269005152;
          }
        }
      } else {
        if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7019284603958083624) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.04446937286580055632) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)15.50000000000000178) ) ) {
              result[0] += 0.024737120643590155;
            } else {
              result[0] += 0.05526192359294585;
            }
          } else {
            if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5647100539952510934) ) ) {
              result[0] += 0.0013177518913113787;
            } else {
              result[0] += 0.0351434070290941;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
            result[0] += 0.0637143461704966;
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3987927703782932487) ) ) {
              result[0] += 0.008085977230444907;
            } else {
              result[0] += 0.05275859934127814;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8255177083825077089) ) ) {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7341068085871017557) ) ) {
          result[0] += 0.07150321785154418;
        } else {
          result[0] += 0.08811058369219543;
        }
      } else {
        result[0] += 0.10538991543545609;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7396101162463498691) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5346753968654129885) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2984949881764770718) ) ) {
        result[0] += -0.09169885462840911;
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0009302321760857001865) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4317260786397597028) ) ) {
            result[0] += -0.06926811409602145;
          } else {
            result[0] += -0.04810738803878991;
          }
        } else {
          result[0] += -0.07769484431197987;
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6617384408086778302) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.625000000000000111) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6058026752044970431) ) ) {
            if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.3093979769950069847) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.966590843157139501) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.08110515786938453375) ) ) {
                  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.2677549912511515973) ) ) {
                    result[0] += -0.01914540357463942;
                  } else {
                    result[0] += -0.06524403064864315;
                  }
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02957950000000000509) ) ) {
                    result[0] += -0.02580476719286491;
                  } else {
                    result[0] += 0.020004818063659276;
                  }
                }
              } else {
                result[0] += -0.07082639476245456;
              }
            } else {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5913340175558032819) ) ) {
                result[0] += -0.05780352560848657;
              } else {
                result[0] += -0.022431432317002932;
              }
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)7.032400086721779109e-06) ) ) {
              result[0] += 0.019397783081213406;
            } else {
              result[0] += -0.023436471269655763;
            }
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5963654365793032985) ) ) {
            result[0] += -0.06970429853352768;
          } else {
            result[0] += -0.045627182611916096;
          }
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4750000000000000333) ) ) {
          if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.4332005353595353436) ) ) {
            result[0] += -0.0078055822198191925;
          } else {
            result[0] += 0.03771428568732182;
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6983922411789055262) ) ) {
            result[0] += -0.03183973657160752;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7150000000000000799) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5356688603015076211) ) ) {
                result[0] += -0.012824336686395463;
              } else {
                result[0] += 0.03583404715887558;
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5550000000000001599) ) ) {
                result[0] += -0.04310684274848241;
              } else {
                result[0] += -0.010795158290493071;
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7583373477169182975) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8319610793798176696) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.25000000000000131e-05) ) ) {
          result[0] += 0.05070914919705494;
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7437931977386935678) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0005715000000000000678) ) ) {
              result[0] += -0.01626574716096284;
            } else {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7765936419225654141) ) ) {
                result[0] += 0.006330548683217779;
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4795364038944723295) ) ) {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3996144213567839887) ) ) {
                    result[0] += 0.01005862026395027;
                  } else {
                    result[0] += 0.04433299844209077;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.02453248258893765341) ) ) {
                    result[0] += 2.9852995201756428e-05;
                  } else {
                    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7962310954155430442) ) ) {
                      result[0] += 0.007273583592398445;
                    } else {
                      result[0] += 0.030228123386608;
                    }
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7962310954155430442) ) ) {
              result[0] += -0.026298421187050225;
            } else {
              result[0] += 0.00948003191636306;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6618962921466065019) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0433285000000000059) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3225540851005025411) ) ) {
              result[0] += 0.050713354626910234;
            } else {
              if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5491908716579932959) ) ) {
                result[0] += -0.012801239965069882;
              } else {
                if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5918528225347782223) ) ) {
                  result[0] += 0.03493758191267586;
                } else {
                  result[0] += 0.00016198754537067686;
                }
              }
            }
          } else {
            result[0] += 0.04150570477826836;
          }
        } else {
          result[0] += 0.04956821797774259;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7903724875956132934) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
          if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7982768737097182266) ) ) {
            result[0] += 0.06633928963071369;
          } else {
            result[0] += 0.08298679470766764;
          }
        } else {
          result[0] += 0.03078177767096222;
        }
      } else {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.891804912653853199) ) ) {
          result[0] += 0.09379634974491276;
        } else {
          result[0] += 0.10463198500022988;
        }
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7396101162463498691) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5346753968654129885) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2984949881764770718) ) ) {
        result[0] += -0.09045120037117782;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += -0.057673877046623453;
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4856029568416016517) ) ) {
            result[0] += -0.07901912674501592;
          } else {
            result[0] += -0.06364112550011429;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6335148768279005305) ) ) {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.3365017545099452945) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5862540317680803303) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3750000000000000555) ) ) {
              result[0] += -0.028848790515072772;
            } else {
              result[0] += -0.05599302139373621;
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.07409325127878772788) ) ) {
              result[0] += -0.029748005472230877;
            } else {
              result[0] += 0.00495009355023931;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002343500000000000531) ) ) {
            result[0] += -0.06617429688398216;
          } else {
            result[0] += -0.04357778785064497;
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6983922411789055262) ) ) {
          if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.465729079252185707) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2850000000000000866) ) ) {
              result[0] += 0.019198139420967122;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06940500000000000835) ) ) {
                result[0] += -0.016217742902213204;
              } else {
                result[0] += -0.05765793632151915;
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004934500000000000518) ) ) {
              if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5736856762879515292) ) ) {
                result[0] += -0.052094763299598175;
              } else {
                result[0] += -0.005126059073340048;
              }
            } else {
              result[0] += -0.005312698642386207;
            }
          }
        } else {
          result[0] += -0.008700453999071617;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7583373477169182975) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8372609372025714425) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.25000000000000131e-05) ) ) {
          result[0] += 0.04579652379381133;
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7437931977386935678) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0005715000000000000678) ) ) {
              result[0] += -0.013125343164636781;
            } else {
              if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6169663040644358665) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6550000000000001377) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1272695000000000076) ) ) {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)183.5000000000000284) ) ) {
                      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7573813322891708166) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02458911890494585445) ) ) {
                          result[0] += 0.020363152750902853;
                        } else {
                          result[0] += -0.024573181811337535;
                        }
                      } else {
                        result[0] += 0.020408468098930665;
                      }
                    } else {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)336.5000000000000568) ) ) {
                        result[0] += 0.06213177590083329;
                      } else {
                        result[0] += 0.010932262893463994;
                      }
                    }
                  } else {
                    result[0] += -0.013259738423078723;
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02008391570334735338) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002027500000000000222) ) ) {
                      result[0] += -0.034750200283071415;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3436166336222546414) ) ) {
                        result[0] += 0.02147840455100769;
                      } else {
                        result[0] += -0.01786855388504554;
                      }
                    }
                  } else {
                    result[0] += -0.04722261184374705;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5028830662814071095) ) ) {
                  if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6140748412273120405) ) ) {
                    result[0] += 0.012071698625720915;
                  } else {
                    result[0] += 0.05932027808369361;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.09221743570336575491) ) ) {
                    result[0] += -0.003340374948435816;
                  } else {
                    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6449951248969220119) ) ) {
                      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7810696647307608931) ) ) {
                        result[0] += 0.014559897462067838;
                      } else {
                        result[0] += 0.07461602906950388;
                      }
                    } else {
                      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.657270379803368221) ) ) {
                        result[0] += -0.02127897760098608;
                      } else {
                        result[0] += 0.027838219363113908;
                      }
                    }
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7962310954155430442) ) ) {
              result[0] += -0.02432600494682368;
            } else {
              result[0] += 0.015005308845819099;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8790620348987957522) ) ) {
          result[0] += 0.031900368532884193;
        } else {
          result[0] += 0.04860809969189287;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8255177083825077089) ) ) {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7341068085871017557) ) ) {
          result[0] += 0.06375772472864477;
        } else {
          result[0] += 0.08103097152184524;
        }
      } else {
        result[0] += 0.10014303868488343;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7396101162463498691) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5223131059347717597) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2692173444281812933) ) ) {
        result[0] += -0.09007706367909202;
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.972562317465584913e-05) ) ) {
          result[0] += -0.05833210607723447;
        } else {
          result[0] += -0.07533536150419819;
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6335148768279005305) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.625000000000000111) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.0442771331626926e-05) ) ) {
            result[0] += -0.01782728016742472;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002465500000000000243) ) ) {
              result[0] += -0.06069707892561922;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)177.5000000000000284) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01289333490204290153) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006083500000000001233) ) ) {
                    result[0] += -0.03834958413317463;
                  } else {
                    if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.02112777881548619577) ) ) {
                      result[0] += 0.04681752078762481;
                    } else {
                      result[0] += -0.009895630033343919;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02711386111807555233) ) ) {
                    result[0] += -0.05274423434874619;
                  } else {
                    result[0] += -0.018128019642103838;
                  }
                }
              } else {
                result[0] += -0.05039851360894137;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03606792155040580705) ) ) {
            result[0] += -0.0603387565142674;
          } else {
            result[0] += -0.017632028162496545;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004834500000000001123) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002365000000000000294) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1095246494610394722) ) ) {
              result[0] += -0.021510517596076178;
            } else {
              result[0] += 0.024321976662650666;
            }
          } else {
            if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5268343718203251091) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8950000000000001288) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0155154064060210508) ) ) {
                  result[0] += -0.039682496806392256;
                } else {
                  result[0] += -0.010169590813707191;
                }
              } else {
                result[0] += -0.06492322530270266;
              }
            } else {
              result[0] += -0.011538813017634219;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5508018452917812224) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006352500000000001375) ) ) {
              result[0] += 0.02870200823178021;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2850000000000000866) ) ) {
                result[0] += 0.03390479860744181;
              } else {
                result[0] += -0.009833495222002726;
              }
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8099155601256282644) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05527450000000001112) ) ) {
                result[0] += -0.02206729994511574;
              } else {
                result[0] += -0.07983489488553519;
              }
            } else {
              result[0] += 0.0002815818409760594;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7787197788111503982) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8527347970710045244) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7962310954155430442) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3905483718502500978) ) ) {
            result[0] += 0.011163831893683869;
          } else {
            result[0] += -0.010614816048827275;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001383500000000000181) ) ) {
            result[0] += 0.0017108557145824935;
          } else {
            result[0] += 0.022522440249968252;
          }
        }
      } else {
        if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7019284603958083624) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9350000000000001643) ) ) {
            if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6118109021115948343) ) ) {
              result[0] += 0.007942766010090328;
            } else {
              result[0] += 0.04678165898521894;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03356779836971720415) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)53.50000000000000711) ) ) {
                result[0] += 0.05006590730214368;
              } else {
                result[0] += 0.009363166268908402;
              }
            } else {
              result[0] += -0.005627262452428125;
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
            if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6225346164046366981) ) ) {
              result[0] += 0.022805639022615475;
            } else {
              result[0] += 0.07065649229074386;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07287111975896176652) ) ) {
              if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6569165541141283038) ) ) {
                result[0] += 0.0228851743732542;
              } else {
                result[0] += 0.05297148733433794;
              }
            } else {
              result[0] += 0.008347935098317242;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8255177083825077089) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7341068085871017557) ) ) {
            result[0] += 0.062325561754120656;
          } else {
            result[0] += 0.08037769165138792;
          }
        } else {
          result[0] += 0.02946475527214386;
        }
      } else {
        result[0] += 0.09790070077535491;
      }
    }
  }
}

