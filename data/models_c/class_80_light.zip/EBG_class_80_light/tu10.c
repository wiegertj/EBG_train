
#include "header.h"

void predict_unit10(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2727691064925280018) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1313656708211964064) ) ) {
      result[0] += -0.05334508209188176;
    } else {
      if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2302999793555680907) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.05104134306603266835) ) ) {
          result[0] += 0.09134017453821905;
        } else {
          result[0] += -0.021646896513724773;
        }
      } else {
        result[0] += -0.02942674003413766;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8622565274156744897) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5717030637423591299) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2802420000000000466) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5089951851639061831) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1450000000000000455) ) ) {
                result[0] += -0.020175143415368937;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09500000000000001499) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3458292651130187578) ) ) {
                    result[0] += 0;
                  } else {
                    result[0] += 0.09164041951927968;
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4583473626633166043) ) ) {
                    result[0] += -0.025690118536431744;
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.07324450000000001793) ) ) {
                      result[0] += 0.0019084228951173445;
                    } else {
                      result[0] += -0.03704512192648541;
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004675500000000000836) ) ) {
                result[0] += -0.0413072044239367;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01742800000000000252) ) ) {
                  result[0] += 0.008006546963250864;
                } else {
                  result[0] += -0.03871810114169554;
                }
              }
            }
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.8085344187842374852) ) ) {
              result[0] += -0.024857216838569195;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8950000000000001288) ) ) {
                result[0] += 0.0003159880094726885;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6161319161557790025) ) ) {
                  result[0] += 0;
                } else {
                  result[0] += -0.01705433074783266;
                }
              }
            }
          }
        } else {
          result[0] += 0.03230415070747894;
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1430295000000000316) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
            result[0] += 0.02758909840171288;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0005635000000000000902) ) ) {
              result[0] += -0.014977706980369546;
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4627502129294571165) ) ) {
                result[0] += 0.01336987082467857;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4141149047989949872) ) ) {
                  result[0] += -0.013316021729302114;
                } else {
                  result[0] += 0.003374700977641108;
                }
              }
            }
          }
        } else {
          result[0] += 0.020919735490916157;
        }
      }
    } else {
      result[0] += 0.03799515658530999;
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2642961365573822663) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1313656708211964064) ) ) {
      result[0] += -0.05314444322363044;
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += 0.02053465998572622;
      } else {
        result[0] += -0.029406140463491243;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8622565274156744897) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5566107632786835291) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02962100000000000496) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1450000000000000455) ) ) {
              result[0] += -0.023940633894430605;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1955936545101208957) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3701792563479459619) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1850000000000000255) ) ) {
                    result[0] += 0.020121437341064176;
                  } else {
                    result[0] += -0.013255610485784483;
                  }
                } else {
                  result[0] += 0.038436013786597625;
                }
              } else {
                result[0] += -0.009632054327752724;
              }
            }
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1866571336964587269) ) ) {
              result[0] += -0.02092381237878244;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5352759199748745589) ) ) {
                result[0] += 0.041410196003430086;
              } else {
                result[0] += 0.005799200434307773;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01401950000000000245) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9111514820863041431) ) ) {
              result[0] += -0.04303857485988056;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4850000000000000422) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00344850000000000061) ) ) {
                  result[0] += 0;
                } else {
                  result[0] += 0.05484454010382968;
                }
              } else {
                result[0] += -0.03178110522301755;
              }
            }
          } else {
            result[0] += -0.04074899252398439;
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.736034375232267446) ) ) {
          result[0] += 0.0005899310987300663;
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9108935748982122105) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002914500000000000424) ) ) {
              result[0] += 0.03541484638066665;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
                result[0] += 0.035456852310579066;
              } else {
                if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8177575351951122951) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6669784622613067482) ) ) {
                    result[0] += -0.0029251160632063253;
                  } else {
                    result[0] += 0.024141917520147264;
                  }
                } else {
                  result[0] += 0.02367846583166187;
                }
              }
            }
          } else {
            result[0] += -0.015875509941837965;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9673254386414430472) ) ) {
        result[0] += 0.02982246667648865;
      } else {
        result[0] += 0.052832617299296586;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2642961365573822663) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1313656708211964064) ) ) {
      result[0] += -0.052936214299681865;
    } else {
      if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2302999793555680907) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.05801046241977435292) ) ) {
          result[0] += 0.07410896319639673;
        } else {
          result[0] += -0.029669245823778934;
        }
      } else {
        result[0] += -0.028929617687017177;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8622565274156744897) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7227354901093919759) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2802420000000000466) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.089430082328138649) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.038112519465065331) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4604805625892014476) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1988654957757923225) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3979185231489558716) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02500000000000000486) ) ) {
                      result[0] += 0.05665017407895695;
                    } else {
                      result[0] += -0.011309579295398171;
                    }
                  } else {
                    result[0] += 0.026975786955413708;
                  }
                } else {
                  result[0] += -0.020895530980226014;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4002876056281407524) ) ) {
                  result[0] += -0.014011962751714058;
                } else {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.01051018765715429869) ) ) {
                    if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.08835747683243963535) ) ) {
                      result[0] += -0.0005759996591300876;
                    } else {
                      result[0] += 0.015008918098861226;
                    }
                  } else {
                    result[0] += -0.004489972889683953;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002788500000000000614) ) ) {
                result[0] += 0;
              } else {
                result[0] += 0.09116881572767062;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.457260671080300662) ) ) {
              result[0] += -0.026335935009931574;
            } else {
              result[0] += 0.002932646433557305;
            }
          }
        } else {
          result[0] += 0.04044102609947824;
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7560518798657903661) ) ) {
          result[0] += 0.0017861240767547844;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
            result[0] += 0.0329982466834691;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6122194349497488419) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002788500000000000614) ) ) {
                result[0] += 0.031442756985136926;
              } else {
                if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8177575351951122951) ) ) {
                  result[0] += -0.014502293262702262;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9650000000000000799) ) ) {
                    result[0] += 0.041518037568460696;
                  } else {
                    result[0] += -0.0075389904593382755;
                  }
                }
              }
            } else {
              result[0] += 0.02505849723438709;
            }
          }
        }
      }
    } else {
      result[0] += 0.03647602741392403;
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2296243883448841061) ) ) {
    if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2302999793555680907) ) ) {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += 0.08418356293412296;
      } else {
        result[0] += -0.01938687536628836;
      }
    } else {
      result[0] += -0.044960392716368786;
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8622565274156744897) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5089951851639061831) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3150000000000000577) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4604805625892014476) ) ) {
              result[0] += -0.012051541707660407;
            } else {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2060867271409693446) ) ) {
                result[0] += 0.03286801910879998;
              } else {
                result[0] += -0.005317803520374491;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007091500000000001448) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1650000000000000355) ) ) {
                result[0] += 0.0489176465206844;
              } else {
                result[0] += 0.006971333081901689;
              }
            } else {
              result[0] += -0.020615950288861283;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004675500000000000836) ) ) {
            result[0] += -0.04033631770869456;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01742800000000000252) ) ) {
              result[0] += 0.00857875760969054;
            } else {
              result[0] += -0.03766173115519171;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6486987125073885307) ) ) {
          result[0] += -0.00019940510141297854;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0007525000000000000222) ) ) {
            result[0] += -0.015554457851547023;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001142500000000000069) ) ) {
              result[0] += 0.041711678122247325;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.09838300000000001211) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9108935748982122105) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9853835301935895963) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9650000000000000799) ) ) {
                      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8115313189803874394) ) ) {
                        result[0] += 0.003421872410311097;
                      } else {
                        result[0] += 0.030182196418166208;
                      }
                    } else {
                      result[0] += -0.02599005778521704;
                    }
                  } else {
                    result[0] += 0.023562548102810586;
                  }
                } else {
                  result[0] += -0.025443982062960092;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4693702733417085549) ) ) {
                  result[0] += -0.01170183529345311;
                } else {
                  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7560518798657903661) ) ) {
                    result[0] += 0.013191128425752003;
                  } else {
                    result[0] += 0.05116477240605947;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9673254386414430472) ) ) {
        result[0] += 0.02794240822640988;
      } else {
        result[0] += 0.05237118739605244;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2252215573829355333) ) ) {
    if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3750409390474713223) ) ) {
      if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4960812931966640527) ) ) {
        result[0] += -0.03476946735295873;
      } else {
        result[0] += 0.08642497877002782;
      }
    } else {
      result[0] += -0.04397751673283665;
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8502789422115718532) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4604805625892014476) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2295059026793999646) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3881589449934809699) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
              result[0] += 0.0009177707655101643;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1250000000000000278) ) ) {
                result[0] += -0.011917684474891485;
              } else {
                result[0] += -0.03549463507098717;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.013855723816631915) ) ) {
              result[0] += -0.003123810746370747;
            } else {
              result[0] += 0.0399168259809249;
            }
          }
        } else {
          result[0] += -0.03430598694297668;
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3073450000000000348) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5717030637423591299) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4073174598994975804) ) ) {
              if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.5170510649617241494) ) ) {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.8085344187842374852) ) ) {
                  result[0] += -0.020103208980532066;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3315854282412060705) ) ) {
                    result[0] += 0.020886229198792454;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7423774199879572544) ) ) {
                      result[0] += -0.01626328719828624;
                    } else {
                      result[0] += 0.008538199400296024;
                    }
                  }
                }
              } else {
                result[0] += -0.026412391877293905;
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4141149047989949872) ) ) {
                result[0] += 0.029295099191191422;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8950000000000001288) ) ) {
                  result[0] += 0.0004949365774991814;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6161319161557790025) ) ) {
                    result[0] += 0;
                  } else {
                    result[0] += -0.016186366686975383;
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.950000000000000467e-05) ) ) {
              result[0] += 0.027681951049074432;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0005635000000000000902) ) ) {
                result[0] += -0.014226872184692369;
              } else {
                result[0] += 0.0037111838512188236;
              }
            }
          }
        } else {
          result[0] += 0.02622560366985132;
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9673254386414430472) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5140962685175880509) ) ) {
          result[0] += 0.012189313773256983;
        } else {
          result[0] += 0.0384140611564472;
        }
      } else {
        result[0] += 0.05208750446594518;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2252215573829355333) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1313656708211964064) ) ) {
      result[0] += -0.052349016400208975;
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += 0.026977637068522888;
      } else {
        result[0] += -0.03160021076949968;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8622565274156744897) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5566107632786835291) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6285027855690678011) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.07243653406935533778) ) ) {
            result[0] += -0.012413173442218886;
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.04908445857219279757) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002914500000000000424) ) ) {
                result[0] += -0.008458274710080173;
              } else {
                result[0] += 0.08049407579506294;
              }
            } else {
              result[0] += -0.0024709108985515936;
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8722100575184922322) ) ) {
            result[0] += -0.03203322130489314;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7392963230402010977) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7242520756532664361) ) ) {
                result[0] += -0.013028342309631272;
              } else {
                result[0] += 0.05669031803594804;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01401950000000000245) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5050000000000001155) ) ) {
                  result[0] += 0.007104493156418712;
                } else {
                  result[0] += -0.034439678990183374;
                }
              } else {
                result[0] += -0.03844059393923223;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9024131424400998469) ) ) {
          result[0] += 0;
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1368445000000000078) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9108935748982122105) ) ) {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8115313189803874394) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06144600000000000756) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9659202880558773741) ) ) {
                      result[0] += 0.010708335435614079;
                    } else {
                      result[0] += 0.0390847068827645;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9439246386423358892) ) ) {
                      result[0] += -0.028216963245573726;
                    } else {
                      result[0] += 0.012939198437634405;
                    }
                  }
                } else {
                  result[0] += -0.0008289652641205456;
                }
              } else {
                result[0] += 0.02215257575613704;
              }
            } else {
              result[0] += -0.024792352310021526;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4838161673366834781) ) ) {
              result[0] += -0.006195166480732106;
            } else {
              result[0] += 0.0331766140448035;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9673254386414430472) ) ) {
        result[0] += 0.02634623463055117;
      } else {
        result[0] += 0.05179483318498978;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2252215573829355333) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1313656708211964064) ) ) {
      result[0] += -0.05210943317812881;
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += 0.024893262404308034;
      } else {
        result[0] += -0.030797115217952774;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8622565274156744897) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4429728266653536473) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02500000000000000486) ) ) {
          result[0] += 0.03034672163570338;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.07500000000000002498) ) ) {
            result[0] += -0.03175257742555083;
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.0719579876753213693) ) ) {
              result[0] += 0.03922099224062289;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.578780523307733108) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3550761912678883081) ) ) {
                  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1645254211347557949) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4026864459943229613) ) ) {
                      result[0] += -0.008452439682738148;
                    } else {
                      result[0] += 0.034124550740604005;
                    }
                  } else {
                    result[0] += -0.024250564029781145;
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3350000000000000755) ) ) {
                    result[0] += 0.03400954086707915;
                  } else {
                    result[0] += -0.014638760577784387;
                  }
                }
              } else {
                result[0] += -0.022530302931717247;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3073450000000000348) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6413546906794281854) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8350000000000000755) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8889371422142716694) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2389374995899939125) ) ) {
                  result[0] += 0.014354175350044358;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4997404627345643502) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
                      result[0] += -0.001645062478627695;
                    } else {
                      result[0] += -0.029780505125321786;
                    }
                  } else {
                    result[0] += -0.0008767340502163158;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02962100000000000496) ) ) {
                  result[0] += 0.021394781717520715;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9297295038086662577) ) ) {
                    result[0] += -0.01032397164505283;
                  } else {
                    result[0] += 0.012782781566861598;
                  }
                }
              }
            } else {
              result[0] += -0.022584235423555102;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.7050000000000000711) ) ) {
              result[0] += 0.030991117731512977;
            } else {
              result[0] += 0.004268010963281363;
            }
          }
        } else {
          result[0] += 0.02503374166701091;
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9673254386414430472) ) ) {
        result[0] += 0.025527284309517707;
      } else {
        result[0] += 0.05149264317397519;
      }
    }
  }
}

