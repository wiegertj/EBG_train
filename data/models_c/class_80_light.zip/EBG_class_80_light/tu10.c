
#include "header.h"

void predict_unit10(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8255177083825077089) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3363340570929463369) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1326198720340577564) ) ) {
        result[0] += -0.0813632195026824;
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0001660383056237000384) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += 0.030841185358777945;
          } else {
            result[0] += -0.03385935089071003;
          }
        } else {
          result[0] += -0.05697900215725451;
        }
      }
    } else {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.4905089628645931121) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6059238433417085679) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5879208094472362367) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004733500000000000728) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001121963940922750215) ) ) {
                result[0] += -0.002137244339297371;
              } else {
                result[0] += -0.03692996118986941;
              }
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.08835747683243963535) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3296315496301309156) ) ) {
                  if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3763018001168558224) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02200300644874975467) ) ) {
                      result[0] += 0.023323921687741687;
                    } else {
                      result[0] += -0.031259872446982265;
                    }
                  } else {
                    result[0] += 0.08063064559177434;
                  }
                } else {
                  if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.144651564651768455) ) ) {
                    result[0] += -0.017689283129857302;
                  } else {
                    result[0] += -0.05800014460898074;
                  }
                }
              } else {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.0491948752242571466) ) ) {
                  if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.071894537606111239) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)43.50000000000000711) ) ) {
                      result[0] += 0.09253955851029028;
                    } else {
                      result[0] += -0.01477766327829496;
                    }
                  } else {
                    result[0] += 0.1007407904947661;
                  }
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01414472145045409836) ) ) {
                    result[0] += -0.046432337083359226;
                  } else {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5809549685175879885) ) ) {
                      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5736683320603016556) ) ) {
                        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5628434130653267031) ) ) {
                          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.544739387236181094) ) ) {
                            if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.4042793371666529856) ) ) {
                              result[0] += -0.026623891765303685;
                            } else {
                              result[0] += 0.051300474647048795;
                            }
                          } else {
                            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03013550000000000256) ) ) {
                              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0145076550961928518) ) ) {
                                result[0] += 0.033553506361715515;
                              } else {
                                result[0] += -0.03752793418514552;
                              }
                            } else {
                              result[0] += 0.06732979036779484;
                            }
                          }
                        } else {
                          result[0] += -0.052332352071071786;
                        }
                      } else {
                        result[0] += 0.03800754452026446;
                      }
                    } else {
                      result[0] += -0.05852739104321995;
                    }
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6550000000000001377) ) ) {
              result[0] += 0.011091503252417407;
            } else {
              result[0] += 0.0898826520123698;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05237611692205520336) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05527450000000001112) ) ) {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.619628671453726132) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4550000000000000711) ) ) {
                  result[0] += -0.010090311465919361;
                } else {
                  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5223131059347717597) ) ) {
                    result[0] += -0.06699557975901149;
                  } else {
                    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.358279098130949436) ) ) {
                      result[0] += -0.005534815413798734;
                    } else {
                      result[0] += -0.04447774743017892;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.4657719170617994342) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01184850000000000139) ) ) {
                    result[0] += 0.0655761134933755;
                  } else {
                    result[0] += 0;
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5250000000000001332) ) ) {
                    result[0] += 0.008646684417245077;
                  } else {
                    result[0] += -0.052180974407834556;
                  }
                }
              }
            } else {
              result[0] += -0.05617163490963663;
            }
          } else {
            result[0] += 0.004618644687345453;
          }
        }
      } else {
        if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6859815657019552315) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8050000000000001599) ) ) {
            result[0] += 0.008708624164425777;
          } else {
            result[0] += 2.5106294540794427e-05;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.04185462050626237;
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6784611311055277483) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5508018452917812224) ) ) {
                result[0] += 0.012591934228540562;
              } else {
                result[0] += -0.05696851536060193;
              }
            } else {
              result[0] += 0.033786054784525094;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9447707794465654008) ) ) {
      result[0] += 0.048556867326050294;
    } else {
      result[0] += 0.08207001169302841;
    }
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8320474816531334694) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2984949881764770718) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1326198720340577564) ) ) {
        result[0] += -0.08100439826887437;
      } else {
        result[0] += -0.04752743178588985;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5963654365793032985) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6277403467108452206) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04822921143616690914) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.13900392495124092) ) ) {
              result[0] += 0.047762976838446346;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
                if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.09551577964343850591) ) ) {
                  result[0] += 0.02868845009761689;
                } else {
                  result[0] += -0.05026518988704368;
                }
              } else {
                result[0] += -0.012097337318159233;
              }
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.0841877145549009831) ) ) {
              result[0] += -0.0292512266127083;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01977150000000000435) ) ) {
                result[0] += 0.07425217886299039;
              } else {
                result[0] += 0.0012993454946152708;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.321871344966293327) ) ) {
            result[0] += -0.03570322216852556;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8267834517085428381) ) ) {
              result[0] += 0.06432451008356761;
            } else {
              result[0] += -0.016565982047301267;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.652066519749839979) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)986.5000000000001137) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2850245757603476204) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4014613332412060864) ) ) {
                if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5701039805841723318) ) ) {
                  result[0] += -0.009762287465017273;
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)37.50000000000000711) ) ) {
                    result[0] += 0.034202810172634435;
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
                      result[0] += 0.023838045046855452;
                    } else {
                      result[0] += -0.02205005817304813;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4138030768592965147) ) ) {
                  result[0] += 0.04565718475672233;
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.5412335719706470316) ) ) {
                    result[0] += -0.03989495201331754;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03378350000000000103) ) ) {
                      if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5439678418521619596) ) ) {
                        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4529241356532663354) ) ) {
                          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7050000000000000711) ) ) {
                            result[0] += -0.046840471188276084;
                          } else {
                            result[0] += 0;
                          }
                        } else {
                          result[0] += 0.015726625168402713;
                        }
                      } else {
                        result[0] += 0.0248410193878288;
                      }
                    } else {
                      result[0] += 0.057691735823800064;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4230630641206030718) ) ) {
                result[0] += -0.038827336983589436;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  result[0] += 0.015717802275502204;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0006455000000000001318) ) ) {
                    result[0] += -0.02835316558859237;
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.004712584303378800944) ) ) {
                      result[0] += -0.01386731680636399;
                    } else {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.006527047460702001085) ) ) {
                        result[0] += 0.02717148347235074;
                      } else {
                        result[0] += -0.001627583798174599;
                      }
                    }
                  }
                }
              }
            }
          } else {
            result[0] += 0.02709159458205363;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09148849557171551128) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6784611311055277483) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5681735652491761712) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
                  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9467376244428525878) ) ) {
                    result[0] += 0.016234113986221824;
                  } else {
                    result[0] += 0.04803543329073264;
                  }
                } else {
                  result[0] += 0.009456239069748996;
                }
              } else {
                result[0] += -0.04393193475386154;
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7218051716834171794) ) ) {
                result[0] += 0.06331355159728569;
              } else {
                if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7982768737097182266) ) ) {
                  result[0] += -0.0029916467994773317;
                } else {
                  result[0] += 0.041842350679018016;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6859815657019552315) ) ) {
              result[0] += -0.03412590098950645;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01322750000000000141) ) ) {
                result[0] += 0.05295821701762571;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.875000000000000111) ) ) {
                  result[0] += 0.015709100425968688;
                } else {
                  result[0] += -0.05048937173327916;
                }
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9447707794465654008) ) ) {
      result[0] += 0.04783064838922269;
    } else {
      result[0] += 0.08161495231552887;
    }
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8320474816531334694) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2984949881764770718) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1326198720340577564) ) ) {
        result[0] += -0.08063253114410203;
      } else {
        result[0] += -0.04570100078611958;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5654503268216671819) ) ) {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.13900392495124092) ) ) {
          result[0] += 0.05916044716123134;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6411603019421380223) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1492500000000000215) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001290117952834850213) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.000758500000000000168) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3550000000000000377) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)13.50000000000000178) ) ) {
                      result[0] += -0.04395234756983221;
                    } else {
                      result[0] += 0.007377682868663139;
                    }
                  } else {
                    result[0] += -0.033177254888491874;
                  }
                } else {
                  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4856029568416016517) ) ) {
                    result[0] += -0.01687916482441477;
                  } else {
                    result[0] += 0.0934386833894502;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.003460076099064600137) ) ) {
                  result[0] += -0.0499514119298641;
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4075435166080402793) ) ) {
                    result[0] += -0.05170907466907484;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08814650000000001651) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00108550000000000031) ) ) {
                        result[0] += -0.04579628413174201;
                      } else {
                        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.0491948752242571466) ) ) {
                          if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.071894537606111239) ) ) {
                            if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.3128350063206974396) ) ) {
                              result[0] += -0.02761899306178996;
                            } else {
                              result[0] += 0.019116413103096114;
                            }
                          } else {
                            result[0] += 0.1263359875482244;
                          }
                        } else {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0229230000000000024) ) ) {
                            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)157.5000000000000284) ) ) {
                              result[0] += -0.032969086268549504;
                            } else {
                              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5792515097236182742) ) ) {
                                result[0] += -0.01673372369707505;
                              } else {
                                result[0] += 0.0682961371380634;
                              }
                            }
                          } else {
                            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
                              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03415316330662036132) ) ) {
                                result[0] += 0.1024403166993746;
                              } else {
                                result[0] += 0;
                              }
                            } else {
                              result[0] += -0.024241793183858575;
                            }
                          }
                        }
                      }
                    } else {
                      result[0] += -0.05743719037799727;
                    }
                  }
                }
              }
            } else {
              result[0] += 0.06646692121483354;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.321871344966293327) ) ) {
              result[0] += -0.0371432189667017;
            } else {
              result[0] += 0.011905891195499585;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9021581204195773251) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)986.5000000000001137) ) ) {
            result[0] += -0.0005269579094158678;
          } else {
            result[0] += 0.025678288317130985;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001383500000000000181) ) ) {
            result[0] += 0.04605823214845147;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
                if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6185135130867678299) ) ) {
                  result[0] += 0.00025689224795177277;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)427.5000000000000568) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007744500000000000516) ) ) {
                      result[0] += 0;
                    } else {
                      result[0] += 0.04051193164359634;
                    }
                  } else {
                    result[0] += -0.004814466337504608;
                  }
                }
              } else {
                result[0] += -0.014434949895810378;
              }
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6666038956030152507) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6552470062311558374) ) ) {
                  if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.680280748538736324) ) ) {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)29.50000000000000355) ) ) {
                      result[0] += 0.009958357236533995;
                    } else {
                      result[0] += -0.05033646879025048;
                    }
                  } else {
                    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9805282181500402094) ) ) {
                      result[0] += 0.013237404811340494;
                    } else {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07287111975896176652) ) ) {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05014750000000000457) ) ) {
                          result[0] += -0.020895228911200263;
                        } else {
                          result[0] += 0.036302067441075794;
                        }
                      } else {
                        result[0] += -0.06959560953115426;
                      }
                    }
                  }
                } else {
                  result[0] += -0.06765505207233326;
                }
              } else {
                if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7982768737097182266) ) ) {
                  result[0] += 0;
                } else {
                  result[0] += 0.054478228043376487;
                }
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9447707794465654008) ) ) {
      result[0] += 0.04593865470394263;
    } else {
      result[0] += 0.08115220874184967;
    }
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8320474816531334694) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2984949881764770718) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1326198720340577564) ) ) {
        result[0] += -0.0802455162832957;
      } else {
        result[0] += -0.0438690048416862;
      }
    } else {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5795217186975821777) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5002776212835359226) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3850000000000000644) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3050000000000000488) ) ) {
              result[0] += -0.019565838616086278;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)127.5000000000000142) ) ) {
                if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.1946989117759076737) ) ) {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6242692027386935738) ) ) {
                    result[0] += 0.08093096269694658;
                  } else {
                    result[0] += -0.004303546806581987;
                  }
                } else {
                  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.2630603227338998429) ) ) {
                    result[0] += -0.03708584467485645;
                  } else {
                    result[0] += 0.034781243047660726;
                  }
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)293.5000000000000568) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3350000000000000755) ) ) {
                    result[0] += 0;
                  } else {
                    result[0] += 0.1126560371657623;
                  }
                } else {
                  result[0] += -0.005150947497754464;
                }
              }
            }
          } else {
            result[0] += -0.05059670757896813;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8950000000000001288) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3233655000000000279) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1325525000000000453) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)491.5000000000000568) ) ) {
                  result[0] += -0.0004912723034438417;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)986.5000000000001137) ) ) {
                    result[0] += -0.03410301583697647;
                  } else {
                    result[0] += 0.01790247651226456;
                  }
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)399.5000000000000568) ) ) {
                  result[0] += -0.0341634798674767;
                } else {
                  result[0] += 0.011600132016116675;
                }
              }
            } else {
              result[0] += 0.0416704797024252;
            }
          } else {
            result[0] += -0.021600629209026688;
          }
        }
      } else {
        if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7341068085871017557) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8850000000000001199) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7079840454522613458) ) ) {
              if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01066013304459604953) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5408295445477387942) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05527450000000001112) ) ) {
                    if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2315209029506543892) ) ) {
                      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4129968667336683663) ) ) {
                        result[0] += -0.006708703209816225;
                      } else {
                        result[0] += 0.035730027923484654;
                      }
                    } else {
                      result[0] += -0.034283214361480255;
                    }
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1180700000000000222) ) ) {
                      result[0] += 0.0630461171608301;
                    } else {
                      result[0] += 0.00011974140489665599;
                    }
                  }
                } else {
                  result[0] += 0.04945543092657655;
                }
              } else {
                result[0] += -0.006012358004937038;
              }
            } else {
              result[0] += 0.04454423589482987;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)24.50000000000000355) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01502249064440015248) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5933854157035177712) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.499023329447236208) ) ) {
                    result[0] += 0.03389252120743292;
                  } else {
                    result[0] += -0.008468108900374274;
                  }
                } else {
                  result[0] += 0.05266450727987198;
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05270200000000000579) ) ) {
                  result[0] += -0.0034105909115135125;
                } else {
                  result[0] += 0.03059394616337301;
                }
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9150000000000001465) ) ) {
                if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5861769322017787998) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0433285000000000059) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007744500000000000516) ) ) {
                      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7485911169215263561) ) ) {
                        result[0] += 0.0017332729051681192;
                      } else {
                        result[0] += -0.026640790529663394;
                      }
                    } else {
                      result[0] += 0.012300307753404512;
                    }
                  } else {
                    result[0] += -0.04403621402647252;
                  }
                } else {
                  result[0] += 0.003548932685823474;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.04032048615039360989) ) ) {
                  result[0] += -0.06823967292877908;
                } else {
                  result[0] += -0.004799484226896448;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.999605151818775961) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02844139229116105297) ) ) {
              result[0] += 0.03461504096425363;
            } else {
              result[0] += 0.010944718855425544;
            }
          } else {
            result[0] += -0.03273168093084366;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9447707794465654008) ) ) {
      result[0] += 0.04404781534823322;
    } else {
      result[0] += 0.0806790003908309;
    }
  }
}

