
#include "header.h"

void predict_unit10(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5828162941871858349) ) ) {
    result[0] += -0.0065662714489576595;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9650000000000000799) ) ) {
      result[0] += 0.03992440084825231;
    } else {
      result[0] += 0.0027760140346863842;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9532041455015286546) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2898514409486858123) ) ) {
      result[0] += -0.04489596434712947;
    } else {
      result[0] += 0.0006757629325410588;
    }
  } else {
    result[0] += 0.09593466350500145;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8643592654933326402) ) ) {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9750000000000000888) ) ) {
      result[0] += -0.0004257511282598801;
    } else {
      result[0] += -0.08958550962963302;
    }
  } else {
    result[0] += 0.05060170768676919;
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2669585275879397535) ) ) {
    result[0] += 0.05583138898811892;
  } else {
    if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5828162941871858349) ) ) {
      result[0] += -0.007131027531463056;
    } else {
      result[0] += 0.00897267044582963;
    }
  }
  if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.0183365983644377499) ) ) {
    result[0] += -0.10517729984702151;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
      result[0] += 0.03104201630034843;
    } else {
      result[0] += -0.0021924592815397046;
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.741544944673366957) ) ) {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03724650000000000877) ) ) {
      result[0] += -0.0019083578068986604;
    } else {
      result[0] += 0.023400210578645057;
    }
  } else {
    result[0] += -0.01982605336243644;
  }
}

