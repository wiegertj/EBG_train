
#include "header.h"

void predict_unit9(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.647174411118524473) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3789369143834280806) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2585695341105315181) ) ) {
        result[0] += -0.04233082600430335;
      } else {
        result[0] += -0.030363700481681077;
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5091389307398357378) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1850000000000000255) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4036106884780860105) ) ) {
              result[0] += -0.011707002747347406;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6800105846231156992) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6784611311055277483) ) ) {
                  result[0] += 0.028896564360789287;
                } else {
                  result[0] += 0.1425941239614444;
                }
              } else {
                result[0] += -0.017780809127532042;
              }
            }
          } else {
            result[0] += -0.02210626145925376;
          }
        } else {
          result[0] += -0.034727585905553644;
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.625000000000000111) ) ) {
          result[0] += -0.00788714348053714;
        } else {
          result[0] += -0.022234881158441164;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8244912349994802936) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.649924828200234006) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.755533006633860027) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4493993753087514587) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4529241356532663354) ) ) {
              if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4323286620486300191) ) ) {
                if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.5329091955564501104) ) ) {
                  result[0] += -0.014019011400284314;
                } else {
                  result[0] += 0.017661570465019816;
                }
              } else {
                result[0] += -0.03373731321748659;
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4797597438944724013) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4713523350863212946) ) ) {
                  result[0] += 0.005740259040787178;
                } else {
                  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4277518309505331517) ) ) {
                    result[0] += 0.09311951807232605;
                  } else {
                    result[0] += 0.013933804809970427;
                  }
                }
              } else {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.09893965937729458371) ) ) {
                  result[0] += -0.023802930027911284;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05572100000000000664) ) ) {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8350000000000000755) ) ) {
                      result[0] += 0.010030605871739246;
                    } else {
                      result[0] += -0.02103709692637958;
                    }
                  } else {
                    result[0] += -0.007332636763611584;
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4613604846474264609) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0007670000000000001036) ) ) {
                result[0] += 0.015528505568950912;
              } else {
                result[0] += -0.03321743057935313;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6550000000000001377) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7214013188511664287) ) ) {
                  result[0] += -0.010530736523670174;
                } else {
                  result[0] += 0.0011350745578394784;
                }
              } else {
                result[0] += -0.030496259061877196;
              }
            }
          }
        } else {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.212199032544347022) ) ) {
            result[0] += 0.03283872305996208;
          } else {
            result[0] += 0.0021888233235799396;
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
          result[0] += 0.02212202814329543;
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6832193430923222399) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3837516359296482826) ) ) {
              result[0] += -0.021063295114439426;
            } else {
              result[0] += 0.005085438439078447;
            }
          } else {
            result[0] += 0.0132332576833782;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8820243969432238762) ) ) {
        result[0] += 0.02665093556344956;
      } else {
        result[0] += 0.04037779258383659;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6322976420381508644) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3789369143834280806) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2585695341105315181) ) ) {
        result[0] += -0.04219358188071142;
      } else {
        result[0] += -0.029896769949676695;
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7448583832663316917) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.029588714460048626) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += -0.004462459452967851;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0021995000000000005) ) ) {
              result[0] += -0.032478967285511466;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.741194024698492604) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6461954822149375) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.679632490452261373) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.287353500000000095) ) ) {
                      if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3362084851504864025) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4583473626633166043) ) ) {
                          result[0] += -0.007694725364352928;
                        } else {
                          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009632500000000000437) ) ) {
                            result[0] += 0.0002888240258145459;
                          } else {
                            result[0] += 0.0837246236245741;
                          }
                        }
                      } else {
                        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.07196201389915944657) ) ) {
                          result[0] += -0.027646779957021368;
                        } else {
                          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.0491948752242571466) ) ) {
                            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005037500000000001178) ) ) {
                              result[0] += -0.00760114845252575;
                            } else {
                              result[0] += 0.07685801635867039;
                            }
                          } else {
                            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02780400000000000579) ) ) {
                              result[0] += -0.02140204520003328;
                            } else {
                              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2089650038525997233) ) ) {
                                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.544739387236181094) ) ) {
                                  result[0] += -0.006049118236196566;
                                } else {
                                  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2610855058569431786) ) ) {
                                    result[0] += 0.07134560533714278;
                                  } else {
                                    result[0] += 0.004621555399855798;
                                  }
                                }
                              } else {
                                result[0] += -0.013896616747679596;
                              }
                            }
                          }
                        }
                      }
                    } else {
                      result[0] += 0.053244815291824614;
                    }
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5681735652491761712) ) ) {
                      result[0] += -0.03380394374087376;
                    } else {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5250000000000001332) ) ) {
                        result[0] += 0.09679302624991198;
                      } else {
                        result[0] += 0;
                      }
                    }
                  }
                } else {
                  result[0] += -0.033634894721095834;
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6461954822149375) ) ) {
                  result[0] += 0.12639252661891767;
                } else {
                  result[0] += -0.0253642421367;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7255694492462312351) ) ) {
            result[0] += 0;
          } else {
            result[0] += 0.07001668203126044;
          }
        }
      } else {
        result[0] += -0.029779213634309708;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8244912349994802936) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8678581689358929596) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7309551922231288801) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4516330415522763486) ) ) {
            result[0] += 0.0025592226782306157;
          } else {
            result[0] += -0.008439451783783329;
          }
        } else {
          result[0] += 0.000828610568550058;
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7369297863416220951) ) ) {
          result[0] += 0.007859285987851104;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001940500000000000167) ) ) {
            result[0] += 0.036230688408321145;
          } else {
            result[0] += 0.014780906536668668;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8820243969432238762) ) ) {
        result[0] += 0.026054291964085593;
      } else {
        result[0] += 0.040031560113744404;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6322976420381508644) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3789369143834280806) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2585695341105315181) ) ) {
        result[0] += -0.04205597148555887;
      } else {
        result[0] += -0.02942669126362742;
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7448583832663316917) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.029588714460048626) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4650000000000000244) ) ) {
              result[0] += -0.007282774521207142;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5613540176884422861) ) ) {
                result[0] += -0.0016631630505031172;
              } else {
                result[0] += 0.04841535533194307;
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0021995000000000005) ) ) {
              result[0] += -0.03201195177414547;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.741194024698492604) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.606193063154585432) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.679632490452261373) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.287353500000000095) ) ) {
                      if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
                        result[0] += 0.026296158320389344;
                      } else {
                        result[0] += -0.014006264323391285;
                      }
                    } else {
                      result[0] += 0.05331974044143355;
                    }
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5681735652491761712) ) ) {
                      result[0] += -0.03342099148550904;
                    } else {
                      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3521593390259187273) ) ) {
                        result[0] += 0.09060191956375765;
                      } else {
                        result[0] += -0.001577752543016587;
                      }
                    }
                  }
                } else {
                  result[0] += -0.032234074319125845;
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6461954822149375) ) ) {
                  result[0] += 0.11376510457840627;
                } else {
                  result[0] += -0.024989427064527454;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7255694492462312351) ) ) {
            result[0] += 0;
          } else {
            result[0] += 0.06441112222466414;
          }
        }
      } else {
        result[0] += -0.029265062630478216;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8244912349994802936) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9031544962109391284) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.755533006633860027) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4516330415522763486) ) ) {
            result[0] += 0.00337963158468781;
          } else {
            result[0] += -0.006239131216918647;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.626239805654523307) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8350000000000000755) ) ) {
              result[0] += 0.0023033372219056513;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
                result[0] += -0.06715625720347235;
              } else {
                result[0] += 0.0018601091674556739;
              }
            }
          } else {
            result[0] += 0.028813560145583214;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9815549730476619272) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001940500000000000167) ) ) {
            result[0] += 0.02643610939408053;
          } else {
            result[0] += 0.00882191808458382;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9450000000000000622) ) ) {
            result[0] += 0.03216878180030298;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01477650000000000144) ) ) {
              result[0] += -0.024378779127061816;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2929122217587940002) ) ) {
                result[0] += -0.029980711710383787;
              } else {
                result[0] += 0.018265873725177992;
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8820243969432238762) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9950000000000001066) ) ) {
          result[0] += 0.02844256088533883;
        } else {
          result[0] += 0.008477569623559524;
        }
      } else {
        result[0] += 0.03968526272843093;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.576775970879121469) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2753344786675505085) ) ) {
      result[0] += -0.04130563507635598;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7429456371859297636) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4649337835814208453) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.661556732613065468) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.09527124760910586632) ) ) {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.08316259990446585315) ) ) {
                result[0] += -0.013287275792777197;
              } else {
                result[0] += 0.08291984618184005;
              }
            } else {
              result[0] += -0.02797692896415248;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6408349166133754382) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01627850000000000477) ) ) {
                result[0] += -0.0012497708697736417;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3932044553488939775) ) ) {
                  result[0] += -0.003691006487183578;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06969450000000000645) ) ) {
                    result[0] += 0.12395336627143515;
                  } else {
                    result[0] += 0;
                  }
                }
              }
            } else {
              result[0] += -0.02721814159814404;
            }
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.285476170085738834) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
              result[0] += 0.04099572787084588;
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.07196201389915944657) ) ) {
                result[0] += -0.01649461719317353;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02780400000000000579) ) ) {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.0194836725655387448) ) ) {
                    result[0] += 0.029606935769033838;
                  } else {
                    result[0] += -0.009768245484221387;
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5665181981407035883) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5613540176884422861) ) ) {
                      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2900991079789891347) ) ) {
                        result[0] += -0.006357826765788293;
                      } else {
                        result[0] += 0.05023083291813175;
                      }
                    } else {
                      result[0] += 0.11072348043237308;
                    }
                  } else {
                    result[0] += 0.004628650201291608;
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.04755207441387177) ) ) {
              result[0] += -0.02247559155859542;
            } else {
              result[0] += 0.05051295989243662;
            }
          }
        }
      } else {
        result[0] += -0.03436967892018984;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8244912349994802936) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8583556158382011914) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7214013188511664287) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7050000000000000711) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.292381066124493438) ) ) {
              result[0] += -0.002606994494790341;
            } else {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3430002875097172832) ) ) {
                result[0] += -0.002072622231472112;
              } else {
                result[0] += 0.08330075962641142;
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              result[0] += -0.012764849711435699;
            } else {
              result[0] += 0.027117364179354758;
            }
          }
        } else {
          result[0] += 0.0002771119799528209;
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7369297863416220951) ) ) {
          result[0] += 0.0069286267533582935;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001940500000000000167) ) ) {
            result[0] += 0.035218621729039626;
          } else {
            result[0] += 0.01390077288387433;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8820243969432238762) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
          result[0] += 0.030910911893744713;
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8420098784315052098) ) ) {
            result[0] += -0.007753919411508484;
          } else {
            result[0] += 0.023693680366165377;
          }
        }
      } else {
        result[0] += 0.039338416416163695;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.576775970879121469) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2753344786675505085) ) ) {
      result[0] += -0.041141769274997554;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7429456371859297636) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4649337835814208453) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.661556732613065468) ) ) {
            result[0] += -0.026490097162690535;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6647571540201006046) ) ) {
              result[0] += 0.06958504857716764;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6408349166133754382) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5449349093854115589) ) ) {
                  result[0] += -0.02993889119096631;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3650000000000000466) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3932044553488939775) ) ) {
                      result[0] += 0.008727769577637025;
                    } else {
                      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.194179762471584888) ) ) {
                        result[0] += 0.12160314467327014;
                      } else {
                        result[0] += 0.0017250098911723035;
                      }
                    }
                  } else {
                    result[0] += -0.02170046397564185;
                  }
                }
              } else {
                result[0] += -0.027604245095314037;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.285476170085738834) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
              result[0] += 0.03856997641584873;
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.07196201389915944657) ) ) {
                result[0] += -0.016010512799425013;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02780400000000000579) ) ) {
                  result[0] += -0.005830090204056789;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5665181981407035883) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5613540176884422861) ) ) {
                      result[0] += 0.0268044102048932;
                    } else {
                      result[0] += 0.10113061006079505;
                    }
                  } else {
                    result[0] += 0.004425214342693069;
                  }
                }
              }
            }
          } else {
            result[0] += -0.02110995693588343;
          }
        }
      } else {
        result[0] += -0.03395648525743947;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8244912349994802936) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8635248854378615446) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7214013188511664287) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4327651086396848146) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2651510000000000811) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0629345000000000182) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.661556732613065468) ) ) {
                  result[0] += 0;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01076850000000000203) ) ) {
                    result[0] += -0.00809604948408539;
                  } else {
                    result[0] += 0.07263222831215402;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3950000000000000733) ) ) {
                  result[0] += 0.005587647840955288;
                } else {
                  result[0] += -0.026738719257933138;
                }
              }
            } else {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.337654390274954419) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3563645686964442283) ) ) {
                  result[0] += 0.038658922453839714;
                } else {
                  result[0] += -0.03632234855832259;
                }
              } else {
                result[0] += 0.07503271160383942;
              }
            }
          } else {
            result[0] += -0.00965610234486291;
          }
        } else {
          result[0] += 0.0003945380014492713;
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7369297863416220951) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8352912313316583903) ) ) {
            result[0] += 0.006321756436583175;
          } else {
            result[0] += 0.028283594125389982;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001940500000000000167) ) ) {
            result[0] += 0.03462981240923465;
          } else {
            result[0] += 0.013436754733006828;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8820243969432238762) ) ) {
        result[0] += 0.0243100109367108;
      } else {
        result[0] += 0.03899059032749884;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.576775970879121469) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2753344786675505085) ) ) {
      result[0] += -0.040976070856601654;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7429456371859297636) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4649337835814208453) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.661556732613065468) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.09527124760910586632) ) ) {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.08316259990446585315) ) ) {
                result[0] += -0.012219133066900922;
              } else {
                result[0] += 0.07913378538464472;
              }
            } else {
              result[0] += -0.027004678689738618;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6408349166133754382) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3650000000000000466) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3932044553488939775) ) ) {
                  result[0] += -0.0017628695369331566;
                } else {
                  result[0] += 0.05428518872004481;
                }
              } else {
                result[0] += -0.02581481511717029;
              }
            } else {
              result[0] += -0.026255998167033022;
            }
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.285476170085738834) ) ) {
            result[0] += -0.0031439911994398735;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5136684729854356091) ) ) {
              result[0] += -0.03712200952722752;
            } else {
              result[0] += -0.016061224633936878;
            }
          }
        }
      } else {
        result[0] += -0.033539412843641155;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8420098784315052098) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.649924828200234006) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7309551922231288801) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4327651086396848146) ) ) {
            result[0] += 0.00029517300474103626;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.647174411118524473) ) ) {
              result[0] += -0.017278338236575805;
            } else {
              result[0] += -0.005773746497667343;
            }
          }
        } else {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.212199032544347022) ) ) {
            result[0] += 0.028456228963353026;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8650000000000001021) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6532207681155780543) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001981500000000000188) ) ) {
                  result[0] += -0.018666856444877904;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3892782419974109565) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3459462384673366864) ) ) {
                      result[0] += -0.011080026463923151;
                    } else {
                      result[0] += 0.006135229634324361;
                    }
                  } else {
                    result[0] += -0.025085323382649547;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6461954822149375) ) ) {
                  result[0] += 0.029516206592498335;
                } else {
                  result[0] += 0.006834118353820458;
                }
              }
            } else {
              result[0] += -0.00042584638365411777;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9750977232358475355) ) ) {
            result[0] += 0.01431579468278609;
          } else {
            result[0] += 0.03185800279696368;
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7240566771921500555) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3459462384673366864) ) ) {
              result[0] += -0.02058025180472863;
            } else {
              result[0] += 0.006376234156383657;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7948589598137713041) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08122600000000000653) ) ) {
                  result[0] += 0.009499563402791305;
                } else {
                  result[0] += 0.02843826079569951;
                }
              } else {
                result[0] += 0.02238524513100935;
              }
            } else {
              result[0] += -0.004436224953337239;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9435227614686748643) ) ) {
        result[0] += 0.03059042335595667;
      } else {
        result[0] += 0.04147733960697706;
      }
    }
  }
}

