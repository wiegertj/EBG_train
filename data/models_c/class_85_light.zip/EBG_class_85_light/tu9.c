
#include "header.h"

void predict_unit9(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02500000000000000486) ) ) {
    result[0] += 0.10745073311636957;
  } else {
    result[0] += -0.00044261903016268425;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1594586647043804151) ) ) {
    result[0] += -0.13614637706883556;
  } else {
    result[0] += 0.0003488437370975788;
  }
  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002301545161532000071) ) ) {
    result[0] += 0.02237324770034303;
  } else {
    result[0] += -0.00198654534992181;
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002186500000000000509) ) ) {
    result[0] += -0.012184805020658574;
  } else {
    result[0] += 0.003814569652874865;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5714860158952760338) ) ) {
    result[0] += -0.006670961508414132;
  } else {
    result[0] += 0.006599980792768864;
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
    result[0] += 0.02053466776219741;
  } else {
    result[0] += -0.0022253779279301097;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5343557630381970958) ) ) {
    result[0] += -0.02162997170394616;
  } else {
    result[0] += 0.002163319511765242;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7050000000000000711) ) ) {
    result[0] += 0.011057928404211515;
  } else {
    result[0] += -0.0040098870407590395;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6194192625572763067) ) ) {
    result[0] += -0.01458703454482128;
  } else {
    result[0] += 0.0030337296023192004;
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9750000000000000888) ) ) {
    result[0] += 0.0013603938645863234;
  } else {
    result[0] += -0.03170908809714572;
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8892522691296157467) ) ) {
    result[0] += -0.0016498199433897607;
  } else {
    result[0] += 0.02925672425205615;
  }
  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.328486960647610404) ) ) {
    result[0] += 0.10650393232775908;
  } else {
    result[0] += -0.00040402522584633905;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.545000000000000151) ) ) {
    result[0] += 0.014424424372962475;
  } else {
    result[0] += -0.0029037860633479517;
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6277403467108452206) ) ) {
    result[0] += 0.00291048730837503;
  } else {
    result[0] += -0.013892789929140583;
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6722423356281408413) ) ) {
    result[0] += -0.003163356270678726;
  } else {
    result[0] += 0.012730187903134904;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5948284698255842384) ) ) {
    result[0] += -0.015224008704508159;
  } else {
    result[0] += 0.0026440891291898503;
  }
  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3750000000000000555) ) ) {
    result[0] += 0.015830682201048524;
  } else {
    result[0] += -0.0026005109921634273;
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8374809319095478655) ) ) {
    result[0] += 0.0007886348880642838;
  } else {
    result[0] += -0.04974711757182679;
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8158067323869347964) ) ) {
    result[0] += -0.0012769662532382746;
  } else {
    result[0] += 0.03264758059457547;
  }
}

