
#include "header.h"

void predict_unit9(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6798361838561514103) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4056437611611355964) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2086966242511653913) ) ) {
        result[0] += -0.04655890463091819;
      } else {
        result[0] += -0.036036561672714566;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5335728757895682461) ) ) {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.2084360867246362881) ) ) {
          result[0] += -0.009426076149758182;
        } else {
          result[0] += -0.031872552297965186;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5350000000000001421) ) ) {
          result[0] += -0.0063667362060801655;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003995500000000001654) ) ) {
            result[0] += -0.02557691864235224;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2157356523887877797) ) ) {
              result[0] += 0.0015778050055207343;
            } else {
              result[0] += -0.021521692870004862;
            }
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7930879927049911959) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.686605359504699142) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.064486481904431292) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006143500000000000523) ) ) {
            result[0] += -0.003123511726818032;
          } else {
            result[0] += 0.0044431623278371486;
          }
        } else {
          result[0] += -0.014138417262136316;
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9224430191215041708) ) ) {
          result[0] += 0.008460364141525541;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += 0.01868282734243669;
          } else {
            result[0] += -0.008444459722643637;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9046795177622769524) ) ) {
        result[0] += 0.03266036145727967;
      } else {
        result[0] += 0.04792038480399977;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6755187506907774919) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4056437611611355964) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2086966242511653913) ) ) {
        result[0] += -0.046413474732634054;
      } else {
        result[0] += -0.03554586833595014;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5335728757895682461) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3750000000000000555) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6574014915075377941) ) ) {
            result[0] += -0.022316550429471806;
          } else {
            result[0] += 0.0006160518343512742;
          }
        } else {
          result[0] += -0.03618670853763962;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5250000000000001332) ) ) {
          result[0] += -0.005942160720802479;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002861500000000000328) ) ) {
            result[0] += -0.026698951025580505;
          } else {
            result[0] += -0.011760316969673683;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7930879927049911959) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.874815099416885511) ) ) {
        result[0] += 0.00015718229790480815;
      } else {
        if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7220124598714527941) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
            if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6239583984657676163) ) ) {
              result[0] += 0.0074027106837526915;
            } else {
              result[0] += 0.02335395404382185;
            }
          } else {
            result[0] += 0.0037459939610015643;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += 0.020624231325745247;
          } else {
            result[0] += -0.010083321962218231;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9046795177622769524) ) ) {
        result[0] += 0.031956063116218986;
      } else {
        result[0] += 0.04760810939875455;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6574910164466515328) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4056437611611355964) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2086966242511653913) ) ) {
        result[0] += -0.04627015350894867;
      } else {
        result[0] += -0.03505044946227249;
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
        result[0] += -0.006121007747804654;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003260500000000000377) ) ) {
          result[0] += -0.03333249682648884;
        } else {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3313460023454675718) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4086612272110553001) ) ) {
              result[0] += -0.008809278867055109;
            } else {
              result[0] += 0.038201545275503186;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0446835897586253597) ) ) {
              result[0] += -0.020474300414076226;
            } else {
              result[0] += -0.0015820855476534647;
            }
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7930879927049911959) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.686605359504699142) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.097216905567068856) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006143500000000000523) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9494413002849252381) ) ) {
              result[0] += -0.005265542873906131;
            } else {
              result[0] += 0.022190580415363346;
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)257.5000000000000568) ) ) {
              result[0] += 0.006014028990252821;
            } else {
              result[0] += -0.007015551833884808;
            }
          }
        } else {
          result[0] += -0.014634703486835031;
        }
      } else {
        result[0] += 0.012124148858328064;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9046795177622769524) ) ) {
        result[0] += 0.03125726516259196;
      } else {
        result[0] += 0.047303031475838926;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6337772083671809886) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4056437611611355964) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2086966242511653913) ) ) {
        result[0] += -0.046128624324943863;
      } else {
        result[0] += -0.03455023345632388;
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
        result[0] += -0.0066341562228018095;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003260500000000000377) ) ) {
          result[0] += -0.03525439394495274;
        } else {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3313460023454675718) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4050000000000000822) ) ) {
              result[0] += -0.013583788960171728;
            } else {
              result[0] += 0.03492214467993955;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0446835897586253597) ) ) {
              result[0] += -0.0217658654794063;
            } else {
              result[0] += 0;
            }
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7930879927049911959) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8361854181907825145) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.850000000000000747e-05) ) ) {
          result[0] += 0.014411399058030851;
        } else {
          result[0] += -0.002870112820048752;
        }
      } else {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6845616084030620163) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8950000000000001288) ) ) {
            result[0] += 0.013651669989687186;
          } else {
            result[0] += 0.0026523182850611863;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9350000000000001643) ) ) {
            result[0] += 0.036898195885817754;
          } else {
            result[0] += 0.013659562662839315;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9046795177622769524) ) ) {
        result[0] += 0.030563793561556616;
      } else {
        result[0] += 0.04700432225301613;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6337772083671809886) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4056437611611355964) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2086966242511653913) ) ) {
        result[0] += -0.04598856146060362;
      } else {
        result[0] += -0.03404518634304463;
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
        result[0] += -0.006365727225599137;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003260500000000000377) ) ) {
          result[0] += -0.03470215785378157;
        } else {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3313460023454675718) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4086612272110553001) ) ) {
              result[0] += -0.011024310895662217;
            } else {
              result[0] += 0.03584157034994798;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0446835897586253597) ) ) {
              result[0] += -0.0211595684180191;
            } else {
              result[0] += 0;
            }
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7930879927049911959) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8361854181907825145) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7437931977386935678) ) ) {
          result[0] += -0.000717679925089603;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02410700000000000343) ) ) {
            result[0] += -0.0030046936437437824;
          } else {
            result[0] += -0.028433703202929362;
          }
        }
      } else {
        if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.75854359055901599) ) ) {
          result[0] += 0.005931439530835131;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += 0.016189688008946174;
          } else {
            result[0] += -0.008902285484483843;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9046795177622769524) ) ) {
        result[0] += 0.029875536887088546;
      } else {
        result[0] += 0.04671119871900931;
      }
    }
  }
}

