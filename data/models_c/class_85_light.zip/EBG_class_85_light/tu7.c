
#include "header.h"

void predict_unit7(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7058987689933927667) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4431477231260214644) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2585695341105315181) ) ) {
        result[0] += -0.04404139692516054;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02500000000000000486) ) ) {
          result[0] += -0.004538055867612611;
        } else {
          result[0] += -0.03495485052708679;
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5693020021745025527) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1550000000000000266) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.564198853668341882) ) ) {
              result[0] += -0.004974026832873562;
            } else {
              result[0] += 0.05790602968749308;
            }
          } else {
            result[0] += -0.018144345508611655;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2350000000000000144) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5091389307398357378) ) ) {
              result[0] += -0.03101678158073216;
            } else {
              result[0] += 0.025540616411022822;
            }
          } else {
            result[0] += -0.03132952960031786;
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7050000000000000711) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3750000000000000555) ) ) {
            if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.01022552087010519806) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5458973873869347182) ) ) {
                result[0] += 0.0023850589478031747;
              } else {
                result[0] += 0.07522797149812654;
              }
            } else {
              result[0] += -0.011740305016214288;
            }
          } else {
            result[0] += -0.010596048177196317;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6181495723579168988) ) ) {
            result[0] += -0.03551665140594207;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4175496798250740715) ) ) {
              result[0] += 0.037522250688636974;
            } else {
              result[0] += -0.01811378477053211;
            }
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7948589598137713041) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9031544962109391284) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8162318130682130191) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8450000000000000844) ) ) {
            result[0] += 0.002515243854049498;
          } else {
            result[0] += -0.004087605673659947;
          }
        } else {
          result[0] += 0.006307666129371017;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9815549730476619272) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9350000000000001643) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.649924828200234006) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.875000000000000111) ) ) {
                if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.05641065258394634824) ) ) {
                  result[0] += 0.0063172922531857;
                } else {
                  result[0] += 0.019862421724540818;
                }
              } else {
                result[0] += -0.03105511300904897;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001940500000000000167) ) ) {
                result[0] += 0.033381576646440814;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3459462384673366864) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2669585275879397535) ) ) {
                    result[0] += 0.031459890118734804;
                  } else {
                    result[0] += -0.026759359860534817;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2140805000000000347) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9660912024445539314) ) ) {
                      result[0] += 0.015841625449677058;
                    } else {
                      result[0] += 0.02959914742675615;
                    }
                  } else {
                    result[0] += 0.0389746191566646;
                  }
                }
              }
            }
          } else {
            result[0] += 0.0003872089001379187;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += 0.04172049170780308;
          } else {
            result[0] += 0.021005394502110076;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8723822823959714867) ) ) {
        result[0] += 0.03050165639097557;
      } else {
        result[0] += 0.04435933989864037;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7058987689933927667) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4431477231260214644) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2585695341105315181) ) ) {
        result[0] += -0.04388829736950939;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02500000000000000486) ) ) {
          result[0] += -0.004371018205852801;
        } else {
          result[0] += -0.03451599605775587;
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.565436264745754591) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4850000000000000422) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1650000000000000355) ) ) {
            result[0] += 0.00347460578486175;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5091389307398357378) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2293378059454632412) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5092601713187812074) ) ) {
                  result[0] += -0.018886355763198255;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6408349166133754382) ) ) {
                    result[0] += 0.11507096056278396;
                  } else {
                    result[0] += 0;
                  }
                }
              } else {
                result[0] += -0.030417872292005228;
              }
            } else {
              result[0] += -0.013120997144167082;
            }
          }
        } else {
          result[0] += -0.03351446617926302;
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7050000000000000711) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3317287208135251686) ) ) {
            result[0] += 0.009041492362574597;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5916566943077593566) ) ) {
              result[0] += -0.019139882208293053;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2250000000000000333) ) ) {
                result[0] += 0.03310538034484064;
              } else {
                result[0] += -0.006436860932421956;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6181495723579168988) ) ) {
            result[0] += -0.03555673771814266;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4175496798250740715) ) ) {
              result[0] += 0.03547904504439456;
            } else {
              result[0] += -0.017587092834645355;
            }
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7948589598137713041) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9031544962109391284) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8162318130682130191) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += 0.015729537145421624;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4850000000000000422) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5191847285678393709) ) ) {
                result[0] += -0.001338058977612297;
              } else {
                result[0] += 0.020528781975304177;
              }
            } else {
              result[0] += -0.0031071140664581066;
            }
          }
        } else {
          result[0] += 0.006038985973662003;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9815549730476619272) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9350000000000001643) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.649924828200234006) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.875000000000000111) ) ) {
                result[0] += 0.01231126728223004;
              } else {
                result[0] += -0.029552436857999378;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001386500000000000362) ) ) {
                result[0] += 0.03609865255518278;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2140805000000000347) ) ) {
                  result[0] += 0.01670399413099242;
                } else {
                  result[0] += 0.0354739933850464;
                }
              }
            }
          } else {
            result[0] += 0.0003709125593891679;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += 0.04099160645860233;
          } else {
            result[0] += 0.020359647353313404;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8723822823959714867) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9950000000000001066) ) ) {
          result[0] += 0.03140166220200063;
        } else {
          result[0] += 0.014385135215505733;
        }
      } else {
        result[0] += 0.0439560750020879;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7058987689933927667) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4431477231260214644) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2585695341105315181) ) ) {
        result[0] += -0.04373811451648791;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02500000000000000486) ) ) {
          result[0] += -0.004209620783243165;
        } else {
          result[0] += -0.03407440935136599;
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.561925680077866585) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2666807845679768918) ) ) {
          result[0] += -0.010318971507279218;
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02120850000000000166) ) ) {
            result[0] += -0.029682838046172753;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6549033795359899823) ) ) {
              result[0] += -0.006376583121239267;
            } else {
              result[0] += -0.032021539462701434;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3750000000000000555) ) ) {
          if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.01022552087010519806) ) ) {
            if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.07196201389915944657) ) ) {
              result[0] += -0.00025047658595355924;
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.04658055172941339556) ) ) {
                result[0] += 0.06970859626841718;
              } else {
                result[0] += 0.013507729422784298;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2446095000000000352) ) ) {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2492881011664858926) ) ) {
                result[0] += 0.03765542979984133;
              } else {
                result[0] += -0.018357254554534127;
              }
            } else {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.337654390274954419) ) ) {
                result[0] += -0.005679750216816308;
              } else {
                result[0] += 0.06713591526159449;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6181495723579168988) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7150000000000000799) ) ) {
              result[0] += -0.01825443085371034;
            } else {
              result[0] += -0.03760312892466392;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4327651086396848146) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4271265817983699864) ) ) {
                result[0] += -0.002385947170444493;
              } else {
                result[0] += 0.028585642217073028;
              }
            } else {
              result[0] += -0.014749852401150981;
            }
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7948589598137713041) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8956174930041188587) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7863566523687727239) ) ) {
          result[0] += -0.0023307497874114707;
        } else {
          result[0] += 0.00430966347720891;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9815549730476619272) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9350000000000001643) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.649924828200234006) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.875000000000000111) ) ) {
                result[0] += 0.01158559156043543;
              } else {
                result[0] += -0.025188689622437168;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2140805000000000347) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00129150000000000033) ) ) {
                  result[0] += 0.03218535510325625;
                } else {
                  result[0] += 0.015202425302694254;
                }
              } else {
                result[0] += 0.03560846226797451;
              }
            }
          } else {
            result[0] += 0.00035530062630630165;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += 0.04027891466510217;
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7093072464629580631) ) ) {
              result[0] += -0.03170530879025529;
            } else {
              result[0] += 0.02350775963480372;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8820243969432238762) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9950000000000001066) ) ) {
          result[0] += 0.031628330330055826;
        } else {
          result[0] += 0.015337528339755891;
        }
      } else {
        result[0] += 0.04395306346753982;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6964842473688145352) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4431477231260214644) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2585695341105315181) ) ) {
        result[0] += -0.043590523822262806;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02500000000000000486) ) ) {
          result[0] += -0.004053713814939423;
        } else {
          result[0] += -0.0336299243547604;
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.561925680077866585) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2666807845679768918) ) ) {
          result[0] += -0.009965124850882317;
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02120850000000000166) ) ) {
            result[0] += -0.02914463684159639;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6549033795359899823) ) ) {
              result[0] += -0.006137725343784934;
            } else {
              result[0] += -0.03151648389101865;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3750000000000000555) ) ) {
          if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.01022552087010519806) ) ) {
            if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.07196201389915944657) ) ) {
              result[0] += 0;
            } else {
              result[0] += 0.04071902883313447;
            }
          } else {
            result[0] += -0.010786675129089613;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5916566943077593566) ) ) {
            result[0] += -0.02610940129093339;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6450000000000001288) ) ) {
              result[0] += -0.0041214715083252055;
            } else {
              result[0] += -0.018495068493146565;
            }
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7948589598137713041) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.878151846485979104) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7728505831511113255) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4516330415522763486) ) ) {
            result[0] += 0.01019165759156621;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              result[0] += 0.01691040797157385;
            } else {
              result[0] += -0.005231144202609435;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6750000000000001554) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4148598843808023462) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5559328435427136617) ) ) {
                if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.07196201389915944657) ) ) {
                  result[0] += 0.0038113672440839375;
                } else {
                  result[0] += 0.024635297495254897;
                }
              } else {
                result[0] += -0.008548292401086066;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7099981828132028161) ) ) {
                result[0] += 0.03435306659644485;
              } else {
                result[0] += 0.008411583953523616;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.827186441538020012) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.7250000000000000888) ) ) {
                result[0] += -0.007722154315484716;
              } else {
                result[0] += 0.004517692480455889;
              }
            } else {
              result[0] += 0.004157585427997212;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9815549730476619272) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6832193430923222399) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
              result[0] += 0.012439216736703057;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8165121341708544422) ) ) {
                result[0] += -0.0015907273907821015;
              } else {
                result[0] += 0.04337409889906768;
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9550000000000000711) ) ) {
              result[0] += 0.017193811619398786;
            } else {
              result[0] += -0.00767887942087652;
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4420778732160803859) ) ) {
            result[0] += 0.014023874692479246;
          } else {
            result[0] += 0.035547728882458066;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8723822823959714867) ) ) {
        result[0] += 0.028415773441401587;
      } else {
        result[0] += 0.04317618635112043;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6964842473688145352) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4431477231260214644) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2585695341105315181) ) ) {
        result[0] += -0.04344521815751983;
      } else {
        result[0] += -0.03247699562269337;
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.561925680077866585) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2666807845679768918) ) ) {
          result[0] += -0.009620800187498906;
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02120850000000000166) ) ) {
            result[0] += -0.02860677945922836;
          } else {
            result[0] += -0.013532912297235005;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04301650000000000612) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
              result[0] += 0.053972764555084804;
            } else {
              result[0] += 0.007315367403910179;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2446095000000000352) ) ) {
              result[0] += -0.013632225230356291;
            } else {
              result[0] += 0.021079646658297126;
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7150000000000000799) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0629345000000000182) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04035600000000000992) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.564374608675820677) ) ) {
                  result[0] += -0.012852113564436855;
                } else {
                  result[0] += 0.004017958631620152;
                }
              } else {
                if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3674039732204867348) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3650000000000000466) ) ) {
                    result[0] += 0;
                  } else {
                    result[0] += 0.07953590889913535;
                  }
                } else {
                  result[0] += -0.006702691304077633;
                }
              }
            } else {
              result[0] += -0.03371534697515088;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6181495723579168988) ) ) {
              result[0] += -0.035610889570283036;
            } else {
              result[0] += -0.016697403041541683;
            }
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7948589598137713041) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9031544962109391284) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.827186441538020012) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += 0.014788391770081472;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4850000000000000422) ) ) {
              result[0] += 0.006817263107038517;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.755533006633860027) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6550000000000001377) ) ) {
                  result[0] += -0.00559850496980818;
                } else {
                  result[0] += -0.03040240134113426;
                }
              } else {
                result[0] += -0.00023630547199764498;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003360500000000000206) ) ) {
            result[0] += -0.0014945899373049478;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003787500000000000502) ) ) {
              result[0] += 0.02774591806079962;
            } else {
              result[0] += 0.00681192783954871;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9815549730476619272) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001940500000000000167) ) ) {
            result[0] += 0.027966314043761292;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9350000000000001643) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9590021414411925571) ) ) {
                result[0] += 0.011524508056387852;
              } else {
                result[0] += 0.02206379790294857;
              }
            } else {
              result[0] += -0.0001389124771102633;
            }
          }
        } else {
          result[0] += 0.02778085848029887;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8820243969432238762) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9950000000000001066) ) ) {
          result[0] += 0.030317230627060078;
        } else {
          result[0] += 0.013833536100003388;
        }
      } else {
        result[0] += 0.04320705433221661;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6964842473688145352) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4431477231260214644) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2585695341105315181) ) ) {
        result[0] += -0.043301896360091845;
      } else {
        result[0] += -0.03201380783819826;
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5380269784348243878) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3650000000000000466) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1550000000000000266) ) ) {
            result[0] += 0.008241817784394697;
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
              result[0] += 0.0364427542312906;
            } else {
              result[0] += -0.018176400513970556;
            }
          }
        } else {
          result[0] += -0.030730452593770784;
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7150000000000000799) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04401350000000000401) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.25500000000000006) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5580998554338508777) ) ) {
                  result[0] += 0.0078112846092335654;
                } else {
                  result[0] += 0.09956524842692688;
                }
              } else {
                result[0] += 0.002708075644699191;
              }
            } else {
              result[0] += -0.009673153783229806;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6181495723579168988) ) ) {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3474442649552166307) ) ) {
                result[0] += -0.009088154373569596;
              } else {
                result[0] += -0.023435408875711772;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0629345000000000182) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.467346322041485851) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6555524765326633529) ) ) {
                    result[0] += -0.0002255251752580521;
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4550000000000000711) ) ) {
                      result[0] += 0.0980342926500496;
                    } else {
                      result[0] += 0.009922889425544057;
                    }
                  }
                } else {
                  result[0] += -0.0155774566363464;
                }
              } else {
                result[0] += -0.03168825673312884;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6181495723579168988) ) ) {
            result[0] += -0.03595813307820915;
          } else {
            result[0] += -0.015830977266492824;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7948589598137713041) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9031544962109391284) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8065490128546884963) ) ) {
          result[0] += -0.0016591924635449805;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7350000000000000977) ) ) {
            result[0] += 0.017360215413083826;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.626239805654523307) ) ) {
              result[0] += 0.0034116617969558757;
            } else {
              result[0] += 0.03534038499858962;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9815549730476619272) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001940500000000000167) ) ) {
            result[0] += 0.027157280692975606;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9350000000000001643) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9590021414411925571) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3679208161557789292) ) ) {
                  result[0] += -0.0037229903304981616;
                } else {
                  result[0] += 0.012212034624952595;
                }
              } else {
                result[0] += 0.02139247494481071;
              }
            } else {
              result[0] += -0.00013303674855389934;
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += 0.038576469929715425;
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7093072464629580631) ) ) {
              result[0] += -0.03255052454546728;
            } else {
              result[0] += 0.02124794451509276;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8723822823959714867) ) ) {
        result[0] += 0.027062614858865405;
      } else {
        result[0] += 0.04242027832941355;
      }
    }
  }
}

