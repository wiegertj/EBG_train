
#include "header.h"

void predict_unit7(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1594586647043804151) ) ) {
    result[0] += -0.14443732111309746;
  } else {
    result[0] += 0.0004331321072813182;
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
    result[0] += 0.023666683832636686;
  } else {
    result[0] += -0.0025079915891045193;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5216735645817832667) ) ) {
    result[0] += -0.026740348095276527;
  } else {
    result[0] += 0.002468353344587526;
  }
  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02500000000000000486) ) ) {
    result[0] += 0.1246407731170803;
  } else {
    result[0] += -0.00048628182665036597;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2553983220265597653) ) ) {
    result[0] += -0.07175925630479262;
  } else {
    result[0] += 0.0008249797306662992;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8450000000000000844) ) ) {
    result[0] += 0.00946130957254588;
  } else {
    result[0] += -0.006223606531369989;
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6802643548677987928) ) ) {
    result[0] += -0.006242736761903628;
  } else {
    result[0] += 0.011643698900529197;
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9750000000000000888) ) ) {
    result[0] += 0.0015830187464756622;
  } else {
    result[0] += -0.03772958350674172;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9224700767327377315) ) ) {
    result[0] += -0.0009199381345732494;
  } else {
    result[0] += 0.06733674210686616;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7238160268635116523) ) ) {
    result[0] += -0.011254602568820543;
  } else {
    result[0] += 0.004974713858346935;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.545000000000000151) ) ) {
    result[0] += 0.018378975088594075;
  } else {
    result[0] += -0.0036438178172975926;
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4101030825879397046) ) ) {
    result[0] += -0.02027726789803359;
  } else {
    result[0] += 0.002622467708046656;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6246353589667689166) ) ) {
    result[0] += -0.01578152961908769;
  } else {
    result[0] += 0.0034224426425884785;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8650000000000001021) ) ) {
    result[0] += 0.00922731177113818;
  } else {
    result[0] += -0.006721646436986117;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6427554134465586211) ) ) {
    result[0] += -0.005006163598815084;
  } else {
    result[0] += 0.011218530706802544;
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
    result[0] += 0.022497913596098082;
  } else {
    result[0] += -0.002404311248266295;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4442092980514921186) ) ) {
    result[0] += -0.03253634514579328;
  } else {
    result[0] += 0.0017387587031791338;
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9750000000000000888) ) ) {
    result[0] += 0.0014772231738911803;
  } else {
    result[0] += -0.03485550062355632;
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8538728410170577376) ) ) {
    result[0] += -0.0022971691581927726;
  } else {
    result[0] += 0.026403605935758873;
  }
}

