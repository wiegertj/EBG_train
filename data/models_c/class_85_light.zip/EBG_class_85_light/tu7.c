
#include "header.h"

void predict_unit7(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.720877625841553682) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4977750020140985776) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2703145439280746909) ) ) {
        result[0] += -0.04737560724240321;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += -0.027743697373031367;
        } else {
          result[0] += -0.03970961481118616;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6003075279628945493) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5650000000000000577) ) ) {
          result[0] += -0.019960840547794307;
        } else {
          result[0] += -0.03525209092331038;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7150000000000000799) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06334000000000002129) ) ) {
            result[0] += -0.00257969148195078;
          } else {
            result[0] += -0.02093681416046588;
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6574910164466515328) ) ) {
            result[0] += -0.03052986994681574;
          } else {
            result[0] += -0.015012234529930196;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8299157965154307925) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8361854181907825145) ) ) {
        result[0] += -1.4148593578467775e-05;
      } else {
        if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.751334311843480207) ) ) {
          result[0] += 0.011224553280593871;
        } else {
          result[0] += 0.021440649596579653;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8999934911843509022) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
          result[0] += 0.03927511586810718;
        } else {
          if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8221629459601094148) ) ) {
            result[0] += -0.005607331805660991;
          } else {
            result[0] += 0.03460769968956734;
          }
        }
      } else {
        result[0] += 0.05145287384578161;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.720877625841553682) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4977750020140985776) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2703145439280746909) ) ) {
        result[0] += -0.0471585407659647;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += -0.027117052221246708;
        } else {
          result[0] += -0.03921491679966891;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6003075279628945493) ) ) {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.2705909127498113409) ) ) {
          result[0] += -0.011759624320569697;
        } else {
          result[0] += -0.028143443330092947;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7150000000000000799) ) ) {
          result[0] += -0.006014115371634353;
        } else {
          result[0] += -0.019479279203690025;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7930879927049911959) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8903263421033805747) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8361854181907825145) ) ) {
          result[0] += -1.3501660531925766e-05;
        } else {
          result[0] += 0.009067044818754595;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
          if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8299157965154307925) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001688500000000000114) ) ) {
              result[0] += 0.03593787716118031;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
                result[0] += 0.022116805001981547;
              } else {
                result[0] += 0.011069920720998619;
              }
            }
          } else {
            result[0] += 0.03301917317020886;
          }
        } else {
          result[0] += -0.007074860163834088;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9046795177622769524) ) ) {
        result[0] += 0.03931434653200316;
      } else {
        result[0] += 0.05122095421620286;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.720877625841553682) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4776960828135016768) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2703145439280746909) ) ) {
        result[0] += -0.046946068641852585;
      } else {
        result[0] += -0.036226895071496575;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6003075279628945493) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4450000000000000622) ) ) {
          result[0] += -0.01681765370264655;
        } else {
          result[0] += -0.03038271460747434;
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.795000000000000151) ) ) {
          result[0] += -0.007662177063163766;
        } else {
          result[0] += -0.021320024542129633;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7930879927049911959) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.686605359504699142) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8450000000000000844) ) ) {
          if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5800805484233819698) ) ) {
            result[0] += 0.0029808748463407164;
          } else {
            result[0] += 0.01689866489464441;
          }
        } else {
          if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5546395296003079345) ) ) {
            result[0] += -0.01075050282267368;
          } else {
            result[0] += 0.0012248874849361193;
          }
        }
      } else {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6845616084030620163) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
            result[0] += 0.01734152595224789;
          } else {
            result[0] += 0.003999744233665999;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
            result[0] += 0.03134281667654649;
          } else {
            result[0] += 0.01886065099905756;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9046795177622769524) ) ) {
        result[0] += 0.038539212949160996;
      } else {
        result[0] += 0.05079636264812041;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.720877625841553682) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4776960828135016768) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2703145439280746909) ) ) {
        result[0] += -0.046737643693008035;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += -0.02594324506292952;
        } else {
          result[0] += -0.03906636582374466;
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6003075279628945493) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4450000000000000622) ) ) {
          result[0] += -0.016266035077867544;
        } else {
          result[0] += -0.02972589105491841;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7150000000000000799) ) ) {
          result[0] += -0.005438526852141452;
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6574910164466515328) ) ) {
            result[0] += -0.029062968758570455;
          } else {
            result[0] += -0.013141950441063043;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7930879927049911959) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8903263421033805747) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8305400774473623571) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)538.5000000000001137) ) ) {
            result[0] += 0.000536287814350134;
          } else {
            result[0] += -0.021014565383008138;
          }
        } else {
          result[0] += 0.00790715204407553;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
          if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7868431215179150229) ) ) {
            result[0] += 0.013975857474609709;
          } else {
            result[0] += 0.025457254637266825;
          }
        } else {
          result[0] += -0.007617561343774561;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9046795177622769524) ) ) {
        result[0] += 0.037775049486918955;
      } else {
        result[0] += 0.05038943358978893;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.720877625841553682) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4648868838492359878) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2478670645711959775) ) ) {
        result[0] += -0.04689852833499703;
      } else {
        result[0] += -0.036081003668309644;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5606360583019965871) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3850000000000000644) ) ) {
          result[0] += -0.01596334926369874;
        } else {
          result[0] += -0.03313366860519986;
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2750000000000000777) ) ) {
          result[0] += 0.0074776358572531615;
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)7.839179265242341959e-06) ) ) {
            result[0] += 0.0019064928253602828;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002412500000000000581) ) ) {
              result[0] += -0.025989051611589327;
            } else {
              result[0] += -0.011557357562138644;
            }
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7930879927049911959) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.686605359504699142) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1259525496914888076) ) ) {
          result[0] += 0.00539019724960837;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1275350000000000372) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7650000000000001243) ) ) {
              result[0] += 0.01780724671033765;
            } else {
              result[0] += -0.004043706221390602;
            }
          } else {
            result[0] += -0.024115459443437914;
          }
        }
      } else {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6845616084030620163) ) ) {
          result[0] += 0.01062444607065375;
        } else {
          result[0] += 0.02043881499638968;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9046795177622769524) ) ) {
        result[0] += 0.037020810874562673;
      } else {
        result[0] += 0.04999863909339446;
      }
    }
  }
}

