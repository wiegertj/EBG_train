
#include "header.h"

void predict_unit14(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.25500000000000006) ) ) {
    result[0] += 0.021541217482371044;
  } else {
    result[0] += -0.00165319041386246;
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.09500000000000001499) ) ) {
    result[0] += -0.050511948668076664;
  } else {
    result[0] += 0.0006141230291766423;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7850000000000001421) ) ) {
    result[0] += 0.007819832284464723;
  } else {
    result[0] += -0.003942461603334613;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5458816983076056895) ) ) {
    result[0] += -0.006578098393089743;
  } else {
    result[0] += 0.005145790460664645;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8950000000000001288) ) ) {
    result[0] += 0.005908202663883506;
  } else {
    result[0] += -0.0051630048321524135;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6009522974168109988) ) ) {
    result[0] += -0.004875808208625521;
  } else {
    result[0] += 0.006490929243697511;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
    result[0] += 0.0037542014011051773;
  } else {
    result[0] += -0.008338532063246038;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6427554134465586211) ) ) {
    result[0] += -0.0036513176326094313;
  } else {
    result[0] += 0.00821270381461658;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8428035383058734009) ) ) {
    result[0] += 0.005021411849358038;
  } else {
    result[0] += -0.006640438274577374;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5948284698255842384) ) ) {
    result[0] += -0.013246018641973271;
  } else {
    result[0] += 0.0022815490227405303;
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
    result[0] += 0.016835565558655067;
  } else {
    result[0] += -0.0018431665072042448;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5216735645817832667) ) ) {
    result[0] += -0.01815056188960671;
  } else {
    result[0] += 0.001617834398952683;
  }
  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1850000000000000255) ) ) {
    result[0] += 0.026322970407459966;
  } else {
    result[0] += -0.001199373504851982;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3936276107755155018) ) ) {
    result[0] += -0.028087202061673883;
  } else {
    result[0] += 0.0010125778351885654;
  }
  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02500000000000000486) ) ) {
    result[0] += 0.0835914559296829;
  } else {
    result[0] += -0.0003756295176031399;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2553983220265597653) ) ) {
    result[0] += -0.05280386723411189;
  } else {
    result[0] += 0.0005411647960562767;
  }
  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3750000000000000555) ) ) {
    result[0] += 0.013629876328128605;
  } else {
    result[0] += -0.002266294908706036;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5458816983076056895) ) ) {
    result[0] += -0.00624330512590677;
  } else {
    result[0] += 0.0048789820890017075;
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.850000000000000659e-05) ) ) {
    result[0] += 0.019006458161916682;
  } else {
    result[0] += -0.0015860066671733344;
  }
}

