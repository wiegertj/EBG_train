
#include "header.h"

void predict_unit14(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4514795106568756933) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2086966242511653913) ) ) {
      result[0] += -0.04297381357276984;
    } else {
      result[0] += -0.02126653063609082;
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8604095077903387567) ) ) {
      if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6845616084030620163) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6337772083671809886) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5250000000000001332) ) ) {
            result[0] += -0.003353418869970164;
          } else {
            result[0] += -0.0169759848658431;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8650000000000001021) ) ) {
            if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6692466953510638472) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6574014915075377941) ) ) {
                result[0] += 4.9907939814105175e-05;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6413622072216433878) ) ) {
                  result[0] += 0.03759782234595739;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007045500000000000547) ) ) {
                    result[0] += 0.029383272451056777;
                  } else {
                    result[0] += -0.008971594694560934;
                  }
                }
              }
            } else {
              result[0] += 0.020219675483420324;
            }
          } else {
            if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5496233189177238687) ) ) {
              result[0] += -0.01314330421381646;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0002862198891947500493) ) ) {
                result[0] += 0.019903775601485464;
              } else {
                result[0] += -0.0004850311471548635;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9350000000000001643) ) ) {
          result[0] += 0.02939561313890888;
        } else {
          result[0] += 0.007428751585938377;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9466345864481623407) ) ) {
        result[0] += 0.026538789379328125;
      } else {
        result[0] += 0.04432070480896333;
      }
    }
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4514795106568756933) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2086966242511653913) ) ) {
      result[0] += -0.04279872206583914;
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
        result[0] += 0.024457736216866224;
      } else {
        result[0] += -0.021714892316191805;
      }
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8604095077903387567) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.751334311843480207) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6524156763781451263) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5250000000000001332) ) ) {
            result[0] += -0.002506501054139075;
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.552787391059560318) ) ) {
              result[0] += -0.03001244322849968;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7350000000000000977) ) ) {
                result[0] += -0.004163773056613237;
              } else {
                result[0] += -0.02134558538110855;
              }
            }
          }
        } else {
          result[0] += 0.0004638106239312153;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001688500000000000114) ) ) {
          result[0] += 0.02406013530875334;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6277403467108452206) ) ) {
              result[0] += 0.02182520796625157;
            } else {
              result[0] += -0.012162798557489505;
            }
          } else {
            if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7667511984859548546) ) ) {
              result[0] += -0.0021069345644440262;
            } else {
              result[0] += 0.011541090663675292;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9466345864481623407) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06877500000000001668) ) ) {
          result[0] += 0.031222950564592337;
        } else {
          result[0] += 0.008329822091265007;
        }
      } else {
        result[0] += 0.044133259539381964;
      }
    }
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4056437611611355964) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2044224800093838168) ) ) {
      result[0] += -0.04278651030328627;
    } else {
      result[0] += -0.022537307928451267;
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8604095077903387567) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6524156763781451263) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3850000000000000644) ) ) {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.07129835413750022777) ) ) {
            result[0] += -0.014437909931714033;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.051391296366422923) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1850000000000000255) ) ) {
                result[0] += 0.039428153130345735;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0539933149742303567) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.207561075208746717e-05) ) ) {
                    result[0] += 0.016587711816719433;
                  } else {
                    result[0] += -0.009554865172442504;
                  }
                } else {
                  result[0] += 0.06626797163973097;
                }
              }
            } else {
              result[0] += -0.021862018352238263;
            }
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5203205671504794738) ) ) {
            result[0] += -0.03045184930406011;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7250000000000000888) ) ) {
              result[0] += -0.004720749496809292;
            } else {
              result[0] += -0.020523193368578437;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7220124598714527941) ) ) {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
            result[0] += 0.018791301280160704;
          } else {
            result[0] += 0.00045028077592932595;
          }
        } else {
          result[0] += 0.009506625323138672;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9466345864481623407) ) ) {
        result[0] += 0.025377117511242924;
      } else {
        result[0] += 0.043943849165528535;
      }
    }
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4056437611611355964) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2044224800093838168) ) ) {
      result[0] += -0.042608601537625274;
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
        result[0] += 0.025295436868174922;
      } else {
        result[0] += -0.023536936916088005;
      }
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8604095077903387567) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6890377340803973683) ) ) {
        if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.197062569726642739) ) ) {
          result[0] += 0.033984644307209086;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003260500000000000377) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
              result[0] += -0.0007515487306514737;
            } else {
              result[0] += -0.02018615047329821;
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3313460023454675718) ) ) {
              if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4026472078210281969) ) ) {
                result[0] += 0.004859808007666474;
              } else {
                result[0] += 0.05005464179530711;
              }
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.08835747683243963535) ) ) {
                result[0] += -0.021873447246437163;
              } else {
                result[0] += -0.0029110646398326006;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7539078735793690589) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9450000000000000622) ) ) {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9606460023648795143) ) ) {
              result[0] += 0.001247986954906513;
            } else {
              result[0] += 0.019120193414852348;
            }
          } else {
            result[0] += -0.017656733988286613;
          }
        } else {
          result[0] += 0.011081752123299078;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9466345864481623407) ) ) {
        result[0] += 0.024796127793735953;
      } else {
        result[0] += 0.04375215503310253;
      }
    }
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4242445369002922351) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2086966242511653913) ) ) {
      result[0] += -0.04224758454284859;
    } else {
      result[0] += -0.020370233085558336;
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8604095077903387567) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5800805484233819698) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9050000000000001377) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6003075279628945493) ) ) {
            if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.2004497084506273452) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.02221682296857134878) ) ) {
                result[0] += -0.013878150597893282;
              } else {
                result[0] += 0.02741822660196798;
              }
            } else {
              result[0] += -0.01127121565814779;
            }
          } else {
            result[0] += -7.318700786726005e-05;
          }
        } else {
          result[0] += -0.02141919038486523;
        }
      } else {
        if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7539078735793690589) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7150000000000000799) ) ) {
            result[0] += 0.02359018158999736;
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3640888533806194149) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9750000000000000888) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4121012012060301655) ) ) {
                  if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5706767343356877742) ) ) {
                    result[0] += -0.008205461709823926;
                  } else {
                    result[0] += 0.018055540824054545;
                  }
                } else {
                  result[0] += 0.03046306422927794;
                }
              } else {
                result[0] += 0.0006048283875882353;
              }
            } else {
              result[0] += 3.965065769766471e-05;
            }
          }
        } else {
          result[0] += 0.010668321303002033;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9466345864481623407) ) ) {
        result[0] += 0.024216734535064458;
      } else {
        result[0] += 0.043557864483180914;
      }
    }
  }
}

