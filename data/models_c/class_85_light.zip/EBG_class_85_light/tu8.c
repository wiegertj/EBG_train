
#include "header.h"

void predict_unit8(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9718823371143295864) ) ) {
    result[0] += -0.00037011000010908943;
  } else {
    result[0] += 0.13842138890885117;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8050000000000001599) ) ) {
    result[0] += 0.009628904006062101;
  } else {
    result[0] += -0.005242471168278173;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6501267983073132362) ) ) {
    result[0] += -0.014509380444810186;
  } else {
    result[0] += 0.003754490210681028;
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4850000000000000422) ) ) {
    result[0] += 0.0179608592768764;
  } else {
    result[0] += -0.0028839595388315286;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7238160268635116523) ) ) {
    result[0] += -0.010597500260264342;
  } else {
    result[0] += 0.004667802839215453;
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9750000000000000888) ) ) {
    result[0] += 0.0014660812424163233;
  } else {
    result[0] += -0.034282256329784024;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8447186612272684636) ) ) {
    result[0] += -0.0015066873697647996;
  } else {
    result[0] += 0.03495074475471422;
  }
  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.13900392495124092) ) ) {
    result[0] += 0.05021328793635542;
  } else {
    result[0] += -0.0009611318381341287;
  }
  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5724391781153673753) ) ) {
    result[0] += -0.023942772546934946;
  } else {
    result[0] += 0.002080671505667036;
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8374809319095478655) ) ) {
    result[0] += 0.0008932200623531356;
  } else {
    result[0] += -0.05484418987844774;
  }
  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02500000000000000486) ) ) {
    result[0] += 0.10934568670425869;
  } else {
    result[0] += -0.00043903754395775783;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1594586647043804151) ) ) {
    result[0] += -0.1419785857487928;
  } else {
    result[0] += 0.0004018095819498804;
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8158067323869347964) ) ) {
    result[0] += -0.0013741292211995738;
  } else {
    result[0] += 0.03508128807536707;
  }
  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3640888533806194149) ) ) {
    result[0] += 0.015236069366192435;
  } else {
    result[0] += -0.003040385934294641;
  }
  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.08835747683243963535) ) ) {
    result[0] += -0.009899317395487795;
  } else {
    result[0] += 0.004945371718070228;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
    result[0] += 0.004989453777993354;
  } else {
    result[0] += -0.009241614846595225;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6009522974168109988) ) ) {
    result[0] += -0.006126918643872177;
  } else {
    result[0] += 0.00816022864010981;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8650000000000001021) ) ) {
    result[0] += 0.008028251036186682;
  } else {
    result[0] += -0.005878065726142297;
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1450000000000000455) ) ) {
    result[0] += -0.04680070949333675;
  } else {
    result[0] += 0.000994020741828085;
  }
}

