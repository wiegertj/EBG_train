
#include "header.h"

void predict_unit8(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.720877625841553682) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4648868838492359878) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2478670645711959775) ) ) {
        result[0] += -0.046710725032140354;
      } else {
        result[0] += -0.03554990388827918;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5606360583019965871) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3850000000000000644) ) ) {
          result[0] += -0.015439388643934937;
        } else {
          result[0] += -0.03251892708856089;
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7150000000000000799) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.405847175991340292e-06) ) ) {
            result[0] += 0.013234607703952442;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002675500000000000361) ) ) {
              result[0] += -0.02233508249219133;
            } else {
              result[0] += -0.005950144036172453;
            }
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6230900802800999339) ) ) {
            result[0] += -0.03776556667076256;
          } else {
            result[0] += -0.014584453591225987;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7930879927049911959) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8943082925133570837) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8361854181907825145) ) ) {
          result[0] += -0.0001602131799529594;
        } else {
          result[0] += 0.007796959677206759;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
          if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8299157965154307925) ) ) {
            result[0] += 0.015603878223807379;
          } else {
            result[0] += 0.03031438656093503;
          }
        } else {
          result[0] += -0.008195479643124438;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9046795177622769524) ) ) {
        result[0] += 0.036275577796105116;
      } else {
        result[0] += 0.04962257707988216;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7108706770295533106) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4514795106568756933) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2478670645711959775) ) ) {
        result[0] += -0.046526140476363005;
      } else {
        result[0] += -0.03547609102106889;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5606360583019965871) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3750000000000000555) ) ) {
          result[0] += -0.014645706952622139;
        } else {
          result[0] += -0.03270603032944144;
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.795000000000000151) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03580753183574705845) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06877500000000001668) ) ) {
              result[0] += -0.010471228179911323;
            } else {
              result[0] += -0.04081218530735832;
            }
          } else {
            result[0] += 0.002824956905568145;
          }
        } else {
          if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5496233189177238687) ) ) {
            result[0] += -0.025330539210947512;
          } else {
            result[0] += 0.006782722084393651;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7930879927049911959) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8943082925133570837) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8305400774473623571) ) ) {
          result[0] += -0.0006378354241166494;
        } else {
          result[0] += 0.007121538735329085;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
          if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8299157965154307925) ) ) {
            result[0] += 0.014985398453717132;
          } else {
            result[0] += 0.029487707149506368;
          }
        } else {
          result[0] += -0.007790983727210063;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9046795177622769524) ) ) {
        result[0] += 0.03553855645284628;
      } else {
        result[0] += 0.04925992885323842;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7055997140865902795) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4056437611611355964) ) ) {
      result[0] += -0.042911536618452636;
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.552787391059560318) ) ) {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.2084360867246362881) ) ) {
          result[0] += -0.00972884483448061;
        } else {
          result[0] += -0.031015914539572982;
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.25500000000000006) ) ) {
          result[0] += 0.01038615717670919;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06334000000000002129) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007442500000000000331) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.009547252630452171e-05) ) ) {
                result[0] += -1.8550905044504056e-05;
              } else {
                result[0] += -0.022045568270049474;
              }
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3313460023454675718) ) ) {
                result[0] += 0.02332021398120285;
              } else {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.08835747683243963535) ) ) {
                  result[0] += -0.028939352224881157;
                } else {
                  result[0] += -0.0017552513677411606;
                }
              }
            }
          } else {
            result[0] += -0.034182113183894205;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7930879927049911959) ) ) {
      if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6845616084030620163) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8361854181907825145) ) ) {
          result[0] += -0.0006205764463827386;
        } else {
          result[0] += 0.007988556006620273;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
          result[0] += 0.01972646834770488;
        } else {
          result[0] += -0.008648629608994167;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9046795177622769524) ) ) {
        result[0] += 0.03480905546469023;
      } else {
        result[0] += 0.04890948625939607;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7055997140865902795) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4056437611611355964) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2086966242511653913) ) ) {
        result[0] += -0.046857499251911794;
      } else {
        result[0] += -0.037004259905695926;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.552787391059560318) ) ) {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.2084360867246362881) ) ) {
          result[0] += -0.009364944628881055;
        } else {
          result[0] += -0.03040925503483307;
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.795000000000000151) ) ) {
          result[0] += -0.009304546567620258;
        } else {
          result[0] += -0.022280889339719688;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7930879927049911959) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.686605359504699142) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.762515391896329886) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006143500000000000523) ) ) {
            result[0] += -0.0029546936683584094;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)15.50000000000000178) ) ) {
              result[0] += -0.006919336986926906;
            } else {
              result[0] += 0.008743996514436731;
            }
          }
        } else {
          result[0] += -0.008178549071746954;
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9120665648705957862) ) ) {
          result[0] += 0.008268613285662321;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
            result[0] += 0.024695088396975783;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003825500000000000341) ) ) {
              result[0] += 0.03018141621628773;
            } else {
              result[0] += 0.00987036097305961;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9046795177622769524) ) ) {
        result[0] += 0.034086498896684865;
      } else {
        result[0] += 0.048570109437836934;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6890377340803973683) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4056437611611355964) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2086966242511653913) ) ) {
        result[0] += -0.04670679759432593;
      } else {
        result[0] += -0.03652264309416974;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.552787391059560318) ) ) {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.2084360867246362881) ) ) {
          result[0] += -0.009011903141989843;
        } else {
          result[0] += -0.02980254431301096;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006912000000000000609) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.009547252630452171e-05) ) ) {
            result[0] += -0.00034956026179730216;
          } else {
            result[0] += -0.022945863972550974;
          }
        } else {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2883407947516276049) ) ) {
            result[0] += 0.021957472237299557;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6552417783486498282) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.08835747683243963535) ) ) {
                result[0] += -0.025365984254310383;
              } else {
                result[0] += 0.000992695400722288;
              }
            } else {
              result[0] += -0.02725277456258684;
            }
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7930879927049911959) ) ) {
      if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6845616084030620163) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8361854181907825145) ) ) {
          result[0] += -0.0010120955190966406;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8950000000000001288) ) ) {
            result[0] += 0.015029760973964959;
          } else {
            result[0] += 0.003816066195621631;
          }
        }
      } else {
        result[0] += 0.017265543739734917;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9046795177622769524) ) ) {
        result[0] += 0.033370401339856665;
      } else {
        result[0] += 0.048240740740005277;
      }
    }
  }
}

