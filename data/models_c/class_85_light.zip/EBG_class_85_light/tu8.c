
#include "header.h"

void predict_unit8(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6809682101532212872) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4431477231260214644) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2585695341105315181) ) ) {
        result[0] += -0.04316026329015275;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02500000000000000486) ) ) {
          result[0] += -0.0014482770644541848;
        } else {
          result[0] += -0.03229783917569682;
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5380269784348243878) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3650000000000000466) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1550000000000000266) ) ) {
            result[0] += 0.00785501711746584;
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
              result[0] += 0.0344990308860443;
            } else {
              result[0] += -0.01766938001074692;
            }
          }
        } else {
          result[0] += -0.03022179125446497;
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.545000000000000151) ) ) {
          result[0] += -0.005171701877425506;
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006064500000000001313) ) ) {
            result[0] += -0.021897215794167573;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.341491527034325726) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2089650038525997233) ) ) {
                if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3072230169823056412) ) ) {
                  result[0] += 0.06509847289211804;
                } else {
                  result[0] += -0.00481004232490754;
                }
              } else {
                result[0] += -0.01955275681005554;
              }
            } else {
              result[0] += 0.03788127004185143;
            }
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.799703292181055736) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.649924828200234006) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8635248854378615446) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.480405183437169869) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7810201528643216928) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.013855723816631915) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007070500000000001263) ) ) {
                  result[0] += -0.0035740521603367975;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7690514563494603717) ) ) {
                    result[0] += -0.001796251733793314;
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.008262500000000000747) ) ) {
                      result[0] += 0.02387041629354476;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.7050000000000000711) ) ) {
                        result[0] += 0.006837996421936167;
                      } else {
                        result[0] += -0.008350138776716151;
                      }
                    }
                  }
                }
              } else {
                result[0] += 0.028067002989916486;
              }
            } else {
              result[0] += -0.014031536793922016;
            }
          } else {
            result[0] += 0.018858695983373707;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7617737907239344741) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9443572767030988802) ) ) {
              result[0] += 0.006202027802425711;
            } else {
              result[0] += 0.021289108091188128;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03221500000000000752) ) ) {
              result[0] += -0.05055119437130819;
            } else {
              result[0] += 0.011646444256600661;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
          result[0] += 0.02615205121026581;
        } else {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.5329091955564501104) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9064470225912234502) ) ) {
              result[0] += -0.02269952174078728;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001463500000000000174) ) ) {
                result[0] += 0.03727225617973627;
              } else {
                result[0] += 0.0005054732265204819;
              }
            }
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6832193430923222399) ) ) {
              result[0] += 0.007040067443417462;
            } else {
              result[0] += 0.0163744541685052;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8820243969432238762) ) ) {
        result[0] += 0.027710617842856503;
      } else {
        result[0] += 0.042483371546949505;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6809682101532212872) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4431477231260214644) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2585695341105315181) ) ) {
        result[0] += -0.04302004658496354;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02500000000000000486) ) ) {
          result[0] += -0.0013918320817932137;
        } else {
          result[0] += -0.03184087457887672;
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5380269784348243878) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2514965760088692104) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3966559369710560001) ) ) {
            result[0] += -0.012380891471721615;
          } else {
            result[0] += 0.01356244712110332;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002158500000000000262) ) ) {
            result[0] += -0.0372507706094176;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6300691579881073645) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7071981171356784834) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01340550000000000248) ) ) {
                  result[0] += -0.023948546880176783;
                } else {
                  result[0] += -0.006578880392041508;
                }
              } else {
                result[0] += 0.08805575144380384;
              }
            } else {
              result[0] += -0.03541262833307302;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.545000000000000151) ) ) {
          result[0] += -0.004969360229506256;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.576775970879121469) ) ) {
            result[0] += -0.030108118599962357;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4123407126900383024) ) ) {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.337654390274954419) ) ) {
                result[0] += -0.018056025131553972;
              } else {
                if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3474442649552166307) ) ) {
                  result[0] += 0.051838923329386506;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6750000000000001554) ) ) {
                    result[0] += -0.016570118768779275;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6235885071751546826) ) ) {
                      result[0] += -0.011770629975081742;
                    } else {
                      result[0] += 0.07716078211198543;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.016779125014599765;
            }
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8244912349994802936) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.649924828200234006) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8016764265861101579) ) ) {
          result[0] += -0.002125620627153747;
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9550000000000000711) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9228588940825653841) ) ) {
              result[0] += 0.00497343841870609;
            } else {
              result[0] += 0.016580567625992238;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01595600000000000143) ) ) {
              result[0] += 0.0036297864648785266;
            } else {
              result[0] += -0.00759512600549255;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
          result[0] += 0.02537236019577454;
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7093072464629580631) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3459462384673366864) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.304333331356783976) ) ) {
                result[0] += 0.004084594676095465;
              } else {
                result[0] += -0.052402613460107356;
              }
            } else {
              result[0] += 0.008424175277131785;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9150000000000001465) ) ) {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7889148352316185386) ) ) {
                result[0] += 0.018653505530553532;
              } else {
                result[0] += 0.03654846758620803;
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8265253025055979696) ) ) {
                result[0] += -0.005093185755617498;
              } else {
                result[0] += 0.014707039719417295;
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8820243969432238762) ) ) {
        result[0] += 0.029703947991904796;
      } else {
        result[0] += 0.042126148834199614;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6623732216749412816) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4299568404094374907) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2585695341105315181) ) ) {
        result[0] += -0.0428809695773331;
      } else {
        result[0] += -0.030909977649127247;
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6408349166133754382) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6043838026813522779) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0198885000000000034) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              result[0] += -0.0059618176178947695;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002941500000000000538) ) ) {
                result[0] += -0.030895594892019013;
              } else {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3296315496301309156) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003572500000000000588) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00328850000000000019) ) ) {
                      result[0] += -0.0008136355530575843;
                    } else {
                      result[0] += 0.09827576710947387;
                    }
                  } else {
                    result[0] += -0.005281280858266482;
                  }
                } else {
                  result[0] += -0.018038689058124443;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.314561000000000035) ) ) {
              result[0] += -0.005370843315315577;
            } else {
              result[0] += 0.05212774914212242;
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002411500000000000449) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
              result[0] += 0.06437391001389407;
            } else {
              result[0] += -0.027919259705187688;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.741194024698492604) ) ) {
              result[0] += 0.024501475215980995;
            } else {
              result[0] += 0.1553158810512566;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.576775970879121469) ) ) {
          result[0] += -0.032036335224048015;
        } else {
          result[0] += -0.015480125707284059;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8244912349994802936) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.649924828200234006) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7728505831511113255) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.480405183437169869) ) ) {
            result[0] += -0.004019744580595286;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8622145545979901238) ) ) {
              result[0] += 0.051954144482986395;
            } else {
              result[0] += -0.0008446069339230221;
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9550000000000000711) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9228588940825653841) ) ) {
              result[0] += 0.0042624571336834635;
            } else {
              result[0] += 0.016000296111464998;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5392639039447236771) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08350800000000001277) ) ) {
                result[0] += 0.0056005476249335875;
              } else {
                result[0] += -0.03567107512079356;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.650000000000000541e-05) ) ) {
                result[0] += 0.02802291641526665;
              } else {
                result[0] += -0.005796628918951298;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
          result[0] += 0.024637269396572545;
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6832193430923222399) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3837516359296482826) ) ) {
              result[0] += -0.022452761341746258;
            } else {
              result[0] += 0.006236768323832464;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00129150000000000033) ) ) {
              result[0] += 0.030540566971420307;
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.5329091955564501104) ) ) {
                result[0] += 0.0013526126459697477;
              } else {
                result[0] += 0.01572666344210555;
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8820243969432238762) ) ) {
        result[0] += 0.0290824388682384;
      } else {
        result[0] += 0.04177228517882517;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6623732216749412816) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3881589449934809699) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2585695341105315181) ) ) {
        result[0] += -0.04274276522140233;
      } else {
        result[0] += -0.031487110872627254;
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5091389307398357378) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3650000000000000466) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1850000000000000255) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1825188526243103071) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.08500000000000000611) ) ) {
                result[0] += -0.019339543103589745;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.709112113944723732) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3050000000000000488) ) ) {
                    result[0] += 0.1798377402203938;
                  } else {
                    result[0] += 0.02475382971692345;
                  }
                } else {
                  result[0] += -0.014875654812402557;
                }
              }
            } else {
              result[0] += -0.009540433555701222;
            }
          } else {
            result[0] += -0.0232977390914936;
          }
        } else {
          result[0] += -0.03524541948790949;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.25500000000000006) ) ) {
          result[0] += 0.007361873255572264;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5250000000000001332) ) ) {
            result[0] += -0.008715806028805497;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.576775970879121469) ) ) {
              result[0] += -0.03103917243795985;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8550000000000000933) ) ) {
                result[0] += -0.011516947895283737;
              } else {
                result[0] += -0.033771224551982656;
              }
            }
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8244912349994802936) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.649924828200234006) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7863566523687727239) ) ) {
          result[0] += -0.002834166229416412;
        } else {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.212199032544347022) ) ) {
            result[0] += 0.03282831792577298;
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.5724391781153673753) ) ) {
              if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.6130861605291061389) ) ) {
                result[0] += -0.00257666968907717;
              } else {
                result[0] += -0.04269362384648492;
              }
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3539353041941689093) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4093335132160804135) ) ) {
                  if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4008331129359999911) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3970139529396985445) ) ) {
                      result[0] += 0.022481244796190854;
                    } else {
                      result[0] += -0.02357579416224283;
                    }
                  } else {
                    result[0] += -0.05529010904044981;
                  }
                } else {
                  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6387700695905161874) ) ) {
                    result[0] += 0.032083898011159094;
                  } else {
                    result[0] += -0.011763996446389348;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8650000000000001021) ) ) {
                  result[0] += 0.008911156803578414;
                } else {
                  result[0] += 0.0004471899790393634;
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
          result[0] += 0.02391851523782662;
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7093072464629580631) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.5329091955564501104) ) ) {
              result[0] += -0.011184932427300228;
            } else {
              result[0] += 0.008658926313143545;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9150000000000001465) ) ) {
              result[0] += 0.020446717032215976;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8265253025055979696) ) ) {
                result[0] += -0.005502036097966235;
              } else {
                result[0] += 0.013747938057074026;
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8820243969432238762) ) ) {
        result[0] += 0.028466035836675403;
      } else {
        result[0] += 0.04142111503078369;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6623732216749412816) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3881589449934809699) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2585695341105315181) ) ) {
        result[0] += -0.042605171300039484;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02500000000000000486) ) ) {
          result[0] += 0;
        } else {
          result[0] += -0.032265894482808026;
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5091389307398357378) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3650000000000000466) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1850000000000000255) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4036106884780860105) ) ) {
              result[0] += -0.010870426042475121;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6800105846231156992) ) ) {
                result[0] += 0.09568904215110244;
              } else {
                result[0] += -0.014806849153019452;
              }
            }
          } else {
            result[0] += -0.02276833898814597;
          }
        } else {
          result[0] += -0.03483542632540673;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.25500000000000006) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2812919420362327561) ) ) {
            result[0] += -0.02063023646302139;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06805950000000000888) ) ) {
              result[0] += 0.02906847894078421;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.314561000000000035) ) ) {
                result[0] += -0.007616726657081315;
              } else {
                result[0] += 0.05610355045187313;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5250000000000001332) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5339727936928498897) ) ) {
              result[0] += -0.021075047149398993;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.07931350000000002287) ) ) {
                result[0] += -0.0029367388971343073;
              } else {
                result[0] += -0.027514214726997978;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.576775970879121469) ) ) {
              result[0] += -0.03054537009084303;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8550000000000000933) ) ) {
                result[0] += -0.011126967249225737;
              } else {
                result[0] += -0.03328172413374409;
              }
            }
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8244912349994802936) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9031544962109391284) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7728505831511113255) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.480405183437169869) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4493993753087514587) ) ) {
              result[0] += 0.00035727009082447487;
            } else {
              result[0] += -0.006824148265273198;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8622145545979901238) ) ) {
              result[0] += 0.04885235320998614;
            } else {
              result[0] += -0.000702195300267221;
            }
          }
        } else {
          result[0] += 0.00299608995098856;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001940500000000000167) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
            result[0] += 0.005740119325799269;
          } else {
            result[0] += 0.03601269813280031;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9815549730476619272) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3789418506030151068) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2669585275879397535) ) ) {
                result[0] += 0.023384174537872348;
              } else {
                result[0] += -0.00793402294201042;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003787500000000000502) ) ) {
                result[0] += 0.024142998882753734;
              } else {
                result[0] += 0.010445245064451178;
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9650000000000000799) ) ) {
              result[0] += 0.03028178413528025;
            } else {
              result[0] += 0.0087443607854054;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8820243969432238762) ) ) {
        result[0] += 0.02785463929793537;
      } else {
        result[0] += 0.04107203108759952;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6623732216749412816) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3789369143834280806) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2585695341105315181) ) ) {
        result[0] += -0.042467941780937796;
      } else {
        result[0] += -0.03082738035032667;
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5091389307398357378) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2015687645351587898) ) ) {
          result[0] += -0.01187021498838538;
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005139500000000000839) ) ) {
            result[0] += -0.03616009232333882;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6300691579881073645) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1152026343392230645) ) ) {
                result[0] += -0.025055416426238472;
              } else {
                result[0] += 0;
              }
            } else {
              result[0] += -0.037758945310258744;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.25500000000000006) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2812919420362327561) ) ) {
            result[0] += -0.020111779832382944;
          } else {
            result[0] += 0.012744651104927571;
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8350000000000000755) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.576775970879121469) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3181031339503840871) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02952850000000000266) ) ) {
                  result[0] += -0.005811044301941253;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5628434130653267031) ) ) {
                    result[0] += 0.09043811270969458;
                  } else {
                    result[0] += 0;
                  }
                }
              } else {
                result[0] += -0.023461150147801153;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.09981450000000001432) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3654644975094878956) ) ) {
                  result[0] += 0.012161436186437478;
                } else {
                  result[0] += -0.008655734602604765;
                }
              } else {
                result[0] += -0.028390056555202634;
              }
            }
          } else {
            result[0] += -0.031014797831255228;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8244912349994802936) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.649924828200234006) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8635248854378615446) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.480405183437169869) ) ) {
            result[0] += -0.0013174710063673903;
          } else {
            result[0] += 0.017534952810200646;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7617737907239344741) ) ) {
            result[0] += 0.0067614765398845865;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03221500000000000752) ) ) {
              result[0] += -0.048769029239320805;
            } else {
              result[0] += 0.010627165142980935;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
          result[0] += 0.022800482917173452;
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7240566771921500555) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3459462384673366864) ) ) {
              result[0] += -0.020086857606685434;
            } else {
              result[0] += 0.008086140678647512;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9150000000000001465) ) ) {
              result[0] += 0.021564255436952957;
            } else {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7574834615487423539) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6552470062311558374) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.984678388445941577) ) ) {
                    result[0] += 0.011959329198253533;
                  } else {
                    result[0] += -0.030497876091574384;
                  }
                } else {
                  result[0] += -0.07737458536097869;
                }
              } else {
                result[0] += 0.013187799140069135;
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8820243969432238762) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9950000000000001066) ) ) {
          result[0] += 0.03010440739868846;
        } else {
          result[0] += 0.010678361100284937;
        }
      } else {
        result[0] += 0.040724438047808495;
      }
    }
  }
}

