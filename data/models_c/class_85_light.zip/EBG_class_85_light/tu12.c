
#include "header.h"

void predict_unit12(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9269973380582882116) ) ) {
    result[0] += -0.0006198366491314846;
  } else {
    result[0] += 0.05525885307172466;
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9750000000000000888) ) ) {
    result[0] += 0.0012319816333869243;
  } else {
    result[0] += -0.02798785706543906;
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8538728410170577376) ) ) {
    result[0] += -0.0017984195960739139;
  } else {
    result[0] += 0.021217827847317114;
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9350000000000001643) ) ) {
    result[0] += 0.0017655630749443807;
  } else {
    result[0] += -0.01999507139552275;
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8835909053824168025) ) ) {
    result[0] += -0.0014436101105972797;
  } else {
    result[0] += 0.024443995290902697;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6450000000000001288) ) ) {
    result[0] += 0.010895500842346613;
  } else {
    result[0] += -0.0031101058554430295;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5948284698255842384) ) ) {
    result[0] += -0.014646745240323973;
  } else {
    result[0] += 0.0025495606573246424;
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8158067323869347964) ) ) {
    result[0] += -0.0011459887414788795;
  } else {
    result[0] += 0.029504896820609677;
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.097216905567068856) ) ) {
    result[0] += 0.0014871219480529702;
  } else {
    result[0] += -0.02517405398301093;
  }
  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3750000000000000555) ) ) {
    result[0] += 0.014259063270664453;
  } else {
    result[0] += -0.002356673689472103;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4690118026602231871) ) ) {
    result[0] += -0.023184193452239807;
  } else {
    result[0] += 0.0014775445676226192;
  }
  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.08835747683243963535) ) ) {
    result[0] += -0.008178947189170302;
  } else {
    result[0] += 0.004100066512527817;
  }
  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3640888533806194149) ) ) {
    result[0] += 0.012990750071580976;
  } else {
    result[0] += -0.002604171708101381;
  }
  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1850000000000000255) ) ) {
    result[0] += 0.027272299721907867;
  } else {
    result[0] += -0.001233561919251297;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6009522974168109988) ) ) {
    result[0] += -0.0050355695690139;
  } else {
    result[0] += 0.006713162020998451;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8950000000000001288) ) ) {
    result[0] += 0.006457755648217165;
  } else {
    result[0] += -0.005638341182787391;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5458816983076056895) ) ) {
    result[0] += -0.00660310586437041;
  } else {
    result[0] += 0.005183017060183835;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
    result[0] += 0.004347098707005681;
  } else {
    result[0] += -0.008030355389980339;
  }
  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06996650000000001479) ) ) {
    result[0] += 0.002276922933130651;
  } else {
    result[0] += -0.014914042524797246;
  }
}

