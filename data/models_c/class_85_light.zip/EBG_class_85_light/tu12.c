
#include "header.h"

void predict_unit12(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4649337835814208453) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2585695341105315181) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3364400153015075223) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1470012909078650398) ) ) {
          result[0] += -0.020446608214702823;
        } else {
          result[0] += 0.0748135843258671;
        }
      } else {
        result[0] += -0.040215075336185166;
      }
    } else {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
        result[0] += -0.009034173669357475;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005956500000000000856) ) ) {
          result[0] += -0.03244427565124851;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7429456371859297636) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.735388073517588059) ) ) {
              result[0] += -0.013402384245938403;
            } else {
              result[0] += 0.05126893869431225;
            }
          } else {
            result[0] += -0.039685017329211675;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8487060949625354622) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.649924828200234006) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.647174411118524473) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.625000000000000111) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.212199032544347022) ) ) {
              result[0] += 0.04074121314863411;
            } else {
              result[0] += -0.004972166503490585;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.321871344966293327) ) ) {
              result[0] += -0.01839331998585952;
            } else {
              result[0] += 0.016486213458993697;
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007216500000000001559) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006829000000000000868) ) ) {
              result[0] += -0.0016328277712536203;
            } else {
              result[0] += -0.02198274713977859;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.008262500000000000747) ) ) {
              result[0] += 0.015236509572448204;
            } else {
              result[0] += 0.001044540293123354;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
          result[0] += 0.016488747995702414;
        } else {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.5329091955564501104) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9064470225912234502) ) ) {
              result[0] += -0.021829882562500368;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001940500000000000167) ) ) {
                result[0] += 0.024438397419588705;
              } else {
                result[0] += -0.004087356991276781;
              }
            }
          } else {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7653912177436181796) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9150000000000001465) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9502065376501991345) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009114500000000002808) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9344431299457928164) ) ) {
                      result[0] += 0.00905336450216298;
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.505061141934673441) ) ) {
                        result[0] += -0.06466359856146411;
                      } else {
                        result[0] += 0;
                      }
                    }
                  } else {
                    result[0] += -0.0032454666746269427;
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1684918471016796648) ) ) {
                    result[0] += 0.024871095340517655;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6249533869346735049) ) ) {
                      result[0] += -0.043538595172078434;
                    } else {
                      result[0] += 0.01551139582110693;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7269078701507538653) ) ) {
                  result[0] += -0.0034082975329559227;
                } else {
                  result[0] += -0.05613674691847832;
                }
              }
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9130460203636198147) ) ) {
                result[0] += 0.014133536524128463;
              } else {
                result[0] += -0.008141495481305924;
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9497779465347261363) ) ) {
        result[0] += 0.025030429846489982;
      } else {
        result[0] += 0.03847693117474444;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4610343496117730866) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2325362818193636161) ) ) {
      result[0] += -0.04031126627203123;
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02500000000000000486) ) ) {
        result[0] += 0.011303141846123346;
      } else {
        result[0] += -0.021050344397940568;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8606418736522790658) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9031544962109391284) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6322976420381508644) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5950000000000000844) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
              result[0] += 0.025237811941020684;
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.07196201389915944657) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4814085394974874643) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4734952854020100799) ) ) {
                    result[0] += -0.009525041972931214;
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006188500000000000424) ) ) {
                      result[0] += -0.014603232475800716;
                    } else {
                      result[0] += 0.05787608838189104;
                    }
                  }
                } else {
                  result[0] += -0.022738836985081567;
                }
              } else {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.0491948752242571466) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005037500000000001178) ) ) {
                    result[0] += 0.0010967637122797657;
                  } else {
                    result[0] += 0.06556934371963345;
                  }
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.115000000000000005) ) ) {
                    result[0] += 0.07867890966681476;
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08586050000000002014) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02780400000000000579) ) ) {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.596756249395726468) ) ) {
                            result[0] += -0.0021519928770584854;
                          } else {
                            result[0] += 0.04472100167524654;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6148066793467338309) ) ) {
                            result[0] += -0.022787635535176265;
                          } else {
                            result[0] += -0.0027753837570317205;
                          }
                        }
                      } else {
                        result[0] += 0.021580861518213798;
                      }
                    } else {
                      result[0] += -0.023055575626876434;
                    }
                  }
                }
              }
            }
          } else {
            result[0] += -0.016928200763686438;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.480405183437169869) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7810201528643216928) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                result[0] += -0.00018261178122555192;
              } else {
                result[0] += 0.017402488880521327;
              }
            } else {
              result[0] += -0.010029811690112533;
            }
          } else {
            result[0] += 0.01557889442181463;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003787500000000000502) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3459462384673366864) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002411500000000000449) ) ) {
              result[0] += 0.0048822681382917595;
            } else {
              result[0] += -0.05340386437373212;
            }
          } else {
            result[0] += 0.01968106117411268;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9590021414411925571) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.875000000000000111) ) ) {
              result[0] += 0.004908561945832451;
            } else {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6425586238723383081) ) ) {
                result[0] += -0.04243099894835234;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004046500000000000617) ) ) {
                  result[0] += -0.04955082442724378;
                } else {
                  result[0] += -0.0005245040764789017;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              result[0] += 0.017166443281052126;
            } else {
              result[0] += 0.0059760323377150105;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9595979360797254332) ) ) {
        result[0] += 0.02647157604316121;
      } else {
        result[0] += 0.03923415385311146;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4431477231260214644) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2325362818193636161) ) ) {
      result[0] += -0.04016015784399005;
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02500000000000000486) ) ) {
        result[0] += 0.010751583036888026;
      } else {
        result[0] += -0.021684667077504386;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8487060949625354622) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7728505831511113255) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.576775970879121469) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5250000000000001332) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1550000000000000266) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.564198853668341882) ) ) {
                result[0] += 0.0015540065824910974;
              } else {
                result[0] += 0.06673642971529567;
              }
            } else {
              result[0] += -0.007003043806544842;
            }
          } else {
            result[0] += -0.02230204676877148;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002305000000000000462) ) ) {
            result[0] += 0.008654401398384819;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4327651086396848146) ) ) {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3717431637504806097) ) ) {
                result[0] += -0.000400091645207519;
              } else {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1077631270849016415) ) ) {
                  result[0] += -0.001781057446792891;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6850000000000001643) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6421070649173944433) ) ) {
                      result[0] += 0;
                    } else {
                      result[0] += 0.051871567150371445;
                    }
                  } else {
                    result[0] += -0.01221299233387466;
                  }
                }
              }
            } else {
              result[0] += -0.00478206522779401;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6832193430923222399) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.212199032544347022) ) ) {
            result[0] += 0.025425873349804822;
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.5724391781153673753) ) ) {
              if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.6130861605291061389) ) ) {
                result[0] += -0.0040931253687992745;
              } else {
                result[0] += -0.044668013623282404;
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6157932186745959102) ) ) {
                result[0] += 0.00735674800126389;
              } else {
                if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5686531642537678843) ) ) {
                  result[0] += -0.011855516010717907;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9612968876196094081) ) ) {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6205626629504208402) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5674119023366835934) ) ) {
                        result[0] += 0.06480733225538655;
                      } else {
                        result[0] += -0.006663312031897921;
                      }
                    } else {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002305000000000000462) ) ) {
                        result[0] += 0.02240857561849468;
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.875000000000000111) ) ) {
                          result[0] += 0.0005317914306727186;
                        } else {
                          result[0] += -0.02078184829424537;
                        }
                      }
                    }
                  } else {
                    result[0] += 0.02004073323498681;
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00129150000000000033) ) ) {
            result[0] += 0.022289728625597166;
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.5329091955564501104) ) ) {
              result[0] += -0.002461626029171763;
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4627502129294571165) ) ) {
                result[0] += 0.03061151904652512;
              } else {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4216892173912067387) ) ) {
                  result[0] += -0.02254291331134786;
                } else {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2150164111726172722) ) ) {
                    result[0] += 0.01748272381985819;
                  } else {
                    result[0] += 0.006586597704177491;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9595979360797254332) ) ) {
        result[0] += 0.02475774044087174;
      } else {
        result[0] += 0.038979211611962924;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4431477231260214644) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2325362818193636161) ) ) {
      result[0] += -0.040005594837781114;
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02500000000000000486) ) ) {
        result[0] += 0.010231457063719016;
      } else {
        result[0] += -0.021195841056559923;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8606418736522790658) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7863566523687727239) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.576775970879121469) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5250000000000001332) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1650000000000000355) ) ) {
              result[0] += 0.014327145388644864;
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
                result[0] += 0.025605668223640344;
              } else {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.07196201389915944657) ) ) {
                  result[0] += -0.015559481124991297;
                } else {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.0491948752242571466) ) ) {
                    result[0] += 0.04786290339725288;
                  } else {
                    result[0] += -0.006297910017536698;
                  }
                }
              }
            }
          } else {
            result[0] += -0.021799625920323085;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002305000000000000462) ) ) {
            result[0] += 0.0073176253949109515;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002244500000000000401) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6950000000000000622) ) ) {
                result[0] += -0.028935137798882057;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5348598478183703708) ) ) {
                  result[0] += -0.002031555444025723;
                } else {
                  result[0] += -0.015698571983866143;
                }
              }
            } else {
              result[0] += -0.0007368383658553562;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7369297863416220951) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9939011701900751783) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.5724391781153673753) ) ) {
              if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.6130861605291061389) ) ) {
                result[0] += -0.0006862484042101977;
              } else {
                result[0] += -0.03839569384474247;
              }
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4627502129294571165) ) ) {
                result[0] += 0.015193173011358741;
              } else {
                result[0] += 0.0024049069968777384;
              }
            }
          } else {
            result[0] += 0.03397236356194235;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9850000000000000977) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9870276685244862014) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0021995000000000005) ) ) {
                result[0] += 0.027431224811831634;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6116569490452262725) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2266524093375991977) ) ) {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007506500000000000151) ) ) {
                      result[0] += -0.004210140381207583;
                    } else {
                      result[0] += 0.011138439604912332;
                    }
                  } else {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.815768484939150107) ) ) {
                      result[0] += -0.06236617006020469;
                    } else {
                      result[0] += -0.008048294352943523;
                    }
                  }
                } else {
                  result[0] += 0.016080163326050414;
                }
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01448550000000000185) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007506500000000000151) ) ) {
                  result[0] += 0.030303102970898454;
                } else {
                  result[0] += -0.03154919799156046;
                }
              } else {
                result[0] += 0.02755039284821959;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6002093903220061533) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.590591194899497629) ) ) {
                result[0] += -0.006858734585452663;
              } else {
                result[0] += -0.06788201081326395;
              }
            } else {
              result[0] += 0.01813866728626651;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9595979360797254332) ) ) {
        result[0] += 0.025496557596568166;
      } else {
        result[0] += 0.038720822288861444;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4610343496117730866) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2585695341105315181) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3364400153015075223) ) ) {
        result[0] += 0.018331776875301915;
      } else {
        result[0] += -0.03958633859784568;
      }
    } else {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
        result[0] += -0.008244540101999343;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005956500000000000856) ) ) {
          result[0] += -0.030903661887333032;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7429456371859297636) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9998087951126271022) ) ) {
              result[0] += -0.01148270927626638;
            } else {
              result[0] += 0.04799310386941963;
            }
          } else {
            result[0] += -0.039088083441561935;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8606418736522790658) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.649924828200234006) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6964842473688145352) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.544739387236181094) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3034437998924661706) ) ) {
                result[0] += -0.018040740289523495;
              } else {
                result[0] += 0.0051039007162456615;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2750000000000000777) ) ) {
                result[0] += 0.04831526710507533;
              } else {
                result[0] += 0.0051263813644596735;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5339727936928498897) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2666807845679768918) ) ) {
                result[0] += 0.007958818303142556;
              } else {
                result[0] += -0.02203283801070549;
              }
            } else {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2408821398435364858) ) ) {
                result[0] += 0.015636203545686886;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8950000000000001288) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.321871344966293327) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.06536400211476856) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6541365753517588422) ) ) {
                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2323027026914575854) ) ) {
                          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1892070720028789232) ) ) {
                            result[0] += -0.006326483223367101;
                          } else {
                            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5613540176884422861) ) ) {
                              result[0] += -0.010241077804331174;
                            } else {
                              result[0] += 0.06225383207851716;
                            }
                          }
                        } else {
                          result[0] += -0.019824367483914137;
                        }
                      } else {
                        result[0] += 0.004255795837710849;
                      }
                    } else {
                      result[0] += -0.025409402071233027;
                    }
                  } else {
                    result[0] += 0.02540982216017078;
                  }
                } else {
                  result[0] += -0.019006476949495015;
                }
              }
            }
          }
        } else {
          result[0] += 0.00043134445571163706;
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
          result[0] += 0.015300681964900286;
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7948589598137713041) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3750409390474713223) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4470070893467337214) ) ) {
                result[0] += -0.0007881486704277001;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9612968876196094081) ) ) {
                  result[0] += -0.06796676190135584;
                } else {
                  result[0] += 1.6077820848010872e-05;
                }
              }
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2328444889043961574) ) ) {
                result[0] += 0.018431878116188023;
              } else {
                result[0] += 0.003496444966644186;
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
              result[0] += 0.016193903307477286;
            } else {
              result[0] += -0.001549831792052675;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9595979360797254332) ) ) {
        result[0] += 0.024996294219064692;
      } else {
        result[0] += 0.03845873754480115;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4431477231260214644) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2325362818193636161) ) ) {
      result[0] += -0.0396886063584506;
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02500000000000000486) ) ) {
        result[0] += 0.010537214953390193;
      } else {
        result[0] += -0.020261132201849417;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8606418736522790658) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8162318130682130191) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5813400334181016982) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.285476170085738834) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7429456371859297636) ) ) {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.07196201389915944657) ) ) {
                result[0] += -0.009735341995822797;
              } else {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.0491948752242571466) ) ) {
                  result[0] += 0.049025587773526495;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1050000000000000239) ) ) {
                    result[0] += 0.08177371545060375;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6729764489447237485) ) ) {
                      result[0] += -0.003956757301051665;
                    } else {
                      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2015687645351587898) ) ) {
                        result[0] += 0.06295138999057126;
                      } else {
                        result[0] += 0.00335423873014849;
                      }
                    }
                  }
                }
              }
            } else {
              result[0] += -0.02320230526493322;
            }
          } else {
            result[0] += -0.01585467289113529;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.480405183437169869) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7890731911809046872) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007216500000000001559) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002305000000000000462) ) ) {
                    result[0] += 0.00714873070049261;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6408349166133754382) ) ) {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6156410786045318773) ) ) {
                        result[0] += -0.004865263208946966;
                      } else {
                        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9150000000000001465) ) ) {
                          result[0] += 0.0646890701150154;
                        } else {
                          result[0] += -0.011241016860792666;
                        }
                      }
                    } else {
                      result[0] += -0.018313545781006524;
                    }
                  }
                } else {
                  result[0] += 0.0012200702052493745;
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001726500000000000387) ) ) {
                  result[0] += -0.006719909526681267;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03147350000000000841) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7810201528643216928) ) ) {
                      result[0] += 0.06835174177431608;
                    } else {
                      result[0] += -0.006129184472136097;
                    }
                  } else {
                    result[0] += -0.0050428229347065446;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.314561000000000035) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
                  result[0] += -0.02471333515558951;
                } else {
                  result[0] += 0.001590793386034147;
                }
              } else {
                result[0] += 0.03308912742019684;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1270445000000000324) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8254037945979900703) ) ) {
                result[0] += 0.04448599806029458;
              } else {
                result[0] += -0.006934557202443527;
              }
            } else {
              result[0] += 0.06779274306495009;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7742199723950403678) ) ) {
          result[0] += 0.0029459283507824456;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9950000000000001066) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6116569490452262725) ) ) {
              result[0] += 0.0084543854347643;
            } else {
              result[0] += 0.023265650249815348;
            }
          } else {
            result[0] += -0.008851143725632579;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9595979360797254332) ) ) {
        result[0] += 0.02449575675543228;
      } else {
        result[0] += 0.0381927048350289;
      }
    }
  }
}

