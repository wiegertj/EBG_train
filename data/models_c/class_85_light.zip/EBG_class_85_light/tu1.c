
#include "header.h"

void predict_unit1(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8305400774473623571) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7055997140865902795) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5335728757895682461) ) ) {
        result[0] += -0.05863746090463205;
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6337772083671809886) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5650000000000000577) ) ) {
            result[0] += -0.03917462319542632;
          } else {
            result[0] += -0.0518735514245651;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6450000000000001288) ) ) {
            result[0] += -0.019386054129394776;
          } else {
            result[0] += -0.04072074776423114;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7546204900970914231) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8650000000000001021) ) ) {
          result[0] += -0.008808851751017645;
        } else {
          result[0] += -0.02642782218769643;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8450000000000000844) ) ) {
          result[0] += 0.018404932350582635;
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.793392967338620303) ) ) {
            result[0] += -0.009787901229097534;
          } else {
            result[0] += 0.0066802243187125175;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8059485593692011784) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8903263421033805747) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8524704828946135793) ) ) {
          result[0] += 0.02710419754741028;
        } else {
          result[0] += 0.044833364432983094;
        }
      } else {
        if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.751334311843480207) ) ) {
          result[0] += 0.05714357714041496;
        } else {
          result[0] += 0.07047875295742845;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8347688071710012148) ) ) {
        result[0] += 0.08443231579405289;
      } else {
        result[0] += 0.09770440161987333;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8305400774473623571) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6890377340803973683) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5335728757895682461) ) ) {
        result[0] += -0.05767680006516253;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5350000000000001421) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6003075279628945493) ) ) {
            result[0] += -0.04044809386131917;
          } else {
            result[0] += -0.02141580052279346;
          }
        } else {
          result[0] += -0.044793463110933546;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7546204900970914231) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7750000000000001332) ) ) {
          result[0] += -0.007484984893475793;
        } else {
          result[0] += -0.026064363705559358;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8450000000000000844) ) ) {
          result[0] += 0.017460268527953387;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3768611742322795499) ) ) {
            result[0] += 0.003998426864750638;
          } else {
            result[0] += -0.013532172495553687;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7411513695868165996) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8943082925133570837) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.863112229636659456) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7850000000000001421) ) ) {
            result[0] += 0.05565124535988763;
          } else {
            result[0] += 0.024702056662302376;
          }
        } else {
          result[0] += 0.04557954251095343;
        }
      } else {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5923248674292501681) ) ) {
          result[0] += 0.03690827717567207;
        } else {
          result[0] += 0.06411246126051176;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8347688071710012148) ) ) {
        result[0] += 0.08073496180563508;
      } else {
        result[0] += 0.09266849221210742;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8305400774473623571) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6890377340803973683) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5335728757895682461) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2946983627136980366) ) ) {
          result[0] += -0.05882023977421065;
        } else {
          result[0] += -0.05343890740417923;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007442500000000000331) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.009547252630452171e-05) ) ) {
            result[0] += -0.03089289253301309;
          } else {
            result[0] += -0.04692002719893873;
          }
        } else {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2883407947516276049) ) ) {
            result[0] += -0.012724170789979073;
          } else {
            result[0] += -0.03695855535096963;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7546204900970914231) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7750000000000001332) ) ) {
          result[0] += -0.007165244787338684;
        } else {
          result[0] += -0.025169825276061666;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8450000000000000844) ) ) {
          result[0] += 0.016571538144755458;
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.793392967338620303) ) ) {
            result[0] += -0.009285381244924989;
          } else {
            result[0] += 0.00639056732085632;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8059485593692011784) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8903263421033805747) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8524704828946135793) ) ) {
          result[0] += 0.02415300696080703;
        } else {
          result[0] += 0.04009498617871494;
        }
      } else {
        result[0] += 0.057349438218164586;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8347688071710012148) ) ) {
        result[0] += 0.07588469023749003;
      } else {
        result[0] += 0.08831707778258138;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8190185834008598675) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6574910164466515328) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5335728757895682461) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2946983627136980366) ) ) {
          result[0] += -0.058011442617696654;
        } else {
          result[0] += -0.052537192076009924;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5250000000000001332) ) ) {
          result[0] += -0.03345423503130203;
        } else {
          result[0] += -0.04626838262827966;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7366403613896054248) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7150000000000000799) ) ) {
          result[0] += -0.01386759004939899;
        } else {
          result[0] += -0.031750119953446204;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8450000000000000844) ) ) {
          result[0] += 0.012732908816018122;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3980578321249962914) ) ) {
            result[0] += -0.0005811198691127243;
          } else {
            result[0] += -0.01782986263543213;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7868431215179150229) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.863112229636659456) ) ) {
        result[0] += 0.022850259703688123;
      } else {
        if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7358378217099063034) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9150000000000001465) ) ) {
            result[0] += 0.052694696254548194;
          } else {
            result[0] += 0.035950163266949345;
          }
        } else {
          result[0] += 0.05633150159980129;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7930879927049911959) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
          result[0] += 0.06929950677118653;
        } else {
          result[0] += 0.04156603522471352;
        }
      } else {
        result[0] += 0.08365492813664731;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.808405985894013468) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6574910164466515328) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5335728757895682461) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2946983627136980366) ) ) {
          result[0] += -0.05725618209951948;
        } else {
          result[0] += -0.05167571990181715;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5250000000000001332) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6003075279628945493) ) ) {
            result[0] += -0.03718009275747056;
          } else {
            result[0] += -0.018624334401501838;
          }
        } else {
          result[0] += -0.04528233935376415;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.720877625841553682) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7050000000000000711) ) ) {
          result[0] += -0.015888245165093542;
        } else {
          result[0] += -0.03374143669283013;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8150000000000000577) ) ) {
          result[0] += 0.008743264767811454;
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7656222061929859324) ) ) {
            result[0] += -0.01752094143588982;
          } else {
            result[0] += -0.002204123991062665;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.772467906864995224) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.863112229636659456) ) ) {
        result[0] += 0.01966463394742961;
      } else {
        if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6509677360553945968) ) ) {
          result[0] += 0.025925062749872475;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9150000000000001465) ) ) {
            result[0] += 0.05987042927940649;
          } else {
            result[0] += 0.04292950203012828;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7930879927049911959) ) ) {
        result[0] += 0.06334070559472818;
      } else {
        result[0] += 0.08030432617869337;
      }
    }
  }
}

