
#include "header.h"

void predict_unit1(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2878265030021618931) ) ) {
    result[0] += -0.19748687466690154;
  } else {
    result[0] += 0.01843081417928549;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8647854850167006058) ) ) {
    result[0] += -0.021271680005950405;
  } else {
    result[0] += 0.18151290392050887;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4036137457843151366) ) ) {
    result[0] += -0.16243017581774685;
  } else {
    result[0] += 0.01776106511631621;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8970324933564088887) ) ) {
    result[0] += -0.015551019169605117;
  } else {
    result[0] += 0.18695180761547625;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2777801063689750438) ) ) {
    result[0] += -0.187966930684357;
  } else {
    result[0] += 0.012413643947354362;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.871520348344035356) ) ) {
    result[0] += -0.037007290610912846;
  } else {
    result[0] += 0.058796394369631584;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8970324933564088887) ) ) {
    result[0] += -0.011698551316629432;
  } else {
    result[0] += 0.1746666995190864;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2467794703436672898) ) ) {
    result[0] += -0.19048713023912153;
  } else {
    result[0] += 0.0095605718794097;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9269973380582882116) ) ) {
    result[0] += -0.008570313416818248;
  } else {
    result[0] += 0.1844709471550534;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2077946113019053243) ) ) {
    result[0] += -0.19870029255444976;
  } else {
    result[0] += 0.0072263367038185805;
  }
  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007225500000000000152) ) ) {
    result[0] += -0.037463977917404516;
  } else {
    result[0] += 0.03187659607648961;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9361616408410365908) ) ) {
    result[0] += -0.006478107717434285;
  } else {
    result[0] += 0.18256818388889903;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2077946113019053243) ) ) {
    result[0] += -0.19377533200335945;
  } else {
    result[0] += 0.005735556944066915;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5948284698255842384) ) ) {
    result[0] += -0.06586649205215382;
  } else {
    result[0] += 0.014074826327602059;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8447186612272684636) ) ) {
    result[0] += -0.007993366241385597;
  } else {
    result[0] += 0.11255272515571398;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2029793354973225827) ) ) {
    result[0] += -0.18829890323142404;
  } else {
    result[0] += 0.004247797578580498;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9532871366621060716) ) ) {
    result[0] += -0.00409249462524468;
  } else {
    result[0] += 0.1881827833575801;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1594586647043804151) ) ) {
    result[0] += -0.2031175351880745;
  } else {
    result[0] += 0.003205062935202211;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9532871366621060716) ) ) {
    result[0] += -0.003281748448628313;
  } else {
    result[0] += 0.18153113221032216;
  }
}

