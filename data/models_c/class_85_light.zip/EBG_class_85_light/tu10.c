
#include "header.h"

void predict_unit10(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.576775970879121469) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2669666665921996418) ) ) {
      result[0] += -0.04121990799873288;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7429456371859297636) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4649337835814208453) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02500000000000000486) ) ) {
            result[0] += 0.012608779801541915;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9998087951126271022) ) ) {
              result[0] += -0.024508989882549674;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009114500000000002808) ) ) {
                result[0] += -0.014063968205143626;
              } else {
                result[0] += 0.06034233299484531;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.285476170085738834) ) ) {
            result[0] += -0.003017840997068;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5136684729854356091) ) ) {
              result[0] += -0.03678003795928463;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3920816614453023763) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7269078701507538653) ) ) {
                  result[0] += -0.011279415503672556;
                } else {
                  result[0] += 0.04284729941774901;
                }
              } else {
                result[0] += -0.02840941422001715;
              }
            }
          }
        }
      } else {
        result[0] += -0.033439403137342845;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8420098784315052098) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.649924828200234006) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7309551922231288801) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2651510000000000811) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7150000000000000799) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0629345000000000182) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6555524765326633529) ) ) {
                  result[0] += -0.002696178959442414;
                } else {
                  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3809493398436038514) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02032350000000000476) ) ) {
                      result[0] += 0.010323906112163118;
                    } else {
                      result[0] += 0.07006884469281985;
                    }
                  } else {
                    result[0] += 0.003427176665337609;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3950000000000000733) ) ) {
                  result[0] += 0.005317138705951681;
                } else {
                  result[0] += -0.024110232833165757;
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6623732216749412816) ) ) {
                result[0] += -0.018401729032806916;
              } else {
                result[0] += -0.006387781084331588;
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8352912313316583903) ) ) {
              result[0] += 0;
            } else {
              result[0] += 0.08055000336708301;
            }
          }
        } else {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.212199032544347022) ) ) {
            result[0] += 0.027309576726967596;
          } else {
            result[0] += 0.0012090164865464585;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9999977834869465676) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.5329091955564501104) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9064470225912234502) ) ) {
              result[0] += -0.019536307006952917;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001940500000000000167) ) ) {
                result[0] += 0.027486233833533307;
              } else {
                result[0] += 0.0002528893101775939;
              }
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9023325039857709173) ) ) {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7742199723950403678) ) ) {
                result[0] += 0.009828802714334764;
              } else {
                result[0] += 0.01991172270786552;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5392639039447236771) ) ) {
                result[0] += 0.00999665667599834;
              } else {
                result[0] += -0.02424698162874469;
              }
            }
          }
        } else {
          result[0] += 0.04252075576774708;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9435227614686748643) ) ) {
        result[0] += 0.030074958464733074;
      } else {
        result[0] += 0.04120535971311011;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5380269784348243878) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2669666665921996418) ) ) {
      result[0] += -0.041066134269569426;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7429456371859297636) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01250250000000000146) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += -0.011389420056208577;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001584500000000000188) ) ) {
              result[0] += -0.04033534288880111;
            } else {
              result[0] += -0.023540252336974425;
            }
          }
        } else {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.07196201389915944657) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4814085394974874643) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4734952854020100799) ) ) {
                result[0] += -0.015534421249076101;
              } else {
                result[0] += 0.059411824902736866;
              }
            } else {
              result[0] += -0.03661872777576648;
            }
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.0491948752242571466) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1350000000000000366) ) ) {
                result[0] += 0;
              } else {
                result[0] += 0.10444861180715836;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.029588714460048626) ) ) {
                result[0] += -0.007506453383770954;
              } else {
                result[0] += 0.03653901001054291;
              }
            }
          }
        }
      } else {
        result[0] += -0.033514187469441035;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8420098784315052098) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8583556158382011914) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6964842473688145352) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04401350000000000401) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.25500000000000006) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5580998554338508777) ) ) {
                  result[0] += 0.0076306879625555706;
                } else {
                  result[0] += 0.09077126182490826;
                }
              } else {
                result[0] += 0.006068078604621263;
              }
            } else {
              result[0] += -0.005876649354120887;
            }
          } else {
            result[0] += -0.009759829886164638;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += 0.015277183658096992;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.314561000000000035) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6300691579881073645) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6156410786045318773) ) ) {
                  result[0] += 0;
                } else {
                  result[0] += 0.06062020037360375;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.480405183437169869) ) ) {
                  result[0] += -0.009003674778631161;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.09981450000000001432) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820591807562814135) ) ) {
                      result[0] += 0.04516862416781918;
                    } else {
                      result[0] += -0.01431403571871077;
                    }
                  } else {
                    result[0] += 0.05821316612243831;
                  }
                }
              }
            } else {
              result[0] += 0.035466113136008545;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7369297863416220951) ) ) {
          result[0] += 0.005979666454008603;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9870276685244862014) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001940500000000000167) ) ) {
                result[0] += 0.03461739519719092;
              } else {
                result[0] += 0.012082036930386465;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01565150000000000222) ) ) {
                result[0] += -0.002235462549894051;
              } else {
                result[0] += 0.038394116958040785;
              }
            }
          } else {
            result[0] += -0.002650168057727772;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9435227614686748643) ) ) {
        result[0] += 0.02955861510537004;
      } else {
        result[0] += 0.040933381640397525;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5380269784348243878) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2669666665921996418) ) ) {
      result[0] += -0.040910301806833776;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7429456371859297636) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01250250000000000146) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02500000000000000486) ) ) {
              result[0] += 0.035972351522003454;
            } else {
              result[0] += -0.012571308051013247;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001584500000000000188) ) ) {
              result[0] += -0.04009375163372998;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4907148431464699034) ) ) {
                result[0] += -0.027302664189651004;
              } else {
                result[0] += -0.009031125263414064;
              }
            }
          }
        } else {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.07196201389915944657) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4814085394974874643) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4734952854020100799) ) ) {
                result[0] += -0.015089250211543469;
              } else {
                result[0] += 0.05524512556007696;
              }
            } else {
              result[0] += -0.03623243670391845;
            }
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.0491948752242571466) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2250575080921391191) ) ) {
                result[0] += 0;
              } else {
                result[0] += 0.09522701464051178;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6784611311055277483) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1224455000000000265) ) ) {
                  result[0] += -0.013445361644374598;
                } else {
                  result[0] += 0.024713118345011498;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6800105846231156992) ) ) {
                  result[0] += 0.09267736611874325;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.029588714460048626) ) ) {
                    result[0] += -0.01503588315675277;
                  } else {
                    result[0] += 0.04116212706939003;
                  }
                }
              }
            }
          }
        }
      } else {
        result[0] += -0.03310851697597333;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8420098784315052098) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8678581689358929596) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7058987689933927667) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7150000000000000799) ) ) {
            result[0] += -0.0035058410869859575;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6181495723579168988) ) ) {
              result[0] += -0.03196536538983722;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4175496798250740715) ) ) {
                result[0] += 0.040371639280704336;
              } else {
                result[0] += -0.011109334343569165;
              }
            }
          }
        } else {
          result[0] += 0.00017976834469471138;
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7369297863416220951) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9939011701900751783) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8352912313316583903) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.198572119349334608) ) ) {
                result[0] += 0.0056918710384671655;
              } else {
                result[0] += -0.01686506214070488;
              }
            } else {
              result[0] += 0.025741022098363812;
            }
          } else {
            result[0] += 0.03702603511487621;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9870276685244862014) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001940500000000000167) ) ) {
                result[0] += 0.034053664013631614;
              } else {
                result[0] += 0.01166699979076126;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01565150000000000222) ) ) {
                result[0] += -0.002148027929185787;
              } else {
                result[0] += 0.03788411146985045;
              }
            }
          } else {
            result[0] += -0.002533848867275278;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9435227614686748643) ) ) {
        result[0] += 0.02904144600279658;
      } else {
        result[0] += 0.04066098736974834;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5380269784348243878) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2669666665921996418) ) ) {
      result[0] += -0.04075218031652112;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7429456371859297636) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01250250000000000146) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += -0.010642683431107084;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001584500000000000188) ) ) {
              result[0] += -0.03985010981617013;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4907148431464699034) ) ) {
                result[0] += -0.026814060470332777;
              } else {
                result[0] += -0.008721867830419254;
              }
            }
          }
        } else {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.07196201389915944657) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4814085394974874643) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4734952854020100799) ) ) {
                result[0] += -0.01465198920215651;
              } else {
                result[0] += 0.05148492618046645;
              }
            } else {
              result[0] += -0.035843960212553;
            }
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.0491948752242571466) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1350000000000000366) ) ) {
                result[0] += 0;
              } else {
                result[0] += 0.08743988165888225;
              }
            } else {
              result[0] += -0.004501217360042722;
            }
          }
        }
      } else {
        result[0] += -0.032698347110416255;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8420098784315052098) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8455909065280039494) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6809682101532212872) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3474442649552166307) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7683067979899498301) ) ) {
              result[0] += 0.0008868716301195603;
            } else {
              result[0] += -0.019408372216358005;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6181495723579168988) ) ) {
              result[0] += -0.021266381341448037;
            } else {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4121935985795305846) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.292381066124493438) ) ) {
                  result[0] += -0.002338896223601179;
                } else {
                  result[0] += 0.06728204133361408;
                }
              } else {
                result[0] += -0.012466718369024181;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8150000000000000577) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.518449662688442281) ) ) {
              result[0] += -0.0017030104514681348;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5259885771356785922) ) ) {
                result[0] += 0.041482340972412726;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8213614112043600146) ) ) {
                  result[0] += 0.0036444067021099117;
                } else {
                  result[0] += 0.027746651458053682;
                }
              }
            }
          } else {
            result[0] += -0.002538085686591538;
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7369297863416220951) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8449888203266332498) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9443572767030988802) ) ) {
              result[0] += 0.003523369269110377;
            } else {
              result[0] += 0.011180433823706;
            }
          } else {
            result[0] += 0.03954950708708366;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9870276685244862014) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001940500000000000167) ) ) {
                result[0] += 0.033493335094365626;
              } else {
                result[0] += 0.011263277822642966;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01565150000000000222) ) ) {
                result[0] += -0.0020641222056190516;
              } else {
                result[0] += 0.037377380355246036;
              }
            }
          } else {
            result[0] += -0.002422824783090191;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9435227614686748643) ) ) {
        result[0] += 0.028523542868805617;
      } else {
        result[0] += 0.04038777834388421;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5380269784348243878) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2669666665921996418) ) ) {
      result[0] += -0.040591559772253726;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7429456371859297636) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01250250000000000146) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += -0.010288680785943308;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001584500000000000188) ) ) {
              result[0] += -0.03960412623286594;
            } else {
              result[0] += -0.022035398907588804;
            }
          }
        } else {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.07196201389915944657) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4814085394974874643) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4734952854020100799) ) ) {
                result[0] += -0.014222750281319408;
              } else {
                result[0] += 0.04807929243413535;
              }
            } else {
              result[0] += -0.03545310040011141;
            }
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.0491948752242571466) ) ) {
              result[0] += 0.058198827665144184;
            } else {
              result[0] += -0.0043274432683588805;
            }
          }
        }
      } else {
        result[0] += -0.03228365582742262;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8420098784315052098) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.649924828200234006) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7058987689933927667) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7150000000000000799) ) ) {
            result[0] += -0.0031851263125762526;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6181495723579168988) ) ) {
              result[0] += -0.03122340501275649;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4175496798250740715) ) ) {
                result[0] += 0.03791022712744069;
              } else {
                result[0] += -0.010515107856877978;
              }
            }
          }
        } else {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.212199032544347022) ) ) {
            result[0] += 0.02415525076462454;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8650000000000001021) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5140962685175880509) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1181375000000000203) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05323650000000000604) ) ) {
                    result[0] += -0.003581157112710121;
                  } else {
                    result[0] += 0.015245993167521482;
                  }
                } else {
                  result[0] += -0.017515174488913973;
                }
              } else {
                result[0] += 0.007749750211400786;
              }
            } else {
              result[0] += -0.0009865148260379535;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9750977232358475355) ) ) {
            result[0] += 0.012786818609117288;
          } else {
            result[0] += 0.02993506280579566;
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3837516359296482826) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7617737907239344741) ) ) {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.66451851912119142) ) ) {
                result[0] += 0.005416060262818258;
              } else {
                result[0] += -0.04229264092490026;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001940500000000000167) ) ) {
                result[0] += 0.023676438492199702;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005248500000000000561) ) ) {
                  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8110202045877191734) ) ) {
                    result[0] += -0.03974546232606973;
                  } else {
                    result[0] += 0.020458305677468355;
                  }
                } else {
                  result[0] += 0.0032282237252163927;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7889148352316185386) ) ) {
              result[0] += 0.006803984151533759;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
                result[0] += 0.021203003020158796;
              } else {
                result[0] += -0.002416927681996749;
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9435227614686748643) ) ) {
        result[0] += 0.028005013908624074;
      } else {
        result[0] += 0.04011336717988435;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5091389307398357378) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2585695341105315181) ) ) {
      result[0] += -0.04077632544386971;
    } else {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
        result[0] += -0.010314821597420807;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005139500000000000839) ) ) {
          result[0] += -0.034136612214629526;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7429456371859297636) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.735388073517588059) ) ) {
              result[0] += -0.014266065880035381;
            } else {
              result[0] += 0.06702832661908399;
            }
          } else {
            result[0] += -0.03828462854466653;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8420098784315052098) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8455909065280039494) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6623732216749412816) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.25500000000000006) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3950000000000000733) ) ) {
              result[0] += -0.0005464528093953656;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3830383354773237436) ) ) {
                if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.0194836725655387448) ) ) {
                  result[0] += 0.017103681024790603;
                } else {
                  result[0] += 0.08419927522478703;
                }
              } else {
                result[0] += -0.007002311774097828;
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8550000000000000933) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08122600000000000653) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6181495723579168988) ) ) {
                  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3474442649552166307) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5339727936928498897) ) ) {
                      result[0] += -0.016535836431830986;
                    } else {
                      result[0] += -0.000512057880760461;
                    }
                  } else {
                    result[0] += -0.020726497270681692;
                  }
                } else {
                  result[0] += 0.0002026597413601412;
                }
              } else {
                result[0] += -0.025745312755783054;
              }
            } else {
              result[0] += -0.030170665667871386;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.480405183437169869) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7810201528643216928) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6300691579881073645) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6156410786045318773) ) ) {
                    result[0] += -0.0003031089518848734;
                  } else {
                    result[0] += 0.05239909168178106;
                  }
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7650000000000001243) ) ) {
                    result[0] += 0.010112853552003573;
                  } else {
                    result[0] += -0.015483698662417427;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001693500000000000344) ) ) {
                  result[0] += -0.009672662520167753;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02405550000000000396) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.7150000000000000799) ) ) {
                      result[0] += 0.08330902934449556;
                    } else {
                      result[0] += 0.006474698139101037;
                    }
                  } else {
                    result[0] += 0.0029199817328833234;
                  }
                }
              }
            } else {
              result[0] += -0.013529807325083982;
            }
          } else {
            result[0] += 0.01845366500079438;
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7369297863416220951) ) ) {
          result[0] += 0.004898801651618803;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9870276685244862014) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001940500000000000167) ) ) {
                result[0] += 0.03265801340022351;
              } else {
                result[0] += 0.01043508621921987;
              }
            } else {
              result[0] += 0.03161041316466476;
            }
          } else {
            result[0] += -0.0023623118719230595;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9435227614686748643) ) ) {
        result[0] += 0.027486001196299813;
      } else {
        result[0] += 0.03983738946271167;
      }
    }
  }
}

