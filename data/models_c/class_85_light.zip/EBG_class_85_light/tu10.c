
#include "header.h"

void predict_unit10(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6337772083671809886) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4056437611611355964) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2086966242511653913) ) ) {
        result[0] += -0.045849663003217585;
      } else {
        result[0] += -0.033535314043872555;
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
        result[0] += -0.006106871247325389;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003260500000000000377) ) ) {
          result[0] += -0.03414742345289793;
        } else {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3313460023454675718) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4050000000000000822) ) ) {
              result[0] += -0.013210200002625756;
            } else {
              result[0] += 0.031607579569202814;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0446835897586253597) ) ) {
              result[0] += -0.020560979976251722;
            } else {
              result[0] += 0;
            }
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7930879927049911959) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8474756727480589058) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.820923736457286557) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7546204900970914231) ) ) {
            result[0] += -0.004501243014406983;
          } else {
            result[0] += 0.0022119799108680604;
          }
        } else {
          result[0] += -0.01823248526319221;
        }
      } else {
        if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7868431215179150229) ) ) {
          result[0] += 0.006829537768291782;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += 0.017975076112820985;
          } else {
            result[0] += -0.01117674629598495;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9046795177622769524) ) ) {
        result[0] += 0.029192447278492906;
      } else {
        result[0] += 0.04642291170567549;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6337772083671809886) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4056437611611355964) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2478670645711959775) ) ) {
        result[0] += -0.044800886804795166;
      } else {
        result[0] += -0.03173520682454631;
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
        result[0] += -0.005857344622610785;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003260500000000000377) ) ) {
          result[0] += -0.0335901219105104;
        } else {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3313460023454675718) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4086612272110553001) ) ) {
              result[0] += -0.010734558801149286;
            } else {
              result[0] += 0.032419518007566865;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0446835897586253597) ) ) {
              result[0] += -0.01997040460789263;
            } else {
              result[0] += 0;
            }
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8347688071710012148) ) ) {
      if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6845616084030620163) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7656222061929859324) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.795000000000000151) ) ) {
            result[0] += 0.00020363936405209935;
          } else {
            result[0] += -0.009367775998867801;
          }
        } else {
          result[0] += 0.003465836714977472;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
          if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8299157965154307925) ) ) {
            result[0] += 0.011780758817462031;
          } else {
            result[0] += 0.024178655286747584;
          }
        } else {
          result[0] += -0.007844217331862708;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9046795177622769524) ) ) {
        result[0] += 0.03270540812535432;
      } else {
        result[0] += 0.04613875502615963;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6337772083671809886) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4056437611611355964) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2086966242511653913) ) ) {
        result[0] += -0.04557687453972956;
      } else {
        result[0] += -0.03248533536179249;
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
        result[0] += -0.005616905836071188;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003260500000000000377) ) ) {
          result[0] += -0.033030225235081756;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6552417783486498282) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6574014915075377941) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3313460023454675718) ) ) {
                result[0] += 0.005973687232285571;
              } else {
                result[0] += -0.015979432479673716;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00948350000000000061) ) ) {
                result[0] += -0.005808422248309898;
              } else {
                result[0] += 0.0657101422383877;
              }
            }
          } else {
            result[0] += -0.02713847848861281;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8347688071710012148) ) ) {
      if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6845616084030620163) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7656222061929859324) ) ) {
          result[0] += -0.004346719228889561;
        } else {
          result[0] += 0.003307120836896308;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
          if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8299157965154307925) ) ) {
            result[0] += 0.011308066000104661;
          } else {
            result[0] += 0.02348155804161678;
          }
        } else {
          result[0] += -0.007450453562985063;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9046795177622769524) ) ) {
        result[0] += 0.03206526545625214;
      } else {
        result[0] += 0.04585805106933316;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6003075279628945493) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2946983627136980366) ) ) {
      result[0] += -0.0431178357663018;
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
        result[0] += -0.010017402736279228;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003260500000000000377) ) ) {
          result[0] += -0.03597397526299621;
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4830601280619837845) ) ) {
            result[0] += -0.026531547838853205;
          } else {
            result[0] += -0.010702161458934906;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8347688071710012148) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8943082925133570837) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7366403613896054248) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7150000000000000799) ) ) {
            result[0] += -8.925238997572494e-05;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
              result[0] += -0.013083168920265516;
            } else {
              result[0] += 0.014130231507226162;
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8150000000000000577) ) ) {
            result[0] += 0.008319818832396098;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7250000000000000888) ) ) {
              result[0] += -0.0037044129560036445;
            } else {
              result[0] += 0.00422448288770665;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7474614522612087475) ) ) {
          result[0] += 0.008802699066399067;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
            result[0] += 0.02053399115631893;
          } else {
            result[0] += -0.002382082245266884;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9046795177622769524) ) ) {
        result[0] += 0.03142681811588241;
      } else {
        result[0] += 0.045580157179363985;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6003075279628945493) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2946983627136980366) ) ) {
      result[0] += -0.04288709677706441;
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
        result[0] += -0.009642957507573558;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003260500000000000377) ) ) {
          result[0] += -0.03547939104316104;
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4830601280619837845) ) ) {
            result[0] += -0.025948807799445698;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6487793308371881951) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6574014915075377941) ) ) {
                result[0] += -0.008554586671311036;
              } else {
                result[0] += 0.026016742840445774;
              }
            } else {
              result[0] += -0.027793961143831127;
            }
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8347688071710012148) ) ) {
      if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6845616084030620163) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7546204900970914231) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4750000000000000333) ) ) {
            result[0] += 0.007830775033092726;
          } else {
            result[0] += -0.006760705527224786;
          }
        } else {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
            result[0] += 0.024096451277473577;
          } else {
            result[0] += 0.0022217888377732233;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
          if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8299157965154307925) ) ) {
            result[0] += 0.010445543583744282;
          } else {
            result[0] += 0.02222946486165368;
          }
        } else {
          result[0] += -0.007020520866616515;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9046795177622769524) ) ) {
        result[0] += 0.030790042071212113;
      } else {
        result[0] += 0.045304463130459174;
      }
    }
  }
}

