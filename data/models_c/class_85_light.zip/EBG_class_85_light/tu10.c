
#include "header.h"

void predict_unit10(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6277403467108452206) ) ) {
    result[0] += 0.0028927823066340684;
  } else {
    result[0] += -0.013855686244325587;
  }
  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5724391781153673753) ) ) {
    result[0] += -0.021085364827179855;
  } else {
    result[0] += 0.0018213769111348314;
  }
  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3640888533806194149) ) ) {
    result[0] += 0.015097472685720106;
  } else {
    result[0] += -0.0030154843691489936;
  }
  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.08835747683243963535) ) ) {
    result[0] += -0.00920180772816676;
  } else {
    result[0] += 0.004607797128742284;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9532871366621060716) ) ) {
    result[0] += -0.0004477708500144048;
  } else {
    result[0] += 0.08635529859825282;
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9750000000000000888) ) ) {
    result[0] += 0.0013571470842179947;
  } else {
    result[0] += -0.031195114436158012;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.751238504316701472) ) ) {
    result[0] += -0.0023364028112192203;
  } else {
    result[0] += 0.018771814450312303;
  }
  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3640888533806194149) ) ) {
    result[0] += 0.013815371699308548;
  } else {
    result[0] += -0.0027418974029867153;
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4101030825879397046) ) ) {
    result[0] += -0.017932572553225255;
  } else {
    result[0] += 0.0023474708071484964;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2878265030021618931) ) ) {
    result[0] += -0.04918921929868575;
  } else {
    result[0] += 0.0007625077265778132;
  }
  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02500000000000000486) ) ) {
    result[0] += 0.10696859306973815;
  } else {
    result[0] += -0.0004348207778265001;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1594586647043804151) ) ) {
    result[0] += -0.12948110769973542;
  } else {
    result[0] += 0.00031219227631150247;
  }
  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1850000000000000255) ) ) {
    result[0] += 0.029632210900467103;
  } else {
    result[0] += -0.001333268463867559;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4442092980514921186) ) ) {
    result[0] += -0.028123431236240965;
  } else {
    result[0] += 0.0014687806409158818;
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
    result[0] += 0.022213204059604693;
  } else {
    result[0] += -0.001815807836902543;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6501267983073132362) ) ) {
    result[0] += -0.012205813927295035;
  } else {
    result[0] += 0.0031104891720496403;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
    result[0] += 0.004769002425022607;
  } else {
    result[0] += -0.008852122459553085;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6009522974168109988) ) ) {
    result[0] += -0.005550845489115553;
  } else {
    result[0] += 0.0073853432527151925;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8650000000000001021) ) ) {
    result[0] += 0.007383327398897899;
  } else {
    result[0] += -0.0054276887301026675;
  }
}

