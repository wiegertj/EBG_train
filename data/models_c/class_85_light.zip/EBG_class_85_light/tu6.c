
#include "header.h"

void predict_unit6(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
    result[0] += 0.02963284169967249;
  } else {
    result[0] += -0.003078198792941993;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5948284698255842384) ) ) {
    result[0] += -0.022243421954044808;
  } else {
    result[0] += 0.003958792779152102;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8450000000000000844) ) ) {
    result[0] += 0.011227834818511693;
  } else {
    result[0] += -0.007372536328465727;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7238160268635116523) ) ) {
    result[0] += -0.013416933019874231;
  } else {
    result[0] += 0.0059417063309316264;
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
    result[0] += 0.027558487768539006;
  } else {
    result[0] += -0.0028994783616202954;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5216735645817832667) ) ) {
    result[0] += -0.029012305028126968;
  } else {
    result[0] += 0.0026962032564915445;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.545000000000000151) ) ) {
    result[0] += 0.019490122883074425;
  } else {
    result[0] += -0.003874385821034763;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6501267983073132362) ) ) {
    result[0] += -0.01684400528142334;
  } else {
    result[0] += 0.004352739281439186;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9749256219547374203) ) ) {
    result[0] += -0.00048043091975048417;
  } else {
    result[0] += 0.16065464166583934;
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9750000000000000888) ) ) {
    result[0] += 0.0018000745249732056;
  } else {
    result[0] += -0.0436710452190403;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8711888949744006627) ) ) {
    result[0] += -0.001549818290666045;
  } else {
    result[0] += 0.04949482346631513;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7050000000000000711) ) ) {
    result[0] += 0.014115093938073996;
  } else {
    result[0] += -0.0050121495388715815;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5948284698255842384) ) ) {
    result[0] += -0.019355700155788125;
  } else {
    result[0] += 0.003414718913324883;
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.850000000000000659e-05) ) ) {
    result[0] += 0.02930245623471974;
  } else {
    result[0] += -0.002340708922784185;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9999118398270484542) ) ) {
    result[0] += -0.00043551109165754524;
  } else {
    result[0] += 0.1529824600152357;
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9750000000000000888) ) ) {
    result[0] += 0.0016672389199637186;
  } else {
    result[0] += -0.03962709886007224;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8035702820527714785) ) ) {
    result[0] += -0.002288522224695117;
  } else {
    result[0] += 0.03207352444480175;
  }
  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5724391781153673753) ) ) {
    result[0] += -0.026754572076982494;
  } else {
    result[0] += 0.002324748878799915;
  }
  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.13900392495124092) ) ) {
    result[0] += 0.06162159177508255;
  } else {
    result[0] += -0.0011719346730568554;
  }
}

