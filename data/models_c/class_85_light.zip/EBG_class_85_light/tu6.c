
#include "header.h"

void predict_unit6(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7309551922231288801) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5091389307398357378) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2669666665921996418) ) ) {
        result[0] += -0.04492065218653125;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02500000000000000486) ) ) {
          result[0] += -0.0037909852321442628;
        } else {
          result[0] += -0.03504354923602436;
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.647174411118524473) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4850000000000000422) ) ) {
          result[0] += -0.012689876593666112;
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003360500000000000206) ) ) {
            result[0] += -0.032860098311098346;
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3362084851504864025) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004469500000000000382) ) ) {
                result[0] += 0.052169482391518154;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4583473626633166043) ) ) {
                  result[0] += -0.02918159713046863;
                } else {
                  result[0] += 0.0362502328872659;
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.576775970879121469) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2650000000000000688) ) ) {
                  result[0] += 0.004375024440406443;
                } else {
                  result[0] += -0.03636273285959158;
                }
              } else {
                result[0] += -0.016457239709456825;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4493993753087514587) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4093335132160804135) ) ) {
            result[0] += -0.02540505677437276;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4797597438944724013) ) ) {
              result[0] += 0.014162153600282829;
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.08835747683243963535) ) ) {
                result[0] += -0.03091619132499256;
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4327651086396848146) ) ) {
                  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3717431637504806097) ) ) {
                    result[0] += 0.002061379073049248;
                  } else {
                    result[0] += 0.03810448498483426;
                  }
                } else {
                  result[0] += -0.006391831459391951;
                }
              }
            }
          }
        } else {
          result[0] += -0.016588817565547583;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7369297863416220951) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8635248854378615446) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8450000000000000844) ) ) {
          result[0] += 0.006168893481252005;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8115031879405597559) ) ) {
            result[0] += -0.004192892613625729;
          } else {
            result[0] += 0.0036564178979037383;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9228588940825653841) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7377727315577889966) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6704712329721626007) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3687216492462311868) ) ) {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.212199032544347022) ) ) {
                  result[0] += 0.037757497730697344;
                } else {
                  result[0] += -0.004949614544326593;
                }
              } else {
                result[0] += 0.013861243187485361;
              }
            } else {
              result[0] += -0.01133686721587072;
            }
          } else {
            result[0] += 0.023774951281240717;
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.66451851912119142) ) ) {
              result[0] += 0.019854146167287305;
            } else {
              result[0] += 0.03291831890383203;
            }
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6779399817775906278) ) ) {
              result[0] += -0.0034348825544749167;
            } else {
              result[0] += 0.01988837019422035;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8487060949625354622) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9850000000000000977) ) ) {
          result[0] += 0.03139205799560969;
        } else {
          result[0] += 0.015570297998222316;
        }
      } else {
        result[0] += 0.0461861429421176;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7309551922231288801) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5001221156824434688) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2669666665921996418) ) ) {
        result[0] += -0.04473824351932161;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02500000000000000486) ) ) {
          result[0] += -0.0036492205028172088;
        } else {
          result[0] += -0.0348694823486001;
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.647174411118524473) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4850000000000000422) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3606800019942653091) ) ) {
              result[0] += 0.04282899560218748;
            } else {
              result[0] += -0.01905179451417823;
            }
          } else {
            result[0] += -0.014215581639454694;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003360500000000000206) ) ) {
            result[0] += -0.032453255471473805;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5150000000000001243) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2650000000000000688) ) ) {
                result[0] += 0.004974633921705386;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5813400334181016982) ) ) {
                  result[0] += -0.033274304628334986;
                } else {
                  result[0] += -0.01703633463784485;
                }
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004557500000000001654) ) ) {
                result[0] += 0.04509536838194373;
              } else {
                result[0] += -0.013091206794039034;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7050000000000000711) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4190692806030151263) ) ) {
            result[0] += -0.026001266416432776;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.268597040930526498) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05572100000000000664) ) ) {
                result[0] += 0.004026142302970839;
              } else {
                result[0] += -0.01360404645410434;
              }
            } else {
              result[0] += 0.053774790318134535;
            }
          }
        } else {
          result[0] += -0.014040603511891568;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7369297863416220951) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8678581689358929596) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8162318130682130191) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4750000000000000333) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5072261056783921029) ) ) {
              result[0] += 0.0018220170622362062;
            } else {
              result[0] += 0.0382079141288347;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.480405183437169869) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7890731911809046872) ) ) {
                result[0] += -0.0012180686264502449;
              } else {
                result[0] += -0.020143932654304603;
              }
            } else {
              result[0] += 0.025278771191381194;
            }
          }
        } else {
          result[0] += 0.005680286466441925;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9443572767030988802) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8449888203266332498) ) ) {
            result[0] += 0.013169533517318439;
          } else {
            result[0] += 0.0494916304463415;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9150000000000001465) ) ) {
            result[0] += 0.02617427601116589;
          } else {
            result[0] += 0.010331847470888226;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8606418736522790658) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7948589598137713041) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9550000000000000711) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9786254024267102558) ) ) {
              result[0] += 0.023594926225781025;
            } else {
              result[0] += 0.04478121371756676;
            }
          } else {
            result[0] += 0.009975025169539041;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += 0.0366000215130614;
          } else {
            result[0] += 0.02304113745852156;
          }
        }
      } else {
        result[0] += 0.04612817277824636;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7309551922231288801) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5001221156824434688) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2669666665921996418) ) ) {
        result[0] += -0.044560782169725845;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02500000000000000486) ) ) {
          result[0] += -0.003512411787291505;
        } else {
          result[0] += -0.0343879449506199;
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.647174411118524473) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4850000000000000422) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.038794232605861678) ) ) {
            result[0] += 0.015020487757668404;
          } else {
            result[0] += -0.013826929241765342;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.565436264745754591) ) ) {
            result[0] += -0.034562114062586476;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3520526286285806106) ) ) {
              result[0] += 0.018784358124243717;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7150000000000000799) ) ) {
                result[0] += -0.0176147816044749;
              } else {
                result[0] += -0.03061530411282225;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4493993753087514587) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4093335132160804135) ) ) {
            result[0] += -0.024119944751252613;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4797597438944724013) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4529241356532663354) ) ) {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4627502129294571165) ) ) {
                  result[0] += 0.023572175018056894;
                } else {
                  result[0] += -0.028994850143303014;
                }
              } else {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4713523350863212946) ) ) {
                  result[0] += 0.007169082457950109;
                } else {
                  result[0] += 0.051298844480802;
                }
              }
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.08835747683243963535) ) ) {
                result[0] += -0.030013753156594592;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5023065337688443766) ) ) {
                  result[0] += 0.05180678658284614;
                } else {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.08377477200961473691) ) ) {
                    result[0] += 0.03741998271648501;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.341491527034325726) ) ) {
                      result[0] += -0.004976221577003497;
                    } else {
                      result[0] += 0.0431855147194363;
                    }
                  }
                }
              }
            }
          }
        } else {
          result[0] += -0.01563525498232366;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7948589598137713041) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8956174930041188587) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8162318130682130191) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4750000000000000333) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5072261056783921029) ) ) {
              result[0] += 0.0017450553878159201;
            } else {
              result[0] += 0.036353366228638176;
            }
          } else {
            result[0] += -0.0016811046930156038;
          }
        } else {
          result[0] += 0.0069911635964744045;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9815549730476619272) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9350000000000001643) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6779399817775906278) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.875000000000000111) ) ) {
                result[0] += 0.015831699456771722;
              } else {
                result[0] += -0.010505478076987177;
              }
            } else {
              result[0] += 0.022071155201912804;
            }
          } else {
            result[0] += 0.001759241012180206;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += 0.04447582833128491;
          } else {
            result[0] += 0.0238405995720396;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8820243969432238762) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9950000000000001066) ) ) {
          result[0] += 0.03573163127997703;
        } else {
          result[0] += 0.020243375202494415;
        }
      } else {
        result[0] += 0.04639018125980743;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7309551922231288801) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5001221156824434688) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2669666665921996418) ) ) {
        result[0] += -0.044387852178554704;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += -0.026450728845927182;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005139500000000000839) ) ) {
            result[0] += -0.04171223454134467;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7429456371859297636) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9998087951126271022) ) ) {
                result[0] += -0.028115437828476954;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7255694492462312351) ) ) {
                  result[0] += -0.02185422161894513;
                } else {
                  result[0] += 0.05440389682904578;
                }
              }
            } else {
              result[0] += -0.043778314758635695;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.647174411118524473) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4850000000000000422) ) ) {
          result[0] += -0.01237659013224881;
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003360500000000000206) ) ) {
            result[0] += -0.03143544900862384;
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3362084851504864025) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004469500000000000382) ) ) {
                result[0] += 0.04951934712565579;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4583473626633166043) ) ) {
                  result[0] += -0.02806100611053159;
                } else {
                  result[0] += 0.03452876146851689;
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.576775970879121469) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2650000000000000688) ) ) {
                  result[0] += 0.004713617198204111;
                } else {
                  result[0] += -0.03561650496823686;
                }
              } else {
                result[0] += -0.014841758072465315;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7050000000000000711) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4190692806030151263) ) ) {
            result[0] += -0.024744291129813977;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.268597040930526498) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05572100000000000664) ) ) {
                result[0] += 0.004038177068659146;
              } else {
                result[0] += -0.012988745470723734;
              }
            } else {
              result[0] += 0.05025140391563831;
            }
          }
        } else {
          result[0] += -0.013173925932168066;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7948589598137713041) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8956174930041188587) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.827186441538020012) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4750000000000000333) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5072261056783921029) ) ) {
              result[0] += 0.0026594237430554047;
            } else {
              result[0] += 0.03361903311869496;
            }
          } else {
            result[0] += -0.001059117140553449;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
            result[0] += 0.006800298502082039;
          } else {
            result[0] += 0.0469470226980833;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9815549730476619272) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9350000000000001643) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6779399817775906278) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.875000000000000111) ) ) {
                result[0] += 0.015238546548516496;
              } else {
                result[0] += -0.01003687769270459;
              }
            } else {
              result[0] += 0.02134097751912096;
            }
          } else {
            result[0] += 0.0016862505496608282;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += 0.043673954439976875;
          } else {
            result[0] += 0.023127259289299415;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8723822823959714867) ) ) {
        result[0] += 0.03262992126232144;
      } else {
        result[0] += 0.04561752890039096;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7058987689933927667) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4610343496117730866) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2585695341105315181) ) ) {
        result[0] += -0.0443576912618521;
      } else {
        result[0] += -0.03455199819758558;
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5693020021745025527) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2811395042919150877) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7392963230402010977) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02780400000000000579) ) ) {
              result[0] += -0.01660012672469294;
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.05641065258394634824) ) ) {
                result[0] += -0.027996876595377543;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5665181981407035883) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5528143519346734314) ) ) {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2900991079789891347) ) ) {
                      result[0] += -0.015863744066217857;
                    } else {
                      result[0] += 0.04311549894095378;
                    }
                  } else {
                    result[0] += 0.09547252516318236;
                  }
                } else {
                  result[0] += 0;
                }
              }
            }
          } else {
            result[0] += -0.0366151865940088;
          }
        } else {
          result[0] += -0.03176286841279458;
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7050000000000000711) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3750000000000000555) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03083400000000000377) ) ) {
              result[0] += 0.011881420804805379;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6550000000000001377) ) ) {
                result[0] += -0.011173443848566415;
              } else {
                result[0] += 0.03591792209824117;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.268597040930526498) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5916566943077593566) ) ) {
                result[0] += -0.02583189835885075;
              } else {
                result[0] += -0.009164445018316722;
              }
            } else {
              result[0] += 0.03457827247377708;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6181495723579168988) ) ) {
            result[0] += -0.03629065618399531;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4175496798250740715) ) ) {
              result[0] += 0.039424253339064005;
            } else {
              result[0] += -0.019128883108818447;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7369297863416220951) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8635248854378615446) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7863566523687727239) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8150000000000000577) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1270445000000000324) ) ) {
              result[0] += 0.0043017726734565515;
            } else {
              result[0] += -0.01564906348359348;
            }
          } else {
            result[0] += -0.005954901279856045;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5350000000000001421) ) ) {
            result[0] += 0.02607997117621005;
          } else {
            result[0] += 0.002580976752600539;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9228588940825653841) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7377727315577889966) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6704712329721626007) ) ) {
              result[0] += 0.01036234684741521;
            } else {
              result[0] += -0.012543827136356654;
            }
          } else {
            result[0] += 0.021289207965600448;
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5424744603768845153) ) ) {
              result[0] += 0.018082738292857354;
            } else {
              result[0] += 0.03137296772465323;
            }
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6779399817775906278) ) ) {
              result[0] += -0.004569661465725229;
            } else {
              result[0] += 0.01722915845675119;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8606418736522790658) ) ) {
        result[0] += 0.027849774253985694;
      } else {
        result[0] += 0.044772289080054054;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7058987689933927667) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4431477231260214644) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2585695341105315181) ) ) {
        result[0] += -0.044197743469424865;
      } else {
        result[0] += -0.034741956127043505;
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5693020021745025527) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2450000000000000233) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.561925680077866585) ) ) {
            result[0] += -0.013826097837432832;
          } else {
            result[0] += 0.05940566564614836;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += -0.014811573867336196;
          } else {
            result[0] += -0.03136378401254285;
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3766016736370984552) ) ) {
          result[0] += -0.005200820993733977;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6322976420381508644) ) ) {
            result[0] += -0.02733669640011866;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4327651086396848146) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5701775282412061552) ) ) {
                result[0] += -0.0016410970187912223;
              } else {
                result[0] += 0.06539673731976757;
              }
            } else {
              result[0] += -0.015642756250360892;
            }
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7948589598137713041) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.878151846485979104) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8065490128546884963) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8450000000000000844) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5072261056783921029) ) ) {
              result[0] += -0.004114938772818782;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5347136344221107285) ) ) {
                result[0] += 0.024320126892404988;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4750000000000000333) ) ) {
                  result[0] += 0.020655670282561066;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5926917132914574227) ) ) {
                    result[0] += -0.010426190145640305;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6186550572613066512) ) ) {
                      result[0] += 0.03497458332511824;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7602748174788022117) ) ) {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01228150000000000248) ) ) {
                          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5386982849183802324) ) ) {
                            result[0] += 0.04872312882323635;
                          } else {
                            result[0] += -0.008577638756435897;
                          }
                        } else {
                          result[0] += -0.02286846520189701;
                        }
                      } else {
                        result[0] += 0.018827143211780927;
                      }
                    }
                  }
                }
              }
            }
          } else {
            result[0] += -0.004667407888536372;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7350000000000000977) ) ) {
            result[0] += 0.019347719719258215;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.321871344966293327) ) ) {
              result[0] += 0.0030160471302667097;
            } else {
              result[0] += 0.03560315237928287;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9815549730476619272) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6832193430923222399) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
              result[0] += 0.014206800160622902;
            } else {
              result[0] += 0.001262547973826189;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9550000000000000711) ) ) {
              result[0] += 0.019519071418887285;
            } else {
              result[0] += -0.007989339476096771;
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += 0.04246729705806096;
          } else {
            result[0] += 0.021666928260733385;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8820243969432238762) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9950000000000001066) ) ) {
          result[0] += 0.03367512066911655;
        } else {
          result[0] += 0.01755605283281793;
        }
      } else {
        result[0] += 0.045127314055560926;
      }
    }
  }
}

