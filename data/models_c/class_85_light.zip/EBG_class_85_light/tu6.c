
#include "header.h"

void predict_unit6(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7366403613896054248) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5335728757895682461) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2946983627136980366) ) ) {
        result[0] += -0.04823459210330069;
      } else {
        result[0] += -0.03806082296683038;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6337772083671809886) ) ) {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.3121154296828153041) ) ) {
          result[0] += -0.01363239001108393;
        } else {
          result[0] += -0.030213190509159545;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7150000000000000799) ) ) {
          result[0] += -0.004409905318588022;
        } else {
          result[0] += -0.01832690134237597;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8299157965154307925) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8361854181907825145) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6196416197487438771) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)13.50000000000000178) ) ) {
            result[0] += -0.010917058547007048;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003327500000000000163) ) ) {
              result[0] += -0.001699761345806285;
            } else {
              result[0] += 0.011332779741366653;
            }
          }
        } else {
          result[0] += -0.006097092165547931;
        }
      } else {
        if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6845616084030620163) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8950000000000001288) ) ) {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9294374284243890338) ) ) {
              result[0] += 0.018753018068364945;
            } else {
              result[0] += 0.04252480762440231;
            }
          } else {
            result[0] += 0.010330979700287402;
          }
        } else {
          result[0] += 0.025794143757585746;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8999934911843509022) ) ) {
        result[0] += 0.04100598088927932;
      } else {
        result[0] += 0.054037765403304086;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7366403613896054248) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5335728757895682461) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2946983627136980366) ) ) {
        result[0] += -0.047974276370151774;
      } else {
        result[0] += -0.03748483218104756;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6337772083671809886) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5650000000000000577) ) ) {
          result[0] += -0.01723534990650984;
        } else {
          result[0] += -0.032954434619956514;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7150000000000000799) ) ) {
          result[0] += -0.0042191112191457;
        } else {
          result[0] += -0.017704622281283437;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7539078735793690589) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8361854181907825145) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6196416197487438771) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)13.50000000000000178) ) ) {
            result[0] += -0.01046135492456683;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.007033789226816100984) ) ) {
              result[0] += -0.002859718597249337;
            } else {
              result[0] += 0.010224525516220096;
            }
          }
        } else {
          result[0] += -0.0058326102140910975;
        }
      } else {
        if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6845616084030620163) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9050000000000001377) ) ) {
            result[0] += 0.021150368798958673;
          } else {
            result[0] += 0.009526917930689681;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.03907950711894122;
          } else {
            result[0] += 0.022122801005470937;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8604095077903387567) ) ) {
        result[0] += 0.03736925957372131;
      } else {
        result[0] += 0.052113325667333614;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7366403613896054248) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5203205671504794738) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2703145439280746909) ) ) {
        result[0] += -0.04805840964040009;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += -0.029234852121817586;
        } else {
          result[0] += -0.04039870547023718;
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6337772083671809886) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5650000000000000577) ) ) {
          result[0] += -0.017881487817101267;
        } else {
          result[0] += -0.03271620187328915;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7150000000000000799) ) ) {
          result[0] += -0.00403615699906102;
        } else {
          result[0] += -0.017097919222006208;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8299157965154307925) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.686605359504699142) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8550000000000000933) ) ) {
          if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5919132173554727538) ) ) {
            result[0] += 0.004479724784541575;
          } else {
            result[0] += 0.020035280484416492;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.640890220251256415) ) ) {
            result[0] += 0.0030052514427653075;
          } else {
            result[0] += -0.008787599738063673;
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9120665648705957862) ) ) {
          result[0] += 0.014080597643497497;
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7290383838442212605) ) ) {
            result[0] += 0.025714422175790713;
          } else {
            result[0] += 0.0061945665034340534;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8999934911843509022) ) ) {
        result[0] += 0.03917477761300074;
      } else {
        result[0] += 0.05293266801741077;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7366403613896054248) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5335728757895682461) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2946983627136980366) ) ) {
        result[0] += -0.047476393102569306;
      } else {
        result[0] += -0.0363342549738617;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6337772083671809886) ) ) {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.3121154296828153041) ) ) {
          result[0] += -0.011783550197659316;
        } else {
          result[0] += -0.028203175258491895;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7150000000000000799) ) ) {
          result[0] += -0.003860753318472114;
        } else {
          result[0] += -0.016506648897208966;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8299157965154307925) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.686605359504699142) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7750000000000001332) ) ) {
          if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5862093503336099909) ) ) {
            result[0] += 0.00574157341362975;
          } else {
            result[0] += 0.028889949865255726;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1318506552362543327) ) ) {
            result[0] += 0.004746477752521182;
          } else {
            result[0] += -0.0049221413909377;
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8943082925133570837) ) ) {
          result[0] += 0.011337007355460013;
        } else {
          result[0] += 0.021866966924809703;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8945815063191204786) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
          result[0] += 0.04055221186376444;
        } else {
          if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8221629459601094148) ) ) {
            result[0] += -0.004336242302838228;
          } else {
            result[0] += 0.03643290625510565;
          }
        }
      } else {
        result[0] += 0.05220352280766672;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.720877625841553682) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4977750020140985776) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2703145439280746909) ) ) {
        result[0] += -0.047597827610245884;
      } else {
        result[0] += -0.03731621967637425;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6003075279628945493) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5650000000000000577) ) ) {
          result[0] += -0.020585803104824274;
        } else {
          result[0] += -0.03587071138974834;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7150000000000000799) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06334000000000002129) ) ) {
            result[0] += -0.00269844351301988;
          } else {
            result[0] += -0.021651339382240516;
          }
        } else {
          result[0] += -0.02074876963485103;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7539078735793690589) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8361854181907825145) ) ) {
        result[0] += -1.4826321972916614e-05;
      } else {
        if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6845616084030620163) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9294374284243890338) ) ) {
              result[0] += 0.013318591855965185;
            } else {
              result[0] += 0.03095949542114045;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04744554725591895727) ) ) {
              result[0] += 0.00861003909697209;
            } else {
              result[0] += -0.011441748655067844;
            }
          }
        } else {
          result[0] += 0.022199999782255415;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8347688071710012148) ) ) {
        result[0] += 0.03255099622379995;
      } else {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9046795177622769524) ) ) {
          result[0] += 0.043141468628894196;
        } else {
          result[0] += 0.05212794429616352;
        }
      }
    }
  }
}

