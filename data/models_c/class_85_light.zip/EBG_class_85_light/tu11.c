
#include "header.h"

void predict_unit11(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5091389307398357378) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2585695341105315181) ) ) {
      result[0] += -0.040622974157347246;
    } else {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
        result[0] += -0.009970572009529142;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005139500000000000839) ) ) {
          result[0] += -0.033753107672309414;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7429456371859297636) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.735388073517588059) ) ) {
              result[0] += -0.013837731249038643;
            } else {
              result[0] += 0.06231104059377832;
            }
          } else {
            result[0] += -0.03801263038998995;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8420098784315052098) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8455909065280039494) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6623732216749412816) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8550000000000000933) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.25500000000000006) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3950000000000000733) ) ) {
                result[0] += -0.0005237813033852636;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3830383354773237436) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0198885000000000034) ) ) {
                    result[0] += -0.003269501536973247;
                  } else {
                    result[0] += 0.05753517819144383;
                  }
                } else {
                  result[0] += -0.006768924908841797;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08122600000000000653) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.576775970879121469) ) ) {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3181031339503840871) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02952850000000000266) ) ) {
                      result[0] += -0.0023719528281199048;
                    } else {
                      result[0] += 0.056170031917928236;
                    }
                  } else {
                    result[0] += -0.017809123547857887;
                  }
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3654644975094878956) ) ) {
                    result[0] += 0.013290423464008877;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6541365753517588422) ) ) {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3419045205559314016) ) ) {
                        result[0] += -0.006015301465523037;
                      } else {
                        result[0] += -0.030861630490449293;
                      }
                    } else {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002411500000000000449) ) ) {
                        result[0] += -0.0099590624188965;
                      } else {
                        result[0] += 0.019169264132709075;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.025142887400467766;
              }
            }
          } else {
            result[0] += -0.02967887440558088;
          }
        } else {
          result[0] += -0.0007256819907701773;
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7369297863416220951) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8449888203266332498) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.221131098939677084) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.687401154095477529) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6704712329721626007) ) ) {
                  result[0] += 0.004208216804071355;
                } else {
                  result[0] += -0.030598301027389713;
                }
              } else {
                result[0] += 0.013262875884734541;
              }
            } else {
              result[0] += -0.01316837031502336;
            }
          } else {
            result[0] += 0.03835078654906978;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9870276685244862014) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001940500000000000167) ) ) {
                result[0] += 0.03210466670058493;
              } else {
                result[0] += 0.01006597315900598;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01565150000000000222) ) ) {
                result[0] += -0.003996930657232198;
              } else {
                result[0] += 0.03617231544713472;
              }
            }
          } else {
            result[0] += -0.0022590642678162734;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9435227614686748643) ) ) {
        result[0] += 0.026966674015299875;
      } else {
        result[0] += 0.03955948711006832;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5091389307398357378) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2585695341105315181) ) ) {
      result[0] += -0.04046686737871468;
    } else {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
        result[0] += -0.009634870428264096;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005139500000000000839) ) ) {
          result[0] += -0.033364588673656465;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7429456371859297636) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
              result[0] += -0.013290816432120852;
            } else {
              result[0] += 0.06652220119199807;
            }
          } else {
            result[0] += -0.037736835482718264;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8420098784315052098) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.878151846485979104) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6809682101532212872) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5665181981407035883) ) ) {
              if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.07196201389915944657) ) ) {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
                  result[0] += 0.0367766795379743;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4075435166080402793) ) ) {
                    result[0] += -0.022867657945798113;
                  } else {
                    if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3362084851504864025) ) ) {
                      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3219690287256820604) ) ) {
                        result[0] += -0.005207493913882496;
                      } else {
                        result[0] += 0.05529654958253544;
                      }
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6278115323581056062) ) ) {
                        result[0] += -0.01399626368675613;
                      } else {
                        result[0] += 0.02303341052104781;
                      }
                    }
                  }
                }
              } else {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.0491948752242571466) ) ) {
                  result[0] += 0.061622781020312836;
                } else {
                  result[0] += 0.007212758680935721;
                }
              }
            } else {
              result[0] += -0.010894119626818022;
            }
          } else {
            result[0] += -0.00986338040681969;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.480405183437169869) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7810201528643216928) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.013855723816631915) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007216500000000001559) ) ) {
                  result[0] += -0.002404760713555473;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01663850000000000398) ) ) {
                    if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.06765554132556478306) ) ) {
                      result[0] += 0.014752780290702865;
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5917931336432161737) ) ) {
                        result[0] += -0.00890278698250104;
                      } else {
                        result[0] += 0.01447871374298329;
                      }
                    }
                  } else {
                    result[0] += -0.0006671881680969874;
                  }
                }
              } else {
                result[0] += 0.029327686130874903;
              }
            } else {
              result[0] += -0.011066632836113014;
            }
          } else {
            result[0] += 0.01828670738683922;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9999977834869465676) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7369297863416220951) ) ) {
            result[0] += 0.005196420252272459;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001940500000000000167) ) ) {
                result[0] += 0.03175963317715974;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9786254024267102558) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3837516359296482826) ) ) {
                    result[0] += -0.011993583342282987;
                  } else {
                    result[0] += 0.009791780901998993;
                  }
                } else {
                  result[0] += 0.021389732647525316;
                }
              }
            } else {
              result[0] += -0.002695089264489474;
            }
          }
        } else {
          result[0] += 0.04042369248005293;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9435227614686748643) ) ) {
        result[0] += 0.02644721849692428;
      } else {
        result[0] += 0.03927932463843672;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5001221156824434688) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2585695341105315181) ) ) {
      result[0] += -0.040307804705194884;
    } else {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
        result[0] += -0.009348926168036547;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005139500000000000839) ) ) {
          result[0] += -0.033947747730284354;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7429456371859297636) ) ) {
            result[0] += -0.011817322168073947;
          } else {
            result[0] += -0.038522952287226936;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8420098784315052098) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.827186441538020012) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.647174411118524473) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.625000000000000111) ) ) {
            result[0] += -0.00410577783434965;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.321871344966293327) ) ) {
              result[0] += -0.019364667962185826;
            } else {
              result[0] += 0.017759999115750408;
            }
          }
        } else {
          result[0] += -0.001093651156312589;
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9228588940825653841) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8449888203266332498) ) ) {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7509562601305637131) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6157932186745959102) ) ) {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.5724391781153673753) ) ) {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
                    result[0] += 0.020721943150893592;
                  } else {
                    result[0] += -0.02603264437095144;
                  }
                } else {
                  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5586843525377236386) ) ) {
                    result[0] += 0.009955766349303707;
                  } else {
                    result[0] += 0.03850642404904606;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.008262500000000000747) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.683473227135678485) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00779400000000000058) ) ) {
                      result[0] += 0.0002568813680314745;
                    } else {
                      result[0] += 0.035582241590907414;
                    }
                  } else {
                    result[0] += 0.01802081573724883;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5792515097236182742) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8550000000000000933) ) ) {
                      result[0] += 0.0034604291961586376;
                    } else {
                      result[0] += -0.03392235651559098;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5917931336432161737) ) ) {
                      result[0] += -0.041350577557848475;
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05989750000000000629) ) ) {
                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8030059940338053481) ) ) {
                          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.578408582175358732) ) ) {
                            result[0] += -0.02810801511158536;
                          } else {
                            result[0] += 0.003511856338518316;
                          }
                        } else {
                          result[0] += -0.025981004843206455;
                        }
                      } else {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.170592500000000008) ) ) {
                          result[0] += 0.019715525815081507;
                        } else {
                          result[0] += -0.014756876044855706;
                        }
                      }
                    }
                  }
                }
              }
            } else {
              result[0] += 0.03544090493076486;
            }
          } else {
            result[0] += 0.04012116784586414;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9999977834869465676) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9023325039857709173) ) ) {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8244912349994802936) ) ) {
                result[0] += 0.008712422570335073;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.966590843157139501) ) ) {
                  result[0] += 0.02808855796032471;
                } else {
                  result[0] += -0.021722729662280758;
                }
              }
            } else {
              result[0] += -0.006835514693350048;
            }
          } else {
            result[0] += 0.040014701733690934;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9435227614686748643) ) ) {
        result[0] += 0.02592784540546015;
      } else {
        result[0] += 0.03899657625174797;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5001221156824434688) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2585695341105315181) ) ) {
      result[0] += -0.040145586517481256;
    } else {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
        result[0] += -0.00902940511658712;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005139500000000000839) ) ) {
          result[0] += -0.033569326444719425;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7429456371859297636) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9998087951126271022) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1750000000000000167) ) ) {
                result[0] += -0.022503706858489198;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09500000000000001499) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3932044553488939775) ) ) {
                    result[0] += -0.0044436175287529064;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5528143519346734314) ) ) {
                      result[0] += 0;
                    } else {
                      result[0] += 0.15838502139450328;
                    }
                  }
                } else {
                  result[0] += -0.009437413700325872;
                }
              }
            } else {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1787026072373491259) ) ) {
                result[0] += 0.08045164695154707;
              } else {
                result[0] += -0.013343040912920628;
              }
            }
          } else {
            result[0] += -0.03826987553447351;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8420098784315052098) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.827186441538020012) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6322976420381508644) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3474442649552166307) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.038794232605861678) ) ) {
              result[0] += 0.03372601614075034;
            } else {
              result[0] += -0.004368853271146577;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4750000000000000333) ) ) {
              result[0] += -0.022820882063271247;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0003145000000000000551) ) ) {
                result[0] += 0.03994936294858839;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002749500000000000641) ) ) {
                  result[0] += -0.020884071761074922;
                } else {
                  result[0] += 0.0073790718110044486;
                }
              }
            }
          }
        } else {
          result[0] += -0.0011692991668695047;
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6832193430923222399) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9350000000000001643) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00106650000000000039) ) ) {
              result[0] += -0.0333528387631319;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9660912024445539314) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6532207681155780543) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05851400000000000351) ) ) {
                    result[0] += 0.007786469225159944;
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06624350000000001071) ) ) {
                      result[0] += -0.03760396774313848;
                    } else {
                      result[0] += -0.0015498501562443018;
                    }
                  }
                } else {
                  result[0] += 0.01779704122190223;
                }
              } else {
                result[0] += 0.03633938335602016;
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
              result[0] += -0.00030910930013456755;
            } else {
              result[0] += 0.04384816360264955;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9999977834869465676) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9023325039857709173) ) ) {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8244912349994802936) ) ) {
                result[0] += 0.008500542792376227;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.966590843157139501) ) ) {
                  result[0] += 0.0275133803345299;
                } else {
                  result[0] += -0.02066170767208314;
                }
              }
            } else {
              result[0] += -0.006519326645291219;
            }
          } else {
            result[0] += 0.03934251330132004;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9497779465347261363) ) ) {
        result[0] += 0.025913382853656144;
      } else {
        result[0] += 0.039301378727766234;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4649337835814208453) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2585695341105315181) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3364400153015075223) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1470012909078650398) ) ) {
          result[0] += -0.021367679430131317;
        } else {
          result[0] += 0.07675220365957086;
        }
      } else {
        result[0] += -0.0405162937390973;
      }
    } else {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
        result[0] += -0.009678769232793698;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005956500000000000856) ) ) {
          result[0] += -0.03322201030497381;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7429456371859297636) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.735388073517588059) ) ) {
              result[0] += -0.014219548161922122;
            } else {
              result[0] += 0.05629638270405857;
            }
          } else {
            result[0] += -0.04007409744508815;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8487060949625354622) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.827186441538020012) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6322976420381508644) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5950000000000000844) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
                result[0] += 0.04872294285305534;
              } else {
                result[0] += -0.012322485311639;
              }
            } else {
              result[0] += -0.005810701153939695;
            }
          } else {
            result[0] += -0.018041314420871403;
          }
        } else {
          result[0] += -0.001119929009248371;
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9228588940825653841) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8449888203266332498) ) ) {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7509562601305637131) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6157932186745959102) ) ) {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.5724391781153673753) ) ) {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
                    result[0] += 0.019712912199287967;
                  } else {
                    result[0] += -0.02506424387700903;
                  }
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.022090000000000002) ) ) {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006956500000000000877) ) ) {
                      result[0] += -0.0008758199889416741;
                    } else {
                      result[0] += 0.03456075265555405;
                    }
                  } else {
                    result[0] += 0.006359146405395622;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.008262500000000000747) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.27189557750136778) ) ) {
                    result[0] += 0.00011816739980977958;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8391219607133014735) ) ) {
                      result[0] += -0.01517489952909942;
                    } else {
                      result[0] += 0.016424047059554695;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5392639039447236771) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5233231360301507928) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02608300000000000549) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9094719547178627961) ) ) {
                          result[0] += 0.013224045379198987;
                        } else {
                          result[0] += -0.01365655544449994;
                        }
                      } else {
                        result[0] += -0.017095913728271243;
                      }
                    } else {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009800500000000001918) ) ) {
                        result[0] += -0.01200655519540768;
                      } else {
                        result[0] += 0.041625690948683174;
                      }
                    }
                  } else {
                    result[0] += -0.008162357028664713;
                  }
                }
              }
            } else {
              result[0] += 0.03474892856448291;
            }
          } else {
            result[0] += 0.03835777064003997;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9999977834869465676) ) ) {
            result[0] += 0.008568801971956993;
          } else {
            result[0] += 0.036217536054012955;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9497779465347261363) ) ) {
        result[0] += 0.026052743944538933;
      } else {
        result[0] += 0.03902972763576813;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4649337835814208453) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2585695341105315181) ) ) {
      result[0] += -0.039810293910411396;
    } else {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
        result[0] += -0.009352296528990344;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005956500000000000856) ) ) {
          result[0] += -0.03283581051344129;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7429456371859297636) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7218051716834171794) ) ) {
              result[0] += -0.014967506817009306;
            } else {
              result[0] += 0.02487369969696706;
            }
          } else {
            result[0] += -0.039880909437982504;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8487060949625354622) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7863566523687727239) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5813400334181016982) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.285476170085738834) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7392963230402010977) ) ) {
              result[0] += 0.000454885983975983;
            } else {
              result[0] += -0.024864473880863953;
            }
          } else {
            result[0] += -0.017557972978754537;
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4327651086396848146) ) ) {
            result[0] += 0.003231176958807627;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7058987689933927667) ) ) {
              result[0] += -0.0081674119414355;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1270445000000000324) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4850000000000000422) ) ) {
                  if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.0841877145549009831) ) ) {
                    result[0] += 0;
                  } else {
                    result[0] += 0.02584450896073398;
                  }
                } else {
                  result[0] += -0.001812413027084044;
                }
              } else {
                result[0] += -0.01954899305205672;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9228588940825653841) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.5724391781153673753) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.212199032544347022) ) ) {
              result[0] += 0.02627156021958554;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4308386641708542575) ) ) {
                result[0] += -0.007310524025754568;
              } else {
                result[0] += -0.046133842408380685;
              }
            }
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2328444889043961574) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001014500000000000211) ) ) {
                result[0] += -0.011411463336775653;
              } else {
                result[0] += 0.012898336970502421;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5150000000000001243) ) ) {
                result[0] += 0.02411501551330098;
              } else {
                if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7509562601305637131) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7377727315577889966) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8030059940338053481) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6914593314070353047) ) ) {
                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6704712329721626007) ) ) {
                          result[0] += -5.433674387106677e-05;
                        } else {
                          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
                            result[0] += -0.057857611399291374;
                          } else {
                            result[0] += 0;
                          }
                        }
                      } else {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6461954822149375) ) ) {
                          result[0] += 0.03499205079577488;
                        } else {
                          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009800500000000001918) ) ) {
                            result[0] += -0.018253830776210525;
                          } else {
                            result[0] += 0.02548240031144256;
                          }
                        }
                      }
                    } else {
                      result[0] += -0.0216331438630563;
                    }
                  } else {
                    result[0] += 0.007692395949739833;
                  }
                } else {
                  result[0] += 0.03379345758412382;
                }
              }
            }
          }
        } else {
          result[0] += 0.00870000507383806;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9497779465347261363) ) ) {
        result[0] += 0.025541564229970018;
      } else {
        result[0] += 0.038755006516100844;
      }
    }
  }
}

