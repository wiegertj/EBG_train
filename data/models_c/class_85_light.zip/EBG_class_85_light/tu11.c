
#include "header.h"

void predict_unit11(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05595150000000000817) ) ) {
    result[0] += 0.002718936793644149;
  } else {
    result[0] += -0.01407538316249692;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5714860158952760338) ) ) {
    result[0] += -0.006092586128958;
  } else {
    result[0] += 0.006040427412204008;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
    result[0] += 0.004663084493317529;
  } else {
    result[0] += -0.008623908504515486;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8711888949744006627) ) ) {
    result[0] += -0.0010454476789693253;
  } else {
    result[0] += 0.03562513342179405;
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    result[0] += 0.0009602048048826851;
  } else {
    result[0] += -0.04225327115643062;
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6722423356281408413) ) ) {
    result[0] += -0.0029812248323782134;
  } else {
    result[0] += 0.012037446560122598;
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6277403467108452206) ) ) {
    result[0] += 0.0027435222630849904;
  } else {
    result[0] += -0.01312452530030139;
  }
  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1850000000000000255) ) ) {
    result[0] += 0.02822518869089274;
  } else {
    result[0] += -0.0012654677521666666;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3936276107755155018) ) ) {
    result[0] += -0.03300129835664589;
  } else {
    result[0] += 0.0012265970996374852;
  }
  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02500000000000000486) ) ) {
    result[0] += 0.09197249636235437;
  } else {
    result[0] += -0.00039697983416383956;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.229397005547024746) ) ) {
    result[0] += -0.06946646627086553;
  } else {
    result[0] += 0.0005297663831432373;
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5912899923618091247) ) ) {
    result[0] += -0.004703067193206954;
  } else {
    result[0] += 0.007684681078183497;
  }
  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3640888533806194149) ) ) {
    result[0] += 0.013654634915066856;
  } else {
    result[0] += -0.0027371592245752432;
  }
  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.25500000000000006) ) ) {
    result[0] += 0.021724518117734275;
  } else {
    result[0] += -0.0016624304122810321;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5343557630381970958) ) ) {
    result[0] += -0.019820690124786048;
  } else {
    result[0] += 0.001967267279192069;
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
    result[0] += 0.01781604204689438;
  } else {
    result[0] += -0.001946642246441393;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7238160268635116523) ) ) {
    result[0] += -0.009289547058721682;
  } else {
    result[0] += 0.00406195595788791;
  }
  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5724391781153673753) ) ) {
    result[0] += -0.020074639974821683;
  } else {
    result[0] += 0.0017341168248191227;
  }
  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.13900392495124092) ) ) {
    result[0] += 0.04289358129676841;
  } else {
    result[0] += -0.0008362519142162901;
  }
}

