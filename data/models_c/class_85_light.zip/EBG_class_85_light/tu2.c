
#include "header.h"

void predict_unit2(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8065490128546884963) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.647174411118524473) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4431477231260214644) ) ) {
        result[0] += -0.05118234385219545;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0198885000000000034) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4850000000000000422) ) ) {
              result[0] += -0.034964827011612735;
            } else {
              result[0] += -0.011335039377024117;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003360500000000000206) ) ) {
              result[0] += -0.04761583316282004;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5813400334181016982) ) ) {
                result[0] += -0.043693138419341214;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
                  result[0] += 0.011180033554355567;
                } else {
                  result[0] += -0.03273347618716271;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5826692266582915725) ) ) {
            if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.07196201389915944657) ) ) {
              result[0] += -0.032648918924773784;
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.04658055172941339556) ) ) {
                result[0] += 0.04346251207820658;
              } else {
                result[0] += -0.01746560437727197;
              }
            }
          } else {
            result[0] += -0.038356687277951634;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7058987689933927667) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7050000000000000711) ) ) {
          result[0] += -0.012514578278885968;
        } else {
          result[0] += -0.03414616291839717;
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8450000000000000844) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7460826136121967433) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4245384058542713834) ) ) {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4079008550763859042) ) ) {
                result[0] += 0.0001350708945560824;
              } else {
                result[0] += -0.041427813914807286;
              }
            } else {
              result[0] += -0.0008770094420668837;
            }
          } else {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4879682222881388531) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1270445000000000324) ) ) {
                result[0] += 0.016555547817494787;
              } else {
                result[0] += -0.009519826551161546;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7255694492462312351) ) ) {
                result[0] += -0.011194953696519686;
              } else {
                result[0] += 0.04745241545146338;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7728505831511113255) ) ) {
            result[0] += -0.017236535329544004;
          } else {
            result[0] += -0.0044753272243121854;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6966902637519932773) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8956174930041188587) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8455909065280039494) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5796417489869073458) ) ) {
            result[0] += 0.029287880982702193;
          } else {
            result[0] += 0.007080907457444757;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8352912313316583903) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02120850000000000166) ) ) {
              result[0] += 0.02781381253632751;
            } else {
              result[0] += 0.016294245970480147;
            }
          } else {
            result[0] += 0.05632279382178827;
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9268618155849429607) ) ) {
            result[0] += 0.039403403222612786;
          } else {
            result[0] += 0.05298205739386815;
          }
        } else {
          result[0] += 0.033328754447132805;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8244912349994802936) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7369297863416220951) ) ) {
          result[0] += 0.04913541938987663;
        } else {
          result[0] += 0.05828316655059433;
        }
      } else {
        result[0] += 0.06932364584683152;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8065490128546884963) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.647174411118524473) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4431477231260214644) ) ) {
        result[0] += -0.050611728648362685;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0198885000000000034) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += -0.03226024770697801;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003360500000000000206) ) ) {
              result[0] += -0.04691214373701396;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5813400334181016982) ) ) {
                result[0] += -0.042946519914815566;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
                  result[0] += 0.010679154011508861;
                } else {
                  result[0] += -0.03192371635959918;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5665181981407035883) ) ) {
            if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.07196201389915944657) ) ) {
              result[0] += -0.031828698698711244;
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.04658055172941339556) ) ) {
                result[0] += 0.04093206989899665;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5613540176884422861) ) ) {
                  result[0] += -0.021801454181507904;
                } else {
                  result[0] += 0.034964477527153794;
                }
              }
            }
          } else {
            result[0] += -0.037195324934624824;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7058987689933927667) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7050000000000000711) ) ) {
          result[0] += -0.01205476298859685;
        } else {
          result[0] += -0.033331118352795515;
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8450000000000000844) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7460826136121967433) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4850000000000000422) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5191847285678393709) ) ) {
                result[0] += -0.009060192299145484;
              } else {
                result[0] += 0.024963299788893716;
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4245384058542713834) ) ) {
                result[0] += -0.0361504002762206;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  result[0] += 0.042999039684020066;
                } else {
                  result[0] += -0.008164130246809623;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6650000000000001465) ) ) {
              result[0] += 0.010686574514400665;
            } else {
              result[0] += -0.009335330000728953;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7728505831511113255) ) ) {
            result[0] += -0.016635564754528185;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7269078701507538653) ) ) {
              result[0] += -0.0010881754100079215;
            } else {
              result[0] += -0.01976125225194898;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7093072464629580631) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.878151846485979104) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8455909065280039494) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5796417489869073458) ) ) {
            result[0] += 0.027881829948611596;
          } else {
            result[0] += 0.006764394534351907;
          }
        } else {
          result[0] += 0.02251204227462267;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9306042630674427052) ) ) {
          result[0] += 0.03484434714723148;
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
            result[0] += 0.05257651215454787;
          } else {
            result[0] += 0.03316431297554964;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8420098784315052098) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7369297863416220951) ) ) {
          result[0] += 0.04752867943868018;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += 0.05855323762926482;
          } else {
            result[0] += 0.0444287460860038;
          }
        }
      } else {
        result[0] += 0.06775889891128505;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8065490128546884963) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.647174411118524473) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4431477231260214644) ) ) {
        result[0] += -0.05006913374210509;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.565436264745754591) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
            result[0] += -0.03531760830780597;
          } else {
            result[0] += -0.04488550751395967;
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3474442649552166307) ) ) {
            result[0] += -0.02102015042656125;
          } else {
            result[0] += -0.03909943995227009;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7058987689933927667) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7050000000000000711) ) ) {
          result[0] += -0.011609926521386104;
        } else {
          result[0] += -0.0325331609472815;
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8450000000000000844) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7460826136121967433) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2565420174990447055) ) ) {
              result[0] += -0.019333464330182435;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                result[0] += 0.04481491579961317;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3892782419974109565) ) ) {
                  result[0] += 0.0034652419482452735;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6732382808793971884) ) ) {
                    result[0] += -0.04385502653344286;
                  } else {
                    result[0] += -0.00408072632763283;
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4879682222881388531) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1270445000000000324) ) ) {
                result[0] += 0.015319501647112184;
              } else {
                result[0] += -0.009564840404733781;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6392692949748745024) ) ) {
                result[0] += -0.015089908737258049;
              } else {
                result[0] += 0.02683005836791976;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7728505831511113255) ) ) {
            result[0] += -0.01605280982580725;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7269078701507538653) ) ) {
              result[0] += -0.001042274047136529;
            } else {
              result[0] += -0.019087544098208994;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7369297863416220951) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8956174930041188587) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8455909065280039494) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5796417489869073458) ) ) {
            result[0] += 0.026561005562004792;
          } else {
            result[0] += 0.006462785447909733;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8352912313316583903) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02120850000000000166) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0006865000000000001526) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.795000000000000151) ) ) {
                  result[0] += 0.01763416075920505;
                } else {
                  result[0] += -0.034401093906021966;
                }
              } else {
                result[0] += 0.027329019063778295;
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9350000000000001643) ) ) {
                result[0] += 0.02071640099426574;
              } else {
                result[0] += 0.001703507537831377;
              }
            }
          } else {
            result[0] += 0.05258211043454041;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9443572767030988802) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9050000000000001377) ) ) {
            result[0] += 0.038250137325181746;
          } else {
            result[0] += 0;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9150000000000001465) ) ) {
            result[0] += 0.051672574436818684;
          } else {
            result[0] += 0.034252093316461986;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8487060949625354622) ) ) {
        result[0] += 0.05540887853987271;
      } else {
        result[0] += 0.06604233322447332;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8065490128546884963) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.647174411118524473) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4431477231260214644) ) ) {
        result[0] += -0.04955217874777038;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.561925680077866585) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
            result[0] += -0.03505017797165715;
          } else {
            result[0] += -0.04421896587935248;
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3474442649552166307) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0412270000000000067) ) ) {
                result[0] += 0.04816679883501483;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2651510000000000811) ) ) {
                  result[0] += -0.024871205499605583;
                } else {
                  result[0] += 0.02498579542187974;
                }
              }
            } else {
              result[0] += -0.02401084973523293;
            }
          } else {
            result[0] += -0.03879433562848582;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7058987689933927667) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7050000000000000711) ) ) {
          result[0] += -0.011179666681034178;
        } else {
          result[0] += -0.031751202476643134;
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8450000000000000844) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7690514563494603717) ) ) {
            result[0] += -0.0017505485496840732;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02713200000000000334) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6446104073115578315) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4797597438944724013) ) ) {
                  result[0] += 0.006301520872187451;
                } else {
                  result[0] += -0.02505287422590668;
                }
              } else {
                result[0] += 0.0255795457265245;
              }
            } else {
              result[0] += 0.021034797240191132;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7728505831511113255) ) ) {
            result[0] += -0.015487768538204263;
          } else {
            result[0] += -0.003960105672424628;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7369297863416220951) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8956174930041188587) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8583556158382011914) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8150000000000000577) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4583473626633166043) ) ) {
              result[0] += 0.004751257809476166;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006956500000000000877) ) ) {
                result[0] += -0.0029444792697296304;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02454350000000000628) ) ) {
                  result[0] += 0.06264723967896389;
                } else {
                  result[0] += 0.026260117337812694;
                }
              }
            }
          } else {
            result[0] += 0.008971996421640881;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2959821382502911269) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0007215000000000000276) ) ) {
              result[0] += -0.015659232754048277;
            } else {
              result[0] += 0.02112189058746078;
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              result[0] += 0.02527052771182349;
            } else {
              result[0] += 0.05121287703216478;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9443572767030988802) ) ) {
          result[0] += 0.03615611085710972;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9250000000000001554) ) ) {
            result[0] += 0.049484213506680884;
          } else {
            result[0] += 0.031145402002034306;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8420098784315052098) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9815549730476619272) ) ) {
            result[0] += 0.052139587851064505;
          } else {
            result[0] += 0.062242467772609625;
          }
        } else {
          result[0] += 0.0408268972593544;
        }
      } else {
        result[0] += 0.06423080291087542;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8016764265861101579) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.647174411118524473) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4431477231260214644) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2669666665921996418) ) ) {
          result[0] += -0.05052500744127561;
        } else {
          result[0] += -0.04611676503784394;
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0198885000000000034) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4850000000000000422) ) ) {
              result[0] += -0.031855018150010246;
            } else {
              result[0] += -0.007693462202214895;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003360500000000000206) ) ) {
              result[0] += -0.045074906353065575;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5813400334181016982) ) ) {
                result[0] += -0.040878983057188206;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
                  result[0] += 0.012054825703609056;
                } else {
                  result[0] += -0.029294386956098442;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6549033795359899823) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6729764489447237485) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.287353500000000095) ) ) {
                result[0] += -0.02566200750965015;
              } else {
                result[0] += 0.03809346489831503;
              }
            } else {
              result[0] += 0.038677035209591024;
            }
          } else {
            result[0] += -0.03908320457334917;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7058987689933927667) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7050000000000000711) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4549440021356783714) ) ) {
            result[0] += -0.026520173076260166;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4737195465326633492) ) ) {
              result[0] += 0.03176853651446835;
            } else {
              result[0] += -0.011124201053023171;
            }
          }
        } else {
          result[0] += -0.030984288527432704;
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7850000000000001421) ) ) {
          result[0] += 0.0030505279810250454;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7648528436111127204) ) ) {
            result[0] += -0.014555754239915498;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5350000000000001421) ) ) {
              result[0] += 0.04499862722597936;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.714147492562814179) ) ) {
                result[0] += -0.0025785931545378514;
              } else {
                result[0] += -0.018401892969294665;
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7369297863416220951) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8956174930041188587) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8455909065280039494) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8550000000000000933) ) ) {
            result[0] += 0.02162242975490414;
          } else {
            result[0] += 0.004703966954931658;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8352912313316583903) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02120850000000000166) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0006865000000000001526) ) ) {
                result[0] += -0.003821409507559223;
              } else {
                result[0] += 0.025094410375280395;
              }
            } else {
              result[0] += 0.012718332628921705;
            }
          } else {
            result[0] += 0.04928594412931396;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9443572767030988802) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9050000000000001377) ) ) {
            result[0] += 0.035172757673317116;
          } else {
            result[0] += 0;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9150000000000001465) ) ) {
            result[0] += 0.048079301097344804;
          } else {
            result[0] += 0.031454515581753856;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8606418736522790658) ) ) {
        result[0] += 0.05247984671181616;
      } else {
        result[0] += 0.06307648450369845;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8016764265861101579) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5813400334181016982) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4431477231260214644) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2585695341105315181) ) ) {
          result[0] += -0.050159902787147215;
        } else {
          result[0] += -0.04567424682382036;
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
            result[0] += 0.009575961420425006;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.314561000000000035) ) ) {
              result[0] += -0.03318269979401755;
            } else {
              result[0] += 0.014354905447922332;
            }
          }
        } else {
          result[0] += -0.042035712949493036;
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7012238381832097689) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7050000000000000711) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.292381066124493438) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02258350000000000288) ) ) {
                if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3163188596495863369) ) ) {
                  result[0] += 0.05094718994589122;
                } else {
                  result[0] += -0.0019039405270075205;
                }
              } else {
                result[0] += -0.013309619181056177;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6322976420381508644) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002305000000000000462) ) ) {
                  result[0] += -0.013207390433931656;
                } else {
                  result[0] += -0.03322136102542715;
                }
              } else {
                result[0] += -0.015609493086133372;
              }
            }
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.333287149483310563) ) ) {
              result[0] += -0.016135847087632906;
            } else {
              result[0] += 0.06657559697105832;
            }
          }
        } else {
          result[0] += -0.03460751739885348;
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7850000000000001421) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7460826136121967433) ) ) {
            result[0] += -0.003227582599491971;
          } else {
            result[0] += 0.008441806231462413;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7648528436111127204) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0003145000000000000551) ) ) {
              result[0] += 0.008064462076117485;
            } else {
              result[0] += -0.015812602459708325;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5350000000000001421) ) ) {
              result[0] += 0.04273898441777497;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3902192490452261464) ) ) {
                result[0] += 0.014468288093015846;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005834500000000000276) ) ) {
                  result[0] += -0.012506886648311262;
                } else {
                  result[0] += 0.001837590395681774;
                }
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7369297863416220951) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8842728335152491015) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8455909065280039494) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8650000000000001021) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.7450000000000001066) ) ) {
              result[0] += 0.021929925068099727;
            } else {
              result[0] += -0.025276527178918748;
            }
          } else {
            result[0] += 0.004190322256354857;
          }
        } else {
          result[0] += 0.01939736179570843;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9443572767030988802) ) ) {
          result[0] += 0.032085351550352456;
        } else {
          result[0] += 0.043630883098420316;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8420098784315052098) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9815549730476619272) ) ) {
            result[0] += 0.04885233461315766;
          } else {
            result[0] += 0.05893414509415443;
          }
        } else {
          result[0] += 0.03758335446950243;
        }
      } else {
        result[0] += 0.061262170932035995;
      }
    }
  }
}

