
#include "header.h"

void predict_unit2(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007225500000000000152) ) ) {
    result[0] += -0.025022397035738927;
  } else {
    result[0] += 0.02124866647116769;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1594586647043804151) ) ) {
    result[0] += -0.19992390353773948;
  } else {
    result[0] += 0.002561742773898807;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9361616408410365908) ) ) {
    result[0] += -0.0030160146932768548;
  } else {
    result[0] += 0.14997930734651546;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1594586647043804151) ) ) {
    result[0] += -0.1964320491372439;
  } else {
    result[0] += 0.0020771172116351815;
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.850000000000000659e-05) ) ) {
    result[0] += 0.07874667677658334;
  } else {
    result[0] += -0.005463959968219236;
  }
  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.13900392495124092) ) ) {
    result[0] += 0.1427310518669949;
  } else {
    result[0] += -0.002858271762801084;
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8063392272619006595) ) ) {
    result[0] += -0.008326232806056409;
  } else {
    result[0] += 0.0476990405253617;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5948284698255842384) ) ) {
    result[0] += -0.042896619297262094;
  } else {
    result[0] += 0.008352519213433472;
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.04546417654371086997) ) ) {
    result[0] += -0.2024916681964517;
  } else {
    result[0] += 0.0016166480072069573;
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
    result[0] += 0.07120348189370752;
  } else {
    result[0] += -0.005016625782189623;
  }
  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01297350000000000066) ) ) {
    result[0] += -0.01596349719672076;
  } else {
    result[0] += 0.02204010993503491;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9532871366621060716) ) ) {
    result[0] += -0.0020077008606345244;
  } else {
    result[0] += 0.16257923630263163;
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6277403467108452206) ) ) {
    result[0] += 0.00830744323895254;
  } else {
    result[0] += -0.03719673794643665;
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.04546417654371086997) ) ) {
    result[0] += -0.1999095678754239;
  } else {
    result[0] += 0.0013463681929151473;
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.850000000000000659e-05) ) ) {
    result[0] += 0.061440055628987474;
  } else {
    result[0] += -0.004492725168303708;
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003179500000000000468) ) ) {
    result[0] += -0.025099277854773765;
  } else {
    result[0] += 0.011014536991527322;
  }
  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.13900392495124092) ) ) {
    result[0] += 0.11184145366497457;
  } else {
    result[0] += -0.002213859891207925;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9694495419873773168) ) ) {
    result[0] += -0.001336152026122788;
  } else {
    result[0] += 0.18118454004904067;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.795000000000000151) ) ) {
    result[0] += 0.02181484236740341;
  } else {
    result[0] += -0.010895350992628136;
  }
}

