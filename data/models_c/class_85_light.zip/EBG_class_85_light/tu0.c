
#include "header.h"

void predict_unit0(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8361854181907825145) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7055997140865902795) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5335728757895682461) ) ) {
        result[0] += -0.8372029798751338;
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6574910164466515328) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5650000000000000577) ) ) {
            result[0] += -0.8163113211369368;
          } else {
            result[0] += -0.8287337718458684;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.795000000000000151) ) ) {
            result[0] += -0.8024650214913183;
          } else {
            result[0] += -0.8210527560394125;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7546204900970914231) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7750000000000001332) ) ) {
          result[0] += -0.7786845495969669;
        } else {
          result[0] += -0.800764351337825;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8450000000000000844) ) ) {
          result[0] += -0.7474932253481485;
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.793392967338620303) ) ) {
            result[0] += -0.7847674825874851;
          } else {
            result[0] += -0.7620541164778807;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7868431215179150229) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8943082925133570837) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.863112229636659456) ) ) {
          result[0] += -0.7280692856080675;
        } else {
          result[0] += -0.7064494704801095;
        }
      } else {
        result[0] += -0.6842939724378577;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8347688071710012148) ) ) {
        if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8299157965154307925) ) ) {
          result[0] += -0.6626163829510703;
        } else {
          result[0] += -0.6474970359197354;
        }
      } else {
        result[0] += -0.6304500996945681;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8361854181907825145) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7055997140865902795) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5335728757895682461) ) ) {
        result[0] += -0.06321589082968603;
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6524156763781451263) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5650000000000000577) ) ) {
            result[0] += -0.04269992817700067;
          } else {
            result[0] += -0.05514777597905099;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6950000000000000622) ) ) {
            result[0] += -0.024141624689631658;
          } else {
            result[0] += -0.044503872689985235;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7656222061929859324) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8150000000000000577) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7366403613896054248) ) ) {
            result[0] += -0.014457260336954615;
          } else {
            result[0] += 0.0101288637598219;
          }
        } else {
          result[0] += -0.026789072116056543;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8450000000000000844) ) ) {
          result[0] += 0.024761176148029463;
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.793392967338620303) ) ) {
            result[0] += -0.008824086684753532;
          } else {
            result[0] += 0.010032829620226264;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7868431215179150229) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8943082925133570837) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.863112229636659456) ) ) {
          result[0] += 0.04181700747633178;
        } else {
          result[0] += 0.06164332782495741;
        }
      } else {
        result[0] += 0.08166066285225367;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7930879927049911959) ) ) {
        result[0] += 0.10484760088532434;
      } else {
        result[0] += 0.12788292008130678;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8305400774473623571) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7055997140865902795) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5335728757895682461) ) ) {
        result[0] += -0.0619416340891033;
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6574910164466515328) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5250000000000001332) ) ) {
            result[0] += -0.040141193675554986;
          } else {
            result[0] += -0.05272950253290234;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.795000000000000151) ) ) {
            result[0] += -0.027699233067557904;
          } else {
            result[0] += -0.04589667880324992;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7546204900970914231) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7750000000000001332) ) ) {
          result[0] += -0.005549184936811672;
        } else {
          result[0] += -0.02629021086922653;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8450000000000000844) ) ) {
          result[0] += 0.02162494958762306;
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.793392967338620303) ) ) {
            result[0] += -0.011120376613203819;
          } else {
            result[0] += 0.007747907547156604;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7868431215179150229) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.874815099416885511) ) ) {
        result[0] += 0.041324958097066114;
      } else {
        if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7358378217099063034) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
            result[0] += 0.06858494819606721;
          } else {
            result[0] += 0.04512659669111093;
          }
        } else {
          result[0] += 0.08037100032257143;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8347688071710012148) ) ) {
        result[0] += 0.10069880855455787;
      } else {
        result[0] += 0.1189311722317225;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8305400774473623571) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7055997140865902795) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5335728757895682461) ) ) {
        result[0] += -0.06075971613693978;
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6524156763781451263) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5650000000000000577) ) ) {
            result[0] += -0.04024741345861283;
          } else {
            result[0] += -0.05262326034903879;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6950000000000000622) ) ) {
            result[0] += -0.022177440628700418;
          } else {
            result[0] += -0.04208401217632442;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7546204900970914231) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7750000000000001332) ) ) {
          result[0] += -0.005307266160402084;
        } else {
          result[0] += -0.025357722900783412;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8450000000000000844) ) ) {
          result[0] += 0.020481607405779863;
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.793392967338620303) ) ) {
            result[0] += -0.010658568329131576;
          } else {
            result[0] += 0.007373120578798404;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7868431215179150229) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.874815099416885511) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7850000000000001421) ) ) {
          result[0] += 0.06298807435537615;
        } else {
          result[0] += 0.03535722392630918;
        }
      } else {
        if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7358378217099063034) ) ) {
          result[0] += 0.0595112387493537;
        } else {
          result[0] += 0.0749709687161697;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7930879927049911959) ) ) {
        result[0] += 0.09004384004137839;
      } else {
        result[0] += 0.1094342113164022;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8305400774473623571) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7055997140865902795) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.552787391059560318) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2946983627136980366) ) ) {
          result[0] += -0.06155886397621253;
        } else {
          result[0] += -0.05601372572730972;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5650000000000000577) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6003075279628945493) ) ) {
            result[0] += -0.04103512536649006;
          } else {
            result[0] += -0.024047185105946348;
          }
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6574910164466515328) ) ) {
            result[0] += -0.05013612849897551;
          } else {
            result[0] += -0.037004971612535596;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7546204900970914231) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7750000000000001332) ) ) {
          result[0] += -0.0050754896223838735;
        } else {
          result[0] += -0.024455944968558813;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8450000000000000844) ) ) {
          result[0] += 0.019410268697997862;
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.793392967338620303) ) ) {
            result[0] += -0.01021461894935327;
          } else {
            result[0] += 0.007017593651797339;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7868431215179150229) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8943082925133570837) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8524704828946135793) ) ) {
          result[0] += 0.02864635610068356;
        } else {
          result[0] += 0.048166390523364015;
        }
      } else {
        result[0] += 0.0668609246194212;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8347688071710012148) ) ) {
        result[0] += 0.08764554144681551;
      } else {
        result[0] += 0.10359931384779128;
      }
    }
  }
}

