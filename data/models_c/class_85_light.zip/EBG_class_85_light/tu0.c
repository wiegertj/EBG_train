
#include "header.h"

void predict_unit0(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8428035383058734009) ) ) {
    result[0] += -1.0165352015058065;
  } else {
    result[0] += -0.20842039799428225;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7912954791267919896) ) ) {
    result[0] += -0.23788125555893422;
  } else {
    result[0] += 0.3585439152958344;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7426946355231481833) ) ) {
    result[0] += -0.23023746964519387;
  } else {
    result[0] += 0.26224504898005235;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9025064615787555811) ) ) {
    result[0] += -0.1681964833377332;
  } else {
    result[0] += 0.29132054020398834;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.696233030072557102) ) ) {
    result[0] += -0.2106534443934668;
  } else {
    result[0] += 0.18081245826701894;
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7534500286421909054) ) ) {
    result[0] += -0.1331189615727372;
  } else {
    result[0] += 0.24165880580184532;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6731153874060867848) ) ) {
    result[0] += -0.1926876547826168;
  } else {
    result[0] += 0.13560994060862658;
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8172266624966749715) ) ) {
    result[0] += -0.09905518110916588;
  } else {
    result[0] += 0.2332168000727773;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5646111891230115587) ) ) {
    result[0] += -0.19981007110875101;
  } else {
    result[0] += 0.09733329056738652;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.751238504316701472) ) ) {
    result[0] += -0.07989152553203122;
  } else {
    result[0] += 0.20946157418952568;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5343557630381970958) ) ) {
    result[0] += -0.19501200493416757;
  } else {
    result[0] += 0.07487134307763894;
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8473511244746200211) ) ) {
    result[0] += -0.06148317043839034;
  } else {
    result[0] += 0.20023525350468893;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5174986308980092931) ) ) {
    result[0] += -0.1864835789419814;
  } else {
    result[0] += 0.058568772022237724;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8100429806159300528) ) ) {
    result[0] += -0.04671777287071267;
  } else {
    result[0] += 0.1959963011686604;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5005285944911254115) ) ) {
    result[0] += -0.17819060589997143;
  } else {
    result[0] += 0.04587560553452848;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4442092980514921186) ) ) {
    result[0] += -0.18255889767773015;
  } else {
    result[0] += 0.03426598299103523;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8579943578484472422) ) ) {
    result[0] += -0.03416301570324932;
  } else {
    result[0] += 0.19968845626574744;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3987360940130840192) ) ) {
    result[0] += -0.18235352292354423;
  } else {
    result[0] += 0.02622956599263278;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8647854850167006058) ) ) {
    result[0] += -0.026811803916469982;
  } else {
    result[0] += 0.19200799596909535;
  }
}

