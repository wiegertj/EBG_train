
#include "header.h"

void predict_unit0(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8455909065280039494) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7012238381832097689) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5380269784348243878) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4431477231260214644) ) ) {
          result[0] += -0.8214249257994812;
        } else {
          result[0] += -0.8148352334770848;
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007506500000000000151) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002305000000000000462) ) ) {
            result[0] += -0.7992727833285354;
          } else {
            result[0] += -0.8113243987142889;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6278115323581056062) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3362084851504864025) ) ) {
              result[0] += -0.7803914049826918;
            } else {
              result[0] += -0.805353371710922;
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6950000000000000622) ) ) {
              result[0] += -0.7835240810988228;
            } else {
              result[0] += -0.8026935854250459;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.790828820793463394) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8050000000000001599) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7460826136121967433) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.518449662688442281) ) ) {
              result[0] += -0.7782633934415075;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4750000000000000333) ) ) {
                result[0] += -0.7409390844003871;
              } else {
                result[0] += -0.7667056344604555;
              }
            }
          } else {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4613604846474264609) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7269078701507538653) ) ) {
                result[0] += -0.7335629476931345;
              } else {
                result[0] += -0.7836716017617523;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7218051716834171794) ) ) {
                result[0] += -0.7686242273925158;
              } else {
                result[0] += -0.7070196107462877;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3687216492462311868) ) ) {
            result[0] += -0.7483720362341356;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7309551922231288801) ) ) {
              result[0] += -0.792903413618996;
            } else {
              result[0] += -0.7791311825120492;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5373685132790656516) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8065490128546884963) ) ) {
            result[0] += -0.7421972276834222;
          } else {
            result[0] += -0.7185912384406685;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8115031879405597559) ) ) {
            result[0] += -0.7645661646318527;
          } else {
            result[0] += -0.7444329340424164;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7369297863416220951) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8956174930041188587) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0006865000000000001526) ) ) {
          result[0] += -0.7596245985372445;
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02120850000000000166) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8678581689358929596) ) ) {
              result[0] += -0.7127798585900922;
            } else {
              result[0] += -0.6977077782825191;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8352912313316583903) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9350000000000001643) ) ) {
                result[0] += -0.7158908974749785;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8583556158382011914) ) ) {
                  result[0] += -0.7795950404550055;
                } else {
                  result[0] += -0.7307326277170353;
                }
              }
            } else {
              result[0] += -0.6816697845516637;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9443572767030988802) ) ) {
          result[0] += -0.6792475978076836;
        } else {
          result[0] += -0.6588589076589039;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8420098784315052098) ) ) {
        result[0] += -0.6459031614851327;
      } else {
        result[0] += -0.6285469265029306;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8455909065280039494) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7012238381832097689) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5091389307398357378) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2669666665921996418) ) ) {
          result[0] += -0.06126774249117075;
        } else {
          result[0] += -0.05711668965200747;
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0153395000000000007) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.565436264745754591) ) ) {
            result[0] += -0.05312583774477233;
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3430002875097172832) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4227592663290559716) ) ) {
                result[0] += -0.03460865058473172;
              } else {
                result[0] += 0.017546041983218113;
              }
            } else {
              result[0] += -0.04711051222936798;
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1295212041281339765) ) ) {
            if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.07196201389915944657) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4814085394974874643) ) ) {
                result[0] += -0.023571531301956182;
              } else {
                result[0] += -0.04554394294500617;
              }
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.04658055172941339556) ) ) {
                result[0] += 0.04054101714781218;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.545000000000000151) ) ) {
                  result[0] += -0.03174820742182214;
                } else {
                  result[0] += 0;
                }
              }
            }
          } else {
            result[0] += -0.0419503732605603;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7863566523687727239) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8150000000000000577) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7460826136121967433) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4190692806030151263) ) ) {
              result[0] += -0.030239172068863094;
            } else {
              result[0] += -0.004487144492167067;
            }
          } else {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4613604846474264609) ) ) {
              result[0] += 0.02089691715619357;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7071981171356784834) ) ) {
                result[0] += -0.010704940978805205;
              } else {
                result[0] += 0.04080698391196521;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3687216492462311868) ) ) {
            result[0] += 0.010411407657058508;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7214013188511664287) ) ) {
              result[0] += -0.03563358224905007;
            } else {
              result[0] += -0.020379602982722175;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8650000000000001021) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01340550000000000248) ) ) {
            result[0] += 0.009601664162264168;
          } else {
            result[0] += 0.03902235128441727;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8115031879405597559) ) ) {
            result[0] += -0.0039944808835340444;
          } else {
            result[0] += 0.014433741665260234;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7369297863416220951) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8956174930041188587) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0006865000000000001526) ) ) {
          result[0] += 0.0003238194903061358;
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6832193430923222399) ) ) {
            result[0] += 0.04590148981714552;
          } else {
            result[0] += 0.07504213219156546;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9443572767030988802) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9050000000000001377) ) ) {
            result[0] += 0.07590595996756132;
          } else {
            result[0] += 0.01705953126755426;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9250000000000001554) ) ) {
            result[0] += 0.09764198000274667;
          } else {
            result[0] += 0.06708811083564756;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8420098784315052098) ) ) {
        result[0] += 0.10497007602118522;
      } else {
        result[0] += 0.12027625682669159;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8391219607133014735) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7012238381832097689) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5380269784348243878) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4431477231260214644) ) ) {
          result[0] += -0.05911271147045407;
        } else {
          result[0] += -0.05246013413102286;
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007506500000000000151) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002305000000000000462) ) ) {
            result[0] += -0.037006276570478;
          } else {
            result[0] += -0.049026182578261995;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5868306463106892634) ) ) {
            result[0] += -0.04453249489091561;
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6950000000000000622) ) ) {
              result[0] += -0.026285764879171378;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.341491527034325726) ) ) {
                result[0] += -0.044863895897385535;
              } else {
                result[0] += 0.012755707444678086;
              }
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7863566523687727239) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8150000000000000577) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7460826136121967433) ) ) {
            result[0] += -0.00775767690118969;
          } else {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4613604846474264609) ) ) {
              result[0] += 0.019865147365789843;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7071981171356784834) ) ) {
                result[0] += -0.010296727724262144;
              } else {
                result[0] += 0.03875411467337159;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3687216492462311868) ) ) {
            result[0] += 0.009947189991275505;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7309551922231288801) ) ) {
              result[0] += -0.031572191346657015;
            } else {
              result[0] += -0.018798356979177814;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8650000000000001021) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002064500000000000363) ) ) {
            result[0] += -0.008968557058416926;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8065490128546884963) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02661500000000000324) ) ) {
                result[0] += 0;
              } else {
                result[0] += 0.03251068663830463;
              }
            } else {
              result[0] += 0.04186254437072926;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8115031879405597559) ) ) {
            result[0] += -0.0038301277450970826;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5284121414321608645) ) ) {
              result[0] += 0.023307844714992584;
            } else {
              result[0] += 0.004271283426975881;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7369297863416220951) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8956174930041188587) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8635248854378615446) ) ) {
          result[0] += 0.033021903206533094;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0006865000000000001526) ) ) {
            result[0] += -0.00016318322880249348;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.733886402487437306) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0153395000000000007) ) ) {
                result[0] += 0.05184964526431222;
              } else {
                result[0] += 0.03419376322294987;
              }
            } else {
              result[0] += 0.06987888799997813;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9443572767030988802) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9050000000000001377) ) ) {
            result[0] += 0.07093766702085759;
          } else {
            result[0] += 0.016313157144247695;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9250000000000001554) ) ) {
            result[0] += 0.09076281471289155;
          } else {
            result[0] += 0.06296822399796893;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8487060949625354622) ) ) {
        result[0] += 0.09783943982539813;
      } else {
        result[0] += 0.11143921751865352;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.827186441538020012) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6964842473688145352) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5091389307398357378) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2669666665921996418) ) ) {
          result[0] += -0.05911758449293568;
        } else {
          result[0] += -0.05486325334516177;
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0153395000000000007) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.565436264745754591) ) ) {
            result[0] += -0.05092353844351591;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6450000000000001288) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6181495723579168988) ) ) {
                result[0] += -0.04065156011799717;
              } else {
                result[0] += -0.025022130991618055;
              }
            } else {
              result[0] += -0.04696295331635182;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2089650038525997233) ) ) {
            result[0] += -0.026443586644480353;
          } else {
            result[0] += -0.041003666972093365;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7728505831511113255) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8050000000000001599) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7309551922231288801) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4040747598994975376) ) ) {
              result[0] += -0.04113214287769281;
            } else {
              result[0] += -0.00802933095306821;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.514594807601719606) ) ) {
              result[0] += 0.01438938323246238;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7285912812060302279) ) ) {
                result[0] += -0.014520824073342917;
              } else {
                result[0] += 0.04330420586951401;
              }
            }
          }
        } else {
          result[0] += -0.02336065926586651;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6650000000000001465) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8450000000000000844) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3629614419597990138) ) ) {
              result[0] += -0.009532335587637676;
            } else {
              result[0] += 0.03300666008634542;
            }
          } else {
            result[0] += 0.009499889487940031;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8016764265861101579) ) ) {
            result[0] += -0.011034554236347324;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004124500000000000562) ) ) {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6425586238723383081) ) ) {
                result[0] += 0.021288194170777656;
              } else {
                result[0] += -0.005064699082249766;
              }
            } else {
              result[0] += -0.0048165815092973754;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7369297863416220951) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8956174930041188587) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8583556158382011914) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6157932186745959102) ) ) {
            result[0] += 0.03936871901534635;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8391219607133014735) ) ) {
              result[0] += 0.005005976956161029;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0176405000000000034) ) ) {
                result[0] += 0.03366284980071144;
              } else {
                result[0] += 0.0037476938902736446;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0006865000000000001526) ) ) {
            result[0] += -0.005716452638977535;
          } else {
            result[0] += 0.04551864432653749;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9443572767030988802) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9050000000000001377) ) ) {
            result[0] += 0.0665603886053877;
          } else {
            result[0] += 0.015604353277698147;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9150000000000001465) ) ) {
            result[0] += 0.08534288607380358;
          } else {
            result[0] += 0.06167772473892974;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8420098784315052098) ) ) {
        result[0] += 0.09101955223786175;
      } else {
        result[0] += 0.10386519864306797;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8162318130682130191) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6964842473688145352) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5091389307398357378) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2669666665921996418) ) ) {
          result[0] += -0.05815097906564703;
        } else {
          result[0] += -0.05384861981973455;
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0153395000000000007) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.565436264745754591) ) ) {
            result[0] += -0.04986899925619385;
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3430002875097172832) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4227592663290559716) ) ) {
                result[0] += -0.031344732222680805;
              } else {
                result[0] += 0.01950516915774482;
              }
            } else {
              result[0] += -0.04418418048408849;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2089650038525997233) ) ) {
            result[0] += -0.02559807108470628;
          } else {
            result[0] += -0.03995600867865617;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7728505831511113255) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8050000000000001599) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7058987689933927667) ) ) {
            result[0] += -0.022967649744470565;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5072261056783921029) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7408351266736160623) ) ) {
                result[0] += -0.019590210257675506;
              } else {
                if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1296381427427941713) ) ) {
                  result[0] += 0.018227002225720903;
                } else {
                  result[0] += -0.03475167831248699;
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4750000000000000333) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1568195108116869629) ) ) {
                  result[0] += 0.0383884212567509;
                } else {
                  result[0] += -0.010373432049408271;
                }
              } else {
                result[0] += 0.0013366295264897446;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7214013188511664287) ) ) {
            result[0] += -0.03233530979186997;
          } else {
            result[0] += -0.01916058160058761;
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5373685132790656516) ) ) {
          result[0] += 0.017304281801060386;
        } else {
          result[0] += -0.006509056814276604;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9164371750852472465) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8842728335152491015) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8455909065280039494) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6850000000000001643) ) ) {
            result[0] += 0.03808857293617775;
          } else {
            result[0] += 0.01266028050653883;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0006865000000000001526) ) ) {
            result[0] += 6.095513198569678e-05;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02164350000000000648) ) ) {
              result[0] += 0.04267918744722686;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.7150000000000000799) ) ) {
                result[0] += 0.03519824676403813;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06152000000000000524) ) ) {
                  result[0] += -0.004856827813041149;
                } else {
                  result[0] += 0.041808014514687276;
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7313236567832696045) ) ) {
          result[0] += 0.056080309875344;
        } else {
          result[0] += 0.0835852533861128;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7948589598137713041) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6779399817775906278) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
            result[0] += 0.07199974120099098;
          } else {
            result[0] += 0.03995691955612167;
          }
        } else {
          result[0] += 0.07943167238827442;
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8606418736522790658) ) ) {
          result[0] += 0.08919128967417896;
        } else {
          result[0] += 0.09803244322755957;
        }
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8162318130682130191) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6964842473688145352) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5091389307398357378) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2669666665921996418) ) ) {
          result[0] += -0.05725309300836634;
        } else {
          result[0] += -0.05289078543067897;
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007070500000000001263) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += -0.03598302778198793;
          } else {
            result[0] += -0.047329871060381244;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5813400334181016982) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
              result[0] += -0.030070889743172135;
            } else {
              result[0] += -0.04931365687457765;
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7050000000000000711) ) ) {
              result[0] += -0.024113133005551034;
            } else {
              result[0] += -0.0415887897120259;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7728505831511113255) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8050000000000001599) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7058987689933927667) ) ) {
            result[0] += -0.02220535232990421;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5072261056783921029) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7408351266736160623) ) ) {
                result[0] += -0.0189077994145111;
              } else {
                if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1411176844756204807) ) ) {
                  result[0] += 0.01833761170792377;
                } else {
                  result[0] += -0.03101357828925671;
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4327651086396848146) ) ) {
                result[0] += 0.04791135415663243;
              } else {
                result[0] += 0.004102476540800285;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7309551922231288801) ) ) {
            result[0] += -0.029162030720267615;
          } else {
            result[0] += -0.01747930272246203;
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5431307184257260223) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5350000000000001421) ) ) {
            result[0] += 0.036943768609048834;
          } else {
            result[0] += 0.011715839781537798;
          }
        } else {
          result[0] += -0.00664262067479605;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6966902637519932773) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8956174930041188587) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8583556158382011914) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6850000000000001643) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4075435166080402793) ) ) {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.038794232605861678) ) ) {
                result[0] += 0.04600205018698273;
              } else {
                result[0] += -0.013691423544233394;
              }
            } else {
              result[0] += 0.040603557290483545;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0176405000000000034) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8455909065280039494) ) ) {
                result[0] += 0.013575151898063662;
              } else {
                result[0] += 0.03403950813078239;
              }
            } else {
              result[0] += -0.0015980504020760517;
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0006865000000000001526) ) ) {
            result[0] += -0.007442914451234427;
          } else {
            result[0] += 0.03989799918804329;
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9268618155849429607) ) ) {
            result[0] += 0.056286099743216474;
          } else {
            result[0] += 0.07271553085883746;
          }
        } else {
          result[0] += 0.04998098231407239;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8244912349994802936) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7369297863416220951) ) ) {
          result[0] += 0.06772450312599454;
        } else {
          result[0] += 0.079964490838458;
        }
      } else {
        result[0] += 0.0918565212346396;
      }
    }
  }
}

