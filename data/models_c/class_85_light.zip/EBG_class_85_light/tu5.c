
#include "header.h"

void predict_unit5(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6194192625572763067) ) ) {
    result[0] += -0.022352780499158474;
  } else {
    result[0] += 0.004789965613961844;
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
    result[0] += 0.0321103590459855;
  } else {
    result[0] += -0.0033092860502989562;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4442092980514921186) ) ) {
    result[0] += -0.04220055300367724;
  } else {
    result[0] += 0.002342237363046689;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9819102573789878496) ) ) {
    result[0] += -0.0005159231094741497;
  } else {
    result[0] += 0.19383459956397497;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.545000000000000151) ) ) {
    result[0] += 0.021749369064316175;
  } else {
    result[0] += -0.004251006013571623;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6246353589667689166) ) ) {
    result[0] += -0.021195098720583814;
  } else {
    result[0] += 0.004680206644277241;
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4101030825879397046) ) ) {
    result[0] += -0.02669825370419435;
  } else {
    result[0] += 0.0034027255468666953;
  }
  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.13900392495124092) ) ) {
    result[0] += 0.07369140840220716;
  } else {
    result[0] += -0.0014331444624641836;
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8374809319095478655) ) ) {
    result[0] += 0.0012188361215083872;
  } else {
    result[0] += -0.07227019763059692;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7550000000000001155) ) ) {
    result[0] += 0.01408321844776416;
  } else {
    result[0] += -0.00611181078697225;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6427554134465586211) ) ) {
    result[0] += -0.006657905820103992;
  } else {
    result[0] += 0.014842692218858184;
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.04546417654371086997) ) ) {
    result[0] += -0.1768178475517839;
  } else {
    result[0] += 0.00047700960139885663;
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9750000000000000888) ) ) {
    result[0] += 0.0018240793211443767;
  } else {
    result[0] += -0.04508963497036623;
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8354641288167671265) ) ) {
    result[0] += -0.0031594063359598576;
  } else {
    result[0] += 0.0287037533629917;
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.850000000000000659e-05) ) ) {
    result[0] += 0.03270529768554265;
  } else {
    result[0] += -0.002582200923118636;
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002186500000000000509) ) ) {
    result[0] += -0.017175808869008585;
  } else {
    result[0] += 0.005465123494689768;
  }
  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5724391781153673753) ) ) {
    result[0] += -0.03071009660005515;
  } else {
    result[0] += 0.0026317050703261965;
  }
  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.328486960647610404) ) ) {
    result[0] += 0.1462039202612147;
  } else {
    result[0] += -0.0005720381571983375;
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1450000000000000455) ) ) {
    result[0] += -0.05834745233414747;
  } else {
    result[0] += 0.0013283389368909401;
  }
}

