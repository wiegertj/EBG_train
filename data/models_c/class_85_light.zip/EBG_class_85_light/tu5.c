
#include "header.h"

void predict_unit5(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7656222061929859324) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.552787391059560318) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2946983627136980366) ) ) {
        result[0] += -0.04967078449375962;
      } else {
        result[0] += -0.04002941469224891;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7055997140865902795) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7150000000000000799) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6003075279628945493) ) ) {
            if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.2878562317506634938) ) ) {
              result[0] += -0.010974872675174876;
            } else {
              result[0] += -0.0315522274988436;
            }
          } else {
            result[0] += -0.012063043041859152;
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6524156763781451263) ) ) {
            result[0] += -0.038648961504914536;
          } else {
            result[0] += -0.022637148100583322;
          }
        }
      } else {
        result[0] += -0.0068492808149422085;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8299157965154307925) ) ) {
      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.686605359504699142) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8550000000000000933) ) ) {
          if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5862093503336099909) ) ) {
            result[0] += 0.004517688776672918;
          } else {
            result[0] += 0.024751327089072545;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6754021834779359024) ) ) {
            result[0] += 0.005469345690151736;
          } else {
            result[0] += -0.012244103513114042;
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9120665648705957862) ) ) {
          result[0] += 0.019436623325160902;
        } else {
          result[0] += 0.030462596942497498;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8999934911843509022) ) ) {
        result[0] += 0.04605194815796849;
      } else {
        result[0] += 0.05741441081495588;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7656222061929859324) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5335728757895682461) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2946983627136980366) ) ) {
        result[0] += -0.049362688854748156;
      } else {
        result[0] += -0.040376497074329755;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6574910164466515328) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5650000000000000577) ) ) {
          result[0] += -0.01875015343128426;
        } else {
          result[0] += -0.0332811591533339;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.795000000000000151) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7366403613896054248) ) ) {
            result[0] += -0.0079395248462861;
          } else {
            result[0] += 0.008249085318965314;
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7159007698053595492) ) ) {
            result[0] += -0.024482234217331814;
          } else {
            result[0] += -0.009608969887399286;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8299157965154307925) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.863112229636659456) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8361854181907825145) ) ) {
          result[0] += 0.0022599641998954168;
        } else {
          result[0] += 0.013085832073907242;
        }
      } else {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6845616084030620163) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9750000000000000888) ) ) {
            if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6509677360553945968) ) ) {
              result[0] += 0.007486610896194961;
            } else {
              result[0] += 0.02804416150522276;
            }
          } else {
            result[0] += 0.007833382793525965;
          }
        } else {
          result[0] += 0.030128069557398707;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8945815063191204786) ) ) {
        result[0] += 0.04473346891295029;
      } else {
        result[0] += 0.05647744320435148;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7656222061929859324) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5335728757895682461) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2946983627136980366) ) ) {
        result[0] += -0.04906594576731276;
      } else {
        result[0] += -0.03979462000987586;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6755187506907774919) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5250000000000001332) ) ) {
          result[0] += -0.016214905412730813;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002861500000000000328) ) ) {
            result[0] += -0.036051678355347;
          } else {
            result[0] += -0.023131714780867865;
          }
        }
      } else {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.458624726291084861) ) ) {
          result[0] += -0.0011782827528221537;
        } else {
          result[0] += -0.013061033100886466;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7539078735793690589) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.863112229636659456) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8361854181907825145) ) ) {
          result[0] += 0.002155151094038742;
        } else {
          result[0] += 0.012473971927850188;
        }
      } else {
        if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6845616084030620163) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9750000000000000888) ) ) {
            if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6509677360553945968) ) ) {
              result[0] += 0.007150183028509791;
            } else {
              result[0] += 0.02687849570866937;
            }
          } else {
            result[0] += 0.0072148143814703865;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.043131035951033604;
          } else {
            result[0] += 0.026189713631695626;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8604095077903387567) ) ) {
        result[0] += 0.04141663556958451;
      } else {
        result[0] += 0.054733331869028685;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7546204900970914231) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5335728757895682461) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2946983627136980366) ) ) {
        result[0] += -0.048779606538416995;
      } else {
        result[0] += -0.039215153178930214;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6524156763781451263) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5650000000000000577) ) ) {
          result[0] += -0.01784312923654778;
        } else {
          result[0] += -0.03250224096177166;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.795000000000000151) ) ) {
          result[0] += -0.005304460673655165;
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7159007698053595492) ) ) {
            result[0] += -0.023944928107750604;
          } else {
            result[0] += -0.008711049898885305;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8299157965154307925) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.686605359504699142) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8550000000000000933) ) ) {
          if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6078908714795508983) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1222815000000000152) ) ) {
              result[0] += 0.010866124823754063;
            } else {
              result[0] += -0.01339661177055457;
            }
          } else {
            result[0] += 0.0253845945644395;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.762515391896329886) ) ) {
            result[0] += 0.003585924982388039;
          } else {
            result[0] += -0.013091245506637901;
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8943082925133570837) ) ) {
          result[0] += 0.014510319612290873;
        } else {
          result[0] += 0.026167999631236886;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8945815063191204786) ) ) {
        result[0] += 0.042689481146959966;
      } else {
        result[0] += 0.05508067592763786;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7546204900970914231) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5335728757895682461) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2946983627136980366) ) ) {
        result[0] += -0.048502766124278215;
      } else {
        result[0] += -0.038637419395128825;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6524156763781451263) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5650000000000000577) ) ) {
          result[0] += -0.01723950809366728;
        } else {
          result[0] += -0.03179613216569625;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.795000000000000151) ) ) {
          result[0] += -0.005076391657701999;
        } else {
          result[0] += -0.01553070074726265;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7539078735793690589) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8474756727480589058) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6650000000000001465) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1222815000000000152) ) ) {
            result[0] += 0.01145567699291949;
          } else {
            result[0] += -0.014125488685255275;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7250000000000000888) ) ) {
            result[0] += -0.006852276263642792;
          } else {
            result[0] += 0.005780938944129788;
          }
        }
      } else {
        if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.751334311843480207) ) ) {
          result[0] += 0.015311698121613428;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
            result[0] += 0.035913234703220796;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001688500000000000114) ) ) {
              result[0] += 0.042738997205264924;
            } else {
              result[0] += 0.018977192213233955;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8411680991848416999) ) ) {
        result[0] += 0.038029646656061594;
      } else {
        result[0] += 0.05281574372354096;
      }
    }
  }
}

