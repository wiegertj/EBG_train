
#include "header.h"

void predict_unit15(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9350000000000001643) ) ) {
    result[0] += 0.001585909131746208;
  } else {
    result[0] += -0.018017338802793628;
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8239875807937219188) ) ) {
    result[0] += -0.002073612567712308;
  } else {
    result[0] += 0.016942520659008992;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
    result[0] += 0.003910565908376096;
  } else {
    result[0] += -0.007205560542455067;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6501267983073132362) ) ) {
    result[0] += -0.010846266348342454;
  } else {
    result[0] += 0.00276078648139197;
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5912899923618091247) ) ) {
    result[0] += -0.004173277261991916;
  } else {
    result[0] += 0.006866566951897122;
  }
  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3640888533806194149) ) ) {
    result[0] += 0.012377723327027077;
  } else {
    result[0] += -0.0024859615790915083;
  }
  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06118935233924421152) ) ) {
    result[0] += 0.0021679513528552875;
  } else {
    result[0] += -0.013101921801597872;
  }
  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.08835747683243963535) ) ) {
    result[0] += -0.007434480523293609;
  } else {
    result[0] += 0.0037398215749712984;
  }
  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09277402050424696234) ) ) {
    result[0] += 0.005137813942117639;
  } else {
    result[0] += -0.006012231365004516;
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002186500000000000509) ) ) {
    result[0] += -0.00935847192558677;
  } else {
    result[0] += 0.002911115193811802;
  }
  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06996650000000001479) ) ) {
    result[0] += 0.0020865049110459256;
  } else {
    result[0] += -0.01358288698171963;
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9893875171118072798) ) ) {
    result[0] += -0.00028085510418488814;
  } else {
    result[0] += 0.11174829404962833;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8450000000000000844) ) ) {
    result[0] += 0.0065754667659904936;
  } else {
    result[0] += -0.004347691859658532;
  }
}

