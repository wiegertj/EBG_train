
#include "header.h"

void predict_unit13(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4431477231260214644) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2277279215734702711) ) ) {
      if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3750409390474713223) ) ) {
        if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4627502129294571165) ) ) {
          result[0] += -0.032411827986323555;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1470012909078650398) ) ) {
            result[0] += -0.006165960615042922;
          } else {
            result[0] += 0.10785599850888139;
          }
        }
      } else {
        result[0] += -0.04086486638849837;
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02500000000000000486) ) ) {
        result[0] += 0.009095869207977473;
      } else {
        result[0] += -0.019860596312535186;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8723822823959714867) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9031544962109391284) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6181495723579168988) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5950000000000000844) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
              result[0] += 0.023607759354355173;
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.07196201389915944657) ) ) {
                if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2085874655574800063) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4050000000000000822) ) ) {
                    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2334545932180011052) ) ) {
                      result[0] += 0.005029372501619798;
                    } else {
                      result[0] += -0.021108467290478473;
                    }
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002158500000000000262) ) ) {
                      result[0] += -0.017194742532283293;
                    } else {
                      result[0] += 0.02452984421592295;
                    }
                  }
                } else {
                  result[0] += -0.02223686719237405;
                }
              } else {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.0491948752242571466) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005037500000000001178) ) ) {
                    result[0] += 0.00012919119663598158;
                  } else {
                    result[0] += 0.06980685900317374;
                  }
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1050000000000000239) ) ) {
                    result[0] += 0.07664317041873268;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.596756249395726468) ) ) {
                      result[0] += -0.007257192142383384;
                    } else {
                      result[0] += 0.011322521358684851;
                    }
                  }
                }
              }
            }
          } else {
            result[0] += -0.018921093184979514;
          }
        } else {
          result[0] += -0.000119705729130023;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9999977834869465676) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001940500000000000167) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              result[0] += -0.0007320146716716161;
            } else {
              result[0] += 0.025612026190111475;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4093335132160804135) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2669585275879397535) ) ) {
                result[0] += 0.01580569458697114;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3177282290201005055) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.7850000000000001421) ) ) {
                    result[0] += -0.07429731797675715;
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8850000000000001199) ) ) {
                      result[0] += 0.015335135591254935;
                    } else {
                      result[0] += -0.034163118721940985;
                    }
                  }
                } else {
                  result[0] += -0.0010083746867280588;
                }
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9815549730476619272) ) ) {
                result[0] += 0.004918351152118464;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
                  result[0] += 0.025509851398137256;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01365850000000000224) ) ) {
                    result[0] += -0.03507600731801542;
                  } else {
                    result[0] += 0.0071338080603032695;
                  }
                }
              }
            }
          }
        } else {
          result[0] += 0.03569244268458329;
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9595979360797254332) ) ) {
        result[0] += 0.025131256278474845;
      } else {
        result[0] += 0.03792249410183563;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4299568404094374907) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2277279215734702711) ) ) {
      result[0] += -0.0395122922684068;
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2655998599748743971) ) ) {
        result[0] += 0.05543438387774449;
      } else {
        result[0] += -0.01915196638837412;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8723822823959714867) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.755533006633860027) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2446095000000000352) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7448583832663316917) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7418777389447237525) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9998087951126271022) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6461954822149375) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6555524765326633529) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6208328749497488142) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5917931336432161737) ) ) {
                        result[0] += -0.004570951140665489;
                      } else {
                        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6750000000000001554) ) ) {
                          result[0] += -0.0025003243375544756;
                        } else {
                          result[0] += 0.02927339317621011;
                        }
                      }
                    } else {
                      result[0] += -0.017318334473750772;
                    }
                  } else {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2569819050134251603) ) ) {
                      result[0] += 0.07963871029597627;
                    } else {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5681735652491761712) ) ) {
                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5043717672569237864) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6800105846231156992) ) ) {
                            result[0] += 0.02894705605423642;
                          } else {
                            result[0] += -0.011876256117776861;
                          }
                        } else {
                          result[0] += -0.025263686693433676;
                        }
                      } else {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01565150000000000222) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7071981171356784834) ) ) {
                            result[0] += -0.02506092425047128;
                          } else {
                            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4081667483809247599) ) ) {
                              result[0] += 0.1399232937138514;
                            } else {
                              result[0] += 0;
                            }
                          }
                        } else {
                          result[0] += 0.09957252454245202;
                        }
                      }
                    }
                  }
                } else {
                  result[0] += -0.015463386586506011;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7201893438693468541) ) ) {
                  result[0] += -0.004745006689998687;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001584500000000000188) ) ) {
                    result[0] += -0.00054865632987054;
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.545000000000000151) ) ) {
                      result[0] += 0.023576523506579565;
                    } else {
                      result[0] += 0.12354178586499145;
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002472500000000000305) ) ) {
                result[0] += 0;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8518170160515455835) ) ) {
                  result[0] += 0.1393443487629928;
                } else {
                  result[0] += -0.025212356008461254;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              result[0] += -0.01583993350090179;
            } else {
              result[0] += 0.009855920917811949;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8352912313316583903) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6300691579881073645) ) ) {
              result[0] += 0.02890292733123563;
            } else {
              result[0] += -0.028860898411775603;
            }
          } else {
            result[0] += 0.057430134403955065;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9443572767030988802) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7509562601305637131) ) ) {
            result[0] += 0.0011004408479934218;
          } else {
            result[0] += 0.01578834451623517;
          }
        } else {
          result[0] += 0.008130125987414813;
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9595979360797254332) ) ) {
        result[0] += 0.02463576901382282;
      } else {
        result[0] += 0.03764788543131323;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4431477231260214644) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2277279215734702711) ) ) {
      if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3750409390474713223) ) ) {
        if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4627502129294571165) ) ) {
          result[0] += -0.031720460946221087;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1470012909078650398) ) ) {
            result[0] += -0.005410487175668091;
          } else {
            result[0] += 0.10258216075968915;
          }
        }
      } else {
        result[0] += -0.040622619242440094;
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02500000000000000486) ) ) {
        result[0] += 0.009535292275710587;
      } else {
        result[0] += -0.018950722244131694;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8723822823959714867) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.649924828200234006) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6181495723579168988) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7150000000000000799) ) ) {
            result[0] += -0.005059358592868629;
          } else {
            result[0] += -0.027691734575846273;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7617737907239344741) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9443572767030988802) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002305000000000000462) ) ) {
                result[0] += 0.009499363491277507;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007070500000000001263) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006829000000000000868) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6723044781720388663) ) ) {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3892782419974109565) ) ) {
                        result[0] += -0.019293044066956866;
                      } else {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6300691579881073645) ) ) {
                          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6156410786045318773) ) ) {
                            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5508018452917812224) ) ) {
                              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7350000000000000977) ) ) {
                                result[0] += -0.023150934194454437;
                              } else {
                                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5350000000000001421) ) ) {
                                  result[0] += 0;
                                } else {
                                  result[0] += 0.09035462375597;
                                }
                              }
                            } else {
                              result[0] += -0.03383706433263104;
                            }
                          } else {
                            result[0] += 0.10720253275612363;
                          }
                        } else {
                          result[0] += -0.011412342459909136;
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3902192490452261464) ) ) {
                        result[0] += 0.010338951612608989;
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4040747598994975376) ) ) {
                          result[0] += -0.02866842328743698;
                        } else {
                          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5850000000000000755) ) ) {
                            result[0] += 0.01780435198457128;
                          } else {
                            result[0] += -0.0031940113202728136;
                          }
                        }
                      }
                    }
                  } else {
                    result[0] += -0.029471370212219246;
                  }
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.008262500000000000747) ) ) {
                    result[0] += 0.01373548874442776;
                  } else {
                    result[0] += 0.0004044230550198715;
                  }
                }
              }
            } else {
              result[0] += 0.014757099139130299;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03221500000000000752) ) ) {
              result[0] += -0.050065800513862925;
            } else {
              result[0] += 0.005563755955984725;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
          result[0] += 0.01427487580645877;
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7948589598137713041) ) ) {
            result[0] += 0.0024397884762836428;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
              result[0] += 0.014883590419775146;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01000850000000000177) ) ) {
                result[0] += -0.03901874268577012;
              } else {
                result[0] += 0.0044548398517903435;
              }
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9595979360797254332) ) ) {
        result[0] += 0.024139970301828864;
      } else {
        result[0] += 0.037368658100575415;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3789369143834280806) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1963252620506650836) ) ) {
      result[0] += -0.04027980713342194;
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2669585275879397535) ) ) {
        result[0] += 0.06207924861383041;
      } else {
        result[0] += -0.021369880700110092;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8606418736522790658) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7309551922231288801) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2068436309895129999) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1350000000000000366) ) ) {
            result[0] += -0.02178307520757079;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09500000000000001499) ) ) {
              result[0] += 0.09007443791112756;
            } else {
              result[0] += 0.019624883253304744;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4649337835814208453) ) ) {
            result[0] += -0.020238952505327666;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2446095000000000352) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7810201528643216928) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6408349166133754382) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7071981171356784834) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007070500000000001263) ) ) {
                        result[0] += -0.007284511161903547;
                      } else {
                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6043838026813522779) ) ) {
                          result[0] += -0.0013508496547217253;
                        } else {
                          result[0] += 0.05095686773473168;
                        }
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002816500000000000427) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7114754460552764614) ) ) {
                          result[0] += 0.06125002501268485;
                        } else {
                          result[0] += -0.009916232931069016;
                        }
                      } else {
                        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7550000000000001155) ) ) {
                          result[0] += 0.12930165958159293;
                        } else {
                          result[0] += 0.00711124487365072;
                        }
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8751680158987383829) ) ) {
                      result[0] += -0.020507327592239177;
                    } else {
                      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5550000000000001599) ) ) {
                        result[0] += 0.04171497045046322;
                      } else {
                        result[0] += -0.020037267043081227;
                      }
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001584500000000000188) ) ) {
                    result[0] += -0.013426954694028652;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7579047064321609017) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7429456371859297636) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7201893438693468541) ) ) {
                          result[0] += 0;
                        } else {
                          result[0] += 0.0725210727574553;
                        }
                      } else {
                        result[0] += -0.021664857742475303;
                      }
                    } else {
                      result[0] += 0.09162624184866443;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.480405183437169869) ) ) {
                  result[0] += -0.02292375869222908;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1270445000000000324) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8254037945979900703) ) ) {
                      result[0] += 0.05496431193665569;
                    } else {
                      result[0] += -0.014846284548781483;
                    }
                  } else {
                    result[0] += 0.07000772795090153;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.337654390274954419) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3520526286285806106) ) ) {
                  result[0] += 0.02246882189819472;
                } else {
                  result[0] += -0.03910686796411875;
                }
              } else {
                result[0] += 0.05079733812261386;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9228588940825653841) ) ) {
          result[0] += 0.0008933418102079946;
        } else {
          result[0] += 0.006404717343012776;
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9595979360797254332) ) ) {
        result[0] += 0.022559554578862225;
      } else {
        result[0] += 0.03708461685571498;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3881589449934809699) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1963252620506650836) ) ) {
      result[0] += -0.0401412475115907;
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4832433377889447379) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02500000000000000486) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.08316259990446585315) ) ) {
            result[0] += -0.001270328313271306;
          } else {
            if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3539353041941689093) ) ) {
              result[0] += 0;
            } else {
              result[0] += 0.13008854024315156;
            }
          }
        } else {
          result[0] += -0.012084936759914375;
        }
      } else {
        result[0] += -0.023117849725581438;
      }
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8723822823959714867) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7309551922231288801) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1825188526243103071) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1850000000000000255) ) ) {
            result[0] += -0.004295492645689702;
          } else {
            result[0] += 0.0653173309912641;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5091389307398357378) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3650000000000000466) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5490157830150754759) ) ) {
                result[0] += -0.014032488818506822;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1050000000000000239) ) ) {
                  result[0] += 0.06983654739097234;
                } else {
                  result[0] += 0.0007884323555439486;
                }
              }
            } else {
              result[0] += -0.025845934725701385;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.25500000000000006) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3950000000000000733) ) ) {
                result[0] += -0.0010054023303571501;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3830383354773237436) ) ) {
                  if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.0194836725655387448) ) ) {
                    result[0] += 0.017831625963246795;
                  } else {
                    result[0] += 0.07759618397604232;
                  }
                } else {
                  result[0] += -0.0037149093737871373;
                }
              }
            } else {
              result[0] += -0.0039236652428496855;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9443572767030988802) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7509562601305637131) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4850000000000000422) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5072261056783921029) ) ) {
                result[0] += 0.0018848775447423843;
              } else {
                result[0] += 0.02667237265644803;
              }
            } else {
              result[0] += 0.0003915848248577687;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5724656755276382736) ) ) {
              result[0] += 0.000252823607224147;
            } else {
              result[0] += 0.02736965613536472;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9999977834869465676) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4093335132160804135) ) ) {
              result[0] += -0.0006571794674157625;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9338838061878478314) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4357222557788944517) ) ) {
                  result[0] += 0.03152821157777544;
                } else {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4026472078210281969) ) ) {
                    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7816726053684978082) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4378622240954774258) ) ) {
                        result[0] += 0.006897762129244357;
                      } else {
                        result[0] += -0.0974521000292924;
                      }
                    } else {
                      result[0] += 0.015372218793109434;
                    }
                  } else {
                    result[0] += 0.00898434508149612;
                  }
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5450375474120604524) ) ) {
                  result[0] += 0;
                } else {
                  result[0] += -0.0835200244070939;
                }
              }
            }
          } else {
            result[0] += 0.03492362521995533;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9595979360797254332) ) ) {
        result[0] += 0.02317169000425513;
      } else {
        result[0] += 0.036795573648673294;
      }
    }
  }
}

