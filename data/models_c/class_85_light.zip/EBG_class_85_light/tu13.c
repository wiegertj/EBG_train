
#include "header.h"

void predict_unit13(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3936276107755155018) ) ) {
    result[0] += -0.03031561050567313;
  } else {
    result[0] += 0.0011119374842968202;
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4101030825879397046) ) ) {
    result[0] += -0.01582773546579073;
  } else {
    result[0] += 0.0020693798646233223;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6427554134465586211) ) ) {
    result[0] += -0.0037874088066862655;
  } else {
    result[0] += 0.008509898995303735;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8428035383058734009) ) ) {
    result[0] += 0.005241953949114942;
  } else {
    result[0] += -0.006933600406659753;
  }
  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)5.951342055710952521e-07) ) ) {
    result[0] += -0.06200678702391918;
  } else {
    result[0] += 0.0005062742476414859;
  }
  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002301545161532000071) ) ) {
    result[0] += 0.018945109589202244;
  } else {
    result[0] += -0.00169477315318332;
  }
  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004919514120213501311) ) ) {
    result[0] += -0.011322763653083481;
  } else {
    result[0] += 0.0028768080462271447;
  }
  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3640888533806194149) ) ) {
    result[0] += 0.012306926348710369;
  } else {
    result[0] += -0.002469948282507865;
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6722423356281408413) ) ) {
    result[0] += -0.0028136877249437405;
  } else {
    result[0] += 0.0113401017988177;
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6277403467108452206) ) ) {
    result[0] += 0.0026226503197230955;
  } else {
    result[0] += -0.012628328666620356;
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8158067323869347964) ) ) {
    result[0] += -0.0011156898550918747;
  } else {
    result[0] += 0.02855187372048204;
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8374809319095478655) ) ) {
    result[0] += 0.0007579555012425621;
  } else {
    result[0] += -0.04802561706312526;
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.883661844891582726) ) ) {
    result[0] += -0.0003989459304057926;
  } else {
    result[0] += 0.07841503795641985;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9979566545417067891) ) ) {
    result[0] += 0.0008185151302777953;
  } else {
    result[0] += -0.03700954727463716;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8970324933564088887) ) ) {
    result[0] += -0.0008108812839279059;
  } else {
    result[0] += 0.04186329904280087;
  }
  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02500000000000000486) ) ) {
    result[0] += 0.08261072932045593;
  } else {
    result[0] += -0.0003569100309209578;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.162621891112566086) ) ) {
    result[0] += -0.11604021486686372;
  } else {
    result[0] += 0.0003072793197578803;
  }
  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5724391781153673753) ) ) {
    result[0] += -0.018343921381972165;
  } else {
    result[0] += 0.0015906709278910452;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6598425543490945566) ) ) {
    result[0] += -0.010451486320944314;
  } else {
    result[0] += 0.00283571353244242;
  }
}

