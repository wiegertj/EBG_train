
#include "header.h"

void predict_unit3(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5948284698255842384) ) ) {
    result[0] += -0.03759144182701053;
  } else {
    result[0] += 0.007145281641533143;
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.04546417654371086997) ) ) {
    result[0] += -0.19676576792762138;
  } else {
    result[0] += 0.0010870277204390452;
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.850000000000000659e-05) ) ) {
    result[0] += 0.0568500249423986;
  } else {
    result[0] += -0.00421267091407821;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6568744878893562067) ) ) {
    result[0] += -0.009318777964463744;
  } else {
    result[0] += 0.024241066992723628;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8450000000000000844) ) ) {
    result[0] += 0.018986447383631647;
  } else {
    result[0] += -0.012106389048048862;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6194192625572763067) ) ) {
    result[0] += -0.03153057816963822;
  } else {
    result[0] += 0.0069989824185431706;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7050000000000000711) ) ) {
    result[0] += 0.024650721124712838;
  } else {
    result[0] += -0.00849548703315546;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2878265030021618931) ) ) {
    result[0] += -0.09655279012802104;
  } else {
    result[0] += 0.001970026263655389;
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7166409246357593466) ) ) {
    result[0] += -0.008619851187914227;
  } else {
    result[0] += 0.021478902832437446;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8050000000000001599) ) ) {
    result[0] += 0.018496230513758788;
  } else {
    result[0] += -0.00984751105551388;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6246353589667689166) ) ) {
    result[0] += -0.029328262474738437;
  } else {
    result[0] += 0.0066727047162631545;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9694495419873773168) ) ) {
    result[0] += -0.0010775425743637325;
  } else {
    result[0] += 0.17337054282482306;
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.850000000000000659e-05) ) ) {
    result[0] += 0.04858619479476433;
  } else {
    result[0] += -0.0036596817382762267;
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002186500000000000509) ) ) {
    result[0] += -0.023347153337235724;
  } else {
    result[0] += 0.007498609802279288;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1594586647043804151) ) ) {
    result[0] += -0.17654697492930993;
  } else {
    result[0] += 0.0009120263145040564;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7050000000000000711) ) ) {
    result[0] += 0.02157271359496982;
  } else {
    result[0] += -0.007532050062761045;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6246353589667689166) ) ) {
    result[0] += -0.02705094184859014;
  } else {
    result[0] += 0.006085241436555828;
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.850000000000000659e-05) ) ) {
    result[0] += 0.04475636223182941;
  } else {
    result[0] += -0.0034412270511128946;
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.097216905567068856) ) ) {
    result[0] += 0.0030198010246580143;
  } else {
    result[0] += -0.049059218823504745;
  }
}

