
#include "header.h"

void predict_unit3(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8305400774473623571) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6574910164466515328) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5335728757895682461) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2946983627136980366) ) ) {
          result[0] += -0.0536252852707349;
        } else {
          result[0] += -0.047126715854633336;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5650000000000000577) ) ) {
          result[0] += -0.02791196777426999;
        } else {
          result[0] += -0.0408054654743718;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7366403613896054248) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7150000000000000799) ) ) {
          result[0] += -0.010264096455885052;
        } else {
          result[0] += -0.025817003140177066;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8450000000000000844) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1131945000000000173) ) ) {
            result[0] += 0.013867256501027506;
          } else {
            result[0] += -0.013599586314184405;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3905483718502500978) ) ) {
            result[0] += 0.0009776687701610156;
          } else {
            result[0] += -0.01362654590193403;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8299157965154307925) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7358378217099063034) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9261395677439890894) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7150000000000000799) ) ) {
            result[0] += 0.048148530075021304;
          } else {
            result[0] += 0.02182506430977279;
          }
        } else {
          result[0] += 0.045608978577761944;
        }
      } else {
        result[0] += 0.04354964675531903;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8945815063191204786) ) ) {
        result[0] += 0.0596089618325515;
      } else {
        result[0] += 0.068749065257999;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8033472943825080703) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6337772083671809886) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4776960828135016768) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2703145439280746909) ) ) {
          result[0] += -0.05331406008964834;
        } else {
          result[0] += -0.04773102185362028;
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5250000000000001332) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.552787391059560318) ) ) {
            result[0] += -0.03908533332921944;
          } else {
            result[0] += -0.025317861231168904;
          }
        } else {
          result[0] += -0.04281991537795316;
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.720877625841553682) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7050000000000000711) ) ) {
          result[0] += -0.012638186230198386;
        } else {
          result[0] += -0.030082485583328284;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8650000000000001021) ) ) {
          result[0] += 0.004701743578308627;
        } else {
          result[0] += -0.008648626089002428;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7411513695868165996) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.863112229636659456) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7650000000000001243) ) ) {
          result[0] += 0.031782580952291715;
        } else {
          result[0] += 0.010512831136362703;
        }
      } else {
        if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.751334311843480207) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += 0.034077214196250774;
          } else {
            result[0] += 0.02101978792277558;
          }
        } else {
          result[0] += 0.041954611872271286;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8347688071710012148) ) ) {
        result[0] += 0.053589441555652914;
      } else {
        result[0] += 0.06578302288392522;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.783526186028636773) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6003075279628945493) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4056437611611355964) ) ) {
        result[0] += -0.051652272102197735;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += -0.03184119111097058;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003260500000000000377) ) ) {
            result[0] += -0.04951918076611595;
          } else {
            result[0] += -0.03876991113034392;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.720877625841553682) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7150000000000000799) ) ) {
          result[0] += -0.01606658683396562;
        } else {
          result[0] += -0.03206749308100483;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8150000000000000577) ) ) {
          result[0] += 0.0044456485002449175;
        } else {
          result[0] += -0.010459177027977063;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7868431215179150229) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8474756727480589058) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)13.50000000000000178) ) ) {
          result[0] += -0.013774145283401287;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002202500000000000464) ) ) {
            result[0] += -0.0033083595598087986;
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6196416197487438771) ) ) {
              result[0] += 0.0206634290420748;
            } else {
              result[0] += 0.0036513711280717984;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8943082925133570837) ) ) {
          result[0] += 0.023696381079341366;
        } else {
          result[0] += 0.035057952188277924;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8347688071710012148) ) ) {
        result[0] += 0.04953837770317473;
      } else {
        result[0] += 0.06428361516140597;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.783526186028636773) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5606360583019965871) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4056437611611355964) ) ) {
        result[0] += -0.05117145571370428;
      } else {
        result[0] += -0.041930382486838245;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7108706770295533106) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7150000000000000799) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6003075279628945493) ) ) {
            result[0] += -0.029992159065476035;
          } else {
            result[0] += -0.016146639680496767;
          }
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6574910164466515328) ) ) {
            result[0] += -0.04200805601923118;
          } else {
            result[0] += -0.026938975584662964;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8150000000000000577) ) ) {
          result[0] += 0.002397383294977036;
        } else {
          result[0] += -0.011275953176222774;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8059485593692011784) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8524704828946135793) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)13.50000000000000178) ) ) {
          result[0] += -0.011659990556077294;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002202500000000000464) ) ) {
            result[0] += -0.002090015113670916;
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6196416197487438771) ) ) {
              result[0] += 0.02054441402365582;
            } else {
              result[0] += 0.0035532407230871687;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.751334311843480207) ) ) {
          result[0] += 0.025930947784693854;
        } else {
          result[0] += 0.038287223051492986;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8347688071710012148) ) ) {
        result[0] += 0.049521407998959883;
      } else {
        result[0] += 0.06290070616421191;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.783526186028636773) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.552787391059560318) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2946983627136980366) ) ) {
        result[0] += -0.051821054921417066;
      } else {
        result[0] += -0.043799011608663174;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.720877625841553682) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007442500000000000331) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)7.839179265242341959e-06) ) ) {
            result[0] += -0.013722492161894398;
          } else {
            result[0] += -0.033608568144355505;
          }
        } else {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3313460023454675718) ) ) {
            result[0] += 0.005889712508141497;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05736790504422335096) ) ) {
              result[0] += -0.02651272828504763;
            } else {
              result[0] += -0.004030057150069823;
            }
          }
        }
      } else {
        result[0] += -0.00458364816371952;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7411513695868165996) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8524704828946135793) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)13.50000000000000178) ) ) {
          result[0] += -0.011166123519953535;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002202500000000000464) ) ) {
            result[0] += -0.001995982110973539;
          } else {
            result[0] += 0.014275050229342121;
          }
        }
      } else {
        if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7358378217099063034) ) ) {
          result[0] += 0.023716880700015888;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.04794759869212577;
          } else {
            result[0] += 0.03188967348901545;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8604095077903387567) ) ) {
        result[0] += 0.05020724702710346;
      } else {
        result[0] += 0.06221575967806936;
      }
    }
  }
}

