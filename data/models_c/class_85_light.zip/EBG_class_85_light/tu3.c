
#include "header.h"

void predict_unit3(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8016764265861101579) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5813400334181016982) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4431477231260214644) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2669666665921996418) ) ) {
          result[0] += -0.0496991285642763;
        } else {
          result[0] += -0.04502263237367982;
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
            result[0] += 0.009156888965142614;
          } else {
            result[0] += -0.031965405373859675;
          }
        } else {
          result[0] += -0.041382055034415305;
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7058987689933927667) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7050000000000000711) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.647174411118524473) ) ) {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3568604342421126119) ) ) {
              result[0] += -0.015557861216477922;
            } else {
              result[0] += -0.030866835650961644;
            }
          } else {
            result[0] += -0.009848329600246179;
          }
        } else {
          result[0] += -0.03336011028681418;
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8050000000000001599) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5072261056783921029) ) ) {
            if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2085874655574800063) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7408351266736160623) ) ) {
                result[0] += -0.013685699734553858;
              } else {
                result[0] += 0.012747934843757556;
              }
            } else {
              result[0] += -0.017443251830388095;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5521365942211056144) ) ) {
              result[0] += 0.020820356465952768;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5926917132914574227) ) ) {
                result[0] += -0.011400684882290502;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6186550572613066512) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6116569490452262725) ) ) {
                    result[0] += 0.00634143619316681;
                  } else {
                    result[0] += 0.07883153771439082;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.755533006633860027) ) ) {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01477650000000000144) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5986852915639623296) ) ) {
                        result[0] += -0.017718666075465784;
                      } else {
                        result[0] += 0.05167229603273042;
                      }
                    } else {
                      result[0] += -0.019749310958295452;
                    }
                  } else {
                    result[0] += 0.018052155799408047;
                  }
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7728505831511113255) ) ) {
            result[0] += -0.01373923153349961;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6750000000000001554) ) ) {
              result[0] += 0.00855148511515289;
            } else {
              result[0] += -0.009807504606442493;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7369297863416220951) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8956174930041188587) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8583556158382011914) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8250000000000000666) ) ) {
            result[0] += 0.02100322555904437;
          } else {
            result[0] += 0.007027493465709277;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2959821382502911269) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0007215000000000000276) ) ) {
              result[0] += -0.01578944822444431;
            } else {
              result[0] += 0.018206588317154368;
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              result[0] += 0.022157733163774482;
            } else {
              result[0] += 0.046738782520748264;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9443572767030988802) ) ) {
          result[0] += 0.03197509388675182;
        } else {
          result[0] += 0.04210663892397606;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8487060949625354622) ) ) {
        result[0] += 0.04881088490930433;
      } else {
        result[0] += 0.06007789651761761;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8016764265861101579) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5813400334181016982) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4431477231260214644) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2669666665921996418) ) ) {
          result[0] += -0.04931786634083923;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02500000000000000486) ) ) {
            result[0] += -0.017243713687282412;
          } else {
            result[0] += -0.044898744590309965;
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
            result[0] += 0.008758232295095255;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5580998554338508777) ) ) {
              result[0] += -0.03319088904505722;
            } else {
              result[0] += -0.015512753983024654;
            }
          }
        } else {
          result[0] += -0.0407411385649724;
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7012238381832097689) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3809493398436038514) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6567653699036690718) ) ) {
            result[0] += -0.018180009383392252;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4297607811809045497) ) ) {
              result[0] += -0.028772361720725014;
            } else {
              result[0] += 0.0013985067579647872;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6322976420381508644) ) ) {
            result[0] += -0.038924691770304616;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6950000000000000622) ) ) {
              result[0] += -0.014723216672813448;
            } else {
              result[0] += -0.031033342508896732;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7750000000000001332) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6541365753517588422) ) ) {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4879682222881388531) ) ) {
              result[0] += 0.0020130818426459343;
            } else {
              result[0] += -0.02042810136258892;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02838150000000000395) ) ) {
              result[0] += 0.03443726030115604;
            } else {
              result[0] += 0.0001728041382458953;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7728505831511113255) ) ) {
            result[0] += -0.012414988388199972;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6750000000000001554) ) ) {
              result[0] += 0.006444456506948916;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4856370791188283076) ) ) {
                result[0] += -0.003581112310763889;
              } else {
                result[0] += -0.023444462053794978;
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7369297863416220951) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8956174930041188587) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8455909065280039494) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8550000000000000933) ) ) {
            result[0] += 0.018871614249257655;
          } else {
            result[0] += 0.00398112246636407;
          }
        } else {
          result[0] += 0.018997880129658442;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9443572767030988802) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9050000000000001377) ) ) {
            result[0] += 0.03119686178716709;
          } else {
            result[0] += 0;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9150000000000001465) ) ) {
            result[0] += 0.043595232953072036;
          } else {
            result[0] += 0.02680122371195421;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8420098784315052098) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9815549730476619272) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001940500000000000167) ) ) {
              result[0] += 0.05904968123099834;
            } else {
              result[0] += 0.04407536793662162;
            }
          } else {
            result[0] += 0.05607288056963138;
          }
        } else {
          result[0] += 0.03466088532186724;
        }
      } else {
        result[0] += 0.05871847765998974;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8016764265861101579) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5693020021745025527) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4431477231260214644) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2585695341105315181) ) ) {
          result[0] += -0.049020857927668485;
        } else {
          result[0] += -0.044107767232078904;
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
          result[0] += -0.03087290625245802;
        } else {
          result[0] += -0.04079652155653525;
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7012238381832097689) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7050000000000000711) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04301650000000000612) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
                result[0] += 0.045001463934952315;
              } else {
                result[0] += 0.0017796736919662376;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2446095000000000352) ) ) {
                result[0] += -0.022738791158181507;
              } else {
                result[0] += 0.014591432231510307;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6322976420381508644) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002305000000000000462) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.596756249395726468) ) ) {
                  result[0] += -0.02572906978714987;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.564198853668341882) ) ) {
                    result[0] += -0.015224954725534005;
                  } else {
                    result[0] += 0.03432057601745636;
                  }
                }
              } else {
                result[0] += -0.032136564205825786;
              }
            } else {
              result[0] += -0.01321553179134106;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6181495723579168988) ) ) {
            result[0] += -0.04459204358999036;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4175496798250740715) ) ) {
              result[0] += 0.029812800376791026;
            } else {
              result[0] += -0.03105856389153169;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7850000000000001421) ) ) {
          result[0] += 0.001953508949824427;
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3837516359296482826) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9050000000000001377) ) ) {
              result[0] += -0.017253804925819575;
            } else {
              result[0] += 0.027414952382976237;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.790828820793463394) ) ) {
              result[0] += -0.011644222169820407;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005956500000000000856) ) ) {
                result[0] += -0.008892054753186626;
              } else {
                result[0] += 0.01789908531036133;
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7369297863416220951) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8956174930041188587) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8635248854378615446) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8650000000000001021) ) ) {
            result[0] += 0.017803173574261682;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8391219607133014735) ) ) {
              result[0] += 0.0022859480848684975;
            } else {
              result[0] += 0.012168471819143703;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.733886402487437306) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6461954822149375) ) ) {
              result[0] += 0.019036019108674064;
            } else {
              result[0] += -0.007859039146480755;
            }
          } else {
            result[0] += 0.037118595528744094;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9443572767030988802) ) ) {
          result[0] += 0.029494922184727827;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9250000000000001554) ) ) {
            result[0] += 0.041870413941674844;
          } else {
            result[0] += 0.02411075463950454;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8606418736522790658) ) ) {
        result[0] += 0.046640541422515926;
      } else {
        result[0] += 0.05800457372987651;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8016764265861101579) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5693020021745025527) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4431477231260214644) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2669666665921996418) ) ) {
          result[0] += -0.04861209469140523;
        } else {
          result[0] += -0.043483991556279224;
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
          result[0] += -0.030182007177063427;
        } else {
          result[0] += -0.04019091120197974;
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7058987689933927667) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7050000000000000711) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.647174411118524473) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3750000000000000555) ) ) {
              if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.01022552087010519806) ) ) {
                if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.07196201389915944657) ) ) {
                  result[0] += -0.009099021657260526;
                } else {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.04658055172941339556) ) ) {
                    result[0] += 0.08220801998331868;
                  } else {
                    result[0] += 0.0077700289539503285;
                  }
                }
              } else {
                result[0] += -0.02375270764385025;
              }
            } else {
              result[0] += -0.02727779339906152;
            }
          } else {
            result[0] += -0.008641686263247475;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6623732216749412816) ) ) {
            result[0] += -0.037018979051524015;
          } else {
            result[0] += -0.025518022270649213;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5350000000000001421) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7648528436111127204) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.497578551165735572) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.518449662688442281) ) ) {
                result[0] += -0.005357463354966519;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1295212041281339765) ) ) {
                  result[0] += 0.028171582432628475;
                } else {
                  result[0] += -0.005184960659665504;
                }
              }
            } else {
              result[0] += -0.017801102192681592;
            }
          } else {
            result[0] += 0.024926071803150228;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7408351266736160623) ) ) {
            result[0] += -0.013551831523092861;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3902192490452261464) ) ) {
              result[0] += 0.01259361760936768;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006188500000000000424) ) ) {
                result[0] += -0.010228630079700657;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1270445000000000324) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7728505831511113255) ) ) {
                    result[0] += -0.006641420932067585;
                  } else {
                    result[0] += 0.009207902868149436;
                  }
                } else {
                  result[0] += -0.042923810358655314;
                }
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7369297863416220951) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8956174930041188587) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8635248854378615446) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8550000000000000933) ) ) {
            result[0] += 0.017544302709338173;
          } else {
            result[0] += 0.0062118067189746145;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.733886402487437306) ) ) {
            result[0] += 0.016763962059666872;
          } else {
            result[0] += 0.035540384019353076;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9443572767030988802) ) ) {
          result[0] += 0.02834116350919754;
        } else {
          result[0] += 0.03800271152732083;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8420098784315052098) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9815549730476619272) ) ) {
            result[0] += 0.04328347586583833;
          } else {
            result[0] += 0.053535887215216196;
          }
        } else {
          result[0] += 0.03196176309319563;
        }
      } else {
        result[0] += 0.056519821787862634;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8162318130682130191) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5813400334181016982) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4431477231260214644) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2669666665921996418) ) ) {
          result[0] += -0.04828447633762712;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02500000000000000486) ) ) {
            result[0] += -0.014089752212680282;
          } else {
            result[0] += -0.04342857480171938;
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5580998554338508777) ) ) {
            result[0] += -0.03057316258964858;
          } else {
            result[0] += -0.011582120718476458;
          }
        } else {
          result[0] += -0.03891372039555774;
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7058987689933927667) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7050000000000000711) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.647174411118524473) ) ) {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3568604342421126119) ) ) {
              result[0] += -0.013234823218083221;
            } else {
              result[0] += -0.028153329271040577;
            }
          } else {
            result[0] += -0.008311324602246869;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6623732216749412816) ) ) {
            result[0] += -0.035823019755306336;
          } else {
            result[0] += -0.02484139535467902;
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8450000000000000844) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7690514563494603717) ) ) {
            result[0] += -0.0011101414355388555;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4036106884780860105) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1295212041281339765) ) ) {
                result[0] += 0.00996405211921843;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1945214781124514347) ) ) {
                  result[0] += -0.05301417140789714;
                } else {
                  result[0] += -0.0028145784113111556;
                }
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9299211678646118751) ) ) {
                result[0] += 0.04001410735785751;
              } else {
                result[0] += 0;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7778052425869795838) ) ) {
            result[0] += -0.01186589995761789;
          } else {
            result[0] += -0.0018913654229036887;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7369297863416220951) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8956174930041188587) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6832193430923222399) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003360500000000000206) ) ) {
            result[0] += 0.005903428095799406;
          } else {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6311795689938223264) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6157932186745959102) ) ) {
                result[0] += 0.019894653172803544;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5792515097236182742) ) ) {
                  result[0] += 0.014674750842588269;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.008596500000000001709) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007070500000000001263) ) ) {
                      result[0] += 0.0027784020735078198;
                    } else {
                      result[0] += 0.056950630695192656;
                    }
                  } else {
                    result[0] += -0.008675272468712133;
                  }
                }
              }
            } else {
              result[0] += 0.02395429923012497;
            }
          }
        } else {
          result[0] += 0.03417940942161441;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9443572767030988802) ) ) {
          result[0] += 0.027239706025594224;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9150000000000001465) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4583473626633166043) ) ) {
              result[0] += 0.028996205672887056;
            } else {
              result[0] += 0.04396796359871608;
            }
          } else {
            result[0] += 0.023238864609325026;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8487060949625354622) ) ) {
        result[0] += 0.04352519087866833;
      } else {
        result[0] += 0.05567293540689782;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8016764265861101579) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5693020021745025527) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4431477231260214644) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2585695341105315181) ) ) {
          result[0] += -0.04804414373090271;
        } else {
          result[0] += -0.04264307637580991;
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4850000000000000422) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5091389307398357378) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2666807845679768918) ) ) {
              result[0] += -0.027030880675698962;
            } else {
              result[0] += -0.04104350293580934;
            }
          } else {
            result[0] += -0.024365883957167603;
          }
        } else {
          result[0] += -0.04170530512046311;
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6964842473688145352) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7050000000000000711) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3750000000000000555) ) ) {
            if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.01022552087010519806) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5458973873869347182) ) ) {
                result[0] += -0.004150592151151609;
              } else {
                result[0] += 0.07193840099388059;
              }
            } else {
              result[0] += -0.01943817734050783;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6369124380183758261) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002305000000000000462) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.596756249395726468) ) ) {
                  result[0] += -0.02595545956368751;
                } else {
                  result[0] += 0.0014437874834109512;
                }
              } else {
                result[0] += -0.03160625174700837;
              }
            } else {
              result[0] += -0.011698894684073638;
            }
          }
        } else {
          result[0] += -0.031802642783770145;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5350000000000001421) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7648528436111127204) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4516330415522763486) ) ) {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3625916462747683644) ) ) {
                result[0] += -0.018425282210606884;
              } else {
                result[0] += 0.020386716739381316;
              }
            } else {
              result[0] += -0.006133588810831618;
            }
          } else {
            result[0] += 0.023427677515964574;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7214013188511664287) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001624500000000000293) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7156562986005801097) ) ) {
                result[0] += 0.007874463657475968;
              } else {
                result[0] += -0.04024679446054599;
              }
            } else {
              result[0] += -0.023557920453328985;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3902192490452261464) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9050000000000001377) ) ) {
                result[0] += -0.008317838945141086;
              } else {
                result[0] += 0.02675796215680233;
              }
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.5329091955564501104) ) ) {
                result[0] += -0.034942276625057965;
              } else {
                result[0] += -0.005921831921048296;
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7369297863416220951) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8956174930041188587) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8455909065280039494) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4850000000000000422) ) ) {
            result[0] += 0.04960827387297061;
          } else {
            result[0] += 0.0058476089032795005;
          }
        } else {
          result[0] += 0.016069796514810757;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9443572767030988802) ) ) {
          result[0] += 0.02618684915380186;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9250000000000001554) ) ) {
            result[0] += 0.03812415699677336;
          } else {
            result[0] += 0.02077590957825873;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8606418736522790658) ) ) {
        result[0] += 0.04296780836655961;
      } else {
        result[0] += 0.05504369030207703;
      }
    }
  }
}

