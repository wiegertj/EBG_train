
#include "header.h"

void predict_unit4(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.783526186028636773) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.552787391059560318) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2946983627136980366) ) ) {
        result[0] += -0.05142033329972009;
      } else {
        result[0] += -0.04315152642935273;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7055997140865902795) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7150000000000000799) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6003075279628945493) ) ) {
            if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.2878562317506634938) ) ) {
              result[0] += -0.014529930057050831;
            } else {
              result[0] += -0.03491398793112554;
            }
          } else {
            result[0] += -0.015091849625829927;
          }
        } else {
          result[0] += -0.03340669702746461;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8150000000000000577) ) ) {
          result[0] += 0.0015568757115432623;
        } else {
          result[0] += -0.010929172826113042;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7411513695868165996) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8524704828946135793) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)13.50000000000000178) ) ) {
          result[0] += -0.01069230626667322;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002202500000000000464) ) ) {
            result[0] += -0.0019061261009308006;
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6196416197487438771) ) ) {
              result[0] += 0.018795746445005933;
            } else {
              result[0] += 0.0027251516502299167;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9120665648705957862) ) ) {
          result[0] += 0.022747351221285763;
        } else {
          result[0] += 0.03477681546719786;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8347688071710012148) ) ) {
        result[0] += 0.04727953659072557;
      } else {
        result[0] += 0.060441901663947854;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7656222061929859324) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.552787391059560318) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2946983627136980366) ) ) {
        result[0] += -0.05103843493134737;
      } else {
        result[0] += -0.04251332411463439;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6890377340803973683) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.625000000000000111) ) ) {
          result[0] += -0.020040624767911915;
        } else {
          result[0] += -0.03227325055072708;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7750000000000001332) ) ) {
          result[0] += -0.0006031796225314755;
        } else {
          result[0] += -0.015232734022130762;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8059485593692011784) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8474756727480589058) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)13.50000000000000178) ) ) {
          result[0] += -0.008941711306758486;
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
            result[0] += 0.009212766326968536;
          } else {
            result[0] += -0.010890808274026595;
          }
        }
      } else {
        if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7358378217099063034) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9150000000000001465) ) ) {
            result[0] += 0.028890654874748546;
          } else {
            if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.686605359504699142) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01606384915386280601) ) ) {
                result[0] += 0.019718242962196174;
              } else {
                result[0] += -0.005053163837929321;
              }
            } else {
              result[0] += 0.021533960480275827;
            }
          }
        } else {
          result[0] += 0.03269436960424114;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8347688071710012148) ) ) {
        result[0] += 0.04514943624084466;
      } else {
        result[0] += 0.0593340271249142;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7656222061929859324) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.552787391059560318) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2946983627136980366) ) ) {
        result[0] += -0.0506738595307831;
      } else {
        result[0] += -0.041883122722183704;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6755187506907774919) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5550000000000001599) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6003075279628945493) ) ) {
            result[0] += -0.02463885577795294;
          } else {
            result[0] += -0.008943272046478806;
          }
        } else {
          result[0] += -0.032223518321370125;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.795000000000000151) ) ) {
          result[0] += -0.0033776390597938114;
        } else {
          result[0] += -0.01620843396208684;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7411513695868165996) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8474756727480589058) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)13.50000000000000178) ) ) {
          result[0] += -0.00855974844322063;
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6196416197487438771) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003327500000000000163) ) ) {
              result[0] += 0.0018181580775333682;
            } else {
              result[0] += 0.015815474030216176;
            }
          } else {
            result[0] += -0.0022179662415899347;
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9120665648705957862) ) ) {
          result[0] += 0.020321610518988377;
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
            result[0] += 0.03816918585519245;
          } else {
            result[0] += 0.0255533853925515;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8604095077903387567) ) ) {
        result[0] += 0.04606802500989058;
      } else {
        result[0] += 0.05893422820197679;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7656222061929859324) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.552787391059560318) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2946983627136980366) ) ) {
        result[0] += -0.050325233405043183;
      } else {
        result[0] += -0.041259759631528226;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6890377340803973683) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7150000000000000799) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6003075279628945493) ) ) {
            if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.2878562317506634938) ) ) {
              result[0] += -0.012329480878365618;
            } else {
              result[0] += -0.03294755030107269;
            }
          } else {
            result[0] += -0.014149112771221007;
          }
        } else {
          result[0] += -0.03290315301135503;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7750000000000001332) ) ) {
          result[0] += -0.00042225629205578405;
        } else {
          result[0] += -0.014073199379942999;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7474614522612087475) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.686605359504699142) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8550000000000000933) ) ) {
          if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5862093503336099909) ) ) {
            result[0] += 0.004970738613158932;
          } else {
            result[0] += 0.027222133312791417;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6754021834779359024) ) ) {
            result[0] += 0.006021966692931251;
          } else {
            result[0] += -0.013346373480766055;
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8943082925133570837) ) ) {
          result[0] += 0.018721097060500954;
        } else {
          result[0] += 0.0309970000634403;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8945815063191204786) ) ) {
        result[0] += 0.047080186936275754;
      } else {
        result[0] += 0.05894838181099709;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7656222061929859324) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.552787391059560318) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2946983627136980366) ) ) {
        result[0] += -0.0499912675144711;
      } else {
        result[0] += -0.04064217380853821;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6755187506907774919) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5550000000000001599) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6003075279628945493) ) ) {
            result[0] += -0.023166850589884495;
          } else {
            result[0] += -0.008004090228339004;
          }
        } else {
          result[0] += -0.030771761491721204;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.795000000000000151) ) ) {
          result[0] += -0.0030064942810159893;
        } else {
          result[0] += -0.015007344205252593;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8299157965154307925) ) ) {
      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.686605359504699142) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8550000000000000933) ) ) {
          if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5862093503336099909) ) ) {
            result[0] += 0.0047386560054918725;
          } else {
            result[0] += 0.025952422037758216;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6754021834779359024) ) ) {
            result[0] += 0.005738780219549891;
          } else {
            result[0] += -0.012783883290989955;
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8943082925133570837) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)81.50000000000001421) ) ) {
            result[0] += 0.0094222461397446;
          } else {
            result[0] += 0.026017167304742836;
          }
        } else {
          result[0] += 0.030334466436196663;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8999934911843509022) ) ) {
        result[0] += 0.047159792441232105;
      } else {
        result[0] += 0.05823456017620424;
      }
    }
  }
}

