
#include "header.h"

void predict_unit4(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02048781658266805514) ) ) {
    result[0] += -0.011505278967748512;
  } else {
    result[0] += 0.012936204491367564;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9749256219547374203) ) ) {
    result[0] += -0.0008142458607342091;
  } else {
    result[0] += 0.18017324140331806;
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.04546417654371086997) ) ) {
    result[0] += -0.1878838181620195;
  } else {
    result[0] += 0.0007166128907520038;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8450000000000000844) ) ) {
    result[0] += 0.014494341119520355;
  } else {
    result[0] += -0.009356382794039221;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6427554134465586211) ) ) {
    result[0] += -0.008178201184691068;
  } else {
    result[0] += 0.018079596683709488;
  }
  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.13900392495124092) ) ) {
    result[0] += 0.08338076537299212;
  } else {
    result[0] += -0.00161557362714745;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.545000000000000151) ) ) {
    result[0] += 0.024906383852069208;
  } else {
    result[0] += -0.004818864744152468;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5948284698255842384) ) ) {
    result[0] += -0.029009716462690936;
  } else {
    result[0] += 0.005317477573446835;
  }
  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5724391781153673753) ) ) {
    result[0] += -0.03742179390708393;
  } else {
    result[0] += 0.0031744065577667202;
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
    result[0] += 0.03872917856564959;
  } else {
    result[0] += -0.0029835863684296664;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5343557630381970958) ) ) {
    result[0] += -0.03395369238516779;
  } else {
    result[0] += 0.00356588976244193;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7050000000000000711) ) ) {
    result[0] += 0.01903033255710256;
  } else {
    result[0] += -0.006685985137685187;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6246353589667689166) ) ) {
    result[0] += -0.023145266788056125;
  } else {
    result[0] += 0.005121437886984932;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.545000000000000151) ) ) {
    result[0] += 0.025202641517010845;
  } else {
    result[0] += -0.004882102573666548;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.135032862234758938) ) ) {
    result[0] += -0.18340456784893103;
  } else {
    result[0] += 0.0005694556226911779;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9532871366621060716) ) ) {
    result[0] += -0.0009278667968501977;
  } else {
    result[0] += 0.12399953495796416;
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6277403467108452206) ) ) {
    result[0] += 0.004751550840784559;
  } else {
    result[0] += -0.022190838037300323;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.871520348344035356) ) ) {
    result[0] += -0.007616653381891665;
  } else {
    result[0] += 0.01331639549360316;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8450000000000000844) ) ) {
    result[0] += 0.012966817738837011;
  } else {
    result[0] += -0.008445196296900803;
  }
}

