
#include "header.h"

void predict_unit4(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7863566523687727239) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.565436264745754591) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4431477231260214644) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2669666665921996418) ) ) {
          result[0] += -0.04767484520274919;
        } else {
          result[0] += -0.042034879677626785;
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4850000000000000422) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5091389307398357378) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2666807845679768918) ) ) {
              result[0] += -0.026387900095150022;
            } else {
              result[0] += -0.04049101806480741;
            }
          } else {
            result[0] += -0.023566664857948717;
          }
        } else {
          result[0] += -0.041734366950341384;
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6964842473688145352) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7050000000000000711) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3750000000000000555) ) ) {
            if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.01022552087010519806) ) ) {
              if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.07196201389915944657) ) ) {
                result[0] += -0.006982811390327046;
              } else {
                result[0] += 0.038026738635119406;
              }
            } else {
              result[0] += -0.01898195192492953;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6369124380183758261) ) ) {
              result[0] += -0.027014402782070103;
            } else {
              result[0] += -0.011275181574999233;
            }
          }
        } else {
          result[0] += -0.031303120719925026;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4850000000000000422) ) ) {
          result[0] += 0.005898953519590464;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7408351266736160623) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              result[0] += 0.016417157611842068;
            } else {
              result[0] += -0.014669988373721509;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3687216492462311868) ) ) {
              result[0] += 0.020791108198156685;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7850000000000001421) ) ) {
                result[0] += 0.005244121265009735;
              } else {
                result[0] += -0.009245828601580838;
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7369297863416220951) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.878151846485979104) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.827186441538020012) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6750000000000001554) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.629632012766062954) ) ) {
              result[0] += -0.015326396169753332;
            } else {
              result[0] += 0.014898515889383042;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00314500000000000066) ) ) {
              result[0] += 0.0050430925399172115;
            } else {
              result[0] += -0.010032618064230758;
            }
          }
        } else {
          result[0] += 0.012137679081085099;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9228588940825653841) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.008262500000000000747) ) ) {
            result[0] += 0.02806965441664447;
          } else {
            result[0] += 0.017459848072031877;
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.66451851912119142) ) ) {
              result[0] += 0.030079740321962083;
            } else {
              result[0] += 0.043865443474457436;
            }
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6779399817775906278) ) ) {
              result[0] += 0.002618737697209233;
            } else {
              result[0] += 0.029997332211522645;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8420098784315052098) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9870276685244862014) ) ) {
            result[0] += 0.04037882558373816;
          } else {
            result[0] += 0.05313267717100152;
          }
        } else {
          result[0] += 0.028080858936503052;
        }
      } else {
        result[0] += 0.053713903874100126;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8016764265861101579) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5693020021745025527) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4431477231260214644) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2669666665921996418) ) ) {
          result[0] += -0.04739028908961503;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02500000000000000486) ) ) {
            result[0] += -0.010946679325910662;
          } else {
            result[0] += -0.04204130282443389;
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
          result[0] += -0.02744621903306682;
        } else {
          result[0] += -0.037915440416177865;
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7012238381832097689) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7050000000000000711) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04301650000000000612) ) ) {
              result[0] += 0.010306213946489447;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2446095000000000352) ) ) {
                result[0] += -0.020546053340506562;
              } else {
                result[0] += 0.016195761580508634;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6322976420381508644) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002305000000000000462) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.596756249395726468) ) ) {
                  result[0] += -0.022628479578261217;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.564198853668341882) ) ) {
                    result[0] += -0.012511215366202554;
                  } else {
                    result[0] += 0.03626654824344711;
                  }
                }
              } else {
                result[0] += -0.02906255069712982;
              }
            } else {
              result[0] += -0.011083440290665431;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6181495723579168988) ) ) {
            result[0] += -0.04229574349339146;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4175496798250740715) ) ) {
              result[0] += 0.034900748539609616;
            } else {
              result[0] += -0.027548716390107267;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5350000000000001421) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7648528436111127204) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4516330415522763486) ) ) {
              result[0] += 0.01419974123394139;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0629345000000000182) ) ) {
                result[0] += 0.001274078864470658;
              } else {
                result[0] += -0.0187907228810925;
              }
            }
          } else {
            result[0] += 0.02198991942021338;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7214013188511664287) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001624500000000000293) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7156562986005801097) ) ) {
                result[0] += 0.012590591230154064;
              } else {
                result[0] += -0.03929661108469739;
              }
            } else {
              result[0] += -0.02252813658456521;
            }
          } else {
            result[0] += -0.005066454477045401;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7369297863416220951) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8956174930041188587) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8635248854378615446) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6950000000000000622) ) ) {
            result[0] += 0.013977245154758462;
          } else {
            result[0] += 0.0042701729795956754;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.733886402487437306) ) ) {
            result[0] += 0.013948906111290627;
          } else {
            result[0] += 0.03215702535768029;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9443572767030988802) ) ) {
          result[0] += 0.02422770987896287;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9150000000000001465) ) ) {
            result[0] += 0.036236024675061616;
          } else {
            result[0] += 0.020333573777325677;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8487060949625354622) ) ) {
        result[0] += 0.04012229502499399;
      } else {
        result[0] += 0.0530431145652767;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7863566523687727239) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.561925680077866585) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3789369143834280806) ) ) {
        result[0] += -0.04581817143680831;
      } else {
        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7429456371859297636) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02120850000000000166) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                result[0] += -0.027273106481001307;
              } else {
                result[0] += -0.038847487702900314;
              }
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.05641065258394634824) ) ) {
                result[0] += -0.03755965071921934;
              } else {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.04658055172941339556) ) ) {
                  result[0] += 0.03453963297946363;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08500000000000000611) ) ) {
                    result[0] += 0.0336364944700981;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5091389307398357378) ) ) {
                      result[0] += -0.028713079532307773;
                    } else {
                      result[0] += -0.005919903397297557;
                    }
                  }
                }
              }
            }
          } else {
            result[0] += -0.043607793997153046;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6964842473688145352) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3750000000000000555) ) ) {
          if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.01022552087010519806) ) ) {
            if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.07196201389915944657) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2250000000000000333) ) ) {
                result[0] += 0.02408214944454594;
              } else {
                result[0] += -0.010943706258244753;
              }
            } else {
              result[0] += 0.03524184988450132;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2446095000000000352) ) ) {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2492881011664858926) ) ) {
                result[0] += 0.02892644755873507;
              } else {
                result[0] += -0.02529124306051478;
              }
            } else {
              result[0] += 0.011520486055910594;
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6450000000000001288) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5916566943077593566) ) ) {
              result[0] += -0.03354382507274245;
            } else {
              result[0] += -0.012229776726814807;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.647174411118524473) ) ) {
              result[0] += -0.03597279351579567;
            } else {
              result[0] += -0.02335674241820649;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8250000000000000666) ) ) {
          result[0] += -0.00015914220002288723;
        } else {
          result[0] += -0.009841963433888467;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7369297863416220951) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.878151846485979104) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5250000000000001332) ) ) {
          result[0] += 0.034878334539048296;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8162318130682130191) ) ) {
            result[0] += 0.0006254539638139571;
          } else {
            result[0] += 0.01010605835800841;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9443572767030988802) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.008596500000000001709) ) ) {
            result[0] += 0.026960613621288102;
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9268618155849429607) ) ) {
                result[0] += 0.017511531329965385;
              } else {
                result[0] += 0.030285177562194017;
              }
            } else {
              result[0] += 0.008309930574643045;
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4093335132160804135) ) ) {
            result[0] += 0.02078402367162748;
          } else {
            result[0] += 0.035583768959251166;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8606418736522790658) ) ) {
        result[0] += 0.039714242077354515;
      } else {
        result[0] += 0.052587611084872934;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7863566523687727239) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5380269784348243878) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2753344786675505085) ) ) {
        result[0] += -0.04674894041183012;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4431477231260214644) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02500000000000000486) ) ) {
            result[0] += -0.006232117809994268;
          } else {
            result[0] += -0.040936856704182026;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3650000000000000466) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2446095000000000352) ) ) {
              result[0] += -0.027926159516290606;
            } else {
              result[0] += 0.023915493937540507;
            }
          } else {
            result[0] += -0.03952257175194277;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6964842473688145352) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
            result[0] += 0.03682977713538899;
          } else {
            result[0] += -0.011303426793930057;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.647174411118524473) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.625000000000000111) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5916566943077593566) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3219690287256820604) ) ) {
                  result[0] += -0.007479307867276051;
                } else {
                  result[0] += -0.030437626916687447;
                }
              } else {
                result[0] += -0.013783152339458458;
              }
            } else {
              result[0] += -0.03628930028672867;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7050000000000000711) ) ) {
              result[0] += -0.008705296998829647;
            } else {
              result[0] += -0.024519118318768983;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4850000000000000422) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5191847285678393709) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
              result[0] += 0.00487424874525269;
            } else {
              result[0] += -0.028032153548539274;
            }
          } else {
            result[0] += 0.01599077631191704;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7408351266736160623) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              result[0] += 0.015852463430560404;
            } else {
              result[0] += -0.013582829496092493;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3687216492462311868) ) ) {
              result[0] += 0.02009436079691046;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7850000000000001421) ) ) {
                result[0] += 0.005128066615907381;
              } else {
                result[0] += -0.008357374023669196;
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7369297863416220951) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.878151846485979104) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5250000000000001332) ) ) {
          result[0] += 0.033348095176556805;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8162318130682130191) ) ) {
            result[0] += 0.0005986508425956224;
          } else {
            result[0] += 0.009663322778798803;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9443572767030988802) ) ) {
          result[0] += 0.021164060833054357;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9150000000000001465) ) ) {
            result[0] += 0.03416534760930992;
          } else {
            result[0] += 0.018369827237735732;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8420098784315052098) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9815549730476619272) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001940500000000000167) ) ) {
              result[0] += 0.05117786999126027;
            } else {
              result[0] += 0.03440598920606469;
            }
          } else {
            result[0] += 0.04759975597590757;
          }
        } else {
          result[0] += 0.02455803728450908;
        }
      } else {
        result[0] += 0.05135627418063601;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7863566523687727239) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5380269784348243878) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2753344786675505085) ) ) {
        result[0] += -0.0464938785612374;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4431477231260214644) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02500000000000000486) ) ) {
            result[0] += -0.006012255341734495;
          } else {
            result[0] += -0.0404901447967355;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3650000000000000466) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1550000000000000266) ) ) {
              result[0] += -0.005107482379625014;
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
                result[0] += 0.022535584523515763;
              } else {
                result[0] += -0.029516216569323173;
              }
            }
          } else {
            result[0] += -0.03900714654063083;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6964842473688145352) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6450000000000001288) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5916566943077593566) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3470551487622928755) ) ) {
              result[0] += -0.01236296746455289;
            } else {
              result[0] += -0.029092109414064243;
            }
          } else {
            result[0] += -0.010559015327498705;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6181495723579168988) ) ) {
            result[0] += -0.03836378857003031;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3750000000000000555) ) ) {
              result[0] += 0.021575109801016647;
            } else {
              result[0] += -0.025113997811642502;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8250000000000000666) ) ) {
          result[0] += -0.00010863465370581538;
        } else {
          result[0] += -0.009132539022352502;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7369297863416220951) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8956174930041188587) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8455909065280039494) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5350000000000001421) ) ) {
            result[0] += 0.03238659345334342;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6950000000000000622) ) ) {
              result[0] += 0.00801725737339671;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6412033930398876036) ) ) {
                result[0] += -0.008511144482307482;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9808239647505231362) ) ) {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6464451517552985971) ) ) {
                    result[0] += 0.031695523727632645;
                  } else {
                    result[0] += 0;
                  }
                } else {
                  result[0] += 0.032566516695721734;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8352912313316583903) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02120850000000000166) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0006865000000000001526) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.795000000000000151) ) ) {
                  result[0] += 0.011813050324354353;
                } else {
                  result[0] += -0.037680603090549124;
                }
              } else {
                result[0] += 0.016221176635888145;
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9350000000000001643) ) ) {
                result[0] += 0.010404729414450463;
              } else {
                result[0] += -0.006643504143085687;
              }
            }
          } else {
            result[0] += 0.03916584640442683;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9815549730476619272) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4093335132160804135) ) ) {
            result[0] += 0.014624018158876621;
          } else {
            result[0] += 0.02519849776844643;
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += 0.050768976636130315;
          } else {
            result[0] += 0.016666051773285572;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8606418736522790658) ) ) {
        result[0] += 0.03772971701166118;
      } else {
        result[0] += 0.05116333658118146;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7863566523687727239) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5380269784348243878) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2753344786675505085) ) ) {
        result[0] += -0.046248614110867385;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4431477231260214644) ) ) {
          result[0] += -0.039619671600341785;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.25500000000000006) ) ) {
            result[0] += -0.02366640251596564;
          } else {
            result[0] += -0.037034467170223524;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6964842473688145352) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
            result[0] += 0.03557102970535273;
          } else {
            result[0] += -0.010362687454115583;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.647174411118524473) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.625000000000000111) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5916566943077593566) ) ) {
                result[0] += -0.02588311361486827;
              } else {
                result[0] += -0.012958368355400509;
              }
            } else {
              result[0] += -0.035174456049202635;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4327651086396848146) ) ) {
              result[0] += -0.0009397668853669295;
            } else {
              result[0] += -0.02060249659455474;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4516330415522763486) ) ) {
          result[0] += 0.0110612922053018;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7309551922231288801) ) ) {
            result[0] += -0.012141892715988577;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3687216492462311868) ) ) {
              result[0] += 0.016255665540232292;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.514594807601719606) ) ) {
                result[0] += 0.004331270106657553;
              } else {
                result[0] += -0.007028381601297588;
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7369297863416220951) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.878151846485979104) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5250000000000001332) ) ) {
          result[0] += 0.030692960656991612;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8162318130682130191) ) ) {
            result[0] += 0.0003963699088249346;
          } else {
            result[0] += 0.008870275450860027;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9228588940825653841) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.008262500000000000747) ) ) {
            result[0] += 0.023495677645038616;
          } else {
            result[0] += 0.013582082381432685;
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.66451851912119142) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5412655711306534334) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.287353500000000095) ) ) {
                  result[0] += 0.021682908853853492;
                } else {
                  result[0] += -0.04140385077874504;
                }
              } else {
                result[0] += 0.03572913671621563;
              }
            } else {
              result[0] += 0.03901876196723994;
            }
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6779399817775906278) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7552974752811213444) ) ) {
                result[0] += 0.013706497374115731;
              } else {
                result[0] += -0.016719034483206864;
              }
            } else {
              result[0] += 0.025356415297416522;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8420098784315052098) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9870276685244862014) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001940500000000000167) ) ) {
              result[0] += 0.04966632041076844;
            } else {
              result[0] += 0.03341995679642741;
            }
          } else {
            result[0] += 0.0488755487081016;
          }
        } else {
          result[0] += 0.022513908965557463;
        }
      } else {
        result[0] += 0.04997492201971692;
      }
    }
  }
}

