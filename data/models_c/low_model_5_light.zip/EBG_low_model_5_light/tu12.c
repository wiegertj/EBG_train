
#include "header.h"

void predict_unit12(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -7.092912942783635e-09;
            } else {
              result[0] += -1.6850323484750073e-08;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.6850323484750073e-08;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -1.6850323484750073e-08;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -1.6850323484750073e-08;
                } else {
                  result[0] += -1.6850323484750073e-08;
                }
              }
            }
          }
        } else {
          result[0] += 1.636198591807511e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -1.6850323484750073e-08;
                } else {
                  result[0] += -1.6850323484750073e-08;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.06536400211476856) ) ) {
                    result[0] += -1.6850323484750073e-08;
                  } else {
                    result[0] += -1.6850323484750073e-08;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -1.6850323484750073e-08;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -1.6850323484750073e-08;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -1.6850323484750073e-08;
                      } else {
                        result[0] += -1.6850323484750073e-08;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -1.6850323484750073e-08;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -1.6850323484750073e-08;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02928050000000000444) ) ) {
                      result[0] += -1.6850323484750073e-08;
                    } else {
                      result[0] += -1.6850323484750073e-08;
                    }
                  }
                }
              } else {
                result[0] += -1.6850323484750073e-08;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -1.6850323484750073e-08;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -1.6850323484750073e-08;
                } else {
                  result[0] += -1.6850323484750073e-08;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -1.6850323484750073e-08;
                } else {
                  result[0] += -1.6850323484750073e-08;
                }
              }
            }
          }
        } else {
          result[0] += 2.3090183594989715e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2575587311557789305) ) ) {
          result[0] += 0.002051042712490173;
        } else {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3158425968844221221) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7150000000000000799) ) ) {
                result[0] += -0.0013771828925917386;
              } else {
                result[0] += 0.002304067276530645;
              }
            } else {
              result[0] += -0.004899714060278709;
            }
          } else {
            result[0] += 4.235255597310934e-06;
          }
        }
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2669585275879397535) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00338750000000000032) ) ) {
            result[0] += -4.027359448102342e-05;
          } else {
            result[0] += 1.852177482851461e-05;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1828583041203602211) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
                result[0] += -0.0010740287679657907;
              } else {
                result[0] += 0.00012766780817978095;
              }
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5910501547487437835) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5835479980653267562) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3872449054220527542) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2659201053550500626) ) ) {
                      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4914057384422110819) ) ) {
                        result[0] += -0.0013076671106821494;
                      } else {
                        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
                          result[0] += 0.0010254110562239358;
                        } else {
                          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5064897371608040322) ) ) {
                            result[0] += -0.0027235561896380334;
                          } else {
                            result[0] += 7.644579479367139e-05;
                          }
                        }
                      }
                    } else {
                      result[0] += 0.002309357603631353;
                    }
                  } else {
                    result[0] += -0.0008428078263716295;
                  }
                } else {
                  result[0] += -0.0026600165714855046;
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02374450000000000519) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9993516786272610419) ) ) {
                    result[0] += 0.0003645426249692789;
                  } else {
                    result[0] += -0.00047741082901071153;
                  }
                } else {
                  result[0] += 9.085527931409933e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.156847194217679814) ) ) {
              result[0] += 2.0074654757829597e-05;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)35.50000000000000711) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4547672002352448062) ) ) {
                  result[0] += -0.0004394926770489528;
                } else {
                  result[0] += 0.0001359162541485479;
                }
              } else {
                result[0] += 6.120405615688122e-05;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -6.319938229339504e-09;
            } else {
              result[0] += -1.501400121882123e-08;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.501400121882123e-08;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -1.501400121882123e-08;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -1.501400121882123e-08;
                } else {
                  result[0] += -1.501400121882123e-08;
                }
              }
            }
          }
        } else {
          result[0] += 1.457888192701383e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -1.501400121882123e-08;
                } else {
                  result[0] += -1.501400121882123e-08;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.06536400211476856) ) ) {
                    result[0] += -1.501400121882123e-08;
                  } else {
                    result[0] += -1.501400121882123e-08;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -1.501400121882123e-08;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -1.501400121882123e-08;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -1.501400121882123e-08;
                      } else {
                        result[0] += -1.501400121882123e-08;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -1.501400121882123e-08;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -1.501400121882123e-08;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02928050000000000444) ) ) {
                      result[0] += -1.501400121882123e-08;
                    } else {
                      result[0] += -1.501400121882123e-08;
                    }
                  }
                }
              } else {
                result[0] += -1.501400121882123e-08;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -1.501400121882123e-08;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -1.501400121882123e-08;
                } else {
                  result[0] += -1.501400121882123e-08;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -1.501400121882123e-08;
                } else {
                  result[0] += -1.501400121882123e-08;
                }
              }
            }
          }
        } else {
          result[0] += 2.0573850997681516e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08030541277720280868) ) ) {
          result[0] += -1.4983011121723682e-05;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2397171522356433271) ) ) {
            result[0] += 0.0028081942263358723;
          } else {
            result[0] += -7.765581689977523e-05;
          }
        }
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2669585275879397535) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00338750000000000032) ) ) {
            result[0] += -3.588464026648958e-05;
          } else {
            result[0] += 1.6503300372939413e-05;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1725637113259415323) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
                result[0] += -0.0009569827692555177;
              } else {
                result[0] += 0.00010766654356391143;
              }
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5910501547487437835) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.08390973343508316418) ) ) {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4983996163819096048) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
                      result[0] += -0.0027672949670489947;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1269590000000000163) ) ) {
                        result[0] += 0.0010697270025801795;
                      } else {
                        result[0] += -0.0018679794398224184;
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
                      result[0] += 0.0012059840405946073;
                    } else {
                      result[0] += 0.00011828793484308535;
                    }
                  }
                } else {
                  result[0] += -0.0005555123762924276;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005491500000000000721) ) ) {
                  result[0] += 0.000468388742323223;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006482000000000000782) ) ) {
                    result[0] += -0.0003256508085434663;
                  } else {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7608008567839197323) ) ) {
                      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7156546188693468924) ) ) {
                        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6586934769095478259) ) ) {
                          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6541365753517588422) ) ) {
                            result[0] += 0.00016715300356989123;
                          } else {
                            result[0] += -0.006359259111760949;
                          }
                        } else {
                          result[0] += 0.0008298477679238674;
                        }
                      } else {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01265500000000000132) ) ) {
                          result[0] += 0.0007625195116474163;
                        } else {
                          result[0] += -0.0010605325197907552;
                        }
                      }
                    } else {
                      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8106783849246231854) ) ) {
                        result[0] += 0.0010382511183153664;
                      } else {
                        result[0] += -0.003461503536257375;
                      }
                    }
                  }
                }
              }
            }
          } else {
            result[0] += 1.8960520792524626e-05;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -5.631201108078349e-09;
            } else {
              result[0] += -1.337779852136226e-08;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.337779852136226e-08;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -1.337779852136226e-08;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -1.337779852136226e-08;
                } else {
                  result[0] += -1.337779852136226e-08;
                }
              }
            }
          }
        } else {
          result[0] += 1.2990097858919973e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -1.337779852136226e-08;
                } else {
                  result[0] += -1.337779852136226e-08;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.06536400211476856) ) ) {
                    result[0] += -1.337779852136226e-08;
                  } else {
                    result[0] += -1.337779852136226e-08;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -1.337779852136226e-08;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -1.337779852136226e-08;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -1.337779852136226e-08;
                      } else {
                        result[0] += -1.337779852136226e-08;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -1.337779852136226e-08;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -1.337779852136226e-08;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02928050000000000444) ) ) {
                      result[0] += -1.337779852136226e-08;
                    } else {
                      result[0] += -1.337779852136226e-08;
                    }
                  }
                }
              } else {
                result[0] += -1.337779852136226e-08;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -1.337779852136226e-08;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -1.337779852136226e-08;
                } else {
                  result[0] += -1.337779852136226e-08;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -1.337779852136226e-08;
                } else {
                  result[0] += -1.337779852136226e-08;
                }
              }
            }
          }
        } else {
          result[0] += 1.8331744446009853e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
        result[0] += -2.356726241852998e-06;
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3687216492462311868) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.009691500000000000462) ) ) {
            result[0] += 2.3862455646315694e-05;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)64.50000000000001421) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)19.50000000000000355) ) ) {
                result[0] += 0.0002762159754900435;
              } else {
                result[0] += 8.755567418584763e-06;
              }
            } else {
              result[0] += 1.4704796150537597e-05;
            }
          }
        } else {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.5724391781153673753) ) ) {
            if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.64813350269320813) ) ) {
              result[0] += 3.134131583096856e-05;
            } else {
              result[0] += -0.0002995410375094324;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2162432673096428282) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1185261981962025396) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01112050000000000191) ) ) {
                  result[0] += 0.0003241840734151279;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02523350000000000246) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
                      result[0] += 0.0025727341816141457;
                    } else {
                      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3539353041941689093) ) ) {
                        result[0] += 0.00018403421739617297;
                      } else {
                        result[0] += -0.001190771784879755;
                      }
                    }
                  } else {
                    if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3763018001168558224) ) ) {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1560895000000000199) ) ) {
                        if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4323286620486300191) ) ) {
                          result[0] += 0.00011802774268867925;
                        } else {
                          result[0] += -0.0068278683108818515;
                        }
                      } else {
                        result[0] += -0.0001982121507939306;
                      }
                    } else {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06270917377236372159) ) ) {
                        result[0] += 0.000434503703879884;
                      } else {
                        result[0] += 0.000434847652087448;
                      }
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001475500000000000249) ) ) {
                  result[0] += 0.002250121493025787;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.003859773430623800444) ) ) {
                    result[0] += -0.006523943843267006;
                  } else {
                    result[0] += 9.670345875201463e-05;
                  }
                }
              }
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2450759342279490716) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1016030000000000127) ) ) {
                  result[0] += 3.741927473286295e-05;
                } else {
                  result[0] += -0.00011102557631744478;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0133385000000000014) ) ) {
                  result[0] += -8.761510639648645e-05;
                } else {
                  result[0] += 1.5820661528413934e-05;
                }
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -5.017521496074645e-09;
            } else {
              result[0] += -1.1919906670436059e-08;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.1919906670436059e-08;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -1.1919906670436059e-08;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -1.1919906670436059e-08;
                } else {
                  result[0] += -1.1919906670436059e-08;
                }
              }
            }
          }
        } else {
          result[0] += 1.1574457028259372e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -1.1919906670436059e-08;
                } else {
                  result[0] += -1.1919906670436059e-08;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.06536400211476856) ) ) {
                    result[0] += -1.1919906670436059e-08;
                  } else {
                    result[0] += -1.1919906670436059e-08;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -1.1919906670436059e-08;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -1.1919906670436059e-08;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -1.1919906670436059e-08;
                      } else {
                        result[0] += -1.1919906670436059e-08;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -1.1919906670436059e-08;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -1.1919906670436059e-08;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02928050000000000444) ) ) {
                      result[0] += -1.1919906670436059e-08;
                    } else {
                      result[0] += -1.1919906670436059e-08;
                    }
                  }
                }
              } else {
                result[0] += -1.1919906670436059e-08;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -1.1919906670436059e-08;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -1.1919906670436059e-08;
                } else {
                  result[0] += -1.1919906670436059e-08;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -1.1919906670436059e-08;
                } else {
                  result[0] += -1.1919906670436059e-08;
                }
              }
            }
          }
        } else {
          result[0] += 1.6333979208446839e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
        result[0] += -2.0998938506807586e-06;
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4589535259190716254) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)262.5000000000000568) ) ) {
            if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.5256280528790188145) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4184049418341709292) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1377635000000000109) ) ) {
                  result[0] += 2.5350347252662124e-05;
                } else {
                  result[0] += 1.1893888814449728e-05;
                }
              } else {
                result[0] += -0.00026374298478120035;
              }
            } else {
              result[0] += 7.482154537822207e-05;
            }
          } else {
            result[0] += 1.310229014455106e-05;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007698000000000000849) ) ) {
                result[0] += 0.0014870137601552815;
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5272802516080402624) ) ) {
                  if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1828583041203602211) ) ) {
                    if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2321635079408217728) ) ) {
                      result[0] += -0.0005043042243320659;
                    } else {
                      result[0] += 0.0022987636925119476;
                    }
                  } else {
                    result[0] += -0.0023749499484465334;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03415342701090800376) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01244450000000000243) ) ) {
                      result[0] += 0.006011940888180779;
                    } else {
                      result[0] += -0.0008700908941691686;
                    }
                  } else {
                    result[0] += 0.001568620083882639;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01289050000000000092) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09351130266911866773) ) ) {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4573392949246231631) ) ) {
                    result[0] += 0.0005133519055485947;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2461338418913805726) ) ) {
                      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5613386861055277288) ) ) {
                        result[0] += -0.0001058706600684505;
                      } else {
                        result[0] += -0.000507276029760603;
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4960533228876460865) ) ) {
                        result[0] += 0.0009545637503044747;
                      } else {
                        result[0] += -0.0002722764472288116;
                      }
                    }
                  }
                } else {
                  result[0] += -0.0002735479900149266;
                }
              } else {
                result[0] += 0.00020715765567542053;
              }
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3763018001168558224) ) ) {
              result[0] += -0.0009824523455731792;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1165587384072143268) ) ) {
                result[0] += 1.4096550234491645e-05;
              } else {
                result[0] += 2.9516811441502932e-05;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -4.470719741680308e-09;
            } else {
              result[0] += -1.0620893624987682e-08;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.0620893624987682e-08;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -1.0620893624987682e-08;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -1.0620893624987682e-08;
                } else {
                  result[0] += -1.0620893624987682e-08;
                }
              }
            }
          }
        } else {
          result[0] += 1.0313090552045476e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -1.0620893624987682e-08;
                } else {
                  result[0] += -1.0620893624987682e-08;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.06536400211476856) ) ) {
                    result[0] += -1.0620893624987682e-08;
                  } else {
                    result[0] += -1.0620893624987682e-08;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -1.0620893624987682e-08;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -1.0620893624987682e-08;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -1.0620893624987682e-08;
                      } else {
                        result[0] += -1.0620893624987682e-08;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -1.0620893624987682e-08;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -1.0620893624987682e-08;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02928050000000000444) ) ) {
                      result[0] += -1.0620893624987682e-08;
                    } else {
                      result[0] += -1.0620893624987682e-08;
                    }
                  }
                }
              } else {
                result[0] += -1.0620893624987682e-08;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -1.0620893624987682e-08;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -1.0620893624987682e-08;
                } else {
                  result[0] += -1.0620893624987682e-08;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -1.0620893624987682e-08;
                } else {
                  result[0] += -1.0620893624987682e-08;
                }
              }
            }
          }
        } else {
          result[0] += 1.4553927345416706e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5650000000000000577) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4184049418341709292) ) ) {
            result[0] += 0.001011311823088653;
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3932416254517326903) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.435405567110552727) ) ) {
                result[0] += 0.00011844989373600411;
              } else {
                result[0] += -0.0038707128412230536;
              }
            } else {
              result[0] += 3.294879032031888e-05;
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.25500000000000006) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)58.50000000000000711) ) ) {
              result[0] += 0.0011199847916590622;
            } else {
              result[0] += -0.004571030112351451;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)542.5000000000001137) ) ) {
                result[0] += 0.0034195386905251372;
              } else {
                result[0] += -0.003212203931538754;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)27.50000000000000355) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6541365753517588422) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)24.50000000000000355) ) ) {
                    result[0] += -0.0009331646202469493;
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.875000000000000111) ) ) {
                      result[0] += -0.00864032151405357;
                    } else {
                      result[0] += -0.0037121967387125257;
                    }
                  }
                } else {
                  result[0] += 0.001116289146385153;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04088342693368870323) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04770400000000000335) ) ) {
                    result[0] += -9.833373340019087e-05;
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7450000000000001066) ) ) {
                      result[0] += 0.0022351457079280274;
                    } else {
                      result[0] += -0.0025154616444622324;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2461338418913805726) ) ) {
                    result[0] += 0.0035194584808003176;
                  } else {
                    result[0] += -5.535562790638506e-05;
                  }
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2450759342279490716) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)488.5000000000000568) ) ) {
              result[0] += 5.427623743452844e-05;
            } else {
              result[0] += 0.00024386876722084724;
            }
          } else {
            result[0] += 4.653107729458075e-05;
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)52.50000000000000711) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1165587384072143268) ) ) {
              result[0] += 2.151789687080223e-05;
            } else {
              result[0] += 1.830491438862188e-05;
            }
          } else {
            result[0] += 1.256032993035896e-05;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -3.983507599230862e-09;
            } else {
              result[0] += -9.463445017827254e-09;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -9.463445017827254e-09;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -9.463445017827254e-09;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -9.463445017827254e-09;
                } else {
                  result[0] += -9.463445017827254e-09;
                }
              }
            }
          }
        } else {
          result[0] += 9.189185849068349e-09;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -9.463445017827254e-09;
                } else {
                  result[0] += -9.463445017827254e-09;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.06536400211476856) ) ) {
                    result[0] += -9.463445017827254e-09;
                  } else {
                    result[0] += -9.463445017827254e-09;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -9.463445017827254e-09;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -9.463445017827254e-09;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -9.463445017827254e-09;
                      } else {
                        result[0] += -9.463445017827254e-09;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -9.463445017827254e-09;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -9.463445017827254e-09;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02928050000000000444) ) ) {
                      result[0] += -9.463445017827254e-09;
                    } else {
                      result[0] += -9.463445017827254e-09;
                    }
                  }
                }
              } else {
                result[0] += -9.463445017827254e-09;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -9.463445017827254e-09;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -9.463445017827254e-09;
                } else {
                  result[0] += -9.463445017827254e-09;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -9.463445017827254e-09;
                } else {
                  result[0] += -9.463445017827254e-09;
                }
              }
            }
          }
        } else {
          result[0] += 1.2967862789131674e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4418673924623115479) ) ) {
          result[0] += 8.233137686817747e-05;
        } else {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3932416254517326903) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01564550000000000315) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4850000000000000422) ) ) {
                result[0] += -0.0013806885378296317;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003182500000000000433) ) ) {
                  result[0] += -0.0030746284857848813;
                } else {
                  result[0] += 0.0012049520802951293;
                }
              }
            } else {
              result[0] += -0.015095535482655815;
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3002177033299863185) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001972498273255000271) ) ) {
                result[0] += -0.0010461492243772142;
              } else {
                result[0] += 0.0004610887860716651;
              }
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.226146172451905686) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5046554252763820747) ) ) {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4643511832914573034) ) ) {
                    result[0] += -1.4365648640684745e-05;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06779550000000000853) ) ) {
                      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)24.50000000000000355) ) ) {
                        result[0] += 0.0007298479551766508;
                      } else {
                        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)113.5000000000000142) ) ) {
                          result[0] += -0.005605123091274946;
                        } else {
                          result[0] += -0.001721374291892948;
                        }
                      }
                    } else {
                      result[0] += 0.000856555053276944;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5950000000000000844) ) ) {
                    result[0] += -0.0003176578608323367;
                  } else {
                    result[0] += 0.000900815130188714;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003250500000000000351) ) ) {
                    if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1916738466035730337) ) ) {
                      result[0] += -0.0020091757354023755;
                    } else {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.097574583927926608e-06) ) ) {
                        result[0] += -0.0015273311007737262;
                      } else {
                        result[0] += 0.00032915989099503945;
                      }
                    }
                  } else {
                    result[0] += 0.0007809107046832313;
                  }
                } else {
                  result[0] += -4.8460634321454275e-06;
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)52.50000000000000711) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3801755927260667134) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2756227488107761969) ) ) {
              result[0] += 4.81107974287229e-05;
            } else {
              result[0] += -0.0003874347396636583;
            }
          } else {
            result[0] += 1.6317938831889214e-05;
          }
        } else {
          result[0] += 1.119152454573838e-05;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -3.5493910846301097e-09;
            } else {
              result[0] += -8.432133374798146e-09;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -8.432133374798146e-09;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -8.432133374798146e-09;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -8.432133374798146e-09;
                } else {
                  result[0] += -8.432133374798146e-09;
                }
              }
            }
          }
        } else {
          result[0] += 8.187762547266555e-09;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -8.432133374798146e-09;
                } else {
                  result[0] += -8.432133374798146e-09;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.06536400211476856) ) ) {
                    result[0] += -8.432133374798146e-09;
                  } else {
                    result[0] += -8.432133374798146e-09;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -8.432133374798146e-09;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -8.432133374798146e-09;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -8.432133374798146e-09;
                      } else {
                        result[0] += -8.432133374798146e-09;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -8.432133374798146e-09;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -8.432133374798146e-09;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02928050000000000444) ) ) {
                      result[0] += -8.432133374798146e-09;
                    } else {
                      result[0] += -8.432133374798146e-09;
                    }
                  }
                }
              } else {
                result[0] += -8.432133374798146e-09;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -8.432133374798146e-09;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -8.432133374798146e-09;
                } else {
                  result[0] += -8.432133374798146e-09;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -8.432133374798146e-09;
                } else {
                  result[0] += -8.432133374798146e-09;
                }
              }
            }
          }
        } else {
          result[0] += 1.15546451020799e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2575587311557789305) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05285913554311885698) ) ) {
            result[0] += 0.0005436428026737014;
          } else {
            result[0] += -5.2517794222811255e-05;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.103377615329305908) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9250000000000001554) ) ) {
              result[0] += 3.99170642692175e-06;
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.9546544174008676498) ) ) {
                result[0] += 0.00020831997860073698;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9550000000000000711) ) ) {
                  result[0] += 0.0012778160069492005;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.714286561348693172) ) ) {
                    result[0] += 6.359587162873371e-05;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04855099859271875401) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01783151068195030359) ) ) {
                        result[0] += -0.0017890727075856438;
                      } else {
                        result[0] += 0.0018614277093616863;
                      }
                    } else {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07576791765615910335) ) ) {
                        result[0] += -0.001178282649644879;
                      } else {
                        result[0] += 0.00010968587600861174;
                      }
                    }
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3158425968844221221) ) ) {
              result[0] += -2.3874365848478925e-05;
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1185261981962025396) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4272215624986276938) ) ) {
                  result[0] += -8.994142282369035e-06;
                } else {
                  result[0] += 0.00023435930447777978;
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)56.50000000000000711) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6665876335678392328) ) ) {
                    result[0] += 0.0004113781597692961;
                  } else {
                    result[0] += -0.00034350009706109175;
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
                    result[0] += 2.4359839730093656e-05;
                  } else {
                    result[0] += -0.0005089960689598174;
                  }
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)52.50000000000000711) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3801755927260667134) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2756227488107761969) ) ) {
              result[0] += 4.28677569238973e-05;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4143094250104821241) ) ) {
                result[0] += -0.005617739021549374;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2712534726811091645) ) ) {
                  result[0] += 0.0003615548844335366;
                } else {
                  result[0] += -0.0005310158622672859;
                }
              }
            }
          } else {
            result[0] += 1.4539635024352002e-05;
          }
        } else {
          result[0] += 9.971889460888482e-06;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -3.1625839182558476e-09;
            } else {
              result[0] += -7.513212484084265e-09;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -7.513212484084265e-09;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -7.513212484084265e-09;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -7.513212484084265e-09;
                } else {
                  result[0] += -7.513212484084265e-09;
                }
              }
            }
          }
        } else {
          result[0] += 7.295472812449637e-09;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -7.513212484084265e-09;
                } else {
                  result[0] += -7.513212484084265e-09;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.06536400211476856) ) ) {
                    result[0] += -7.513212484084265e-09;
                  } else {
                    result[0] += -7.513212484084265e-09;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -7.513212484084265e-09;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -7.513212484084265e-09;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -7.513212484084265e-09;
                      } else {
                        result[0] += -7.513212484084265e-09;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -7.513212484084265e-09;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -7.513212484084265e-09;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02928050000000000444) ) ) {
                      result[0] += -7.513212484084265e-09;
                    } else {
                      result[0] += -7.513212484084265e-09;
                    }
                  }
                }
              } else {
                result[0] += -7.513212484084265e-09;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -7.513212484084265e-09;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -7.513212484084265e-09;
                } else {
                  result[0] += -7.513212484084265e-09;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -7.513212484084265e-09;
                } else {
                  result[0] += -7.513212484084265e-09;
                }
              }
            }
          }
        } else {
          result[0] += 1.0295437699025722e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2575587311557789305) ) ) {
          result[0] += 0.0002463150138095916;
        } else {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.103377615329305908) ) ) {
              if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.8537219630417757221) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
                  result[0] += -0.00024234958292376868;
                } else {
                  result[0] += 0.00018561758861466226;
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005491500000000000721) ) ) {
                  result[0] += -0.0010351074374656299;
                } else {
                  result[0] += -0.007548754461020372;
                }
              }
            } else {
              result[0] += -1.1685740344500344e-05;
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3539353041941689093) ) ) {
              if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3763018001168558224) ) ) {
                if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3998230401234152409) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)24.50000000000000355) ) ) {
                    if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.6699946881477002458) ) ) {
                      result[0] += -0.00038610745853781065;
                    } else {
                      if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4589535259190716254) ) ) {
                        result[0] += 0.0014393114904227874;
                      } else {
                        result[0] += 0.0002206488716095945;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4418673924623115479) ) ) {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02278050000000000561) ) ) {
                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05502768819289250574) ) ) {
                          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4074873865577889887) ) ) {
                            result[0] += -0.00026754215106870855;
                          } else {
                            result[0] += 0.0005444066908769919;
                          }
                        } else {
                          result[0] += -0.0001961551168947297;
                        }
                      } else {
                        result[0] += 6.552687639746509e-05;
                      }
                    } else {
                      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)50.50000000000000711) ) ) {
                        result[0] += -0.009085197061671947;
                      } else {
                        result[0] += 4.809876313665234e-05;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03603979634774020363) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01369138287730510203) ) ) {
                      result[0] += -0.0039746930655751985;
                    } else {
                      result[0] += 0.004458478815772935;
                    }
                  } else {
                    result[0] += -0.007143671025896981;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0008375000000000000283) ) ) {
                  result[0] += -0.0003728051288572961;
                } else {
                  result[0] += 0.0004889043040807816;
                }
              }
            } else {
              result[0] += 4.848604354728157e-06;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)17.50000000000000355) ) ) {
          result[0] += 1.0232515831184863e-05;
        } else {
          result[0] += 8.88516832660958e-06;
        }
      }
    }
  }
}

