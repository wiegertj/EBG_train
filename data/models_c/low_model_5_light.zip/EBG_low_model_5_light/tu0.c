
#include "header.h"

void predict_unit0(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0.009999999776482582;
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += 0.009530963842270325;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3084325690180824142) ) ) {
                    result[0] += 0.009530963842270325;
                  } else {
                    result[0] += 0.009530963842270325;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5642589213209130428) ) ) {
                    result[0] += 0.009530963842270325;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                      result[0] += 0.009530963842270325;
                    } else {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.770367159345256014) ) ) {
                        result[0] += 0.009530963842270325;
                      } else {
                        result[0] += 0.009530963842270325;
                      }
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6323035877889447987) ) ) {
                result[0] += 0.009530963842270325;
              } else {
                result[0] += 0.009530963842270325;
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6800105846231156992) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5673593061306533292) ) ) {
                  if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.071894537606111239) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5012509875628141653) ) ) {
                      result[0] += 0.009999999776482582;
                    } else {
                      result[0] += 0.009530963842270325;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5259885771356785922) ) ) {
                      result[0] += 0.011407107579119355;
                    } else {
                      result[0] += 0.009999999776482582;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3230417339964383738) ) ) {
                    result[0] += 0.009530963842270325;
                  } else {
                    result[0] += 0.009530963842270325;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01366150000000000177) ) ) {
                  result[0] += 0.009999999776482582;
                } else {
                  result[0] += 0.010750456555530155;
                }
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7469309846842711043) ) ) {
                result[0] += 0.009530963842270325;
              } else {
                result[0] += 0.009530963842270325;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8458243956458841861) ) ) {
                      result[0] += 0.009530963842270325;
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7847910031909549611) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.743670590552763966) ) ) {
                            result[0] += 0.009530963842270325;
                          } else {
                            result[0] += 0.009530963842270325;
                          }
                        } else {
                          result[0] += 0.009530963842270325;
                        }
                      } else {
                        result[0] += 0.009530963842270325;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                      result[0] += 0.009530963842270325;
                    } else {
                      result[0] += 0.009530963842270325;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9330260472110553094) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.051391296366422923) ) ) {
                      result[0] += 0.009530963842270325;
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                        result[0] += 0.009530963842270325;
                      } else {
                        result[0] += 0.009530963842270325;
                      }
                    }
                  } else {
                    result[0] += 0.009530963842270325;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7568047583165830039) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7240686518592965859) ) ) {
                    result[0] += 0.009530963842270325;
                  } else {
                    result[0] += 0.009530963842270325;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.029588714460048626) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06983950000000001268) ) ) {
                      result[0] += 0.009530963842270325;
                    } else {
                      result[0] += 0.009530963842270325;
                    }
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003447500000000000477) ) ) {
                      result[0] += 0.009530963842270325;
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05972350000000000575) ) ) {
                        result[0] += 0.009530963842270325;
                      } else {
                        result[0] += 0.009530963842270325;
                      }
                    }
                  }
                }
              }
            } else {
              result[0] += 0.009530963842270325;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              result[0] += 0.009530963842270325;
            } else {
              result[0] += 0.009530963842270325;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7458524151256281653) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6642917660552764003) ) ) {
                result[0] += 0.009999999776482582;
              } else {
                result[0] += 0.009530963842270325;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8032211286180904741) ) ) {
                result[0] += 0.009530963842270325;
              } else {
                result[0] += 0.009530963842270325;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
              result[0] += 0.009999999776482582;
            } else {
              result[0] += 0.009788935037471143;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.457260671080300662) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7418777389447237525) ) ) {
              result[0] += 0.010938071644907097;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01109850000000000246) ) ) {
                result[0] += 0.009999999776482582;
              } else {
                result[0] += 0.01046903571069484;
              }
            }
          } else {
            result[0] += 0.009530963842270325;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6968016071608041928) ) ) {
            result[0] += 0.009999999776482582;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9111514820863041431) ) ) {
              result[0] += 0.009999999776482582;
            } else {
              result[0] += 0.009999999776482582;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7568047583165830039) ) ) {
            result[0] += 0.01046903571069484;
          } else {
            result[0] += 0.009999999776482582;
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.05500000000000000722) ) ) {
          result[0] += 0.01046903571069484;
        } else {
          result[0] += 0.011407107579119355;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.717118227269369246) ) ) {
        result[0] += 0.01562843089966492;
      } else {
        result[0] += 0.009577866719999512;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5750608109547740154) ) ) {
              result[0] += -0.0004470364629622945;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                  result[0] += -0.0004470364629622945;
                } else {
                  result[0] += -0.0004470364629622945;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5881074671461999914) ) ) {
                    result[0] += -0.0004470364629622945;
                  } else {
                    result[0] += -0.0004470364629622945;
                  }
                } else {
                  result[0] += -0.0004470364629622945;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1347820638606622157) ) ) {
                result[0] += -0.0004470364629622945;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5458973873869347182) ) ) {
                  result[0] += 2.1999471249963017e-05;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002091500000000000477) ) ) {
                    result[0] += -0.0003766803571384176;
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02035900000000000556) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009908500000000002375) ) ) {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004748500000000000117) ) ) {
                          result[0] += -0.0004470364629622945;
                        } else {
                          result[0] += 0;
                        }
                      } else {
                        result[0] += -0.0004470364629622945;
                      }
                    } else {
                      result[0] += -0.0004470364629622945;
                    }
                  }
                }
              }
            } else {
              result[0] += 0.000894072925924589;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -0.0004470364629622945;
                    } else {
                      result[0] += -0.0004470364629622945;
                    }
                  } else {
                    result[0] += -0.0004470364629622945;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -0.0004470364629622945;
                  } else {
                    result[0] += -0.0004470364629622945;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -0.0004470364629622945;
                        } else {
                          result[0] += -0.0004470364629622945;
                        }
                      } else {
                        result[0] += -0.0004470364629622945;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -0.0004470364629622945;
                          } else {
                            result[0] += -0.0004470364629622945;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -0.0004470364629622945;
                            } else {
                              result[0] += -0.0004470364629622945;
                            }
                          } else {
                            result[0] += -0.0004470364629622945;
                          }
                        }
                      } else {
                        result[0] += -0.0004470364629622945;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -0.0004470364629622945;
                      } else {
                        result[0] += -0.0004470364629622945;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -0.0004470364629622945;
                      } else {
                        result[0] += -0.0004470364629622945;
                      }
                    }
                  }
                } else {
                  result[0] += -0.0004470364629622945;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -0.0004470364629622945;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -0.0004470364629622945;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -0.0004470364629622945;
                    } else {
                      result[0] += -0.0004470364629622945;
                    }
                  }
                } else {
                  result[0] += -0.0004470364629622945;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004302500000000001636) ) ) {
                result[0] += -0.0004470364629622945;
              } else {
                result[0] += 0.0003645807486565253;
              }
            } else {
              result[0] += -0.0004470364629622945;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0003865000000000000705) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5400401558291457738) ) ) {
            result[0] += 2.1999471249963017e-05;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.0004470364629622945;
              } else {
                result[0] += 0;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5881074671461999914) ) ) {
                  result[0] += 2.1999471249963017e-05;
                } else {
                  result[0] += -0.0004470364629622945;
                }
              } else {
                result[0] += 9.899694925425097e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01264450000000000122) ) ) {
              result[0] += 0;
            } else {
              result[0] += 2.1999471249963017e-05;
            }
          } else {
            result[0] += 0.001832144881713857;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6968016071608041928) ) ) {
            result[0] += 0;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9111514820863041431) ) ) {
              result[0] += 0;
            } else {
              result[0] += 0;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7568047583165830039) ) ) {
            result[0] += 0.0004470364629622945;
          } else {
            result[0] += 0;
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.05500000000000000722) ) ) {
          result[0] += 0.0004470364629622945;
        } else {
          result[0] += 0.0013411093888868835;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.717118227269369246) ) ) {
        result[0] += 0.005364437472280503;
      } else {
        result[0] += -0.00040233349878957426;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -0.0004260688459903854;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -0.0004260688459903854;
                  } else {
                    result[0] += -0.0004260688459903854;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -0.0004260688459903854;
                    } else {
                      result[0] += -0.0004260688459903854;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -0.0004260688459903854;
                    } else {
                      result[0] += -0.0004260688459903854;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.00044806831724034845;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                result[0] += -0.0004260688459903854;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6406283774623117155) ) ) {
                  result[0] += -0.0004260688459903854;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.709112113944723732) ) ) {
                    result[0] += -0.0004260688459903854;
                  } else {
                    result[0] += -0.0004260688459903854;
                  }
                }
              }
            } else {
              result[0] += 0.0008521376919807709;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -0.0004260688459903854;
                    } else {
                      result[0] += -0.0004260688459903854;
                    }
                  } else {
                    result[0] += -0.0004260688459903854;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -0.0004260688459903854;
                  } else {
                    result[0] += -0.0004260688459903854;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -0.0004260688459903854;
                        } else {
                          result[0] += -0.0004260688459903854;
                        }
                      } else {
                        result[0] += -0.0004260688459903854;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -0.0004260688459903854;
                          } else {
                            result[0] += -0.0004260688459903854;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -0.0004260688459903854;
                            } else {
                              result[0] += -0.0004260688459903854;
                            }
                          } else {
                            result[0] += -0.0004260688459903854;
                          }
                        }
                      } else {
                        result[0] += -0.0004260688459903854;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -0.0004260688459903854;
                      } else {
                        result[0] += -0.0004260688459903854;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -0.0004260688459903854;
                      } else {
                        result[0] += -0.0004260688459903854;
                      }
                    }
                  }
                } else {
                  result[0] += -0.0004260688459903854;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -0.0004260688459903854;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -0.0004260688459903854;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -0.0004260688459903854;
                    } else {
                      result[0] += -0.0004260688459903854;
                    }
                  }
                } else {
                  result[0] += -0.0004260688459903854;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -0.0004260688459903854;
              } else {
                result[0] += 2.0967616971909083e-05;
              }
            } else {
              result[0] += -0.0004260688459903854;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5424744603768845153) ) ) {
              result[0] += 2.0967616971909083e-05;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.0004260688459903854;
              } else {
                result[0] += 0;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7472528898492464267) ) ) {
              result[0] += -0.0004260688459903854;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8066186623115578769) ) ) {
                result[0] += -0.0004260688459903854;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8715165423366836306) ) ) {
                  result[0] += 4.29670882218721e-05;
                } else {
                  result[0] += -0.0004260688459903854;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
            result[0] += 0;
          } else {
            result[0] += 0.001756110731783108;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.03500000000000001027) ) ) {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.111039020874343905) ) ) {
            result[0] += 0;
          } else {
            result[0] += -4.656911644696355e-05;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
            result[0] += 0.0004260688459903854;
          } else {
            result[0] += -4.656911644696355e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6461954822149375) ) ) {
          result[0] += 0.0008951047802026429;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.992027305872230758) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7568047583165830039) ) ) {
              result[0] += 0.000422466817765294;
            } else {
              result[0] += -4.422779260439522e-05;
            }
          } else {
            result[0] += 0.0004260688459903854;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.0650000000000000161) ) ) {
        result[0] += 0.00046688761258245067;
      } else {
        result[0] += 0.006906637748518247;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -0.00040608468562192075;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -0.00040608468562192075;
                  } else {
                    result[0] += -0.00040608468562192075;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -0.00040608468562192075;
                    } else {
                      result[0] += -0.00040608468562192075;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -0.00040608468562192075;
                    } else {
                      result[0] += -0.00040608468562192075;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.00042705230259382985;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6169593235427136557) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.071894537606111239) ) ) {
                  result[0] += -0.00040608468562192075;
                } else {
                  result[0] += 4.095177734037376e-05;
                }
              } else {
                result[0] += 0.001281205305456099;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6406283774623117155) ) ) {
                  result[0] += -0.00040608468562192075;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.709112113944723732) ) ) {
                    result[0] += -0.00040608468562192075;
                  } else {
                    result[0] += -0.00040608468562192075;
                  }
                }
              } else {
                result[0] += 0.00034313343703158396;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -0.00040608468562192075;
                    } else {
                      result[0] += -0.00040608468562192075;
                    }
                  } else {
                    result[0] += -0.00040608468562192075;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -0.00040608468562192075;
                  } else {
                    result[0] += -0.00040608468562192075;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -0.00040608468562192075;
                        } else {
                          result[0] += -0.00040608468562192075;
                        }
                      } else {
                        result[0] += -0.00040608468562192075;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -0.00040608468562192075;
                          } else {
                            result[0] += -0.00040608468562192075;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -0.00040608468562192075;
                            } else {
                              result[0] += -0.00040608468562192075;
                            }
                          } else {
                            result[0] += -0.00040608468562192075;
                          }
                        }
                      } else {
                        result[0] += -0.00040608468562192075;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -0.00040608468562192075;
                      } else {
                        result[0] += -0.00040608468562192075;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -0.00040608468562192075;
                      } else {
                        result[0] += -0.00040608468562192075;
                      }
                    }
                  }
                } else {
                  result[0] += -0.00040608468562192075;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -0.00040608468562192075;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -0.00040608468562192075;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -0.00040608468562192075;
                    } else {
                      result[0] += -0.00040608468562192075;
                    }
                  }
                } else {
                  result[0] += -0.00040608468562192075;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -0.00040608468562192075;
              } else {
                result[0] += 1.998416036846468e-05;
              }
            } else {
              result[0] += -0.00040608468562192075;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5424744603768845153) ) ) {
              result[0] += 1.998416036846468e-05;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.00040608468562192075;
              } else {
                result[0] += 0;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7472528898492464267) ) ) {
              result[0] += -0.00040608468562192075;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8066186623115578769) ) ) {
                result[0] += -0.00040608468562192075;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8715165423366836306) ) ) {
                  result[0] += 4.095177734037376e-05;
                } else {
                  result[0] += -0.00040608468562192075;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
            result[0] += 0;
          } else {
            result[0] += 0.0016737428261758358;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.05500000000000000722) ) ) {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002135500000000000679) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.03500000000000001027) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
            result[0] += 2.18425895263606e-06;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
              result[0] += -4.438485749432749e-05;
            } else {
              result[0] += 0.0012068382413721566;
            }
          }
        } else {
          result[0] += 0.00040056811052184576;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.555383890033505745) ) ) {
          result[0] += 0.0008531211485842153;
        } else {
          result[0] += -6.48657954653204e-05;
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.09500000000000001499) ) ) {
        result[0] += 0.0010365926374496116;
      } else {
        result[0] += 0.008072131912727733;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -0.00038703785420719403;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -0.00038703785420719403;
                  } else {
                    result[0] += -0.00038703785420719403;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -0.00038703785420719403;
                    } else {
                      result[0] += -0.00038703785420719403;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -0.00038703785420719403;
                    } else {
                      result[0] += -0.00038703785420719403;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.00040702201457565876;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6169593235427136557) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.00038703785420719403;
              } else {
                result[0] += 0.0012211121713766827;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6406283774623117155) ) ) {
                  result[0] += -0.00038703785420719403;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.709112113944723732) ) ) {
                    result[0] += -0.00038703785420719403;
                  } else {
                    result[0] += -0.00038703785420719403;
                  }
                }
              } else {
                result[0] += 0.0003270392454520936;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -0.00038703785420719403;
                    } else {
                      result[0] += -0.00038703785420719403;
                    }
                  } else {
                    result[0] += -0.00038703785420719403;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -0.00038703785420719403;
                  } else {
                    result[0] += -0.00038703785420719403;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -0.00038703785420719403;
                        } else {
                          result[0] += -0.00038703785420719403;
                        }
                      } else {
                        result[0] += -0.00038703785420719403;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -0.00038703785420719403;
                          } else {
                            result[0] += -0.00038703785420719403;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -0.00038703785420719403;
                            } else {
                              result[0] += -0.00038703785420719403;
                            }
                          } else {
                            result[0] += -0.00038703785420719403;
                          }
                        }
                      } else {
                        result[0] += -0.00038703785420719403;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -0.00038703785420719403;
                      } else {
                        result[0] += -0.00038703785420719403;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -0.00038703785420719403;
                      } else {
                        result[0] += -0.00038703785420719403;
                      }
                    }
                  }
                } else {
                  result[0] += -0.00038703785420719403;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -0.00038703785420719403;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -0.00038703785420719403;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -0.00038703785420719403;
                    } else {
                      result[0] += -0.00038703785420719403;
                    }
                  }
                } else {
                  result[0] += -0.00038703785420719403;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -0.00038703785420719403;
              } else {
                result[0] += 1.9046831414726735e-05;
              }
            } else {
              result[0] += -0.00038703785420719403;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5424744603768845153) ) ) {
              result[0] += 1.9046831414726735e-05;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.00038703785420719403;
              } else {
                result[0] += 0;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7472528898492464267) ) ) {
              result[0] += -0.00038703785420719403;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8066186623115578769) ) ) {
                result[0] += -0.00038703785420719403;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8715165423366836306) ) ) {
                  result[0] += 3.903099178319142e-05;
                } else {
                  result[0] += -0.00038703785420719403;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
            result[0] += 0;
          } else {
            result[0] += 0.0015952382714104778;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006264500000000000103) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7392963230402010977) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001851500000000000064) ) ) {
            result[0] += -1.024495961310353e-07;
          } else {
            result[0] += 0.000809504671972488;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002740500000000000314) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8299222285691966183) ) ) {
              result[0] += -8.324687061050821e-05;
            } else {
              result[0] += -4.230304813782247e-05;
            }
          } else {
            result[0] += -0.00010525987717169872;
          }
        }
      } else {
        result[0] += 0.0008131067001975796;
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05500000000000000722) ) ) {
        result[0] += 0.0006579806357098906;
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.717118227269369246) ) ) {
          result[0] += 0.007693519910988011;
        } else {
          result[0] += -0.0006149861227274212;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -0.00036888438764907456;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -0.00036888438764907456;
                  } else {
                    result[0] += -0.00036888438764907456;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -0.00036888438764907456;
                    } else {
                      result[0] += -0.00036888438764907456;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -0.00036888438764907456;
                    } else {
                      result[0] += -0.00036888438764907456;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.00038793121906380133;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6169593235427136557) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.00036888438764907456;
              } else {
                result[0] += 0.0011638376212885345;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6406283774623117155) ) ) {
                  result[0] += -0.00036888438764907456;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.709112113944723732) ) ) {
                    result[0] += -0.00036888438764907456;
                  } else {
                    result[0] += -0.00036888438764907456;
                  }
                }
              } else {
                result[0] += 0.0003116999293077637;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -0.00036888438764907456;
                    } else {
                      result[0] += -0.00036888438764907456;
                    }
                  } else {
                    result[0] += -0.00036888438764907456;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -0.00036888438764907456;
                  } else {
                    result[0] += -0.00036888438764907456;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -0.00036888438764907456;
                        } else {
                          result[0] += -0.00036888438764907456;
                        }
                      } else {
                        result[0] += -0.00036888438764907456;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -0.00036888438764907456;
                          } else {
                            result[0] += -0.00036888438764907456;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -0.00036888438764907456;
                            } else {
                              result[0] += -0.00036888438764907456;
                            }
                          } else {
                            result[0] += -0.00036888438764907456;
                          }
                        }
                      } else {
                        result[0] += -0.00036888438764907456;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -0.00036888438764907456;
                      } else {
                        result[0] += -0.00036888438764907456;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -0.00036888438764907456;
                      } else {
                        result[0] += -0.00036888438764907456;
                      }
                    }
                  }
                } else {
                  result[0] += -0.00036888438764907456;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -0.00036888438764907456;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -0.00036888438764907456;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -0.00036888438764907456;
                    } else {
                      result[0] += -0.00036888438764907456;
                    }
                  }
                } else {
                  result[0] += -0.00036888438764907456;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -0.00036888438764907456;
              } else {
                result[0] += 1.815346655811949e-05;
              }
            } else {
              result[0] += -0.00036888438764907456;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5424744603768845153) ) ) {
              result[0] += 1.815346655811949e-05;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.00036888438764907456;
              } else {
                result[0] += 0;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7472528898492464267) ) ) {
              result[0] += -0.00036888438764907456;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8066186623115578769) ) ) {
                result[0] += -0.00036888438764907456;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8715165423366836306) ) ) {
                  result[0] += 3.720029797284623e-05;
                } else {
                  result[0] += -0.00036888438764907456;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
            result[0] += 0;
          } else {
            result[0] += 0.0015204158624458506;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006264500000000000103) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7392963230402010977) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001851500000000000064) ) ) {
            result[0] += -9.764434182052075e-08;
          } else {
            result[0] += 0.0007715359931170417;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002740500000000000314) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8299222285691966183) ) ) {
              result[0] += -7.934229315052946e-05;
            } else {
              result[0] += -4.031888312313788e-05;
            }
          } else {
            result[0] += -0.00010032281057891719;
          }
        }
      } else {
        result[0] += 0.0007749690732709954;
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1250000000000000278) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0006325000000000001411) ) ) {
          result[0] += 0.00048807503826930063;
        } else {
          result[0] += 0.001427939639633648;
        }
      } else {
        result[0] += 0.008739774063040742;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -0.0003515823839246146;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -0.0003515823839246146;
                  } else {
                    result[0] += -0.0003515823839246146;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -0.0003515823839246146;
                    } else {
                      result[0] += -0.0003515823839246146;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -0.0003515823839246146;
                    } else {
                      result[0] += -0.0003515823839246146;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.0003697358504827342;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6169593235427136557) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.0003515823839246146;
              } else {
                result[0] += 0.00110924945347115;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6406283774623117155) ) ) {
                  result[0] += -0.0003515823839246146;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.709112113944723732) ) ) {
                    result[0] += -0.0003515823839246146;
                  } else {
                    result[0] += -0.0003515823839246146;
                  }
                }
              } else {
                result[0] += 0.00029708008222730853;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -0.0003515823839246146;
                    } else {
                      result[0] += -0.0003515823839246146;
                    }
                  } else {
                    result[0] += -0.0003515823839246146;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -0.0003515823839246146;
                  } else {
                    result[0] += -0.0003515823839246146;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -0.0003515823839246146;
                        } else {
                          result[0] += -0.0003515823839246146;
                        }
                      } else {
                        result[0] += -0.0003515823839246146;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -0.0003515823839246146;
                          } else {
                            result[0] += -0.0003515823839246146;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -0.0003515823839246146;
                            } else {
                              result[0] += -0.0003515823839246146;
                            }
                          } else {
                            result[0] += -0.0003515823839246146;
                          }
                        }
                      } else {
                        result[0] += -0.0003515823839246146;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -0.0003515823839246146;
                      } else {
                        result[0] += -0.0003515823839246146;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -0.0003515823839246146;
                      } else {
                        result[0] += -0.0003515823839246146;
                      }
                    }
                  }
                } else {
                  result[0] += -0.0003515823839246146;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -0.0003515823839246146;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -0.0003515823839246146;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -0.0003515823839246146;
                    } else {
                      result[0] += -0.0003515823839246146;
                    }
                  }
                } else {
                  result[0] += -0.0003515823839246146;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -0.0003515823839246146;
              } else {
                result[0] += 1.7302003724459927e-05;
              }
            } else {
              result[0] += -0.0003515823839246146;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5424744603768845153) ) ) {
              result[0] += 1.7302003724459927e-05;
            } else {
              result[0] += -0.0003515823839246146;
            }
          } else {
            result[0] += -0.0003515823839246146;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
            result[0] += 0;
          } else {
            result[0] += 0.0014491028934085388;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04500000000000000527) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7273815826884423297) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002135500000000000679) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
            result[0] += 0.00033769629431719145;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.03500000000000001027) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2770180392662731639) ) ) {
                result[0] += -0.0005113295972251586;
              } else {
                result[0] += 0.0001767178176126456;
              }
            } else {
              result[0] += 0.0003280258957365668;
            }
          }
        } else {
          result[0] += 0.000758705162506788;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.166246961251310221) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.114862829452247572) ) ) {
            result[0] += -4.2293663012901034e-05;
          } else {
            result[0] += -0.0005226819449579493;
          }
        } else {
          result[0] += 0.0002935667797025633;
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.09500000000000001499) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.03500000000000001027) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6406283774623117155) ) ) {
              result[0] += 0.0004267422711993565;
            } else {
              result[0] += -4.2293663012901034e-05;
            }
          } else {
            result[0] += 0.0004651825646035814;
          }
        } else {
          result[0] += 0.0028995653792619116;
        }
      } else {
        result[0] += 0.00786081104832541;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -0.0003350919063663583;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -0.0003350919063663583;
                  } else {
                    result[0] += -0.0003350919063663583;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -0.0003350919063663583;
                    } else {
                      result[0] += -0.0003350919063663583;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -0.0003350919063663583;
                    } else {
                      result[0] += -0.0003350919063663583;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.00035239391009081835;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6169593235427136557) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.0003350919063663583;
              } else {
                result[0] += 0.0010572216669399107;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6406283774623117155) ) ) {
                  result[0] += -0.0003350919063663583;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.709112113944723732) ) ) {
                    result[0] += -0.0003350919063663583;
                  } else {
                    result[0] += -0.0003350919063663583;
                  }
                }
              } else {
                result[0] += 0.0002831459585255226;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -0.0003350919063663583;
                    } else {
                      result[0] += -0.0003350919063663583;
                    }
                  } else {
                    result[0] += -0.0003350919063663583;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -0.0003350919063663583;
                  } else {
                    result[0] += -0.0003350919063663583;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -0.0003350919063663583;
                        } else {
                          result[0] += -0.0003350919063663583;
                        }
                      } else {
                        result[0] += -0.0003350919063663583;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -0.0003350919063663583;
                          } else {
                            result[0] += -0.0003350919063663583;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -0.0003350919063663583;
                            } else {
                              result[0] += -0.0003350919063663583;
                            }
                          } else {
                            result[0] += -0.0003350919063663583;
                          }
                        }
                      } else {
                        result[0] += -0.0003350919063663583;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -0.0003350919063663583;
                      } else {
                        result[0] += -0.0003350919063663583;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -0.0003350919063663583;
                      } else {
                        result[0] += -0.0003350919063663583;
                      }
                    }
                  }
                } else {
                  result[0] += -0.0003350919063663583;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -0.0003350919063663583;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -0.0003350919063663583;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -0.0003350919063663583;
                    } else {
                      result[0] += -0.0003350919063663583;
                    }
                  }
                } else {
                  result[0] += -0.0003350919063663583;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -0.0003350919063663583;
              } else {
                result[0] += 1.6490477558256286e-05;
              }
            } else {
              result[0] += -0.0003350919063663583;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7568047583165830039) ) ) {
            result[0] += 0;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8066186623115578769) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7974125133417085953) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7664523331407036011) ) ) {
                  result[0] += -0.0003350919063663583;
                } else {
                  result[0] += -0.0003350919063663583;
                }
              } else {
                result[0] += -0.0003350919063663583;
              }
            } else {
              result[0] += -0.00010104647073760227;
            }
          }
        } else {
          result[0] += 0.00010041230327329729;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05500000000000000722) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.03500000000000001027) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
            result[0] += -3.644405776107178e-05;
          } else {
            result[0] += -2.6939819904398922e-05;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6461954822149375) ) ) {
            result[0] += 0.0007012346478146434;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.992027305872230758) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7568047583165830039) ) ) {
                result[0] += 3.8477835707935475e-05;
              } else {
                result[0] += -0.0001557511552496536;
              }
            } else {
              result[0] += 0.00032078152620647007;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6273136390703518694) ) ) {
          result[0] += 0.00101546147547148;
        } else {
          result[0] += 0.0003001777840714171;
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1850000000000000255) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.96280210579579717) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
            result[0] += 0.000456571654163966;
          } else {
            result[0] += 0.002801751237860501;
          }
        } else {
          result[0] += -0.0007981950093361949;
        }
      } else {
        result[0] += 0.010306326534715634;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -0.0003193748914801045;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -0.0003193748914801045;
                  } else {
                    result[0] += -0.0003193748914801045;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -0.0003193748914801045;
                    } else {
                      result[0] += -0.0003193748914801045;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -0.0003193748914801045;
                    } else {
                      result[0] += -0.0003193748914801045;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.00033586536903836093;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6169593235427136557) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.0003193748914801045;
              } else {
                result[0] += 0.0010076341706092837;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6406283774623117155) ) ) {
                  result[0] += -0.0003193748914801045;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.709112113944723732) ) ) {
                    result[0] += -0.0003193748914801045;
                  } else {
                    result[0] += -0.0003193748914801045;
                  }
                }
              } else {
                result[0] += 0.0002698653953111345;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -0.0003193748914801045;
                    } else {
                      result[0] += -0.0003193748914801045;
                    }
                  } else {
                    result[0] += -0.0003193748914801045;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -0.0003193748914801045;
                  } else {
                    result[0] += -0.0003193748914801045;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -0.0003193748914801045;
                        } else {
                          result[0] += -0.0003193748914801045;
                        }
                      } else {
                        result[0] += -0.0003193748914801045;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -0.0003193748914801045;
                          } else {
                            result[0] += -0.0003193748914801045;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -0.0003193748914801045;
                            } else {
                              result[0] += -0.0003193748914801045;
                            }
                          } else {
                            result[0] += -0.0003193748914801045;
                          }
                        }
                      } else {
                        result[0] += -0.0003193748914801045;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -0.0003193748914801045;
                      } else {
                        result[0] += -0.0003193748914801045;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -0.0003193748914801045;
                      } else {
                        result[0] += -0.0003193748914801045;
                      }
                    }
                  }
                } else {
                  result[0] += -0.0003193748914801045;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -0.0003193748914801045;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -0.0003193748914801045;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -0.0003193748914801045;
                    } else {
                      result[0] += -0.0003193748914801045;
                    }
                  }
                } else {
                  result[0] += -0.0003193748914801045;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -0.0003193748914801045;
              } else {
                result[0] += 1.5717014886253758e-05;
              }
            } else {
              result[0] += -0.0003193748914801045;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01314200000000000264) ) ) {
            result[0] += -0.0003303524636802972;
          } else {
            result[0] += 2.570705965797016e-05;
          }
        } else {
          result[0] += 1.6490477558256286e-05;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05500000000000000722) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.03500000000000001027) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.709112113944723732) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5508018452917812224) ) ) {
                result[0] += -2.5720511481308517e-05;
              } else {
                result[0] += -1.3366594795706871e-05;
              }
            } else {
              result[0] += -3.473470045501976e-05;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
              result[0] += 0.0003914160254960501;
            } else {
              result[0] += -4.777783158029465e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6461954822149375) ) ) {
            result[0] += 0.0006683442222655105;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.992027305872230758) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7568047583165830039) ) ) {
                result[0] += 3.667308690582247e-05;
              } else {
                result[0] += -0.0001484458662256517;
              }
            } else {
              result[0] += 0.00030573571958794155;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6273136390703518694) ) ) {
          result[0] += 0.000967832682226461;
        } else {
          result[0] += 0.0002860983670185473;
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1850000000000000255) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
          result[0] += 0.00043515680245074346;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
            result[0] += 0.0026738360991913042;
          } else {
            result[0] += -0.000635854320553451;
          }
        }
      } else {
        result[0] += 0.009822922774460025;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -0.0003043950610863483;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -0.0003043950610863483;
                  } else {
                    result[0] += -0.0003043950610863483;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -0.0003043950610863483;
                    } else {
                      result[0] += -0.0003043950610863483;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -0.0003043950610863483;
                    } else {
                      result[0] += -0.0003043950610863483;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.0003201120759726022;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6169593235427136557) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.0003043950610863483;
              } else {
                result[0] += 0.0009603725060973112;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6406283774623117155) ) ) {
                  result[0] += -0.0003043950610863483;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.709112113944723732) ) ) {
                    result[0] += -0.0003043950610863483;
                  } else {
                    result[0] += -0.0003043950610863483;
                  }
                }
              } else {
                result[0] += 0.00025720773824808204;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -0.0003043950610863483;
                    } else {
                      result[0] += -0.0003043950610863483;
                    }
                  } else {
                    result[0] += -0.0003043950610863483;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -0.0003043950610863483;
                  } else {
                    result[0] += -0.0003043950610863483;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -0.0003043950610863483;
                        } else {
                          result[0] += -0.0003043950610863483;
                        }
                      } else {
                        result[0] += -0.0003043950610863483;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -0.0003043950610863483;
                          } else {
                            result[0] += -0.0003043950610863483;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -0.0003043950610863483;
                            } else {
                              result[0] += -0.0003043950610863483;
                            }
                          } else {
                            result[0] += -0.0003043950610863483;
                          }
                        }
                      } else {
                        result[0] += -0.0003043950610863483;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -0.0003043950610863483;
                      } else {
                        result[0] += -0.0003043950610863483;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -0.0003043950610863483;
                      } else {
                        result[0] += -0.0003043950610863483;
                      }
                    }
                  }
                } else {
                  result[0] += -0.0003043950610863483;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -0.0003043950610863483;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -0.0003043950610863483;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -0.0003043950610863483;
                    } else {
                      result[0] += -0.0003043950610863483;
                    }
                  }
                } else {
                  result[0] += -0.0003043950610863483;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -0.0003043950610863483;
              } else {
                result[0] += 1.4979830393756197e-05;
              }
            } else {
              result[0] += -0.0003043950610863483;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -0.00031485774569180234;
          } else {
            result[0] += 1.1007316933764292e-05;
          }
        } else {
          result[0] += 3.749418923845782e-05;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08500000000000000611) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.03500000000000001027) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.714631904321608169) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5777799923753693667) ) ) {
                result[0] += -1.7360544923938546e-05;
              } else {
                result[0] += -1.5396011838643045e-05;
              }
            } else {
              result[0] += -3.310551815085445e-05;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
              result[0] += 0.0003730572069672797;
            } else {
              result[0] += -4.861182597761551e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6461954822149375) ) ) {
            result[0] += 0.0006387960669512199;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.786764172562814168) ) ) {
              result[0] += -9.829733369440152e-05;
            } else {
              result[0] += 0.0003180704574984437;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6208328749497488142) ) ) {
          result[0] += 0.0010772191137456456;
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003653500000000000497) ) ) {
            result[0] += 0.0002569262632299864;
          } else {
            result[0] += 0.0008488677620390241;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1650000000000000355) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.08500000000000000611) ) ) {
            result[0] += -7.273679078883006e-05;
          } else {
            result[0] += 0.0010051212973486055;
          }
        } else {
          result[0] += 0.0028325781154845534;
        }
      } else {
        result[0] += 0.011707372670755082;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -0.0002901178385826042;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -0.0002901178385826042;
                  } else {
                    result[0] += -0.0002901178385826042;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -0.0002901178385826042;
                    } else {
                      result[0] += -0.0002901178385826042;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -0.0002901178385826042;
                    } else {
                      result[0] += -0.0002901178385826042;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.0003050976689763606;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.709112113944723732) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5694467910050252657) ) ) {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.071894537606111239) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5072068278894473758) ) ) {
                      result[0] += 0.00015691862437969034;
                    } else {
                      result[0] += -0.0003121173098325672;
                    }
                  } else {
                    result[0] += 0.00044629164931930934;
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4364163272837385255) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6169593235427136557) ) ) {
                      result[0] += -0.0003110854555545133;
                    } else {
                      result[0] += -0.0002901178385826042;
                    }
                  } else {
                    result[0] += 0.00015795047865774426;
                  }
                }
              } else {
                result[0] += 0.003354313254672804;
              }
            } else {
              result[0] += -0.0002901178385826042;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -0.0002901178385826042;
                    } else {
                      result[0] += -0.0002901178385826042;
                    }
                  } else {
                    result[0] += -0.0002901178385826042;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -0.0002901178385826042;
                  } else {
                    result[0] += -0.0002901178385826042;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -0.0002901178385826042;
                        } else {
                          result[0] += -0.0002901178385826042;
                        }
                      } else {
                        result[0] += -0.0002901178385826042;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -0.0002901178385826042;
                          } else {
                            result[0] += -0.0002901178385826042;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -0.0002901178385826042;
                            } else {
                              result[0] += -0.0002901178385826042;
                            }
                          } else {
                            result[0] += -0.0002901178385826042;
                          }
                        }
                      } else {
                        result[0] += -0.0002901178385826042;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -0.0002901178385826042;
                      } else {
                        result[0] += -0.0002901178385826042;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -0.0002901178385826042;
                      } else {
                        result[0] += -0.0002901178385826042;
                      }
                    }
                  }
                } else {
                  result[0] += -0.0002901178385826042;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -0.0002901178385826042;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -0.0002901178385826042;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -0.0002901178385826042;
                    } else {
                      result[0] += -0.0002901178385826042;
                    }
                  }
                } else {
                  result[0] += -0.0002901178385826042;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -0.0002901178385826042;
              } else {
                result[0] += 1.4277222503744058e-05;
              }
            } else {
              result[0] += -0.0002901178385826042;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -0.0003000897856722607;
          } else {
            result[0] += 1.0491034204104618e-05;
          }
        } else {
          result[0] += 3.5735576991450674e-05;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08500000000000000611) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.03500000000000001027) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.714631904321608169) ) ) {
              result[0] += -1.7755230921927757e-05;
            } else {
              result[0] += -3.155275035280071e-05;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
              result[0] += 0.0003555594830177237;
            } else {
              result[0] += -4.633175660553448e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6461954822149375) ) ) {
            result[0] += 0.0006088342352781628;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.786764172562814168) ) ) {
              result[0] += -9.368683541735603e-05;
            } else {
              result[0] += 0.00030315180974717566;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003653500000000000497) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6208328749497488142) ) ) {
            result[0] += 0.0006950391304755759;
          } else {
            result[0] += 0.0002448754979708567;
          }
        } else {
          result[0] += 0.001247052156739341;
        }
      }
    } else {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1650000000000000355) ) ) {
          result[0] += 0.0003337404500217891;
        } else {
          result[0] += 0.0036536791643873327;
        }
      } else {
        result[0] += 0.009751146920699949;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -0.0002765102691333281;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -0.0002765102691333281;
                  } else {
                    result[0] += -0.0002765102691333281;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -0.0002765102691333281;
                    } else {
                      result[0] += -0.0002765102691333281;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -0.0002765102691333281;
                    } else {
                      result[0] += -0.0002765102691333281;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.00029078749163707223;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.709112113944723732) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5694467910050252657) ) ) {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.071894537606111239) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5072068278894473758) ) ) {
                      result[0] += 0.00014955857685705742;
                    } else {
                      result[0] += -0.0002974778861052371;
                    }
                  } else {
                    result[0] += 0.0004253589667844663;
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4364163272837385255) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6169593235427136557) ) ) {
                      result[0] += -0.00029649442950179276;
                    } else {
                      result[0] += -0.0002765102691333281;
                    }
                  } else {
                    result[0] += 0.0001505420334605018;
                  }
                }
              } else {
                result[0] += 0.003196983906051617;
              }
            } else {
              result[0] += -0.0002765102691333281;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -0.0002765102691333281;
                    } else {
                      result[0] += -0.0002765102691333281;
                    }
                  } else {
                    result[0] += -0.0002765102691333281;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -0.0002765102691333281;
                  } else {
                    result[0] += -0.0002765102691333281;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -0.0002765102691333281;
                        } else {
                          result[0] += -0.0002765102691333281;
                        }
                      } else {
                        result[0] += -0.0002765102691333281;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -0.0002765102691333281;
                          } else {
                            result[0] += -0.0002765102691333281;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -0.0002765102691333281;
                            } else {
                              result[0] += -0.0002765102691333281;
                            }
                          } else {
                            result[0] += -0.0002765102691333281;
                          }
                        }
                      } else {
                        result[0] += -0.0002765102691333281;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -0.0002765102691333281;
                      } else {
                        result[0] += -0.0002765102691333281;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -0.0002765102691333281;
                      } else {
                        result[0] += -0.0002765102691333281;
                      }
                    }
                  }
                } else {
                  result[0] += -0.0002765102691333281;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -0.0002765102691333281;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -0.0002765102691333281;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -0.0002765102691333281;
                    } else {
                      result[0] += -0.0002765102691333281;
                    }
                  }
                } else {
                  result[0] += -0.0002765102691333281;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -0.0002765102691333281;
              } else {
                result[0] += 1.3607569449276133e-05;
              }
            } else {
              result[0] += -0.0002765102691333281;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -0.00028601449606061903;
          } else {
            result[0] += 9.99896699022857e-06;
          }
        } else {
          result[0] += 3.405944998010637e-05;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1250000000000000278) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.03500000000000001027) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
            result[0] += -3.00728129458523e-05;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
              result[0] += 0.0003388824652164388;
            } else {
              result[0] += -4.423939804464876e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6461954822149375) ) ) {
            result[0] += 0.0005806076930779256;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.786764172562814168) ) ) {
              result[0] += -8.812515888339043e-05;
            } else {
              result[0] += 0.0002998542636901761;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003653500000000000497) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6551236496733668924) ) ) {
            result[0] += 0.0007031483668680388;
          } else {
            result[0] += 0.000242178589116149;
          }
        } else {
          result[0] += 0.0014555982455635187;
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1650000000000000355) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.064486481904431292) ) ) {
            result[0] += 0.0003519489558083798;
          } else {
            result[0] += -0.0006190611240986369;
          }
        } else {
          result[0] += 0.004768920703368407;
        }
      } else {
        result[0] += 0.009762818577306417;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -0.0002635409436032177;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -0.0002635409436032177;
                  } else {
                    result[0] += -0.0002635409436032177;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -0.0002635409436032177;
                    } else {
                      result[0] += -0.0002635409436032177;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -0.0002635409436032177;
                    } else {
                      result[0] += -0.0002635409436032177;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.000277148513052494;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6169593235427136557) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.071894537606111239) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
                    result[0] += 0.0001425437420187031;
                  } else {
                    result[0] += -0.00028352510397168236;
                  }
                } else {
                  result[0] += 9.50674603908703e-05;
                }
              } else {
                result[0] += 0.0007252082116740748;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6406283774623117155) ) ) {
                  result[0] += -0.0002635409436032177;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.709112113944723732) ) ) {
                    result[0] += -0.0002635409436032177;
                  } else {
                    result[0] += -0.0002635409436032177;
                  }
                }
              } else {
                result[0] += 0.00023067436311354706;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -0.0002635409436032177;
                    } else {
                      result[0] += -0.0002635409436032177;
                    }
                  } else {
                    result[0] += -0.0002635409436032177;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -0.0002635409436032177;
                  } else {
                    result[0] += -0.0002635409436032177;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -0.0002635409436032177;
                        } else {
                          result[0] += -0.0002635409436032177;
                        }
                      } else {
                        result[0] += -0.0002635409436032177;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -0.0002635409436032177;
                          } else {
                            result[0] += -0.0002635409436032177;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -0.0002635409436032177;
                            } else {
                              result[0] += -0.0002635409436032177;
                            }
                          } else {
                            result[0] += -0.0002635409436032177;
                          }
                        }
                      } else {
                        result[0] += -0.0002635409436032177;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -0.0002635409436032177;
                      } else {
                        result[0] += -0.0002635409436032177;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -0.0002635409436032177;
                      } else {
                        result[0] += -0.0002635409436032177;
                      }
                    }
                  }
                } else {
                  result[0] += -0.0002635409436032177;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -0.0002635409436032177;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -0.0002635409436032177;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -0.0002635409436032177;
                    } else {
                      result[0] += -0.0002635409436032177;
                    }
                  }
                } else {
                  result[0] += -0.0002635409436032177;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -0.0002635409436032177;
              } else {
                result[0] += 1.2969325530110313e-05;
              }
            } else {
              result[0] += -0.0002635409436032177;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7472528898492464267) ) ) {
              result[0] += -0.000277338830811025;
            } else {
              result[0] += -0.0002616218159247712;
            }
          } else {
            result[0] += 9.529979497403965e-06;
          }
        } else {
          result[0] += 3.246193935038173e-05;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1250000000000000278) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.03500000000000001027) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
            result[0] += -2.8662289922879836e-05;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
              result[0] += 0.0003229876594950677;
            } else {
              result[0] += -4.216441125918328e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6461954822149375) ) ) {
            result[0] += 0.0005533751052958669;
          } else {
            result[0] += 1.0923539583595667e-06;
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003653500000000000497) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6551236496733668924) ) ) {
            result[0] += 0.0006701681810164967;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003048500000000000428) ) ) {
              result[0] += 0.0002510546188669861;
            } else {
              result[0] += -0.00013629852618036407;
            }
          }
        } else {
          result[0] += 0.001387325455742942;
        }
      }
    } else {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1950000000000000344) ) ) {
          result[0] += 0.00030250307322864166;
        } else {
          result[0] += 0.003962468888803597;
        }
      } else {
        result[0] += 0.010242979686489163;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -0.00025117992605831594;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -0.00025117992605831594;
                  } else {
                    result[0] += -0.00025117992605831594;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -0.00025117992605831594;
                    } else {
                      result[0] += -0.00025117992605831594;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -0.00025117992605831594;
                    } else {
                      result[0] += -0.00025117992605831594;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.0002641492515884264;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.709112113944723732) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5694467910050252657) ) ) {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.071894537606111239) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5072068278894473758) ) ) {
                      result[0] += 0.0001358579281488782;
                    } else {
                      result[0] += -0.0002702267574730426;
                    }
                  } else {
                    result[0] += 0.0003713932304360118;
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4364163272837385255) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6169593235427136557) ) ) {
                      result[0] += -0.0002870467806273728;
                    } else {
                      result[0] += -0.00025117992605831594;
                    }
                  } else {
                    result[0] += 0.00015584208851734282;
                  }
                }
              } else {
                result[0] += 0.0030130189975299385;
              }
            } else {
              result[0] += -0.00025117992605831594;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -0.00025117992605831594;
                    } else {
                      result[0] += -0.00025117992605831594;
                    }
                  } else {
                    result[0] += -0.00025117992605831594;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -0.00025117992605831594;
                  } else {
                    result[0] += -0.00025117992605831594;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -0.00025117992605831594;
                        } else {
                          result[0] += -0.00025117992605831594;
                        }
                      } else {
                        result[0] += -0.00025117992605831594;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -0.00025117992605831594;
                          } else {
                            result[0] += -0.00025117992605831594;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -0.00025117992605831594;
                            } else {
                              result[0] += -0.00025117992605831594;
                            }
                          } else {
                            result[0] += -0.00025117992605831594;
                          }
                        }
                      } else {
                        result[0] += -0.00025117992605831594;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -0.00025117992605831594;
                      } else {
                        result[0] += -0.00025117992605831594;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -0.00025117992605831594;
                      } else {
                        result[0] += -0.00025117992605831594;
                      }
                    }
                  }
                } else {
                  result[0] += -0.00025117992605831594;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -0.00025117992605831594;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -0.00025117992605831594;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -0.00025117992605831594;
                    } else {
                      result[0] += -0.00025117992605831594;
                    }
                  }
                } else {
                  result[0] += -0.00025117992605831594;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -0.00025117992605831594;
              } else {
                result[0] += 1.2361017544901784e-05;
              }
            } else {
              result[0] += -0.00025117992605831594;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -0.00026032838456642736;
          } else {
            result[0] += 9.082989203754076e-06;
          }
        } else {
          result[0] += 3.09393577113946e-05;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1250000000000000278) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.03500000000000001027) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8440161800932387548) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5986941274482283637) ) ) {
                result[0] += -6.430290259147177e-06;
              } else {
                result[0] += -5.213133459214888e-05;
              }
            } else {
              result[0] += 1.3138699910533016e-06;
            }
          } else {
            result[0] += -4.32646785637903e-05;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6461954822149375) ) ) {
            result[0] += 0.0005274198237674958;
          } else {
            result[0] += 1.0411186312793699e-06;
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004655500000000000783) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2659201053550500626) ) ) {
            result[0] += 0.0006782706032821056;
          } else {
            result[0] += 0.00024335853811396137;
          }
        } else {
          result[0] += 0.0013427769073590607;
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3450000000000000289) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1950000000000000344) ) ) {
            result[0] += 0.00028831459175611694;
          } else {
            result[0] += 0.0023695069649432104;
          }
        } else {
          result[0] += 0.003875441381124778;
        }
      } else {
        result[0] += 0.012576761503280702;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -0.00023939868466757187;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -0.00023939868466757187;
                  } else {
                    result[0] += -0.00023939868466757187;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -0.00023939868466757187;
                    } else {
                      result[0] += -0.00023939868466757187;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -0.00023939868466757187;
                    } else {
                      result[0] += -0.00023939868466757187;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.00025175970221247377;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.709112113944723732) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5694467910050252657) ) ) {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.071894537606111239) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5072068278894473758) ) ) {
                      result[0] += 0.00012948570298150275;
                    } else {
                      result[0] += -0.00025755215122569134;
                    }
                  } else {
                    result[0] += 0.0003539735529668854;
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4364163272837385255) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6169593235427136557) ) ) {
                      result[0] += -0.0002735832548350215;
                    } else {
                      result[0] += -0.00023939868466757187;
                    }
                  } else {
                    result[0] += 0.00014853253439622944;
                  }
                }
              } else {
                result[0] += 0.002871697576340585;
              }
            } else {
              result[0] += -0.00023939868466757187;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -0.00023939868466757187;
                    } else {
                      result[0] += -0.00023939868466757187;
                    }
                  } else {
                    result[0] += -0.00023939868466757187;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -0.00023939868466757187;
                  } else {
                    result[0] += -0.00023939868466757187;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -0.00023939868466757187;
                        } else {
                          result[0] += -0.00023939868466757187;
                        }
                      } else {
                        result[0] += -0.00023939868466757187;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -0.00023939868466757187;
                          } else {
                            result[0] += -0.00023939868466757187;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -0.00023939868466757187;
                            } else {
                              result[0] += -0.00023939868466757187;
                            }
                          } else {
                            result[0] += -0.00023939868466757187;
                          }
                        }
                      } else {
                        result[0] += -0.00023939868466757187;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -0.00023939868466757187;
                      } else {
                        result[0] += -0.00023939868466757187;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -0.00023939868466757187;
                      } else {
                        result[0] += -0.00023939868466757187;
                      }
                    }
                  }
                } else {
                  result[0] += -0.00023939868466757187;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -0.00023939868466757187;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -0.00023939868466757187;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -0.00023939868466757187;
                    } else {
                      result[0] += -0.00023939868466757187;
                    }
                  }
                } else {
                  result[0] += -0.00023939868466757187;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -0.00023939868466757187;
              } else {
                result[0] += 1.1781241390744058e-05;
              }
            } else {
              result[0] += -0.00023939868466757187;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -0.0002481180475877969;
          } else {
            result[0] += 8.65696436156941e-06;
          }
        } else {
          result[0] += 2.9488190624149393e-05;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1450000000000000455) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.03500000000000001027) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8440161800932387548) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5986941274482283637) ) ) {
                result[0] += -6.12868653251033e-06;
              } else {
                result[0] += -4.9686187615279525e-05;
              }
            } else {
              result[0] += 1.2522447658071958e-06;
            }
          } else {
            result[0] += -4.1235409625576596e-05;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6461954822149375) ) ) {
            result[0] += 0.0005026819382382759;
          } else {
            result[0] += 9.922864252031282e-07;
          }
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
          result[0] += 0.0010837679272293927;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03500000000000001027) ) ) {
            result[0] += 6.0728663434878674e-05;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.96280210579579717) ) ) {
              result[0] += 0.0005508551268988311;
            } else {
              result[0] += -0.00038036468605440887;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1650000000000000355) ) ) {
          result[0] += 0.0001927900989603105;
        } else {
          result[0] += 0.0036557557299604615;
        }
      } else {
        result[0] += 0.010110722794599894;
      }
    }
  }
}

