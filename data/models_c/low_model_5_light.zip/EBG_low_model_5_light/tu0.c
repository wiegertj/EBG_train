
#include "header.h"

void predict_unit0(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0.009999999776482582;
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5814822343216081713) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0009293908214454501713) ) ) {
              result[0] += 0.009601953335125582;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01127328256994905228) ) ) {
                result[0] += 0.009999999776482582;
              } else {
                result[0] += 0.009999999776482582;
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
                  result[0] += 0.009601953335125582;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                    result[0] += 0.009601953335125582;
                  } else {
                    result[0] += 0.009601953335125582;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4455657651192640456) ) ) {
                  result[0] += 0.009601953335125582;
                } else {
                  result[0] += 0.009601953335125582;
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                result[0] += 0.009601953335125582;
              } else {
                result[0] += 0.009999999776482582;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.883880929790755059e-06) ) ) {
                    result[0] += 0.009601953335125582;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.063944343817919913) ) ) {
                      result[0] += 0.009601953335125582;
                    } else {
                      result[0] += 0.009601953335125582;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9127147582663316383) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8254037945979900703) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.234671350732867934) ) ) {
                          result[0] += 0.009601953335125582;
                        } else {
                          result[0] += 0.009601953335125582;
                        }
                      } else {
                        result[0] += 0.009601953335125582;
                      }
                    } else {
                      result[0] += 0.009601953335125582;
                    }
                  } else {
                    result[0] += 0.009601953335125582;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
                  result[0] += 0.009601953335125582;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.272781830548367354) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05185700000000000726) ) ) {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005972045269192751034) ) ) {
                        result[0] += 0.009601953335125582;
                      } else {
                        result[0] += 0.009601953335125582;
                      }
                    } else {
                      result[0] += 0.009601953335125582;
                    }
                  } else {
                    result[0] += 0.009601953335125582;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003024500000000000712) ) ) {
                result[0] += 0.009601953335125582;
              } else {
                result[0] += 0.009601953335125582;
              }
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.690815535104635854e-06) ) ) {
              result[0] += 0.009601953335125582;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
                result[0] += 0.009601953335125582;
              } else {
                result[0] += 0.009601953335125582;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7463838234422112139) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
              result[0] += 0.009601953335125582;
            } else {
              result[0] += 0.009999999776482582;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.038494786985569569e-06) ) ) {
              result[0] += 0.009601953335125582;
            } else {
              result[0] += 0.009601953335125582;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.224356303145077041) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7412676365326634764) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6577150591959800563) ) ) {
                result[0] += 0.010796092659196583;
              } else {
                result[0] += 0.010398046217839583;
              }
            } else {
              result[0] += 0.009999999776482582;
            }
          } else {
            result[0] += 0.009601953335125582;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6968016071608041928) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0004715000000000000766) ) ) {
            result[0] += 0.009999999776482582;
          } else {
            result[0] += 0.010796092659196583;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
            result[0] += 0.009999999776482582;
          } else {
            result[0] += 0.009999999776482582;
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.05500000000000000722) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004749500000000001117) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002055218118527550337) ) ) {
              result[0] += 0.010398046217839583;
            } else {
              result[0] += 0.009999999776482582;
            }
          } else {
            result[0] += 0.010398046217839583;
          }
        } else {
          result[0] += 0.011194139100553583;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
          result[0] += 0.010796092659196583;
        } else {
          result[0] += 0.015970696396837587;
        }
      } else {
        result[0] += 0.009999999776482582;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                  result[0] += -0.0003822023440551599;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                    result[0] += -0.0003822023440551599;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      result[0] += -0.0003822023440551599;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        result[0] += -0.0003822023440551599;
                      } else {
                        result[0] += -0.0003822023440551599;
                      }
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6100010069597990858) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.06355808660527756393) ) ) {
                    result[0] += -0.00026754047444962247;
                  } else {
                    result[0] += 0;
                  }
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005479696504671500816) ) ) {
                    result[0] += -0.0003822023440551599;
                  } else {
                    result[0] += -0.0003822023440551599;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
                result[0] += 1.584409730184036e-05;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7159035085929649211) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -0.0003822023440551599;
                  } else {
                    result[0] += -0.0003822023440551599;
                  }
                } else {
                  result[0] += 1.584409730184036e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -0.0003822023440551599;
                  } else {
                    result[0] += -0.0003822023440551599;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                    result[0] += -0.0003822023440551599;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      result[0] += -0.0003822023440551599;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                        result[0] += -0.0003822023440551599;
                      } else {
                        result[0] += -0.0003822023440551599;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.0003822023440551599;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.701692321267631473e-05) ) ) {
                result[0] += -0.0003822023440551599;
              } else {
                result[0] += -0.0003822023440551599;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6902865188442212085) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
              result[0] += 0;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
                result[0] += 0.00116245112946732;
              } else {
                result[0] += 0.0003663582467533195;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01332150000000000174) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9567162861906464144) ) ) {
                  result[0] += -0.0003822023440551599;
                } else {
                  result[0] += -0.0003822023440551599;
                }
              } else {
                result[0] += 0;
              }
            } else {
              result[0] += 0.00039804644135700025;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                result[0] += -0.0003822023440551599;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.858234205283420677e-05) ) ) {
                    result[0] += -0.0003822023440551599;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                      result[0] += -0.0003822023440551599;
                    } else {
                      result[0] += -0.0003822023440551599;
                    }
                  }
                } else {
                  result[0] += -0.0003822023440551599;
                }
              }
            } else {
              result[0] += -0.0003822023440551599;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
              result[0] += -0.0003822023440551599;
            } else {
              result[0] += -0.0003822023440551599;
            }
          }
        } else {
          result[0] += -0.0003822023440551599;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6968016071608041928) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0004715000000000000766) ) ) {
            result[0] += 0;
          } else {
            result[0] += 0.0007644046881103198;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
            result[0] += 0;
          } else {
            result[0] += 0;
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.05500000000000000722) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004749500000000001117) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002055218118527550337) ) ) {
              result[0] += 0.0003822023440551599;
            } else {
              result[0] += 0;
            }
          } else {
            result[0] += 0.0003822023440551599;
          }
        } else {
          result[0] += 0.0011466070321654795;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
          result[0] += 0.0007644046881103198;
        } else {
          result[0] += 0.005733035160827398;
        }
      } else {
        result[0] += 0;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                  result[0] += -0.00036698891542216727;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                    result[0] += -0.00036698891542216727;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      result[0] += -0.00036698891542216727;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        result[0] += -0.00036698891542216727;
                      } else {
                        result[0] += -0.00036698891542216727;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.00036698891542216727;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)5.045799003287211847e-06) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3212986210119083141) ) ) {
                  result[0] += 1.5213428632992626e-05;
                } else {
                  result[0] += -0.00036698891542216727;
                }
              } else {
                result[0] += -0.00036698891542216727;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6100010069597990858) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5494686760804020631) ) ) {
                  result[0] += 1.0649353615395154e-05;
                } else {
                  result[0] += -6.306109294066181e-08;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                  result[0] += -0.00036698891542216727;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7114754460552764614) ) ) {
                    result[0] += 3.105752593483299e-05;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8466324982590252013) ) ) {
                      result[0] += -0.00036698891542216727;
                    } else {
                      result[0] += -0.00036698891542216727;
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6161319161557790025) ) ) {
                result[0] += 0.0011161801748994942;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                  result[0] += 1.0460151090092795e-05;
                } else {
                  result[0] += 0.0015693656966204409;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -0.00036698891542216727;
                  } else {
                    result[0] += -0.00036698891542216727;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                    result[0] += -0.00036698891542216727;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      result[0] += -0.00036698891542216727;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                        result[0] += -0.00036698891542216727;
                      } else {
                        result[0] += -0.00036698891542216727;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.00036698891542216727;
              }
            } else {
              result[0] += -0.00036698891542216727;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.729199597233659459e-06) ) ) {
              result[0] += -0.00036698891542216727;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.00036698891542216727;
              } else {
                result[0] += 3.0296808075483673e-05;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                result[0] += -0.00036698891542216727;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.858234205283420677e-05) ) ) {
                    result[0] += -0.00036698891542216727;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                      result[0] += -0.00036698891542216727;
                    } else {
                      result[0] += -0.00036698891542216727;
                    }
                  }
                } else {
                  result[0] += -0.00036698891542216727;
                }
              }
            } else {
              result[0] += -0.00036698891542216727;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
              result[0] += -0.00036698891542216727;
            } else {
              result[0] += -0.00036698891542216727;
            }
          }
        } else {
          result[0] += -0.00036698891542216727;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.05500000000000000722) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6968016071608041928) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0004715000000000000766) ) ) {
              result[0] += 0;
            } else {
              result[0] += 0.0007339778308443345;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
              result[0] += 0;
            } else {
              result[0] += 0;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004749500000000001117) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002055218118527550337) ) ) {
              result[0] += 0.00036698891542216727;
            } else {
              result[0] += 0;
            }
          } else {
            result[0] += 0.00036698891542216727;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0009685000000000000683) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.002347679878538096e-06) ) ) {
            result[0] += -6.211505186966604e-05;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7412676365326634764) ) ) {
              result[0] += 0.0003359313894873342;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7789937396482412568) ) ) {
                result[0] += -6.211505186966604e-05;
              } else {
                result[0] += 0.0003359313894873342;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
            result[0] += 0.001530070787700264;
          } else {
            result[0] += 0.0003607779789154851;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.09500000000000001499) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5508018452917812224) ) ) {
          result[0] += 0.001126322950547435;
        } else {
          result[0] += 0.0007029203049095014;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
          result[0] += 0.007097019793328226;
        } else {
          result[0] += 0.001990232206785001;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                  result[0] += -0.00035238105191553017;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                    result[0] += -0.00035238105191553017;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      result[0] += -0.00035238105191553017;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        result[0] += -0.00035238105191553017;
                      } else {
                        result[0] += -0.00035238105191553017;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.00035238105191553017;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                  result[0] += -0.00035238105191553017;
                } else {
                  result[0] += -0.00035238105191553017;
                }
              } else {
                result[0] += 1.4607863506637075e-05;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6100010069597990858) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.07196201389915944657) ) ) {
                  result[0] += -0.00033488238807289727;
                } else {
                  result[0] += 1.0353388842121376e-05;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                  result[0] += -0.00035238105191553017;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7114754460552764614) ) ) {
                    result[0] += 2.9821292139629702e-05;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8466324982590252013) ) ) {
                      result[0] += -0.00035238105191553017;
                    } else {
                      result[0] += -0.00035238105191553017;
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6161319161557790025) ) ) {
                result[0] += 0.0010717510192532274;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                  result[0] += 1.0043788489039594e-05;
                } else {
                  result[0] += 0.0015068976521514198;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -0.00035238105191553017;
                  } else {
                    result[0] += -0.00035238105191553017;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                    result[0] += -0.00035238105191553017;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      result[0] += -0.00035238105191553017;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                        result[0] += -0.00035238105191553017;
                      } else {
                        result[0] += -0.00035238105191553017;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.00035238105191553017;
              }
            } else {
              result[0] += -0.00035238105191553017;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.729199597233659459e-06) ) ) {
              result[0] += -0.00035238105191553017;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.00035238105191553017;
              } else {
                result[0] += 2.909085438463626e-05;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                result[0] += -0.00035238105191553017;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.858234205283420677e-05) ) ) {
                    result[0] += -0.00035238105191553017;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                      result[0] += -0.00035238105191553017;
                    } else {
                      result[0] += -0.00035238105191553017;
                    }
                  }
                } else {
                  result[0] += -0.00035238105191553017;
                }
              }
            } else {
              result[0] += -0.00035238105191553017;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
              result[0] += -0.00035238105191553017;
            } else {
              result[0] += -0.00035238105191553017;
            }
          }
        } else {
          result[0] += -0.00035238105191553017;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.05500000000000000722) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6968016071608041928) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0004715000000000000766) ) ) {
              result[0] += 0;
            } else {
              result[0] += 0.0007047621038310603;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
              result[0] += 0;
            } else {
              result[0] += 0;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004749500000000001117) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002055218118527550337) ) ) {
              result[0] += 0.00035238105191553017;
            } else {
              result[0] += 0;
            }
          } else {
            result[0] += 0.00035238105191553017;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0009685000000000000683) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.002347679878538096e-06) ) ) {
            result[0] += -5.964258427925947e-05;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7412676365326634764) ) ) {
              result[0] += 0.0003225597597759004;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7789937396482412568) ) ) {
                result[0] += -5.964258427925947e-05;
              } else {
                result[0] += 0.0003225597597759004;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
            result[0] += 0.0014691668631321157;
          } else {
            result[0] += 0.00034641733953177185;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.09500000000000001499) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5508018452917812224) ) ) {
          result[0] += 0.0010814900653169294;
        } else {
          result[0] += 0.0006749408116914306;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
          result[0] += 0.006814525439716535;
        } else {
          result[0] += 0.0019110117202757995;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                  result[0] += -0.00033835464923035434;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                    result[0] += -0.00033835464923035434;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      result[0] += -0.00033835464923035434;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        result[0] += -0.00033835464923035434;
                      } else {
                        result[0] += -0.00033835464923035434;
                      }
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                  result[0] += -0.00033835464923035434;
                } else {
                  result[0] += -0.00033835464923035434;
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6100010069597990858) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5494686760804020631) ) ) {
                  result[0] += 1.437742192491122e-05;
                } else {
                  result[0] += -4.72663936191821e-07;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                  result[0] += -0.00033835464923035434;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7114754460552764614) ) ) {
                    result[0] += 2.8634266191812903e-05;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8466324982590252013) ) ) {
                      result[0] += -0.00033835464923035434;
                    } else {
                      result[0] += -0.00033835464923035434;
                    }
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -0.00033835464923035434;
                  } else {
                    result[0] += -0.00033835464923035434;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                    result[0] += -0.00033835464923035434;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      result[0] += -0.00033835464923035434;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                        result[0] += -0.00033835464923035434;
                      } else {
                        result[0] += -0.00033835464923035434;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.00033835464923035434;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.701692321267631473e-05) ) ) {
                result[0] += -0.00033835464923035434;
              } else {
                result[0] += -0.00033835464923035434;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6902865188442212085) ) ) {
              result[0] += 1.4026402685175827e-05;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                result[0] += -0.00033835464923035434;
              } else {
                result[0] += -0.00033835464923035434;
              }
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01231177969451185093) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6161319161557790025) ) ) {
                  result[0] += 0.0006310439090192385;
                } else {
                  result[0] += -1.6760917348414226e-06;
                }
              } else {
                result[0] += 0.00023299746766223834;
              }
            } else {
              result[0] += 0.0014801642432554166;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                result[0] += -0.00033835464923035434;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.858234205283420677e-05) ) ) {
                    result[0] += -0.00033835464923035434;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                      result[0] += -0.00033835464923035434;
                    } else {
                      result[0] += -0.00033835464923035434;
                    }
                  }
                } else {
                  result[0] += -0.00033835464923035434;
                }
              }
            } else {
              result[0] += -0.00033835464923035434;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
              result[0] += -0.00033835464923035434;
            } else {
              result[0] += -0.00033835464923035434;
            }
          }
        } else {
          result[0] += -0.00033835464923035434;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6968016071608041928) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0004715000000000000766) ) ) {
            result[0] += 0;
          } else {
            result[0] += 0.0006767092984607086;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
            result[0] += 0;
          } else {
            result[0] += 0;
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.05500000000000000722) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004749500000000001117) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002055218118527550337) ) ) {
              result[0] += 0.00033835464923035434;
            } else {
              result[0] += 0;
            }
          } else {
            result[0] += 0.00033835464923035434;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7342470301758795559) ) ) {
            result[0] += 0.0010130855328875559;
          } else {
            result[0] += 0.0002500285909118955;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1250000000000000278) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0009685000000000000683) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8327395279648243109) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03500000000000001027) ) ) {
              result[0] += 0.00026382294833400256;
            } else {
              result[0] += 0.0007077668243955416;
            }
          } else {
            result[0] += -7.74557346811725e-05;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.363906689523952442) ) ) {
            result[0] += 0.001801214761945617;
          } else {
            result[0] += 0.0003361173892392446;
          }
        }
      } else {
        result[0] += 0.007737415071784969;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                  result[0] += -0.0003248865625250453;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                    result[0] += -0.0003248865625250453;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      result[0] += -0.0003248865625250453;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        result[0] += -0.0003248865625250453;
                      } else {
                        result[0] += -0.0003248865625250453;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.0003248865625250453;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6881801856532664408) ) ) {
                  result[0] += 1.4098755374156792e-05;
                } else {
                  result[0] += -0.0003248865625250453;
                }
              } else {
                result[0] += -0.0003248865625250453;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6100010069597990858) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5494686760804020631) ) ) {
                  result[0] += 1.3805133748809683e-05;
                } else {
                  result[0] += -4.5384971599538434e-07;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                  result[0] += -0.0003248865625250453;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7114754460552764614) ) ) {
                    result[0] += 2.7494489390484885e-05;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8466324982590252013) ) ) {
                      result[0] += -0.0003248865625250453;
                    } else {
                      result[0] += -0.0003248865625250453;
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6161319161557790025) ) ) {
                result[0] += 0.0010039718715822853;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                  result[0] += 3.1719753867724345e-06;
                } else {
                  result[0] += 0.0013879987137358427;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -0.0003248865625250453;
                  } else {
                    result[0] += -0.0003248865625250453;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                    result[0] += -0.0003248865625250453;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      result[0] += -0.0003248865625250453;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                        result[0] += -0.0003248865625250453;
                      } else {
                        result[0] += -0.0003248865625250453;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.0003248865625250453;
              }
            } else {
              result[0] += -0.0003248865625250453;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8022705390703518402) ) ) {
                result[0] += -0.0003248865625250453;
              } else {
                result[0] += -0.0003248865625250453;
              }
            } else {
              result[0] += 3.57514231776584e-06;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                result[0] += -0.0003248865625250453;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.858234205283420677e-05) ) ) {
                    result[0] += -0.0003248865625250453;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                      result[0] += -0.0003248865625250453;
                    } else {
                      result[0] += -0.0003248865625250453;
                    }
                  }
                } else {
                  result[0] += -0.0003248865625250453;
                }
              }
            } else {
              result[0] += -0.0003248865625250453;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
              result[0] += -0.0003248865625250453;
            } else {
              result[0] += -0.0003248865625250453;
            }
          }
        } else {
          result[0] += -0.0003248865625250453;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03500000000000001027) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0009685000000000000683) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6968016071608041928) ) ) {
            result[0] += 0;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += 0;
            } else {
              result[0] += 0;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8697742174477757215) ) ) {
            result[0] += 0.000542897526592366;
          } else {
            result[0] += 0;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.576152860085799078e-06) ) ) {
          result[0] += -7.262084917016935e-05;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6732382808793971884) ) ) {
            result[0] += 0.0007229330038820454;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6968016071608041928) ) ) {
              result[0] += -7.315987883195494e-05;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
                result[0] += 0.0003614665019410227;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7890731911809046872) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.762281072713567931) ) ) {
                    result[0] += 0.0002888851797016526;
                  } else {
                    result[0] += -7.315987883195494e-05;
                  }
                } else {
                  result[0] += 0.0003182410152193124;
                }
              }
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2150000000000000244) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.835029170797551251e-06) ) ) {
              result[0] += 0.0010433052707010078;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.125515493975159704e-06) ) ) {
                result[0] += 0.0006452587552020786;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                  result[0] += 0.0010606866531586438;
                } else {
                  result[0] += 0.0006276403661962767;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04500000000000000527) ) ) {
              result[0] += 0.0012866535488387032;
            } else {
              result[0] += 0.0030167088586461836;
            }
          }
        } else {
          result[0] += 0.010613801542294366;
        }
      } else {
        result[0] += -4.152869197995345e-05;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                  result[0] += -0.0003119545682302124;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                    result[0] += -0.0003119545682302124;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      result[0] += -0.0003119545682302124;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        result[0] += -0.0003119545682302124;
                      } else {
                        result[0] += -0.0003119545682302124;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.0003119545682302124;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6881801856532664408) ) ) {
                  result[0] += 1.353755942118851e-05;
                } else {
                  result[0] += -0.0003119545682302124;
                }
              } else {
                result[0] += -0.0003119545682302124;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6100010069597990858) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5494686760804020631) ) ) {
                  result[0] += 1.3255625300410115e-05;
                } else {
                  result[0] += -4.3578438915533524e-07;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                  result[0] += -0.0003119545682302124;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7114754460552764614) ) ) {
                    result[0] += 2.640008100014195e-05;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8466324982590252013) ) ) {
                      result[0] += -0.0003119545682302124;
                    } else {
                      result[0] += -0.0003119545682302124;
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6161319161557790025) ) ) {
                result[0] += 0.0009640091276184627;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                  result[0] += 3.0457160324726266e-06;
                } else {
                  result[0] += 0.0013327499176398713;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -0.0003119545682302124;
                  } else {
                    result[0] += -0.0003119545682302124;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                    result[0] += -0.0003119545682302124;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      result[0] += -0.0003119545682302124;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                        result[0] += -0.0003119545682302124;
                      } else {
                        result[0] += -0.0003119545682302124;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.0003119545682302124;
              }
            } else {
              result[0] += -0.0003119545682302124;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8022705390703518402) ) ) {
                result[0] += -0.0003119545682302124;
              } else {
                result[0] += -0.0003119545682302124;
              }
            } else {
              result[0] += 3.4328350468918806e-06;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                result[0] += -0.0003119545682302124;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.858234205283420677e-05) ) ) {
                    result[0] += -0.0003119545682302124;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                      result[0] += -0.0003119545682302124;
                    } else {
                      result[0] += -0.0003119545682302124;
                    }
                  }
                } else {
                  result[0] += -0.0003119545682302124;
                }
              }
            } else {
              result[0] += -0.0003119545682302124;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
              result[0] += -0.0003119545682302124;
            } else {
              result[0] += -0.0003119545682302124;
            }
          }
        } else {
          result[0] += -0.0003119545682302124;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03500000000000001027) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0009685000000000000683) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6968016071608041928) ) ) {
            result[0] += 0;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += 0;
            } else {
              result[0] += 0;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8697742174477757215) ) ) {
            result[0] += 0.0005212876832611875;
          } else {
            result[0] += 0;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.576152860085799078e-06) ) ) {
          result[0] += -6.973020204750744e-05;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6732382808793971884) ) ) {
            result[0] += 0.0006941569122853724;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6968016071608041928) ) ) {
              result[0] += -7.024777582494748e-05;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
                result[0] += 0.0003470784561426862;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7890731911809046872) ) ) {
                  result[0] += -7.175385645019598e-06;
                } else {
                  result[0] += 0.0003055735445759837;
                }
              }
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1850000000000000255) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.584873521522560625e-06) ) ) {
              result[0] += 0.0009687409340092819;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.125515493975159704e-06) ) ) {
                result[0] += 0.000356597240934814;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                  result[0] += 0.001001085014988845;
                } else {
                  result[0] += 0.00028762249978749613;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04500000000000000527) ) ) {
              result[0] += 0.0011218712998168634;
            } else {
              result[0] += 0.0028108120200077795;
            }
          }
        } else {
          result[0] += 0.009299583118818035;
        }
      } else {
        result[0] += -3.987565713732211e-05;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                  result[0] += -0.0002995373273777559;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                    result[0] += -0.0002995373273777559;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      result[0] += -0.0002995373273777559;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        result[0] += -0.0002995373273777559;
                      } else {
                        result[0] += -0.0002995373273777559;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.0002995373273777559;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6881801856532664408) ) ) {
                  result[0] += 1.2998701673917774e-05;
                } else {
                  result[0] += -0.0002995373273777559;
                }
              } else {
                result[0] += -0.0002995373273777559;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6100010069597990858) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5494686760804020631) ) ) {
                  result[0] += 1.2727989840737518e-05;
                } else {
                  result[0] += -4.1843814623736545e-07;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                  result[0] += -0.0002995373273777559;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7114754460552764614) ) ) {
                    result[0] += 2.5349235147289418e-05;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8466324982590252013) ) ) {
                      result[0] += -0.0002995373273777559;
                    } else {
                      result[0] += -0.0002995373273777559;
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6161319161557790025) ) ) {
                result[0] += 0.0009256370864923612;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                  result[0] += 2.9244823869518583e-06;
                } else {
                  result[0] += 0.001279700280260581;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -0.0002995373273777559;
                  } else {
                    result[0] += -0.0002995373273777559;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                    result[0] += -0.0002995373273777559;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      result[0] += -0.0002995373273777559;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                        result[0] += -0.0002995373273777559;
                      } else {
                        result[0] += -0.0002995373273777559;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.0002995373273777559;
              }
            } else {
              result[0] += -0.0002995373273777559;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8022705390703518402) ) ) {
                result[0] += -0.0002995373273777559;
              } else {
                result[0] += -0.0002995373273777559;
              }
            } else {
              result[0] += 3.296192266419576e-06;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                result[0] += -0.0002995373273777559;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.858234205283420677e-05) ) ) {
                    result[0] += -0.0002995373273777559;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                      result[0] += -0.0002995373273777559;
                    } else {
                      result[0] += -0.0002995373273777559;
                    }
                  }
                } else {
                  result[0] += -0.0002995373273777559;
                }
              }
            } else {
              result[0] += -0.0002995373273777559;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
              result[0] += -0.0002995373273777559;
            } else {
              result[0] += -0.0002995373273777559;
            }
          }
        } else {
          result[0] += -0.0002995373273777559;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03500000000000001027) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0009685000000000000683) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6968016071608041928) ) ) {
            result[0] += 0;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += 0;
            } else {
              result[0] += 0;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8697742174477757215) ) ) {
            result[0] += 0.0005005380120728612;
          } else {
            result[0] += 0;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.576152860085799078e-06) ) ) {
          result[0] += -6.695461610745676e-05;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6732382808793971884) ) ) {
            result[0] += 0.0006665262427999231;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6968016071608041928) ) ) {
              result[0] += -6.745158804441138e-05;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
                result[0] += 0.0003332631213999616;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7890731911809046872) ) ) {
                  result[0] += -6.8897719664992326e-06;
                } else {
                  result[0] += 0.0002934102981049825;
                }
              }
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1250000000000000278) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7342470301758795559) ) ) {
            result[0] += 0.001458628450982493;
          } else {
            result[0] += 0.0006922199116131756;
          }
        } else {
          result[0] += 0.009025063007038904;
        }
      } else {
        result[0] += -3.828842075981632e-05;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                  result[0] += -0.00028761435038962633;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                    result[0] += -0.00028761435038962633;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      result[0] += -0.00028761435038962633;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        result[0] += -0.00028761435038962633;
                      } else {
                        result[0] += -0.00028761435038962633;
                      }
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                  result[0] += -0.00028761435038962633;
                } else {
                  result[0] += -0.00028761435038962633;
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6100010069597990858) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5494686760804020631) ) ) {
                  result[0] += 1.2221356723240015e-05;
                } else {
                  result[0] += -4.017823643613299e-07;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                  result[0] += -0.00028761435038962633;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7114754460552764614) ) ) {
                    result[0] += 2.434021784058608e-05;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8466324982590252013) ) ) {
                      result[0] += -0.00028761435038962633;
                    } else {
                      result[0] += -0.00028761435038962633;
                    }
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -0.00028761435038962633;
                  } else {
                    result[0] += -0.00028761435038962633;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                    result[0] += -0.00028761435038962633;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      result[0] += -0.00028761435038962633;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                        result[0] += -0.00028761435038962633;
                      } else {
                        result[0] += -0.00028761435038962633;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.00028761435038962633;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.701692321267631473e-05) ) ) {
                result[0] += -0.00028761435038962633;
              } else {
                result[0] += -0.00028761435038962633;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6902865188442212085) ) ) {
              result[0] += 1.2481292967996391e-05;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                result[0] += -0.00028761435038962633;
              } else {
                result[0] += -0.00028761435038962633;
              }
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01231177969451185093) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6161319161557790025) ) ) {
                  result[0] += 0.0004907459894851841;
                } else {
                  result[0] += -1.7440054519982274e-06;
                }
              } else {
                result[0] += 0.00010854364543002416;
              }
            } else {
              result[0] += 0.0016257643377605461;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                result[0] += -0.00028761435038962633;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.858234205283420677e-05) ) ) {
                    result[0] += -0.00028761435038962633;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                      result[0] += -0.00028761435038962633;
                    } else {
                      result[0] += -0.00028761435038962633;
                    }
                  }
                } else {
                  result[0] += -0.00028761435038962633;
                }
              }
            } else {
              result[0] += -0.00028761435038962633;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
              result[0] += -0.00028761435038962633;
            } else {
              result[0] += -0.00028761435038962633;
            }
          }
        } else {
          result[0] += -0.00028761435038962633;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04500000000000000527) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0009685000000000000683) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6968016071608041928) ) ) {
              result[0] += 0;
            } else {
              result[0] += 0;
            }
          } else {
            result[0] += 7.424625897047497e-05;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8697742174477757215) ) ) {
            result[0] += 0.00048061427418057996;
          } else {
            result[0] += 0;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.576152860085799078e-06) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.07500000000000002498) ) ) {
            result[0] += -6.455894396700084e-05;
          } else {
            result[0] += 0.0003698486650071979;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6732382808793971884) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1050000000000000239) ) ) {
              result[0] += 0.0006399954023051565;
            } else {
              result[0] += 0.0012167442211020309;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6959555468592965033) ) ) {
              result[0] += -6.476670152590385e-05;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7342470301758795559) ) ) {
                result[0] += 0.00046542831570491023;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7890731911809046872) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7536081807788946874) ) ) {
                    result[0] += 0.00028341776173660077;
                  } else {
                    result[0] += -6.968791721899464e-05;
                  }
                } else {
                  result[0] += 0.00028837675264784885;
                }
              }
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.115000000000000005) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7382388927638191545) ) ) {
              result[0] += 0.0005403569720583283;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09500000000000001499) ) ) {
                result[0] += 0.0005489413250235114;
              } else {
                result[0] += -0.00019251175527901622;
              }
            }
          } else {
            result[0] += 0.0026518008341818344;
          }
        } else {
          result[0] += 0.0074716841794988925;
        }
      } else {
        result[0] += -3.676436376288854e-05;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                  result[0] += -0.00027616596326815533;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                    result[0] += -0.00027616596326815533;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      result[0] += -0.00027616596326815533;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        result[0] += -0.00027616596326815533;
                      } else {
                        result[0] += -0.00027616596326815533;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.00027616596326815533;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                  result[0] += -0.00027616596326815533;
                } else {
                  result[0] += -0.00027616596326815533;
                }
              } else {
                result[0] += 1.1353810863099474e-05;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6100010069597990858) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5494686760804020631) ) ) {
                  result[0] += 1.1734889957142651e-05;
                } else {
                  result[0] += -3.8578955997045857e-07;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                  result[0] += -0.00027616596326815533;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7114754460552764614) ) ) {
                    result[0] += 2.3371364109600594e-05;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8466324982590252013) ) ) {
                      result[0] += -0.00027616596326815533;
                    } else {
                      result[0] += -0.00027616596326815533;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00326944116196775051) ) ) {
                result[0] += 0.0003507315695239632;
              } else {
                result[0] += 0.0005022695455109191;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -0.00027616596326815533;
                  } else {
                    result[0] += -0.00027616596326815533;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                    result[0] += -0.00027616596326815533;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      result[0] += -0.00027616596326815533;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                        result[0] += -0.00027616596326815533;
                      } else {
                        result[0] += -0.00027616596326815533;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.00027616596326815533;
              }
            } else {
              result[0] += -0.00027616596326815533;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.016289495364576286e-06) ) ) {
                result[0] += -0.00027616596326815533;
              } else {
                result[0] += -0.00027616596326815533;
              }
            } else {
              result[0] += 8.419811213897935e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                result[0] += -0.00027616596326815533;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.858234205283420677e-05) ) ) {
                    result[0] += -0.00027616596326815533;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                      result[0] += -0.00027616596326815533;
                    } else {
                      result[0] += -0.00027616596326815533;
                    }
                  }
                } else {
                  result[0] += -0.00027616596326815533;
                }
              }
            } else {
              result[0] += -0.00027616596326815533;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
              result[0] += -0.00027616596326815533;
            } else {
              result[0] += -0.00027616596326815533;
            }
          }
        } else {
          result[0] += -0.00027616596326815533;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0009685000000000000683) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6968016071608041928) ) ) {
              result[0] += 0;
            } else {
              result[0] += 0;
            }
          } else {
            result[0] += 9.503671851633096e-05;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8697742174477757215) ) ) {
            result[0] += 0.0005042331806688849;
          } else {
            result[0] += 0;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.576152860085799078e-06) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.16917529420057901e-06) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.0650000000000000161) ) ) {
              result[0] += -2.423011115790755e-05;
            } else {
              result[0] += 0.0006562497806256658;
            }
          } else {
            result[0] += -0.000123991001235875;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6518611175125629265) ) ) {
            result[0] += 0.0008325315765658304;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01798150000000000096) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.000210500000000000048) ) ) {
                result[0] += 0.00027689801837512274;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0009285000000000001802) ) ) {
                  result[0] += -0.00012731958991669693;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001886500000000000373) ) ) {
                    result[0] += 0.0001999709194386207;
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004657500000000001049) ) ) {
                      result[0] += -4.798854414992254e-05;
                    } else {
                      result[0] += 0.00033113242694546736;
                    }
                  }
                }
              }
            } else {
              result[0] += 0.0006641387140368385;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1450000000000000455) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002579500000000000629) ) ) {
            result[0] += 0.000942446769496004;
          } else {
            result[0] += 0.002463488461626584;
          }
        } else {
          result[0] += 0.009356362914394721;
        }
      } else {
        result[0] += -3.5300971313721997e-05;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                  result[0] += -0.00026517327513216787;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                    result[0] += -0.00026517327513216787;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      result[0] += -0.00026517327513216787;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        result[0] += -0.00026517327513216787;
                      } else {
                        result[0] += -0.00026517327513216787;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.00026517327513216787;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                  result[0] += -0.00026517327513216787;
                } else {
                  result[0] += -0.00026517327513216787;
                }
              } else {
                result[0] += 1.0901876452008239e-05;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6100010069597990858) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5494686760804020631) ) ) {
                  result[0] += 1.1267786827986443e-05;
                } else {
                  result[0] += -3.70433343481354e-07;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                  result[0] += -0.00026517327513216787;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7114754460552764614) ) ) {
                    result[0] += 2.244107525745847e-05;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8466324982590252013) ) ) {
                      result[0] += -0.00026517327513216787;
                    } else {
                      result[0] += -0.00026517327513216787;
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6161319161557790025) ) ) {
                result[0] += 0.0008492657999669537;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                  result[0] += -1.681100648648959e-05;
                } else {
                  result[0] += 0.0011485805680467702;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -0.00026517327513216787;
                  } else {
                    result[0] += -0.00026517327513216787;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                    result[0] += -0.00026517327513216787;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      result[0] += -0.00026517327513216787;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                        result[0] += -0.00026517327513216787;
                      } else {
                        result[0] += -0.00026517327513216787;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.00026517327513216787;
              }
            } else {
              result[0] += -0.00026517327513216787;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.729199597233659459e-06) ) ) {
              result[0] += -0.00026517327513216787;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.00027951743923365646;
              } else {
                result[0] += 2.4528491176658384e-05;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                result[0] += -0.00026517327513216787;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.858234205283420677e-05) ) ) {
                    result[0] += -0.00026517327513216787;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                      result[0] += -0.00026517327513216787;
                    } else {
                      result[0] += -0.00026517327513216787;
                    }
                  }
                } else {
                  result[0] += -0.00026517327513216787;
                }
              }
            } else {
              result[0] += -0.00026517327513216787;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
              result[0] += -0.00026517327513216787;
            } else {
              result[0] += -0.00026517327513216787;
            }
          }
        } else {
          result[0] += -0.00026517327513216787;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0009685000000000000683) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6968016071608041928) ) ) {
              result[0] += 0;
            } else {
              result[0] += 0;
            }
          } else {
            result[0] += 9.125381567140928e-05;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8697742174477757215) ) ) {
            result[0] += 0.0004841623579023299;
          } else {
            result[0] += 0;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.576152860085799078e-06) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.16917529420057901e-06) ) ) {
            result[0] += 0.00026186451506068003;
          } else {
            result[0] += -0.00011905558344533663;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6518611175125629265) ) ) {
            result[0] += 0.0007993929526881882;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01798150000000000096) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.000210500000000000048) ) ) {
                result[0] += 0.0002658761910454635;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0009285000000000001802) ) ) {
                  result[0] += -0.00012225167883528294;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001886500000000000373) ) ) {
                    result[0] += 0.00019201114797496295;
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004657500000000001049) ) ) {
                      result[0] += -4.607837718474901e-05;
                    } else {
                      result[0] += 0.00031795181823450274;
                    }
                  }
                }
              }
            } else {
              result[0] += 0.0006377029082769744;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3250000000000000666) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.891911223721401525) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8327395279648243109) ) ) {
              result[0] += 0.0011120618206099748;
            } else {
              result[0] += -0.00021134987290318298;
            }
          } else {
            result[0] += 0.0030302715110893095;
          }
        } else {
          result[0] += -3.3895828681527336e-05;
        }
      } else {
        result[0] += 0.01137221500628425;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                  result[0] += -0.00025461814704530835;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                    result[0] += -0.00025461814704530835;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      result[0] += -0.00025461814704530835;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        result[0] += -0.00025461814704530835;
                      } else {
                        result[0] += -0.00025461814704530835;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.00025461814704530835;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                  result[0] += -0.00025461814704530835;
                } else {
                  result[0] += -0.00025461814704530835;
                }
              } else {
                result[0] += 1.0467931129725225e-05;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6100010069597990858) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5494686760804020631) ) ) {
                  result[0] += 1.0819276573076506e-05;
                } else {
                  result[0] += -3.556883757384733e-07;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                  result[0] += -0.00025461814704530835;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7114754460552764614) ) ) {
                    result[0] += 2.1547816222846994e-05;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8466324982590252013) ) ) {
                      result[0] += -0.00025461814704530835;
                    } else {
                      result[0] += -0.00025461814704530835;
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6161319161557790025) ) ) {
                result[0] += 0.000815461076267054;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                  result[0] += -1.614185034077509e-05;
                } else {
                  result[0] += 0.0011028617262525925;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -0.00025461814704530835;
                  } else {
                    result[0] += -0.00025461814704530835;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                    result[0] += -0.00025461814704530835;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      result[0] += -0.00025461814704530835;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                        result[0] += -0.00025461814704530835;
                      } else {
                        result[0] += -0.00025461814704530835;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.00025461814704530835;
              }
            } else {
              result[0] += -0.00025461814704530835;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.729199597233659459e-06) ) ) {
              result[0] += -0.00025461814704530835;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.00026839134678655107;
              } else {
                result[0] += 2.355214329236279e-05;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                result[0] += -0.00025461814704530835;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.858234205283420677e-05) ) ) {
                    result[0] += -0.00025461814704530835;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                      result[0] += -0.00025461814704530835;
                    } else {
                      result[0] += -0.00025461814704530835;
                    }
                  }
                } else {
                  result[0] += -0.00025461814704530835;
                }
              }
            } else {
              result[0] += -0.00025461814704530835;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
              result[0] += -0.00025461814704530835;
            } else {
              result[0] += -0.00025461814704530835;
            }
          }
        } else {
          result[0] += -0.00025461814704530835;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0009685000000000000683) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6968016071608041928) ) ) {
              result[0] += 0;
            } else {
              result[0] += 0;
            }
          } else {
            result[0] += 8.762148993139528e-05;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8697742174477757215) ) ) {
            result[0] += 0.0004648904471113655;
          } else {
            result[0] += 0;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.576152860085799078e-06) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.16917529420057901e-06) ) ) {
            result[0] += 0.00025144109099394034;
          } else {
            result[0] += -0.00011431661820800271;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7342470301758795559) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002194500000000000704) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.000210500000000000048) ) ) {
                result[0] += 0.00040134301353485474;
              } else {
                result[0] += 0.00016679967404710578;
              }
            } else {
              result[0] += 0.001115482606890708;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8466324982590252013) ) ) {
              result[0] += -0.00012173086438643107;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                result[0] += 0.0002552930836401925;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005372500000000001406) ) ) {
                  result[0] += -4.424424373756346e-05;
                } else {
                  result[0] += 0.00047377714807084225;
                }
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3550000000000000377) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.891911223721401525) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8327395279648243109) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1450000000000000455) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6276844434422111929) ) ) {
                  result[0] += 0.0007688326547035595;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6635233717587941671) ) ) {
                    result[0] += -2.2502035096983207e-05;
                  } else {
                    result[0] += 0.000431787712133376;
                  }
                }
              } else {
                result[0] += 0.002172881258347917;
              }
            } else {
              result[0] += -0.0002020754640342618;
            }
          } else {
            result[0] += 0.0030409043270557172;
          }
        } else {
          result[0] += -3.254661725301728e-05;
        }
      } else {
        result[0] += 0.011715640166101254;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                  result[0] += -0.00024448316208514396;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                    result[0] += -0.00024448316208514396;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      result[0] += -0.00024448316208514396;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        result[0] += -0.00024448316208514396;
                      } else {
                        result[0] += -0.00024448316208514396;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.00024448316208514396;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                  result[0] += -0.00024448316208514396;
                } else {
                  result[0] += -0.00024448316208514396;
                }
              } else {
                result[0] += 1.0051258846956133e-05;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6100010069597990858) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5494686760804020631) ) ) {
                  result[0] += 1.038861910965357e-05;
                } else {
                  result[0] += -3.415303262025262e-07;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                  result[0] += -0.00024448316208514396;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7114754460552764614) ) ) {
                    result[0] += 2.0690113047023965e-05;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8466324982590252013) ) ) {
                      result[0] += -0.00024448316208514396;
                    } else {
                      result[0] += -0.00024448316208514396;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01085750000000000083) ) ) {
                  result[0] += -1.3090945119789766e-05;
                } else {
                  result[0] += 0.0003487463840697049;
                }
              } else {
                result[0] += 0.0015001168843696681;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -0.00024448316208514396;
                  } else {
                    result[0] += -0.00024448316208514396;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                    result[0] += -0.00024448316208514396;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      result[0] += -0.00024448316208514396;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                        result[0] += -0.00024448316208514396;
                      } else {
                        result[0] += -0.00024448316208514396;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.00024448316208514396;
              }
            } else {
              result[0] += -0.00024448316208514396;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.729199597233659459e-06) ) ) {
              result[0] += -0.00024448316208514396;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.0002577081244998225;
              } else {
                result[0] += 2.2614658589022894e-05;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                result[0] += -0.00024448316208514396;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.858234205283420677e-05) ) ) {
                    result[0] += -0.00024448316208514396;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                      result[0] += -0.00024448316208514396;
                    } else {
                      result[0] += -0.00024448316208514396;
                    }
                  }
                } else {
                  result[0] += -0.00024448316208514396;
                }
              }
            } else {
              result[0] += -0.00024448316208514396;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
              result[0] += -0.00024448316208514396;
            } else {
              result[0] += -0.00024448316208514396;
            }
          }
        } else {
          result[0] += -0.00024448316208514396;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0009685000000000000683) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6968016071608041928) ) ) {
              result[0] += 0;
            } else {
              result[0] += 0;
            }
          } else {
            result[0] += 8.413374762807923e-05;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8697742174477757215) ) ) {
            result[0] += 0.0004463856478883967;
          } else {
            result[0] += 0;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.576152860085799078e-06) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.16917529420057901e-06) ) ) {
            result[0] += 0.00024143256762212647;
          } else {
            result[0] += -0.00010976628579972867;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5920309527638191183) ) ) {
            result[0] += 0.0009002646811247308;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0480970000000000078) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.000210500000000000048) ) ) {
                result[0] += 0.00024513123306845407;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0009285000000000001802) ) ) {
                  result[0] += -8.870382404339299e-05;
                } else {
                  result[0] += 0.00016861865398696833;
                }
              }
            } else {
              result[0] += 0.001394071063039433;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1850000000000000255) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.723113719091885043) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8168185667587940513) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6276844434422111929) ) ) {
                result[0] += 0.0011405741823492955;
              } else {
                result[0] += 0.0007240392215939927;
              }
            } else {
              result[0] += -8.08315050650774e-05;
            }
          } else {
            result[0] += 0.0021709343298744704;
          }
        } else {
          result[0] += -3.1251110706483256e-05;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
          result[0] += 0.003678576553172744;
        } else {
          result[0] += 0.010659403451772685;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                  result[0] += -0.0002347515966036567;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                    result[0] += -0.0002347515966036567;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      result[0] += -0.0002347515966036567;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        result[0] += -0.0002347515966036567;
                      } else {
                        result[0] += -0.0002347515966036567;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.0002347515966036567;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                  result[0] += -0.0002347515966036567;
                } else {
                  result[0] += -0.0002347515966036567;
                }
              } else {
                result[0] += 9.651172056494585e-06;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6100010069597990858) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5494686760804020631) ) ) {
                  result[0] += 9.975103813689663e-06;
                } else {
                  result[0] += -3.2793583280263426e-07;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                  result[0] += -0.0002347515966036567;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7114754460552764614) ) ) {
                    result[0] += 1.9866550441651734e-05;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8466324982590252013) ) ) {
                      result[0] += -0.0002347515966036567;
                    } else {
                      result[0] += -0.0002347515966036567;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01085750000000000083) ) ) {
                  result[0] += -1.2569864696249557e-05;
                } else {
                  result[0] += 0.00033486465804791736;
                }
              } else {
                result[0] += 0.0014404052642907198;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -0.0002347515966036567;
                  } else {
                    result[0] += -0.0002347515966036567;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                    result[0] += -0.0002347515966036567;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      result[0] += -0.0002347515966036567;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                        result[0] += -0.0002347515966036567;
                      } else {
                        result[0] += -0.0002347515966036567;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.0002347515966036567;
              }
            } else {
              result[0] += -0.0002347515966036567;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.729199597233659459e-06) ) ) {
              result[0] += -0.0002347515966036567;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.00024745014408394467;
              } else {
                result[0] += 2.1714490131516166e-05;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                result[0] += -0.0002347515966036567;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.858234205283420677e-05) ) ) {
                    result[0] += -0.0002347515966036567;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                      result[0] += -0.0002347515966036567;
                    } else {
                      result[0] += -0.0002347515966036567;
                    }
                  }
                } else {
                  result[0] += -0.0002347515966036567;
                }
              }
            } else {
              result[0] += -0.0002347515966036567;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
              result[0] += -0.0002347515966036567;
            } else {
              result[0] += -0.0002347515966036567;
            }
          }
        } else {
          result[0] += -0.0002347515966036567;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0009685000000000000683) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6968016071608041928) ) ) {
              result[0] += 0;
            } else {
              result[0] += 0;
            }
          } else {
            result[0] += 8.078483366908673e-05;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8697742174477757215) ) ) {
            result[0] += 0.00042861742562976446;
          } else {
            result[0] += 0;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.576152860085799078e-06) ) ) {
          result[0] += 0.00013096473440502544;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7342470301758795559) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002194500000000000704) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.000210500000000000048) ) ) {
                result[0] += 0.00037471167760127686;
              } else {
                result[0] += 0.00014871186250750438;
              }
            } else {
              result[0] += 0.0010458839054325285;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8466324982590252013) ) ) {
              result[0] += -0.00012374950330432165;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                result[0] += 0.0002482293026920916;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005372500000000001406) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00260107659603655032) ) ) {
                    result[0] += 0.00018895512790154519;
                  } else {
                    result[0] += -4.919492298778485e-05;
                  }
                } else {
                  result[0] += 0.00041650095513606024;
                }
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1250000000000000278) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09500000000000001499) ) ) {
            result[0] += 0.00045854765512254054;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7322719660050253099) ) ) {
              result[0] += 0.0003806390967111922;
            } else {
              result[0] += -0.00024135563730312294;
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4350000000000000533) ) ) {
            result[0] += 0.0019296109655999778;
          } else {
            result[0] += 0.007918507896425855;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1350000000000000366) ) ) {
            result[0] += 0.0017980082577361257;
          } else {
            result[0] += 0.009040970282979387;
          }
        } else {
          result[0] += -3.0007171338162106e-05;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                  result[0] += -0.00022540739263170152;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                    result[0] += -0.00022540739263170152;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      result[0] += -0.00022540739263170152;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        result[0] += -0.00022540739263170152;
                      } else {
                        result[0] += -0.00022540739263170152;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.00022540739263170152;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                  result[0] += -0.00022540739263170152;
                } else {
                  result[0] += -0.00022540739263170152;
                }
              } else {
                result[0] += 9.267010578706705e-06;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6100010069597990858) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5494686760804020631) ) ) {
                  result[0] += 9.57804834729422e-06;
                } else {
                  result[0] += -3.1488246338679173e-07;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                  result[0] += -0.00022540739263170152;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7114754460552764614) ) ) {
                    result[0] += 1.9075769453442554e-05;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8466324982590252013) ) ) {
                      result[0] += -0.00022540739263170152;
                    } else {
                      result[0] += -0.00022540739263170152;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004848500000000001246) ) ) {
                  result[0] += -1.3302235363788906e-05;
                } else {
                  result[0] += 0.00032153548920276696;
                }
              } else {
                result[0] += 0.0013830704440529057;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -0.00022540739263170152;
                  } else {
                    result[0] += -0.00022540739263170152;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                    result[0] += -0.00022540739263170152;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      result[0] += -0.00022540739263170152;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                        result[0] += -0.00022540739263170152;
                      } else {
                        result[0] += -0.00022540739263170152;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.00022540739263170152;
              }
            } else {
              result[0] += -0.00022540739263170152;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.729199597233659459e-06) ) ) {
              result[0] += -0.00022540739263170152;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.0002376004789371984;
              } else {
                result[0] += 2.0850152559923548e-05;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                result[0] += -0.00022540739263170152;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.858234205283420677e-05) ) ) {
                    result[0] += -0.00022540739263170152;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                      result[0] += -0.00022540739263170152;
                    } else {
                      result[0] += -0.00022540739263170152;
                    }
                  }
                } else {
                  result[0] += -0.00022540739263170152;
                }
              }
            } else {
              result[0] += -0.00022540739263170152;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
              result[0] += -0.00022540739263170152;
            } else {
              result[0] += -0.00022540739263170152;
            }
          }
        } else {
          result[0] += -0.00022540739263170152;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0009685000000000000683) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6968016071608041928) ) ) {
              result[0] += 0;
            } else {
              result[0] += 0;
            }
          } else {
            result[0] += 7.756922204145253e-05;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8697742174477757215) ) ) {
            result[0] += 0.0004115564611508696;
          } else {
            result[0] += 0;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.576152860085799078e-06) ) ) {
          result[0] += 0.00012575172964118713;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5920309527638191183) ) ) {
            result[0] += 0.0008257417344064076;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05311250000000000693) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.000210500000000000048) ) ) {
                result[0] += 0.00022549319207296284;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0009285000000000001802) ) ) {
                  result[0] += -8.794130685355673e-05;
                } else {
                  result[0] += 0.00013193164091882727;
                }
              }
            } else {
              result[0] += 0.0013684878201128512;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1850000000000000255) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.723113719091885043) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005170679155401200662) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7342470301758795559) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1050000000000000239) ) ) {
                result[0] += 0.0006364596849153551;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2739990068871500095) ) ) {
                  result[0] += 0.0018141393085970511;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4677590045467516222) ) ) {
                    result[0] += 0.0009801908562659977;
                  } else {
                    result[0] += 0.0014055503467820959;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8466324982590252013) ) ) {
                result[0] += -0.0001360612995949274;
              } else {
                result[0] += 0.0006408694514612458;
              }
            }
          } else {
            result[0] += 0.0022720102032263963;
          }
        } else {
          result[0] += -2.8812746534830086e-05;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1650000000000000355) ) ) {
            result[0] += 0.00045480913477033045;
          } else {
            result[0] += 0.004250185017460206;
          }
        } else {
          result[0] += 0.009875237068393102;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                  result[0] += -0.00021643513138189496;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                    result[0] += -0.00021643513138189496;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      result[0] += -0.00021643513138189496;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        result[0] += -0.00021643513138189496;
                      } else {
                        result[0] += -0.00021643513138189496;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.00021643513138189496;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                  result[0] += -0.00021643513138189496;
                } else {
                  result[0] += -0.00021643513138189496;
                }
              } else {
                result[0] += 8.898140512174631e-06;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6100010069597990858) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5494686760804020631) ) ) {
                  result[0] += 9.19679753279401e-06;
                } else {
                  result[0] += -3.023486787069632e-07;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                  result[0] += -0.00021643513138189496;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7114754460552764614) ) ) {
                    result[0] += 1.8316465221761853e-05;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8466324982590252013) ) ) {
                      result[0] += -0.00021643513138189496;
                    } else {
                      result[0] += -0.00021643513138189496;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004848500000000001246) ) ) {
                  result[0] += -1.2772744607088921e-05;
                } else {
                  result[0] += 0.0003087368831919815;
                }
              } else {
                result[0] += 0.001328017815982253;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -0.00021643513138189496;
                  } else {
                    result[0] += -0.00021643513138189496;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                    result[0] += -0.00021643513138189496;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      result[0] += -0.00021643513138189496;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                        result[0] += -0.00021643513138189496;
                      } else {
                        result[0] += -0.00021643513138189496;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.00021643513138189496;
              }
            } else {
              result[0] += -0.00021643513138189496;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.729199597233659459e-06) ) ) {
              result[0] += -0.00021643513138189496;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.0002281428762152374;
              } else {
                result[0] += 2.002021963855027e-05;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                result[0] += -0.00021643513138189496;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.858234205283420677e-05) ) ) {
                    result[0] += -0.00021643513138189496;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                      result[0] += -0.00021643513138189496;
                    } else {
                      result[0] += -0.00021643513138189496;
                    }
                  }
                } else {
                  result[0] += -0.00021643513138189496;
                }
              }
            } else {
              result[0] += -0.00021643513138189496;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
              result[0] += -0.00021643513138189496;
            } else {
              result[0] += -0.00021643513138189496;
            }
          }
        } else {
          result[0] += -0.00021643513138189496;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1550000000000000266) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0009685000000000000683) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6968016071608041928) ) ) {
              result[0] += 0;
            } else {
              result[0] += 0;
            }
          } else {
            result[0] += -4.966013191110854e-06;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8697742174477757215) ) ) {
            result[0] += 0.0006056203713622777;
          } else {
            result[0] += 0.00011588131023872366;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002194500000000000704) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006290243127013950622) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                result[0] += 0.00030174935935209656;
              } else {
                result[0] += 0.0010291938866634717;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6449783570351760309) ) ) {
                result[0] += 0.00035295884982895184;
              } else {
                result[0] += -0.00012451322084195383;
              }
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004099190464141650413) ) ) {
              result[0] += 0.0006564798219414944;
            } else {
              result[0] += 0.0015949649766789143;
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8466324982590252013) ) ) {
            result[0] += -0.00013642578415201832;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.723113719091885043) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
                result[0] += 0.0005810225788403354;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.051391296366422923) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9993516786272610419) ) ) {
                      result[0] += -7.620758343887294e-06;
                    } else {
                      result[0] += 0.000560561424940524;
                    }
                  } else {
                    result[0] += -0.0001284595859954881;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7983409114572864729) ) ) {
                    result[0] += 9.333312994193631e-06;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8507017292462312197) ) ) {
                      result[0] += 0.0005986090494525534;
                    } else {
                      result[0] += 0.00019903992998299795;
                    }
                  }
                }
              }
            } else {
              result[0] += -2.766586538680426e-05;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1850000000000000255) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7536081807788946874) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08500000000000000611) ) ) {
            result[0] += 0.0011728092864354267;
          } else {
            result[0] += 0.0023220650663355897;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7712418641206031378) ) ) {
            result[0] += -0.00011618328383010972;
          } else {
            result[0] += 0.000933793693455564;
          }
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3450000000000000289) ) ) {
          result[0] += 0.004071904583455283;
        } else {
          result[0] += 0.013462621027630156;
        }
      }
    }
  }
}

