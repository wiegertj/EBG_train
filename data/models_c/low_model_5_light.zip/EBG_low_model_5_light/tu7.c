
#include "header.h"

void predict_unit7(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
              result[0] += -3.023941894059339e-06;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                  result[0] += -3.023941894059339e-06;
                } else {
                  result[0] += -3.023941894059339e-06;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                    result[0] += -3.023941894059339e-06;
                  } else {
                    result[0] += -3.023941894059339e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                    result[0] += -3.023941894059339e-06;
                  } else {
                    result[0] += -3.023941894059339e-06;
                  }
                }
              }
            }
          } else {
            result[0] += -3.180078920706481e-06;
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
            result[0] += 2.1325182462032225e-06;
          } else {
            result[0] += -3.635377136261718e-06;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                    result[0] += -3.023941894059339e-06;
                  } else {
                    result[0] += -3.023941894059339e-06;
                  }
                } else {
                  result[0] += -3.023941894059339e-06;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -3.023941894059339e-06;
                } else {
                  result[0] += -3.023941894059339e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                        result[0] += -3.023941894059339e-06;
                      } else {
                        result[0] += -3.023941894059339e-06;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7847910031909549611) ) ) {
                        result[0] += -3.023941894059339e-06;
                      } else {
                        result[0] += -3.023941894059339e-06;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                          result[0] += -3.023941894059339e-06;
                        } else {
                          result[0] += -3.023941894059339e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                            result[0] += -3.023941894059339e-06;
                          } else {
                            result[0] += -3.023941894059339e-06;
                          }
                        } else {
                          result[0] += -3.023941894059339e-06;
                        }
                      }
                    } else {
                      result[0] += -3.023941894059339e-06;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                      result[0] += -3.023941894059339e-06;
                    } else {
                      result[0] += -3.023941894059339e-06;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                      result[0] += -3.023941894059339e-06;
                    } else {
                      result[0] += -3.023941894059339e-06;
                    }
                  }
                }
              } else {
                result[0] += -3.023941894059339e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
              result[0] += -3.023941894059339e-06;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                  result[0] += -3.023941894059339e-06;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                    result[0] += -3.023941894059339e-06;
                  } else {
                    result[0] += -3.023941894059339e-06;
                  }
                }
              } else {
                result[0] += -3.023941894059339e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
              result[0] += -3.023941894059339e-06;
            } else {
              result[0] += 1.488136388676821e-07;
            }
          } else {
            result[0] += -3.023941894059339e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.115000000000000005) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.992027305872230758) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7472528898492464267) ) ) {
              result[0] += -1.2296877309234198e-05;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2050000000000000433) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9284011333411857914) ) ) {
                  result[0] += -1.0804570077141297e-06;
                } else {
                  result[0] += -0.0002868420739207735;
                }
              } else {
                result[0] += -0.0005205215205350117;
              }
            }
          } else {
            result[0] += 8.767313146168863e-06;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.154253000000000029) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.370731135743224804) ) ) {
              result[0] += 0.00014116636023275288;
            } else {
              result[0] += -0.0016677621471089007;
            }
          } else {
            result[0] += 0.0022445025623374156;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.457260671080300662) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
            result[0] += 0.0026623832433207693;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01264450000000000122) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5800027599246232457) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1001961271985990637) ) ) {
                  result[0] += 0.0020766535977186098;
                } else {
                  result[0] += -0.0023981417503044907;
                }
              } else {
                result[0] += 0.0027288973733246417;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9950000000000001066) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4100284358542713448) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0997940000000000077) ) ) {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03485950000000000853) ) ) {
                      result[0] += 0.00047973070286906036;
                    } else {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05391850000000000809) ) ) {
                        result[0] += -0.005659890011311057;
                      } else {
                        result[0] += -0.0025195847081542757;
                      }
                    }
                  } else {
                    result[0] += 0.005657778797950593;
                  }
                } else {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1701831610694422292) ) ) {
                    result[0] += 0.0033004195264115053;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4914057384422110819) ) ) {
                      result[0] += -0.004544672602423438;
                    } else {
                      result[0] += 0.0008281576682364457;
                    }
                  }
                }
              } else {
                result[0] += 0.0013176719709877638;
              }
            }
          }
        } else {
          result[0] += -0.0017660279786867524;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
              result[0] += -2.882108149760737e-06;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                  result[0] += -2.882108149760737e-06;
                } else {
                  result[0] += -2.882108149760737e-06;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                    result[0] += -2.882108149760737e-06;
                  } else {
                    result[0] += -2.882108149760737e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                    result[0] += -2.882108149760737e-06;
                  } else {
                    result[0] += -2.882108149760737e-06;
                  }
                }
              }
            }
          } else {
            result[0] += -3.030921788628332e-06;
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
            result[0] += 2.0324954751842854e-06;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.16821429881140601) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5673593061306533292) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5145936098743719711) ) ) {
                  result[0] += -8.263047840032326e-06;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009189500000000001487) ) ) {
                    result[0] += -2.044290752281837e-05;
                  } else {
                    result[0] += 0.00030055883853153233;
                  }
                }
              } else {
                result[0] += -2.381618965004462e-05;
              }
            } else {
              result[0] += 9.085931546506959e-08;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                    result[0] += -2.882108149760737e-06;
                  } else {
                    result[0] += -2.882108149760737e-06;
                  }
                } else {
                  result[0] += -2.882108149760737e-06;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -2.882108149760737e-06;
                } else {
                  result[0] += -2.882108149760737e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                        result[0] += -2.882108149760737e-06;
                      } else {
                        result[0] += -2.882108149760737e-06;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7847910031909549611) ) ) {
                        result[0] += -2.882108149760737e-06;
                      } else {
                        result[0] += -2.882108149760737e-06;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                          result[0] += -2.882108149760737e-06;
                        } else {
                          result[0] += -2.882108149760737e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                            result[0] += -2.882108149760737e-06;
                          } else {
                            result[0] += -2.882108149760737e-06;
                          }
                        } else {
                          result[0] += -2.882108149760737e-06;
                        }
                      }
                    } else {
                      result[0] += -2.882108149760737e-06;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                      result[0] += -2.882108149760737e-06;
                    } else {
                      result[0] += -2.882108149760737e-06;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                      result[0] += -2.882108149760737e-06;
                    } else {
                      result[0] += -2.882108149760737e-06;
                    }
                  }
                }
              } else {
                result[0] += -2.882108149760737e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
              result[0] += -2.882108149760737e-06;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                  result[0] += -2.882108149760737e-06;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                    result[0] += -2.882108149760737e-06;
                  } else {
                    result[0] += -2.882108149760737e-06;
                  }
                }
              } else {
                result[0] += -2.882108149760737e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
              result[0] += -2.882108149760737e-06;
            } else {
              result[0] += 1.418337442986599e-07;
            }
          } else {
            result[0] += -2.882108149760737e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9650000000000000799) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.115000000000000005) ) ) {
          result[0] += -1.1153691544231479e-05;
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08494950000000001111) ) ) {
            result[0] += 0.0001415009210087662;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9993516786272610419) ) ) {
              result[0] += 0.0016712216411964803;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.786764172562814168) ) ) {
                result[0] += -0.002334898538441912;
              } else {
                result[0] += 0.0008731479196704471;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0025375078993533848;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01264450000000000122) ) ) {
            result[0] += 0.002083634990933752;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1030960000000000071) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.316725863161028132) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4129968667336683663) ) ) {
                  if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4188836135812591954) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3978000706030150879) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3597967273366834418) ) ) {
                        result[0] += -0.0003720953171336126;
                      } else {
                        result[0] += 0.001825312878303922;
                      }
                    } else {
                      result[0] += -0.00203285144960434;
                    }
                  } else {
                    if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3715165125194505591) ) ) {
                      result[0] += -0.004981679051963665;
                    } else {
                      result[0] += -0.0007551280104109631;
                    }
                  }
                } else {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1537850195715064483) ) ) {
                    result[0] += 0.001863939156816445;
                  } else {
                    if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.121863051132545086) ) ) {
                      result[0] += -0.002493572108156017;
                    } else {
                      result[0] += 0.0008192080858644417;
                    }
                  }
                }
              } else {
                result[0] += -0.00190441030101371;
              }
            } else {
              result[0] += 0.0019708949737045713;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
              result[0] += -2.746926917886822e-06;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                  result[0] += -2.746926917886822e-06;
                } else {
                  result[0] += -2.746926917886822e-06;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                    result[0] += -2.746926917886822e-06;
                  } else {
                    result[0] += -2.746926917886822e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                    result[0] += -2.746926917886822e-06;
                  } else {
                    result[0] += -2.746926917886822e-06;
                  }
                }
              }
            }
          } else {
            result[0] += -2.8887606621854257e-06;
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
            result[0] += 1.937164131654942e-06;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06355808660527756393) ) ) {
              result[0] += -1.4673853743912646e-05;
            } else {
              result[0] += -2.840095675546125e-07;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                    result[0] += -2.746926917886822e-06;
                  } else {
                    result[0] += -2.746926917886822e-06;
                  }
                } else {
                  result[0] += -2.746926917886822e-06;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -2.746926917886822e-06;
                } else {
                  result[0] += -2.746926917886822e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                        result[0] += -2.746926917886822e-06;
                      } else {
                        result[0] += -2.746926917886822e-06;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7847910031909549611) ) ) {
                        result[0] += -2.746926917886822e-06;
                      } else {
                        result[0] += -2.746926917886822e-06;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                          result[0] += -2.746926917886822e-06;
                        } else {
                          result[0] += -2.746926917886822e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                            result[0] += -2.746926917886822e-06;
                          } else {
                            result[0] += -2.746926917886822e-06;
                          }
                        } else {
                          result[0] += -2.746926917886822e-06;
                        }
                      }
                    } else {
                      result[0] += -2.746926917886822e-06;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                      result[0] += -2.746926917886822e-06;
                    } else {
                      result[0] += -2.746926917886822e-06;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                      result[0] += -2.746926917886822e-06;
                    } else {
                      result[0] += -2.746926917886822e-06;
                    }
                  }
                }
              } else {
                result[0] += -2.746926917886822e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
              result[0] += -2.746926917886822e-06;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                  result[0] += -2.746926917886822e-06;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                    result[0] += -2.746926917886822e-06;
                  } else {
                    result[0] += -2.746926917886822e-06;
                  }
                }
              } else {
                result[0] += -2.746926917886822e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
              result[0] += -2.746926917886822e-06;
            } else {
              result[0] += 1.3518123187400413e-07;
            }
          } else {
            result[0] += -2.746926917886822e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9850000000000000977) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.7750000000000001332) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1627210000000000323) ) ) {
            result[0] += 6.686864420028737e-06;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.07500000000000002498) ) ) {
              result[0] += -0.00021544065658835938;
            } else {
              result[0] += 0.0018786189405380874;
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007045500000000000547) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5705607401507538645) ) ) {
                result[0] += -0.004412807639176004;
              } else {
                result[0] += 0.001551216894301198;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                result[0] += 0.002057298647489705;
              } else {
                result[0] += -0.0005018705070043465;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4558178340201005097) ) ) {
              if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1701831610694422292) ) ) {
                result[0] += -0.00014564073998182519;
              } else {
                result[0] += -0.004912965076749306;
              }
            } else {
              result[0] += 0.000833639998999493;
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.002418489657878701;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01264450000000000122) ) ) {
            result[0] += 0.001976909241496076;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.316725863161028132) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1811070000000000457) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4129968667336683663) ) ) {
                  if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4188836135812591954) ) ) {
                    result[0] += 0.0006843704012136476;
                  } else {
                    if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3715165125194505591) ) ) {
                      result[0] += -0.00449634792978114;
                    } else {
                      result[0] += -0.0016204225927370758;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1001961271985990637) ) ) {
                    result[0] += 0.0017673845490815202;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6050666370100503677) ) ) {
                      result[0] += -0.0008830847695289044;
                    } else {
                      result[0] += 0.0011398527061948138;
                    }
                  }
                }
              } else {
                result[0] += 0.00189340233995845;
              }
            } else {
              result[0] += -0.0012593465359242023;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
              result[0] += -2.6180861716926225e-06;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                  result[0] += -2.6180861716926225e-06;
                } else {
                  result[0] += -2.6180861716926225e-06;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                    result[0] += -2.6180861716926225e-06;
                  } else {
                    result[0] += -2.6180861716926225e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                    result[0] += -2.6180861716926225e-06;
                  } else {
                    result[0] += -2.6180861716926225e-06;
                  }
                }
              }
            }
          } else {
            result[0] += -2.7532674035665392e-06;
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
            result[0] += 1.8463041708027396e-06;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06355808660527756393) ) ) {
              result[0] += -1.3985597258601922e-05;
            } else {
              result[0] += -2.7068849797254285e-07;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                    result[0] += -2.6180861716926225e-06;
                  } else {
                    result[0] += -2.6180861716926225e-06;
                  }
                } else {
                  result[0] += -2.6180861716926225e-06;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -2.6180861716926225e-06;
                } else {
                  result[0] += -2.6180861716926225e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                        result[0] += -2.6180861716926225e-06;
                      } else {
                        result[0] += -2.6180861716926225e-06;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7847910031909549611) ) ) {
                        result[0] += -2.6180861716926225e-06;
                      } else {
                        result[0] += -2.6180861716926225e-06;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                          result[0] += -2.6180861716926225e-06;
                        } else {
                          result[0] += -2.6180861716926225e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                            result[0] += -2.6180861716926225e-06;
                          } else {
                            result[0] += -2.6180861716926225e-06;
                          }
                        } else {
                          result[0] += -2.6180861716926225e-06;
                        }
                      }
                    } else {
                      result[0] += -2.6180861716926225e-06;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                      result[0] += -2.6180861716926225e-06;
                    } else {
                      result[0] += -2.6180861716926225e-06;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                      result[0] += -2.6180861716926225e-06;
                    } else {
                      result[0] += -2.6180861716926225e-06;
                    }
                  }
                }
              } else {
                result[0] += -2.6180861716926225e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
              result[0] += -2.6180861716926225e-06;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                  result[0] += -2.6180861716926225e-06;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                    result[0] += -2.6180861716926225e-06;
                  } else {
                    result[0] += -2.6180861716926225e-06;
                  }
                }
              } else {
                result[0] += -2.6180861716926225e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
              result[0] += -2.6180861716926225e-06;
            } else {
              result[0] += 1.2884074619431639e-07;
            }
          } else {
            result[0] += -2.6180861716926225e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9350000000000001643) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.154253000000000029) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03500000000000001027) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1750000000000000167) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7683067979899498301) ) ) {
                  result[0] += -1.4864777988107295e-05;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7894192122613066243) ) ) {
                    result[0] += -0.0004101575674174142;
                  } else {
                    result[0] += -1.3008861140287603e-05;
                  }
                }
              } else {
                result[0] += 0.0016689533893376458;
              }
            } else {
              result[0] += 8.565604893772365e-06;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.07500000000000002498) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001255500000000000322) ) ) {
                result[0] += -1.930932244342719e-05;
              } else {
                result[0] += 0.000978778615995839;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.114862829452247572) ) ) {
                result[0] += 0.00010424324384166345;
              } else {
                result[0] += -0.00023642111651192617;
              }
            }
          }
        } else {
          result[0] += 0.0007809833774596277;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.457260671080300662) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
            result[0] += 0.0023050537997366294;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01264450000000000122) ) ) {
              result[0] += 0.0019218107075157902;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1811070000000000457) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4129968667336683663) ) ) {
                  if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4314418144595498217) ) ) {
                    result[0] += 0.0005240974768663002;
                  } else {
                    if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.392100875596731957) ) ) {
                      result[0] += -0.0031374985696872005;
                    } else {
                      result[0] += -0.003142106551908817;
                    }
                  }
                } else {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1537850195715064483) ) ) {
                    result[0] += 0.001693617022327149;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4693702733417085549) ) ) {
                      result[0] += -0.0025372019507699504;
                    } else {
                      result[0] += 0.0009778487833065994;
                    }
                  }
                }
              } else {
                result[0] += 0.0018445450850612085;
              }
            }
          }
        } else {
          result[0] += -0.0016378124830739034;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
              result[0] += -2.495288519609077e-06;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                  result[0] += -2.495288519609077e-06;
                } else {
                  result[0] += -2.495288519609077e-06;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                    result[0] += -2.495288519609077e-06;
                  } else {
                    result[0] += -2.495288519609077e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                    result[0] += -2.495288519609077e-06;
                  } else {
                    result[0] += -2.495288519609077e-06;
                  }
                }
              }
            }
          } else {
            result[0] += -2.624129265803278e-06;
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
            result[0] += 1.7597058687078633e-06;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06355808660527756393) ) ) {
              result[0] += -1.3329622476369289e-05;
            } else {
              result[0] += -2.5799223443604573e-07;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                    result[0] += -2.495288519609077e-06;
                  } else {
                    result[0] += -2.495288519609077e-06;
                  }
                } else {
                  result[0] += -2.495288519609077e-06;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -2.495288519609077e-06;
                } else {
                  result[0] += -2.495288519609077e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                        result[0] += -2.495288519609077e-06;
                      } else {
                        result[0] += -2.495288519609077e-06;
                      }
                    } else {
                      result[0] += -2.495288519609077e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                          result[0] += -2.495288519609077e-06;
                        } else {
                          result[0] += -2.495288519609077e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                            result[0] += -2.495288519609077e-06;
                          } else {
                            result[0] += -2.495288519609077e-06;
                          }
                        } else {
                          result[0] += -2.495288519609077e-06;
                        }
                      }
                    } else {
                      result[0] += -2.495288519609077e-06;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                      result[0] += -2.495288519609077e-06;
                    } else {
                      result[0] += -2.495288519609077e-06;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                      result[0] += -2.495288519609077e-06;
                    } else {
                      result[0] += -2.495288519609077e-06;
                    }
                  }
                }
              } else {
                result[0] += -2.495288519609077e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
              result[0] += -2.495288519609077e-06;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                  result[0] += -2.495288519609077e-06;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                    result[0] += -2.495288519609077e-06;
                  } else {
                    result[0] += -2.495288519609077e-06;
                  }
                }
              } else {
                result[0] += -2.495288519609077e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
              result[0] += -2.495288519609077e-06;
            } else {
              result[0] += 1.2279765208361729e-07;
            }
          } else {
            result[0] += -2.495288519609077e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9650000000000000799) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.154253000000000029) ) ) {
          result[0] += 1.3426252576430882e-05;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.07500000000000002498) ) ) {
            result[0] += -0.000283266843089349;
          } else {
            result[0] += 0.0017878855917659202;
          }
        }
      } else {
        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0021969384910831636;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01264450000000000122) ) ) {
            result[0] += 0.0018087906380455342;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9993516786272610419) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6650804020351760437) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5508018452917812224) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6050666370100503677) ) ) {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1001961271985990637) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4129968667336683663) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3978000706030150879) ) ) {
                            if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4188836135812591954) ) ) {
                              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.688558886476752785) ) ) {
                                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04871150000000001173) ) ) {
                                  result[0] += 0.0014788199127636625;
                                } else {
                                  result[0] += -0.00476980974706296;
                                }
                              } else {
                                result[0] += 0.0014513376940176426;
                              }
                            } else {
                              result[0] += -0.0032710111629243154;
                            }
                          } else {
                            result[0] += -0.002252091394483664;
                          }
                        } else {
                          result[0] += 0.00152514257396634;
                        }
                      } else {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08771650000000001668) ) ) {
                          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06783400000000001928) ) ) {
                            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5499504253266332965) ) ) {
                              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.178455187992527714) ) ) {
                                result[0] += -0.004007318933041061;
                              } else {
                                result[0] += -0.001651804548254202;
                              }
                            } else {
                              result[0] += -1.3687473868735912e-05;
                            }
                          } else {
                            result[0] += -0.005574079982520452;
                          }
                        } else {
                          result[0] += 0.0007704472406267661;
                        }
                      }
                    } else {
                      result[0] += 0.0019785954744473175;
                    }
                  } else {
                    result[0] += -0.005153911113101847;
                  }
                } else {
                  result[0] += 0.0023931117031025734;
                }
              } else {
                result[0] += -0.0015662144199894924;
              }
            } else {
              result[0] += 0.0017330285946293308;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
              result[0] += -2.378250518800677e-06;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                  result[0] += -2.378250518800677e-06;
                } else {
                  result[0] += -2.378250518800677e-06;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                    result[0] += -2.378250518800677e-06;
                  } else {
                    result[0] += -2.378250518800677e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                    result[0] += -2.378250518800677e-06;
                  } else {
                    result[0] += -2.378250518800677e-06;
                  }
                }
              }
            }
          } else {
            result[0] += -2.5010481708842248e-06;
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
            result[0] += 1.6771693382562164e-06;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06355808660527756393) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01503750000000000052) ) ) {
                result[0] += -5.333015277101166e-05;
              } else {
                result[0] += -5.906042720452598e-06;
              }
            } else {
              result[0] += -2.4589147129574624e-07;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                    result[0] += -2.378250518800677e-06;
                  } else {
                    result[0] += -2.378250518800677e-06;
                  }
                } else {
                  result[0] += -2.378250518800677e-06;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -2.378250518800677e-06;
                } else {
                  result[0] += -2.378250518800677e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                        result[0] += -2.378250518800677e-06;
                      } else {
                        result[0] += -2.378250518800677e-06;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7847910031909549611) ) ) {
                        result[0] += -2.378250518800677e-06;
                      } else {
                        result[0] += -2.378250518800677e-06;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                          result[0] += -2.378250518800677e-06;
                        } else {
                          result[0] += -2.378250518800677e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                            result[0] += -2.378250518800677e-06;
                          } else {
                            result[0] += -2.378250518800677e-06;
                          }
                        } else {
                          result[0] += -2.378250518800677e-06;
                        }
                      }
                    } else {
                      result[0] += -2.378250518800677e-06;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                      result[0] += -2.378250518800677e-06;
                    } else {
                      result[0] += -2.378250518800677e-06;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                      result[0] += -2.378250518800677e-06;
                    } else {
                      result[0] += -2.378250518800677e-06;
                    }
                  }
                }
              } else {
                result[0] += -2.378250518800677e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
              result[0] += -2.378250518800677e-06;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                  result[0] += -2.378250518800677e-06;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                    result[0] += -2.378250518800677e-06;
                  } else {
                    result[0] += -2.378250518800677e-06;
                  }
                }
              } else {
                result[0] += -2.378250518800677e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
              result[0] += -2.378250518800677e-06;
            } else {
              result[0] += 1.1703800080848552e-07;
            }
          } else {
            result[0] += -2.378250518800677e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9850000000000000977) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.7750000000000001332) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1627210000000000323) ) ) {
            result[0] += 4.773148335696576e-06;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.07500000000000002498) ) ) {
              result[0] += -0.0002286804098883938;
            } else {
              result[0] += 0.0016700157712100736;
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007045500000000000547) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5705607401507538645) ) ) {
                result[0] += -0.004219875136179036;
              } else {
                result[0] += 0.0014729401238150674;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                result[0] += 0.0018897850722919584;
              } else {
                result[0] += -0.00046787171560072534;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4129968667336683663) ) ) {
              if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4314418144595498217) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.09326150000000001106) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04119700000000000445) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0195175000000000036) ) ) {
                      result[0] += -0.00025912870557372;
                    } else {
                      result[0] += 0.0016565892828492538;
                    }
                  } else {
                    result[0] += -0.004209201803990682;
                  }
                } else {
                  result[0] += 0.00636816304048121;
                }
              } else {
                result[0] += -0.005551535136066585;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007303000000000001331) ) ) {
                result[0] += -0.0015426026147338063;
              } else {
                result[0] += 0.0008256558890256176;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0020938941790227383;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01109850000000000246) ) ) {
            result[0] += 0.0017583853357265456;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.316725863161028132) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1811070000000000457) ) ) {
                result[0] += 0.0008473659649779186;
              } else {
                result[0] += 0.0016367938993799133;
              }
            } else {
              result[0] += -0.0011681916660731572;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
              result[0] += -2.266702020919728e-06;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                  result[0] += -2.266702020919728e-06;
                } else {
                  result[0] += -2.266702020919728e-06;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                    result[0] += -2.266702020919728e-06;
                  } else {
                    result[0] += -2.266702020919728e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                    result[0] += -2.266702020919728e-06;
                  } else {
                    result[0] += -2.266702020919728e-06;
                  }
                }
              }
            }
          } else {
            result[0] += -2.3837400217281294e-06;
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
            result[0] += 1.5985040677578284e-06;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.16821429881140601) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5458973873869347182) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.020650504707780553) ) ) {
                  result[0] += -5.62902808777234e-06;
                } else {
                  result[0] += 0.0008315045400990985;
                }
              } else {
                result[0] += -1.832111756527211e-05;
              }
            } else {
              result[0] += 1.3624897709075374e-07;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                    result[0] += -2.266702020919728e-06;
                  } else {
                    result[0] += -2.266702020919728e-06;
                  }
                } else {
                  result[0] += -2.266702020919728e-06;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -2.266702020919728e-06;
                } else {
                  result[0] += -2.266702020919728e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                        result[0] += -2.266702020919728e-06;
                      } else {
                        result[0] += -2.266702020919728e-06;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7847910031909549611) ) ) {
                        result[0] += -2.266702020919728e-06;
                      } else {
                        result[0] += -2.266702020919728e-06;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                          result[0] += -2.266702020919728e-06;
                        } else {
                          result[0] += -2.266702020919728e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                            result[0] += -2.266702020919728e-06;
                          } else {
                            result[0] += -2.266702020919728e-06;
                          }
                        } else {
                          result[0] += -2.266702020919728e-06;
                        }
                      }
                    } else {
                      result[0] += -2.266702020919728e-06;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                      result[0] += -2.266702020919728e-06;
                    } else {
                      result[0] += -2.266702020919728e-06;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                      result[0] += -2.266702020919728e-06;
                    } else {
                      result[0] += -2.266702020919728e-06;
                    }
                  }
                }
              } else {
                result[0] += -2.266702020919728e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
              result[0] += -2.266702020919728e-06;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                  result[0] += -2.266702020919728e-06;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                    result[0] += -2.266702020919728e-06;
                  } else {
                    result[0] += -2.266702020919728e-06;
                  }
                }
              } else {
                result[0] += -2.266702020919728e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
              result[0] += -2.266702020919728e-06;
            } else {
              result[0] += 1.1154849788104334e-07;
            }
          } else {
            result[0] += -2.266702020919728e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9650000000000000799) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.115000000000000005) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.992027305872230758) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7472528898492464267) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4230630641206030718) ) ) {
                result[0] += 0.0005583291612150807;
              } else {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4612588522637047217) ) ) {
                  result[0] += -0.0009336069435271745;
                } else {
                  result[0] += -1.2946743262708499e-05;
                }
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2050000000000000433) ) ) {
                result[0] += -0.00013838400964436066;
              } else {
                result[0] += -0.0005016406801304556;
              }
            }
          } else {
            result[0] += 8.300194021855668e-06;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.154253000000000029) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.370731135743224804) ) ) {
              result[0] += 0.00013944004997404943;
            } else {
              result[0] += -0.0015657863077337656;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9284011333411857914) ) ) {
              result[0] += 0.0028257129044219047;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9350000000000001643) ) ) {
                result[0] += 0.0013132180314579993;
              } else {
                result[0] += -0.0012987876822011025;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0019956830155875944;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01243050000000000231) ) ) {
            result[0] += 0.0016513412962805333;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1811070000000000457) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.992027305872230758) ) ) {
                result[0] += 0.0007028505712293349;
              } else {
                result[0] += -0.001154881308730837;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3316832053466863273) ) ) {
                result[0] += 0.002011987576363723;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6247722585678393559) ) ) {
                  result[0] += -0.007349497640669684;
                } else {
                  result[0] += 0.0016906025839792996;
                }
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
              result[0] += -2.1603855485470797e-06;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                  result[0] += -2.1603855485470797e-06;
                } else {
                  result[0] += -2.1603855485470797e-06;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                    result[0] += -2.1603855485470797e-06;
                  } else {
                    result[0] += -2.1603855485470797e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                    result[0] += -2.1603855485470797e-06;
                  } else {
                    result[0] += -2.1603855485470797e-06;
                  }
                }
              }
            }
          } else {
            result[0] += -2.271934046428031e-06;
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
            result[0] += 1.5235284812056852e-06;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.16821429881140601) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5458973873869347182) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.020650504707780553) ) ) {
                  result[0] += -5.365006437085462e-06;
                } else {
                  result[0] += 0.0007925039883506569;
                }
              } else {
                result[0] += -1.746179129676067e-05;
              }
            } else {
              result[0] += 1.2985841032239083e-07;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                    result[0] += -2.1603855485470797e-06;
                  } else {
                    result[0] += -2.1603855485470797e-06;
                  }
                } else {
                  result[0] += -2.1603855485470797e-06;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -2.1603855485470797e-06;
                } else {
                  result[0] += -2.1603855485470797e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                        result[0] += -2.1603855485470797e-06;
                      } else {
                        result[0] += -2.1603855485470797e-06;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7847910031909549611) ) ) {
                        result[0] += -2.1603855485470797e-06;
                      } else {
                        result[0] += -2.1603855485470797e-06;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                          result[0] += -2.1603855485470797e-06;
                        } else {
                          result[0] += -2.1603855485470797e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                            result[0] += -2.1603855485470797e-06;
                          } else {
                            result[0] += -2.1603855485470797e-06;
                          }
                        } else {
                          result[0] += -2.1603855485470797e-06;
                        }
                      }
                    } else {
                      result[0] += -2.1603855485470797e-06;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                      result[0] += -2.1603855485470797e-06;
                    } else {
                      result[0] += -2.1603855485470797e-06;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                      result[0] += -2.1603855485470797e-06;
                    } else {
                      result[0] += -2.1603855485470797e-06;
                    }
                  }
                }
              } else {
                result[0] += -2.1603855485470797e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
              result[0] += -2.1603855485470797e-06;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                  result[0] += -2.1603855485470797e-06;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                    result[0] += -2.1603855485470797e-06;
                  } else {
                    result[0] += -2.1603855485470797e-06;
                  }
                }
              } else {
                result[0] += -2.1603855485470797e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
              result[0] += -2.1603855485470797e-06;
            } else {
              result[0] += 1.0631647237272314e-07;
            }
          } else {
            result[0] += -2.1603855485470797e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9850000000000000977) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8450000000000000844) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.154253000000000029) ) ) {
            result[0] += 5.330049855987292e-06;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.07500000000000002498) ) ) {
              result[0] += -0.00025964398568027394;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.992027305872230758) ) ) {
                result[0] += 0.002757824262262165;
              } else {
                result[0] += 0.00015748617229692662;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007045500000000000547) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3837516359296482826) ) ) {
              result[0] += -0.0007317534934881673;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.22579873602455991) ) ) {
                result[0] += 0.002387910372727849;
              } else {
                result[0] += -0.00017738185510869097;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5400401558291457738) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1001961271985990637) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009908500000000002375) ) ) {
                  result[0] += -0.0014715122178301017;
                } else {
                  result[0] += 0.000572718032615711;
                }
              } else {
                result[0] += -0.008043011414263173;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9993516786272610419) ) ) {
                result[0] += 0.0013435768780165295;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01503750000000000052) ) ) {
                  result[0] += 0.0019627787730915874;
                } else {
                  result[0] += -0.0021170646026394757;
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.001902078308734599;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01109850000000000246) ) ) {
            result[0] += 0.0015984569005266793;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1811070000000000457) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.316725863161028132) ) ) {
                result[0] += 0.0007776501771110379;
              } else {
                result[0] += -0.0011836793957348815;
              }
            } else {
              result[0] += 0.0016480020715375296;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
              result[0] += -2.059055700880037e-06;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                  result[0] += -2.059055700880037e-06;
                } else {
                  result[0] += -2.059055700880037e-06;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                    result[0] += -2.059055700880037e-06;
                  } else {
                    result[0] += -2.059055700880037e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                    result[0] += -2.059055700880037e-06;
                  } else {
                    result[0] += -2.059055700880037e-06;
                  }
                }
              }
            }
          } else {
            result[0] += -2.165372173252687e-06;
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
            result[0] += 1.452069519160285e-06;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08693186820944626136) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5450375474120604524) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5145936098743719711) ) ) {
                  result[0] += -5.113368350833598e-06;
                } else {
                  result[0] += 0.0003194048747476181;
                }
              } else {
                result[0] += -2.8520245937272342e-05;
              }
            } else {
              result[0] += 1.0595574101853466e-07;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                    result[0] += -2.059055700880037e-06;
                  } else {
                    result[0] += -2.059055700880037e-06;
                  }
                } else {
                  result[0] += -2.059055700880037e-06;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -2.059055700880037e-06;
                } else {
                  result[0] += -2.059055700880037e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                        result[0] += -2.059055700880037e-06;
                      } else {
                        result[0] += -2.059055700880037e-06;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7847910031909549611) ) ) {
                        result[0] += -2.059055700880037e-06;
                      } else {
                        result[0] += -2.059055700880037e-06;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                          result[0] += -2.059055700880037e-06;
                        } else {
                          result[0] += -2.059055700880037e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                            result[0] += -2.059055700880037e-06;
                          } else {
                            result[0] += -2.059055700880037e-06;
                          }
                        } else {
                          result[0] += -2.059055700880037e-06;
                        }
                      }
                    } else {
                      result[0] += -2.059055700880037e-06;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                      result[0] += -2.059055700880037e-06;
                    } else {
                      result[0] += -2.059055700880037e-06;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                      result[0] += -2.059055700880037e-06;
                    } else {
                      result[0] += -2.059055700880037e-06;
                    }
                  }
                }
              } else {
                result[0] += -2.059055700880037e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
              result[0] += -2.059055700880037e-06;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                  result[0] += -2.059055700880037e-06;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                    result[0] += -2.059055700880037e-06;
                  } else {
                    result[0] += -2.059055700880037e-06;
                  }
                }
              } else {
                result[0] += -2.059055700880037e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
              result[0] += -2.059055700880037e-06;
            } else {
              result[0] += 1.013298476671326e-07;
            }
          } else {
            result[0] += -2.059055700880037e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.154253000000000029) ) ) {
          result[0] += 7.260762578037738e-06;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.07500000000000002498) ) ) {
            result[0] += -0.00024746574946945486;
          } else {
            result[0] += 0.0016076129231954934;
          }
        }
      } else {
        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.001812863999092285;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.457260671080300662) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3597967273366834418) ) ) {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.8975410753335467673) ) ) {
                result[0] += 0.0016800850260535606;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009908500000000002375) ) ) {
                  result[0] += -0.005409773729169447;
                } else {
                  result[0] += -2.3254981429347985e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01109850000000000246) ) ) {
                result[0] += 0.001865157982285686;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1811070000000000457) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08693186820944626136) ) ) {
                    result[0] += 0.0010819240399688249;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5917931336432161737) ) ) {
                      result[0] += -0.001579136316781609;
                    } else {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3665106630729573767) ) ) {
                        result[0] += 0.0017923856673561956;
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6665876335678392328) ) ) {
                          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5508018452917812224) ) ) {
                            result[0] += -0.0005315196232213392;
                          } else {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6002093903220061533) ) ) {
                              result[0] += -0.006741453524512361;
                            } else {
                              result[0] += -0.0030052309175838234;
                            }
                          }
                        } else {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8030059940338053481) ) ) {
                            result[0] += 0.0024288626979484503;
                          } else {
                            result[0] += 0.0007390304613309762;
                          }
                        }
                      }
                    }
                  }
                } else {
                  result[0] += 0.0015446706790632776;
                }
              }
            }
          } else {
            result[0] += -0.0012719943971797286;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
              result[0] += -1.9624785872956363e-06;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                  result[0] += -1.9624785872956363e-06;
                } else {
                  result[0] += -1.9624785872956363e-06;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                    result[0] += -1.9624785872956363e-06;
                  } else {
                    result[0] += -1.9624785872956363e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                    result[0] += -1.9624785872956363e-06;
                  } else {
                    result[0] += -1.9624785872956363e-06;
                  }
                }
              }
            }
          } else {
            result[0] += -2.0638084349626804e-06;
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
            result[0] += 1.3839622392919205e-06;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08693186820944626136) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5450375474120604524) ) ) {
                result[0] += -4.8735329953323964e-06;
              } else {
                result[0] += -2.7182543887657186e-05;
              }
            } else {
              result[0] += 1.0098603591007505e-07;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                    result[0] += -1.9624785872956363e-06;
                  } else {
                    result[0] += -1.9624785872956363e-06;
                  }
                } else {
                  result[0] += -1.9624785872956363e-06;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -1.9624785872956363e-06;
                } else {
                  result[0] += -1.9624785872956363e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                        result[0] += -1.9624785872956363e-06;
                      } else {
                        result[0] += -1.9624785872956363e-06;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7847910031909549611) ) ) {
                        result[0] += -1.9624785872956363e-06;
                      } else {
                        result[0] += -1.9624785872956363e-06;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                          result[0] += -1.9624785872956363e-06;
                        } else {
                          result[0] += -1.9624785872956363e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                            result[0] += -1.9624785872956363e-06;
                          } else {
                            result[0] += -1.9624785872956363e-06;
                          }
                        } else {
                          result[0] += -1.9624785872956363e-06;
                        }
                      }
                    } else {
                      result[0] += -1.9624785872956363e-06;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                      result[0] += -1.9624785872956363e-06;
                    } else {
                      result[0] += -1.9624785872956363e-06;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                      result[0] += -1.9624785872956363e-06;
                    } else {
                      result[0] += -1.9624785872956363e-06;
                    }
                  }
                }
              } else {
                result[0] += -1.9624785872956363e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
              result[0] += -1.9624785872956363e-06;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                  result[0] += -1.9624785872956363e-06;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                    result[0] += -1.9624785872956363e-06;
                  } else {
                    result[0] += -1.9624785872956363e-06;
                  }
                }
              } else {
                result[0] += -1.9624785872956363e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
              result[0] += -1.9624785872956363e-06;
            } else {
              result[0] += 9.657711358448569e-08;
            }
          } else {
            result[0] += -1.9624785872956363e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.154253000000000029) ) ) {
          result[0] += 6.920206714536427e-06;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.07500000000000002498) ) ) {
            result[0] += -0.00023585871631122323;
          } else {
            result[0] += 0.0015322100985818395;
          }
        }
      } else {
        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.001727834161250317;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01243050000000000231) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3837516359296482826) ) ) {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.8975410753335467673) ) ) {
                result[0] += 0.0019917430308796706;
              } else {
                result[0] += -0.0008610289030655321;
              }
            } else {
              result[0] += 0.0017527813928786928;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1811070000000000457) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9808239647505231362) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6050666370100503677) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2379276778945206283) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4129968667336683663) ) ) {
                      if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4314418144595498217) ) ) {
                        result[0] += 0.0003967662292670177;
                      } else {
                        result[0] += -0.002914814337849613;
                      }
                    } else {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08693186820944626136) ) ) {
                        result[0] += 0.0013085183932981456;
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5645244997236181783) ) ) {
                          result[0] += -0.001787791985087262;
                        } else {
                          result[0] += 0.0010666167296986668;
                        }
                      }
                    }
                  } else {
                    result[0] += -0.0029397161107052264;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3665106630729573767) ) ) {
                    result[0] += 0.0021016082380310493;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6650804020351760437) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6551236496733668924) ) ) {
                        result[0] += 0.0008386652215389214;
                      } else {
                        result[0] += -0.0033374885434779194;
                      }
                    } else {
                      result[0] += 0.0021103564250440415;
                    }
                  }
                }
              } else {
                result[0] += -0.0021975299745073417;
              }
            } else {
              result[0] += 0.001468084694674773;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
              result[0] += -1.8704312874818427e-06;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                  result[0] += -1.8704312874818427e-06;
                } else {
                  result[0] += -1.8704312874818427e-06;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                    result[0] += -1.8704312874818427e-06;
                  } else {
                    result[0] += -1.8704312874818427e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                    result[0] += -1.8704312874818427e-06;
                  } else {
                    result[0] += -1.8704312874818427e-06;
                  }
                }
              }
            }
          } else {
            result[0] += -1.967008401066245e-06;
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
            result[0] += 1.3190494356589087e-06;
          } else {
            result[0] += -3.2574003279256642e-06;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                    result[0] += -1.8704312874818427e-06;
                  } else {
                    result[0] += -1.8704312874818427e-06;
                  }
                } else {
                  result[0] += -1.8704312874818427e-06;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -1.8704312874818427e-06;
                } else {
                  result[0] += -1.8704312874818427e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                        result[0] += -1.8704312874818427e-06;
                      } else {
                        result[0] += -1.8704312874818427e-06;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7847910031909549611) ) ) {
                        result[0] += -1.8704312874818427e-06;
                      } else {
                        result[0] += -1.8704312874818427e-06;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                          result[0] += -1.8704312874818427e-06;
                        } else {
                          result[0] += -1.8704312874818427e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                            result[0] += -1.8704312874818427e-06;
                          } else {
                            result[0] += -1.8704312874818427e-06;
                          }
                        } else {
                          result[0] += -1.8704312874818427e-06;
                        }
                      }
                    } else {
                      result[0] += -1.8704312874818427e-06;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                      result[0] += -1.8704312874818427e-06;
                    } else {
                      result[0] += -1.8704312874818427e-06;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                      result[0] += -1.8704312874818427e-06;
                    } else {
                      result[0] += -1.8704312874818427e-06;
                    }
                  }
                }
              } else {
                result[0] += -1.8704312874818427e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
              result[0] += -1.8704312874818427e-06;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                  result[0] += -1.8704312874818427e-06;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                    result[0] += -1.8704312874818427e-06;
                  } else {
                    result[0] += -1.8704312874818427e-06;
                  }
                }
              } else {
                result[0] += -1.8704312874818427e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
              result[0] += -1.8704312874818427e-06;
            } else {
              result[0] += 9.204729981389095e-08;
            }
          } else {
            result[0] += -1.8704312874818427e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.154253000000000029) ) ) {
          result[0] += 6.595624145151306e-06;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.07500000000000002498) ) ) {
            result[0] += -0.0002247960947292405;
          } else {
            result[0] += 0.0014603439374757266;
          }
        }
      } else {
        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0016467925284403054;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.457260671080300662) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01264450000000000122) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3837516359296482826) ) ) {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.8975410753335467673) ) ) {
                  result[0] += 0.0018983231234716326;
                } else {
                  result[0] += -0.0008122781742429935;
                }
              } else {
                result[0] += 0.001693285097687724;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1811070000000000457) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4129968667336683663) ) ) {
                  if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4314418144595498217) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1113440000000000124) ) ) {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03403950000000000725) ) ) {
                        result[0] += 0.001007390856902491;
                      } else {
                        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.688558886476752785) ) ) {
                          result[0] += -0.004381950142962619;
                        } else {
                          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04503850000000000908) ) ) {
                            result[0] += -0.0009284634397705511;
                          } else {
                            result[0] += 0.002125763083883655;
                          }
                        }
                      }
                    } else {
                      result[0] += 0.002050723752083948;
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06276700000000001722) ) ) {
                      result[0] += -0.0020506013251376976;
                    } else {
                      result[0] += -0.004593942494557843;
                    }
                  }
                } else {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1537850195715064483) ) ) {
                    result[0] += 0.0015240875737550085;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4693702733417085549) ) ) {
                      result[0] += -0.0026333477375812173;
                    } else {
                      result[0] += 0.0006453705808557646;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3316832053466863273) ) ) {
                  result[0] += 0.0016151171207249618;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6247722585678393559) ) ) {
                    result[0] += -0.0068996702716765165;
                  } else {
                    result[0] += 0.0014423311957944488;
                  }
                }
              }
            }
          } else {
            result[0] += -0.0011370540861290388;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
              result[0] += -1.7827013368905373e-06;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                  result[0] += -1.7827013368905373e-06;
                } else {
                  result[0] += -1.7827013368905373e-06;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                    result[0] += -1.7827013368905373e-06;
                  } else {
                    result[0] += -1.7827013368905373e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                    result[0] += -1.7827013368905373e-06;
                  } else {
                    result[0] += -1.7827013368905373e-06;
                  }
                }
              }
            }
          } else {
            result[0] += -1.8747486367043323e-06;
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
            result[0] += 1.2571812758434326e-06;
          } else {
            result[0] += -3.1046165439194427e-06;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                    result[0] += -1.7827013368905373e-06;
                  } else {
                    result[0] += -1.7827013368905373e-06;
                  }
                } else {
                  result[0] += -1.7827013368905373e-06;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -1.7827013368905373e-06;
                } else {
                  result[0] += -1.7827013368905373e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                        result[0] += -1.7827013368905373e-06;
                      } else {
                        result[0] += -1.7827013368905373e-06;
                      }
                    } else {
                      result[0] += -1.7827013368905373e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                          result[0] += -1.7827013368905373e-06;
                        } else {
                          result[0] += -1.7827013368905373e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                            result[0] += -1.7827013368905373e-06;
                          } else {
                            result[0] += -1.7827013368905373e-06;
                          }
                        } else {
                          result[0] += -1.7827013368905373e-06;
                        }
                      }
                    } else {
                      result[0] += -1.7827013368905373e-06;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                      result[0] += -1.7827013368905373e-06;
                    } else {
                      result[0] += -1.7827013368905373e-06;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                      result[0] += -1.7827013368905373e-06;
                    } else {
                      result[0] += -1.7827013368905373e-06;
                    }
                  }
                }
              } else {
                result[0] += -1.7827013368905373e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
              result[0] += -1.7827013368905373e-06;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                  result[0] += -1.7827013368905373e-06;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                    result[0] += -1.7827013368905373e-06;
                  } else {
                    result[0] += -1.7827013368905373e-06;
                  }
                }
              } else {
                result[0] += -1.7827013368905373e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
              result[0] += -1.7827013368905373e-06;
            } else {
              result[0] += 8.772995059141571e-08;
            }
          } else {
            result[0] += -1.7827013368905373e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9250000000000001554) ) ) {
        result[0] += 1.0116689836962379e-05;
      } else {
        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0015695520395107672;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.457260671080300662) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6665876335678392328) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5508018452917812224) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6066922323869347045) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2273413669989351737) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1811070000000000457) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4100284358542713448) ) ) {
                        if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4314418144595498217) ) ) {
                          result[0] += 0.0004991034833881971;
                        } else {
                          result[0] += -0.002633176002789411;
                        }
                      } else {
                        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1537850195715064483) ) ) {
                          result[0] += 0.001699009659073629;
                        } else {
                          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5090080881909548882) ) ) {
                            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5072068278894473758) ) ) {
                              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4693702733417085549) ) ) {
                                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06276700000000001722) ) ) {
                                  result[0] += -0.0022987661423013264;
                                } else {
                                  result[0] += -0.0037229579412043985;
                                }
                              } else {
                                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009719500000000000708) ) ) {
                                  result[0] += -0.0033052159485858395;
                                } else {
                                  result[0] += 0.0012921187921694592;
                                }
                              }
                            } else {
                              result[0] += -0.0031797524926801836;
                            }
                          } else {
                            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1044543990012605922) ) ) {
                              result[0] += -0.0016221287192518176;
                            } else {
                              result[0] += 0.001614627235679152;
                            }
                          }
                        }
                      }
                    } else {
                      result[0] += 0.0015153805447595953;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5750608109547740154) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2928385884053317234) ) ) {
                        result[0] += -7.07886224893752e-05;
                      } else {
                        result[0] += -0.006534313350190996;
                      }
                    } else {
                      result[0] += -0.0001538845806071867;
                    }
                  }
                } else {
                  result[0] += 0.0017700760764403239;
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06607900000000001273) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6126225748691961348) ) ) {
                    result[0] += -0.008718014115353941;
                  } else {
                    result[0] += -0.002604829671214781;
                  }
                } else {
                  result[0] += 0.0016811000219394323;
                }
              }
            } else {
              result[0] += 0.0015913610079299693;
            }
          } else {
            result[0] += -0.001083722162383236;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
              result[0] += -1.6990862363246048e-06;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                  result[0] += -1.6990862363246048e-06;
                } else {
                  result[0] += -1.6990862363246048e-06;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                    result[0] += -1.6990862363246048e-06;
                  } else {
                    result[0] += -1.6990862363246048e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                    result[0] += -1.6990862363246048e-06;
                  } else {
                    result[0] += -1.6990862363246048e-06;
                  }
                }
              }
            }
          } else {
            result[0] += -1.7868161869159116e-06;
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
            result[0] += 1.1982149551065336e-06;
          } else {
            result[0] += -2.958998868559781e-06;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                    result[0] += -1.6990862363246048e-06;
                  } else {
                    result[0] += -1.6990862363246048e-06;
                  }
                } else {
                  result[0] += -1.6990862363246048e-06;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -1.6990862363246048e-06;
                } else {
                  result[0] += -1.6990862363246048e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                        result[0] += -1.6990862363246048e-06;
                      } else {
                        result[0] += -1.6990862363246048e-06;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7847910031909549611) ) ) {
                        result[0] += -1.6990862363246048e-06;
                      } else {
                        result[0] += -1.6990862363246048e-06;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                          result[0] += -1.6990862363246048e-06;
                        } else {
                          result[0] += -1.6990862363246048e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                            result[0] += -1.6990862363246048e-06;
                          } else {
                            result[0] += -1.6990862363246048e-06;
                          }
                        } else {
                          result[0] += -1.6990862363246048e-06;
                        }
                      }
                    } else {
                      result[0] += -1.6990862363246048e-06;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                      result[0] += -1.6990862363246048e-06;
                    } else {
                      result[0] += -1.6990862363246048e-06;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                      result[0] += -1.6990862363246048e-06;
                    } else {
                      result[0] += -1.6990862363246048e-06;
                    }
                  }
                }
              } else {
                result[0] += -1.6990862363246048e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
              result[0] += -1.6990862363246048e-06;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                  result[0] += -1.6990862363246048e-06;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                    result[0] += -1.6990862363246048e-06;
                  } else {
                    result[0] += -1.6990862363246048e-06;
                  }
                }
              } else {
                result[0] += -1.6990862363246048e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
              result[0] += -1.6990862363246048e-06;
            } else {
              result[0] += 8.361510056607587e-08;
            }
          } else {
            result[0] += -1.6990862363246048e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9250000000000001554) ) ) {
        result[0] += 9.642180719474721e-06;
      } else {
        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.001495934407150614;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01109850000000000246) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3837516359296482826) ) ) {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.8975410753335467673) ) ) {
                result[0] += 0.0017858751981328438;
              } else {
                result[0] += -0.0008514522531601127;
              }
            } else {
              result[0] += 0.0016113160419659518;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1811070000000000457) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8066186623115578769) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6665876335678392328) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5508018452917812224) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6066922323869347045) ) ) {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08693186820944626136) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5090080881909548882) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5072068278894473758) ) ) {
                            result[0] += 0.0004133310782251624;
                          } else {
                            result[0] += -0.0030306106712498027;
                          }
                        } else {
                          result[0] += 0.001801875466836069;
                        }
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5645244997236181783) ) ) {
                          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.178455187992527714) ) ) {
                            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5392784256532664466) ) ) {
                              result[0] += -0.0016062436080832312;
                            } else {
                              result[0] += -0.0044411700946604986;
                            }
                          } else {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2273413669989351737) ) ) {
                              result[0] += 0.0031847245133128648;
                            } else {
                              result[0] += -0.0024967056820148457;
                            }
                          }
                        } else {
                          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2379276778945206283) ) ) {
                            result[0] += 0.0009434378734220542;
                          } else {
                            result[0] += -0.003343270581943136;
                          }
                        }
                      }
                    } else {
                      result[0] += 0.0015483501273324918;
                    }
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6002093903220061533) ) ) {
                      result[0] += -0.006743117352295943;
                    } else {
                      result[0] += -0.0017321941380666571;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8030059940338053481) ) ) {
                    result[0] += 0.0021769068058551328;
                  } else {
                    result[0] += 0.0007007540829994248;
                  }
                }
              } else {
                result[0] += -0.004838597988928371;
              }
            } else {
              result[0] += 0.0012823997489648602;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
              result[0] += -1.6193929845271519e-06;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                  result[0] += -1.6193929845271519e-06;
                } else {
                  result[0] += -1.6193929845271519e-06;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                    result[0] += -1.6193929845271519e-06;
                  } else {
                    result[0] += -1.6193929845271519e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                    result[0] += -1.6193929845271519e-06;
                  } else {
                    result[0] += -1.6193929845271519e-06;
                  }
                }
              }
            }
          } else {
            result[0] += -1.7030080850930856e-06;
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
            result[0] += 1.1420143667647973e-06;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.16821429881140601) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5673593061306533292) ) ) {
                result[0] += -4.207757637752363e-06;
              } else {
                result[0] += -1.6998261959373212e-05;
              }
            } else {
              result[0] += 5.512504132550189e-07;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                    result[0] += -1.6193929845271519e-06;
                  } else {
                    result[0] += -1.6193929845271519e-06;
                  }
                } else {
                  result[0] += -1.6193929845271519e-06;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -1.6193929845271519e-06;
                } else {
                  result[0] += -1.6193929845271519e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                        result[0] += -1.6193929845271519e-06;
                      } else {
                        result[0] += -1.6193929845271519e-06;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7847910031909549611) ) ) {
                        result[0] += -1.6193929845271519e-06;
                      } else {
                        result[0] += -1.6193929845271519e-06;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                          result[0] += -1.6193929845271519e-06;
                        } else {
                          result[0] += -1.6193929845271519e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                            result[0] += -1.6193929845271519e-06;
                          } else {
                            result[0] += -1.6193929845271519e-06;
                          }
                        } else {
                          result[0] += -1.6193929845271519e-06;
                        }
                      }
                    } else {
                      result[0] += -1.6193929845271519e-06;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                      result[0] += -1.6193929845271519e-06;
                    } else {
                      result[0] += -1.6193929845271519e-06;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                      result[0] += -1.6193929845271519e-06;
                    } else {
                      result[0] += -1.6193929845271519e-06;
                    }
                  }
                }
              } else {
                result[0] += -1.6193929845271519e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
              result[0] += -1.6193929845271519e-06;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                  result[0] += -1.6193929845271519e-06;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                    result[0] += -1.6193929845271519e-06;
                  } else {
                    result[0] += -1.6193929845271519e-06;
                  }
                }
              } else {
                result[0] += -1.6193929845271519e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
              result[0] += -1.6193929845271519e-06;
            } else {
              result[0] += 7.969325179760966e-08;
            }
          } else {
            result[0] += -1.6193929845271519e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.115000000000000005) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.199891832540424419) ) ) {
              result[0] += -1.4490751928779736e-05;
            } else {
              result[0] += -0.0006141253305430858;
            }
          } else {
            result[0] += 9.094013371640154e-06;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1414455000000000295) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.370731135743224804) ) ) {
              result[0] += 0.00010655882129955021;
            } else {
              result[0] += -0.0015149635160870676;
            }
          } else {
            result[0] += 0.0015497327176407344;
          }
        }
      } else {
        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.001425769706364498;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01109850000000000246) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3837516359296482826) ) ) {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.8975410753335467673) ) ) {
                result[0] += 0.0017021112320662972;
              } else {
                result[0] += -0.0008115160819676629;
              }
            } else {
              result[0] += 0.001535739527771215;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1811070000000000457) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9808239647505231362) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6650804020351760437) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5508018452917812224) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6066922323869347045) ) ) {
                      result[0] += 0.0003954958220058493;
                    } else {
                      result[0] += 0.0014610984834814878;
                    }
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6002093903220061533) ) ) {
                      result[0] += -0.006529858666307325;
                    } else {
                      result[0] += -0.00010263320341341482;
                    }
                  }
                } else {
                  result[0] += 0.001832231414888193;
                }
              } else {
                result[0] += -0.0019896483862290935;
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4931942899748744114) ) ) {
                result[0] += 0.001853190089836191;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5308132790452262384) ) ) {
                  result[0] += -0.0013200638026214925;
                } else {
                  result[0] += 0.0012608979874342726;
                }
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
              result[0] += -1.5434376326939708e-06;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                  result[0] += -1.5434376326939708e-06;
                } else {
                  result[0] += -1.5434376326939708e-06;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                    result[0] += -1.5434376326939708e-06;
                  } else {
                    result[0] += -1.5434376326939708e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                    result[0] += -1.5434376326939708e-06;
                  } else {
                    result[0] += -1.5434376326939708e-06;
                  }
                }
              }
            }
          } else {
            result[0] += -1.6231308844914248e-06;
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
            result[0] += 1.0884497880275648e-06;
          } else {
            result[0] += -2.1875686902927085e-06;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                    result[0] += -1.5434376326939708e-06;
                  } else {
                    result[0] += -1.5434376326939708e-06;
                  }
                } else {
                  result[0] += -1.5434376326939708e-06;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -1.5434376326939708e-06;
                } else {
                  result[0] += -1.5434376326939708e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                        result[0] += -1.5434376326939708e-06;
                      } else {
                        result[0] += -1.5434376326939708e-06;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7847910031909549611) ) ) {
                        result[0] += -1.5434376326939708e-06;
                      } else {
                        result[0] += -1.5434376326939708e-06;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                          result[0] += -1.5434376326939708e-06;
                        } else {
                          result[0] += -1.5434376326939708e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                            result[0] += -1.5434376326939708e-06;
                          } else {
                            result[0] += -1.5434376326939708e-06;
                          }
                        } else {
                          result[0] += -1.5434376326939708e-06;
                        }
                      }
                    } else {
                      result[0] += -1.5434376326939708e-06;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                      result[0] += -1.5434376326939708e-06;
                    } else {
                      result[0] += -1.5434376326939708e-06;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                      result[0] += -1.5434376326939708e-06;
                    } else {
                      result[0] += -1.5434376326939708e-06;
                    }
                  }
                }
              } else {
                result[0] += -1.5434376326939708e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
              result[0] += -1.5434376326939708e-06;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                  result[0] += -1.5434376326939708e-06;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                    result[0] += -1.5434376326939708e-06;
                  } else {
                    result[0] += -1.5434376326939708e-06;
                  }
                }
              } else {
                result[0] += -1.5434376326939708e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
              result[0] += -1.5434376326939708e-06;
            } else {
              result[0] += 7.595535183331079e-08;
            }
          } else {
            result[0] += -1.5434376326939708e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9850000000000000977) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4850000000000000422) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4702452205161443133) ) ) {
            result[0] += 0.0004660953342031823;
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.469327283602055445) ) ) {
              result[0] += -0.0009712232072439752;
            } else {
              result[0] += -7.514631276305867e-06;
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4100284358542713448) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.545000000000000151) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6850000000000001643) ) ) {
                result[0] += -0.002694641400938435;
              } else {
                result[0] += 0.00015865834847943912;
              }
            } else {
              if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4008331129359999911) ) ) {
                result[0] += 6.579201544628719e-05;
              } else {
                result[0] += -0.0030097098023094304;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2450759342279490716) ) ) {
                result[0] += 0.001159677668390667;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4751828078391960308) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02264200000000000587) ) ) {
                    result[0] += -0.0019622848814418383;
                  } else {
                    result[0] += 0.0007457415401069769;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6650804020351760437) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5416614654131287621) ) ) {
                      if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2328444889043961574) ) ) {
                        result[0] += -0.0011524233834633423;
                      } else {
                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07127303416489440269) ) ) {
                          result[0] += 0.0009349295213447309;
                        } else {
                          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5917931336432161737) ) ) {
                            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                              result[0] += -0.004644971656303797;
                            } else {
                              result[0] += -0.0007430927500775525;
                            }
                          } else {
                            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6642917660552764003) ) ) {
                              result[0] += 0.0011189783458243113;
                            } else {
                              result[0] += -0.0010032869484396763;
                            }
                          }
                        }
                      }
                    } else {
                      result[0] += -0.0023379274582254147;
                    }
                  } else {
                    result[0] += 0.0009312429865229408;
                  }
                }
              }
            } else {
              result[0] += -0.00042799824515372557;
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0013588959822501308;
        } else {
          result[0] += 0.0007662472188951084;
        }
      }
    }
  }
}

