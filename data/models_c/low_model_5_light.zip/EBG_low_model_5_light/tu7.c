
#include "header.h"

void predict_unit7(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -4.209291711896537e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -4.209291711896537e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                result[0] += -4.209291711896537e-06;
              } else {
                result[0] += -4.209291711896537e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006452000000000001137) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5687531224874372571) ) ) {
              result[0] += 1.6570409081833694e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6635233717587941671) ) ) {
                result[0] += -2.324283430445481e-05;
              } else {
                result[0] += 4.154303702656714e-07;
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1643367459977091716) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5041457217085428821) ) ) {
                result[0] += -1.5613928629051031e-06;
              } else {
                result[0] += -6.441439420450766e-05;
              }
            } else {
              result[0] += 7.529235474677541e-07;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -4.209291711896537e-06;
              } else {
                result[0] += -4.209291711896537e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -4.209291711896537e-06;
                  } else {
                    result[0] += -4.209291711896537e-06;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -4.209291711896537e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -4.209291711896537e-06;
                        } else {
                          result[0] += -4.209291711896537e-06;
                        }
                      } else {
                        result[0] += -4.209291711896537e-06;
                      }
                    }
                  } else {
                    result[0] += -4.209291711896537e-06;
                  }
                }
              } else {
                result[0] += -4.209291711896537e-06;
              }
            }
          } else {
            result[0] += -4.209291711896537e-06;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -4.209291711896537e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -4.209291711896537e-06;
                } else {
                  result[0] += -4.209291711896537e-06;
                }
              } else {
                result[0] += -4.209291711896537e-06;
              }
            } else {
              result[0] += -4.209291711896537e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03500000000000001027) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.883880929790755059e-06) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
                result[0] += 9.636091444052966e-06;
              } else {
                result[0] += -0.00012500061000322854;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.314196657149456993) ) ) {
                result[0] += -7.000912972740762e-05;
              } else {
                result[0] += -3.838731587159611e-06;
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.723113719091885043) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4529241356532663354) ) ) {
                      result[0] += -0.0002481476536132297;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5041457217085428821) ) ) {
                        result[0] += 0.0004282735558935326;
                      } else {
                        result[0] += -7.421221646531377e-06;
                      }
                    }
                  } else {
                    result[0] += -1.4276922361343214e-05;
                  }
                } else {
                  result[0] += 1.239753282127699e-05;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.121680358022378199) ) ) {
                  result[0] += -4.7718253215072546e-05;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.249304608119721216) ) ) {
                    result[0] += 0.00010005838674211283;
                  } else {
                    result[0] += 2.0681639701017554e-05;
                  }
                }
              }
            } else {
              result[0] += -5.119091515696624e-06;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02577363736079425413) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0240756843176193544) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1711110322396684202) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06008500000000000646) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03018900000000000403) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6150000000000001021) ) ) {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5550000000000001599) ) ) {
                        result[0] += 8.395152378279433e-05;
                      } else {
                        result[0] += -0.00028447926128622754;
                      }
                    } else {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7350000000000000977) ) ) {
                        result[0] += 0.001006915739804087;
                      } else {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7650000000000001243) ) ) {
                          result[0] += -0.0005268171945848571;
                        } else {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8150000000000000577) ) ) {
                            result[0] += 0.000622465263262996;
                          } else {
                            result[0] += -4.0897350542317977e-05;
                          }
                        }
                      }
                    }
                  } else {
                    result[0] += 0.0014846479442382923;
                  }
                } else {
                  result[0] += -0.0005397660651964204;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6050000000000000933) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5050000000000001155) ) ) {
                    result[0] += 4.652660097812667e-06;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.039722088301102687) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5150000000000001243) ) ) {
                        result[0] += 0.0021004558273999808;
                      } else {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5250000000000001332) ) ) {
                          result[0] += -0.0008078849763255804;
                        } else {
                          result[0] += 0.0004461961644820971;
                        }
                      }
                    } else {
                      result[0] += 0.0013057940963423066;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6850000000000001643) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6650000000000001465) ) ) {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6550000000000001377) ) ) {
                        result[0] += -0.00024813098517656993;
                      } else {
                        result[0] += 0.0005751213785359645;
                      }
                    } else {
                      result[0] += -0.0002031156739455384;
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8350000000000000755) ) ) {
                      result[0] += 0.00016112627591408408;
                    } else {
                      result[0] += -0.00012945906088032526;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2350000000000000144) ) ) {
                result[0] += 0.00012023178706379595;
              } else {
                result[0] += -0.0005392549117773471;
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.194581012612933923) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0683765000000000206) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05185700000000000726) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7250000000000000888) ) ) {
                    result[0] += 0.00019132217934080553;
                  } else {
                    result[0] += 0.0012648673642082146;
                  }
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05860550000000001175) ) ) {
                    result[0] += -0.0007374588920808995;
                  } else {
                    result[0] += 0.000599115467938887;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1507499186893259402) ) ) {
                  result[0] += 0.001890568210259414;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5920309527638191183) ) ) {
                    result[0] += -0.0008581841482858994;
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04477003072051350535) ) ) {
                      result[0] += 0.00012637934245853162;
                    } else {
                      result[0] += 0.0018352073625516239;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8022705390703518402) ) ) {
                result[0] += -0.0011678182479037994;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.540399458636966701) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005473500000000000067) ) ) {
                    result[0] += -0.00012357791524071228;
                  } else {
                    result[0] += 0.0006867105047016809;
                  }
                } else {
                  result[0] += 0.0005561278367972239;
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00583050000000000148) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008506177121675452882) ) ) {
              result[0] += 0.0015797474387045393;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3687216492462311868) ) ) {
                result[0] += 0.002224303689395581;
              } else {
                result[0] += 0.0023448951477564317;
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021562361187840079) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4931942899748744114) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4129968667336683663) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03409611752714010457) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01351316588546045208) ) ) {
                        result[0] += -0.00048682677266611733;
                      } else {
                        result[0] += 0.001764924173119727;
                      }
                    } else {
                      result[0] += -0.001019015371847174;
                    }
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02159955403810970287) ) ) {
                      result[0] += 0.00017912219502840628;
                    } else {
                      result[0] += 0.0020111403865383784;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
                    result[0] += -0.0006671801589645999;
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03350035677887956004) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5455059598241206453) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5353359946984925788) ) ) {
                          result[0] += -0.00014441550427991083;
                        } else {
                          result[0] += -0.0014523619871384158;
                        }
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5701775282412061552) ) ) {
                          result[0] += 0.002590352999318579;
                        } else {
                          result[0] += -0.000502192791934042;
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5361772370603016258) ) ) {
                        result[0] += 0.002018073850898277;
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5494686760804020631) ) ) {
                          result[0] += -0.001253396812395118;
                        } else {
                          result[0] += 0.0010749523102163063;
                        }
                      }
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7875164333668343009) ) ) {
                  result[0] += 0.0018227868662383183;
                } else {
                  result[0] += -0.0001257942312094614;
                }
              }
            } else {
              result[0] += 0.0018371857027466353;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.234744531431348824) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09956041386891252565) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
                result[0] += 0.0023863315105222306;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01881166515770610337) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02251500000000000376) ) ) {
                    result[0] += 0.002402157554896577;
                  } else {
                    result[0] += -0.0008595295921134207;
                  }
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01287800000000000229) ) ) {
                    result[0] += 0.0022099942422549477;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4734952854020100799) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4575776583165829803) ) ) {
                        result[0] += 0.0017634975823543845;
                      } else {
                        result[0] += 0.0011696796859767518;
                      }
                    } else {
                      result[0] += 0.001781091062835297;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5612777274623116375) ) ) {
                result[0] += -0.0013488937039531313;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8440161800932387548) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1604180000000000328) ) ) {
                    result[0] += 0.0018594781332687568;
                  } else {
                    result[0] += 0.0007865274391370818;
                  }
                } else {
                  result[0] += -5.879402624533896e-05;
                }
              }
            }
          } else {
            result[0] += 0.002460785993200736;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -4.041742349496123e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -4.041742349496123e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                result[0] += -4.041742349496123e-06;
              } else {
                result[0] += -4.041742349496123e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1643367459977091716) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006452000000000001137) ) ) {
              result[0] += 8.641070911645282e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5041457217085428821) ) ) {
                result[0] += -1.4992421742520002e-06;
              } else {
                result[0] += -6.185040210867084e-05;
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
              result[0] += 1.9141687552169354e-06;
            } else {
              result[0] += -1.2303144728220963e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -4.041742349496123e-06;
              } else {
                result[0] += -4.041742349496123e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -4.041742349496123e-06;
                  } else {
                    result[0] += -4.041742349496123e-06;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -4.041742349496123e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -4.041742349496123e-06;
                        } else {
                          result[0] += -4.041742349496123e-06;
                        }
                      } else {
                        result[0] += -4.041742349496123e-06;
                      }
                    }
                  } else {
                    result[0] += -4.041742349496123e-06;
                  }
                }
              } else {
                result[0] += -4.041742349496123e-06;
              }
            }
          } else {
            result[0] += -4.041742349496123e-06;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -4.041742349496123e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -4.041742349496123e-06;
                } else {
                  result[0] += -4.041742349496123e-06;
                }
              } else {
                result[0] += -4.041742349496123e-06;
              }
            } else {
              result[0] += -4.041742349496123e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02500000000000000486) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1450000000000000455) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.723113719091885043) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.121680358022378199) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4389499174623116007) ) ) {
                    result[0] += 0.00029957003187774906;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4693879269597989734) ) ) {
                      result[0] += -0.00015443859514236403;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6047319804020101497) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5748180127889448432) ) ) {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5478500007788945636) ) ) {
                            if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.02125964230697484705) ) ) {
                              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.08377477200961473691) ) ) {
                                result[0] += 0.0003501306516599764;
                              } else {
                                result[0] += -0.0002363697677693051;
                              }
                            } else {
                              result[0] += 0.00026489044621827613;
                            }
                          } else {
                            result[0] += -1.9525373436285865e-05;
                          }
                        } else {
                          result[0] += 4.6547920585759214e-05;
                        }
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9112103514676580529) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8377933889099087317) ) ) {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6208328749497488142) ) ) {
                              result[0] += -7.294095949291226e-05;
                            } else {
                              result[0] += -1.155236681539668e-05;
                            }
                          } else {
                            result[0] += -5.6505754850307324e-05;
                          }
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7478339930150754711) ) ) {
                            result[0] += 0.00019100387873888805;
                          } else {
                            result[0] += -8.395835612624115e-06;
                          }
                        }
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.125515493975159704e-06) ) ) {
                    result[0] += -1.0262420005716161e-05;
                  } else {
                    result[0] += 1.0743883775261317e-06;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.121680358022378199) ) ) {
                  result[0] += -4.581884508461428e-05;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
                    result[0] += 0.000197271787462737;
                  } else {
                    result[0] += 1.072947356807044e-05;
                  }
                }
              }
            } else {
              result[0] += -4.80342857299738e-06;
            }
          } else {
            result[0] += 0.0009329424277052627;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1127930000000000182) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1301603066321575797) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1149262718553918233) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08404042173159891049) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05701962466675345592) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0119121105025029022) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.903059230149356746e-07) ) ) {
                        result[0] += 0.0004707757604063339;
                      } else {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.175366324986798601e-07) ) ) {
                          result[0] += -7.378573407924147e-05;
                        } else {
                          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.038494786985569569e-06) ) ) {
                            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.794554612313755398e-06) ) ) {
                              result[0] += 7.339207455466736e-05;
                            } else {
                              result[0] += 0.00044779733324591046;
                            }
                          } else {
                            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.381175493840676405e-06) ) ) {
                              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.835029170797551251e-06) ) ) {
                                result[0] += -1.3621280692711725e-07;
                              } else {
                                result[0] += -0.00020034058862167855;
                              }
                            } else {
                              result[0] += 6.770196731493193e-06;
                            }
                          }
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01326604349644140181) ) ) {
                        result[0] += 0.0006004365948986307;
                      } else {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01376440091032050082) ) ) {
                          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01351316588546045208) ) ) {
                            result[0] += -4.1495565173533375e-05;
                          } else {
                            result[0] += -0.0005115731406235668;
                          }
                        } else {
                          result[0] += 0.0001487266280962188;
                        }
                      }
                    }
                  } else {
                    result[0] += -9.875710178390666e-05;
                  }
                } else {
                  result[0] += 0.00098943651371291;
                }
              } else {
                result[0] += -0.0006378876107962758;
              }
            } else {
              result[0] += 0.0010797200410619073;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
              result[0] += 0.0008519644969501914;
            } else {
              result[0] += -0.00037315786100293225;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021562361187840079) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005473500000000000067) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008506177121675452882) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006290243127013950622) ) ) {
                result[0] += 0.0018350274591112613;
              } else {
                result[0] += -0.001016742268742027;
              }
            } else {
              result[0] += 0.0022338589287654318;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2932818109908455484) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08407783631914581002) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01351316588546045208) ) ) {
                      result[0] += -6.108355718744424e-05;
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01650738594486505367) ) ) {
                        result[0] += 0.003192654560807075;
                      } else {
                        result[0] += 0.0011689594891788242;
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1051257686552766607) ) ) {
                      result[0] += -0.0022154237599783327;
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
                        result[0] += 0.0019018094489282405;
                      } else {
                        result[0] += -0.00021387489410214786;
                      }
                    }
                  }
                } else {
                  result[0] += -0.0025296993550889685;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7003595884880823297) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6717423563567840317) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6359282793467337935) ) ) {
                      result[0] += 0.0025458435616197124;
                    } else {
                      result[0] += 0.00028187073128934964;
                    }
                  } else {
                    result[0] += 0.002818825831375316;
                  }
                } else {
                  result[0] += 0.0004378011879094269;
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3278371989949749321) ) ) {
                result[0] += 0.002291344431832958;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
                  result[0] += -0.00035277228772890554;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01905700000000000102) ) ) {
                    result[0] += 0.0021144592304450883;
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08965900000000000258) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06646350000000002256) ) ) {
                        result[0] += 0.0011487316799140244;
                      } else {
                        result[0] += -4.71529881833032e-05;
                      }
                    } else {
                      result[0] += 0.0017050197359786466;
                    }
                  }
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.234744531431348824) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1254545000000000243) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6558660377084782889) ) ) {
                result[0] += 0.0020735756166805953;
              } else {
                result[0] += 0.0005207263725782736;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1773295000000000288) ) ) {
                result[0] += -0.0002059930420417172;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3251271839107726103) ) ) {
                  result[0] += 0.002164071137273535;
                } else {
                  result[0] += -9.452894202237485e-05;
                }
              }
            }
          } else {
            result[0] += 0.0023628352802578956;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -3.880862229990291e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.880862229990291e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                result[0] += -3.880862229990291e-06;
              } else {
                result[0] += -3.880862229990291e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08693186820944626136) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5041457217085428821) ) ) {
              result[0] += 1.4199521357209314e-05;
            } else {
              result[0] += -5.731893974774073e-05;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6269974968039345731) ) ) {
              result[0] += 1.7986025646185676e-06;
            } else {
              result[0] += -1.16895582851273e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -3.880862229990291e-06;
              } else {
                result[0] += -3.880862229990291e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -3.880862229990291e-06;
                  } else {
                    result[0] += -3.880862229990291e-06;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -3.880862229990291e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -3.880862229990291e-06;
                        } else {
                          result[0] += -3.880862229990291e-06;
                        }
                      } else {
                        result[0] += -3.880862229990291e-06;
                      }
                    }
                  } else {
                    result[0] += -3.880862229990291e-06;
                  }
                }
              } else {
                result[0] += -3.880862229990291e-06;
              }
            }
          } else {
            result[0] += -3.880862229990291e-06;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -3.880862229990291e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -3.880862229990291e-06;
                } else {
                  result[0] += -3.880862229990291e-06;
                }
              } else {
                result[0] += -3.880862229990291e-06;
              }
            } else {
              result[0] += -3.880862229990291e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.115000000000000005) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.768269948548106596) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.729199597233659459e-06) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7601236426381910993) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7463838234422112139) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7292744312814071206) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6577150591959800563) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6299505656030152112) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6077784371608041525) ) ) {
                          result[0] += -1.0804801405638659e-05;
                        } else {
                          result[0] += 0.00018504967279005496;
                        }
                      } else {
                        result[0] += -7.843925729369091e-05;
                      }
                    } else {
                      result[0] += 4.819385299537075e-05;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7397481077386934833) ) ) {
                      result[0] += -0.00010385892470055675;
                    } else {
                      result[0] += 1.0076728383150337e-05;
                    }
                  }
                } else {
                  result[0] += 4.701121518901655e-05;
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                  result[0] += -5.321671438181738e-06;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.690815535104635854e-06) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.052300094327177008e-06) ) ) {
                      result[0] += -3.7883535887002936e-06;
                    } else {
                      result[0] += 0.0004509459674389889;
                    }
                  } else {
                    result[0] += -7.316859705585544e-05;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1050000000000000239) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.0442771331626926e-05) ) ) {
                  result[0] += 1.1331592041229034e-05;
                } else {
                  result[0] += -5.414792332332116e-07;
                }
              } else {
                result[0] += -0.00032655520994160855;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8917151133668342888) ) ) {
              result[0] += -5.4244843484648614e-05;
            } else {
              result[0] += -2.7212836447655713e-06;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.168924500000000033) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0816878293504414571) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.310012234630710122e-06) ) ) {
                result[0] += -0.00014709030271282863;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.038494786985569569e-06) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.25500000000000006) ) ) {
                      result[0] += 3.82457104797789e-05;
                    } else {
                      result[0] += 0.0017669297555769244;
                    }
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0119121105025029022) ) ) {
                      result[0] += 2.0489280874544055e-05;
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01210357511382575101) ) ) {
                        result[0] += 0.0013340246763413953;
                      } else {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1250000000000000278) ) ) {
                          result[0] += 0.001443347155128995;
                        } else {
                          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0173600348455768029) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.29500000000000004) ) ) {
                              result[0] += -0.00011688042915906886;
                            } else {
                              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5550000000000001599) ) ) {
                                result[0] += 0.0008700468846968882;
                              } else {
                                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.625000000000000111) ) ) {
                                  result[0] += -0.0006288377976677968;
                                } else {
                                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.795000000000000151) ) ) {
                                    result[0] += 0.0010083392573981512;
                                  } else {
                                    result[0] += 0.00010674686564444668;
                                  }
                                }
                              }
                            }
                          } else {
                            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5650000000000000577) ) ) {
                              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4850000000000000422) ) ) {
                                result[0] += 9.385218396717099e-05;
                              } else {
                                result[0] += -0.00029722532633290983;
                              }
                            } else {
                              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5850000000000000755) ) ) {
                                result[0] += 0.0019793624736115416;
                              } else {
                                result[0] += 0.0003407180284445095;
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04756785543737290789) ) ) {
                    result[0] += 2.1693831423676783e-05;
                  } else {
                    result[0] += -0.0006905459907104714;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2326999203141443262) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1044543990012605922) ) ) {
                  result[0] += 0.0007023361296336788;
                } else {
                  result[0] += 0.0019305002305812311;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4287309711685468594) ) ) {
                  result[0] += -0.00045290265132713755;
                } else {
                  result[0] += 0.0005947342077957083;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05964584249592785187) ) ) {
              result[0] += 0.0021282268087882287;
            } else {
              result[0] += 0.0007915705727893152;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021562361187840079) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01595548253114795548) ) ) {
              result[0] += 0.0016060391730675018;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
                result[0] += 0.0017284324849994787;
              } else {
                result[0] += 0.0020863383646772854;
              }
            }
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
              result[0] += 0.002231799084279426;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0184998371148766029) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1405997886577425304) ) ) {
                  result[0] += -8.140456345426049e-05;
                } else {
                  result[0] += -0.001648626861743493;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02192319026750580435) ) ) {
                  result[0] += 0.002238801992904357;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08693186820944626136) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4093335132160804135) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1127930000000000182) ) ) {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03389850000000000502) ) ) {
                          result[0] += 0.0006359950306076504;
                        } else {
                          result[0] += -0.0016087312306968676;
                        }
                      } else {
                        result[0] += 0.001923240945795924;
                      }
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02884459794480960168) ) ) {
                        result[0] += -9.135621235662379e-05;
                      } else {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0409003745630781082) ) ) {
                          result[0] += 0.002179698926663439;
                        } else {
                          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0526089167981486569) ) ) {
                            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04756785543737290789) ) ) {
                              result[0] += 0.0012451912856167146;
                            } else {
                              result[0] += -0.0013225752351219598;
                            }
                          } else {
                            result[0] += 0.0016053776505634137;
                          }
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5499504253266332965) ) ) {
                      result[0] += -0.0017815750058915217;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7269841738944724518) ) ) {
                        result[0] += 0.0011934555441704073;
                      } else {
                        result[0] += -0.0001967264064939038;
                      }
                    }
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03968700000000000699) ) ) {
            result[0] += 0.0019910376753252907;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.234744531431348824) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3251271839107726103) ) ) {
                result[0] += 0.0016798849831972846;
              } else {
                result[0] += 4.895903275925076e-05;
              }
            } else {
              result[0] += 0.0023370086939140384;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -3.7263858865330326e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.7263858865330326e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                result[0] += -3.7263858865330326e-06;
              } else {
                result[0] += -3.7263858865330326e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006452000000000001137) ) ) {
            result[0] += 1.4828346085272928e-06;
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.06765554132556478306) ) ) {
              result[0] += -2.4302639751775703e-05;
            } else {
              result[0] += -1.0306446889793097e-06;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -3.7263858865330326e-06;
              } else {
                result[0] += -3.7263858865330326e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -3.7263858865330326e-06;
                  } else {
                    result[0] += -3.7263858865330326e-06;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -3.7263858865330326e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -3.7263858865330326e-06;
                        } else {
                          result[0] += -3.7263858865330326e-06;
                        }
                      } else {
                        result[0] += -3.7263858865330326e-06;
                      }
                    }
                  } else {
                    result[0] += -3.7263858865330326e-06;
                  }
                }
              } else {
                result[0] += -3.7263858865330326e-06;
              }
            }
          } else {
            result[0] += -3.7263858865330326e-06;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -3.7263858865330326e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -3.7263858865330326e-06;
                } else {
                  result[0] += -3.7263858865330326e-06;
                }
              } else {
                result[0] += -3.7263858865330326e-06;
              }
            } else {
              result[0] += -3.7263858865330326e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02500000000000000486) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1450000000000000455) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.72638075848137134e-06) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
                result[0] += -4.6484188892167714e-07;
              } else {
                result[0] += -1.3880553925041263e-05;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.723113719091885043) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4575776583165829803) ) ) {
                      result[0] += -0.00015287934242887096;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6047319804020101497) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5748180127889448432) ) ) {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4992002680402010117) ) ) {
                            result[0] += 0.0004400507097444636;
                          } else {
                            result[0] += -7.603577442829799e-06;
                          }
                        } else {
                          result[0] += 6.826903461416183e-05;
                        }
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6334213184170854882) ) ) {
                          result[0] += -7.22254472947682e-05;
                        } else {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6858832018090453841) ) ) {
                              result[0] += 2.2947802006194485e-06;
                            } else {
                              result[0] += -2.8215725324585932e-05;
                            }
                          } else {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
                              result[0] += 0.00015647859147188285;
                            } else {
                              result[0] += -1.2067887992611302e-05;
                            }
                          }
                        }
                      }
                    }
                  } else {
                    result[0] += -1.1941202163223285e-05;
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.121680358022378199) ) ) {
                    result[0] += -4.39734888318798e-05;
                  } else {
                    result[0] += 6.0439502200699065e-05;
                  }
                }
              } else {
                result[0] += -3.9787236345750436e-06;
              }
            }
          } else {
            result[0] += 0.0008958285389299841;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.168924500000000033) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1301603066321575797) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.96280210579579717) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.373325504271297691e-06) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                    result[0] += -8.087128210498484e-05;
                  } else {
                    result[0] += 0.0001795101871150246;
                  }
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.038494786985569569e-06) ) ) {
                    result[0] += 0.00022353845969682318;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01148539754569130079) ) ) {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.690815535104635854e-06) ) ) {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                            result[0] += -0.00010381110565512279;
                          } else {
                            result[0] += -0.00011778750705332801;
                          }
                        } else {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01127328256994905228) ) ) {
                            result[0] += 2.8898905926088622e-05;
                          } else {
                            result[0] += -0.0008075985806067702;
                          }
                        }
                      } else {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01231177969451185093) ) ) {
                          result[0] += 0.0006099762066827368;
                        } else {
                          result[0] += 0.0002077505448156257;
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8466324982590252013) ) ) {
                        result[0] += -0.00032082005342775135;
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.723113719091885043) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
                            result[0] += -8.091196500430018e-06;
                          } else {
                            result[0] += -0.00024051349842383422;
                          }
                        } else {
                          result[0] += 0.00025186739446405606;
                        }
                      }
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008157865216470052208) ) ) {
                  result[0] += 0.00018362975835981243;
                } else {
                  result[0] += -0.000776911473361674;
                }
              }
            } else {
              result[0] += 0.0010085552448407826;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05964584249592785187) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04247438584267165113) ) ) {
                result[0] += 0.0003970101981968685;
              } else {
                result[0] += 0.003477146009639411;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9993516786272610419) ) ) {
                result[0] += 0.001002824517917751;
              } else {
                result[0] += -0.0002623370585089461;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021562361187840079) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005473500000000000067) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008506177121675452882) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3457619648241206378) ) ) {
                result[0] += -0.0002667165909962116;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006290243127013950622) ) ) {
                  result[0] += 0.002480895424982755;
                } else {
                  result[0] += -0.001053160810849329;
                }
              }
            } else {
              result[0] += 0.0020618950090602337;
            }
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
              result[0] += 0.002143097425205494;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2932818109908455484) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08407783631914581002) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4129968667336683663) ) ) {
                        if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4601878067544193374) ) ) {
                          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03409611752714010457) ) ) {
                            result[0] += 0.0016899044299999969;
                          } else {
                            result[0] += -0.00019354151212683037;
                          }
                        } else {
                          result[0] += -0.002369081188935954;
                        }
                      } else {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02661305910200095423) ) ) {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4797597438944724013) ) ) {
                            result[0] += 0.0014404055961631582;
                          } else {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5284121414321608645) ) ) {
                              result[0] += -0.0003930770250908362;
                            } else {
                              result[0] += 0.0017915522661367592;
                            }
                          }
                        } else {
                          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1711110322396684202) ) ) {
                            result[0] += 0.0018455609003194412;
                          } else {
                            result[0] += 0.0013967295161180842;
                          }
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5449942632663317132) ) ) {
                        result[0] += -0.0033935655524255136;
                      } else {
                        result[0] += 0.0006858992237163542;
                      }
                    }
                  } else {
                    result[0] += -0.002476510644527963;
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5508018452917812224) ) ) {
                    result[0] += 0.0022116874331296705;
                  } else {
                    result[0] += 0.0008619868180686054;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
                  result[0] += -0.0006030655734592613;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
                    result[0] += 0.0020965490763208187;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1534042965400678749) ) ) {
                      result[0] += 0.0012696689332701064;
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2564454682769619631) ) ) {
                        result[0] += -0.0006530122312234634;
                      } else {
                        result[0] += 0.0006820554360308403;
                      }
                    }
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03968700000000000699) ) ) {
            result[0] += 0.0019117851274267643;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3251271839107726103) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.234744531431348824) ) ) {
                result[0] += 0.001613017757757612;
              } else {
                result[0] += 0.0022491828409770716;
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4364163272837385255) ) ) {
                result[0] += -0.0013542779018298103;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2646734959245704566) ) ) {
                  result[0] += 0.00037269085380008246;
                } else {
                  result[0] += 0.002220028012133263;
                }
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -3.578058419091913e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.578058419091913e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                result[0] += -3.578058419091913e-06;
              } else {
                result[0] += -3.578058419091913e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006452000000000001137) ) ) {
            result[0] += 1.4238109033034812e-06;
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.06765554132556478306) ) ) {
              result[0] += -2.3335281803276016e-05;
            } else {
              result[0] += -9.896202429872086e-07;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -3.578058419091913e-06;
              } else {
                result[0] += -3.578058419091913e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -3.578058419091913e-06;
                  } else {
                    result[0] += -3.578058419091913e-06;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -3.578058419091913e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -3.578058419091913e-06;
                        } else {
                          result[0] += -3.578058419091913e-06;
                        }
                      } else {
                        result[0] += -3.578058419091913e-06;
                      }
                    }
                  } else {
                    result[0] += -3.578058419091913e-06;
                  }
                }
              } else {
                result[0] += -3.578058419091913e-06;
              }
            }
          } else {
            result[0] += -3.578058419091913e-06;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -3.578058419091913e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -3.578058419091913e-06;
                } else {
                  result[0] += -3.578058419091913e-06;
                }
              } else {
                result[0] += -3.578058419091913e-06;
              }
            } else {
              result[0] += -3.578058419091913e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03500000000000001027) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.716605685555453681e-07) ) ) {
            result[0] += -4.066510595738999e-05;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.723113719091885043) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6858832018090453841) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6055650374709939943) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.543101476988260834) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3561404984221285264) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3115605993075549196) ) ) {
                          result[0] += -4.806638067779396e-06;
                        } else {
                          result[0] += -6.96939593011188e-05;
                        }
                      } else {
                        result[0] += 3.3684025970350665e-05;
                      }
                    } else {
                      result[0] += -0.00016412111081603225;
                    }
                  } else {
                    result[0] += 0.00043510290261862273;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.714147492562814179) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6754021834779359024) ) ) {
                      result[0] += -0.00010865340265181226;
                    } else {
                      result[0] += -5.1165530787264946e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9567162861906464144) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7218051716834171794) ) ) {
                          result[0] += 1.7160926247477076e-05;
                        } else {
                          result[0] += -0.00019481827360279158;
                        }
                      } else {
                        result[0] += 2.9355251637722772e-06;
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7478339930150754711) ) ) {
                        result[0] += 0.00014778030472739195;
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7753767533919598831) ) ) {
                          result[0] += -2.1199084515987807e-05;
                        } else {
                          result[0] += -6.826168956205638e-06;
                        }
                      }
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.121680358022378199) ) ) {
                  result[0] += -4.2223139718398294e-05;
                } else {
                  result[0] += 6.0529467586880764e-05;
                }
              }
            } else {
              result[0] += -3.5779591596122774e-06;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1301603066321575797) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.168924500000000033) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.701692321267631473e-05) ) ) {
                  result[0] += -5.839064479097303e-06;
                } else {
                  result[0] += 0.0006002036552036498;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01148539754569130079) ) ) {
                    result[0] += 7.663213326641807e-06;
                  } else {
                    result[0] += 0.0002095681169372787;
                  }
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008157865216470052208) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005972045269192751034) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.552189803348073886e-06) ) ) {
                        result[0] += 0.00017902654308219238;
                      } else {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.125515493975159704e-06) ) ) {
                          result[0] += -0.0002870597111816628;
                        } else {
                          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.578971790991679312e-05) ) ) {
                            result[0] += 0.00042796343110938946;
                          } else {
                            result[0] += -7.753585749592062e-05;
                          }
                        }
                      }
                    } else {
                      result[0] += 0.0003274210591456382;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.96280210579579717) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.723113719091885043) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8577098326317653676) ) ) {
                          result[0] += -0.0006472426388154869;
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.363906689523952442) ) ) {
                            result[0] += -2.134232477340912e-05;
                          } else {
                            result[0] += -0.00023503898235725036;
                          }
                        }
                      } else {
                        result[0] += 0.0007064447874608628;
                      }
                    } else {
                      result[0] += -0.0007511763788153927;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2271190000000000431) ) ) {
                result[0] += 0.0019169060308224326;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08404042173159891049) ) ) {
                  result[0] += 0.0010170430745883796;
                } else {
                  result[0] += -0.00027245712276132155;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2932818109908455484) ) ) {
              result[0] += 0.001327994589569202;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8377933889099087317) ) ) {
                result[0] += -0.00023844330502592126;
              } else {
                result[0] += 0.0009521560884842936;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021562361187840079) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00583050000000000148) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008506177121675452882) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3457619648241206378) ) ) {
                result[0] += -0.00017184822470925654;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4484214422864321592) ) ) {
                  result[0] += 0.0027758181230098976;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5041457217085428821) ) ) {
                    result[0] += -0.0015044272335309004;
                  } else {
                    result[0] += 0.002799669938754058;
                  }
                }
              }
            } else {
              result[0] += 0.0019788425484144343;
            }
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
              result[0] += 0.002057792192940335;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.009795390075261452625) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9550000000000000711) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00984850000000000135) ) ) {
                    result[0] += -0.000215795272959339;
                  } else {
                    result[0] += 0.0031058527904175024;
                  }
                } else {
                  if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.06765554132556478306) ) ) {
                    result[0] += 8.478345242938548e-05;
                  } else {
                    result[0] += -0.0039016756890741804;
                  }
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3837516359296482826) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03240100000000000618) ) ) {
                      result[0] += 0.0004844108952333784;
                    } else {
                      result[0] += -0.0007334956414745752;
                    }
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01172600000000000205) ) ) {
                      result[0] += 0.0015735399941621117;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5041457217085428821) ) ) {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.421180086331658321) ) ) {
                          result[0] += -0.0013756151589210221;
                        } else {
                          result[0] += 0.0014116334678279923;
                        }
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
                          result[0] += -0.0007186983485359205;
                        } else {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05473596564878090848) ) ) {
                            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
                              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5800027599246232457) ) ) {
                                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5494686760804020631) ) ) {
                                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5361772370603016258) ) ) {
                                    result[0] += 0.00046166348832770717;
                                  } else {
                                    result[0] += -0.0028204738192663817;
                                  }
                                } else {
                                  result[0] += 0.0010151531958443793;
                                }
                              } else {
                                result[0] += -0.000688044625919785;
                              }
                            } else {
                              result[0] += 0.0016908682428202306;
                            }
                          } else {
                            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06217080128912850362) ) ) {
                              result[0] += 0.0024822011271159014;
                            } else {
                              result[0] += 0.0009444459542686685;
                            }
                          }
                        }
                      }
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
                    result[0] += 0.002003670834561403;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1534042965400678749) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5400528323115579843) ) ) {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1358410000000000173) ) ) {
                          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05860550000000001175) ) ) {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3644118032412060892) ) ) {
                              result[0] += 9.832569867281535e-05;
                            } else {
                              result[0] += 0.0013839281768003473;
                            }
                          } else {
                            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08201150000000001494) ) ) {
                              result[0] += -0.0029854624710562746;
                            } else {
                              result[0] += 0.0010048224225906188;
                            }
                          }
                        } else {
                          result[0] += 0.001643146328209171;
                        }
                      } else {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03545400000000000634) ) ) {
                          result[0] += 0.0017579595528860901;
                        } else {
                          result[0] += 0.0021605643503448874;
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6059258460552764403) ) ) {
                        result[0] += -0.0012355280210686243;
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8030059940338053481) ) ) {
                          result[0] += 0.0013442441862541465;
                        } else {
                          result[0] += -0.000133611646774957;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03968700000000000699) ) ) {
            result[0] += 0.001835687199064698;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.234744531431348824) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3251271839107726103) ) ) {
                result[0] += 0.0015488121584904002;
              } else {
                result[0] += -4.127074238784944e-05;
              }
            } else {
              result[0] += 0.0021544569678491874;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -3.435635073839804e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.435635073839804e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                result[0] += -3.435635073839804e-06;
              } else {
                result[0] += -3.435635073839804e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006452000000000001137) ) ) {
            result[0] += 1.3671366157141876e-06;
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.06765554132556478306) ) ) {
              result[0] += -2.2406429194528867e-05;
            } else {
              result[0] += -9.502287605050875e-07;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -3.435635073839804e-06;
              } else {
                result[0] += -3.435635073839804e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -3.435635073839804e-06;
                  } else {
                    result[0] += -3.435635073839804e-06;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -3.435635073839804e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -3.435635073839804e-06;
                        } else {
                          result[0] += -3.435635073839804e-06;
                        }
                      } else {
                        result[0] += -3.435635073839804e-06;
                      }
                    }
                  } else {
                    result[0] += -3.435635073839804e-06;
                  }
                }
              } else {
                result[0] += -3.435635073839804e-06;
              }
            }
          } else {
            result[0] += -3.435635073839804e-06;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -3.435635073839804e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -3.435635073839804e-06;
                } else {
                  result[0] += -3.435635073839804e-06;
                }
              } else {
                result[0] += -3.435635073839804e-06;
              }
            } else {
              result[0] += -3.435635073839804e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3150000000000000577) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03500000000000001027) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.723113719091885043) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.716605685555453681e-07) ) ) {
                result[0] += -3.904644584983564e-05;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04557577292723340862) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03409611752714010457) ) ) {
                      result[0] += -4.665471958156265e-06;
                    } else {
                      result[0] += -0.00011220480760521237;
                    }
                  } else {
                    result[0] += 0.0003431190148044407;
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.121680358022378199) ) ) {
                    result[0] += -4.054246263004944e-05;
                  } else {
                    result[0] += 5.812011361600834e-05;
                  }
                }
              }
            } else {
              result[0] += -3.435539765348521e-06;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006308000000000001106) ) ) {
                result[0] += 7.610543795275211e-06;
              } else {
                result[0] += 0.0016829044831161892;
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3850000000000000644) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001683500000000000317) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008506177121675452882) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001464500000000000307) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3644118032412060892) ) ) {
                        result[0] += 0.0005015609286422615;
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4052145559547739029) ) ) {
                          result[0] += -0.001032150999339644;
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4251092621105527214) ) ) {
                            result[0] += 0.0006833185444667501;
                          } else {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5072261056783921029) ) ) {
                              result[0] += -0.00019968783614616493;
                            } else {
                              result[0] += 8.619133112428286e-06;
                            }
                          }
                        }
                      }
                    } else {
                      result[0] += -0.0002495898522418581;
                    }
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0008045000000000002019) ) ) {
                      result[0] += -0.00046708995861632067;
                    } else {
                      result[0] += 3.5304784315101065e-05;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002023500000000000559) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1950000000000000344) ) ) {
                      result[0] += 0.0005441507385370751;
                    } else {
                      result[0] += 0.0006480384819515383;
                    }
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3650000000000000466) ) ) {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3450000000000000289) ) ) {
                        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1050000000000000239) ) ) {
                          result[0] += 0.0002131936092542232;
                        } else {
                          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1450000000000000455) ) ) {
                            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                              result[0] += 1.1015254185740675e-05;
                            } else {
                              result[0] += -0.00021883549287556375;
                            }
                          } else {
                            result[0] += 0.00010417031505740664;
                          }
                        }
                      } else {
                        result[0] += -0.0003529323987349172;
                      }
                    } else {
                      result[0] += 0.0007109995571590396;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4450000000000000622) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
                    result[0] += 0.0007373654627896305;
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03468100000000001043) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01415250000000000188) ) ) {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005259500000000001153) ) ) {
                          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001751500000000000236) ) ) {
                            result[0] += -7.940395058569932e-05;
                          } else {
                            result[0] += -0.0008744248649570673;
                          }
                        } else {
                          result[0] += 0.0004400084094182244;
                        }
                      } else {
                        result[0] += -0.0012345232413877554;
                      }
                    } else {
                      result[0] += 9.07263638541406e-05;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4797597438944724013) ) ) {
                    result[0] += 0.0005116689493429908;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02032228342586875347) ) ) {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01376440091032050082) ) ) {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005814890055470450791) ) ) {
                          result[0] += -0.00022216455350811373;
                        } else {
                          result[0] += 0.0005868813611282066;
                        }
                      } else {
                        result[0] += -0.0005847926245773845;
                      }
                    } else {
                      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5050000000000001155) ) ) {
                        result[0] += 0.0008597006417647203;
                      } else {
                        result[0] += -9.915460272088803e-06;
                      }
                    }
                  }
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1513805188710139749) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9808239647505231362) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003965500000000001142) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006782232836504950395) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002895500000000000504) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.310012234630710122e-06) ) ) {
                      result[0] += -0.0003113736101824904;
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.038494786985569569e-06) ) ) {
                        result[0] += 0.002071251967322783;
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006124087708088651362) ) ) {
                          result[0] += 0.0002499378229144818;
                        } else {
                          result[0] += -0.00016509324679347953;
                        }
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5515127872864322711) ) ) {
                      result[0] += 5.891163830712583e-05;
                    } else {
                      result[0] += -0.00019177508487350483;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003504500000000000236) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3687216492462311868) ) ) {
                      result[0] += -0.0004789279475065902;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4443392717336683839) ) ) {
                        result[0] += 0.0015582969248491307;
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.505061141934673441) ) ) {
                          result[0] += -0.00022645405437877114;
                        } else {
                          result[0] += 0.0006071455614377964;
                        }
                      }
                    }
                  } else {
                    result[0] += 0.001379241932633657;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.009795390075261452625) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002867412157011550635) ) ) {
                    result[0] += 0.000725550671451476;
                  } else {
                    result[0] += -0.00018273676342803;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1604180000000000328) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8764371766733816127) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3569067370100503234) ) ) {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3044676633919599085) ) ) {
                            result[0] += 0.0005379633051226097;
                          } else {
                            result[0] += -0.0009701674108981217;
                          }
                        } else {
                          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1711110322396684202) ) ) {
                            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.008306500000000001382) ) ) {
                              result[0] += 0.001346254172656369;
                            } else {
                              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
                                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4814085394974874643) ) ) {
                                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
                                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4405029099497487777) ) ) {
                                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4183012963065327328) ) ) {
                                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3837516359296482826) ) ) {
                                          result[0] += 0.0011333678162888509;
                                        } else {
                                          result[0] += -0.00019628239959765132;
                                        }
                                      } else {
                                        result[0] += 0.002395128491698153;
                                      }
                                    } else {
                                      result[0] += -0.001848680031003099;
                                    }
                                  } else {
                                    result[0] += 0.0032748917531738183;
                                  }
                                } else {
                                  result[0] += -0.0010306390513778897;
                                }
                              } else {
                                result[0] += 0.00134825924649616;
                              }
                            }
                          } else {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4751828078391960308) ) ) {
                              result[0] += -0.0014050750512118702;
                            } else {
                              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.0841877145549009831) ) ) {
                                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5072261056783921029) ) ) {
                                  result[0] += 0.0012911136929016284;
                                } else {
                                  result[0] += -0.0011639441367597033;
                                }
                              } else {
                                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
                                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.51994285276381913) ) ) {
                                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.07196201389915944657) ) ) {
                                      result[0] += 0.001608166841847958;
                                    } else {
                                      result[0] += -0.0012201923254236487;
                                    }
                                  } else {
                                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5361772370603016258) ) ) {
                                      result[0] += 0.0023353293948464924;
                                    } else {
                                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5499504253266332965) ) ) {
                                        result[0] += -0.0002527965043334158;
                                      } else {
                                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.555096866909547848) ) ) {
                                          result[0] += 0.003460125920924499;
                                        } else {
                                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5719332634924624292) ) ) {
                                            result[0] += -0.00014121224029036092;
                                          } else {
                                            result[0] += 0.0013906746424291315;
                                          }
                                        }
                                      }
                                    }
                                  }
                                } else {
                                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6722423356281408413) ) ) {
                                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5018975334485012985) ) ) {
                                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4364163272837385255) ) ) {
                                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3966559369710560001) ) ) {
                                          result[0] += 0.00012645567709418233;
                                        } else {
                                          result[0] += -0.0010281419491102602;
                                        }
                                      } else {
                                        result[0] += 0.0025698653848482624;
                                      }
                                    } else {
                                      result[0] += -0.001241515142229806;
                                    }
                                  } else {
                                    result[0] += 0.0007995889570144556;
                                  }
                                }
                              }
                            }
                          }
                        }
                      } else {
                        result[0] += -0.0010342462641022374;
                      }
                    } else {
                      result[0] += 0.0013649747899825131;
                    }
                  } else {
                    result[0] += 0.0020124732232121214;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7894192122613066243) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                    result[0] += -0.0011717626485763298;
                  } else {
                    result[0] += 0.000912534025503258;
                  }
                } else {
                  result[0] += -0.0011562424123053947;
                }
              } else {
                result[0] += 7.68918841736511e-05;
              }
            }
          } else {
            result[0] += 0.0012876005791960916;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.234744531431348824) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.234671350732867934) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6541365753517588422) ) ) {
                  result[0] += 0.001549515186651051;
                } else {
                  result[0] += 0.0017277782758785885;
                }
              } else {
                result[0] += 0.0017626183217282518;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09956041386891252565) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
                  result[0] += 0.0019731956243109437;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01881166515770610337) ) ) {
                    result[0] += -0.0005158029468338665;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4734952854020100799) ) ) {
                      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.244955337349149066) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4093335132160804135) ) ) {
                          if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4999497468491173047) ) ) {
                            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6782348568386622478) ) ) {
                              result[0] += -9.316711548584049e-05;
                            } else {
                              result[0] += 0.002045374905061244;
                            }
                          } else {
                            result[0] += -0.002001900322325916;
                          }
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4405029099497487777) ) ) {
                            result[0] += 0.0021887530954759057;
                          } else {
                            result[0] += 0.00100073864143875;
                          }
                        }
                      } else {
                        result[0] += -0.00014543825542830073;
                      }
                    } else {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1494199460089949139) ) ) {
                        result[0] += 0.002113670345620658;
                      } else {
                        result[0] += 0.0012618781444659255;
                      }
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5499504253266332965) ) ) {
                  result[0] += -0.0025639003451004895;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2623980000000000756) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06508917425002432033) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5859181088693469208) ) ) {
                        result[0] += 0.002164965506659476;
                      } else {
                        result[0] += -0.00022547541348118597;
                      }
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07954367714673930834) ) ) {
                        result[0] += 0.001539693700605777;
                      } else {
                        result[0] += 0.0009838845383174648;
                      }
                    }
                  } else {
                    result[0] += -0.0001499704280384242;
                  }
                }
              }
            }
          } else {
            result[0] += -0.0010951905577504142;
          }
        } else {
          result[0] += 0.00204036410707669;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -3.298880839288786e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.298880839288786e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                result[0] += -3.298880839288786e-06;
              } else {
                result[0] += -3.298880839288786e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4781247323869347032) ) ) {
            result[0] += 3.706334423484721e-05;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02455150000000000388) ) ) {
              result[0] += 3.7173910183392833e-07;
            } else {
              result[0] += -5.325239874056431e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -3.298880839288786e-06;
              } else {
                result[0] += -3.298880839288786e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -3.298880839288786e-06;
                  } else {
                    result[0] += -3.298880839288786e-06;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -3.298880839288786e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -3.298880839288786e-06;
                        } else {
                          result[0] += -3.298880839288786e-06;
                        }
                      } else {
                        result[0] += -3.298880839288786e-06;
                      }
                    }
                  } else {
                    result[0] += -3.298880839288786e-06;
                  }
                }
              } else {
                result[0] += -3.298880839288786e-06;
              }
            }
          } else {
            result[0] += -3.298880839288786e-06;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -3.298880839288786e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -3.298880839288786e-06;
                } else {
                  result[0] += -3.298880839288786e-06;
                }
              } else {
                result[0] += -3.298880839288786e-06;
              }
            } else {
              result[0] += -3.298880839288786e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.168924500000000033) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0816878293504414571) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03500000000000001027) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.469327283602055445) ) ) {
                    result[0] += -0.000143427441800131;
                  } else {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                      result[0] += 0.0002112395932434996;
                    } else {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.07196201389915944657) ) ) {
                        result[0] += -0.00011678338940057528;
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.314196657149456993) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.121680358022378199) ) ) {
                            result[0] += -5.81359288918125e-06;
                          } else {
                            result[0] += -1.0266120687373702e-05;
                          }
                        } else {
                          result[0] += 3.7516270736091917e-06;
                        }
                      }
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += 5.7545355887800924e-05;
                  } else {
                    result[0] += 0.00028191340203694037;
                  }
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.723113719091885043) ) ) {
                  result[0] += -2.3037140893654135e-05;
                } else {
                  result[0] += -3.339190178125485e-06;
                }
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
                result[0] += 7.089323233578147e-05;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7640286906783920751) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.224356303145077041) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                      result[0] += 4.636371528777705e-05;
                    } else {
                      result[0] += 0.0007327202446193137;
                    }
                  } else {
                    result[0] += -0.0007659683775435851;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.723113719091885043) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8507017292462312197) ) ) {
                      result[0] += -3.283648387170615e-05;
                    } else {
                      result[0] += -0.0001381088009288507;
                    }
                  } else {
                    result[0] += 0.00023074379512572798;
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2326999203141443262) ) ) {
              result[0] += 0.0012249615950475988;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.543101476988260834) ) ) {
                result[0] += -0.00042412124189491714;
              } else {
                result[0] += 0.00038675050195702255;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05964584249592785187) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04247438584267165113) ) ) {
              result[0] += 0.00023050698860599864;
            } else {
              result[0] += 0.00186722614344117;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9993516786272610419) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.564198853668341882) ) ) {
                result[0] += -0.00012896727823973213;
              } else {
                result[0] += 0.003182249192134182;
              }
            } else {
              result[0] += -0.00021364720808051654;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1206324332205917643) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3837516359296482826) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6269304705026225166) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.317357466959798995) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2669585275879397535) ) ) {
                      result[0] += 0.002373059207535549;
                    } else {
                      result[0] += -0.001058738487236988;
                    }
                  } else {
                    result[0] += 0.0018680897649670525;
                  }
                } else {
                  result[0] += -0.0017493165804969108;
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005473500000000000067) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008332142139858200389) ) ) {
                    result[0] += 0.0017565301745793287;
                  } else {
                    result[0] += 0.002003558979621533;
                  }
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05473596564878090848) ) ) {
                    result[0] += 0.0004337464525416952;
                  } else {
                    result[0] += 0.0016412661019371277;
                  }
                }
              }
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
                result[0] += 0.0018655450383425786;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01108250000000000207) ) ) {
                  result[0] += 0.0017711318194560477;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5400528323115579843) ) ) {
                    result[0] += 0.0012280878543282122;
                  } else {
                    result[0] += 0.0018380415421005182;
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5612777274623116375) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2273413669989351737) ) ) {
                result[0] += -0.0011553351956686841;
              } else {
                result[0] += -0.005402647296930083;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6077784371608041525) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3763200711443456803) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5859181088693469208) ) ) {
                      result[0] += 0.0019370428361750965;
                    } else {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
                        result[0] += 0.00202227027820181;
                      } else {
                        result[0] += -0.0008684733640443783;
                      }
                    }
                  } else {
                    result[0] += -0.00218463408846549;
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5508018452917812224) ) ) {
                    result[0] += 0.0018203001648958426;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5986852915639623296) ) ) {
                      result[0] += -0.00039180652653840963;
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8440161800932387548) ) ) {
                        result[0] += 0.0015623801322483556;
                      } else {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01359050000000000188) ) ) {
                          result[0] += 0.0017581477466937876;
                        } else {
                          result[0] += -8.002144563175865e-05;
                        }
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.0010860393486318016;
              }
            }
          }
        } else {
          result[0] += 0.001959148138071931;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -3.1675700584997918e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.1675700584997918e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                result[0] += -3.1675700584997918e-06;
              } else {
                result[0] += -3.1675700584997918e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006452000000000001137) ) ) {
            result[0] += 1.2979212850338916e-06;
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.06765554132556478306) ) ) {
              result[0] += -2.123666759825115e-05;
            } else {
              result[0] += -5.003433143437873e-07;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -3.1675700584997918e-06;
              } else {
                result[0] += -3.1675700584997918e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -3.1675700584997918e-06;
                  } else {
                    result[0] += -3.1675700584997918e-06;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -3.1675700584997918e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -3.1675700584997918e-06;
                        } else {
                          result[0] += -3.1675700584997918e-06;
                        }
                      } else {
                        result[0] += -3.1675700584997918e-06;
                      }
                    }
                  } else {
                    result[0] += -3.1675700584997918e-06;
                  }
                }
              } else {
                result[0] += -3.1675700584997918e-06;
              }
            }
          } else {
            result[0] += -3.1675700584997918e-06;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -3.1675700584997918e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -3.1675700584997918e-06;
                } else {
                  result[0] += -3.1675700584997918e-06;
                }
              } else {
                result[0] += -3.1675700584997918e-06;
              }
            } else {
              result[0] += -3.1675700584997918e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.115000000000000005) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8022705390703518402) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.224356303145077041) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.966590843157139501) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1050000000000000239) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4295075599497487628) ) ) {
                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07500000000000002498) ) ) {
                          result[0] += 0.00015018767932079786;
                        } else {
                          result[0] += 0.001030847677559744;
                        }
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4529241356532663354) ) ) {
                          result[0] += -0.0002956849986748189;
                        } else {
                          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09500000000000001499) ) ) {
                            result[0] += -5.632052420098713e-06;
                          } else {
                            result[0] += 0.00011399422469609695;
                          }
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5336217185678392427) ) ) {
                        result[0] += -0.00027278808221243656;
                      } else {
                        result[0] += -0.00016280389397228443;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04500000000000000527) ) ) {
                      result[0] += 3.1010517731602825e-05;
                    } else {
                      result[0] += 0.0005279830057415596;
                    }
                  }
                } else {
                  result[0] += -2.1298017271591074e-05;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7954292854522614364) ) ) {
                  result[0] += -0.0001274701776326974;
                } else {
                  result[0] += 3.517902743486302e-06;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.180517123172382332) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.051391296366422923) ) ) {
                  result[0] += 0.000212681657796662;
                } else {
                  result[0] += -0.00011387913574113908;
                }
              } else {
                result[0] += 0.00021079240638466787;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8419399877135679278) ) ) {
              result[0] += -0.0001438182264182779;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.768269948548106596) ) ) {
                  result[0] += 7.526004144154927e-06;
                } else {
                  result[0] += -4.155987050518843e-06;
                }
              } else {
                result[0] += 0.00011745830857569494;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.168924500000000033) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.310012234630710122e-06) ) ) {
              result[0] += -0.0001292326882328775;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1301603066321575797) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5792515097236182742) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.009795390075261452625) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.038494786985569569e-06) ) ) {
                      result[0] += 0.0008057458348598753;
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.381175493840676405e-06) ) ) {
                        result[0] += -0.0005343670419174282;
                      } else {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.552189803348073886e-06) ) ) {
                          result[0] += 0.001510394098176242;
                        } else {
                          result[0] += -9.431209951802156e-06;
                        }
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5701775282412061552) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08693186820944626136) ) ) {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3644118032412060892) ) ) {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3278371989949749321) ) ) {
                            result[0] += 0.00010064890950975186;
                          } else {
                            result[0] += -0.0008916894064506528;
                          }
                        } else {
                          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1711110322396684202) ) ) {
                            result[0] += 0.0006493669348011783;
                          } else {
                            if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.0255903056102470966) ) ) {
                              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.05035649857444463723) ) ) {
                                result[0] += 0.00021429059648065684;
                              } else {
                                result[0] += -0.001213464247312721;
                              }
                            } else {
                              result[0] += 0.0006730838810438968;
                            }
                          }
                        }
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1129321246270776624) ) ) {
                          result[0] += -0.0010662513815957713;
                        } else {
                          result[0] += 0.00018783784659986326;
                        }
                      }
                    } else {
                      result[0] += 0.002173408398276179;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05721739154190200877) ) ) {
                    result[0] += -0.0006998021271166648;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5814822343216081713) ) ) {
                      result[0] += -0.00030376125945469844;
                    } else {
                      result[0] += 2.095223934865559e-05;
                    }
                  }
                }
              } else {
                result[0] += 0.0008651130649658255;
              }
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05964584249592785187) ) ) {
              result[0] += 0.0017904858551786337;
            } else {
              result[0] += 0.00035245934701861795;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0526089167981486569) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
              result[0] += 0.002882031571904976;
            } else {
              result[0] += 0.00183079090818517;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002769500000000000694) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002998483312272000063) ) ) {
                result[0] += 0.0011420128020880418;
              } else {
                result[0] += 0.0018088245478963302;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00424585153689335023) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.09893965937729458371) ) ) {
                  result[0] += 2.5563618557976828e-05;
                } else {
                  result[0] += -0.001181752591115684;
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01287800000000000229) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01397330054109465099) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4639489995477387718) ) ) {
                      result[0] += -0.000987162185142646;
                    } else {
                      result[0] += 0.0015843747480641986;
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
                      result[0] += 0.0012233315545187454;
                    } else {
                      result[0] += 0.0018154442016880795;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8440161800932387548) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04756785543737290789) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9650000000000000799) ) ) {
                          result[0] += 0.00042317275988032135;
                        } else {
                          result[0] += -0.000256736114607439;
                        }
                      } else {
                        result[0] += 0.0007901780360135962;
                      }
                    } else {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
                        result[0] += -0.0012197145669105452;
                      } else {
                        result[0] += 0.0007481279779228865;
                      }
                    }
                  } else {
                    result[0] += -0.0006617487163837982;
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02405800000000000646) ) ) {
            result[0] += 0.0016356465181804913;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.234744531431348824) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.01537695356895864805) ) ) {
                result[0] += 0.001386849916704661;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02733191529475900369) ) ) {
                  result[0] += -0.0006442509515271255;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08693186820944626136) ) ) {
                    result[0] += 0.0018534658143828499;
                  } else {
                    result[0] += 0.0001648799373715176;
                  }
                }
              }
            } else {
              result[0] += 0.0019095004078285495;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -3.0414860567281123e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.0414860567281123e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                result[0] += -3.0414860567281123e-06;
              } else {
                result[0] += -3.0414860567281123e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4781247323869347032) ) ) {
            result[0] += 3.5536387678103094e-05;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02455150000000000388) ) ) {
              result[0] += 3.589633258516178e-07;
            } else {
              result[0] += -5.0287387896674045e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -3.0414860567281123e-06;
              } else {
                result[0] += -3.0414860567281123e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -3.0414860567281123e-06;
                  } else {
                    result[0] += -3.0414860567281123e-06;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -3.0414860567281123e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -3.0414860567281123e-06;
                        } else {
                          result[0] += -3.0414860567281123e-06;
                        }
                      } else {
                        result[0] += -3.0414860567281123e-06;
                      }
                    }
                  } else {
                    result[0] += -3.0414860567281123e-06;
                  }
                }
              } else {
                result[0] += -3.0414860567281123e-06;
              }
            }
          } else {
            result[0] += -3.0414860567281123e-06;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -3.0414860567281123e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -3.0414860567281123e-06;
                } else {
                  result[0] += -3.0414860567281123e-06;
                }
              } else {
                result[0] += -3.0414860567281123e-06;
              }
            } else {
              result[0] += -3.0414860567281123e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3150000000000000577) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3850000000000000644) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001683500000000000317) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8327395279648243109) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                  result[0] += -6.891693133862083e-06;
                } else {
                  result[0] += 0.0001789825038112988;
                }
              } else {
                result[0] += -5.024951140806579e-06;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001980500000000000489) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1450000000000000455) ) ) {
                  result[0] += 0.00017211148575586337;
                } else {
                  result[0] += 0.0008611259558733297;
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3650000000000000466) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3450000000000000289) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5478500007788945636) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5179236987437186857) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5041457217085428821) ) ) {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3569067370100503234) ) ) {
                            result[0] += -0.000671046362982033;
                          } else {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.421180086331658321) ) ) {
                              result[0] += 0.0011530877958130315;
                            } else {
                              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4908111093216080412) ) ) {
                                result[0] += 4.6205868898728e-05;
                              } else {
                                result[0] += 0.0009933077888589575;
                              }
                            }
                          }
                        } else {
                          result[0] += -9.124101988171089e-05;
                        }
                      } else {
                        result[0] += 0.00045293104592382833;
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5623076833668342323) ) ) {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02615650000000000266) ) ) {
                          result[0] += -5.2505551220125195e-05;
                        } else {
                          result[0] += -0.00017263887858319022;
                        }
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5834559473869348478) ) ) {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5748180127889448432) ) ) {
                            result[0] += -6.178571665309048e-06;
                          } else {
                            result[0] += 0.0004758929300182069;
                          }
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6273136390703518694) ) ) {
                            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                              result[0] += -3.122832845251079e-05;
                            } else {
                              result[0] += -0.00036461939707743923;
                            }
                          } else {
                            result[0] += 7.845814586258188e-06;
                          }
                        }
                      }
                    }
                  } else {
                    result[0] += -0.00033410829231339236;
                  }
                } else {
                  result[0] += 0.0006594633912086235;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4450000000000000622) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                result[0] += 0.0007269050932470994;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03468100000000001043) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01415250000000000188) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005259500000000001153) ) ) {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001751500000000000236) ) ) {
                        result[0] += -7.171940963733346e-05;
                      } else {
                        result[0] += -0.0008310356898647282;
                      }
                    } else {
                      result[0] += 0.0004477599380941626;
                    }
                  } else {
                    result[0] += -0.0011823466918145756;
                  }
                } else {
                  result[0] += 8.553693010409361e-05;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01622350000000000528) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003965500000000001142) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6312254229396986327) ) ) {
                    result[0] += 0.0005319121839740264;
                  } else {
                    result[0] += -0.00020310539495139218;
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5550000000000001599) ) ) {
                    result[0] += -1.7952027325749593e-06;
                  } else {
                    result[0] += -0.0007728737201491456;
                  }
                }
              } else {
                result[0] += 0.0007602297216596312;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1301603066321575797) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9808239647505231362) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1604180000000000328) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003965500000000001142) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004867285882244350333) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00342950000000000069) ) ) {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003941149135554950639) ) ) {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.310012234630710122e-06) ) ) {
                          result[0] += -0.00020042390615285517;
                        } else {
                          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.038494786985569569e-06) ) ) {
                            result[0] += 0.001929114222194058;
                          } else {
                            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001074448343160400252) ) ) {
                                result[0] += 0.00028029744635450576;
                              } else {
                                result[0] += -9.544492664156563e-05;
                              }
                            } else {
                              result[0] += 0.0003980319600044782;
                            }
                          }
                        }
                      } else {
                        result[0] += -0.00015454381217832672;
                      }
                    } else {
                      result[0] += -0.00032694465617404643;
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003572500000000000588) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3687216492462311868) ) ) {
                        result[0] += -0.0003170928642795905;
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4295075599497487628) ) ) {
                          result[0] += 0.0013800292283063596;
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.505061141934673441) ) ) {
                            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001350500000000000355) ) ) {
                              result[0] += 0.0006220955212642905;
                            } else {
                              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002289500000000000302) ) ) {
                                result[0] += -0.0006160631534223155;
                              } else {
                                result[0] += -4.96996034425032e-05;
                              }
                            }
                          } else {
                            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6553322322110554099) ) ) {
                              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
                                result[0] += 0.0004844568155554124;
                              } else {
                                result[0] += -0.0002731423590845463;
                              }
                            } else {
                              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6722423356281408413) ) ) {
                                result[0] += 0.0009193767705125831;
                              } else {
                                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6902865188442212085) ) ) {
                                  result[0] += -0.0001261835903878428;
                                } else {
                                  result[0] += 0.0007687158187106479;
                                }
                              }
                            }
                          }
                        }
                      }
                    } else {
                      result[0] += 0.0012614919491403395;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.009795390075261452625) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002867412157011550635) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5400528323115579843) ) ) {
                        result[0] += 0.0002711414472266999;
                      } else {
                        result[0] += 0.001041460616015249;
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4405029099497487777) ) ) {
                        result[0] += -0.0017523385958478578;
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5041457217085428821) ) ) {
                          result[0] += 0.0005306409634144377;
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5400528323115579843) ) ) {
                            result[0] += -0.0008296157148701368;
                          } else {
                            result[0] += -0.00016808772493987742;
                          }
                        }
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3115605993075549196) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4183012963065327328) ) ) {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03291917222295825951) ) ) {
                          if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.629632012766062954) ) ) {
                            result[0] += 0.0016200014359549475;
                          } else {
                            result[0] += -0.0001732743806246014;
                          }
                        } else {
                          result[0] += -0.0008487659358291351;
                        }
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4405029099497487777) ) ) {
                          result[0] += 0.0014213105758461063;
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
                            result[0] += -0.00041474273283790625;
                          } else {
                            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2795185878002977575) ) ) {
                              result[0] += 0.002024178273161163;
                            } else {
                              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.244955337349149066) ) ) {
                                result[0] += -0.0012652248587224153;
                              } else {
                                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.181114681928726734) ) ) {
                                  result[0] += 0.0013393252506880297;
                                } else {
                                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.0841877145549009831) ) ) {
                                    result[0] += -0.000606504913734614;
                                  } else {
                                    result[0] += 0.0005889530084503034;
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4364163272837385255) ) ) {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03181986453917805963) ) ) {
                          result[0] += -0.00013154511394033942;
                        } else {
                          result[0] += -0.0015512146025250643;
                        }
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5018975334485012985) ) ) {
                          result[0] += 0.0017214284496444977;
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6722423356281408413) ) ) {
                            result[0] += -0.0008997120471236972;
                          } else {
                            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6503673217403566076) ) ) {
                              result[0] += 0.0019323727124916424;
                            } else {
                              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8764371766733816127) ) ) {
                                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
                                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7492319095182128352) ) ) {
                                    result[0] += -1.5787719562960414e-05;
                                  } else {
                                    result[0] += 0.0020670514040919373;
                                  }
                                } else {
                                  result[0] += -0.0010373970963874087;
                                }
                              } else {
                                result[0] += 0.0011902062508201475;
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              } else {
                result[0] += 0.0018854030144431057;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7894192122613066243) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                    result[0] += -0.001178855425676999;
                  } else {
                    result[0] += 0.000829587778492614;
                  }
                } else {
                  result[0] += -0.0013819682723375324;
                }
              } else {
                result[0] += 1.532466978791563e-05;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04928050000000000486) ) ) {
              result[0] += 0.0006877826931965136;
            } else {
              result[0] += 0.002925749826939051;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0526089167981486569) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
              result[0] += 0.0027673133282332912;
            } else {
              result[0] += 0.001757916925969124;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002769500000000000694) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002998483312272000063) ) ) {
                result[0] += 0.0010965553878864616;
              } else {
                result[0] += 0.0017368249288540816;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01397330054109465099) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3837516359296482826) ) ) {
                  result[0] += -0.0012428266119907487;
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2672247508226724966) ) ) {
                    if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3750409390474713223) ) ) {
                      result[0] += 1.8109028412783566e-05;
                    } else {
                      result[0] += 0.0027111497840489386;
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
                      result[0] += 3.7966639089226664e-05;
                    } else {
                      result[0] += -0.0010887957389437138;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01262450000000000204) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1534042965400678749) ) ) {
                    result[0] += 0.0017431903950700543;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                      result[0] += -8.842987713114657e-05;
                    } else {
                      result[0] += 0.0014676561124993656;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0409003745630781082) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03076611039958550634) ) ) {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3103100527046326884) ) ) {
                        if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4026472078210281969) ) ) {
                          result[0] += 0.0004103283545814171;
                        } else {
                          result[0] += 0.003209234293311339;
                        }
                      } else {
                        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.07196201389915944657) ) ) {
                          result[0] += -0.00040882212391665367;
                        } else {
                          result[0] += 0.0004949228100510303;
                        }
                      }
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09221529126392057074) ) ) {
                        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2177889902755587859) ) ) {
                          result[0] += 0.000604805981004241;
                        } else {
                          result[0] += 0.0013028013896247928;
                        }
                      } else {
                        result[0] += 0.0009475012583749472;
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
                      result[0] += -0.0011255184086428247;
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04756785543737290789) ) ) {
                        result[0] += 0.0013448103653132299;
                      } else {
                        result[0] += -0.00030074601627018736;
                      }
                    }
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02405800000000000646) ) ) {
            result[0] += 0.0015705401891372803;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.234744531431348824) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.01537695356895864805) ) ) {
                result[0] += 0.0013316468480667214;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02733191529475900369) ) ) {
                  result[0] += -0.0006186067710943114;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08693186820944626136) ) ) {
                    result[0] += 0.0017796892655746212;
                  } else {
                    result[0] += 0.00015831694999263572;
                  }
                }
              }
            } else {
              result[0] += 0.0018334934219190711;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -2.9204207838903364e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.9204207838903364e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                result[0] += -2.9204207838903364e-06;
              } else {
                result[0] += -2.9204207838903364e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006452000000000001137) ) ) {
            result[0] += 1.2319695812495409e-06;
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.06765554132556478306) ) ) {
              result[0] += -2.1245781470587006e-05;
            } else {
              result[0] += -9.156064096998981e-08;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -2.9204207838903364e-06;
              } else {
                result[0] += -2.9204207838903364e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -2.9204207838903364e-06;
                  } else {
                    result[0] += -2.9204207838903364e-06;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -2.9204207838903364e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -2.9204207838903364e-06;
                        } else {
                          result[0] += -2.9204207838903364e-06;
                        }
                      } else {
                        result[0] += -2.9204207838903364e-06;
                      }
                    }
                  } else {
                    result[0] += -2.9204207838903364e-06;
                  }
                }
              } else {
                result[0] += -2.9204207838903364e-06;
              }
            }
          } else {
            result[0] += -2.9204207838903364e-06;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -2.9204207838903364e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -2.9204207838903364e-06;
                } else {
                  result[0] += -2.9204207838903364e-06;
                }
              } else {
                result[0] += -2.9204207838903364e-06;
              }
            } else {
              result[0] += -2.9204207838903364e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.115000000000000005) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.234671350732867934) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.194581012612933923) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1050000000000000239) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4295075599497487628) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07500000000000002498) ) ) {
                      result[0] += 0.00013202548419202794;
                    } else {
                      result[0] += 0.0009623856481864539;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4529241356532663354) ) ) {
                      result[0] += -0.00028490917152942756;
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.166761325528187454) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7686690743216081367) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9310018456912946272) ) ) {
                            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09500000000000001499) ) ) {
                              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3561404984221285264) ) ) {
                                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3115605993075549196) ) ) {
                                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2932818109908455484) ) ) {
                                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.03945373639888280493) ) ) {
                                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.0141436144428988015) ) ) {
                                        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3103100527046326884) ) ) {
                                          result[0] += 0.0009698325215936827;
                                        } else {
                                          result[0] += -2.0768361561005018e-05;
                                        }
                                      } else {
                                        result[0] += 0.00030775181204345964;
                                      }
                                    } else {
                                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05721739154190200877) ) ) {
                                        result[0] += -0.00027318979250311496;
                                      } else {
                                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
                                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1165587384072143268) ) ) {
                                            result[0] += -1.7096035006030854e-05;
                                          } else {
                                            result[0] += 0.0002677488813814497;
                                          }
                                        } else {
                                          result[0] += -4.931965957180805e-05;
                                        }
                                      }
                                    }
                                  } else {
                                    result[0] += 0.0003783123493233669;
                                  }
                                } else {
                                  result[0] += -0.0002821092424477833;
                                }
                              } else {
                                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6055650374709939943) ) ) {
                                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3830383354773237436) ) ) {
                                      result[0] += 7.336649067115871e-05;
                                    } else {
                                      result[0] += 1.3573773749321862e-06;
                                    }
                                  } else {
                                    result[0] += 0.00037477216834699986;
                                  }
                                } else {
                                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6558660377084782889) ) ) {
                                    result[0] += -0.00012662850017467573;
                                  } else {
                                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7293493725076146683) ) ) {
                                      result[0] += 1.4704363259187989e-05;
                                    } else {
                                      result[0] += -3.6857603121595956e-05;
                                    }
                                  }
                                }
                              }
                            } else {
                              result[0] += 0.00014043213661575797;
                            }
                          } else {
                            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9567162861906464144) ) ) {
                              result[0] += 0.0002713902473907626;
                            } else {
                              result[0] += 0.00014281358085858258;
                            }
                          }
                        } else {
                          result[0] += -5.05184651954571e-05;
                        }
                      } else {
                        result[0] += 4.348924040687687e-05;
                      }
                    }
                  }
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.07196201389915944657) ) ) {
                    result[0] += -0.0004659584051835195;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1948292836308671283) ) ) {
                      result[0] += 0.0007115959809045598;
                    } else {
                      result[0] += -0.0003191749544733055;
                    }
                  }
                }
              } else {
                result[0] += -5.0360875101413824e-05;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7954292854522614364) ) ) {
                result[0] += -1.8164393166155317e-05;
              } else {
                result[0] += 0.00026980403966249676;
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.768269948548106596) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8419399877135679278) ) ) {
                  result[0] += -0.00013809849994854347;
                } else {
                  result[0] += 7.3239811111121525e-06;
                }
              } else {
                result[0] += -3.7905430648129186e-06;
              }
            } else {
              result[0] += 0.00011285485962874227;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.168924500000000033) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1301603066321575797) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.310012234630710122e-06) ) ) {
                result[0] += -0.00011649543434527584;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5792515097236182742) ) ) {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7572008430306190752) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02328402533912880476) ) ) {
                      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.8537219630417757221) ) ) {
                        result[0] += 0.0008183126445347052;
                      } else {
                        result[0] += -0.0005053725961730795;
                      }
                    } else {
                      result[0] += -0.001392279898227813;
                    }
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03127843326018551334) ) ) {
                      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.08110515786938453375) ) ) {
                        result[0] += 0.00024450258868770217;
                      } else {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.125515493975159704e-06) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09221529126392057074) ) ) {
                            result[0] += -0.00013532622455118799;
                          } else {
                            result[0] += 0.0015983764583711326;
                          }
                        } else {
                          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001237226668511850168) ) ) {
                            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.120890988778383868e-05) ) ) {
                              result[0] += 2.426150766556218e-05;
                            } else {
                              result[0] += -0.00041079047569868646;
                            }
                          } else {
                            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2533229942273665936) ) ) {
                              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1738383111593791719) ) ) {
                                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09221529126392057074) ) ) {
                                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
                                    result[0] += -4.2800891569782185e-05;
                                  } else {
                                    result[0] += 0.00048257764314552255;
                                  }
                                } else {
                                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1076318469022627677) ) ) {
                                    result[0] += -0.0006820261241274999;
                                  } else {
                                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1206324332205917643) ) ) {
                                      result[0] += 0.0012960830090348154;
                                    } else {
                                      result[0] += -0.00011077458776595655;
                                    }
                                  }
                                }
                              } else {
                                result[0] += 0.0015470390505986841;
                              }
                            } else {
                              result[0] += -0.00035820153315701647;
                            }
                          }
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04557577292723340862) ) ) {
                        result[0] += 0.0008254417575599015;
                      } else {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05585367585607920599) ) ) {
                          result[0] += -0.00029591587645768063;
                        } else {
                          result[0] += 0.0011498001174888876;
                        }
                      }
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05721739154190200877) ) ) {
                    result[0] += -0.0006478050390613951;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5814822343216081713) ) ) {
                      result[0] += -0.00029401969138485206;
                    } else {
                      result[0] += 2.4275175514418253e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += 0.0008281498227929185;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3142265000000000197) ) ) {
              result[0] += 0.0017048659410194983;
            } else {
              result[0] += 6.512130324851391e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005473500000000000067) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3569067370100503234) ) ) {
              result[0] += -0.0003097861945111584;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008332142139858200389) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005972045269192751034) ) ) {
                  result[0] += 0.0016022474162168644;
                } else {
                  result[0] += -0.0012432814621581936;
                }
              } else {
                result[0] += 0.001774220838809124;
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021562361187840079) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2932818109908455484) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08407783631914581002) ) ) {
                    result[0] += 0.0007219913006096846;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1051257686552766607) ) ) {
                      result[0] += -0.0020920537331446613;
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1311798687976579447) ) ) {
                        result[0] += 0.0023866609367808535;
                      } else {
                        result[0] += -0.00028120313490611275;
                      }
                    }
                  }
                } else {
                  result[0] += -0.002193544841712518;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5508018452917812224) ) ) {
                  result[0] += 0.0019222980085031212;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6836184685175880071) ) ) {
                    result[0] += -0.00031437497516205275;
                  } else {
                    result[0] += 0.0010860016126445966;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
                result[0] += 0.00011714017465814363;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1250629713251516228) ) ) {
                  result[0] += 0.0020492377936938014;
                } else {
                  result[0] += 0.0006202275835305397;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.469327283602055445) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
              result[0] += 0.0016830788815880165;
            } else {
              result[0] += 0.0016719818624062446;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4082869870603015872) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09244171632358916257) ) ) {
                result[0] += -0.0020901295622494237;
              } else {
                result[0] += 0.0009762245391907717;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8440161800932387548) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.07196200000000001207) ) ) {
                    if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.002753795023577549923) ) ) {
                      result[0] += 0.0014703908817054467;
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02733191529475900369) ) ) {
                        result[0] += -8.79791682162472e-05;
                      } else {
                        result[0] += 0.0013777863345463056;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3251271839107726103) ) ) {
                      result[0] += 0.0012505080975082725;
                    } else {
                      result[0] += -0.0012360319751442397;
                    }
                  }
                } else {
                  result[0] += -0.00017248436622280643;
                }
              } else {
                result[0] += 0.0017321764011584179;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -2.804174471262772e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.804174471262772e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                result[0] += -2.804174471262772e-06;
              } else {
                result[0] += -2.804174471262772e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006452000000000001137) ) ) {
            result[0] += 1.1829314693858083e-06;
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.06765554132556478306) ) ) {
              result[0] += -2.0400100680862987e-05;
            } else {
              result[0] += -8.791610215794616e-08;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -2.804174471262772e-06;
              } else {
                result[0] += -2.804174471262772e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -2.804174471262772e-06;
                  } else {
                    result[0] += -2.804174471262772e-06;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -2.804174471262772e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -2.804174471262772e-06;
                        } else {
                          result[0] += -2.804174471262772e-06;
                        }
                      } else {
                        result[0] += -2.804174471262772e-06;
                      }
                    }
                  } else {
                    result[0] += -2.804174471262772e-06;
                  }
                }
              } else {
                result[0] += -2.804174471262772e-06;
              }
            }
          } else {
            result[0] += -2.804174471262772e-06;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -2.804174471262772e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -2.804174471262772e-06;
                } else {
                  result[0] += -2.804174471262772e-06;
                }
              } else {
                result[0] += -2.804174471262772e-06;
              }
            } else {
              result[0] += -2.804174471262772e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9450000000000000622) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6950000000000000622) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.168924500000000033) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02500000000000000486) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1450000000000000455) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.723113719091885043) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03181986453917805963) ) ) {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.08500000000000000611) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.332369726860020087) ) ) {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.293999201342569312e-07) ) ) {
                          result[0] += -2.5654207881438844e-05;
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7492319095182128352) ) ) {
                            result[0] += -8.695667853473949e-06;
                          } else {
                            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9567162861906464144) ) ) {
                              result[0] += 5.557049021599278e-06;
                            } else {
                              result[0] += -3.654429024911634e-06;
                            }
                          }
                        }
                      } else {
                        result[0] += 5.5223411070574915e-05;
                      }
                    } else {
                      result[0] += -0.00014199288332811317;
                    }
                  } else {
                    result[0] += -5.2818497321510316e-05;
                  }
                } else {
                  result[0] += -3.417128070661604e-06;
                }
              } else {
                result[0] += 0.0008662325425410894;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1513805188710139749) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7640286906783920751) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.373325504271297691e-06) ) ) {
                        result[0] += -6.949916016886407e-05;
                      } else {
                        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
                          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.038494786985569569e-06) ) ) {
                            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1650000000000000355) ) ) {
                              result[0] += -1.6721767825728276e-05;
                            } else {
                              result[0] += 0.0011087578583028543;
                            }
                          } else {
                            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002339521674937150662) ) ) {
                              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9350000000000001643) ) ) {
                                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0007504883022448001527) ) ) {
                                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.25500000000000006) ) ) {
                                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.701692321267631473e-05) ) ) {
                                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.690815535104635854e-06) ) ) {
                                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                                            result[0] += -0.0001279945698866369;
                                          } else {
                                            result[0] += -0.00023834389344206262;
                                          }
                                        } else {
                                          result[0] += -1.3163177587315761e-05;
                                        }
                                      } else {
                                        result[0] += -0.00030360596032603205;
                                      }
                                    } else {
                                      result[0] += 7.046260217850178e-05;
                                    }
                                  } else {
                                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7250000000000000888) ) ) {
                                      result[0] += 0.0006288493260394362;
                                    } else {
                                      result[0] += -0.0003184480196236571;
                                    }
                                  }
                                } else {
                                  result[0] += -0.00012159424197448493;
                                }
                              } else {
                                result[0] += 0.0009105061954644244;
                              }
                            } else {
                              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1050000000000000239) ) ) {
                                result[0] += 0.0002776103810778454;
                              } else {
                                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
                                  result[0] += 4.079199905781417e-05;
                                } else {
                                  result[0] += -0.0007123952747482795;
                                }
                              }
                            }
                          }
                        } else {
                          result[0] += 0.00041469397271761847;
                        }
                      }
                    } else {
                      result[0] += 0.0005621218228546702;
                    }
                  } else {
                    result[0] += -0.000690712983897041;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.234671350732867934) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9112103514676580529) ) ) {
                      result[0] += -0.0004133631892538892;
                    } else {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9350000000000001643) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
                          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)5.045799003287211847e-06) ) ) {
                            result[0] += 0.00031521777403966457;
                          } else {
                            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.966590843157139501) ) ) {
                              result[0] += 0.0005430519215005188;
                            } else {
                              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9808239647505231362) ) ) {
                                result[0] += -8.751326573934873e-05;
                              } else {
                                result[0] += -5.588877478583069e-05;
                              }
                            }
                          }
                        } else {
                          result[0] += -0.00076077870079634;
                        }
                      } else {
                        result[0] += -0.0006842917104157857;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01065347450249755183) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8507017292462312197) ) ) {
                        result[0] += 0.00036889775870103904;
                      } else {
                        result[0] += -5.917202947776295e-06;
                      }
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01969319515722280436) ) ) {
                        result[0] += -0.00011988191463340246;
                      } else {
                        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7550000000000001155) ) ) {
                          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3550000000000000377) ) ) {
                            result[0] += 3.985863951398047e-05;
                          } else {
                            result[0] += 0.0007240619518839246;
                          }
                        } else {
                          result[0] += -0.00021437756889050135;
                        }
                      }
                    }
                  }
                }
              } else {
                result[0] += 0.0016797905248866036;
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2271190000000000431) ) ) {
              result[0] += 0.0008011668955640185;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3251271839107726103) ) ) {
                result[0] += 0.0035725180802002768;
              } else {
                result[0] += -0.00019447277503965884;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6836184685175880071) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2323027026914575854) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03469629566125685682) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8550000000000000933) ) ) {
                    result[0] += 0.002164260406537292;
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9050000000000001377) ) ) {
                      result[0] += -0.0009466817280584792;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03181986453917805963) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5792515097236182742) ) ) {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5674119023366835934) ) ) {
                            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001504690974371400121) ) ) {
                              result[0] += -0.00048742634860626333;
                            } else {
                              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02366047096071570086) ) ) {
                                result[0] += 0.0005693255197221076;
                              } else {
                                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02884459794480960168) ) ) {
                                  result[0] += -0.000979113783433339;
                                } else {
                                  result[0] += 0.0014092370744227826;
                                }
                              }
                            }
                          } else {
                            result[0] += -0.00044982523583514194;
                          }
                        } else {
                          result[0] += 0.0016675827854706188;
                        }
                      } else {
                        result[0] += -0.0014203047400966951;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5190499213819096402) ) ) {
                    result[0] += 0.0006781503879473044;
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9650000000000000799) ) ) {
                      result[0] += 0.003820523701674603;
                    } else {
                      result[0] += 0.001151639861702293;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5834559473869348478) ) ) {
                  result[0] += -0.0011703686834053189;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06364359169843836206) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02129391514754680123) ) ) {
                      result[0] += -7.840272977178299e-05;
                    } else {
                      result[0] += 0.002045870249898409;
                    }
                  } else {
                    result[0] += -0.0005692122751058064;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7269841738944724518) ) ) {
                result[0] += 0.0016383184487268403;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7789937396482412568) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01085750000000000083) ) ) {
                    result[0] += 0.0008174317428158797;
                  } else {
                    result[0] += -0.0007757107235606531;
                  }
                } else {
                  result[0] += 0.002445478494523885;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03603011311338780859) ) ) {
              result[0] += 0.0003072302308953052;
            } else {
              result[0] += -0.001638708184434901;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0526089167981486569) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.244955337349149066) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
              result[0] += 0.0016209493093154097;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03468100000000001043) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008506177121675452882) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4093335132160804135) ) ) {
                    result[0] += -0.0011949172124398927;
                  } else {
                    result[0] += 0.0032133668809084426;
                  }
                } else {
                  result[0] += 0.001611036281587026;
                }
              } else {
                result[0] += -0.0002425771808569681;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4693879269597989734) ) ) {
              result[0] += -0.0026601144573247704;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9993516786272610419) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01151200000000000313) ) ) {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.07409325127878772788) ) ) {
                    result[0] += 0.0016892710687199006;
                  } else {
                    result[0] += 0.0012173489861714687;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
                    result[0] += -9.203061652378146e-05;
                  } else {
                    result[0] += 0.001153363618109505;
                  }
                }
              } else {
                result[0] += -0.0009997226189679043;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03091100000000000445) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9112103514676580529) ) ) {
              result[0] += 0.0014215870631351462;
            } else {
              result[0] += 0.0006513763074193675;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3057749246864051029) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.01537695356895864805) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.378188349821562797) ) ) {
                  if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4999497468491173047) ) ) {
                    if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6782348568386622478) ) ) {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
                        result[0] += 0.0016160845241566524;
                      } else {
                        result[0] += -0.0005176393601554148;
                      }
                    } else {
                      result[0] += 0.001694626970127518;
                    }
                  } else {
                    result[0] += -0.0010645320349970723;
                  }
                } else {
                  result[0] += 0.0014270016811482838;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02733191529475900369) ) ) {
                  result[0] += -0.0009379819123853594;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05463331189772155372) ) ) {
                    result[0] += 0.0016967611488792429;
                  } else {
                    result[0] += 0.0003553333492208804;
                  }
                }
              }
            } else {
              result[0] += 0.0016967611488792429;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -2.6925553018448597e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.6925553018448597e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                result[0] += -2.6925553018448597e-06;
              } else {
                result[0] += -2.6925553018448597e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4781247323869347032) ) ) {
            result[0] += 3.402575010199904e-05;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02455150000000000388) ) ) {
              result[0] += 2.671649775952257e-07;
            } else {
              result[0] += -4.662801671638394e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -2.6925553018448597e-06;
              } else {
                result[0] += -2.6925553018448597e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -2.6925553018448597e-06;
                  } else {
                    result[0] += -2.6925553018448597e-06;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -2.6925553018448597e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -2.6925553018448597e-06;
                        } else {
                          result[0] += -2.6925553018448597e-06;
                        }
                      } else {
                        result[0] += -2.6925553018448597e-06;
                      }
                    }
                  } else {
                    result[0] += -2.6925553018448597e-06;
                  }
                }
              } else {
                result[0] += -2.6925553018448597e-06;
              }
            }
          } else {
            result[0] += -2.6925553018448597e-06;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -2.6925553018448597e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -2.6925553018448597e-06;
                } else {
                  result[0] += -2.6925553018448597e-06;
                }
              } else {
                result[0] += -2.6925553018448597e-06;
              }
            } else {
              result[0] += -2.6925553018448597e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9450000000000000622) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6950000000000000622) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02500000000000000486) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1450000000000000455) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.723113719091885043) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.394135022639764854) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4389499174623116007) ) ) {
                    result[0] += 0.0002995589187641279;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4693879269597989734) ) ) {
                      result[0] += -0.00012396822205623241;
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.002347679878538096e-06) ) ) {
                        result[0] += -1.7863274900597838e-05;
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03181986453917805963) ) ) {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6858832018090453841) ) ) {
                              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5041457217085428821) ) ) {
                                result[0] += 0.00034966022342619975;
                              } else {
                                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6481803955276382867) ) ) {
                                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5528143519346734314) ) ) {
                                      result[0] += -1.993580356715907e-05;
                                    } else {
                                      result[0] += 1.0449016094579118e-05;
                                    }
                                  } else {
                                    result[0] += -6.100213029660228e-05;
                                  }
                                } else {
                                  result[0] += 2.247600336501149e-05;
                                }
                              }
                            } else {
                              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.714147492562814179) ) ) {
                                result[0] += -5.242224665371818e-05;
                              } else {
                                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7211604863065327331) ) ) {
                                  result[0] += 1.808886088910099e-05;
                                } else {
                                  result[0] += -4.543891754063021e-05;
                                }
                              }
                            }
                          } else {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
                              result[0] += 0.0001866030783906507;
                            } else {
                              result[0] += -5.452399941717945e-07;
                            }
                          }
                        } else {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04247438584267165113) ) ) {
                            result[0] += -0.00018941229590016924;
                          } else {
                            result[0] += 3.41846247238315e-05;
                          }
                        }
                      }
                    }
                  }
                } else {
                  result[0] += 0.00019045224020304387;
                }
              } else {
                result[0] += -3.2811105008025783e-06;
              }
            } else {
              result[0] += 0.0008366510074806388;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.168924500000000033) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7640286906783920751) ) ) {
                  result[0] += 3.4282246713382527e-05;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7954292854522614364) ) ) {
                    result[0] += -0.00013023372862574513;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8025985781909549255) ) ) {
                      result[0] += 0.0003800576920585902;
                    } else {
                      result[0] += -1.6417884035070824e-05;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2004855000000000109) ) ) {
                  result[0] += 0.0017662025208709268;
                } else {
                  result[0] += 0.0006669887995639113;
                }
              }
            } else {
              result[0] += -0.00027655036224264135;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3998546246231156065) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.8537219630417757221) ) ) {
              result[0] += 0.0012257496680091581;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9650000000000000799) ) ) {
                result[0] += 0.001672141295857406;
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7572008430306190752) ) ) {
                  result[0] += -0.001092309063535657;
                } else {
                  result[0] += -0.0004511516475758647;
                }
              }
            }
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4601878067544193374) ) ) {
              result[0] += 0.001855196718626516;
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.378188349821562797) ) ) {
                result[0] += -0.0014230458749961944;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6836184685175880071) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2323027026914575854) ) ) {
                      result[0] += 0.0007162200824792396;
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5928702589437735426) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2564454682769619631) ) ) {
                          result[0] += -0.000883132894221882;
                        } else {
                          result[0] += 0.00013434842024428916;
                        }
                      } else {
                        result[0] += -0.0008768789964176106;
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7269841738944724518) ) ) {
                      result[0] += 0.0015731057644366984;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7789937396482412568) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8440161800932387548) ) ) {
                          result[0] += 0.0012820168899605302;
                        } else {
                          result[0] += -0.0003682679637592476;
                        }
                      } else {
                        result[0] += 0.002348137091132103;
                      }
                    }
                  }
                } else {
                  result[0] += -0.00018271596170256046;
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.009602467408789250661) ) ) {
          if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.06765554132556478306) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4129968667336683663) ) ) {
              result[0] += -1.3654558544192656e-05;
            } else {
              result[0] += 0.002518800205712704;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005372500000000001406) ) ) {
              result[0] += 0.0012733778763125132;
            } else {
              result[0] += -0.00230971954407907;
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01108250000000000207) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
              result[0] += 0.0014065185345751507;
            } else {
              result[0] += 0.0014674559212091462;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021562361187840079) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
                result[0] += 0.0015564279974539358;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01910124190761275029) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5400528323115579843) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4674830972361809223) ) ) {
                      result[0] += 0.00012136363426095915;
                    } else {
                      result[0] += -0.002512328569766505;
                    }
                  } else {
                    result[0] += 0.0012929015840074474;
                  }
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0229305563329877532) ) ) {
                    result[0] += 0.0015242691588743887;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08693186820944626136) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4129968667336683663) ) ) {
                        if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.469327283602055445) ) ) {
                          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6782348568386622478) ) ) {
                            result[0] += -0.00021039707812900858;
                          } else {
                            result[0] += 0.001631944922035797;
                          }
                        } else {
                          result[0] += -0.0024915303914231106;
                        }
                      } else {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02884459794480960168) ) ) {
                          result[0] += -0.0001328406734118217;
                        } else {
                          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0409003745630781082) ) ) {
                            result[0] += 0.001792904927129016;
                          } else {
                            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0526089167981486569) ) ) {
                              result[0] += 0.0001512088952519475;
                            } else {
                              result[0] += 0.0013085171813898239;
                            }
                          }
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5499504253266332965) ) ) {
                        result[0] += -0.001677805915065937;
                      } else {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7342470301758795559) ) ) {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6059258460552764403) ) ) {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5800027599246232457) ) ) {
                              result[0] += 0.0018596115468391917;
                            } else {
                              result[0] += -0.0006874460665639416;
                            }
                          } else {
                            result[0] += 0.0012306156304035469;
                          }
                        } else {
                          result[0] += -0.0001633622404670559;
                        }
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3057749246864051029) ) ) {
                result[0] += 0.001239522966609077;
              } else {
                result[0] += 0.0016280093829235576;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -2.5853790938436572e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.5853790938436572e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                result[0] += -2.5853790938436572e-06;
              } else {
                result[0] += -2.5853790938436572e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.07196201389915944657) ) ) {
            result[0] += -1.5681356911335848e-05;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
              result[0] += 8.91165484234949e-07;
            } else {
              result[0] += -9.136523738333081e-06;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -2.5853790938436572e-06;
              } else {
                result[0] += -2.5853790938436572e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -2.5853790938436572e-06;
                  } else {
                    result[0] += -2.5853790938436572e-06;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -2.5853790938436572e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -2.5853790938436572e-06;
                        } else {
                          result[0] += -2.5853790938436572e-06;
                        }
                      } else {
                        result[0] += -2.5853790938436572e-06;
                      }
                    }
                  } else {
                    result[0] += -2.5853790938436572e-06;
                  }
                }
              } else {
                result[0] += -2.5853790938436572e-06;
              }
            }
          } else {
            result[0] += -2.5853790938436572e-06;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -2.5853790938436572e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -2.5853790938436572e-06;
                } else {
                  result[0] += -2.5853790938436572e-06;
                }
              } else {
                result[0] += -2.5853790938436572e-06;
              }
            } else {
              result[0] += -2.5853790938436572e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.115000000000000005) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3561404984221285264) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3115605993075549196) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2888738239382729889) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2533229942273665936) ) ) {
                        result[0] += -1.0326303185253532e-05;
                      } else {
                        result[0] += -0.0001357735793979313;
                      }
                    } else {
                      result[0] += 0.00034534481957484514;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3251271839107726103) ) ) {
                      result[0] += -0.0003490088500106308;
                    } else {
                      result[0] += -0.0002463931380320369;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3830383354773237436) ) ) {
                    result[0] += 8.032129555317471e-05;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.966590843157139501) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6413622072216433878) ) ) {
                          result[0] += 6.3319989137997044e-06;
                        } else {
                          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6558660377084782889) ) ) {
                            result[0] += -0.00018688443684057498;
                          } else {
                            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7293493725076146683) ) ) {
                              result[0] += 1.4849167910950548e-05;
                            } else {
                              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7492319095182128352) ) ) {
                                result[0] += -0.00013879631897174938;
                              } else {
                                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8377933889099087317) ) ) {
                                  result[0] += 8.790636469658921e-05;
                                } else {
                                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8466324982590252013) ) ) {
                                    result[0] += -0.0002163942859860576;
                                  } else {
                                    result[0] += -1.067817953271649e-05;
                                  }
                                }
                              }
                            }
                          }
                        }
                      } else {
                        result[0] += 0.0003485033919784643;
                      }
                    } else {
                      result[0] += -6.223215492650493e-06;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7954292854522614364) ) ) {
                  result[0] += -0.00011515217224022008;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                    result[0] += -1.5047495648791577e-05;
                  } else {
                    result[0] += 0.00012218202381855507;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                result[0] += -4.459268172973414e-05;
              } else {
                result[0] += 0.00018655846934163015;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8419399877135679278) ) ) {
              result[0] += -0.00013021072437312335;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.768269948548106596) ) ) {
                  result[0] += 9.670535144523449e-06;
                } else {
                  result[0] += -3.3730408350319646e-06;
                }
              } else {
                result[0] += 0.00011137355804920154;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.310012234630710122e-06) ) ) {
            result[0] += -0.00011045657819509613;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3115605993075549196) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.07196200000000001207) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003024500000000000712) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002063500000000000664) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001715500000000000228) ) ) {
                        result[0] += 0.00018775273223389647;
                      } else {
                        result[0] += -0.00014176144707765074;
                      }
                    } else {
                      result[0] += 0.0005857408815384942;
                    }
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003226000000000000135) ) ) {
                      result[0] += -0.0003855731432988431;
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01287800000000000229) ) ) {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003965500000000001142) ) ) {
                          result[0] += 0.00041652133547093347;
                        } else {
                          result[0] += -4.808644684190387e-05;
                        }
                      } else {
                        result[0] += 0.0003753597387262561;
                      }
                    }
                  }
                } else {
                  result[0] += -0.00115515226644802;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0409003745630781082) ) ) {
                  result[0] += 0.00027971851293473937;
                } else {
                  result[0] += 0.002022210005482845;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3665106630729573767) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03127843326018551334) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01254618095428180168) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005972045269192751034) ) ) {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002339521674937150662) ) ) {
                        result[0] += -0.00011896403061397951;
                      } else {
                        result[0] += 0.00048044600562309415;
                      }
                    } else {
                      result[0] += -0.0007269002298130236;
                    }
                  } else {
                    result[0] += 0.0006729914837114053;
                  }
                } else {
                  result[0] += -0.0029738019145920105;
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1605461427107033601) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0005095000000000000787) ) ) {
                    result[0] += 0.00029324162929326254;
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0006235000000000000308) ) ) {
                      result[0] += -0.0003263992277549656;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6449783570351760309) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.543101476988260834) ) ) {
                          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3966559369710560001) ) ) {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6208328749497488142) ) ) {
                              result[0] += 0.0014433320922601657;
                            } else {
                              result[0] += -9.439915660611667e-05;
                            }
                          } else {
                            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4364163272837385255) ) ) {
                              result[0] += -0.0006572076527161244;
                            } else {
                              result[0] += 0.0002557690890698242;
                            }
                          }
                        } else {
                          result[0] += -0.0011938122448023813;
                        }
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6518611175125629265) ) ) {
                          result[0] += 0.0007821857002330698;
                        } else {
                          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00135663295830650032) ) ) {
                            result[0] += -0.00016085707238214762;
                          } else {
                            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8377933889099087317) ) ) {
                              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6732382808793971884) ) ) {
                                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6717423563567840317) ) ) {
                                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.543101476988260834) ) ) {
                                    result[0] += 0.0001358546039533669;
                                  } else {
                                    result[0] += -0.0003822426240857789;
                                  }
                                } else {
                                  result[0] += -0.0009940908756785453;
                                }
                              } else {
                                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6836184685175880071) ) ) {
                                  result[0] += 0.0014079956053825032;
                                } else {
                                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6959555468592965033) ) ) {
                                    result[0] += -9.38199984701204e-05;
                                  } else {
                                    result[0] += 0.0005286925125232501;
                                  }
                                }
                              }
                            } else {
                              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.166761325528187454) ) ) {
                                  result[0] += -5.22808402631199e-05;
                                } else {
                                  result[0] += -0.0006755471178037276;
                                }
                              } else {
                                result[0] += 0.00014414962517267702;
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                } else {
                  result[0] += 0.002446334335039222;
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005473500000000000067) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001776826981475250261) ) ) {
              result[0] += -0.0011103001587755884;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04477003072051350535) ) ) {
                result[0] += 0.0013966436152427339;
              } else {
                result[0] += 0.0017508600839318113;
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021562361187840079) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2932818109908455484) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08407783631914581002) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01351316588546045208) ) ) {
                      result[0] += -9.222475326619904e-05;
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01650738594486505367) ) ) {
                        result[0] += 0.002594392753162716;
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07316210697219156789) ) ) {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05473596564878090848) ) ) {
                            result[0] += 0.0006255398012836578;
                          } else {
                            result[0] += 0.001243442235315121;
                          }
                        } else {
                          result[0] += -0.00030946527089146565;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1051257686552766607) ) ) {
                      result[0] += -0.001962489616080088;
                    } else {
                      result[0] += -5.2490334205124947e-05;
                    }
                  }
                } else {
                  result[0] += -0.0020884896452670236;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7733398996305392847) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6647073645226131422) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6359282793467337935) ) ) {
                      result[0] += 0.0019066242222727145;
                    } else {
                      result[0] += -0.00040850342874607624;
                    }
                  } else {
                    result[0] += 0.0018399961642903292;
                  }
                } else {
                  result[0] += 4.309885024394111e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
                result[0] += 1.1078204152502896e-05;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1250629713251516228) ) ) {
                  result[0] += 0.0018579910061246108;
                } else {
                  result[0] += 0.0005211901426978257;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.244955337349149066) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
              result[0] += 0.0014898037893952979;
            } else {
              result[0] += 0.0013874413872833114;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4693879269597989734) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05831812793683335133) ) ) {
                result[0] += -0.003701998830705177;
              } else {
                result[0] += 0.0007903828007404604;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3830383354773237436) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5424744603768845153) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1706267463716274191) ) ) {
                    result[0] += 0.0008422648225757749;
                  } else {
                    result[0] += 0.0015214819060801702;
                  }
                } else {
                  result[0] += 0.0014989586621649985;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6047319804020101497) ) ) {
                  result[0] += -0.001902442107057604;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8440161800932387548) ) ) {
                    result[0] += 0.0012812538505515586;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
                      result[0] += -0.0002979771066197359;
                    } else {
                      result[0] += 0.001364689876507705;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -2.482468996757112e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.482468996757112e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                result[0] += -2.482468996757112e-06;
              } else {
                result[0] += -2.482468996757112e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.07196201389915944657) ) ) {
            result[0] += -1.5057166065963483e-05;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
              result[0] += 8.5569295847608e-07;
            } else {
              result[0] += -8.772847654162565e-06;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -2.482468996757112e-06;
              } else {
                result[0] += -2.482468996757112e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -2.482468996757112e-06;
                  } else {
                    result[0] += -2.482468996757112e-06;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -2.482468996757112e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -2.482468996757112e-06;
                        } else {
                          result[0] += -2.482468996757112e-06;
                        }
                      } else {
                        result[0] += -2.482468996757112e-06;
                      }
                    }
                  } else {
                    result[0] += -2.482468996757112e-06;
                  }
                }
              } else {
                result[0] += -2.482468996757112e-06;
              }
            }
          } else {
            result[0] += -2.482468996757112e-06;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -2.482468996757112e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -2.482468996757112e-06;
                } else {
                  result[0] += -2.482468996757112e-06;
                }
              } else {
                result[0] += -2.482468996757112e-06;
              }
            } else {
              result[0] += -2.482468996757112e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03500000000000001027) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.723113719091885043) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.716605685555453681e-07) ) ) {
              result[0] += -4.923613150845999e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.166761325528187454) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9567162861906464144) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9112103514676580529) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5986852915639623296) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3763200711443456803) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3115605993075549196) ) ) {
                          result[0] += -2.1627866937258862e-06;
                        } else {
                          result[0] += -2.3296916046852202e-05;
                        }
                      } else {
                        result[0] += 4.395599527893407e-06;
                      }
                    } else {
                      result[0] += -3.399538155559448e-05;
                    }
                  } else {
                    result[0] += 0.00011075362076746707;
                  }
                } else {
                  result[0] += -1.8675462899462644e-05;
                }
              } else {
                result[0] += 2.334267867687145e-05;
              }
            }
          } else {
            result[0] += -3.531371212051936e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02577363736079425413) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02528885254406800301) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2545696998002126565) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4150000000000000355) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4737195465326633492) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4592177672613065309) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4484214422864321592) ) ) {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3837516359296482826) ) ) {
                          result[0] += -5.912837506760936e-05;
                        } else {
                          result[0] += 0.00015663671648639447;
                        }
                      } else {
                        result[0] += -0.00027067954648119197;
                      }
                    } else {
                      result[0] += 0.0007412612633436584;
                    }
                  } else {
                    result[0] += -0.0004436399753127943;
                  }
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5150000000000001243) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3998546246231156065) ) ) {
                      result[0] += 0.0002890607964409018;
                    } else {
                      result[0] += 0.0013665557198805861;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4592177672613065309) ) ) {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.8537219630417757221) ) ) {
                        result[0] += 0.001055848346725423;
                      } else {
                        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6782348568386622478) ) ) {
                          result[0] += -0.0005246685572128192;
                        } else {
                          result[0] += 0.00019361531114067514;
                        }
                      }
                    } else {
                      result[0] += 0.0012098557248081294;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4751828078391960308) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4643511832914573034) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
                      result[0] += -0.00010460793576728686;
                    } else {
                      result[0] += 0.000614530453357368;
                    }
                  } else {
                    result[0] += -0.00046579099165135435;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7640286906783920751) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6665289424874373259) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6647073645226131422) ) ) {
                        result[0] += 6.079955944734699e-06;
                      } else {
                        result[0] += -0.00029534342840102634;
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7190147863316583843) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6968016071608041928) ) ) {
                          result[0] += 0.00012254409957219387;
                        } else {
                          result[0] += 0.0004527782732857837;
                        }
                      } else {
                        result[0] += 7.075776882372792e-06;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8643464628140704598) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8507017292462312197) ) ) {
                        result[0] += -1.873277321464347e-05;
                      } else {
                        result[0] += -0.00014167532840742583;
                      }
                    } else {
                      result[0] += 0.00011777318053718919;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.0005636535907178902;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
                  result[0] += 0.001397316802839543;
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.07500000000000002498) ) ) {
                    result[0] += -0.00022572227257250594;
                  } else {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7835979262278595092) ) ) {
                      result[0] += -0.0008353890445466129;
                    } else {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6269304705026225166) ) ) {
                        result[0] += 0.0020770574495881894;
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
                          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7550000000000001155) ) ) {
                            result[0] += 0.000703602798479396;
                          } else {
                            if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3539353041941689093) ) ) {
                              result[0] += -0.00021682039616999378;
                            } else {
                              result[0] += -0.000989047911934928;
                            }
                          }
                        } else {
                          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1738383111593791719) ) ) {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4639489995477387718) ) ) {
                              result[0] += 0.0030701448737593348;
                            } else {
                              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5309997332914574431) ) ) {
                                result[0] += 3.0637421993418946e-05;
                              } else {
                                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5800027599246232457) ) ) {
                                  result[0] += 0.001164587742613164;
                                } else {
                                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.590591194899497629) ) ) {
                                    result[0] += -0.0006679996149999965;
                                  } else {
                                    result[0] += 0.0005287416546308605;
                                  }
                                }
                              }
                            }
                          } else {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6116569490452262725) ) ) {
                              result[0] += -0.0003008329937205389;
                            } else {
                              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6299505656030152112) ) ) {
                                result[0] += 0.0020308600904448784;
                              } else {
                                result[0] += 5.932752810256515e-05;
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.001074533559890584;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8168185667587940513) ) ) {
                result[0] += 0.000652845408462932;
              } else {
                result[0] += 0.00028288620409016945;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005473500000000000067) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3569067370100503234) ) ) {
              result[0] += -0.00022421425581721486;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008332142139858200389) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005972045269192751034) ) ) {
                  result[0] += 0.0015067178796192887;
                } else {
                  result[0] += -0.001170373471569762;
                }
              } else {
                result[0] += 0.0015465739235975733;
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021562361187840079) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2932818109908455484) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08407783631914581002) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01351316588546045208) ) ) {
                      result[0] += -8.855377969988252e-05;
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01650738594486505367) ) ) {
                        result[0] += 0.002491123870566594;
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07316210697219156789) ) ) {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05473596564878090848) ) ) {
                            result[0] += 0.0006006404115443006;
                          } else {
                            result[0] += 0.0011939474585288081;
                          }
                        } else {
                          result[0] += -0.0002971471156359399;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1051257686552766607) ) ) {
                      result[0] += -0.0018843734135459782;
                    } else {
                      result[0] += -5.040097508482299e-05;
                    }
                  }
                } else {
                  result[0] += -0.0020053580562979416;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7733398996305392847) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6647073645226131422) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6359282793467337935) ) ) {
                      result[0] += 0.0018307317219083134;
                    } else {
                      result[0] += -0.0003922430947731777;
                    }
                  } else {
                    result[0] += 0.0017667557701226497;
                  }
                } else {
                  result[0] += 4.138331580897988e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
                result[0] += 1.0637240168694865e-05;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1250629713251516228) ) ) {
                  result[0] += 0.0017840343336654294;
                } else {
                  result[0] += 0.0005004443540770004;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
            result[0] += 0.001430502678400916;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01085750000000000083) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01021941412521685209) ) ) {
                result[0] += 3.953700641015517e-05;
              } else {
                result[0] += 0.0013722046051080734;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1706267463716274191) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01881166515770610337) ) ) {
                  result[0] += -0.00043654414782141014;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02229191548174745338) ) ) {
                    result[0] += 0.0019730741846164814;
                  } else {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1828583041203602211) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03350035677887956004) ) ) {
                        result[0] += -0.0003298907343024979;
                      } else {
                        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6782348568386622478) ) ) {
                          result[0] += 0.00022716562257922525;
                        } else {
                          result[0] += 0.0013575934195144217;
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4797597438944724013) ) ) {
                        result[0] += -0.0009617471338672669;
                      } else {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7342470301758795559) ) ) {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6077784371608041525) ) ) {
                            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5829435000502513065) ) ) {
                              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5455059598241206453) ) ) {
                                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5353359946984925788) ) ) {
                                  result[0] += 0.0008401164895445613;
                                } else {
                                  result[0] += -8.575637777497323e-05;
                                }
                              } else {
                                result[0] += 0.0013691251371502743;
                              }
                            } else {
                              result[0] += -0.0007189908690873333;
                            }
                          } else {
                            result[0] += 0.0012163194557736447;
                          }
                        } else {
                          result[0] += -0.00014503106195458968;
                        }
                      }
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3346339054385528144) ) ) {
                  result[0] += 0.0014879070378286887;
                } else {
                  result[0] += 0.0011909781516093855;
                }
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -2.3836551995546265e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.3836551995546265e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                result[0] += -2.3836551995546265e-06;
              } else {
                result[0] += -2.3836551995546265e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4781247323869347032) ) ) {
            result[0] += 3.389490319318248e-05;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02455150000000000388) ) ) {
              result[0] += 1.8699749027708686e-07;
            } else {
              result[0] += -4.354846906703312e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -2.3836551995546265e-06;
              } else {
                result[0] += -2.3836551995546265e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -2.3836551995546265e-06;
                  } else {
                    result[0] += -2.3836551995546265e-06;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -2.3836551995546265e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -2.3836551995546265e-06;
                        } else {
                          result[0] += -2.3836551995546265e-06;
                        }
                      } else {
                        result[0] += -2.3836551995546265e-06;
                      }
                    }
                  } else {
                    result[0] += -2.3836551995546265e-06;
                  }
                }
              } else {
                result[0] += -2.3836551995546265e-06;
              }
            }
          } else {
            result[0] += -2.3836551995546265e-06;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -2.3836551995546265e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -2.3836551995546265e-06;
                } else {
                  result[0] += -2.3836551995546265e-06;
                }
              } else {
                result[0] += -2.3836551995546265e-06;
              }
            } else {
              result[0] += -2.3836551995546265e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.115000000000000005) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7712418641206031378) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.767254320477387064) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7601236426381910993) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7322719660050253099) ) ) {
                        result[0] += -5.569217157862247e-06;
                      } else {
                        result[0] += -0.00031607039551098085;
                      }
                    } else {
                      result[0] += 4.620915542053959e-05;
                    }
                  } else {
                    result[0] += -3.4327048619493216e-05;
                  }
                } else {
                  result[0] += 0.0001621726177630685;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7954292854522614364) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7875164333668343009) ) ) {
                    result[0] += -1.7177692271789713e-05;
                  } else {
                    result[0] += -0.00018091151901269005;
                  }
                } else {
                  result[0] += 1.0869306671260399e-06;
                }
              }
            } else {
              result[0] += 8.835009616374809e-05;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8419399877135679278) ) ) {
              result[0] += -0.00012391756399047208;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.723113719091885043) ) ) {
                result[0] += 2.9208528107194432e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                  result[0] += -3.390806234503281e-06;
                } else {
                  result[0] += 0.00010587381692779952;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.310012234630710122e-06) ) ) {
            result[0] += -0.00010633956308465053;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.168924500000000033) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1513805188710139749) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6558660377084782889) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3115605993075549196) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1534042965400678749) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1206324332205917643) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1129321246270776624) ) ) {
                            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.06355808660527756393) ) ) {
                              result[0] += 0.00011974302713051555;
                            } else {
                              result[0] += -0.00020277677844803658;
                            }
                          } else {
                            result[0] += 0.00112090344946187;
                          }
                        } else {
                          result[0] += -0.00017195329350647593;
                        }
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2323027026914575854) ) ) {
                          result[0] += 0.0006930530345477553;
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2888738239382729889) ) ) {
                            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2739990068871500095) ) ) {
                              result[0] += 1.9181302281977354e-05;
                            } else {
                              result[0] += -0.0005351956183361477;
                            }
                          } else {
                            result[0] += 0.0007824330834817329;
                          }
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3665106630729573767) ) ) {
                        result[0] += -0.0002609504414673427;
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3763200711443456803) ) ) {
                          result[0] += 0.002389013141047558;
                        } else {
                          result[0] += -1.072704513178782e-05;
                        }
                      }
                    }
                  } else {
                    result[0] += 0.0002810855800743107;
                  }
                } else {
                  result[0] += -1.6118276577625854e-05;
                }
              } else {
                result[0] += 0.0009776172421794727;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2863695000000000546) ) ) {
                result[0] += 0.0020713782503774146;
              } else {
                result[0] += -2.3812328198204303e-05;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005473500000000000067) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001776826981475250261) ) ) {
              result[0] += -0.0011260794254355536;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04477003072051350535) ) ) {
                result[0] += 0.0012924752095784043;
              } else {
                result[0] += 0.0016196068937674127;
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021562361187840079) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2145423861003193655) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5494686760804020631) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08407783631914581002) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4129968667336683663) ) ) {
                        if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4601878067544193374) ) ) {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03409611752714010457) ) ) {
                            result[0] += 0.0018450500760462591;
                          } else {
                            result[0] += -0.0003025872987763573;
                          }
                        } else {
                          result[0] += -0.0021134709836757143;
                        }
                      } else {
                        if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1711110322396684202) ) ) {
                          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02159955403810970287) ) ) {
                            result[0] += 0.00045213414729511825;
                          } else {
                            result[0] += 0.0013046455177929833;
                          }
                        } else {
                          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1044543990012605922) ) ) {
                            result[0] += -0.002181732064594844;
                          } else {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5072261056783921029) ) ) {
                              result[0] += -0.0005125409001930151;
                            } else {
                              result[0] += 0.002022537043539842;
                            }
                          }
                        }
                      }
                    } else {
                      result[0] += -0.001814873844386938;
                    }
                  } else {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.009014249010710599294) ) ) {
                      result[0] += 0.0025476442384014344;
                    } else {
                      result[0] += 0.0008705367835848732;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03127843326018551334) ) ) {
                    result[0] += -0.0003680048709102342;
                  } else {
                    result[0] += -0.001959322408102649;
                  }
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7733398996305392847) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6647073645226131422) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6359282793467337935) ) ) {
                      result[0] += 0.001757860095581009;
                    } else {
                      result[0] += -0.00037662999762206695;
                    }
                  } else {
                    result[0] += 0.001696430683846335;
                  }
                } else {
                  result[0] += 3.973606761323085e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
                result[0] += 1.0213828599729871e-05;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1250629713251516228) ) ) {
                  result[0] += 0.0017130214803007435;
                } else {
                  result[0] += 0.0004805243442079969;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
            result[0] += 0.0013735620270792777;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01085750000000000083) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01021941412521685209) ) ) {
                result[0] += 3.7963249904632905e-05;
              } else {
                result[0] += 0.0013175844878995212;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06081637682680595541) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01881166515770610337) ) ) {
                  result[0] += -0.00041916766297945976;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02229191548174745338) ) ) {
                    result[0] += 0.0018945366670890368;
                  } else {
                    result[0] += 0.0005636922702051474;
                  }
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3057749246864051029) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8466324982590252013) ) ) {
                    result[0] += 0.0010574532419704182;
                  } else {
                    result[0] += -0.000134555202555622;
                  }
                } else {
                  result[0] += 0.0014434193886825994;
                }
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -2.288774650473398e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.288774650473398e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                result[0] += -2.288774650473398e-06;
              } else {
                result[0] += -2.288774650473398e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.07196201389915944657) ) ) {
            result[0] += -1.5806995505394306e-05;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
              result[0] += 1.2653053372845776e-06;
            } else {
              result[0] += -7.821774158224795e-06;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -2.288774650473398e-06;
              } else {
                result[0] += -2.288774650473398e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -2.288774650473398e-06;
                  } else {
                    result[0] += -2.288774650473398e-06;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -2.288774650473398e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -2.288774650473398e-06;
                        } else {
                          result[0] += -2.288774650473398e-06;
                        }
                      } else {
                        result[0] += -2.288774650473398e-06;
                      }
                    }
                  } else {
                    result[0] += -2.288774650473398e-06;
                  }
                }
              } else {
                result[0] += -2.288774650473398e-06;
              }
            }
          } else {
            result[0] += -2.288774650473398e-06;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -2.288774650473398e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -2.288774650473398e-06;
                } else {
                  result[0] += -2.288774650473398e-06;
                }
              } else {
                result[0] += -2.288774650473398e-06;
              }
            } else {
              result[0] += -2.288774650473398e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02500000000000000486) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1450000000000000455) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.723113719091885043) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.394135022639764854) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4389499174623116007) ) ) {
                  result[0] += 0.00028835388683988954;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4693879269597989734) ) ) {
                    result[0] += -0.00011831490648149235;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                      result[0] += 9.220666630533222e-06;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6334213184170854882) ) ) {
                        result[0] += -0.00012590483095221343;
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6858832018090453841) ) ) {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6481803955276382867) ) ) {
                            result[0] += -4.506682768694382e-05;
                          } else {
                            result[0] += 2.358124998265639e-05;
                          }
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.714147492562814179) ) ) {
                            result[0] += -4.609668060728863e-05;
                          } else {
                            result[0] += -7.542087615099959e-06;
                          }
                        }
                      }
                    }
                  }
                }
              } else {
                result[0] += 0.00018039464203713936;
              }
            } else {
              result[0] += -3.0878732856011762e-06;
            }
          } else {
            result[0] += 0.0008091732857608802;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0119121105025029022) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01127328256994905228) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.249304608119721216) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.180517123172382332) ) ) {
                  result[0] += 1.9483403742621433e-06;
                } else {
                  result[0] += -0.00044188848054241736;
                }
              } else {
                result[0] += 9.029410102086753e-05;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2739990068871500095) ) ) {
                result[0] += 6.46531240572631e-05;
              } else {
                result[0] += -0.0005192199469469235;
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.96280210579579717) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01210357511382575101) ) ) {
                result[0] += 0.001035847415324902;
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6782348568386622478) ) ) {
                  if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.8537219630417757221) ) ) {
                    result[0] += 1.559482795697093e-05;
                  } else {
                    result[0] += -0.0010014337822148412;
                  }
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6269304705026225166) ) ) {
                    result[0] += 0.001242323656475341;
                  } else {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5261805248634544574) ) ) {
                      result[0] += -0.00029706380352854814;
                    } else {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.316132418552224348) ) ) {
                        result[0] += 0.000764180309021047;
                      } else {
                        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.244955337349149066) ) ) {
                          result[0] += -0.00017303663822407366;
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.723113719091885043) ) ) {
                            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.194581012612933923) ) ) {
                              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.121680358022378199) ) ) {
                                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
                                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6558660377084782889) ) ) {
                                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5986852915639623296) ) ) {
                                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.564374608675820677) ) ) {
                                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3115605993075549196) ) ) {
                                          result[0] += 0.0003085122977260729;
                                        } else {
                                          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3665106630729573767) ) ) {
                                            result[0] += -0.0013037092114370596;
                                          } else {
                                            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3966559369710560001) ) ) {
                                              result[0] += 0.0008132694380837036;
                                            } else {
                                              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4364163272837385255) ) ) {
                                                result[0] += -0.0001123147878230991;
                                              } else {
                                                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5018975334485012985) ) ) {
                                                  result[0] += 0.0008568675119961985;
                                                } else {
                                                  result[0] += -0.00011327330275554035;
                                                }
                                              }
                                            }
                                          }
                                        }
                                      } else {
                                        result[0] += 0.0007093209678923066;
                                      }
                                    } else {
                                      result[0] += -0.00017916878515178924;
                                    }
                                  } else {
                                    result[0] += 0.0010658754923899487;
                                  }
                                } else {
                                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9112103514676580529) ) ) {
                                    result[0] += -0.00030994707891315317;
                                  } else {
                                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9567162861906464144) ) ) {
                                      result[0] += 0.00046561726437935173;
                                    } else {
                                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                                        result[0] += -0.00012986286021553074;
                                      } else {
                                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.051391296366422923) ) ) {
                                          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.039722088301102687) ) ) {
                                            result[0] += -1.8118373107041087e-05;
                                          } else {
                                            result[0] += 0.0033521187984415315;
                                          }
                                        } else {
                                          result[0] += -0.00039294057198516837;
                                        }
                                      }
                                    }
                                  }
                                }
                              } else {
                                result[0] += 0.0009867936307226502;
                              }
                            } else {
                              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.224356303145077041) ) ) {
                                result[0] += -0.0006371297383414664;
                              } else {
                                result[0] += -4.192148735866596e-05;
                              }
                            }
                          } else {
                            result[0] += 0.0005606661990955772;
                          }
                        }
                      }
                    }
                  }
                }
              }
            } else {
              result[0] += -0.000620849463980209;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005473500000000000067) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3569067370100503234) ) ) {
              result[0] += -0.00018490616387942493;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008332142139858200389) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005972045269192751034) ) ) {
                  result[0] += 0.0014915667010674846;
                } else {
                  result[0] += -0.0011752336879081806;
                }
              } else {
                result[0] += 0.0014218234584335236;
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021562361187840079) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6487823756783920315) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3830383354773237436) ) ) {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.9159493641278110276) ) ) {
                    result[0] += 0.0029637407435813036;
                  } else {
                    result[0] += 0.0002275974558875537;
                  }
                } else {
                  result[0] += -0.002247489889049094;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7733398996305392847) ) ) {
                  result[0] += 0.0016040891236799154;
                } else {
                  result[0] += 3.595158808456829e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
                result[0] += 9.807270777965276e-06;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1250629713251516228) ) ) {
                  result[0] += 0.0016448352683564823;
                } else {
                  result[0] += 0.0004613972432607337;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
            result[0] += 0.001318887878171014;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01085750000000000083) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01021941412521685209) ) ) {
                result[0] += 3.645213621816636e-05;
              } else {
                result[0] += 0.0012651385050677026;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8440161800932387548) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01881166515770610337) ) ) {
                    result[0] += -0.00018791377205625603;
                  } else {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1828583041203602211) ) ) {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6782348568386622478) ) ) {
                        result[0] += 0.00046320109567691637;
                      } else {
                        result[0] += 0.001180179867683855;
                      }
                    } else {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1126213758155867467) ) ) {
                        result[0] += -0.00030917418639522283;
                      } else {
                        result[0] += 0.0008477343901713444;
                      }
                    }
                  }
                } else {
                  result[0] += -0.00032806514132731346;
                }
              } else {
                result[0] += 0.0013828759642082525;
              }
            }
          }
        }
      }
    }
  }
}

