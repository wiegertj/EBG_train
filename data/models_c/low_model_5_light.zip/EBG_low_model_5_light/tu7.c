
#include "header.h"

void predict_unit7(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -7.166324421381476e-07;
            } else {
              result[0] += -1.7024723928094762e-06;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.7024723928094762e-06;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -1.7024723928094762e-06;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -1.7024723928094762e-06;
                } else {
                  result[0] += -1.7024723928094762e-06;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4754075198241206057) ) ) {
            result[0] += 0.0001420155007822733;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)30.50000000000000355) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6323035877889447987) ) ) {
                result[0] += -1.415179074998519e-05;
              } else {
                result[0] += -0.0009541120432157241;
              }
            } else {
              result[0] += -1.7009718229447216e-06;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -1.7024723928094762e-06;
                } else {
                  result[0] += -1.7024723928094762e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -1.7024723928094762e-06;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -1.7024723928094762e-06;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -1.7024723928094762e-06;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -1.7024723928094762e-06;
                      } else {
                        result[0] += -1.7024723928094762e-06;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -1.7024723928094762e-06;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -1.7024723928094762e-06;
                  } else {
                    result[0] += -1.7024723928094762e-06;
                  }
                }
              } else {
                result[0] += -1.7024723928094762e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -1.7024723928094762e-06;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -1.7024723928094762e-06;
                } else {
                  result[0] += -1.7024723928094762e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -1.7024723928094762e-06;
                } else {
                  result[0] += -1.7024723928094762e-06;
                }
              }
            }
          }
        } else {
          result[0] += -1.9027966862443055e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)89.50000000000001421) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7638563461306534519) ) ) {
              result[0] += -7.175845752430298e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.316725863161028132) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)7.597155088881926898e-06) ) ) {
                  result[0] += -0.0006927577365000086;
                } else {
                  result[0] += -0.00031794728108644146;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06270917377236372159) ) ) {
                  result[0] += 0.00030199665128899004;
                } else {
                  result[0] += -0.0018360635008685803;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.115000000000000005) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7948036090201006099) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7712418641206031378) ) ) {
                  result[0] += -0.00011525827763470463;
                } else {
                  result[0] += -0.00040039987337099246;
                }
              } else {
                result[0] += 0.0001453605144162211;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01369138287730510203) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5050000000000001155) ) ) {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3498337084924623697) ) ) {
                    result[0] += -0.0028070216375475107;
                  } else {
                    result[0] += 0.00102015512674251;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6950000000000000622) ) ) {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)284.5000000000000568) ) ) {
                      result[0] += -9.184019679365722e-05;
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4750000000000000333) ) ) {
                        result[0] += -0.0034855862861411803;
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6650000000000001465) ) ) {
                          result[0] += 0.00015181389739945148;
                        } else {
                          result[0] += -0.002622847734691862;
                        }
                      }
                    }
                  } else {
                    result[0] += 0.00038160369053774065;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.04446937286580055632) ) ) {
                  result[0] += 0.0022558117813178745;
                } else {
                  result[0] += 0.0004927648523391808;
                }
              }
            }
          }
        } else {
          result[0] += 0.0021990649852734064;
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.9546544174008676498) ) ) {
          result[0] += 0.001866061449002857;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1271566581126106488) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9194299814036738239) ) ) {
              result[0] += 0.0010503345010419813;
            } else {
              result[0] += -0.002257906183317299;
            }
          } else {
            result[0] += 0.0019221001918872719;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -6.385349438214986e-07;
            } else {
              result[0] += -1.5169395770819584e-06;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.5169395770819584e-06;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -1.5169395770819584e-06;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -1.5169395770819584e-06;
                } else {
                  result[0] += -1.5169395770819584e-06;
                }
              }
            }
          }
        } else {
          result[0] += -1.3214615630581221e-06;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -1.5169395770819584e-06;
                } else {
                  result[0] += -1.5169395770819584e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -1.5169395770819584e-06;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -1.5169395770819584e-06;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -1.5169395770819584e-06;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -1.5169395770819584e-06;
                      } else {
                        result[0] += -1.5169395770819584e-06;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -1.5169395770819584e-06;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -1.5169395770819584e-06;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02928050000000000444) ) ) {
                      result[0] += -1.5169395770819584e-06;
                    } else {
                      result[0] += -1.5169395770819584e-06;
                    }
                  }
                }
              } else {
                result[0] += -1.5169395770819584e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -1.5169395770819584e-06;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -1.5169395770819584e-06;
                } else {
                  result[0] += -1.5169395770819584e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -1.5169395770819584e-06;
                } else {
                  result[0] += -1.5169395770819584e-06;
                }
              }
            }
          }
        } else {
          result[0] += -1.6954328379687322e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.641728423423682037e-06) ) ) {
          result[0] += -0.00013288548081934851;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)37.50000000000000711) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)18.50000000000000355) ) ) {
              result[0] += 0.00015428328663987632;
            } else {
              result[0] += -0.0002981975043683504;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7293938685427137081) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04088342693368870323) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00448250000000000124) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.09274867639439776656) ) ) {
                      result[0] += -0.0004916828077047764;
                    } else {
                      result[0] += -9.858623270673452e-05;
                    }
                  } else {
                    result[0] += 0.0004209161910085105;
                  }
                } else {
                  result[0] += -2.756432527197241e-05;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3950000000000000733) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06779550000000000853) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3050000000000000488) ) ) {
                        result[0] += 0.00018271637590909474;
                      } else {
                        result[0] += -0.006246081219140135;
                      }
                    } else {
                      result[0] += 0.0026775443111899224;
                    }
                  } else {
                    result[0] += 0.005234643295858679;
                  }
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02985350000000000156) ) ) {
                    result[0] += 0.0015092244733186915;
                  } else {
                    result[0] += -0.0017664106549474057;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7377710019346734871) ) ) {
                result[0] += -0.0015316120690247934;
              } else {
                result[0] += 5.689503056215909e-06;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.9546544174008676498) ) ) {
          result[0] += 0.0016627009502268818;
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
            result[0] += 2.3834081304972482e-05;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3830383354773237436) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)34.50000000000000711) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03264450000000000685) ) ) {
                  result[0] += 0.001768860352673323;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
                    result[0] += -0.0013117618230781554;
                  } else {
                    result[0] += 0.002076591605785481;
                  }
                }
              } else {
                result[0] += 0.0016597445819853019;
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6037488751507539275) ) ) {
                result[0] += -0.005149100211472299;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09998752698574815689) ) ) {
                  result[0] += -0.001477830731410087;
                } else {
                  result[0] += 0.0013535905879541131;
                }
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -5.689483904253777e-07;
            } else {
              result[0] += -1.351625841474134e-06;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.351625841474134e-06;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -1.351625841474134e-06;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -1.351625841474134e-06;
                } else {
                  result[0] += -1.351625841474134e-06;
                }
              }
            }
          }
        } else {
          result[0] += -1.1774507199423254e-06;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -1.351625841474134e-06;
                } else {
                  result[0] += -1.351625841474134e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -1.351625841474134e-06;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -1.351625841474134e-06;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -1.351625841474134e-06;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -1.351625841474134e-06;
                      } else {
                        result[0] += -1.351625841474134e-06;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -1.351625841474134e-06;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -1.351625841474134e-06;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02928050000000000444) ) ) {
                      result[0] += -1.351625841474134e-06;
                    } else {
                      result[0] += -1.351625841474134e-06;
                    }
                  }
                }
              } else {
                result[0] += -1.351625841474134e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -1.351625841474134e-06;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -1.351625841474134e-06;
                } else {
                  result[0] += -1.351625841474134e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -1.351625841474134e-06;
                } else {
                  result[0] += -1.351625841474134e-06;
                }
              }
            }
          }
        } else {
          result[0] += -1.5106671820709936e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02664459509800340062) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002982500000000000342) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.676837902221867901e-06) ) ) {
              result[0] += -6.586308887388379e-05;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.442840729522613108) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3687216492462311868) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001240500000000000066) ) ) {
                    result[0] += 0.0012161788192984;
                  } else {
                    result[0] += -0.0020174506741872733;
                  }
                } else {
                  result[0] += 0.002272399162752657;
                }
              } else {
                result[0] += 8.538634157785099e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5350000000000001421) ) ) {
              result[0] += 6.652163139664072e-05;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6850000000000001643) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01221850000000000193) ) ) {
                  result[0] += -0.0017490439922988133;
                } else {
                  result[0] += -0.00010840411344851211;
                }
              } else {
                result[0] += -0.00014602615903380205;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1507499186893259402) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)114.5000000000000142) ) ) {
              result[0] += 0.0009689826543981132;
            } else {
              result[0] += 0.002042320341813604;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5613386861055277288) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
                result[0] += 0.0001910511773450371;
              } else {
                result[0] += -0.009947778109064345;
              }
            } else {
              result[0] += 9.316974842635781e-05;
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.9546544174008676498) ) ) {
          result[0] += 0.0014815023649744387;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1271566581126106488) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)117.5000000000000142) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9310018456912946272) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02374450000000000519) ) ) {
                  result[0] += 0.0010725207636459078;
                } else {
                  result[0] += -0.0004240411918601538;
                }
              } else {
                result[0] += -0.004815178412217765;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07184972061993401271) ) ) {
                result[0] += 0.0006642835728682015;
              } else {
                result[0] += 0.0018282221098416644;
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)48.50000000000000711) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3801755927260667134) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03676400000000001195) ) ) {
                  result[0] += 0.0016513986754862963;
                } else {
                  result[0] += -0.0004101186749931633;
                }
              } else {
                result[0] += 0.0017925953260701972;
              }
            } else {
              result[0] += 0.001764683744117005;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -5.069452722984024e-07;
            } else {
              result[0] += -1.2043277418174687e-06;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.2043277418174687e-06;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -1.2043277418174687e-06;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -1.2043277418174687e-06;
                } else {
                  result[0] += -1.2043277418174687e-06;
                }
              }
            }
          }
        } else {
          result[0] += -1.0491339564083283e-06;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -1.2043277418174687e-06;
                } else {
                  result[0] += -1.2043277418174687e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.06536400211476856) ) ) {
                    result[0] += -1.2043277418174687e-06;
                  } else {
                    result[0] += -1.2043277418174687e-06;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -1.2043277418174687e-06;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -1.2043277418174687e-06;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -1.2043277418174687e-06;
                      } else {
                        result[0] += -1.2043277418174687e-06;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -1.2043277418174687e-06;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -1.2043277418174687e-06;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02928050000000000444) ) ) {
                      result[0] += -1.2043277418174687e-06;
                    } else {
                      result[0] += -1.2043277418174687e-06;
                    }
                  }
                }
              } else {
                result[0] += -1.2043277418174687e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -1.2043277418174687e-06;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -1.2043277418174687e-06;
                } else {
                  result[0] += -1.2043277418174687e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -1.2043277418174687e-06;
                } else {
                  result[0] += -1.2043277418174687e-06;
                }
              }
            }
          }
        } else {
          result[0] += -1.3460370023978527e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)89.50000000000001421) ) ) {
            result[0] += -3.271769639818052e-05;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.115000000000000005) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.29500000000000004) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7948036090201006099) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7712418641206031378) ) ) {
                    result[0] += -0.00010075963122675704;
                  } else {
                    result[0] += -0.00032729228096271785;
                  }
                } else {
                  result[0] += 0.00015172585021232848;
                }
              } else {
                result[0] += -0.0019018404280625174;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.04446937286580055632) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.00183922645599140025) ) ) {
                  result[0] += -0.00045234384199349876;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)425.5000000000000568) ) ) {
                    result[0] += 0.0015441796691961255;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.795000000000000151) ) ) {
                      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.08377477200961473691) ) ) {
                        result[0] += -0.0012791666782253758;
                      } else {
                        result[0] += 0.0038920870419863174;
                      }
                    } else {
                      result[0] += -0.0020771222617597604;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
                  result[0] += 0.0021341616072006134;
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6273136390703518694) ) ) {
                    result[0] += -0.0006826813527992648;
                  } else {
                    result[0] += 0.00037844813982422124;
                  }
                }
              }
            }
          }
        } else {
          result[0] += 0.001966721771423478;
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.9546544174008676498) ) ) {
          result[0] += 0.0013200505220889902;
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
            result[0] += -5.205106226045479e-05;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3783101257612192514) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)76.50000000000001421) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2394849609754011732) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02812450000000000366) ) ) {
                    result[0] += 0.0013957678880186502;
                  } else {
                    result[0] += 6.822153791758151e-05;
                  }
                } else {
                  result[0] += 0.0015723712312695546;
                }
              } else {
                result[0] += 0.0015723712312695546;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.103377615329305908) ) ) {
                result[0] += -0.001120570469549564;
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6017346544472362835) ) ) {
                  result[0] += -0.0037403651338042752;
                } else {
                  result[0] += 0.001021199293184362;
                }
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -4.5169915836046807e-07;
            } else {
              result[0] += -1.0730819618906493e-06;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.0730819618906493e-06;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -1.0730819618906493e-06;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -1.0730819618906493e-06;
                } else {
                  result[0] += -1.0730819618906493e-06;
                }
              }
            }
          }
        } else {
          result[0] += -9.348009558675252e-07;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -1.0730819618906493e-06;
                } else {
                  result[0] += -1.0730819618906493e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.06536400211476856) ) ) {
                    result[0] += -1.0730819618906493e-06;
                  } else {
                    result[0] += -1.0730819618906493e-06;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -1.0730819618906493e-06;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -1.0730819618906493e-06;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -1.0730819618906493e-06;
                      } else {
                        result[0] += -1.0730819618906493e-06;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -1.0730819618906493e-06;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -1.0730819618906493e-06;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02928050000000000444) ) ) {
                      result[0] += -1.0730819618906493e-06;
                    } else {
                      result[0] += -1.0730819618906493e-06;
                    }
                  }
                }
              } else {
                result[0] += -1.0730819618906493e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -1.0730819618906493e-06;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -1.0730819618906493e-06;
                } else {
                  result[0] += -1.0730819618906493e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -1.0730819618906493e-06;
                } else {
                  result[0] += -1.0730819618906493e-06;
                }
              }
            }
          }
        } else {
          result[0] += -1.199347965804324e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.641728423423682037e-06) ) ) {
            result[0] += -0.00012302278217710155;
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)89.50000000000001421) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001475500000000000249) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2150000000000000244) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1250000000000000278) ) ) {
                    result[0] += 2.4022170190409615e-05;
                  } else {
                    result[0] += -0.0018470743806453175;
                  }
                } else {
                  result[0] += 0.0012360358175081004;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9808239647505231362) ) ) {
                  result[0] += -8.349574615961403e-05;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.0144392355375913) ) ) {
                    result[0] += -0.0043263604281019415;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05067558311325295883) ) ) {
                      result[0] += 0.00022381186552747174;
                    } else {
                      result[0] += -0.0027713489688165165;
                    }
                  }
                }
              }
            } else {
              result[0] += 0.0001677145231727088;
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)15.50000000000000178) ) ) {
            result[0] += -0.0006169382134237869;
          } else {
            result[0] += 0.0023990899458199806;
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.9546544174008676498) ) ) {
          result[0] += 0.0011761934520418344;
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02687100000000000252) ) ) {
              result[0] += 0.0015111489776888619;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4465236086683417871) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)100.5000000000000142) ) ) {
                  result[0] += -0.018537516166381645;
                } else {
                  result[0] += 0.001141098725521537;
                }
              } else {
                result[0] += -7.353683140404393e-05;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3783101257612192514) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)113.5000000000000142) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2394849609754011732) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01775050000000000239) ) ) {
                    result[0] += 0.0015217807689106412;
                  } else {
                    result[0] += 0.0004723246899158058;
                  }
                } else {
                  result[0] += 0.0014010166394779302;
                }
              } else {
                result[0] += 0.0014010166394779302;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.103377615329305908) ) ) {
                result[0] += -0.0009984524279797043;
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6017346544472362835) ) ) {
                  result[0] += -0.0033327459101065897;
                } else {
                  result[0] += 0.000909910569159429;
                }
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -4.0247368071612627e-07;
            } else {
              result[0] += -9.561391446462338e-07;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -9.561391446462338e-07;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -9.561391446462338e-07;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -9.561391446462338e-07;
                } else {
                  result[0] += -9.561391446462338e-07;
                }
              }
            }
          }
        } else {
          result[0] += -8.329277893954001e-07;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -9.561391446462338e-07;
                } else {
                  result[0] += -9.561391446462338e-07;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.06536400211476856) ) ) {
                    result[0] += -9.561391446462338e-07;
                  } else {
                    result[0] += -9.561391446462338e-07;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -9.561391446462338e-07;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -9.561391446462338e-07;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -9.561391446462338e-07;
                      } else {
                        result[0] += -9.561391446462338e-07;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -9.561391446462338e-07;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -9.561391446462338e-07;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02928050000000000444) ) ) {
                      result[0] += -9.561391446462338e-07;
                    } else {
                      result[0] += -9.561391446462338e-07;
                    }
                  }
                }
              } else {
                result[0] += -9.561391446462338e-07;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -9.561391446462338e-07;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -9.561391446462338e-07;
                } else {
                  result[0] += -9.561391446462338e-07;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -9.561391446462338e-07;
                } else {
                  result[0] += -9.561391446462338e-07;
                }
              }
            }
          }
        } else {
          result[0] += -1.0686448741873495e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7750000000000001332) ) ) {
            result[0] += -9.651720380512796e-06;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03945037468542575421) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00448250000000000124) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001570360081376600365) ) ) {
                    result[0] += -0.0027068933204009342;
                  } else {
                    result[0] += 0.0036003984171903204;
                  }
                } else {
                  result[0] += -3.052270489828024e-05;
                }
              } else {
                result[0] += 0.0022422993646173616;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)782.5000000000001137) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
                    result[0] += 0.000300933846882112;
                  } else {
                    result[0] += 0.004802050628990614;
                  }
                } else {
                  result[0] += -0.003167749794507272;
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)221.5000000000000284) ) ) {
                  result[0] += -0.0020078415967004254;
                } else {
                  result[0] += 0.0009676316842751241;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)15.50000000000000178) ) ) {
            result[0] += -0.0005497052383988405;
          } else {
            result[0] += 0.002137640823524953;
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.9546544174008676498) ) ) {
          result[0] += 0.001048013703624614;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1271566581126106488) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
              result[0] += -0.006833101311039647;
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3998230401234152409) ) ) {
                result[0] += 0.0013769192487360616;
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4007818937688442662) ) ) {
                  result[0] += -0.007773545129847205;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01008250000000000292) ) ) {
                    result[0] += 0.001541560811170909;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.06536400211476856) ) ) {
                      result[0] += 0.00034630000829580725;
                    } else {
                      result[0] += -0.0023782086937305905;
                    }
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)48.50000000000000711) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3801755927260667134) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03676400000000001195) ) ) {
                  result[0] += 0.0012136916102675008;
                } else {
                  result[0] += -0.0005012101754032029;
                }
              } else {
                result[0] += 0.0012732058276264649;
              }
            } else {
              result[0] += 0.001248336006827855;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -3.5861271970737127e-07;
            } else {
              result[0] += -8.519405752698619e-07;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -8.519405752698619e-07;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -8.519405752698619e-07;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -8.519405752698619e-07;
                } else {
                  result[0] += -8.519405752698619e-07;
                }
              }
            }
          }
        } else {
          result[0] += -7.421566034913478e-07;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -8.519405752698619e-07;
                } else {
                  result[0] += -8.519405752698619e-07;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.06536400211476856) ) ) {
                    result[0] += -8.519405752698619e-07;
                  } else {
                    result[0] += -8.519405752698619e-07;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -8.519405752698619e-07;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -8.519405752698619e-07;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -8.519405752698619e-07;
                      } else {
                        result[0] += -8.519405752698619e-07;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -8.519405752698619e-07;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -8.519405752698619e-07;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02928050000000000444) ) ) {
                      result[0] += -8.519405752698619e-07;
                    } else {
                      result[0] += -8.519405752698619e-07;
                    }
                  }
                }
              } else {
                result[0] += -8.519405752698619e-07;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -8.519405752698619e-07;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -8.519405752698619e-07;
                } else {
                  result[0] += -8.519405752698619e-07;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -8.519405752698619e-07;
                } else {
                  result[0] += -8.519405752698619e-07;
                }
              }
            }
          }
        } else {
          result[0] += -9.521856039177337e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0465984882276438625) ) ) {
          result[0] += 1.666922247042069e-07;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.213351496714494937) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1350000000000000366) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7156546188693468924) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06679007938737886729) ) ) {
                  result[0] += 0.002294780095634246;
                } else {
                  result[0] += -0.0018438913827049793;
                }
              } else {
                result[0] += -0.00048787566316360853;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)2.500000000000000444) ) ) {
                result[0] += -0.00426467569069978;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006979000000000000828) ) ) {
                  result[0] += 0.001907017341525266;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9750000000000000888) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06779550000000000853) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7250000000000000888) ) ) {
                        result[0] += -7.175848725058047e-06;
                      } else {
                        result[0] += 0.007350222180792303;
                      }
                    } else {
                      result[0] += 0.005613564851326149;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8150000000000000577) ) ) {
                      result[0] += -0.005463200235563424;
                    } else {
                      result[0] += 0.0005866973716337858;
                    }
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1350000000000000366) ) ) {
              result[0] += 0.000637391058188958;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8257879984924624273) ) ) {
                result[0] += -0.009819458450871621;
              } else {
                result[0] += -0.0003534649384431131;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.9546544174008676498) ) ) {
          result[0] += 0.0009338027865044682;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2162432673096428282) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01112050000000000191) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
                result[0] += 1.9475461687934583e-05;
              } else {
                result[0] += 0.0013155067433007418;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8440161800932387548) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
                  result[0] += -0.000285068971420159;
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2450759342279490716) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
                      result[0] += -0.00018644650177872997;
                    } else {
                      result[0] += 0.0011315861405869776;
                    }
                  } else {
                    result[0] += 0.0004298894397476683;
                  }
                }
              } else {
                result[0] += -0.000889447730677546;
              }
            }
          } else {
            result[0] += 0.0011122942740520254;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -3.1953165858473764e-07;
            } else {
              result[0] += -7.590974052837112e-07;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -7.590974052837112e-07;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -7.590974052837112e-07;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -7.590974052837112e-07;
                } else {
                  result[0] += -7.590974052837112e-07;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.435405567110552727) ) ) {
            result[0] += 0.0051907149501826556;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.09274867639439776656) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.008240561420177351659) ) ) {
                result[0] += -0.00017928683758087048;
              } else {
                result[0] += -1.6146473429390823e-06;
              }
            } else {
              result[0] += 1.0859744363488305e-06;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -7.590974052837112e-07;
                } else {
                  result[0] += -7.590974052837112e-07;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.06536400211476856) ) ) {
                    result[0] += -7.590974052837112e-07;
                  } else {
                    result[0] += -7.590974052837112e-07;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -7.590974052837112e-07;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -7.590974052837112e-07;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -7.590974052837112e-07;
                      } else {
                        result[0] += -7.590974052837112e-07;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -7.590974052837112e-07;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -7.590974052837112e-07;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02928050000000000444) ) ) {
                      result[0] += -7.590974052837112e-07;
                    } else {
                      result[0] += -7.590974052837112e-07;
                    }
                  }
                }
              } else {
                result[0] += -7.590974052837112e-07;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -7.590974052837112e-07;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -7.590974052837112e-07;
                } else {
                  result[0] += -7.590974052837112e-07;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -7.590974052837112e-07;
                } else {
                  result[0] += -7.590974052837112e-07;
                }
              }
            }
          }
        } else {
          result[0] += -8.484178853125989e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1329848183536343209) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8650000000000001021) ) ) {
            result[0] += -1.0836323951203252e-05;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005491500000000000721) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.00802520011231920051) ) ) {
                result[0] += 0.0005796502352862263;
              } else {
                result[0] += 0.0028877379024380557;
              }
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1828583041203602211) ) ) {
                result[0] += 0.0012290206085981744;
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5196530228391961215) ) ) {
                  result[0] += -0.004378679637879258;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03415342701090800376) ) ) {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)191.5000000000000284) ) ) {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
                        result[0] += 0.005935172010452676;
                      } else {
                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02403426826619565679) ) ) {
                          result[0] += -0.0007023824772518827;
                        } else {
                          result[0] += -0.007877031485521388;
                        }
                      }
                    } else {
                      result[0] += 0.001235384638928669;
                    }
                  } else {
                    result[0] += 0.0013126609264201648;
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.5724391781153673753) ) ) {
            result[0] += -0.005477694395501884;
          } else {
            result[0] += 0.001291312171474516;
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.9546544174008676498) ) ) {
          result[0] += 0.0008320383989901018;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2162432673096428282) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9993516786272610419) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01738250000000000559) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02937690275817125482) ) ) {
                  result[0] += 0.00046639456863123267;
                } else {
                  result[0] += 0.0010464749302682374;
                }
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)34.50000000000000711) ) ) {
                  result[0] += -0.0011986966452185463;
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4378622240954774258) ) ) {
                    result[0] += 0.0010082676281764056;
                  } else {
                    result[0] += 0.0004407875753140617;
                  }
                }
              }
            } else {
              result[0] += -0.0008311699120027094;
            }
          } else {
            result[0] += 0.0009910781595035174;
          }
        }
      }
    }
  }
}

