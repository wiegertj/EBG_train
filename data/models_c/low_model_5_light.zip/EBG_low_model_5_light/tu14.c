
#include "header.h"

void predict_unit14(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -4.451273739676482e-08;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -4.451273739676482e-08;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -4.451273739676482e-08;
              } else {
                result[0] += -4.451273739676482e-08;
              }
            }
          }
        } else {
          result[0] += -3.2962258838599115e-09;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.384300133116745416e-05) ) ) {
                result[0] += -4.451273739676482e-08;
              } else {
                result[0] += -4.451273739676482e-08;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -4.451273739676482e-08;
                  } else {
                    result[0] += -4.451273739676482e-08;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -4.451273739676482e-08;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -4.451273739676482e-08;
                        } else {
                          result[0] += -4.451273739676482e-08;
                        }
                      } else {
                        result[0] += -4.451273739676482e-08;
                      }
                    }
                  } else {
                    result[0] += -4.451273739676482e-08;
                  }
                }
              } else {
                result[0] += -4.451273739676482e-08;
              }
            }
          } else {
            result[0] += -4.451273739676482e-08;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -4.451273739676482e-08;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -4.451273739676482e-08;
                } else {
                  result[0] += -4.451273739676482e-08;
                }
              } else {
                result[0] += -4.451273739676482e-08;
              }
            } else {
              result[0] += -4.451273739676482e-08;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4000638056452025526) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1254545000000000243) ) ) {
            if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4026472078210281969) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003690377133234250349) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001504690974371400121) ) ) {
                    result[0] += 2.4866417155207383e-05;
                  } else {
                    result[0] += 0.0004907980121876599;
                  }
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004867285882244350333) ) ) {
                    result[0] += -0.0012591727705924822;
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005972045269192751034) ) ) {
                      result[0] += 0.0009204969090153626;
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007472892829241450756) ) ) {
                        result[0] += -0.00041796364753702285;
                      } else {
                        result[0] += -6.495254295537117e-05;
                      }
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04247438584267165113) ) ) {
                  result[0] += 0.00018934997616237417;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0526089167981486569) ) ) {
                    result[0] += -0.00013045302887744546;
                  } else {
                    result[0] += 2.5375399060974793e-05;
                  }
                }
              }
            } else {
              result[0] += 0.0019209794489952541;
            }
          } else {
            if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6269304705026225166) ) ) {
              result[0] += 5.590492120806977e-05;
            } else {
              result[0] += 5.270751122300782e-06;
            }
          }
        } else {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.378188349821562797) ) ) {
            result[0] += -0.0016825680709207657;
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3539353041941689093) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4734952854020100799) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4419864859045226635) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4138030768592965147) ) ) {
                    result[0] += 0.00026241525362847716;
                  } else {
                    result[0] += 0.0003797660192306714;
                  }
                } else {
                  result[0] += -7.150064975507924e-05;
                }
              } else {
                result[0] += 0.0006521894364358352;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4251092621105527214) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004132000000000001123) ) ) {
                  result[0] += 1.1773616705596606e-05;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01387300000000000165) ) ) {
                    result[0] += -0.0005896969586180183;
                  } else {
                    result[0] += -0.0009943223337650704;
                  }
                }
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3329403679585331566) ) ) {
                  result[0] += -0.0006226250391403734;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05463331189772155372) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5800027599246232457) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02733191529475900369) ) ) {
                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6650000000000001465) ) ) {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5493276582412061071) ) ) {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4643511832914573034) ) ) {
                              result[0] += 0.00030327460085528217;
                            } else {
                              result[0] += -9.860249858719013e-05;
                            }
                          } else {
                            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5612777274623116375) ) ) {
                              result[0] += 0.0003734801997765316;
                            } else {
                              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5671541132663318052) ) ) {
                                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5628434130653267031) ) ) {
                                  result[0] += 7.329404073310374e-06;
                                } else {
                                  result[0] += -0.0013520589794573288;
                                }
                              } else {
                                result[0] += 0.00048379998409341985;
                              }
                            }
                          }
                        } else {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7050000000000000711) ) ) {
                            result[0] += 0.00033488589054969246;
                          } else {
                            result[0] += 6.424942605815886e-05;
                          }
                        }
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5271332674874372737) ) ) {
                          result[0] += -0.000226847932189902;
                        } else {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.25500000000000006) ) ) {
                            result[0] += 0.00021424715856324927;
                          } else {
                            result[0] += 0.00042350726832163715;
                          }
                        }
                      }
                    } else {
                      result[0] += -0.0005296067896484153;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5628434130653267031) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5392784256532664466) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5284121414321608645) ) ) {
                          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09956041386891252565) ) ) {
                            result[0] += 0.00034179009497232354;
                          } else {
                            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2326999203141443262) ) ) {
                              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.512360309673366987) ) ) {
                                result[0] += -0.0018142376048507342;
                              } else {
                                result[0] += -0.0005454566268596186;
                              }
                            } else {
                              result[0] += 5.5388063449199906e-05;
                            }
                          }
                        } else {
                          result[0] += 0.0006248736798473511;
                        }
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3251271839107726103) ) ) {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5400528323115579843) ) ) {
                            result[0] += -0.002161271556829066;
                          } else {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5499504253266332965) ) ) {
                              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1738383111593791719) ) ) {
                                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1206324332205917643) ) ) {
                                  result[0] += -0.00022704430184562285;
                                } else {
                                  result[0] += -0.0013406372940817114;
                                }
                              } else {
                                result[0] += 1.0015207323691985e-05;
                              }
                            } else {
                              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.55780239615577909) ) ) {
                                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.07274795227358500649) ) ) {
                                  result[0] += -0.0002261483804889307;
                                } else {
                                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1405997886577425304) ) ) {
                                    result[0] += 0.0009583604576757961;
                                  } else {
                                    result[0] += -2.551480102010662e-06;
                                  }
                                }
                              } else {
                                result[0] += -0.0003547351377350735;
                              }
                            }
                          }
                        } else {
                          result[0] += -0.0020048629858573468;
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08693186820944626136) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.06355808660527756393) ) ) {
                          result[0] += 0.00042459710010886534;
                        } else {
                          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08407783631914581002) ) ) {
                            result[0] += -0.0004375268742481737;
                          } else {
                            result[0] += -0.0003124598336976346;
                          }
                        }
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5800027599246232457) ) ) {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5748180127889448432) ) ) {
                            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5745673188442211865) ) ) {
                              result[0] += 0.0002783660467024829;
                            } else {
                              result[0] += -0.0001858865472856775;
                            }
                          } else {
                            result[0] += 0.0006693714800539811;
                          }
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5834559473869348478) ) ) {
                            result[0] += -0.00029415942881720294;
                          } else {
                            result[0] += 7.198323375919066e-07;
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      } else {
        result[0] += 2.702245101370911e-05;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -4.274092368557761e-08;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -4.274092368557761e-08;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -4.274092368557761e-08;
              } else {
                result[0] += -4.274092368557761e-08;
              }
            }
          }
        } else {
          result[0] += -3.165020782629322e-09;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.384300133116745416e-05) ) ) {
                result[0] += -4.274092368557761e-08;
              } else {
                result[0] += -4.274092368557761e-08;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -4.274092368557761e-08;
                  } else {
                    result[0] += -4.274092368557761e-08;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -4.274092368557761e-08;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -4.274092368557761e-08;
                        } else {
                          result[0] += -4.274092368557761e-08;
                        }
                      } else {
                        result[0] += -4.274092368557761e-08;
                      }
                    }
                  } else {
                    result[0] += -4.274092368557761e-08;
                  }
                }
              } else {
                result[0] += -4.274092368557761e-08;
              }
            }
          } else {
            result[0] += -4.274092368557761e-08;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -4.274092368557761e-08;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -4.274092368557761e-08;
                } else {
                  result[0] += -4.274092368557761e-08;
                }
              } else {
                result[0] += -4.274092368557761e-08;
              }
            } else {
              result[0] += -4.274092368557761e-08;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9450000000000000622) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
          result[0] += 5.881540791465606e-07;
        } else {
          result[0] += 0.00041618744478901355;
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 2.8862172544206136e-05;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2929122217587940002) ) ) {
              result[0] += -0.0002897268658443522;
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4323286620486300191) ) ) {
                result[0] += 6.906743662112438e-05;
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.378188349821562797) ) ) {
                  result[0] += -0.0008107791012302042;
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2302999793555680907) ) ) {
                    result[0] += 0.00011963805180652653;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.314196657149456993) ) ) {
                      result[0] += 3.894699620597301e-05;
                    } else {
                      result[0] += -0.0005620904330688046;
                    }
                  }
                }
              }
            }
          } else {
            result[0] += 2.5946831943391878e-05;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -4.103963639021535e-08;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -4.103963639021535e-08;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -4.103963639021535e-08;
              } else {
                result[0] += -4.103963639021535e-08;
              }
            }
          }
        } else {
          result[0] += -3.0390382538787377e-09;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.384300133116745416e-05) ) ) {
                result[0] += -4.103963639021535e-08;
              } else {
                result[0] += -4.103963639021535e-08;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -4.103963639021535e-08;
                  } else {
                    result[0] += -4.103963639021535e-08;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -4.103963639021535e-08;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -4.103963639021535e-08;
                        } else {
                          result[0] += -4.103963639021535e-08;
                        }
                      } else {
                        result[0] += -4.103963639021535e-08;
                      }
                    }
                  } else {
                    result[0] += -4.103963639021535e-08;
                  }
                }
              } else {
                result[0] += -4.103963639021535e-08;
              }
            }
          } else {
            result[0] += -4.103963639021535e-08;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -4.103963639021535e-08;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -4.103963639021535e-08;
                } else {
                  result[0] += -4.103963639021535e-08;
                }
              } else {
                result[0] += -4.103963639021535e-08;
              }
            } else {
              result[0] += -4.103963639021535e-08;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9250000000000001554) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7150000000000000799) ) ) {
              result[0] += -0.00020944252490076473;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9650000000000000799) ) ) {
                result[0] += 0.001482845496197425;
              } else {
                result[0] += -6.0521316200068406e-05;
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05052567209861091174) ) ) {
              result[0] += 0.00010540515034407601;
            } else {
              result[0] += 2.3036068287394698e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7650000000000001243) ) ) {
            result[0] += -4.0497568530012377e-07;
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2302999793555680907) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2428155000000000174) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02615650000000000266) ) ) {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7983975536720421262) ) ) {
                    result[0] += -0.0002022925322660247;
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
                      result[0] += 0.00211919970110163;
                    } else {
                      result[0] += 7.799852993832568e-05;
                    }
                  }
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6782348568386622478) ) ) {
                    result[0] += -0.00033777629432409973;
                  } else {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6269304705026225166) ) ) {
                      result[0] += 0.00040301373348304196;
                    } else {
                      result[0] += -2.18496890272309e-05;
                    }
                  }
                }
              } else {
                result[0] += 6.992224898013118e-05;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001052500000000000267) ) ) {
                result[0] += 0.0010859487216076514;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005013289129500051074) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006186000000000001393) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002867412157011550635) ) ) {
                      result[0] += 0.0005603589944020022;
                    } else {
                      result[0] += -0.000332615378259756;
                    }
                  } else {
                    result[0] += -0.0012975973509034532;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08965900000000000258) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.07000300000000002354) ) ) {
                      result[0] += 1.1132686036588685e-05;
                    } else {
                      result[0] += -0.0007311521526521749;
                    }
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02930104421257910194) ) ) {
                      result[0] += -0.00029620879205474407;
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3541095000000000215) ) ) {
                        result[0] += 0.00015631864670593405;
                      } else {
                        result[0] += -0.00012681662121250364;
                      }
                    }
                  }
                }
              }
            }
          }
        }
      } else {
        result[0] += 2.491402750835318e-05;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -3.940606823173121e-08;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.940606823173121e-08;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -3.940606823173121e-08;
              } else {
                result[0] += -3.940606823173121e-08;
              }
            }
          }
        } else {
          result[0] += -2.9180704149644738e-09;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.384300133116745416e-05) ) ) {
                result[0] += -3.940606823173121e-08;
              } else {
                result[0] += -3.940606823173121e-08;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -3.940606823173121e-08;
                  } else {
                    result[0] += -3.940606823173121e-08;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -3.940606823173121e-08;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -3.940606823173121e-08;
                        } else {
                          result[0] += -3.940606823173121e-08;
                        }
                      } else {
                        result[0] += -3.940606823173121e-08;
                      }
                    }
                  } else {
                    result[0] += -3.940606823173121e-08;
                  }
                }
              } else {
                result[0] += -3.940606823173121e-08;
              }
            }
          } else {
            result[0] += -3.940606823173121e-08;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -3.940606823173121e-08;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -3.940606823173121e-08;
                } else {
                  result[0] += -3.940606823173121e-08;
                }
              } else {
                result[0] += -3.940606823173121e-08;
              }
            } else {
              result[0] += -3.940606823173121e-08;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9450000000000000622) ) ) {
          result[0] += 6.186168524575106e-07;
        } else {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.146109394227906586) ) ) {
              result[0] += 1.978051345119598e-05;
            } else {
              result[0] += 2.3517709418128654e-05;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9750000000000000888) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1250629713251516228) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3725635588693467781) ) ) {
                  result[0] += -0.0006839405150419683;
                } else {
                  result[0] += 0.0009444880728272087;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6242129639949749453) ) ) {
                  result[0] += -0.00042351425370593766;
                } else {
                  result[0] += 0.0008201028005794708;
                }
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                  result[0] += 2.9365403296030487e-05;
                } else {
                  result[0] += -0.00047904849929280115;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7890731911809046872) ) ) {
                  result[0] += 0.00039845593754370026;
                } else {
                  result[0] += 0.00014348449356120865;
                }
              }
            }
          }
        }
      } else {
        result[0] += 2.3922333487229323e-05;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -3.783752367392033e-08;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.783752367392033e-08;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -3.783752367392033e-08;
              } else {
                result[0] += -3.783752367392033e-08;
              }
            }
          }
        } else {
          result[0] += -2.801917657937682e-09;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.384300133116745416e-05) ) ) {
                result[0] += -3.783752367392033e-08;
              } else {
                result[0] += -3.783752367392033e-08;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -3.783752367392033e-08;
                  } else {
                    result[0] += -3.783752367392033e-08;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -3.783752367392033e-08;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -3.783752367392033e-08;
                        } else {
                          result[0] += -3.783752367392033e-08;
                        }
                      } else {
                        result[0] += -3.783752367392033e-08;
                      }
                    }
                  } else {
                    result[0] += -3.783752367392033e-08;
                  }
                }
              } else {
                result[0] += -3.783752367392033e-08;
              }
            }
          } else {
            result[0] += -3.783752367392033e-08;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -3.783752367392033e-08;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -3.783752367392033e-08;
                } else {
                  result[0] += -3.783752367392033e-08;
                }
              } else {
                result[0] += -3.783752367392033e-08;
              }
            } else {
              result[0] += -3.783752367392033e-08;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3539353041941689093) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4592177672613065309) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4389499174623116007) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4129968667336683663) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9750000000000000888) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004460500000000000922) ) ) {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1750000000000000167) ) ) {
                          result[0] += 0.00022746429002297921;
                        } else {
                          result[0] += -0.00011157577673273605;
                        }
                      } else {
                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9250000000000001554) ) ) {
                          result[0] += 0.0001671516460063756;
                        } else {
                          result[0] += 0.001549472448961285;
                        }
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.09229200000000001292) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4550000000000000711) ) ) {
                          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3250000000000000666) ) ) {
                            result[0] += -3.1954363116693445e-05;
                          } else {
                            result[0] += 0.0019056531598445178;
                          }
                        } else {
                          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8350000000000000755) ) ) {
                            result[0] += -0.0007325548023567601;
                          } else {
                            result[0] += 0.00021187249538850278;
                          }
                        }
                      } else {
                        result[0] += 0.0012772286316307068;
                      }
                    }
                  } else {
                    result[0] += -0.0005776036963833703;
                  }
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001653500000000000239) ) ) {
                    result[0] += 9.912937285562369e-05;
                  } else {
                    result[0] += 0.0012077175550901645;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7750000000000001332) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001841500000000000255) ) ) {
                    result[0] += -0.0003120909447406504;
                  } else {
                    result[0] += -0.0003627317700035251;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
                      result[0] += 0.0011165731033675223;
                    } else {
                      result[0] += -8.652981939941962e-05;
                    }
                  } else {
                    result[0] += -0.0012505629884433636;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
                result[0] += 0.0016387065066646544;
              } else {
                result[0] += -0.0006759828620130554;
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003882500000000000534) ) ) {
              result[0] += -3.926597578370789e-06;
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
                result[0] += 2.2581595342930274e-05;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
                  result[0] += 6.427656739195641e-05;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1773295000000000288) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0956005000000000188) ) ) {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5724391781153673753) ) ) {
                        if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7572008430306190752) ) ) {
                          result[0] += 0.0001634651008834972;
                        } else {
                          result[0] += -0.000284145236205585;
                        }
                      } else {
                        result[0] += 0.0003265037829031523;
                      }
                    } else {
                      result[0] += -0.0005299790402097691;
                    }
                  } else {
                    result[0] += 6.634479452099002e-05;
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4251092621105527214) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05964584249592785187) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004132000000000001123) ) ) {
                result[0] += 1.058517586585434e-05;
              } else {
                result[0] += -0.0010884545792689746;
              }
            } else {
              result[0] += 0.0003079658385780303;
            }
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3329403679585331566) ) ) {
              result[0] += -0.0005998853898329568;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3115605993075549196) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03409611752714010457) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6077784371608041525) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.04446937286580055632) ) ) {
                      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.001779740531418749641) ) ) {
                        if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.009014249010710599294) ) ) {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4643511832914573034) ) ) {
                            result[0] += 0.00029572639983545165;
                          } else {
                            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5499504253266332965) ) ) {
                              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4693077114572864472) ) ) {
                                result[0] += -0.00019693437008754756;
                              } else {
                                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4693879269597989734) ) ) {
                                  result[0] += 0.0006904851784681527;
                                } else {
                                  result[0] += -6.0066480860338124e-05;
                                }
                              }
                            } else {
                              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.55780239615577909) ) ) {
                                result[0] += 0.0009380546849149246;
                              } else {
                                result[0] += 1.2330148156114996e-05;
                              }
                            }
                          }
                        } else {
                          result[0] += -0.0007283417014183062;
                        }
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5153685380402011074) ) ) {
                          result[0] += -0.00044011198373705284;
                        } else {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5628434130653267031) ) ) {
                            result[0] += 0.0004660679373520222;
                          } else {
                            result[0] += -0.0010135526742456919;
                          }
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1129321246270776624) ) ) {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5392784256532664466) ) ) {
                          result[0] += 0.0003853707438542503;
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5499504253266332965) ) ) {
                            result[0] += -0.001661446912892724;
                          } else {
                            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1051257686552766607) ) ) {
                              result[0] += -0.00019898587646470284;
                            } else {
                              result[0] += -0.000299323328460504;
                            }
                          }
                        }
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1206324332205917643) ) ) {
                          result[0] += 0.0006007678013148332;
                        } else {
                          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1507499186893259402) ) ) {
                            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.590591194899497629) ) ) {
                              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5499504253266332965) ) ) {
                                result[0] += -0.0012832151187796982;
                              } else {
                                result[0] += 0.0002763708693718729;
                              }
                            } else {
                              result[0] += -0.00034614227677485566;
                            }
                          } else {
                            result[0] += 7.315947161574269e-06;
                          }
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                      result[0] += 0.000795315908267418;
                    } else {
                      result[0] += 3.031746226047796e-06;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
                    if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.04779931491322893938) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5041457217085428821) ) ) {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4405029099497487777) ) ) {
                            result[0] += 7.425610161753657e-05;
                          } else {
                            result[0] += -0.00025359473195835406;
                          }
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4639489995477387718) ) ) {
                            result[0] += 0.00030140488457390925;
                          } else {
                            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4838161673366834781) ) ) {
                              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4797597438944724013) ) ) {
                                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4731110269597990081) ) ) {
                                  result[0] += -0.0002096809310815848;
                                } else {
                                  result[0] += 0.00022184688661718913;
                                }
                              } else {
                                result[0] += -0.00017145830371449313;
                              }
                            } else {
                              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4931942899748744114) ) ) {
                                result[0] += 0.00018990886821728547;
                              } else {
                                result[0] += 0.00016545494926633269;
                              }
                            }
                          }
                        }
                      } else {
                        result[0] += -0.0003003431496416053;
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4908111093216080412) ) ) {
                        result[0] += -0.002033498925242661;
                      } else {
                        result[0] += -0.0005443394232858233;
                      }
                    }
                  } else {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1044543990012605922) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5271332674874372737) ) ) {
                        result[0] += 8.194318444305225e-05;
                      } else {
                        result[0] += -0.0008221361078295124;
                      }
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5792515097236182742) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05721739154190200877) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02733191529475900369) ) ) {
                            if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.009014249010710599294) ) ) {
                              result[0] += 0.00016174024816626342;
                            } else {
                              result[0] += 1.6760991070039097e-05;
                            }
                          } else {
                            result[0] += 0.0003252198929277031;
                          }
                        } else {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5719332634924624292) ) ) {
                            result[0] += 0.00020736017791953207;
                          } else {
                            result[0] += 0.0005034978174827917;
                          }
                        }
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5834559473869348478) ) ) {
                          result[0] += -0.0003221338220652613;
                        } else {
                          result[0] += 9.926930388938555e-05;
                        }
                      }
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5748180127889448432) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4143094250104821241) ) ) {
                    result[0] += -0.0016280546886606182;
                  } else {
                    result[0] += 1.3267365587041793e-05;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5829435000502513065) ) ) {
                    result[0] += 0.0005056495661377696;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5951110425376885393) ) ) {
                      result[0] += -0.0007723275404658974;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6481803955276382867) ) ) {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6100010069597990858) ) ) {
                          result[0] += 0.00020622325219696598;
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
                            result[0] += -0.00116734466759911;
                          } else {
                            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6359282793467337935) ) ) {
                              result[0] += -2.6529914753752478e-05;
                            } else {
                              result[0] += -6.331382129897132e-05;
                            }
                          }
                        }
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6553322322110554099) ) ) {
                          result[0] += 0.000329306973260662;
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6577150591959800563) ) ) {
                            result[0] += -0.00038022880289722384;
                          } else {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6647073645226131422) ) ) {
                              result[0] += 0.0003618339662477796;
                            } else {
                              result[0] += -8.286153871114666e-07;
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      } else {
        result[0] += 2.297011349459013e-05;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -3.633141447543965e-08;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.633141447543965e-08;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -3.633141447543965e-08;
              } else {
                result[0] += -3.633141447543965e-08;
              }
            }
          }
        } else {
          result[0] += -2.6903883201730638e-09;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.384300133116745416e-05) ) ) {
                result[0] += -3.633141447543965e-08;
              } else {
                result[0] += -3.633141447543965e-08;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -3.633141447543965e-08;
                  } else {
                    result[0] += -3.633141447543965e-08;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -3.633141447543965e-08;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -3.633141447543965e-08;
                        } else {
                          result[0] += -3.633141447543965e-08;
                        }
                      } else {
                        result[0] += -3.633141447543965e-08;
                      }
                    }
                  } else {
                    result[0] += -3.633141447543965e-08;
                  }
                }
              } else {
                result[0] += -3.633141447543965e-08;
              }
            }
          } else {
            result[0] += -3.633141447543965e-08;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -3.633141447543965e-08;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -3.633141447543965e-08;
                } else {
                  result[0] += -3.633141447543965e-08;
                }
              } else {
                result[0] += -3.633141447543965e-08;
              }
            } else {
              result[0] += -3.633141447543965e-08;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1706267463716274191) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3539353041941689093) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1127930000000000182) ) ) {
            if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.378188349821562797) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4000638056452025526) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4026472078210281969) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8850000000000001199) ) ) {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7572008430306190752) ) ) {
                      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.8537219630417757221) ) ) {
                        result[0] += 7.837610193396394e-06;
                      } else {
                        result[0] += -0.00047703964116660577;
                      }
                    } else {
                      result[0] += 5.8643140854833216e-05;
                    }
                  } else {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.146109394227906586) ) ) {
                        result[0] += 1.8747872881408418e-05;
                      } else {
                        result[0] += 3.0085720463968884e-05;
                      }
                    } else {
                      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5724391781153673753) ) ) {
                        if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7572008430306190752) ) ) {
                          if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7983975536720421262) ) ) {
                            result[0] += -0.00014129612365411403;
                          } else {
                            result[0] += 9.601967735060173e-05;
                          }
                        } else {
                          result[0] += -0.00013680251735136034;
                        }
                      } else {
                        if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4601878067544193374) ) ) {
                          result[0] += 0.0001344990692139014;
                        } else {
                          result[0] += -4.7353434347923356e-05;
                        }
                      }
                    }
                  }
                } else {
                  result[0] += 0.001875022979940725;
                }
              } else {
                result[0] += -0.001446826166666487;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5950000000000000844) ) ) {
                result[0] += 0.0007040140941860697;
              } else {
                result[0] += 0.0003802450748589487;
              }
            }
          } else {
            if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6269304705026225166) ) ) {
              result[0] += 4.97788881485343e-05;
            } else {
              result[0] += -0.00023207453454771198;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4251092621105527214) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004132000000000001123) ) ) {
              result[0] += 1.0851717728931424e-05;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01387300000000000165) ) ) {
                result[0] += -0.0005322469792734105;
              } else {
                result[0] += -0.0013294652111631498;
              }
            }
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3329403679585331566) ) ) {
              result[0] += -0.0006005244920320766;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3541095000000000215) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1773295000000000288) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4405029099497487777) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4347441410050251753) ) ) {
                      result[0] += -0.00017145413744081795;
                    } else {
                      result[0] += 0.00032124707929976;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4529241356532663354) ) ) {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006186000000000001393) ) ) {
                          result[0] += 0.0005219000977697714;
                        } else {
                          result[0] += -0.00017932191887249703;
                        }
                      } else {
                        result[0] += -0.00028234066104473356;
                      }
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7733398996305392847) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7492319095182128352) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7293493725076146683) ) ) {
                            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1604180000000000328) ) ) {
                              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.09229200000000001292) ) ) {
                                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08720350000000000323) ) ) {
                                  result[0] += 9.612369542977616e-06;
                                } else {
                                  result[0] += -0.000503801043754557;
                                }
                              } else {
                                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1014535000000000159) ) ) {
                                  result[0] += 0.0006197333744336304;
                                } else {
                                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1127930000000000182) ) ) {
                                    result[0] += -0.00022718543888177703;
                                  } else {
                                    result[0] += 0.00043174712532761164;
                                  }
                                }
                              }
                            } else {
                              result[0] += -0.00035348791459397357;
                            }
                          } else {
                            result[0] += -0.00016389568024062455;
                          }
                        } else {
                          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002237500000000000339) ) ) {
                            result[0] += 2.9273509902026963e-05;
                          } else {
                            result[0] += 0.0009401479736312893;
                          }
                        }
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                            result[0] += -0.00018719348001575555;
                          } else {
                            result[0] += -3.742975659435783e-05;
                          }
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7269841738944724518) ) ) {
                            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9186477097784532253) ) ) {
                              result[0] += 2.1161080362852243e-05;
                            } else {
                              result[0] += 0.0004846313194854395;
                            }
                          } else {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                              result[0] += -0.00040319275241860683;
                            } else {
                              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7382388927638191545) ) ) {
                                result[0] += 0.0007308123674053763;
                              } else {
                                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7425707671105529206) ) ) {
                                  result[0] += -0.0002866843674412494;
                                } else {
                                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
                                      result[0] += 1.5536763974385639e-06;
                                    } else {
                                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.234671350732867934) ) ) {
                                        result[0] += -0.000183869342197317;
                                      } else {
                                        result[0] += -6.0160720417480466e-06;
                                      }
                                    }
                                  } else {
                                    result[0] += 0.00034652474177606453;
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1494199460089949139) ) ) {
                    result[0] += 0.0005339197778400295;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7983409114572864729) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5284121414321608645) ) ) {
                          result[0] += -0.00015167627678757295;
                        } else {
                          result[0] += 0.000535270907156317;
                        }
                      } else {
                        result[0] += -0.00025209679124654923;
                      }
                    } else {
                      result[0] += 0.0020989687447434497;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.590591194899497629) ) ) {
                  result[0] += -0.0006261209505299682;
                } else {
                  result[0] += 0.0010976338655984254;
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01308450000000000064) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4364163272837385255) ) ) {
            result[0] += -0.00027836513908414045;
          } else {
            result[0] += 0.0001307485513958383;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1206324332205917643) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.316132418552224348) ) ) {
              result[0] += 2.6401068452262684e-05;
            } else {
              result[0] += 2.2055796280743807e-05;
            }
          } else {
            result[0] += 3.176155288567064e-05;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -3.488525541897398e-08;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.488525541897398e-08;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -3.488525541897398e-08;
              } else {
                result[0] += -3.488525541897398e-08;
              }
            }
          }
        } else {
          result[0] += -2.583298368108084e-09;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.384300133116745416e-05) ) ) {
                result[0] += -3.488525541897398e-08;
              } else {
                result[0] += -3.488525541897398e-08;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -3.488525541897398e-08;
                  } else {
                    result[0] += -3.488525541897398e-08;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -3.488525541897398e-08;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -3.488525541897398e-08;
                        } else {
                          result[0] += -3.488525541897398e-08;
                        }
                      } else {
                        result[0] += -3.488525541897398e-08;
                      }
                    }
                  } else {
                    result[0] += -3.488525541897398e-08;
                  }
                }
              } else {
                result[0] += -3.488525541897398e-08;
              }
            }
          } else {
            result[0] += -3.488525541897398e-08;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -3.488525541897398e-08;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -3.488525541897398e-08;
                } else {
                  result[0] += -3.488525541897398e-08;
                }
              } else {
                result[0] += -3.488525541897398e-08;
              }
            } else {
              result[0] += -3.488525541897398e-08;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1605461427107033601) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3539353041941689093) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4636504894974874946) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4389499174623116007) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3998546246231156065) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.09229200000000001292) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004749500000000001117) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2646519339949748861) ) ) {
                        result[0] += 0.0008641639385590968;
                      } else {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.000210500000000000048) ) ) {
                          result[0] += -0.000209989300702013;
                        } else {
                          result[0] += 0.0002620904431417946;
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006969500000000000868) ) ) {
                        result[0] += -0.0009978256081080833;
                      } else {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4550000000000000711) ) ) {
                          result[0] += 0.00038630465359157704;
                        } else {
                          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03873000000000000748) ) ) {
                            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3457619648241206378) ) ) {
                              result[0] += -0.0002963759643754002;
                            } else {
                              result[0] += 0.0002248473061492849;
                            }
                          } else {
                            result[0] += -0.001900505855555489;
                          }
                        }
                      }
                    }
                  } else {
                    result[0] += 0.0018580272058067668;
                  }
                } else {
                  result[0] += 0.0004739259417577365;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6150000000000001021) ) ) {
                  result[0] += -0.0003056070053511612;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004848500000000001246) ) ) {
                    result[0] += 0.0018276676487838147;
                  } else {
                    result[0] += -0.0007587287634059054;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00877850000000000158) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4750000000000000333) ) ) {
                  result[0] += 0.0010520229696554606;
                } else {
                  result[0] += -0.0005234132960643753;
                }
              } else {
                result[0] += 0.002949473725743704;
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002895500000000000504) ) ) {
              result[0] += -4.516553180632721e-06;
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
                result[0] += 2.0485191532796338e-05;
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6458133101595427972) ) ) {
                  if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7572008430306190752) ) ) {
                    result[0] += 5.789603227107351e-05;
                  } else {
                    result[0] += -0.0004683974532308371;
                  }
                } else {
                  result[0] += 9.214518903592642e-05;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4251092621105527214) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004132000000000001123) ) ) {
              result[0] += 1.0419768956815172e-05;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01387300000000000165) ) ) {
                result[0] += -0.0005172137863852871;
              } else {
                result[0] += -0.0012919916412616425;
              }
            }
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3329403679585331566) ) ) {
              result[0] += -0.0005855329652073929;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3541095000000000215) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1773295000000000288) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4405029099497487777) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4347441410050251753) ) ) {
                      result[0] += -0.00017772625105108895;
                    } else {
                      result[0] += 0.00030708216540614855;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4529241356532663354) ) ) {
                        result[0] += -2.787740365777134e-05;
                      } else {
                        result[0] += -0.00027473110522654347;
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4643511832914573034) ) ) {
                        result[0] += 0.0003252008770974584;
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4674830972361809223) ) ) {
                          result[0] += -0.0014457186562351503;
                        } else {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                            result[0] += 6.701709021017307e-06;
                          } else {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7954292854522614364) ) ) {
                              result[0] += -9.050825776679381e-05;
                            } else {
                              result[0] += -2.2754500622278595e-06;
                            }
                          }
                        }
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                    result[0] += 0.00044141197239587764;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7983409114572864729) ) ) {
                      result[0] += -0.0002504428361495608;
                    } else {
                      result[0] += 0.0020154200389395204;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.564198853668341882) ) ) {
                  result[0] += -0.0006664247754111789;
                } else {
                  result[0] += 0.000743850430618698;
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1165587384072143268) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.316132418552224348) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6622812854083105494) ) ) {
              result[0] += 2.8800216849692525e-05;
            } else {
              result[0] += -4.741525393942252e-05;
            }
          } else {
            result[0] += 2.117787313903458e-05;
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4364163272837385255) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
              result[0] += -0.0011613353979682242;
            } else {
              result[0] += 3.049729554760196e-05;
            }
          } else {
            result[0] += 6.654000171645759e-05;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -3.3496660210401194e-08;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.3496660210401194e-08;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -3.3496660210401194e-08;
              } else {
                result[0] += -3.3496660210401194e-08;
              }
            }
          }
        } else {
          result[0] += -2.4804710935708385e-09;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.384300133116745416e-05) ) ) {
                result[0] += -3.3496660210401194e-08;
              } else {
                result[0] += -3.3496660210401194e-08;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -3.3496660210401194e-08;
                  } else {
                    result[0] += -3.3496660210401194e-08;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -3.3496660210401194e-08;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -3.3496660210401194e-08;
                        } else {
                          result[0] += -3.3496660210401194e-08;
                        }
                      } else {
                        result[0] += -3.3496660210401194e-08;
                      }
                    }
                  } else {
                    result[0] += -3.3496660210401194e-08;
                  }
                }
              } else {
                result[0] += -3.3496660210401194e-08;
              }
            }
          } else {
            result[0] += -3.3496660210401194e-08;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -3.3496660210401194e-08;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -3.3496660210401194e-08;
                } else {
                  result[0] += -3.3496660210401194e-08;
                }
              } else {
                result[0] += -3.3496660210401194e-08;
              }
            } else {
              result[0] += -3.3496660210401194e-08;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1605461427107033601) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3539353041941689093) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4636504894974874946) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4389499174623116007) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3998546246231156065) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9750000000000000888) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6950000000000000622) ) ) {
                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6450000000000001288) ) ) {
                          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4850000000000000422) ) ) {
                            result[0] += 0.0001129159939942106;
                          } else {
                            result[0] += -0.000225016263670706;
                          }
                        } else {
                          result[0] += 0.00040405563895265967;
                        }
                      } else {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7550000000000001155) ) ) {
                          result[0] += -0.0014781151916995609;
                        } else {
                          result[0] += -5.309265110851306e-05;
                        }
                      }
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3569067370100503234) ) ) {
                        result[0] += 6.418381565876789e-06;
                      } else {
                        result[0] += 0.0016777680742466141;
                      }
                    }
                  } else {
                    result[0] += -0.000628711001203952;
                  }
                } else {
                  result[0] += 0.00045506148787773955;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6150000000000001021) ) ) {
                  result[0] += -0.000293442426985882;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8050000000000001599) ) ) {
                    result[0] += 0.0010470771122914053;
                  } else {
                    result[0] += -0.0005689882517125159;
                  }
                }
              }
            } else {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.378188349821562797) ) ) {
                result[0] += 0.000838037682200229;
              } else {
                result[0] += 0.0017592780773402312;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2669585275879397535) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.146109394227906586) ) ) {
                result[0] += 5.190295631059504e-06;
              } else {
                result[0] += 1.9669785755557883e-05;
              }
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5724391781153673753) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7572008430306190752) ) ) {
                  result[0] += 6.34316108903921e-05;
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.629632012766062954) ) ) {
                    result[0] += -0.0001942470994137699;
                  } else {
                    result[0] += 5.6171172194265385e-05;
                  }
                }
              } else {
                result[0] += 0.00011789349972856917;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4251092621105527214) ) ) {
            result[0] += -0.0003917144470661498;
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3329403679585331566) ) ) {
              result[0] += -0.0005622260333766417;
            } else {
              result[0] += 2.521224490817613e-06;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1165587384072143268) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.316132418552224348) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6622812854083105494) ) ) {
              result[0] += 2.765383444133557e-05;
            } else {
              result[0] += -4.552790658757235e-05;
            }
          } else {
            result[0] += 2.0334895416341895e-05;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
            result[0] += 1.8893047337371423e-06;
          } else {
            result[0] += 2.928336152409475e-05;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -3.2163337541189626e-08;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.2163337541189626e-08;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -3.2163337541189626e-08;
              } else {
                result[0] += -3.2163337541189626e-08;
              }
            }
          }
        } else {
          result[0] += -2.381736822195478e-09;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.384300133116745416e-05) ) ) {
                result[0] += -3.2163337541189626e-08;
              } else {
                result[0] += -3.2163337541189626e-08;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -3.2163337541189626e-08;
                  } else {
                    result[0] += -3.2163337541189626e-08;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -3.2163337541189626e-08;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -3.2163337541189626e-08;
                        } else {
                          result[0] += -3.2163337541189626e-08;
                        }
                      } else {
                        result[0] += -3.2163337541189626e-08;
                      }
                    }
                  } else {
                    result[0] += -3.2163337541189626e-08;
                  }
                }
              } else {
                result[0] += -3.2163337541189626e-08;
              }
            }
          } else {
            result[0] += -3.2163337541189626e-08;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -3.2163337541189626e-08;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -3.2163337541189626e-08;
                } else {
                  result[0] += -3.2163337541189626e-08;
                }
              } else {
                result[0] += -3.2163337541189626e-08;
              }
            } else {
              result[0] += -3.2163337541189626e-08;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1605461427107033601) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3539353041941689093) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4636504894974874946) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4389499174623116007) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3998546246231156065) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9750000000000000888) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2646519339949748861) ) ) {
                      result[0] += 0.000784415543982969;
                    } else {
                      result[0] += -9.140844213731692e-06;
                    }
                  } else {
                    result[0] += -0.0006036853829774614;
                  }
                } else {
                  result[0] += 0.00043694792688803397;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6150000000000001021) ) ) {
                  result[0] += -0.00028176205534431655;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8050000000000001599) ) ) {
                    result[0] += 0.0010053985795224238;
                  } else {
                    result[0] += -0.0005463398763294761;
                  }
                }
              }
            } else {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.378188349821562797) ) ) {
                result[0] += 0.0008046798897423373;
              } else {
                result[0] += 0.0016892506379707298;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2669585275879397535) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.146109394227906586) ) ) {
                result[0] += 4.983697755888122e-06;
              } else {
                result[0] += 1.888683691583383e-05;
              }
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5724391781153673753) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7572008430306190752) ) ) {
                  result[0] += 6.0906738135510365e-05;
                } else {
                  result[0] += -6.488332322490166e-05;
                }
              } else {
                result[0] += 0.0001132007908210709;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4138030768592965147) ) ) {
            result[0] += -0.0005780895779064737;
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3329403679585331566) ) ) {
              result[0] += -0.0005398468256940444;
            } else {
              result[0] += 2.3815703849451434e-06;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1165587384072143268) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.316132418552224348) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6622812854083105494) ) ) {
              result[0] += 2.6553083377805736e-05;
            } else {
              result[0] += -4.371568442710652e-05;
            }
          } else {
            result[0] += 1.9525472122667082e-05;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
            result[0] += 1.8141016294645772e-06;
          } else {
            result[0] += 2.8117747713478215e-05;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -3.088308730753035e-08;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.088308730753035e-08;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -3.088308730753035e-08;
              } else {
                result[0] += -3.088308730753035e-08;
              }
            }
          }
        } else {
          result[0] += -2.286932633444055e-09;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.384300133116745416e-05) ) ) {
                result[0] += -3.088308730753035e-08;
              } else {
                result[0] += -3.088308730753035e-08;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -3.088308730753035e-08;
                  } else {
                    result[0] += -3.088308730753035e-08;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -3.088308730753035e-08;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -3.088308730753035e-08;
                        } else {
                          result[0] += -3.088308730753035e-08;
                        }
                      } else {
                        result[0] += -3.088308730753035e-08;
                      }
                    }
                  } else {
                    result[0] += -3.088308730753035e-08;
                  }
                }
              } else {
                result[0] += -3.088308730753035e-08;
              }
            }
          } else {
            result[0] += -3.088308730753035e-08;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -3.088308730753035e-08;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -3.088308730753035e-08;
                } else {
                  result[0] += -3.088308730753035e-08;
                }
              } else {
                result[0] += -3.088308730753035e-08;
              }
            } else {
              result[0] += -3.088308730753035e-08;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3539353041941689093) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9750000000000000888) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.378188349821562797) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4000638056452025526) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4389499174623116007) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3793862752261306648) ) ) {
                      result[0] += 6.694996825012594e-07;
                    } else {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8950000000000001288) ) ) {
                        result[0] += 0.0003041495801758987;
                      } else {
                        result[0] += 0.0019492426284722867;
                      }
                    }
                  } else {
                    if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4026472078210281969) ) ) {
                      result[0] += -0.000374763267197369;
                    } else {
                      result[0] += 0.0018814715305089528;
                    }
                  }
                } else {
                  result[0] += -0.0015296478297696296;
                }
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3750409390474713223) ) ) {
                  result[0] += 0.002840860456372462;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5950000000000000844) ) ) {
                    result[0] += -4.220514490050687e-05;
                  } else {
                    result[0] += 0.0017892798592934937;
                  }
                }
              }
            } else {
              result[0] += -0.0003846136039991247;
            }
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2646519339949748861) ) ) {
                result[0] += 7.348754400787365e-06;
              } else {
                result[0] += 1.8135053076745115e-05;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1773295000000000288) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0956005000000000188) ) ) {
                  if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3750409390474713223) ) ) {
                    if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4133512684738382403) ) ) {
                      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5724391781153673753) ) ) {
                        if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7572008430306190752) ) ) {
                          result[0] += 6.144916153232781e-05;
                        } else {
                          result[0] += -0.00018122175366971964;
                        }
                      } else {
                        result[0] += 0.00010869487352584168;
                      }
                    } else {
                      result[0] += -0.00017262439434458362;
                    }
                  } else {
                    result[0] += 0.00028559545507551675;
                  }
                } else {
                  result[0] += -0.0005148156836165651;
                }
              } else {
                result[0] += 5.9349008837693134e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1605461427107033601) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4138030768592965147) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004132000000000001123) ) ) {
                result[0] += 0.0003905993351038079;
              } else {
                result[0] += -0.001151339593590304;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3541095000000000215) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1773295000000000288) ) ) {
                  result[0] += 1.0798636043491183e-06;
                } else {
                  result[0] += 0.00034217528506992465;
                }
              } else {
                result[0] += -0.00035525846298553257;
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00877850000000000158) ) ) {
              result[0] += -7.724749503650304e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6735883055778896233) ) ) {
                result[0] += 8.973878156488514e-05;
              } else {
                result[0] += -4.151281760171471e-07;
              }
            }
          }
        }
      } else {
        result[0] += 1.8748267635869823e-05;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -2.965379697996557e-08;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.965379697996557e-08;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -2.965379697996557e-08;
              } else {
                result[0] += -2.965379697996557e-08;
              }
            }
          }
        } else {
          result[0] += -2.195902091772804e-09;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.384300133116745416e-05) ) ) {
                result[0] += -2.965379697996557e-08;
              } else {
                result[0] += -2.965379697996557e-08;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -2.965379697996557e-08;
                  } else {
                    result[0] += -2.965379697996557e-08;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -2.965379697996557e-08;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -2.965379697996557e-08;
                        } else {
                          result[0] += -2.965379697996557e-08;
                        }
                      } else {
                        result[0] += -2.965379697996557e-08;
                      }
                    }
                  } else {
                    result[0] += -2.965379697996557e-08;
                  }
                }
              } else {
                result[0] += -2.965379697996557e-08;
              }
            }
          } else {
            result[0] += -2.965379697996557e-08;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -2.965379697996557e-08;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -2.965379697996557e-08;
                } else {
                  result[0] += -2.965379697996557e-08;
                }
              } else {
                result[0] += -2.965379697996557e-08;
              }
            } else {
              result[0] += -2.965379697996557e-08;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4601878067544193374) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9450000000000000622) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4389499174623116007) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4129968667336683663) ) ) {
                  result[0] += 8.085883618960723e-05;
                } else {
                  result[0] += 0.0007973915748563307;
                }
              } else {
                result[0] += -0.000270230844938194;
              }
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.8537219630417757221) ) ) {
                result[0] += 0.0004843124591977598;
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7572008430306190752) ) ) {
                  result[0] += -0.0009608897484963637;
                } else {
                  result[0] += -0.0004031652015116884;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1604180000000000328) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.317357466959798995) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01590200000000000294) ) ) {
                    result[0] += -5.034260140099263e-06;
                  } else {
                    result[0] += 0.00023061717730443808;
                  }
                } else {
                  result[0] += 0.00010363340323667272;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2669585275879397535) ) ) {
                  result[0] += 1.668229019370905e-05;
                } else {
                  if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5724391781153673753) ) ) {
                    result[0] += -0.00022658980108794817;
                  } else {
                    result[0] += 0.0002858308598505508;
                  }
                }
              }
            } else {
              result[0] += 4.472545936973412e-05;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3837516359296482826) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007696500000000001084) ) ) {
              result[0] += 0.0003285914069033841;
            } else {
              result[0] += -0.0020288887528024328;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1605461427107033601) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3541095000000000215) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1773295000000000288) ) ) {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3539353041941689093) ) ) {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.378188349821562797) ) ) {
                      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4000638056452025526) ) ) {
                        if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4026472078210281969) ) ) {
                          result[0] += -0.0001190142570187174;
                        } else {
                          result[0] += 0.0017917452738299986;
                        }
                      } else {
                        result[0] += -0.000986831322387517;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.008962500000000001715) ) ) {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004749500000000001117) ) ) {
                          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001841500000000000255) ) ) {
                            result[0] += 8.156580215604051e-05;
                          } else {
                            result[0] += 0.0012734230838173247;
                          }
                        } else {
                          result[0] += -0.00013167380944375775;
                        }
                      } else {
                        result[0] += 0.00035160985922448807;
                      }
                    }
                  } else {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3245708964283948172) ) ) {
                      result[0] += -0.0001877888931989521;
                    } else {
                      result[0] += 1.3140706512526712e-06;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8030059940338053481) ) ) {
                    result[0] += 0.0003711083682379067;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                      result[0] += -0.0003244528608373053;
                    } else {
                      result[0] += 0.0006698730636621257;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3346339054385528144) ) ) {
                  result[0] += -0.00038877811845317055;
                } else {
                  result[0] += 0.0009353397684576038;
                }
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00877850000000000158) ) ) {
                result[0] += -7.087065258993996e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1165587384072143268) ) ) {
                  result[0] += 9.167158425791205e-05;
                } else {
                  result[0] += 6.1269265348156915e-06;
                }
              }
            }
          }
        }
      } else {
        result[0] += 1.800199949778494e-05;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -2.847343811752267e-08;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.847343811752267e-08;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -2.847343811752267e-08;
              } else {
                result[0] += -2.847343811752267e-08;
              }
            }
          }
        } else {
          result[0] += -2.108494988499247e-09;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.384300133116745416e-05) ) ) {
                result[0] += -2.847343811752267e-08;
              } else {
                result[0] += -2.847343811752267e-08;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -2.847343811752267e-08;
                  } else {
                    result[0] += -2.847343811752267e-08;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -2.847343811752267e-08;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -2.847343811752267e-08;
                        } else {
                          result[0] += -2.847343811752267e-08;
                        }
                      } else {
                        result[0] += -2.847343811752267e-08;
                      }
                    }
                  } else {
                    result[0] += -2.847343811752267e-08;
                  }
                }
              } else {
                result[0] += -2.847343811752267e-08;
              }
            }
          } else {
            result[0] += -2.847343811752267e-08;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -2.847343811752267e-08;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -2.847343811752267e-08;
                } else {
                  result[0] += -2.847343811752267e-08;
                }
              } else {
                result[0] += -2.847343811752267e-08;
              }
            } else {
              result[0] += -2.847343811752267e-08;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3539353041941689093) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9750000000000000888) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.378188349821562797) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4000638056452025526) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9250000000000001554) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1050000000000000239) ) ) {
                      result[0] += 0.00010676693986160322;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4405029099497487777) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3998546246231156065) ) ) {
                          result[0] += -1.9712632383727215e-05;
                        } else {
                          result[0] += 0.00042671892995482054;
                        }
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4592177672613065309) ) ) {
                          result[0] += -0.0014125385684129758;
                        } else {
                          result[0] += 6.0106571482395684e-05;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.317357466959798995) ) ) {
                      result[0] += -0.000792049880996802;
                    } else {
                      result[0] += 0.0014080687339381988;
                    }
                  }
                } else {
                  result[0] += -0.0014294802704041864;
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7550000000000001155) ) ) {
                  result[0] += 0.0005385724023149439;
                } else {
                  result[0] += 0.001835175342407933;
                }
              }
            } else {
              result[0] += -0.00035832922004663993;
            }
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2646519339949748861) ) ) {
                result[0] += 3.5045321747804503e-06;
              } else {
                result[0] += 1.6749161087135735e-05;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
                result[0] += 4.4071204521611905e-05;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1773295000000000288) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0956005000000000188) ) ) {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5724391781153673753) ) ) {
                      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7572008430306190752) ) ) {
                        result[0] += 0.00015917684041746077;
                      } else {
                        result[0] += -0.0002480218848373399;
                      }
                    } else {
                      result[0] += 0.0002930928157759089;
                    }
                  } else {
                    result[0] += -0.0004863241998494909;
                  }
                } else {
                  result[0] += 5.882891415578029e-05;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1605461427107033601) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4138030768592965147) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004132000000000001123) ) ) {
                result[0] += 0.0003749993611070308;
              } else {
                result[0] += -0.001040915020174388;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3541095000000000215) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1773295000000000288) ) ) {
                  result[0] += 9.845739010906475e-07;
                } else {
                  result[0] += 0.0003137832824475803;
                }
              } else {
                result[0] += -0.00032564235097545005;
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00877850000000000158) ) ) {
              result[0] += -7.13517047484145e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6735883055778896233) ) ) {
                result[0] += 8.251780634937747e-05;
              } else {
                result[0] += -6.424842821431473e-07;
              }
            }
          }
        }
      } else {
        result[0] += 1.7285436298029434e-05;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -2.7340063020601895e-08;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.7340063020601895e-08;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -2.7340063020601895e-08;
              } else {
                result[0] += -2.7340063020601895e-08;
              }
            }
          }
        } else {
          result[0] += -2.0245670939441934e-09;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.384300133116745416e-05) ) ) {
                result[0] += -2.7340063020601895e-08;
              } else {
                result[0] += -2.7340063020601895e-08;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -2.7340063020601895e-08;
                  } else {
                    result[0] += -2.7340063020601895e-08;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -2.7340063020601895e-08;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -2.7340063020601895e-08;
                        } else {
                          result[0] += -2.7340063020601895e-08;
                        }
                      } else {
                        result[0] += -2.7340063020601895e-08;
                      }
                    }
                  } else {
                    result[0] += -2.7340063020601895e-08;
                  }
                }
              } else {
                result[0] += -2.7340063020601895e-08;
              }
            }
          } else {
            result[0] += -2.7340063020601895e-08;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -2.7340063020601895e-08;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -2.7340063020601895e-08;
                } else {
                  result[0] += -2.7340063020601895e-08;
                }
              } else {
                result[0] += -2.7340063020601895e-08;
              }
            } else {
              result[0] += -2.7340063020601895e-08;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3539353041941689093) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9750000000000000888) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.378188349821562797) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4000638056452025526) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9250000000000001554) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1050000000000000239) ) ) {
                      result[0] += 0.00010251711971996363;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4405029099497487777) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3998546246231156065) ) ) {
                          result[0] += -1.8927978049175323e-05;
                        } else {
                          result[0] += 0.00040973353442234873;
                        }
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4592177672613065309) ) ) {
                          result[0] += -0.0013563129721126074;
                        } else {
                          result[0] += 5.771405074084554e-05;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.317357466959798995) ) ) {
                      result[0] += -0.0007605226166413118;
                    } else {
                      result[0] += 0.001352021057812421;
                    }
                  }
                } else {
                  result[0] += -0.00137258031566993;
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7550000000000001155) ) ) {
                  result[0] += 0.0005171347190203199;
                } else {
                  result[0] += 0.0017621268393440115;
                }
              }
            } else {
              result[0] += -0.0003440660526404539;
            }
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2646519339949748861) ) ) {
                result[0] += 3.365035515582761e-06;
              } else {
                result[0] += 1.608246667558717e-05;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1773295000000000288) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0956005000000000188) ) ) {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5724391781153673753) ) ) {
                    if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7572008430306190752) ) ) {
                      result[0] += 5.515407609319317e-05;
                    } else {
                      result[0] += -0.00016693490972983295;
                    }
                  } else {
                    result[0] += 9.952027618240105e-05;
                  }
                } else {
                  result[0] += -0.000466966237707218;
                }
              } else {
                result[0] += 5.648725011058027e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1605461427107033601) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4138030768592965147) ) ) {
              result[0] += -0.0004186244800488395;
            } else {
              result[0] += 1.7397943454468848e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01151200000000000313) ) ) {
              result[0] += -5.8090731614101524e-05;
            } else {
              result[0] += 6.618840488654839e-05;
            }
          }
        }
      } else {
        result[0] += 1.659739564207929e-05;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -2.6251801517094684e-08;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.6251801517094684e-08;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -2.6251801517094684e-08;
              } else {
                result[0] += -2.6251801517094684e-08;
              }
            }
          }
        } else {
          result[0] += -1.9439799194396325e-09;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.384300133116745416e-05) ) ) {
                result[0] += -2.6251801517094684e-08;
              } else {
                result[0] += -2.6251801517094684e-08;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -2.6251801517094684e-08;
                  } else {
                    result[0] += -2.6251801517094684e-08;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -2.6251801517094684e-08;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -2.6251801517094684e-08;
                        } else {
                          result[0] += -2.6251801517094684e-08;
                        }
                      } else {
                        result[0] += -2.6251801517094684e-08;
                      }
                    }
                  } else {
                    result[0] += -2.6251801517094684e-08;
                  }
                }
              } else {
                result[0] += -2.6251801517094684e-08;
              }
            }
          } else {
            result[0] += -2.6251801517094684e-08;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -2.6251801517094684e-08;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -2.6251801517094684e-08;
                } else {
                  result[0] += -2.6251801517094684e-08;
                }
              } else {
                result[0] += -2.6251801517094684e-08;
              }
            } else {
              result[0] += -2.6251801517094684e-08;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3539353041941689093) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4636504894974874946) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4389499174623116007) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4129968667336683663) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.09229200000000001292) ) ) {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002194500000000000704) ) ) {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0008535000000000002003) ) ) {
                          result[0] += 2.875789753105518e-06;
                        } else {
                          result[0] += 0.001274385120663077;
                        }
                      } else {
                        result[0] += -4.722226567194017e-05;
                      }
                    } else {
                      result[0] += 0.0012045934028375523;
                    }
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001653500000000000239) ) ) {
                      result[0] += 0.00015675732589375194;
                    } else {
                      result[0] += 0.002251919621797039;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6150000000000001021) ) ) {
                    result[0] += -0.0002821755597518934;
                  } else {
                    result[0] += 0.00047486736193549825;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4050000000000000822) ) ) {
                  result[0] += 0.0007220894242208871;
                } else {
                  result[0] += 0.002353459215850087;
                }
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8250000000000000666) ) ) {
                result[0] += -0.00048242096566181717;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004371500000000001253) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3364660453768844595) ) ) {
                    result[0] += -3.152666100205288e-05;
                  } else {
                    result[0] += 0.0011272450214635224;
                  }
                } else {
                  if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4601878067544193374) ) ) {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7835979262278595092) ) ) {
                      result[0] += -0.0007956640766887803;
                    } else {
                      result[0] += 0.0004955249178585069;
                    }
                  } else {
                    result[0] += -0.0009910287780830144;
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2646519339949748861) ) ) {
                result[0] += 3.231091471387707e-06;
              } else {
                result[0] += 1.5442309798431424e-05;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
                result[0] += 3.877906068602226e-05;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1773295000000000288) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0956005000000000188) ) ) {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5724391781153673753) ) ) {
                      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7572008430306190752) ) ) {
                        result[0] += 0.0001506454743677836;
                      } else {
                        result[0] += -0.00023150467692871512;
                      }
                    } else {
                      result[0] += 0.00027746499101817995;
                    }
                  } else {
                    result[0] += -0.00044837881237643265;
                  }
                } else {
                  result[0] += 5.423879517146916e-05;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1605461427107033601) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4138030768592965147) ) ) {
              result[0] += -0.00040196128122155174;
            } else {
              result[0] += 1.670542449109137e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00877850000000000158) ) ) {
              result[0] += -6.619929451778258e-05;
            } else {
              result[0] += 5.8836065224862956e-05;
            }
          }
        }
      } else {
        result[0] += 1.5936742200200053e-05;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -2.520685787642939e-08;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.520685787642939e-08;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -2.520685787642939e-08;
              } else {
                result[0] += -2.520685787642939e-08;
              }
            }
          }
        } else {
          result[0] += -1.8666004888098265e-09;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.384300133116745416e-05) ) ) {
                result[0] += -2.520685787642939e-08;
              } else {
                result[0] += -2.520685787642939e-08;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -2.520685787642939e-08;
                  } else {
                    result[0] += -2.520685787642939e-08;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -2.520685787642939e-08;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -2.520685787642939e-08;
                        } else {
                          result[0] += -2.520685787642939e-08;
                        }
                      } else {
                        result[0] += -2.520685787642939e-08;
                      }
                    }
                  } else {
                    result[0] += -2.520685787642939e-08;
                  }
                }
              } else {
                result[0] += -2.520685787642939e-08;
              }
            }
          } else {
            result[0] += -2.520685787642939e-08;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -2.520685787642939e-08;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -2.520685787642939e-08;
                } else {
                  result[0] += -2.520685787642939e-08;
                }
              } else {
                result[0] += -2.520685787642939e-08;
              }
            } else {
              result[0] += -2.520685787642939e-08;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3539353041941689093) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4592177672613065309) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4419864859045226635) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3644118032412060892) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4650000000000000244) ) ) {
                    result[0] += 0.00023946463452387417;
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6050000000000000933) ) ) {
                      result[0] += -0.0002764541644345179;
                    } else {
                      result[0] += -9.02545297441436e-05;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3950000000000000733) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1350000000000000366) ) ) {
                      result[0] += 7.112247911707573e-05;
                    } else {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2250000000000000333) ) ) {
                        result[0] += -0.0009824961560189174;
                      } else {
                        result[0] += -4.772402886051853e-05;
                      }
                    }
                  } else {
                    result[0] += 0.0003500296181042808;
                  }
                }
              } else {
                result[0] += -0.00021894184327911698;
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4050000000000000822) ) ) {
                  result[0] += 0.0006933469110131769;
                } else {
                  result[0] += 0.0026292263721904726;
                }
              } else {
                result[0] += -0.0008427150636779248;
              }
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04653956279752540642) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
                result[0] += 0.00016777842916998817;
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5724391781153673753) ) ) {
                  result[0] += 8.409574138405113e-06;
                } else {
                  result[0] += 0.00019082471824325868;
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05701962466675345592) ) ) {
                result[0] += -1.947245992687284e-05;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1773295000000000288) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0296135000000000044) ) ) {
                    result[0] += 3.857799070416273e-05;
                  } else {
                    result[0] += -1.1205207983617662e-05;
                  }
                } else {
                  result[0] += 4.1023651387320266e-05;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1605461427107033601) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3966785421356783803) ) ) {
              result[0] += -0.0006187417885268211;
            } else {
              result[0] += 1.2170186155078581e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01151200000000000313) ) ) {
              result[0] += -5.3143411243723106e-05;
            } else {
              result[0] += 6.121185023427405e-05;
            }
          }
        }
      } else {
        result[0] += 1.530238583405814e-05;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -2.420350784645233e-08;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.420350784645233e-08;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -2.420350784645233e-08;
              } else {
                result[0] += -2.420350784645233e-08;
              }
            }
          }
        } else {
          result[0] += -1.7923011189485072e-09;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.384300133116745416e-05) ) ) {
                result[0] += -2.420350784645233e-08;
              } else {
                result[0] += -2.420350784645233e-08;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -2.420350784645233e-08;
                  } else {
                    result[0] += -2.420350784645233e-08;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -2.420350784645233e-08;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -2.420350784645233e-08;
                        } else {
                          result[0] += -2.420350784645233e-08;
                        }
                      } else {
                        result[0] += -2.420350784645233e-08;
                      }
                    }
                  } else {
                    result[0] += -2.420350784645233e-08;
                  }
                }
              } else {
                result[0] += -2.420350784645233e-08;
              }
            }
          } else {
            result[0] += -2.420350784645233e-08;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -2.420350784645233e-08;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -2.420350784645233e-08;
                } else {
                  result[0] += -2.420350784645233e-08;
                }
              } else {
                result[0] += -2.420350784645233e-08;
              }
            } else {
              result[0] += -2.420350784645233e-08;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3539353041941689093) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4592177672613065309) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4419864859045226635) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3721023948335018816) ) ) {
                  if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4000638056452025526) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4389499174623116007) ) ) {
                        result[0] += 6.150527448448684e-06;
                      } else {
                        result[0] += -0.00029372925309600195;
                      }
                    } else {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9750000000000000888) ) ) {
                        if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5724391781153673753) ) ) {
                          result[0] += 0.0005480067227996403;
                        } else {
                          result[0] += 0.0025355294486416715;
                        }
                      } else {
                        result[0] += -0.0002858121844667886;
                      }
                    }
                  } else {
                    result[0] += -0.0004137524017639304;
                  }
                } else {
                  result[0] += 0.0013724410803130369;
                }
              } else {
                result[0] += -0.00021022694092618407;
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4050000000000000822) ) ) {
                  result[0] += 0.000665748483340838;
                } else {
                  result[0] += 0.002524570949754002;
                }
              } else {
                result[0] += -0.000809171089710664;
              }
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04653956279752540642) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
                result[0] += 0.00016110006835395497;
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5724391781153673753) ) ) {
                  result[0] += 8.074834025011669e-06;
                } else {
                  result[0] += 0.00018322900807151248;
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05701962466675345592) ) ) {
                result[0] += -1.869736557171141e-05;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1773295000000000288) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0296135000000000044) ) ) {
                    result[0] += 3.704240747838996e-05;
                  } else {
                    result[0] += -1.0759188657395092e-05;
                  }
                } else {
                  result[0] += 3.939071950620044e-05;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1605461427107033601) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3966785421356783803) ) ) {
              result[0] += -0.0005941129912721279;
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3245708964283948172) ) ) {
                result[0] += -0.0001805374038195977;
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2795185878002977575) ) ) {
                  result[0] += 0.00018882321065091538;
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2677063317952667609) ) ) {
                    result[0] += -0.00029738635575014583;
                  } else {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2302999793555680907) ) ) {
                      result[0] += 0.00018804468188054043;
                    } else {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1920506035764254771) ) ) {
                        result[0] += -0.00013689251952727786;
                      } else {
                        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1711110322396684202) ) ) {
                          result[0] += 0.00022479607798775585;
                        } else {
                          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1044543990012605922) ) ) {
                            result[0] += -0.00013111174601580352;
                          } else {
                            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.08110515786938453375) ) ) {
                              result[0] += 0.00034996046068605795;
                            } else {
                              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.0722510271427987405) ) ) {
                                result[0] += -0.000534953700592255;
                              } else {
                                result[0] += 7.112491442503928e-07;
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1165587384072143268) ) ) {
              result[0] += 7.447623649978534e-05;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.576481470050251299) ) ) {
                result[0] += -0.00046889326101676616;
              } else {
                result[0] += 4.421363648417302e-05;
              }
            }
          }
        }
      } else {
        result[0] += 1.469327979789297e-05;
      }
    }
  }
}

