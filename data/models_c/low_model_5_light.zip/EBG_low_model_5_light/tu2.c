
#include "header.h"

void predict_unit2(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -0.00011099695545014655;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -0.00011099695545014655;
                  } else {
                    result[0] += -0.00011099695545014655;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -0.00011099695545014655;
                    } else {
                      result[0] += -0.00011099695545014655;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -0.00011099695545014655;
                    } else {
                      result[0] += -0.00011099695545014655;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.00011672812860030462;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
              result[0] += 6.831437518508749e-05;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002091500000000000477) ) ) {
                  result[0] += -0.0001043035739685374;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01660200000000000217) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01009750000000000057) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004748500000000000117) ) ) {
                        result[0] += -0.00011099695545014655;
                      } else {
                        result[0] += -7.416668441071764e-05;
                      }
                    } else {
                      result[0] += -0.00011099695545014655;
                    }
                  } else {
                    result[0] += -0.00011996637423320165;
                  }
                }
              } else {
                result[0] += 9.097144576748127e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -0.00011099695545014655;
                    } else {
                      result[0] += -0.00011099695545014655;
                    }
                  } else {
                    result[0] += -0.00011099695545014655;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -0.00011099695545014655;
                  } else {
                    result[0] += -0.00011099695545014655;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -0.00011099695545014655;
                        } else {
                          result[0] += -0.00011099695545014655;
                        }
                      } else {
                        result[0] += -0.00011099695545014655;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -0.00011099695545014655;
                          } else {
                            result[0] += -0.00011099695545014655;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -0.00011099695545014655;
                            } else {
                              result[0] += -0.00011099695545014655;
                            }
                          } else {
                            result[0] += -0.00011099695545014655;
                          }
                        }
                      } else {
                        result[0] += -0.00011099695545014655;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -0.00011099695545014655;
                      } else {
                        result[0] += -0.00011099695545014655;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -0.00011099695545014655;
                      } else {
                        result[0] += -0.00011099695545014655;
                      }
                    }
                  }
                } else {
                  result[0] += -0.00011099695545014655;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -0.00011099695545014655;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -0.00011099695545014655;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -0.00011099695545014655;
                    } else {
                      result[0] += -0.00011099695545014655;
                    }
                  }
                } else {
                  result[0] += -0.00011099695545014655;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -0.00011099695545014655;
              } else {
                result[0] += 5.46236052888802e-06;
              }
            } else {
              result[0] += -0.00011099695545014655;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5424744603768845153) ) ) {
            result[0] += 0.00013389146632102205;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.00011728845973729394;
              } else {
                result[0] += -6.201474176893668e-06;
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7472528898492464267) ) ) {
                result[0] += -0.00011728845973729394;
              } else {
                result[0] += -0.0001185737413579044;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
            result[0] += -1.7983946965831172e-06;
          } else {
            result[0] += 0.000994186067596897;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3350000000000000755) ) ) {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0650000000000000161) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05256900000000001155) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
            result[0] += -1.7483733294774808e-05;
          } else {
            result[0] += 0.00011297442624196453;
          }
        } else {
          result[0] += 0.0009543237198120311;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2450000000000000233) ) ) {
            result[0] += 3.376500911848108e-05;
          } else {
            result[0] += 0.0015146973995071645;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.280667053512810405) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7593447680904524821) ) ) {
              result[0] += 0.0018767815837965052;
            } else {
              result[0] += 0.0003203078021923174;
            }
          } else {
            result[0] += -0.0016915652759990514;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8450000000000000844) ) ) {
        result[0] += 0.004663995453636733;
      } else {
        result[0] += 0.013596337233772996;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -0.00010579079926435232;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -0.00010579079926435232;
                  } else {
                    result[0] += -0.00010579079926435232;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -0.00010579079926435232;
                    } else {
                      result[0] += -0.00010579079926435232;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -0.00010579079926435232;
                    } else {
                      result[0] += -0.00010579079926435232;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.0001112531597932403;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.709112113944723732) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
                result[0] += 6.511018543496184e-05;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5131783528140704265) ) ) {
                  result[0] += -0.00011433952006617896;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5694467910050252657) ) ) {
                    result[0] += 0.0001522079451176147;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4364163272837385255) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6169593235427136557) ) ) {
                        result[0] += -0.00010028870123273144;
                      } else {
                        result[0] += -0.00010579079926435232;
                      }
                    } else {
                      result[0] += 8.67045579668899e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.00010579079926435232;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -0.00010579079926435232;
                    } else {
                      result[0] += -0.00010579079926435232;
                    }
                  } else {
                    result[0] += -0.00010579079926435232;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -0.00010579079926435232;
                  } else {
                    result[0] += -0.00010579079926435232;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -0.00010579079926435232;
                        } else {
                          result[0] += -0.00010579079926435232;
                        }
                      } else {
                        result[0] += -0.00010579079926435232;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -0.00010579079926435232;
                          } else {
                            result[0] += -0.00010579079926435232;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -0.00010579079926435232;
                            } else {
                              result[0] += -0.00010579079926435232;
                            }
                          } else {
                            result[0] += -0.00010579079926435232;
                          }
                        }
                      } else {
                        result[0] += -0.00010579079926435232;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -0.00010579079926435232;
                      } else {
                        result[0] += -0.00010579079926435232;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -0.00010579079926435232;
                      } else {
                        result[0] += -0.00010579079926435232;
                      }
                    }
                  }
                } else {
                  result[0] += -0.00010579079926435232;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -0.00010579079926435232;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -0.00010579079926435232;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -0.00010579079926435232;
                    } else {
                      result[0] += -0.00010579079926435232;
                    }
                  }
                } else {
                  result[0] += -0.00010579079926435232;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -0.00010579079926435232;
              } else {
                result[0] += 5.206156185794317e-06;
              }
            } else {
              result[0] += -0.00010579079926435232;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5424744603768845153) ) ) {
            result[0] += 0.00012761147528176034;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.00011178720938581156;
              } else {
                result[0] += -5.910602746986964e-06;
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7472528898492464267) ) ) {
                result[0] += -0.00011178720938581156;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8066186623115578769) ) ) {
                  result[0] += -0.00010151001381961156;
                } else {
                  result[0] += -0.00011644843110443437;
                }
              }
            }
          }
        } else {
          result[0] += 8.132195515673964e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3350000000000000755) ) ) {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09500000000000001499) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04215400000000000397) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4795216591959799435) ) ) {
            result[0] += 0.0007184039927769791;
          } else {
            result[0] += -2.3067771991261288e-06;
          }
        } else {
          result[0] += 0.0008590238365599132;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.08500000000000000611) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7240686518592965859) ) ) {
              result[0] += -0.000270428332967944;
            } else {
              result[0] += -0.001036308251050099;
            }
          } else {
            result[0] += 0.000634888600071039;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.96280210579579717) ) ) {
            result[0] += 0.0017700872173554187;
          } else {
            result[0] += -0.0012029219039162106;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5750000000000000666) ) ) {
        result[0] += 0.004081629748519605;
      } else {
        result[0] += 0.013427655643276639;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -0.00010082883051704198;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -0.00010082883051704198;
                  } else {
                    result[0] += -0.00010082883051704198;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -0.00010082883051704198;
                    } else {
                      result[0] += -0.00010082883051704198;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -0.00010082883051704198;
                    } else {
                      result[0] += -0.00010082883051704198;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.00010603498670283624;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
              result[0] += 6.205628370147971e-05;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002091500000000000477) ) ) {
                  result[0] += -9.41085724242374e-05;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01660200000000000217) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01009750000000000057) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004748500000000000117) ) ) {
                        result[0] += -0.00010082883051704198;
                      } else {
                        result[0] += -7.157608294786984e-05;
                      }
                    } else {
                      result[0] += -0.00010082883051704198;
                    }
                  } else {
                    result[0] += -0.00010897658558514588;
                  }
                }
              } else {
                result[0] += 8.263780254134465e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -0.00010082883051704198;
                    } else {
                      result[0] += -0.00010082883051704198;
                    }
                  } else {
                    result[0] += -0.00010082883051704198;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -0.00010082883051704198;
                  } else {
                    result[0] += -0.00010082883051704198;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -0.00010082883051704198;
                        } else {
                          result[0] += -0.00010082883051704198;
                        }
                      } else {
                        result[0] += -0.00010082883051704198;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -0.00010082883051704198;
                          } else {
                            result[0] += -0.00010082883051704198;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -0.00010082883051704198;
                            } else {
                              result[0] += -0.00010082883051704198;
                            }
                          } else {
                            result[0] += -0.00010082883051704198;
                          }
                        }
                      } else {
                        result[0] += -0.00010082883051704198;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -0.00010082883051704198;
                      } else {
                        result[0] += -0.00010082883051704198;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -0.00010082883051704198;
                      } else {
                        result[0] += -0.00010082883051704198;
                      }
                    }
                  }
                } else {
                  result[0] += -0.00010082883051704198;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -0.00010082883051704198;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -0.00010082883051704198;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -0.00010082883051704198;
                    } else {
                      result[0] += -0.00010082883051704198;
                    }
                  }
                } else {
                  result[0] += -0.00010082883051704198;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -0.00010082883051704198;
              } else {
                result[0] += 4.961968747310416e-06;
              }
            } else {
              result[0] += -0.00010082883051704198;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5424744603768845153) ) ) {
            result[0] += 0.00012162603839547689;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
              result[0] += -0.0001065439874498909;
            } else {
              result[0] += -0.0001065439874498909;
            }
          }
        } else {
          result[0] += 7.750766315059265e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3350000000000000755) ) ) {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09500000000000001499) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05256900000000001155) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5613540176884422861) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0004575000000000000616) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.05500000000000000722) ) ) {
                result[0] += -0.00010893002468069117;
              } else {
                result[0] += 0.0003406111908319091;
              }
            } else {
              result[0] += 0.0008667382889961127;
            }
          } else {
            result[0] += -8.311097749133939e-06;
          }
        } else {
          result[0] += 0.0009254437670231181;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.08500000000000000611) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7240686518592965859) ) ) {
              result[0] += -0.0002577442721053247;
            } else {
              result[0] += -0.0009877016690973419;
            }
          } else {
            result[0] += 0.0006051100426399334;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.028975360347832879) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7593447680904524821) ) ) {
              result[0] += 0.0019637921760366226;
            } else {
              result[0] += 0.00024574334068173205;
            }
          } else {
            result[0] += -0.0014772739397814578;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6150000000000001021) ) ) {
        result[0] += 0.004226293364761001;
      } else {
        result[0] += 0.013735924118755993;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -9.609959593962633e-05;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -9.609959593962633e-05;
                  } else {
                    result[0] += -9.609959593962633e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -9.609959593962633e-05;
                    } else {
                      result[0] += -9.609959593962633e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -9.609959593962633e-05;
                    } else {
                      result[0] += -9.609959593962633e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.00010106156468693668;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.709112113944723732) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
                result[0] += 5.914562093645486e-05;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5131783528140704265) ) ) {
                  result[0] += -0.00010386519200817825;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5673593061306533292) ) ) {
                    result[0] += 0.00014119283540650816;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4364163272837385255) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6169593235427136557) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2103007793702001138) ) ) {
                          result[0] += -0.00014891411190649765;
                        } else {
                          result[0] += 0.00031203620396116476;
                        }
                      } else {
                        result[0] += -9.609959593962633e-05;
                      }
                    } else {
                      result[0] += 7.876179256308626e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -9.609959593962633e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -9.609959593962633e-05;
                    } else {
                      result[0] += -9.609959593962633e-05;
                    }
                  } else {
                    result[0] += -9.609959593962633e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -9.609959593962633e-05;
                  } else {
                    result[0] += -9.609959593962633e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -9.609959593962633e-05;
                        } else {
                          result[0] += -9.609959593962633e-05;
                        }
                      } else {
                        result[0] += -9.609959593962633e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -9.609959593962633e-05;
                          } else {
                            result[0] += -9.609959593962633e-05;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -9.609959593962633e-05;
                            } else {
                              result[0] += -9.609959593962633e-05;
                            }
                          } else {
                            result[0] += -9.609959593962633e-05;
                          }
                        }
                      } else {
                        result[0] += -9.609959593962633e-05;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -9.609959593962633e-05;
                      } else {
                        result[0] += -9.609959593962633e-05;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -9.609959593962633e-05;
                      } else {
                        result[0] += -9.609959593962633e-05;
                      }
                    }
                  }
                } else {
                  result[0] += -9.609959593962633e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -9.609959593962633e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -9.609959593962633e-05;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -9.609959593962633e-05;
                    } else {
                      result[0] += -9.609959593962633e-05;
                    }
                  }
                } else {
                  result[0] += -9.609959593962633e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -9.609959593962633e-05;
              } else {
                result[0] += 4.729234577415696e-06;
              }
            } else {
              result[0] += -9.609959593962633e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01314200000000000264) ) ) {
            result[0] += -0.00010154669146936677;
          } else {
            result[0] += 4.598937036989449e-06;
          }
        } else {
          result[0] += 4.0736197003422785e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3350000000000000755) ) ) {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09500000000000001499) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05256900000000001155) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4292508528894472541) ) ) {
            result[0] += 0.001451155500087762;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4421126575628140931) ) ) {
              result[0] += -0.0005972602308210907;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4795216591959799435) ) ) {
                result[0] += 0.0008402347805296779;
              } else {
                result[0] += -1.6460956112525736e-06;
              }
            }
          }
        } else {
          result[0] += 0.000882037127870244;
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01660200000000000217) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
            result[0] += 0.0010908671081605982;
          } else {
            result[0] += 8.711115814433229e-05;
          }
        } else {
          result[0] += 0.0024985997709825714;
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8050000000000001599) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.173295225808050013) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1850000000000000255) ) ) {
            result[0] += -0.0005919353148454131;
          } else {
            result[0] += 0.003955753342301553;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01130350000000000278) ) ) {
            result[0] += 0.0023972394127204327;
          } else {
            result[0] += -0.002483741438307102;
          }
        }
      } else {
        result[0] += 0.01128632215834496;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -9.159217946298141e-05;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -9.159217946298141e-05;
                  } else {
                    result[0] += -9.159217946298141e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -9.159217946298141e-05;
                    } else {
                      result[0] += -9.159217946298141e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -9.159217946298141e-05;
                    } else {
                      result[0] += -9.159217946298141e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -9.632141404039709e-05;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
              result[0] += 5.637147871739852e-05;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002091500000000000477) ) ) {
                  result[0] += -8.487752697277836e-05;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01660200000000000217) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01009750000000000057) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004748500000000000117) ) ) {
                        result[0] += -9.159217946298141e-05;
                      } else {
                        result[0] += -6.909430770379091e-05;
                      }
                    } else {
                      result[0] += -9.159217946298141e-05;
                    }
                  } else {
                    result[0] += -9.899354116271922e-05;
                  }
                }
              } else {
                result[0] += 7.506758138500835e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -9.159217946298141e-05;
                    } else {
                      result[0] += -9.159217946298141e-05;
                    }
                  } else {
                    result[0] += -9.159217946298141e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -9.159217946298141e-05;
                  } else {
                    result[0] += -9.159217946298141e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -9.159217946298141e-05;
                        } else {
                          result[0] += -9.159217946298141e-05;
                        }
                      } else {
                        result[0] += -9.159217946298141e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -9.159217946298141e-05;
                          } else {
                            result[0] += -9.159217946298141e-05;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -9.159217946298141e-05;
                            } else {
                              result[0] += -9.159217946298141e-05;
                            }
                          } else {
                            result[0] += -9.159217946298141e-05;
                          }
                        }
                      } else {
                        result[0] += -9.159217946298141e-05;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -9.159217946298141e-05;
                      } else {
                        result[0] += -9.159217946298141e-05;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -9.159217946298141e-05;
                      } else {
                        result[0] += -9.159217946298141e-05;
                      }
                    }
                  }
                } else {
                  result[0] += -9.159217946298141e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -9.159217946298141e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -9.159217946298141e-05;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -9.159217946298141e-05;
                    } else {
                      result[0] += -9.159217946298141e-05;
                    }
                  }
                } else {
                  result[0] += -9.159217946298141e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -9.159217946298141e-05;
              } else {
                result[0] += 4.507416476645e-06;
              }
            } else {
              result[0] += -9.159217946298141e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7472528898492464267) ) ) {
            result[0] += -9.678378663295772e-05;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8066186623115578769) ) ) {
              result[0] += -8.698862847987955e-05;
            } else {
              result[0] += -0.00010122638029835735;
            }
          }
        } else {
          result[0] += 7.196160108540866e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.25500000000000006) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5613540176884422861) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.05500000000000000722) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5286349724371860459) ) ) {
              result[0] += -6.320228889394819e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5450375474120604524) ) ) {
                result[0] += -0.0004928282504547952;
              } else {
                result[0] += -0.00028468151010744555;
              }
            }
          } else {
            result[0] += 0.0004478320054104401;
          }
        } else {
          result[0] += 0.0013512469160843416;
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04215400000000000397) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1850000000000000255) ) ) {
            result[0] += -1.1337080616656933e-06;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.051391296366422923) ) ) {
              result[0] += 0.0011852813799661794;
            } else {
              result[0] += -0.0005957359578122389;
            }
          }
        } else {
          result[0] += 0.00080334888523723;
        }
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5750000000000000666) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1850000000000000255) ) ) {
            result[0] += -0.001961664316723813;
          } else {
            result[0] += 0.0018495333078895825;
          }
        } else {
          result[0] += 0.0033487371638513163;
        }
      } else {
        result[0] += 0.011624217036207246;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -8.729617702086265e-05;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -8.729617702086265e-05;
                  } else {
                    result[0] += -8.729617702086265e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -8.729617702086265e-05;
                    } else {
                      result[0] += -8.729617702086265e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -8.729617702086265e-05;
                    } else {
                      result[0] += -8.729617702086265e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -9.180359349750761e-05;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
              result[0] += 5.372745373998581e-05;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002091500000000000477) ) ) {
                  result[0] += -8.08964658680644e-05;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01660200000000000217) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01009750000000000057) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004748500000000000117) ) ) {
                        result[0] += -8.729617702086265e-05;
                      } else {
                        result[0] += -6.585353631509434e-05;
                      }
                    } else {
                      result[0] += -8.729617702086265e-05;
                    }
                  } else {
                    result[0] += -9.435038825291311e-05;
                  }
                }
              } else {
                result[0] += 7.154664198991205e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -8.729617702086265e-05;
                    } else {
                      result[0] += -8.729617702086265e-05;
                    }
                  } else {
                    result[0] += -8.729617702086265e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -8.729617702086265e-05;
                  } else {
                    result[0] += -8.729617702086265e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -8.729617702086265e-05;
                        } else {
                          result[0] += -8.729617702086265e-05;
                        }
                      } else {
                        result[0] += -8.729617702086265e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -8.729617702086265e-05;
                          } else {
                            result[0] += -8.729617702086265e-05;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -8.729617702086265e-05;
                            } else {
                              result[0] += -8.729617702086265e-05;
                            }
                          } else {
                            result[0] += -8.729617702086265e-05;
                          }
                        }
                      } else {
                        result[0] += -8.729617702086265e-05;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -8.729617702086265e-05;
                      } else {
                        result[0] += -8.729617702086265e-05;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -8.729617702086265e-05;
                      } else {
                        result[0] += -8.729617702086265e-05;
                      }
                    }
                  }
                } else {
                  result[0] += -8.729617702086265e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -8.729617702086265e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -8.729617702086265e-05;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -8.729617702086265e-05;
                    } else {
                      result[0] += -8.729617702086265e-05;
                    }
                  }
                } else {
                  result[0] += -8.729617702086265e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -8.729617702086265e-05;
              } else {
                result[0] += 4.296002442118807e-06;
              }
            } else {
              result[0] += -8.729617702086265e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -9.224427915349292e-05;
          } else {
            result[0] += 3.7123618208694283e-06;
          }
        } else {
          result[0] += 6.8586343330715605e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3850000000000000644) ) ) {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09500000000000001499) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5613540176884422861) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0004575000000000000616) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.05500000000000000722) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
                result[0] += -1.0421537064016187e-05;
              } else {
                result[0] += -0.0005479324909242875;
              }
            } else {
              result[0] += 0.0003014237656979064;
            }
          } else {
            result[0] += 0.0008305778475986608;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.055261500000000012) ) ) {
            result[0] += -8.664520788780624e-06;
          } else {
            result[0] += 0.0007672443372558664;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1650000000000000355) ) ) {
            result[0] += -0.0002919145436483003;
          } else {
            result[0] += 0.0007637356408440782;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7593447680904524821) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.173295225808050013) ) ) {
              result[0] += 0.0018344159758487866;
            } else {
              result[0] += -0.0021920236523246673;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8458243956458841861) ) ) {
              result[0] += -0.0014400474012287122;
            } else {
              result[0] += 0.0004086431635244564;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5750000000000000666) ) ) {
        result[0] += 0.003846841291459824;
      } else {
        result[0] += 0.011078999474314333;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -8.320167253512945e-05;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -8.320167253512945e-05;
                  } else {
                    result[0] += -8.320167253512945e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -8.320167253512945e-05;
                    } else {
                      result[0] += -8.320167253512945e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -8.320167253512945e-05;
                    } else {
                      result[0] += -8.320167253512945e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -8.749767497724825e-05;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.709112113944723732) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
                result[0] += 5.120744303788115e-05;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5131783528140704265) ) ) {
                  result[0] += -8.99250159042489e-05;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5694467910050252657) ) ) {
                    result[0] += 0.00012769364983593489;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4364163272837385255) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6169593235427136557) ) ) {
                        result[0] += -0.00010615195361546553;
                      } else {
                        result[0] += -8.320167253512945e-05;
                      }
                    } else {
                      result[0] += 6.819084730835539e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -8.320167253512945e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -8.320167253512945e-05;
                    } else {
                      result[0] += -8.320167253512945e-05;
                    }
                  } else {
                    result[0] += -8.320167253512945e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -8.320167253512945e-05;
                  } else {
                    result[0] += -8.320167253512945e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -8.320167253512945e-05;
                        } else {
                          result[0] += -8.320167253512945e-05;
                        }
                      } else {
                        result[0] += -8.320167253512945e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -8.320167253512945e-05;
                          } else {
                            result[0] += -8.320167253512945e-05;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -8.320167253512945e-05;
                            } else {
                              result[0] += -8.320167253512945e-05;
                            }
                          } else {
                            result[0] += -8.320167253512945e-05;
                          }
                        }
                      } else {
                        result[0] += -8.320167253512945e-05;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -8.320167253512945e-05;
                      } else {
                        result[0] += -8.320167253512945e-05;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -8.320167253512945e-05;
                      } else {
                        result[0] += -8.320167253512945e-05;
                      }
                    }
                  }
                } else {
                  result[0] += -8.320167253512945e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -8.320167253512945e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -8.320167253512945e-05;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -8.320167253512945e-05;
                    } else {
                      result[0] += -8.320167253512945e-05;
                    }
                  }
                } else {
                  result[0] += -8.320167253512945e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -8.320167253512945e-05;
              } else {
                result[0] += 4.094504485733255e-06;
              }
            } else {
              result[0] += -8.320167253512945e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7472528898492464267) ) ) {
              result[0] += -8.791769089193666e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8066186623115578769) ) ) {
                result[0] += -7.193663515744323e-05;
              } else {
                result[0] += -9.215191094566114e-05;
              }
            }
          } else {
            result[0] += 1.6446729358428713e-06;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.316725863161028132) ) ) {
            result[0] += 8.24793665998839e-06;
          } else {
            result[0] += -0.00023115160762046541;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3850000000000000644) ) ) {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09500000000000001499) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5613540176884422861) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002682500000000000422) ) ) {
            result[0] += 9.566670051819433e-05;
          } else {
            result[0] += 0.0008859813952822082;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.055261500000000012) ) ) {
            result[0] += -8.258123619430149e-06;
          } else {
            result[0] += 0.000731257820002118;
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006028500000000000872) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
            result[0] += 0.0009058017664510443;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1250000000000000278) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7801862323115579256) ) ) {
                result[0] += -0.0009491230669284274;
              } else {
                result[0] += 0.00021452563520733172;
              }
            } else {
              result[0] += 0.000319584321998298;
            }
          }
        } else {
          result[0] += 0.001846413539709789;
        }
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6350000000000001199) ) ) {
        result[0] += 0.0040070892564019935;
      } else {
        result[0] += 0.01196646386367972;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -7.929921502734906e-05;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -7.929921502734906e-05;
                  } else {
                    result[0] += -7.929921502734906e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -7.929921502734906e-05;
                    } else {
                      result[0] += -7.929921502734906e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -7.929921502734906e-05;
                    } else {
                      result[0] += -7.929921502734906e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -8.339371951308229e-05;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
              result[0] += 4.8805629895807054e-05;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002091500000000000477) ) ) {
                  result[0] += -7.293162718713328e-05;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01660200000000000217) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01009750000000000057) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004748500000000000117) ) ) {
                        result[0] += -7.929921502734906e-05;
                      } else {
                        result[0] += -6.365051109818324e-05;
                      }
                    } else {
                      result[0] += -7.929921502734906e-05;
                    }
                  } else {
                    result[0] += -8.570720942560343e-05;
                  }
                }
              } else {
                result[0] += 6.499245145966572e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -7.929921502734906e-05;
                    } else {
                      result[0] += -7.929921502734906e-05;
                    }
                  } else {
                    result[0] += -7.929921502734906e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -7.929921502734906e-05;
                  } else {
                    result[0] += -7.929921502734906e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -7.929921502734906e-05;
                        } else {
                          result[0] += -7.929921502734906e-05;
                        }
                      } else {
                        result[0] += -7.929921502734906e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -7.929921502734906e-05;
                          } else {
                            result[0] += -7.929921502734906e-05;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -7.929921502734906e-05;
                            } else {
                              result[0] += -7.929921502734906e-05;
                            }
                          } else {
                            result[0] += -7.929921502734906e-05;
                          }
                        }
                      } else {
                        result[0] += -7.929921502734906e-05;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -7.929921502734906e-05;
                      } else {
                        result[0] += -7.929921502734906e-05;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -7.929921502734906e-05;
                      } else {
                        result[0] += -7.929921502734906e-05;
                      }
                    }
                  }
                } else {
                  result[0] += -7.929921502734906e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -7.929921502734906e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -7.929921502734906e-05;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -7.929921502734906e-05;
                    } else {
                      result[0] += -7.929921502734906e-05;
                    }
                  }
                } else {
                  result[0] += -7.929921502734906e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -7.929921502734906e-05;
              } else {
                result[0] += 3.902457507780415e-06;
              }
            } else {
              result[0] += -7.929921502734906e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
            result[0] += -8.379403517163736e-05;
          } else {
            result[0] += 1.5675318634249713e-06;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.316725863161028132) ) ) {
            result[0] += 7.861078783677317e-06;
          } else {
            result[0] += -0.0002203097663556384;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4050000000000000822) ) ) {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.25500000000000006) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5613540176884422861) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.05500000000000000722) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
                result[0] += -1.6094963112293282e-05;
              } else {
                result[0] += -0.0005351430182160755;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1750000000000000167) ) ) {
                result[0] += 0.0003952862294049228;
              } else {
                result[0] += -0.0004982158057357826;
              }
            }
          } else {
            result[0] += 0.0011104450795728668;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04215400000000000397) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03500000000000001027) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001774500000000000252) ) ) {
                result[0] += 5.1210104585909505e-06;
              } else {
                result[0] += -0.00015368472405841665;
              }
            } else {
              result[0] += 5.632225076416193e-05;
            }
          } else {
            result[0] += 0.0006119629559801885;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8411352666870987038) ) ) {
          result[0] += 0.001863062447576631;
        } else {
          result[0] += 0.00046901504542939975;
        }
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6650000000000001465) ) ) {
        result[0] += 0.004134040640054155;
      } else {
        result[0] += 0.012812300187548012;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -7.557979680394844e-05;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -7.557979680394844e-05;
                  } else {
                    result[0] += -7.557979680394844e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -7.557979680394844e-05;
                    } else {
                      result[0] += -7.557979680394844e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -7.557979680394844e-05;
                    } else {
                      result[0] += -7.557979680394844e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -7.948225431172887e-05;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.709112113944723732) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
                result[0] += 4.6516470423340635e-05;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5131783528140704265) ) ) {
                  result[0] += -8.168723323158362e-05;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5694467910050252657) ) ) {
                    result[0] += 0.00011865597908083737;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4364163272837385255) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6169593235427136557) ) ) {
                        result[0] += -9.962703690203403e-05;
                      } else {
                        result[0] += -7.557979680394844e-05;
                      }
                    } else {
                      result[0] += 6.194407187281627e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -7.557979680394844e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -7.557979680394844e-05;
                    } else {
                      result[0] += -7.557979680394844e-05;
                    }
                  } else {
                    result[0] += -7.557979680394844e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -7.557979680394844e-05;
                  } else {
                    result[0] += -7.557979680394844e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -7.557979680394844e-05;
                        } else {
                          result[0] += -7.557979680394844e-05;
                        }
                      } else {
                        result[0] += -7.557979680394844e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -7.557979680394844e-05;
                          } else {
                            result[0] += -7.557979680394844e-05;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -7.557979680394844e-05;
                            } else {
                              result[0] += -7.557979680394844e-05;
                            }
                          } else {
                            result[0] += -7.557979680394844e-05;
                          }
                        }
                      } else {
                        result[0] += -7.557979680394844e-05;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -7.557979680394844e-05;
                      } else {
                        result[0] += -7.557979680394844e-05;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -7.557979680394844e-05;
                      } else {
                        result[0] += -7.557979680394844e-05;
                      }
                    }
                  }
                } else {
                  result[0] += -7.557979680394844e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -7.557979680394844e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -7.557979680394844e-05;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -7.557979680394844e-05;
                    } else {
                      result[0] += -7.557979680394844e-05;
                    }
                  }
                } else {
                  result[0] += -7.557979680394844e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -7.557979680394844e-05;
              } else {
                result[0] += 3.7194182234006454e-06;
              }
            } else {
              result[0] += -7.557979680394844e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
            result[0] += -7.986379372697525e-05;
          } else {
            result[0] += 1.4940089845846687e-06;
          }
        } else {
          result[0] += 7.492365932314126e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6350000000000001199) ) ) {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.25500000000000006) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0009565000000000001019) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3550000000000000377) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
              result[0] += -1.5314367947954067e-05;
            } else {
              result[0] += 3.0469312370432264e-05;
            }
          } else {
            result[0] += -0.0015942236800340626;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7270847835843652351) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04119700000000000445) ) ) {
              result[0] += 0.0004958050762051581;
            } else {
              result[0] += 0.002349338231741598;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.992027305872230758) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7568047583165830039) ) ) {
                  result[0] += -0.00014678017628172327;
                } else {
                  result[0] += -0.00031554490109026074;
                }
              } else {
                result[0] += 2.511765507182132e-05;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                result[0] += 0.00012327323231201977;
              } else {
                result[0] += -0.0013842641438838016;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.73477567396984933) ) ) {
          result[0] += 0.001907855852657528;
        } else {
          result[0] += 0.00027001916359671417;
        }
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6750000000000001554) ) ) {
        result[0] += 0.0038928329589710997;
      } else {
        result[0] += 0.012680392752716938;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -7.203483266456106e-05;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -7.203483266456106e-05;
                  } else {
                    result[0] += -7.203483266456106e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -7.203483266456106e-05;
                    } else {
                      result[0] += -7.203483266456106e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -7.203483266456106e-05;
                    } else {
                      result[0] += -7.203483266456106e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -7.57542508879617e-05;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
              result[0] += 4.433468075844698e-05;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002091500000000000477) ) ) {
                  result[0] += -6.572241640602364e-05;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01660200000000000217) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01009750000000000057) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004748500000000000117) ) ) {
                        result[0] += -7.203483266456106e-05;
                      } else {
                        result[0] += -6.153205686953272e-05;
                      }
                    } else {
                      result[0] += -7.203483266456106e-05;
                    }
                  } else {
                    result[0] += -7.785580837074555e-05;
                  }
                }
              } else {
                result[0] += 5.903867224589769e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -7.203483266456106e-05;
                    } else {
                      result[0] += -7.203483266456106e-05;
                    }
                  } else {
                    result[0] += -7.203483266456106e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -7.203483266456106e-05;
                  } else {
                    result[0] += -7.203483266456106e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -7.203483266456106e-05;
                        } else {
                          result[0] += -7.203483266456106e-05;
                        }
                      } else {
                        result[0] += -7.203483266456106e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -7.203483266456106e-05;
                          } else {
                            result[0] += -7.203483266456106e-05;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -7.203483266456106e-05;
                            } else {
                              result[0] += -7.203483266456106e-05;
                            }
                          } else {
                            result[0] += -7.203483266456106e-05;
                          }
                        }
                      } else {
                        result[0] += -7.203483266456106e-05;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -7.203483266456106e-05;
                      } else {
                        result[0] += -7.203483266456106e-05;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -7.203483266456106e-05;
                      } else {
                        result[0] += -7.203483266456106e-05;
                      }
                    }
                  }
                } else {
                  result[0] += -7.203483266456106e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -7.203483266456106e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -7.203483266456106e-05;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -7.203483266456106e-05;
                    } else {
                      result[0] += -7.203483266456106e-05;
                    }
                  }
                } else {
                  result[0] += -7.203483266456106e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -7.203483266456106e-05;
              } else {
                result[0] += 3.5449641393873786e-06;
              }
            } else {
              result[0] += -7.203483266456106e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7472528898492464267) ) ) {
              result[0] += -7.61178947332012e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8066186623115578769) ) ) {
                result[0] += -6.088640795607457e-05;
              } else {
                result[0] += -8.015351464663073e-05;
              }
            }
          } else {
            result[0] += 1.4239345930377462e-06;
          }
        } else {
          result[0] += 7.140947039007024e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3850000000000000644) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5613540176884422861) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.05500000000000000722) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
              result[0] += -1.462175258568194e-05;
            } else {
              result[0] += -0.0005114720073776199;
            }
          } else {
            result[0] += 0.00038567591770139766;
          }
        } else {
          result[0] += 0.001385077825013634;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2050000000000000433) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04215400000000000397) ) ) {
            result[0] += -7.608634362230849e-07;
          } else {
            result[0] += 0.0005943815927621956;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001851500000000000064) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1350000000000000366) ) ) {
              result[0] += -0.0006126807049709106;
            } else {
              result[0] += 0.0008362623941052787;
            }
          } else {
            result[0] += 0.0016061210899524483;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9550000000000000711) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4350000000000000533) ) ) {
          result[0] += 0.0015052157591478278;
        } else {
          result[0] += 0.004040046886516077;
        }
      } else {
        result[0] += 0.011616601255939718;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -6.86561400855768e-05;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -6.86561400855768e-05;
                  } else {
                    result[0] += -6.86561400855768e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -6.86561400855768e-05;
                    } else {
                      result[0] += -6.86561400855768e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -6.86561400855768e-05;
                    } else {
                      result[0] += -6.86561400855768e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -7.22011042249642e-05;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
              result[0] += 4.225522487121352e-05;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002091500000000000477) ) ) {
                  result[0] += -6.263979883935314e-05;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01660200000000000217) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01009750000000000057) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004748500000000000117) ) ) {
                        result[0] += -6.86561400855768e-05;
                      } else {
                        result[0] += -5.864598222724361e-05;
                      }
                    } else {
                      result[0] += -6.86561400855768e-05;
                    }
                  } else {
                    result[0] += -7.4204091107821e-05;
                  }
                }
              } else {
                result[0] += 5.626954630485226e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -6.86561400855768e-05;
                    } else {
                      result[0] += -6.86561400855768e-05;
                    }
                  } else {
                    result[0] += -6.86561400855768e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -6.86561400855768e-05;
                  } else {
                    result[0] += -6.86561400855768e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -6.86561400855768e-05;
                        } else {
                          result[0] += -6.86561400855768e-05;
                        }
                      } else {
                        result[0] += -6.86561400855768e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -6.86561400855768e-05;
                          } else {
                            result[0] += -6.86561400855768e-05;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -6.86561400855768e-05;
                            } else {
                              result[0] += -6.86561400855768e-05;
                            }
                          } else {
                            result[0] += -6.86561400855768e-05;
                          }
                        }
                      } else {
                        result[0] += -6.86561400855768e-05;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -6.86561400855768e-05;
                      } else {
                        result[0] += -6.86561400855768e-05;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -6.86561400855768e-05;
                      } else {
                        result[0] += -6.86561400855768e-05;
                      }
                    }
                  }
                } else {
                  result[0] += -6.86561400855768e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -6.86561400855768e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -6.86561400855768e-05;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -6.86561400855768e-05;
                    } else {
                      result[0] += -6.86561400855768e-05;
                    }
                  }
                } else {
                  result[0] += -6.86561400855768e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -6.86561400855768e-05;
              } else {
                result[0] += 3.3786925789842607e-06;
              }
            } else {
              result[0] += -6.86561400855768e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7472528898492464267) ) ) {
              result[0] += -7.254769186675521e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8066186623115578769) ) ) {
                result[0] += -5.803061656859205e-05;
              } else {
                result[0] += -7.639402670033179e-05;
              }
            }
          } else {
            result[0] += 1.357146942334698e-06;
          }
        } else {
          result[0] += 6.8060109549605195e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6350000000000001199) ) ) {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.25500000000000006) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04215400000000000397) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5613540176884422861) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2450000000000000233) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.05500000000000000722) ) ) {
                  result[0] += -0.00017025658315112974;
                } else {
                  result[0] += 0.00027519316326454416;
                }
              } else {
                result[0] += -0.000938844513575995;
              }
            } else {
              result[0] += 0.0007411811716010421;
            }
          } else {
            result[0] += -9.158842339721755e-08;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8440161800932387548) ) ) {
            result[0] += 0.0018222137103966907;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7418777389447237525) ) ) {
              result[0] += -0.0015983580137087106;
            } else {
              result[0] += 0.00029024777155701407;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8411352666870987038) ) ) {
          result[0] += 0.0017993433124658695;
        } else {
          result[0] += 0.0002704949521862811;
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9550000000000000711) ) ) {
        result[0] += 0.003735992163125091;
      } else {
        result[0] += 0.011071740901516042;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -6.543592033315466e-05;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -6.543592033315466e-05;
                  } else {
                    result[0] += -6.543592033315466e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -6.543592033315466e-05;
                    } else {
                      result[0] += -6.543592033315466e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -6.543592033315466e-05;
                    } else {
                      result[0] += -6.543592033315466e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -6.881461291213895e-05;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.709112113944723732) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
                result[0] += 4.0273302939632254e-05;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5131783528140704265) ) ) {
                  result[0] += -7.072365251051431e-05;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5694467910050252657) ) ) {
                    result[0] += 0.00010768221723471938;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4364163272837385255) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6169593235427136557) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2103007793702001138) ) ) {
                          result[0] += -0.00011428725363635797;
                        } else {
                          result[0] += 0.00032621925238605036;
                        }
                      } else {
                        result[0] += -6.543592033315466e-05;
                      }
                    } else {
                      result[0] += 5.363030232398089e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -6.543592033315466e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -6.543592033315466e-05;
                    } else {
                      result[0] += -6.543592033315466e-05;
                    }
                  } else {
                    result[0] += -6.543592033315466e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -6.543592033315466e-05;
                  } else {
                    result[0] += -6.543592033315466e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -6.543592033315466e-05;
                        } else {
                          result[0] += -6.543592033315466e-05;
                        }
                      } else {
                        result[0] += -6.543592033315466e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -6.543592033315466e-05;
                          } else {
                            result[0] += -6.543592033315466e-05;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -6.543592033315466e-05;
                            } else {
                              result[0] += -6.543592033315466e-05;
                            }
                          } else {
                            result[0] += -6.543592033315466e-05;
                          }
                        }
                      } else {
                        result[0] += -6.543592033315466e-05;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -6.543592033315466e-05;
                      } else {
                        result[0] += -6.543592033315466e-05;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -6.543592033315466e-05;
                      } else {
                        result[0] += -6.543592033315466e-05;
                      }
                    }
                  }
                } else {
                  result[0] += -6.543592033315466e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -6.543592033315466e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -6.543592033315466e-05;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -6.543592033315466e-05;
                    } else {
                      result[0] += -6.543592033315466e-05;
                    }
                  }
                } else {
                  result[0] += -6.543592033315466e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -6.543592033315466e-05;
              } else {
                result[0] += 3.220219752422148e-06;
              }
            } else {
              result[0] += -6.543592033315466e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7472528898492464267) ) ) {
              result[0] += -6.914494434773123e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8066186623115578769) ) ) {
                result[0] += -5.530877206223779e-05;
              } else {
                result[0] += -7.281087225207942e-05;
              }
            }
          } else {
            result[0] += 1.2934918725157335e-06;
          }
        } else {
          result[0] += 6.486784577173368e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4650000000000000244) ) ) {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.25500000000000006) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04215400000000000397) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5613540176884422861) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2450000000000000233) ) ) {
                result[0] += 2.3122593557892493e-05;
              } else {
                result[0] += -0.0006981025852172657;
              }
            } else {
              result[0] += 0.0007010598557682488;
            }
          } else {
            result[0] += -1.450105620010593e-07;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8440161800932387548) ) ) {
            result[0] += 0.0017267624747900894;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7418777389447237525) ) ) {
              result[0] += -0.0015233892776164773;
            } else {
              result[0] += 0.00027663410778419774;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7273815826884423297) ) ) {
          result[0] += 0.0017279279772792124;
        } else {
          result[0] += 0.00030262997368156865;
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9550000000000000711) ) ) {
        result[0] += 0.004230705451031378;
      } else {
        result[0] += 0.010631047257701861;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -6.236674046210314e-05;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -6.236674046210314e-05;
                  } else {
                    result[0] += -6.236674046210314e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -6.236674046210314e-05;
                    } else {
                      result[0] += -6.236674046210314e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -6.236674046210314e-05;
                    } else {
                      result[0] += -6.236674046210314e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -6.558696021452529e-05;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
              result[0] += 3.838434027060029e-05;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002091500000000000477) ) ) {
                  result[0] += -5.642177602546776e-05;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01660200000000000217) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01009750000000000057) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004748500000000000117) ) ) {
                        result[0] += -6.236674046210314e-05;
                      } else {
                        result[0] += -5.676201962558679e-05;
                      }
                    } else {
                      result[0] += -6.236674046210314e-05;
                    }
                  } else {
                    result[0] += -6.740645899375205e-05;
                  }
                }
              } else {
                result[0] += 5.11148483724947e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -6.236674046210314e-05;
                    } else {
                      result[0] += -6.236674046210314e-05;
                    }
                  } else {
                    result[0] += -6.236674046210314e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -6.236674046210314e-05;
                  } else {
                    result[0] += -6.236674046210314e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -6.236674046210314e-05;
                        } else {
                          result[0] += -6.236674046210314e-05;
                        }
                      } else {
                        result[0] += -6.236674046210314e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -6.236674046210314e-05;
                          } else {
                            result[0] += -6.236674046210314e-05;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -6.236674046210314e-05;
                            } else {
                              result[0] += -6.236674046210314e-05;
                            }
                          } else {
                            result[0] += -6.236674046210314e-05;
                          }
                        }
                      } else {
                        result[0] += -6.236674046210314e-05;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -6.236674046210314e-05;
                      } else {
                        result[0] += -6.236674046210314e-05;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -6.236674046210314e-05;
                      } else {
                        result[0] += -6.236674046210314e-05;
                      }
                    }
                  }
                } else {
                  result[0] += -6.236674046210314e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -6.236674046210314e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -6.236674046210314e-05;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -6.236674046210314e-05;
                    } else {
                      result[0] += -6.236674046210314e-05;
                    }
                  }
                } else {
                  result[0] += -6.236674046210314e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -6.236674046210314e-05;
              } else {
                result[0] += 3.0691798710515035e-06;
              }
            } else {
              result[0] += -6.236674046210314e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7472528898492464267) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7322719660050253099) ) ) {
                result[0] += -6.590179791842199e-05;
              } else {
                result[0] += 0.00038122865828659505;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8066186623115578769) ) ) {
                result[0] += -5.27145918468189e-05;
              } else {
                result[0] += -6.939578062698984e-05;
              }
            }
          } else {
            result[0] += 1.2328224542775107e-06;
          }
        } else {
          result[0] += 6.182531063953922e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4650000000000000244) ) ) {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2050000000000000433) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5613540176884422861) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02972700000000000342) ) ) {
            result[0] += 0.00038587845897535217;
          } else {
            result[0] += 0.0020077209556624985;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04215400000000000397) ) ) {
            result[0] += -3.139807940270965e-06;
          } else {
            result[0] += 0.0004458305492904789;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.000210500000000000048) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1650000000000000355) ) ) {
            result[0] += -0.0010388197130823677;
          } else {
            result[0] += 0.0006872480644524704;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8299222285691966183) ) ) {
            result[0] += 0.0021233272838569643;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3450000000000000289) ) ) {
              result[0] += 0.0016320164981929348;
            } else {
              result[0] += 6.673663765164522e-05;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9650000000000000799) ) ) {
        result[0] += 0.0041388199511105265;
      } else {
        result[0] += 0.010522837624224884;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -5.9441516159077674e-05;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -5.9441516159077674e-05;
                  } else {
                    result[0] += -5.9441516159077674e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -5.9441516159077674e-05;
                    } else {
                      result[0] += -5.9441516159077674e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -5.9441516159077674e-05;
                    } else {
                      result[0] += -5.9441516159077674e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -6.251069603012923e-05;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.709112113944723732) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
                result[0] += 3.65839767405648e-05;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5131783528140704265) ) ) {
                  result[0] += -6.424485377647719e-05;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5694467910050252657) ) ) {
                    result[0] += 0.00010023406406651559;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4364163272837385255) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6169593235427136557) ) ) {
                        result[0] += -9.286649214135848e-05;
                      } else {
                        result[0] += -5.9441516159077674e-05;
                      }
                    } else {
                      result[0] += 4.871737825305595e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -5.9441516159077674e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -5.9441516159077674e-05;
                    } else {
                      result[0] += -5.9441516159077674e-05;
                    }
                  } else {
                    result[0] += -5.9441516159077674e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -5.9441516159077674e-05;
                  } else {
                    result[0] += -5.9441516159077674e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -5.9441516159077674e-05;
                        } else {
                          result[0] += -5.9441516159077674e-05;
                        }
                      } else {
                        result[0] += -5.9441516159077674e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -5.9441516159077674e-05;
                          } else {
                            result[0] += -5.9441516159077674e-05;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -5.9441516159077674e-05;
                            } else {
                              result[0] += -5.9441516159077674e-05;
                            }
                          } else {
                            result[0] += -5.9441516159077674e-05;
                          }
                        }
                      } else {
                        result[0] += -5.9441516159077674e-05;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -5.9441516159077674e-05;
                      } else {
                        result[0] += -5.9441516159077674e-05;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -5.9441516159077674e-05;
                      } else {
                        result[0] += -5.9441516159077674e-05;
                      }
                    }
                  }
                } else {
                  result[0] += -5.9441516159077674e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -5.9441516159077674e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -5.9441516159077674e-05;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -5.9441516159077674e-05;
                    } else {
                      result[0] += -5.9441516159077674e-05;
                    }
                  }
                } else {
                  result[0] += -5.9441516159077674e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -5.9441516159077674e-05;
              } else {
                result[0] += 2.925224303025426e-06;
              }
            } else {
              result[0] += -5.9441516159077674e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7472528898492464267) ) ) {
              result[0] += -6.28107667140386e-05;
            } else {
              result[0] += -5.688741371539793e-05;
            }
          } else {
            result[0] += 1.1749986498290878e-06;
          }
        } else {
          result[0] += 5.892548134134519e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4650000000000000244) ) ) {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2050000000000000433) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01874250000000000568) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4795216591959799435) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.469327283602055445) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4292508528894472541) ) ) {
                result[0] += 0.0014618570032494049;
              } else {
                result[0] += -0.0008936607472903876;
              }
            } else {
              result[0] += 0.0008529317524219354;
            }
          } else {
            result[0] += 3.853577294116126e-07;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5986941274482283637) ) ) {
            result[0] += 0.0013571892547582607;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7013523401005025137) ) ) {
              result[0] += -0.0007650371421554067;
            } else {
              result[0] += 0.00019485001104053239;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.000210500000000000048) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1650000000000000355) ) ) {
            result[0] += -0.0009900953345329234;
          } else {
            result[0] += 0.0006550136599373722;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8299222285691966183) ) ) {
            result[0] += 0.0020237356020086947;
          } else {
            result[0] += 0.0004628432763347573;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
        result[0] += 0.004114444924010789;
      } else {
        result[0] += 0.010498317008689343;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -5.6653495390493954e-05;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -5.6653495390493954e-05;
                  } else {
                    result[0] += -5.6653495390493954e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -5.6653495390493954e-05;
                    } else {
                      result[0] += -5.6653495390493954e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -5.6653495390493954e-05;
                    } else {
                      result[0] += -5.6653495390493954e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -5.957871969351943e-05;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
              result[0] += 3.486805673143996e-05;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002091500000000000477) ) ) {
                  result[0] += -5.079587176895077e-05;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01660200000000000217) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01009750000000000057) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004748500000000000117) ) ) {
                        result[0] += -5.6653495390493954e-05;
                      } else {
                        result[0] += -5.494368853815525e-05;
                      }
                    } else {
                      result[0] += -5.6653495390493954e-05;
                    }
                  } else {
                    result[0] += -6.123153920818637e-05;
                  }
                }
              } else {
                result[0] += 4.6432358099852294e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -5.6653495390493954e-05;
                    } else {
                      result[0] += -5.6653495390493954e-05;
                    }
                  } else {
                    result[0] += -5.6653495390493954e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -5.6653495390493954e-05;
                  } else {
                    result[0] += -5.6653495390493954e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -5.6653495390493954e-05;
                        } else {
                          result[0] += -5.6653495390493954e-05;
                        }
                      } else {
                        result[0] += -5.6653495390493954e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -5.6653495390493954e-05;
                          } else {
                            result[0] += -5.6653495390493954e-05;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -5.6653495390493954e-05;
                            } else {
                              result[0] += -5.6653495390493954e-05;
                            }
                          } else {
                            result[0] += -5.6653495390493954e-05;
                          }
                        }
                      } else {
                        result[0] += -5.6653495390493954e-05;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -5.6653495390493954e-05;
                      } else {
                        result[0] += -5.6653495390493954e-05;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -5.6653495390493954e-05;
                      } else {
                        result[0] += -5.6653495390493954e-05;
                      }
                    }
                  }
                } else {
                  result[0] += -5.6653495390493954e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -5.6653495390493954e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -5.6653495390493954e-05;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -5.6653495390493954e-05;
                    } else {
                      result[0] += -5.6653495390493954e-05;
                    }
                  }
                } else {
                  result[0] += -5.6653495390493954e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -5.6653495390493954e-05;
              } else {
                result[0] += 2.7880207685837185e-06;
              }
            } else {
              result[0] += -5.6653495390493954e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7472528898492464267) ) ) {
              result[0] += -5.9864715983758516e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8066186623115578769) ) ) {
                result[0] += -4.7573863824873536e-05;
              } else {
                result[0] += -6.347264489122845e-05;
              }
            }
          } else {
            result[0] += 1.1198869896551721e-06;
          }
        } else {
          result[0] += 5.616166446058484e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4850000000000000422) ) ) {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04215400000000000397) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4795216591959799435) ) ) {
            result[0] += 0.0010413525561506732;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.03500000000000001027) ) ) {
              result[0] += -1.4356115943877267e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8507017292462312197) ) ) {
                result[0] += 0.0001100796056181516;
              } else {
                result[0] += -0.00021521066260772332;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6754021834779359024) ) ) {
            result[0] += 0.002296320300242307;
          } else {
            result[0] += 0.00019666016543683877;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7273815826884423297) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2650000000000000688) ) ) {
              result[0] += -0.0005738904822204261;
            } else {
              result[0] += 0.0017430195494715756;
            }
          } else {
            result[0] += 0.0022467686763993945;
          }
        } else {
          result[0] += 0.0004664816827858004;
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9350000000000001643) ) ) {
        result[0] += 0.0036307959400555465;
      } else {
        result[0] += 0.008948973127335232;
      }
    }
  }
}

