
#include "header.h"

void predict_unit9(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -1.1474037018243422e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.1474037018243422e-06;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -1.1474037018243422e-06;
              } else {
                result[0] += -1.1474037018243422e-06;
              }
            }
          }
        } else {
          result[0] += -8.496673092643728e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -1.1474037018243422e-06;
              } else {
                result[0] += -1.1474037018243422e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -1.1474037018243422e-06;
                  } else {
                    result[0] += -1.1474037018243422e-06;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -1.1474037018243422e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -1.1474037018243422e-06;
                        } else {
                          result[0] += -1.1474037018243422e-06;
                        }
                      } else {
                        result[0] += -1.1474037018243422e-06;
                      }
                    }
                  } else {
                    result[0] += -1.1474037018243422e-06;
                  }
                }
              } else {
                result[0] += -1.1474037018243422e-06;
              }
            }
          } else {
            result[0] += -1.1474037018243422e-06;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -1.1474037018243422e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -1.1474037018243422e-06;
                } else {
                  result[0] += -1.1474037018243422e-06;
                }
              } else {
                result[0] += -1.1474037018243422e-06;
              }
            } else {
              result[0] += -1.1474037018243422e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8450000000000000844) ) ) {
          result[0] += 1.829132391433089e-06;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9250000000000001554) ) ) {
            result[0] += 0.004502198284323288;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3837516359296482826) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6269304705026225166) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3684892717336683554) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03409611752714010457) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006937836693866150477) ) ) {
                      result[0] += -0.00038801021611261223;
                    } else {
                      result[0] += 0.0013557102606881234;
                    }
                  } else {
                    result[0] += -0.0005168784419505064;
                  }
                } else {
                  result[0] += 0.0019811799867816182;
                }
              } else {
                result[0] += -0.0017484261863752403;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08407783631914581002) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05473596564878090848) ) ) {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4635963316561722558) ) ) {
                    result[0] += 0.0010374052497472753;
                  } else {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.378188349821562797) ) ) {
                      result[0] += -0.0012526812309617058;
                    } else {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3329403679585331566) ) ) {
                        result[0] += 0.0015833727261255267;
                      } else {
                        if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.003774417747733249413) ) ) {
                          result[0] += 5.342273730852199e-05;
                        } else {
                          result[0] += 0.0010887900186890606;
                        }
                      }
                    }
                  }
                } else {
                  result[0] += 0.0008602184351920758;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1051257686552766607) ) ) {
                  result[0] += -0.0004717385958684728;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1206324332205917643) ) ) {
                    result[0] += 0.0019198492305739113;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1507499186893259402) ) ) {
                      result[0] += -0.000724877409761007;
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
                        result[0] += 0.0017876171885167474;
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4364163272837385255) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3892782419974109565) ) ) {
                            result[0] += -3.667695962191376e-05;
                          } else {
                            result[0] += -0.0015497011139379057;
                          }
                        } else {
                          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5508018452917812224) ) ) {
                            result[0] += 0.0012437400625634615;
                          } else {
                            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9993516786272610419) ) ) {
                              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8466324982590252013) ) ) {
                                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7733398996305392847) ) ) {
                                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6558660377084782889) ) ) {
                                    result[0] += -0.00012950175048636705;
                                  } else {
                                    result[0] += 0.0011161079507372095;
                                  }
                                } else {
                                  result[0] += -0.00019181691840130223;
                                }
                              } else {
                                result[0] += 0.0010312111411388944;
                              }
                            } else {
                              result[0] += -0.0003206608600352305;
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.000661182101694317;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01085750000000000083) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01021941412521685209) ) ) {
              result[0] += 6.074794144696035e-05;
            } else {
              result[0] += 0.0006451565748170758;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1706267463716274191) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03468100000000001043) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01822956926157560595) ) ) {
                  result[0] += -0.0004853036053090121;
                } else {
                  result[0] += 0.000616781048118961;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05964584249592785187) ) ) {
                  result[0] += -7.446407343952711e-05;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1438325364936231809) ) ) {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.181114681928726734) ) ) {
                      result[0] += 0.0008000633203700815;
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02733191529475900369) ) ) {
                        result[0] += -0.0002798123413065114;
                      } else {
                        result[0] += 0.0010459448862963935;
                      }
                    }
                  } else {
                    result[0] += -0.0005499936963120265;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3346339054385528144) ) ) {
                result[0] += 0.0006964865645125978;
              } else {
                result[0] += 0.0004545361911642274;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -1.1017317047723907e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.1017317047723907e-06;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -1.1017317047723907e-06;
              } else {
                result[0] += -1.1017317047723907e-06;
              }
            }
          }
        } else {
          result[0] += -8.158466036294149e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -1.1017317047723907e-06;
              } else {
                result[0] += -1.1017317047723907e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -1.1017317047723907e-06;
                  } else {
                    result[0] += -1.1017317047723907e-06;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -1.1017317047723907e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -1.1017317047723907e-06;
                        } else {
                          result[0] += -1.1017317047723907e-06;
                        }
                      } else {
                        result[0] += -1.1017317047723907e-06;
                      }
                    }
                  } else {
                    result[0] += -1.1017317047723907e-06;
                  }
                }
              } else {
                result[0] += -1.1017317047723907e-06;
              }
            }
          } else {
            result[0] += -1.1017317047723907e-06;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -1.1017317047723907e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -1.1017317047723907e-06;
                } else {
                  result[0] += -1.1017317047723907e-06;
                }
              } else {
                result[0] += -1.1017317047723907e-06;
              }
            } else {
              result[0] += -1.1017317047723907e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8450000000000000844) ) ) {
          result[0] += 1.7563244258873572e-06;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9250000000000001554) ) ) {
            result[0] += 0.00432298987978182;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2145423861003193655) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5719332634924624292) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1706267463716274191) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3837516359296482826) ) ) {
                    result[0] += -0.0001413194899254223;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5628434130653267031) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5493276582412061071) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5361772370603016258) ) ) {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.51994285276381913) ) ) {
                            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4931942899748744114) ) ) {
                              result[0] += 0.0006666690155091476;
                            } else {
                              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
                                result[0] += -0.0002610690735417771;
                              } else {
                                result[0] += 0.0007785064216079135;
                              }
                            }
                          } else {
                            result[0] += 0.0012956999571538516;
                          }
                        } else {
                          result[0] += -0.000589074657616084;
                        }
                      } else {
                        result[0] += 0.0007834697513256232;
                      }
                    } else {
                      result[0] += -0.0004997027244832242;
                    }
                  }
                } else {
                  result[0] += 0.0013128424950976632;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.590591194899497629) ) ) {
                  result[0] += 0.0014270782781410655;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6059258460552764403) ) ) {
                    result[0] += -0.00013158233390982285;
                  } else {
                    result[0] += 0.0008580789445912918;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5792515097236182742) ) ) {
                result[0] += -0.0033353270828343114;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6116569490452262725) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5985432365577890712) ) ) {
                    result[0] += 0.0008925098419776741;
                  } else {
                    result[0] += -0.0011512693161680038;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9993516786272610419) ) ) {
                    result[0] += 0.0007686688005138368;
                  } else {
                    result[0] += -0.0003397731252234232;
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0006348639828392253;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01085750000000000083) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01021941412521685209) ) ) {
              result[0] += 5.8329891201640605e-05;
            } else {
              result[0] += 0.0006194763463706754;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1706267463716274191) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01881166515770610337) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0149275149599735011) ) ) {
                  result[0] += 0.0006429951806384251;
                } else {
                  result[0] += -0.0014482797434013687;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7342470301758795559) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6077784371608041525) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5829435000502513065) ) ) {
                      result[0] += 0.0004524483745777158;
                    } else {
                      result[0] += -0.0011132024626437453;
                    }
                  } else {
                    result[0] += 0.0006429109991016119;
                  }
                } else {
                  result[0] += -0.0002064551130095005;
                }
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3346339054385528144) ) ) {
                result[0] += 0.0006687631640472111;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2646734959245704566) ) ) {
                  result[0] += -2.6737859926075532e-05;
                } else {
                  result[0] += 0.0006976562934123871;
                }
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -1.0578776653506935e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.0578776653506935e-06;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -1.0578776653506935e-06;
              } else {
                result[0] += -1.0578776653506935e-06;
              }
            }
          }
        } else {
          result[0] += -7.833721191767653e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -1.0578776653506935e-06;
              } else {
                result[0] += -1.0578776653506935e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -1.0578776653506935e-06;
                  } else {
                    result[0] += -1.0578776653506935e-06;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -1.0578776653506935e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -1.0578776653506935e-06;
                        } else {
                          result[0] += -1.0578776653506935e-06;
                        }
                      } else {
                        result[0] += -1.0578776653506935e-06;
                      }
                    }
                  } else {
                    result[0] += -1.0578776653506935e-06;
                  }
                }
              } else {
                result[0] += -1.0578776653506935e-06;
              }
            }
          } else {
            result[0] += -1.0578776653506935e-06;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -1.0578776653506935e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -1.0578776653506935e-06;
                } else {
                  result[0] += -1.0578776653506935e-06;
                }
              } else {
                result[0] += -1.0578776653506935e-06;
              }
            } else {
              result[0] += -1.0578776653506935e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8450000000000000844) ) ) {
          result[0] += 1.6864145555651832e-06;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9550000000000000711) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02796916660693585244) ) ) {
              result[0] += 0.00046703391322870067;
            } else {
              result[0] += 0.0031493327688452482;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3837516359296482826) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6269304705026225166) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3457619648241206378) ) ) {
                  result[0] += -0.00012970603636013625;
                } else {
                  result[0] += 0.0016535763991141095;
                }
              } else {
                result[0] += -0.0016204074740072414;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08407783631914581002) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05473596564878090848) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04014449846134480332) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03350035677887956004) ) ) {
                      result[0] += 0.0004773233464268711;
                    } else {
                      result[0] += 0.0008451478010770588;
                    }
                  } else {
                    result[0] += -0.0005537191521165944;
                  }
                } else {
                  result[0] += 0.0007680750366344619;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1051257686552766607) ) ) {
                  result[0] += -0.0004964593196466528;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1206324332205917643) ) ) {
                    result[0] += 0.0017944745200154572;
                  } else {
                    result[0] += 5.169609755851531e-05;
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0006095934473628979;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01085750000000000083) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01021941412521685209) ) ) {
              result[0] += 5.6008090587986876e-05;
            } else {
              result[0] += 0.0005948183103017553;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1706267463716274191) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.244955337349149066) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6782348568386622478) ) ) {
                  result[0] += 1.9047735911164244e-06;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03603011311338780859) ) ) {
                    result[0] += 7.658790472443113e-05;
                  } else {
                    result[0] += 0.0007335486769925432;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4751828078391960308) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05831812793683335133) ) ) {
                    result[0] += -0.0024147208111799747;
                  } else {
                    result[0] += -0.0004319543766065673;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7211604863065327331) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6077784371608041525) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5829435000502513065) ) ) {
                        result[0] += 0.0004349633629148483;
                      } else {
                        result[0] += -0.0005702896431577148;
                      }
                    } else {
                      result[0] += 0.0006111047961073602;
                    }
                  } else {
                    result[0] += -0.00014051849214435875;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3346339054385528144) ) ) {
                result[0] += 0.0006421432836962477;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2646734959245704566) ) ) {
                  result[0] += -2.5673568902977007e-05;
                } else {
                  result[0] += 0.0006698863323033704;
                }
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -1.0157692204011068e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.0157692204011068e-06;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -1.0157692204011068e-06;
              } else {
                result[0] += -1.0157692204011068e-06;
              }
            }
          }
        } else {
          result[0] += -7.521902700501363e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -1.0157692204011068e-06;
              } else {
                result[0] += -1.0157692204011068e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -1.0157692204011068e-06;
                  } else {
                    result[0] += -1.0157692204011068e-06;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -1.0157692204011068e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -1.0157692204011068e-06;
                        } else {
                          result[0] += -1.0157692204011068e-06;
                        }
                      } else {
                        result[0] += -1.0157692204011068e-06;
                      }
                    }
                  } else {
                    result[0] += -1.0157692204011068e-06;
                  }
                }
              } else {
                result[0] += -1.0157692204011068e-06;
              }
            }
          } else {
            result[0] += -1.0157692204011068e-06;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -1.0157692204011068e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -1.0157692204011068e-06;
                } else {
                  result[0] += -1.0157692204011068e-06;
                }
              } else {
                result[0] += -1.0157692204011068e-06;
              }
            } else {
              result[0] += -1.0157692204011068e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8450000000000000844) ) ) {
          result[0] += 1.6192874228155521e-06;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9250000000000001554) ) ) {
            result[0] += 0.004025556729237939;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2145423861003193655) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.51994285276381913) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1711110322396684202) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3644118032412060892) ) ) {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.9159493641278110276) ) ) {
                      result[0] += 0.0014203849070826093;
                    } else {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7983975536720421262) ) ) {
                        result[0] += -0.0008979071846750045;
                      } else {
                        result[0] += -1.7818377720138037e-06;
                      }
                    }
                  } else {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4601878067544193374) ) ) {
                      result[0] += 0.0009338581166320287;
                    } else {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.378188349821562797) ) ) {
                        result[0] += -0.0011532380421052384;
                      } else {
                        result[0] += 0.0008222109302485758;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06508917425002432033) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03237403661108240877) ) ) {
                      result[0] += -0.0008104394184269526;
                    } else {
                      result[0] += 0.0012887351671721351;
                    }
                  } else {
                    result[0] += -0.0011975219975766305;
                  }
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05473596564878090848) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5719332634924624292) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08407783631914581002) ) ) {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.03941486779484403707) ) ) {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5361772370603016258) ) ) {
                          result[0] += 0.000733046508418885;
                        } else {
                          result[0] += -0.0011717923535767938;
                        }
                      } else {
                        result[0] += 0.0010408740437932514;
                      }
                    } else {
                      result[0] += -0.0015574165342164812;
                    }
                  } else {
                    result[0] += 0.0014871015861706292;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1165587384072143268) ) ) {
                    result[0] += 0.0010443277193975858;
                  } else {
                    result[0] += 0.0001515040709578461;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6116569490452262725) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5792515097236182742) ) ) {
                  result[0] += -0.0032046233170709916;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5985432365577890712) ) ) {
                    result[0] += 0.0008549260597235605;
                  } else {
                    result[0] += -0.001107501194521811;
                  }
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9993516786272610419) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6665289424874373259) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6425364825628142595) ) ) {
                      result[0] += 0.0013280990531535821;
                    } else {
                      result[0] += -0.0002458808352554704;
                    }
                  } else {
                    result[0] += 0.0008067626564957162;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7890731911809046872) ) ) {
                    result[0] += -0.0015238876713824165;
                  } else {
                    result[0] += 0.0004469235990992621;
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0005853287965808063;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01595548253114795548) ) ) {
              result[0] += 0.0002858236254934976;
            } else {
              result[0] += 0.0005579057285259361;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8440161800932387548) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06217080128912850362) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6047319804020101497) ) ) {
                    result[0] += 2.3545897455260927e-05;
                  } else {
                    result[0] += 0.000886847885387597;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08407783631914581002) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02733191529475900369) ) ) {
                      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.0255903056102470966) ) ) {
                        result[0] += 0.0005920245659219975;
                      } else {
                        result[0] += -0.00043872900744566416;
                      }
                    } else {
                      result[0] += 0.0008865328694849362;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.55780239615577909) ) ) {
                      result[0] += -0.0006330164002175539;
                    } else {
                      result[0] += 0.0004033967360924453;
                    }
                  }
                }
              } else {
                result[0] += -0.000506574789105074;
              }
            } else {
              result[0] += 0.0006165829982332707;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -9.753368871553104e-07;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -9.753368871553104e-07;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -9.753368871553104e-07;
              } else {
                result[0] += -9.753368871553104e-07;
              }
            }
          }
        } else {
          result[0] += -7.222496033592285e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -9.753368871553104e-07;
              } else {
                result[0] += -9.753368871553104e-07;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -9.753368871553104e-07;
                  } else {
                    result[0] += -9.753368871553104e-07;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -9.753368871553104e-07;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -9.753368871553104e-07;
                        } else {
                          result[0] += -9.753368871553104e-07;
                        }
                      } else {
                        result[0] += -9.753368871553104e-07;
                      }
                    }
                  } else {
                    result[0] += -9.753368871553104e-07;
                  }
                }
              } else {
                result[0] += -9.753368871553104e-07;
              }
            }
          } else {
            result[0] += -9.753368871553104e-07;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -9.753368871553104e-07;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -9.753368871553104e-07;
                } else {
                  result[0] += -9.753368871553104e-07;
                }
              } else {
                result[0] += -9.753368871553104e-07;
              }
            } else {
              result[0] += -9.753368871553104e-07;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9450000000000000622) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5050000000000001155) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5650000000000000577) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5350000000000001421) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8507017292462312197) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7954292854522614364) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7686690743216081367) ) ) {
                    result[0] += 3.1530910532589066e-06;
                  } else {
                    result[0] += -7.76344156997828e-05;
                  }
                } else {
                  result[0] += 1.0475323316875074e-05;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8841271910804021639) ) ) {
                  result[0] += -5.760564368462006e-05;
                } else {
                  result[0] += 3.2656898570208957e-06;
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4908111093216080412) ) ) {
                result[0] += 0.0013078638053882071;
              } else {
                result[0] += 0.0004038198969134115;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3966785421356783803) ) ) {
              result[0] += 0.00047147774385684514;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7412676365326634764) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4347441410050251753) ) ) {
                  result[0] += -0.0006375954429832103;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4693879269597989734) ) ) {
                    result[0] += 0.0010988724613637693;
                  } else {
                    result[0] += -8.010902187561524e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8327395279648243109) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7983409114572864729) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7536081807788946874) ) ) {
                      result[0] += -0.00023411992650900512;
                    } else {
                      result[0] += -8.006389362635653e-05;
                    }
                  } else {
                    result[0] += -0.0007204171574589121;
                  }
                } else {
                  result[0] += 0.00022068038703359816;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5150000000000001243) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01792322003581395262) ) ) {
              result[0] += 0.0018163117611051966;
            } else {
              result[0] += 0.0008935463134089518;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6959555468592965033) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6334213184170854882) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
                  result[0] += -0.0006811129984201892;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0816878293504414571) ) ) {
                    result[0] += 8.263655141355223e-05;
                  } else {
                    result[0] += 0.00063614606235656;
                  }
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07509423281309261788) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6449783570351760309) ) ) {
                    result[0] += -0.0006456833827664647;
                  } else {
                    result[0] += 5.4673381996393965e-05;
                  }
                } else {
                  result[0] += -0.0015833633792284123;
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7211604863065327331) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01519731488065295157) ) ) {
                  result[0] += 0.00032329772658124326;
                } else {
                  result[0] += 0.0019801612053315133;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002295101748406000225) ) ) {
                  result[0] += 0.0017229109579435682;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07136094095721451369) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7397481077386934833) ) ) {
                      result[0] += -0.0005457694965305154;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.767254320477387064) ) ) {
                        result[0] += 0.0006188121850396582;
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8025985781909549255) ) ) {
                          result[0] += -0.00023433871870886188;
                        } else {
                          result[0] += 0.0002047686892949767;
                        }
                      }
                    }
                  } else {
                    result[0] += 0.0006357457456941487;
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0005620299916097612;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.314196657149456993) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02300100000000000408) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06628065069736611969) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01021941412521685209) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007291314867598450676) ) ) {
                    result[0] += 0.0004742300412714596;
                  } else {
                    result[0] += -0.00013366390806285206;
                  }
                } else {
                  result[0] += 0.0005586413042090131;
                }
              } else {
                result[0] += 0.000505059301498908;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1706267463716274191) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6782348568386622478) ) ) {
                  result[0] += -0.0004659073651947289;
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1828583041203602211) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4734952854020100799) ) ) {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6130861605291061389) ) ) {
                        result[0] += 0.0008939047767283955;
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3931761618090452437) ) ) {
                          result[0] += -0.0010636133536743966;
                        } else {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4405029099497487777) ) ) {
                            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05152559976027410588) ) ) {
                              result[0] += 0.0004724313862488605;
                            } else {
                              result[0] += 0.0009148113559602355;
                            }
                          } else {
                            result[0] += -0.00015798326766310023;
                          }
                        }
                      }
                    } else {
                      result[0] += 0.0007920115213316883;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07509423281309261788) ) ) {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04557577292723340862) ) ) {
                          result[0] += -0.00035698193269212815;
                        } else {
                          result[0] += 0.0008891563817648739;
                        }
                      } else {
                        result[0] += -0.001305078155388023;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07316210697219156789) ) ) {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5400528323115579843) ) ) {
                          result[0] += -0.0006523976913632316;
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5792515097236182742) ) ) {
                            result[0] += 0.0008930780361627035;
                          } else {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6116569490452262725) ) ) {
                              result[0] += -0.0006645234220249297;
                            } else {
                              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6553322322110554099) ) ) {
                                result[0] += 0.0007426680703947604;
                              } else {
                                result[0] += -0.0004163324097501232;
                              }
                            }
                          }
                        }
                      } else {
                        result[0] += 0.0005523680608306221;
                      }
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3346339054385528144) ) ) {
                  result[0] += 0.0005920401308598952;
                } else {
                  result[0] += 0.0004798085166701306;
                }
              }
            }
          } else {
            result[0] += -0.000632737687988157;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -9.365139485819114e-07;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -9.365139485819114e-07;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -9.365139485819114e-07;
              } else {
                result[0] += -9.365139485819114e-07;
              }
            }
          }
        } else {
          result[0] += -6.935007142777762e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -9.365139485819114e-07;
              } else {
                result[0] += -9.365139485819114e-07;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -9.365139485819114e-07;
                  } else {
                    result[0] += -9.365139485819114e-07;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -9.365139485819114e-07;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -9.365139485819114e-07;
                        } else {
                          result[0] += -9.365139485819114e-07;
                        }
                      } else {
                        result[0] += -9.365139485819114e-07;
                      }
                    }
                  } else {
                    result[0] += -9.365139485819114e-07;
                  }
                }
              } else {
                result[0] += -9.365139485819114e-07;
              }
            }
          } else {
            result[0] += -9.365139485819114e-07;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -9.365139485819114e-07;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -9.365139485819114e-07;
                } else {
                  result[0] += -9.365139485819114e-07;
                }
              } else {
                result[0] += -9.365139485819114e-07;
              }
            } else {
              result[0] += -9.365139485819114e-07;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8450000000000000844) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03500000000000001027) ) ) {
            result[0] += -2.941678804795975e-06;
          } else {
            result[0] += 1.3219278682960648e-05;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05473596564878090848) ) ) {
              result[0] += 0.00032039192586486704;
            } else {
              result[0] += 0.001975543471053759;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07316210697219156789) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725302343969849939) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003406870502861350427) ) ) {
                    result[0] += -0.0008770867086342372;
                  } else {
                    result[0] += 0.00047770358878698033;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4832433377889447379) ) ) {
                    result[0] += -0.001293122784268703;
                  } else {
                    result[0] += 3.560904516644093e-06;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021562361187840079) ) ) {
                  result[0] += -0.0013623479099515534;
                } else {
                  result[0] += 0.00020786094437432744;
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5361772370603016258) ) ) {
                result[0] += 0.0008457235756055883;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5472997959798996392) ) ) {
                  result[0] += -0.0012814312438287287;
                } else {
                  result[0] += 0.0003205062384671537;
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0005396585873001023;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03468100000000001043) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0173600348455768029) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.0141436144428988015) ) ) {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4000638056452025526) ) ) {
                    result[0] += -4.5742536539092635e-06;
                  } else {
                    result[0] += 0.0016184304725736717;
                  }
                } else {
                  result[0] += -0.000815482395488449;
                }
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2302999793555680907) ) ) {
                  result[0] += 0.0005842892783705793;
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                    result[0] += -0.0001705378912583387;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.020650504707780553) ) ) {
                      result[0] += 0.0005718514423817109;
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1643367459977091716) ) ) {
                        result[0] += 0.0001561439230542979;
                      } else {
                        result[0] += 0.00045019778116297935;
                      }
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05964584249592785187) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4734952854020100799) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3725635588693467781) ) ) {
                    result[0] += 0.0005249216555911489;
                  } else {
                    result[0] += -0.0021121571006732917;
                  }
                } else {
                  result[0] += 0.00032151787874257204;
                }
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6782348568386622478) ) ) {
                    result[0] += -0.00013161995120517742;
                  } else {
                    result[0] += 0.0005723559798959649;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5072261056783921029) ) ) {
                    result[0] += -0.0005793199406483049;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7149244603266332598) ) ) {
                      result[0] += 0.0005684741836102238;
                    } else {
                      result[0] += -0.00018642194536992252;
                    }
                  }
                }
              }
            }
          } else {
            result[0] += 0.0005684741836102238;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -8.992363432972698e-07;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -8.992363432972698e-07;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -8.992363432972698e-07;
              } else {
                result[0] += -8.992363432972698e-07;
              }
            }
          }
        } else {
          result[0] += -6.658961645210857e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -8.992363432972698e-07;
              } else {
                result[0] += -8.992363432972698e-07;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -8.992363432972698e-07;
                  } else {
                    result[0] += -8.992363432972698e-07;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -8.992363432972698e-07;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -8.992363432972698e-07;
                        } else {
                          result[0] += -8.992363432972698e-07;
                        }
                      } else {
                        result[0] += -8.992363432972698e-07;
                      }
                    }
                  } else {
                    result[0] += -8.992363432972698e-07;
                  }
                }
              } else {
                result[0] += -8.992363432972698e-07;
              }
            }
          } else {
            result[0] += -8.992363432972698e-07;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -8.992363432972698e-07;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -8.992363432972698e-07;
                } else {
                  result[0] += -8.992363432972698e-07;
                }
              } else {
                result[0] += -8.992363432972698e-07;
              }
            } else {
              result[0] += -8.992363432972698e-07;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8050000000000001599) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3115605993075549196) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1088700000000000084) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2888738239382729889) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2739990068871500095) ) ) {
                  result[0] += 8.892650265873351e-06;
                } else {
                  result[0] += -0.0005447394063725987;
                }
              } else {
                result[0] += 0.0004758223118996605;
              }
            } else {
              result[0] += 0.000735885417749255;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3665106630729573767) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6059258460552764403) ) ) {
                result[0] += -5.051107183562008e-05;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6161319161557790025) ) ) {
                  result[0] += -0.0013629615772787563;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6532207681155780543) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6299505656030152112) ) ) {
                      result[0] += -0.0002665191296012284;
                    } else {
                      result[0] += 0.0003152481312771799;
                    }
                  } else {
                    result[0] += -0.00020406654322598056;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3966559369710560001) ) ) {
                result[0] += 0.00018905211591449382;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4287309711685468594) ) ) {
                  result[0] += -0.00013156249787555136;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                    result[0] += 4.062173469101326e-05;
                  } else {
                    result[0] += -2.151336919016901e-06;
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005473500000000000067) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006937836693866150477) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5745673188442211865) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4389499174623116007) ) ) {
                  result[0] += 0.00041331210666911884;
                } else {
                  result[0] += -0.0009943609376261004;
                }
              } else {
                result[0] += 0.0008443650735657716;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05964584249592785187) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001464500000000000307) ) ) {
                  result[0] += 0.001527362689940708;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004749500000000001117) ) ) {
                    result[0] += 0.0005315070077478828;
                  } else {
                    result[0] += -0.0004370641312617564;
                  }
                }
              } else {
                result[0] += 0.0009091158496609336;
              }
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03350035677887956004) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6647073645226131422) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6002102120603015623) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05720850000000000934) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5455059598241206453) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4931942899748744114) ) ) {
                        result[0] += 0.00020364312402885307;
                      } else {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009152500000000002647) ) ) {
                          result[0] += -0.0017013261374799976;
                        } else {
                          result[0] += -0.00023901739062550008;
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5701775282412061552) ) ) {
                        result[0] += 0.0028347164358407174;
                      } else {
                        result[0] += 0.0008360539383295635;
                      }
                    }
                  } else {
                    result[0] += -0.00042879042710461515;
                  }
                } else {
                  result[0] += -0.0007488604076043684;
                }
              } else {
                result[0] += 0.001165549461371508;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4093335132160804135) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02120250000000000259) ) ) {
                  result[0] += 0.0008311624746649194;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05439750000000000835) ) ) {
                    result[0] += -0.0012648437575222445;
                  } else {
                    result[0] += -0.00026375870789900694;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0366913419685883091) ) ) {
                  result[0] += 0.0018838423160278748;
                } else {
                  result[0] += 0.00044195819805947415;
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0005181776687977114;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01595548253114795548) ) ) {
              result[0] += 0.00018879764070705766;
            } else {
              result[0] += 0.0004906996265624837;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1706267463716274191) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7211604863065327331) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6077784371608041525) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5792515097236182742) ) ) {
                    result[0] += 0.000311075529703038;
                  } else {
                    result[0] += -0.0004798335130188639;
                  }
                } else {
                  result[0] += 0.0006858112367491421;
                }
              } else {
                result[0] += -0.00021760966363956578;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
                result[0] += 0.0004997166992648877;
              } else {
                result[0] += 0.0005458462705255109;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -8.634425598583803e-07;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -8.634425598583803e-07;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -8.634425598583803e-07;
              } else {
                result[0] += -8.634425598583803e-07;
              }
            }
          }
        } else {
          result[0] += -6.393904040685463e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -8.634425598583803e-07;
              } else {
                result[0] += -8.634425598583803e-07;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -8.634425598583803e-07;
                  } else {
                    result[0] += -8.634425598583803e-07;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -8.634425598583803e-07;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -8.634425598583803e-07;
                        } else {
                          result[0] += -8.634425598583803e-07;
                        }
                      } else {
                        result[0] += -8.634425598583803e-07;
                      }
                    }
                  } else {
                    result[0] += -8.634425598583803e-07;
                  }
                }
              } else {
                result[0] += -8.634425598583803e-07;
              }
            }
          } else {
            result[0] += -8.634425598583803e-07;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -8.634425598583803e-07;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -8.634425598583803e-07;
                } else {
                  result[0] += -8.634425598583803e-07;
                }
              } else {
                result[0] += -8.634425598583803e-07;
              }
            } else {
              result[0] += -8.634425598583803e-07;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.146109394227906586) ) ) {
            result[0] += 0.0006547410469112364;
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7572008430306190752) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.8537219630417757221) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
                  result[0] += -0.00026491459346113537;
                } else {
                  result[0] += 0.00037484077040408025;
                }
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7983975536720421262) ) ) {
                  result[0] += -0.001190510413868141;
                } else {
                  result[0] += -9.226310838409443e-05;
                }
              }
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6130861605291061389) ) ) {
                result[0] += 0.0004603550757175377;
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.469327283602055445) ) ) {
                  if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4702452205161443133) ) ) {
                    result[0] += -2.287814804536102e-05;
                  } else {
                    result[0] += -0.00021362718031914452;
                  }
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4000638056452025526) ) ) {
                    if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4026472078210281969) ) ) {
                      result[0] += 0.00034687601682902437;
                    } else {
                      result[0] += 0.0028583266260418156;
                    }
                  } else {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.378188349821562797) ) ) {
                      result[0] += -0.0012536536600343791;
                    } else {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3750409390474713223) ) ) {
                        result[0] += 0.003310475242899242;
                      } else {
                        result[0] += 1.9390653377495743e-06;
                      }
                    }
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005473500000000000067) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04477003072051350535) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002998483312272000063) ) ) {
                result[0] += -0.0002325339644916838;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02366047096071570086) ) ) {
                  result[0] += 0.0010153468332972542;
                } else {
                  result[0] += -3.974861083133246e-05;
                }
              }
            } else {
              result[0] += 0.0008360577923128481;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05473596564878090848) ) ) {
                result[0] += 0.0006806080728646171;
              } else {
                result[0] += 0.001939252327141903;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6647073645226131422) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6425364825628142595) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6208328749497488142) ) ) {
                    result[0] += -7.093085128002294e-05;
                  } else {
                    result[0] += 0.0009508018764357831;
                  }
                } else {
                  result[0] += -0.0006169029240733091;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7890731911809046872) ) ) {
                  result[0] += 0.000544651247310903;
                } else {
                  result[0] += -0.0007947287726359439;
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0004975517906311283;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01595548253114795548) ) ) {
              result[0] += 0.0001812826176370817;
            } else {
              result[0] += 0.00047116750211306736;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3057749246864051029) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7211604863065327331) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06081637682680595541) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6047319804020101497) ) ) {
                    result[0] += -3.6427263517769523e-06;
                  } else {
                    result[0] += 0.0007758631277351307;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4405029099497487777) ) ) {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6782348568386622478) ) ) {
                      result[0] += 0.0006219785184570425;
                    } else {
                      result[0] += 0.0005870142487828842;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4693077114572864472) ) ) {
                      result[0] += -0.0002377160986864711;
                    } else {
                      result[0] += 0.0005017688231226762;
                    }
                  }
                }
              } else {
                result[0] += -0.0002089477882242943;
              }
            } else {
              result[0] += 0.0005241190534888006;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -8.29073535263392e-07;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -8.29073535263392e-07;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -8.29073535263392e-07;
              } else {
                result[0] += -8.29073535263392e-07;
              }
            }
          }
        } else {
          result[0] += -6.139396960019487e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -8.29073535263392e-07;
              } else {
                result[0] += -8.29073535263392e-07;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -8.29073535263392e-07;
                  } else {
                    result[0] += -8.29073535263392e-07;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -8.29073535263392e-07;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -8.29073535263392e-07;
                        } else {
                          result[0] += -8.29073535263392e-07;
                        }
                      } else {
                        result[0] += -8.29073535263392e-07;
                      }
                    }
                  } else {
                    result[0] += -8.29073535263392e-07;
                  }
                }
              } else {
                result[0] += -8.29073535263392e-07;
              }
            }
          } else {
            result[0] += -8.29073535263392e-07;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -8.29073535263392e-07;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -8.29073535263392e-07;
                } else {
                  result[0] += -8.29073535263392e-07;
                }
              } else {
                result[0] += -8.29073535263392e-07;
              }
            } else {
              result[0] += -8.29073535263392e-07;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.146109394227906586) ) ) {
            result[0] += 0.0006286793119553748;
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7572008430306190752) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.8537219630417757221) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
                  result[0] += -0.0002543697621063664;
                } else {
                  result[0] += 0.00035992036659709736;
                }
              } else {
                result[0] += -0.000489735071792323;
              }
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6269304705026225166) ) ) {
                result[0] += 0.00045515454143394476;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01287800000000000229) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01172600000000000205) ) ) {
                    result[0] += -6.183367513719606e-07;
                  } else {
                    result[0] += -0.0005226565414433803;
                  }
                } else {
                  result[0] += 3.819374338352597e-05;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005473500000000000067) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05473596564878090848) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002998483312272000063) ) ) {
                result[0] += -0.00022327803257874467;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04014449846134480332) ) ) {
                  result[0] += 0.0007459834335313437;
                } else {
                  result[0] += -0.00010358024151194463;
                }
              }
            } else {
              result[0] += 0.0008297259155317208;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05473596564878090848) ) ) {
                result[0] += 0.0006535167101228167;
              } else {
                result[0] += 0.0018620610766453337;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1706267463716274191) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05964584249592785187) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0526089167981486569) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04653956279752540642) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01397330054109465099) ) ) {
                        result[0] += -0.000502049010685489;
                      } else {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0170586839503055511) ) ) {
                          result[0] += 0.0007778906526846854;
                        } else {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03350035677887956004) ) ) {
                            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03028287126648195396) ) ) {
                              result[0] += 3.472805364338509e-05;
                            } else {
                              result[0] += -0.001431681862756376;
                            }
                          } else {
                            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03795623917694670307) ) ) {
                              result[0] += 0.0012261740948207645;
                            } else {
                              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0416474308606116575) ) ) {
                                result[0] += -0.0001567562938441066;
                              } else {
                                result[0] += 0.0013229850406902526;
                              }
                            }
                          }
                        }
                      }
                    } else {
                      result[0] += -0.0005044543913651095;
                    }
                  } else {
                    result[0] += 0.0010224953597510941;
                  }
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06508917425002432033) ) ) {
                    result[0] += -0.0019300048308382783;
                  } else {
                    result[0] += -9.040166205032671e-05;
                  }
                }
              } else {
                result[0] += 0.0007106619092326437;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.00047774691822330146;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01021941412521685209) ) ) {
              result[0] += 5.355986364665296e-05;
            } else {
              result[0] += 0.0004745311539807793;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1706267463716274191) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0366913419685883091) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4129968667336683663) ) ) {
                  result[0] += -0.0012913590347246135;
                } else {
                  result[0] += 0.00024008259774988618;
                }
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.181114681928726734) ) ) {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6782348568386622478) ) ) {
                    result[0] += -0.00011982820949588332;
                  } else {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6269304705026225166) ) ) {
                      result[0] += 0.0007997926429627122;
                    } else {
                      result[0] += 0.0005062086567702873;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5424744603768845153) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.120319831241355063) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06217080128912850362) ) ) {
                        result[0] += -0.00033828178638052435;
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08951570884523896154) ) ) {
                          result[0] += 0.0009174874731380454;
                        } else {
                          result[0] += -0.00025580360574562985;
                        }
                      }
                    } else {
                      result[0] += -0.0006408642085192954;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5701775282412061552) ) ) {
                      result[0] += 0.0008625753279233473;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6116569490452262725) ) ) {
                        result[0] += -0.0002442540151115992;
                      } else {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7190147863316583843) ) ) {
                          result[0] += 0.0006556731860113983;
                        } else {
                          result[0] += -0.00012831758175162568;
                        }
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.01537695356895864805) ) ) {
                  result[0] += 0.0005049383382996242;
                } else {
                  result[0] += 0.00026580391086674206;
                }
              } else {
                result[0] += 0.0005032566806136281;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -7.960725574922767e-07;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -7.960725574922767e-07;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -7.960725574922767e-07;
              } else {
                result[0] += -7.960725574922767e-07;
              }
            }
          }
        } else {
          result[0] += -5.895020443355873e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -7.960725574922767e-07;
              } else {
                result[0] += -7.960725574922767e-07;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -7.960725574922767e-07;
                  } else {
                    result[0] += -7.960725574922767e-07;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -7.960725574922767e-07;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -7.960725574922767e-07;
                        } else {
                          result[0] += -7.960725574922767e-07;
                        }
                      } else {
                        result[0] += -7.960725574922767e-07;
                      }
                    }
                  } else {
                    result[0] += -7.960725574922767e-07;
                  }
                }
              } else {
                result[0] += -7.960725574922767e-07;
              }
            }
          } else {
            result[0] += -7.960725574922767e-07;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -7.960725574922767e-07;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -7.960725574922767e-07;
                } else {
                  result[0] += -7.960725574922767e-07;
                }
              } else {
                result[0] += -7.960725574922767e-07;
              }
            } else {
              result[0] += -7.960725574922767e-07;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8050000000000001599) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3115605993075549196) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2888738239382729889) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2739990068871500095) ) ) {
                result[0] += 1.7949922260322592e-05;
              } else {
                result[0] += -0.0005231088188031437;
              }
            } else {
              result[0] += 0.00046819577724230407;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3561404984221285264) ) ) {
              result[0] += -0.00019668768101232476;
            } else {
              result[0] += -1.1466590576902152e-06;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005479696504671500816) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
              result[0] += -0.0015294017448061364;
            } else {
              result[0] += 0.00026952162706841596;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001939500000000000252) ) ) {
              result[0] += 0.001032351968815502;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02884459794480960168) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.008306500000000001382) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01376440091032050082) ) ) {
                      result[0] += 0.003079621374275787;
                    } else {
                      result[0] += -1.346000355529378e-05;
                    }
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01262450000000000204) ) ) {
                      result[0] += -0.0008673909504215122;
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05574000000000000482) ) ) {
                        result[0] += 0.0004991863779243997;
                      } else {
                        result[0] += -0.0009295928963731705;
                      }
                    }
                  }
                } else {
                  result[0] += 0.0015532564967804378;
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02251500000000000376) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07136094095721451369) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0110643527143887508) ) ) {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00922340305469475201) ) ) {
                        result[0] += 4.498317802682445e-05;
                      } else {
                        result[0] += -0.00047304337534908783;
                      }
                    } else {
                      result[0] += 0.00037104859200825624;
                    }
                  } else {
                    result[0] += 0.0006626790258581095;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4093335132160804135) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05964584249592785187) ) ) {
                      result[0] += -0.00017519816417018631;
                    } else {
                      result[0] += -0.0021460012150748635;
                    }
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04160250000000000753) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03160800000000000415) ) ) {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02563650000000000304) ) ) {
                          result[0] += -0.0002604366394419196;
                        } else {
                          result[0] += 0.00048521933224128944;
                        }
                      } else {
                        result[0] += -0.0014814244088049275;
                      }
                    } else {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05574000000000000482) ) ) {
                        result[0] += 0.0018482545517461593;
                      } else {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.09229200000000001292) ) ) {
                          result[0] += -0.00033174302658930857;
                        } else {
                          result[0] += 0.00040370988932006223;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2302999793555680907) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
            result[0] += 0.00045873037173144144;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01238050000000000088) ) ) {
              result[0] += 0.0005010771124141043;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2428155000000000174) ) ) {
                result[0] += 0.0004605368524221138;
              } else {
                result[0] += 0.0004887212432696297;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4693879269597989734) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.110653077273335107) ) ) {
              result[0] += -0.002099338659542297;
            } else {
              result[0] += 0.00037869842985696275;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3830383354773237436) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5424744603768845153) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5353359946984925788) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2271190000000000431) ) ) {
                      result[0] += 0.0004848471802046548;
                    } else {
                      result[0] += -0.0002845805420434719;
                    }
                  } else {
                    result[0] += -0.000417040620632405;
                  }
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0102480000000000019) ) ) {
                    result[0] += 0.0003991726090035394;
                  } else {
                    result[0] += 0.0005191315977179582;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6047319804020101497) ) ) {
                  result[0] += -0.0024395465811902664;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8440161800932387548) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6784611311055277483) ) ) {
                      result[0] += 0.0002850049044821286;
                    } else {
                      result[0] += 0.0005585875227901578;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
                      result[0] += -0.0006566233822116288;
                    } else {
                      result[0] += 0.0005853147538397484;
                    }
                  }
                }
              }
            } else {
              result[0] += 0.0004820453250666427;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -7.643851719268319e-07;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -7.643851719268319e-07;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -7.643851719268319e-07;
              } else {
                result[0] += -7.643851719268319e-07;
              }
            }
          }
        } else {
          result[0] += -5.660371247190598e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -7.643851719268319e-07;
              } else {
                result[0] += -7.643851719268319e-07;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -7.643851719268319e-07;
                  } else {
                    result[0] += -7.643851719268319e-07;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -7.643851719268319e-07;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -7.643851719268319e-07;
                        } else {
                          result[0] += -7.643851719268319e-07;
                        }
                      } else {
                        result[0] += -7.643851719268319e-07;
                      }
                    }
                  } else {
                    result[0] += -7.643851719268319e-07;
                  }
                }
              } else {
                result[0] += -7.643851719268319e-07;
              }
            }
          } else {
            result[0] += -7.643851719268319e-07;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -7.643851719268319e-07;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -7.643851719268319e-07;
                } else {
                  result[0] += -7.643851719268319e-07;
                }
              } else {
                result[0] += -7.643851719268319e-07;
              }
            } else {
              result[0] += -7.643851719268319e-07;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03500000000000001027) ) ) {
            result[0] += -2.9453594029223017e-06;
          } else {
            result[0] += 1.13024786429144e-05;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002710500000000000669) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002998483312272000063) ) ) {
              result[0] += -0.00018241927672254268;
            } else {
              result[0] += 0.0008297514476193953;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05473596564878090848) ) ) {
                result[0] += 0.00060902802490539;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02162700000000000386) ) ) {
                  result[0] += 0.0007530540617038696;
                } else {
                  result[0] += 0.001970340518646716;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03160800000000000415) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01397330054109465099) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5748180127889448432) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007787546829340650199) ) ) {
                      result[0] += 2.420557974031896e-05;
                    } else {
                      result[0] += -0.0015153076327676757;
                    }
                  } else {
                    result[0] += 0.0013742474034446686;
                  }
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003361500000000000338) ) ) {
                    result[0] += -0.0005492607074602394;
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005372500000000001406) ) ) {
                      result[0] += 0.0006446721591155831;
                    } else {
                      result[0] += 0.0003528390681814489;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4093335132160804135) ) ) {
                  result[0] += -0.0007330545711968369;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04160250000000000753) ) ) {
                    result[0] += -0.0013088919229863167;
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05574000000000000482) ) ) {
                      result[0] += 0.0018751735078305395;
                    } else {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.09229200000000001292) ) ) {
                        result[0] += -0.0004711698499722724;
                      } else {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06217080128912850362) ) ) {
                          result[0] += 0.001569019625978982;
                        } else {
                          result[0] += -0.00028543786376793965;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.00044047077212230234;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01085750000000000083) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01021941412521685209) ) ) {
              result[0] += 9.575994735881104e-05;
            } else {
              result[0] += 0.0004281404484663043;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1165587384072143268) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05701962466675345592) ) ) {
                  result[0] += 0.00023336427965192663;
                } else {
                  result[0] += 0.00044485704414207617;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1738383111593791719) ) ) {
                  result[0] += -0.00038923906283713387;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3251271839107726103) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2533229942273665936) ) ) {
                      result[0] += 0.00025041889941310907;
                    } else {
                      result[0] += 0.000618495640776468;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4364163272837385255) ) ) {
                      result[0] += -0.0004475817076901883;
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8440161800932387548) ) ) {
                        result[0] += 0.0003475191759810149;
                      } else {
                        result[0] += -9.771938963142255e-05;
                      }
                    }
                  }
                }
              }
            } else {
              result[0] += 0.00046403708403470773;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -7.339590914956025e-07;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -7.339590914956025e-07;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -7.339590914956025e-07;
              } else {
                result[0] += -7.339590914956025e-07;
              }
            }
          }
        } else {
          result[0] += -5.435062178984178e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -7.339590914956025e-07;
              } else {
                result[0] += -7.339590914956025e-07;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -7.339590914956025e-07;
                  } else {
                    result[0] += -7.339590914956025e-07;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -7.339590914956025e-07;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -7.339590914956025e-07;
                        } else {
                          result[0] += -7.339590914956025e-07;
                        }
                      } else {
                        result[0] += -7.339590914956025e-07;
                      }
                    }
                  } else {
                    result[0] += -7.339590914956025e-07;
                  }
                }
              } else {
                result[0] += -7.339590914956025e-07;
              }
            }
          } else {
            result[0] += -7.339590914956025e-07;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -7.339590914956025e-07;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -7.339590914956025e-07;
                } else {
                  result[0] += -7.339590914956025e-07;
                }
              } else {
                result[0] += -7.339590914956025e-07;
              }
            } else {
              result[0] += -7.339590914956025e-07;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03500000000000001027) ) ) {
            result[0] += -2.8281204174167363e-06;
          } else {
            result[0] += 1.085258749262587e-05;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005479696504671500816) ) ) {
              result[0] += -0.0009692555451128179;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05473596564878090848) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01170971943545395279) ) ) {
                  result[0] += 0.0031576697253395203;
                } else {
                  result[0] += 0.0002616742715642714;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09341808925382111273) ) ) {
                  result[0] += 0.0018708659840702769;
                } else {
                  result[0] += 0.0010121225238466742;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8466324982590252013) ) ) {
                result[0] += 0.00010354569752283536;
              } else {
                result[0] += 0.0007385035583900323;
              }
            } else {
              result[0] += -0.0007752962536393786;
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0004229379893939097;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01085750000000000083) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01021941412521685209) ) ) {
              result[0] += 9.194825664654369e-05;
            } else {
              result[0] += 0.0004110984698940869;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05701962466675345592) ) ) {
                result[0] += 0.0001250098933193295;
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.181114681928726734) ) ) {
                  result[0] += 0.0004515604909357834;
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1126213758155867467) ) ) {
                    result[0] += -0.00015656840822660253;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08407783631914581002) ) ) {
                      result[0] += 0.0004475192645382013;
                    } else {
                      result[0] += 0.0001589150425342745;
                    }
                  }
                }
              }
            } else {
              result[0] += 0.00044556625262608124;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -7.047441103954526e-07;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -7.047441103954526e-07;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -7.047441103954526e-07;
              } else {
                result[0] += -7.047441103954526e-07;
              }
            }
          }
        } else {
          result[0] += -5.218721458258719e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -7.047441103954526e-07;
              } else {
                result[0] += -7.047441103954526e-07;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -7.047441103954526e-07;
                  } else {
                    result[0] += -7.047441103954526e-07;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -7.047441103954526e-07;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -7.047441103954526e-07;
                        } else {
                          result[0] += -7.047441103954526e-07;
                        }
                      } else {
                        result[0] += -7.047441103954526e-07;
                      }
                    }
                  } else {
                    result[0] += -7.047441103954526e-07;
                  }
                }
              } else {
                result[0] += -7.047441103954526e-07;
              }
            }
          } else {
            result[0] += -7.047441103954526e-07;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -7.047441103954526e-07;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -7.047441103954526e-07;
                } else {
                  result[0] += -7.047441103954526e-07;
                }
              } else {
                result[0] += -7.047441103954526e-07;
              }
            } else {
              result[0] += -7.047441103954526e-07;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.115000000000000005) ) ) {
            result[0] += -3.1756097417491437e-06;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.310012234630710122e-06) ) ) {
              result[0] += -8.437094600275787e-05;
            } else {
              result[0] += 3.5575470440759425e-05;
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005479696504671500816) ) ) {
              result[0] += -0.0009306746722006974;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05473596564878090848) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01170971943545395279) ) ) {
                  result[0] += 0.0030319798028149198;
                } else {
                  result[0] += 0.00025125842007237285;
                }
              } else {
                result[0] += 0.0015750711615133142;
              }
            }
          } else {
            result[0] += 0.00010268933758740145;
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0004061030928583295;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01085750000000000083) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01021941412521685209) ) ) {
              result[0] += 8.828828893002549e-05;
            } else {
              result[0] += 0.0003947348412294672;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1706267463716274191) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08407783631914581002) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02733191529475900369) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05701962466675345592) ) ) {
                    result[0] += 1.5662738648000847e-05;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1513805188710139749) ) ) {
                      result[0] += 0.00041530778420030025;
                    } else {
                      result[0] += -9.711280943132005e-05;
                    }
                  }
                } else {
                  result[0] += 0.000761145136466036;
                }
              } else {
                result[0] += 2.977648060042761e-05;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.01537695356895864805) ) ) {
                  result[0] += 0.0004297059190712275;
                } else {
                  result[0] += 0.0001869321225245467;
                }
              } else {
                result[0] += 0.00042783064610500264;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -6.766920212474182e-07;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -6.766920212474182e-07;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -6.766920212474182e-07;
              } else {
                result[0] += -6.766920212474182e-07;
              }
            }
          }
        } else {
          result[0] += -5.0109921031262757e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -6.766920212474182e-07;
              } else {
                result[0] += -6.766920212474182e-07;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -6.766920212474182e-07;
                  } else {
                    result[0] += -6.766920212474182e-07;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -6.766920212474182e-07;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -6.766920212474182e-07;
                        } else {
                          result[0] += -6.766920212474182e-07;
                        }
                      } else {
                        result[0] += -6.766920212474182e-07;
                      }
                    }
                  } else {
                    result[0] += -6.766920212474182e-07;
                  }
                }
              } else {
                result[0] += -6.766920212474182e-07;
              }
            }
          } else {
            result[0] += -6.766920212474182e-07;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -6.766920212474182e-07;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -6.766920212474182e-07;
                } else {
                  result[0] += -6.766920212474182e-07;
                }
              } else {
                result[0] += -6.766920212474182e-07;
              }
            } else {
              result[0] += -6.766920212474182e-07;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.115000000000000005) ) ) {
            result[0] += -3.0492057232396016e-06;
          } else {
            result[0] += 2.358252333842417e-05;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005479696504671500816) ) ) {
              result[0] += -0.0008936294972396172;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05473596564878090848) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01170971943545395279) ) ) {
                  result[0] += 0.0029112929230396814;
                } else {
                  result[0] += 0.00024125716785174963;
                }
              } else {
                result[0] += 0.0015123760130395262;
              }
            }
          } else {
            result[0] += 9.860182495684154e-05;
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0003899383034033834;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01085750000000000083) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01021941412521685209) ) ) {
              result[0] += 8.477400492926507e-05;
            } else {
              result[0] += 0.00037902256099517096;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05701962466675345592) ) ) {
                result[0] += 0.00010457363803016478;
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4133512684738382403) ) ) {
                  result[0] += 0.00043511363590696195;
                } else {
                  result[0] += 0.00020448066444097462;
                }
              }
            } else {
              result[0] += 0.0004108009991058056;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -6.497565355501421e-07;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -6.497565355501421e-07;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -6.497565355501421e-07;
              } else {
                result[0] += -6.497565355501421e-07;
              }
            }
          }
        } else {
          result[0] += -4.811531341236236e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -6.497565355501421e-07;
              } else {
                result[0] += -6.497565355501421e-07;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -6.497565355501421e-07;
                  } else {
                    result[0] += -6.497565355501421e-07;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -6.497565355501421e-07;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -6.497565355501421e-07;
                        } else {
                          result[0] += -6.497565355501421e-07;
                        }
                      } else {
                        result[0] += -6.497565355501421e-07;
                      }
                    }
                  } else {
                    result[0] += -6.497565355501421e-07;
                  }
                }
              } else {
                result[0] += -6.497565355501421e-07;
              }
            }
          } else {
            result[0] += -6.497565355501421e-07;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -6.497565355501421e-07;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -6.497565355501421e-07;
                } else {
                  result[0] += -6.497565355501421e-07;
                }
              } else {
                result[0] += -6.497565355501421e-07;
              }
            } else {
              result[0] += -6.497565355501421e-07;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
          result[0] += 6.515478710388367e-07;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005479696504671500816) ) ) {
              result[0] += -0.0008580588923177658;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05473596564878090848) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01170971943545395279) ) ) {
                  result[0] += 0.0027954099416731175;
                } else {
                  result[0] += 0.00023165401192557752;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1643367459977091716) ) ) {
                  result[0] += 0.0016388088158834381;
                } else {
                  result[0] += 0.0007331665378168553;
                }
              }
            }
          } else {
            result[0] += 9.467701431557913e-05;
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0003744169476546034;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01085750000000000083) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01021941412521685209) ) ) {
              result[0] += 8.139960575567515e-05;
            } else {
              result[0] += 0.00036393570249813775;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7211604863065327331) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05701962466675345592) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5515127872864322711) ) ) {
                    result[0] += -4.539933134227401e-05;
                  } else {
                    result[0] += 0.0006346615364253777;
                  }
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4133512684738382403) ) ) {
                    result[0] += 0.00041779409208397204;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4693077114572864472) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4419864859045226635) ) ) {
                        result[0] += 0.00010360504587727151;
                      } else {
                        result[0] += -0.00028720955571401503;
                      }
                    } else {
                      result[0] += 0.0003860343833244315;
                    }
                  }
                }
              } else {
                result[0] += -9.328259779185124e-05;
              }
            } else {
              result[0] += 0.00039444921116031656;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -6.238932072996329e-07;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -6.238932072996329e-07;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -6.238932072996329e-07;
              } else {
                result[0] += -6.238932072996329e-07;
              }
            }
          }
        } else {
          result[0] += -4.620010044169726e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -6.238932072996329e-07;
              } else {
                result[0] += -6.238932072996329e-07;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -6.238932072996329e-07;
                  } else {
                    result[0] += -6.238932072996329e-07;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -6.238932072996329e-07;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -6.238932072996329e-07;
                        } else {
                          result[0] += -6.238932072996329e-07;
                        }
                      } else {
                        result[0] += -6.238932072996329e-07;
                      }
                    }
                  } else {
                    result[0] += -6.238932072996329e-07;
                  }
                }
              } else {
                result[0] += -6.238932072996329e-07;
              }
            }
          } else {
            result[0] += -6.238932072996329e-07;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -6.238932072996329e-07;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -6.238932072996329e-07;
                } else {
                  result[0] += -6.238932072996329e-07;
                }
              } else {
                result[0] += -6.238932072996329e-07;
              }
            } else {
              result[0] += -6.238932072996329e-07;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
          result[0] += 6.256132393150634e-07;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005479696504671500816) ) ) {
              result[0] += -0.0008239041626981685;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05473596564878090848) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01170971943545395279) ) ) {
                  result[0] += 0.0026841396412443344;
                } else {
                  result[0] += 0.0002224331062121686;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1643367459977091716) ) ) {
                  result[0] += 0.0015735766127026977;
                } else {
                  result[0] += 0.0007039831040345516;
                }
              }
            }
          } else {
            result[0] += 9.090842936868421e-05;
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4323286620486300191) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
            result[0] += 0.0003595134139617167;
          } else {
            result[0] += 0.00038628829644113334;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01085750000000000083) ) ) {
            result[0] += 0.00030284090216416355;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4052145559547739029) ) ) {
                result[0] += -0.002153987886392368;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06008500000000000646) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4419864859045226635) ) ) {
                    result[0] += 0.0005193759698526182;
                  } else {
                    result[0] += 0.0002713200165571399;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
                    result[0] += -0.0002761322445801549;
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.07786400000000001653) ) ) {
                      result[0] += -0.00015933334194199872;
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4088125000000000786) ) ) {
                        result[0] += 0.00038956453497897785;
                      } else {
                        result[0] += -0.0002523666535703416;
                      }
                    }
                  }
                }
              }
            } else {
              result[0] += 0.0003787483003295315;
            }
          }
        }
      }
    }
  }
}

