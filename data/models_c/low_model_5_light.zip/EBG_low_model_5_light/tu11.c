
#include "header.h"

void predict_unit11(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -1.7853320297698766e-08;
            } else {
              result[0] += -4.241335326115114e-08;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -4.241335326115114e-08;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -4.241335326115114e-08;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -4.241335326115114e-08;
                } else {
                  result[0] += -4.241335326115114e-08;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0009495000000000001486) ) ) {
            result[0] += -0.00045293596477794185;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0660705000000000181) ) ) {
              result[0] += 2.793896135389052e-06;
            } else {
              result[0] += -0.0007232449086100785;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -4.241335326115114e-08;
                } else {
                  result[0] += -4.241335326115114e-08;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.06536400211476856) ) ) {
                    result[0] += -4.241335326115114e-08;
                  } else {
                    result[0] += -4.241335326115114e-08;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -4.241335326115114e-08;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -4.241335326115114e-08;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -4.241335326115114e-08;
                      } else {
                        result[0] += -4.241335326115114e-08;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -4.241335326115114e-08;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -4.241335326115114e-08;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02928050000000000444) ) ) {
                      result[0] += -4.241335326115114e-08;
                    } else {
                      result[0] += -4.241335326115114e-08;
                    }
                  }
                }
              } else {
                result[0] += -4.241335326115114e-08;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -4.241335326115114e-08;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -4.241335326115114e-08;
                } else {
                  result[0] += -4.241335326115114e-08;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -4.241335326115114e-08;
                } else {
                  result[0] += -4.241335326115114e-08;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.786764172562814168) ) ) {
            result[0] += -9.156650660432831e-05;
          } else {
            result[0] += 1.1429302339755564e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9250000000000001554) ) ) {
        result[0] += 1.2416961215355975e-06;
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2162432673096428282) ) ) {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1185261981962025396) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4931942899748744114) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03420850000000000973) ) ) {
                  result[0] += 0.0004821065455206897;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04313150000000001011) ) ) {
                    result[0] += -0.00661877359911215;
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)15.50000000000000178) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09069971400431196817) ) ) {
                        result[0] += 0.004558627495540137;
                      } else {
                        result[0] += -0.008713129292446954;
                      }
                    } else {
                      result[0] += 0.0010743909871713294;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1377635000000000109) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1016030000000000127) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4795364038944723295) ) ) {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)262.5000000000000568) ) ) {
                        result[0] += 6.902629112447639e-05;
                      } else {
                        result[0] += 0.00045703839208539865;
                      }
                    } else {
                      result[0] += -0.0007776881779663646;
                    }
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06116598190050365896) ) ) {
                      result[0] += -0.009115543122263712;
                    } else {
                      result[0] += 2.747357684031476e-05;
                    }
                  }
                } else {
                  result[0] += 4.662050432070316e-05;
                }
              }
            } else {
              result[0] += 0.00048600485523429425;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02321150000000000296) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5800027599246232457) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1978388257998979494) ) ) {
                  result[0] += 0.00012874487962840074;
                } else {
                  result[0] += -0.004901222035395364;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9567162861906464144) ) ) {
                  result[0] += 0.00032093363255743566;
                } else {
                  result[0] += -0.0001661126036901069;
                }
              }
            } else {
              result[0] += -2.638224285173424e-05;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0131020000000000008) ) ) {
            result[0] += -0.00017031596933255895;
          } else {
            result[0] += 5.5292143863437126e-05;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -1.5907692985954163e-08;
            } else {
              result[0] += -3.779121143481499e-08;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.779121143481499e-08;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -3.779121143481499e-08;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -3.779121143481499e-08;
                } else {
                  result[0] += -3.779121143481499e-08;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.435405567110552727) ) ) {
            result[0] += 0.0037617095455812453;
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6711668573618091438) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6135097231155780539) ) ) {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5072261056783921029) ) ) {
                    result[0] += -0.0006010165307399251;
                  } else {
                    result[0] += 2.5609385036619574e-05;
                  }
                } else {
                  result[0] += -3.681898124032582e-05;
                }
              } else {
                result[0] += 0.004620549309922311;
              }
            } else {
              result[0] += 2.35828303073078e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -3.779121143481499e-08;
                } else {
                  result[0] += -3.779121143481499e-08;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.06536400211476856) ) ) {
                    result[0] += -3.779121143481499e-08;
                  } else {
                    result[0] += -3.779121143481499e-08;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -3.779121143481499e-08;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -3.779121143481499e-08;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -3.779121143481499e-08;
                      } else {
                        result[0] += -3.779121143481499e-08;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -3.779121143481499e-08;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -3.779121143481499e-08;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02928050000000000444) ) ) {
                      result[0] += -3.779121143481499e-08;
                    } else {
                      result[0] += -3.779121143481499e-08;
                    }
                  }
                }
              } else {
                result[0] += -3.779121143481499e-08;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -3.779121143481499e-08;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -3.779121143481499e-08;
                } else {
                  result[0] += -3.779121143481499e-08;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -3.779121143481499e-08;
                } else {
                  result[0] += -3.779121143481499e-08;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.786764172562814168) ) ) {
            result[0] += -8.15877299331846e-05;
          } else {
            result[0] += 1.0183754597629407e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1840395000000000225) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1345.500000000000227) ) ) {
            result[0] += -8.456646318207761e-06;
          } else {
            result[0] += 0.0026979712134273495;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
            result[0] += -0.000513141087568343;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.545000000000000151) ) ) {
              result[0] += 0.008490536018458276;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7593447680904524821) ) ) {
                result[0] += 0.0020992064838976786;
              } else {
                result[0] += -0.0053724703100750705;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.9546544174008676498) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003118500000000000178) ) ) {
            result[0] += 0.00013423109989488412;
          } else {
            result[0] += 4.153987366038374e-05;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3801755927260667134) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2913701978391959879) ) ) {
              result[0] += -0.0015391768774932425;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4519613501507538378) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)97.50000000000001421) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)79.50000000000001421) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09998752698574815689) ) ) {
                      result[0] += 0.00022860415069346008;
                    } else {
                      result[0] += 0.0001940499777634003;
                    }
                  } else {
                    result[0] += -0.00018457904395223138;
                  }
                } else {
                  if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.5140174937654242715) ) ) {
                    result[0] += 2.447954880742835e-05;
                  } else {
                    result[0] += 0.0002482364615783898;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4578754035427136104) ) ) {
                  result[0] += -0.0006874105338089203;
                } else {
                  result[0] += 8.261276525428468e-05;
                }
              }
            }
          } else {
            result[0] += 4.938348740601472e-05;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -1.4174097138028616e-08;
            } else {
              result[0] += -3.367278349620709e-08;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.367278349620709e-08;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -3.367278349620709e-08;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -3.367278349620709e-08;
                } else {
                  result[0] += -3.367278349620709e-08;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02530977052884725645) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004773500000000000833) ) ) {
              result[0] += -3.6377924589845706e-05;
            } else {
              result[0] += 2.237020216543012e-05;
            }
          } else {
            result[0] += -0.000597128498540024;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -3.367278349620709e-08;
                } else {
                  result[0] += -3.367278349620709e-08;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.06536400211476856) ) ) {
                    result[0] += -3.367278349620709e-08;
                  } else {
                    result[0] += -3.367278349620709e-08;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -3.367278349620709e-08;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -3.367278349620709e-08;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -3.367278349620709e-08;
                      } else {
                        result[0] += -3.367278349620709e-08;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -3.367278349620709e-08;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -3.367278349620709e-08;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02928050000000000444) ) ) {
                      result[0] += -3.367278349620709e-08;
                    } else {
                      result[0] += -3.367278349620709e-08;
                    }
                  }
                }
              } else {
                result[0] += -3.367278349620709e-08;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -3.367278349620709e-08;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -3.367278349620709e-08;
                } else {
                  result[0] += -3.367278349620709e-08;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -3.367278349620709e-08;
                } else {
                  result[0] += -3.367278349620709e-08;
                }
              }
            }
          }
        } else {
          result[0] += 4.614218556607688e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.641728423423682037e-06) ) ) {
          result[0] += -9.02455515491674e-05;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0005505000000000000995) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1550000000000000266) ) ) {
              result[0] += -2.071778680941199e-05;
            } else {
              result[0] += 0.0011410237240821648;
            }
          } else {
            result[0] += -3.0299326710792256e-05;
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.9546544174008676498) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003118500000000000178) ) ) {
            result[0] += 0.00011960280164647831;
          } else {
            result[0] += 3.701292229381197e-05;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)48.50000000000000711) ) ) {
                result[0] += -0.0026754014159837483;
              } else {
                result[0] += 0.00053394459906838;
              }
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1828583041203602211) ) ) {
                result[0] += 0.0001424240736345905;
              } else {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5910501547487437835) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5835479980653267562) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3872449054220527542) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2542665105872564113) ) ) {
                        result[0] += 5.9476817070935234e-05;
                      } else {
                        result[0] += 0.0023754239382502242;
                      }
                    } else {
                      result[0] += -0.0020503795345130893;
                    }
                  } else {
                    result[0] += -0.0032740416784199184;
                  }
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02424450000000000563) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9567162861906464144) ) ) {
                      result[0] += 0.0003683749858667638;
                    } else {
                      result[0] += -0.0002995129963368299;
                    }
                  } else {
                    result[0] += 2.0906257021469293e-05;
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)27.50000000000000355) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4573392949246231631) ) ) {
                result[0] += 0.000131025805651294;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.606193063154585432) ) ) {
                  result[0] += -0.0003288712802469015;
                } else {
                  result[0] += 0.0002460175583152229;
                }
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                result[0] += 4.0263479551864836e-05;
              } else {
                result[0] += 0.00014414908790113601;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -1.2629425891933916e-08;
            } else {
              result[0] += -3.000317548269638e-08;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.000317548269638e-08;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -3.000317548269638e-08;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -3.000317548269638e-08;
                } else {
                  result[0] += -3.000317548269638e-08;
                }
              }
            }
          }
        } else {
          result[0] += 2.298129636368689e-06;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -3.000317548269638e-08;
                } else {
                  result[0] += -3.000317548269638e-08;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.06536400211476856) ) ) {
                    result[0] += -3.000317548269638e-08;
                  } else {
                    result[0] += -3.000317548269638e-08;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -3.000317548269638e-08;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -3.000317548269638e-08;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -3.000317548269638e-08;
                      } else {
                        result[0] += -3.000317548269638e-08;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -3.000317548269638e-08;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -3.000317548269638e-08;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02928050000000000444) ) ) {
                      result[0] += -3.000317548269638e-08;
                    } else {
                      result[0] += -3.000317548269638e-08;
                    }
                  }
                }
              } else {
                result[0] += -3.000317548269638e-08;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -3.000317548269638e-08;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -3.000317548269638e-08;
                } else {
                  result[0] += -3.000317548269638e-08;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -3.000317548269638e-08;
                } else {
                  result[0] += -3.000317548269638e-08;
                }
              }
            }
          }
        } else {
          result[0] += 4.1113681345947696e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
        result[0] += -2.023032255032287e-06;
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2669585275879397535) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00338750000000000032) ) ) {
            result[0] += -5.7515718546179914e-05;
          } else {
            result[0] += 3.297931110546813e-05;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003977500000000001) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.002767112624980650522) ) ) {
                result[0] += -0.002022141779349194;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02620539606947270075) ) ) {
                  result[0] += 0.0016322863236732522;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)175.5000000000000284) ) ) {
                    result[0] += 0.00011164875814505269;
                  } else {
                    result[0] += -0.0008314769037624666;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)262.5000000000000568) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
                  result[0] += 0.004160949535965838;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)92.50000000000001421) ) ) {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)86.50000000000001421) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0195721650588623515) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4960533228876460865) ) ) {
                          result[0] += -0.00033400619642463434;
                        } else {
                          result[0] += -0.0033482148515746094;
                        }
                      } else {
                        result[0] += 0.00017981859068954016;
                      }
                    } else {
                      result[0] += 0.0004474152790496951;
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09637729146099090205) ) ) {
                      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6571412079648242255) ) ) {
                        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6402527760050252814) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02803443610476625408) ) ) {
                            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5910501547487437835) ) ) {
                              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.04446937286580055632) ) ) {
                                result[0] += -0.0006814131599488201;
                              } else {
                                result[0] += -0.0019690934756817764;
                              }
                            } else {
                              result[0] += 0.0030980927359152257;
                            }
                          } else {
                            result[0] += 0.00014185525059670702;
                          }
                        } else {
                          result[0] += -0.0073270189356097115;
                        }
                      } else {
                        result[0] += 0.0014748796773857468;
                      }
                    } else {
                      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3715165125194505591) ) ) {
                        result[0] += -3.297364484645781e-05;
                      } else {
                        result[0] += -0.00042546783021200766;
                      }
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)810.5000000000001137) ) ) {
                  result[0] += 0.00020650065920500442;
                } else {
                  result[0] += -0.0015053245063614815;
                }
              }
            }
          } else {
            result[0] += 3.694919859675344e-05;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -1.125309053599799e-08;
            } else {
              result[0] += -2.673347569103906e-08;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.673347569103906e-08;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -2.673347569103906e-08;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -2.673347569103906e-08;
                } else {
                  result[0] += -2.673347569103906e-08;
                }
              }
            }
          }
        } else {
          result[0] += 2.047683012891434e-06;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -2.673347569103906e-08;
                } else {
                  result[0] += -2.673347569103906e-08;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.06536400211476856) ) ) {
                    result[0] += -2.673347569103906e-08;
                  } else {
                    result[0] += -2.673347569103906e-08;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -2.673347569103906e-08;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -2.673347569103906e-08;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -2.673347569103906e-08;
                      } else {
                        result[0] += -2.673347569103906e-08;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -2.673347569103906e-08;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -2.673347569103906e-08;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02928050000000000444) ) ) {
                      result[0] += -2.673347569103906e-08;
                    } else {
                      result[0] += -2.673347569103906e-08;
                    }
                  }
                }
              } else {
                result[0] += -2.673347569103906e-08;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -2.673347569103906e-08;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -2.673347569103906e-08;
                } else {
                  result[0] += -2.673347569103906e-08;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -2.673347569103906e-08;
                } else {
                  result[0] += -2.673347569103906e-08;
                }
              }
            }
          }
        } else {
          result[0] += 3.663317576050926e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
        result[0] += -1.802565319902381e-06;
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2669585275879397535) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00338750000000000032) ) ) {
            result[0] += -5.1247744242717556e-05;
          } else {
            result[0] += 2.9385276643591756e-05;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003977500000000001) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.002767112624980650522) ) ) {
                result[0] += -0.0018017718868872132;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)208.5000000000000284) ) ) {
                  result[0] += 0.0002724788242481433;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02620539606947270075) ) ) {
                    result[0] += 0.0014544022775156145;
                  } else {
                    result[0] += -0.0006512146044073459;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)262.5000000000000568) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)137.5000000000000284) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)121.5000000000000142) ) ) {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)92.50000000000001421) ) ) {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)85.50000000000001421) ) ) {
                        result[0] += 0.0001134873794857332;
                      } else {
                        result[0] += 0.0003779919150564616;
                      }
                    } else {
                      result[0] += -0.0001724025613711882;
                    }
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)127.5000000000000142) ) ) {
                      result[0] += 0.0002946425248616214;
                    } else {
                      result[0] += 9.413466727678338e-05;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09637729146099090205) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)155.5000000000000284) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02180250462562445188) ) ) {
                        result[0] += -0.004075661369717465;
                      } else {
                        result[0] += 2.609555605628485e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)244.5000000000000284) ) ) {
                        result[0] += 0.00021515932875047157;
                      } else {
                        result[0] += -0.005815044152982194;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5733499648994976328) ) ) {
                      result[0] += -0.0003281912947219912;
                    } else {
                      result[0] += 0.0003019997867483706;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)810.5000000000001137) ) ) {
                  result[0] += 0.00018399653584082372;
                } else {
                  result[0] += -0.0013412765632474187;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3687216492462311868) ) ) {
              result[0] += 5.017502604338722e-05;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
                result[0] += 0.00011272014874807098;
              } else {
                result[0] += 3.184896096860625e-05;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -1.002674608450506e-08;
            } else {
              result[0] += -2.382010273997665e-08;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.382010273997665e-08;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -2.382010273997665e-08;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -2.382010273997665e-08;
                } else {
                  result[0] += -2.382010273997665e-08;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0660705000000000181) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001281074579984450108) ) ) {
              result[0] += -0.0004150602120625992;
            } else {
              result[0] += 8.6348678996141e-06;
            }
          } else {
            result[0] += -0.0005547718715079422;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -2.382010273997665e-08;
                } else {
                  result[0] += -2.382010273997665e-08;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.06536400211476856) ) ) {
                    result[0] += -2.382010273997665e-08;
                  } else {
                    result[0] += -2.382010273997665e-08;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -2.382010273997665e-08;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -2.382010273997665e-08;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -2.382010273997665e-08;
                      } else {
                        result[0] += -2.382010273997665e-08;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -2.382010273997665e-08;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -2.382010273997665e-08;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02928050000000000444) ) ) {
                      result[0] += -2.382010273997665e-08;
                    } else {
                      result[0] += -2.382010273997665e-08;
                    }
                  }
                }
              } else {
                result[0] += -2.382010273997665e-08;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -2.382010273997665e-08;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -2.382010273997665e-08;
                } else {
                  result[0] += -2.382010273997665e-08;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -2.382010273997665e-08;
                } else {
                  result[0] += -2.382010273997665e-08;
                }
              }
            }
          }
        } else {
          result[0] += 3.2640948763704764e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
        result[0] += -1.6061245313491554e-06;
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2669585275879397535) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00338750000000000032) ) ) {
            result[0] += -4.566284411206634e-05;
          } else {
            result[0] += 2.6182914514458713e-05;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002668500000000000299) ) ) {
              result[0] += 0.00026077747909322143;
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.629632012766062954) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01035297934913455113) ) ) {
                  result[0] += -0.004877960249545687;
                } else {
                  if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.7147736162829507744) ) ) {
                    if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
                      result[0] += -0.0012211663839294608;
                    } else {
                      result[0] += 8.267421111422835e-05;
                    }
                  } else {
                    result[0] += -0.00019991187573398686;
                  }
                }
              } else {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2450759342279490716) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)159.5000000000000284) ) ) {
                    result[0] += 0.00018834502044027827;
                  } else {
                    result[0] += 0.0001639448771338567;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3084325690180824142) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)7.500000000000000888) ) ) {
                      result[0] += 0.0012481798216324553;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2229087561192843736) ) ) {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
                          result[0] += 0.0033780506779195886;
                        } else {
                          result[0] += -5.350378275796789e-05;
                        }
                      } else {
                        result[0] += -0.0029610695563580263;
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3872449054220527542) ) ) {
                      result[0] += 0.0006712002543467809;
                    } else {
                      result[0] += 0.00011165991078506023;
                    }
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4573392949246231631) ) ) {
                result[0] += 0.00022356676743144478;
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4983996163819096048) ) ) {
                  result[0] += -0.0008239826384307901;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0133385000000000014) ) ) {
                    result[0] += -0.0003937013465446893;
                  } else {
                    result[0] += 0.00014168544977221213;
                  }
                }
              }
            } else {
              result[0] += 2.8378110321356612e-05;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -8.934046759986924e-09;
            } else {
              result[0] += -2.1224224679966773e-08;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.1224224679966773e-08;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -2.1224224679966773e-08;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -2.1224224679966773e-08;
                } else {
                  result[0] += -2.1224224679966773e-08;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.435405567110552727) ) ) {
            result[0] += 0.003347911756128311;
          } else {
            result[0] += -6.529798071385715e-08;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -2.1224224679966773e-08;
                } else {
                  result[0] += -2.1224224679966773e-08;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.06536400211476856) ) ) {
                    result[0] += -2.1224224679966773e-08;
                  } else {
                    result[0] += -2.1224224679966773e-08;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -2.1224224679966773e-08;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -2.1224224679966773e-08;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -2.1224224679966773e-08;
                      } else {
                        result[0] += -2.1224224679966773e-08;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -2.1224224679966773e-08;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -2.1224224679966773e-08;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02928050000000000444) ) ) {
                      result[0] += -2.1224224679966773e-08;
                    } else {
                      result[0] += -2.1224224679966773e-08;
                    }
                  }
                }
              } else {
                result[0] += -2.1224224679966773e-08;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -2.1224224679966773e-08;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -2.1224224679966773e-08;
                } else {
                  result[0] += -2.1224224679966773e-08;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -2.1224224679966773e-08;
                } else {
                  result[0] += -2.1224224679966773e-08;
                }
              }
            }
          }
        } else {
          result[0] += 2.9083788507993345e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
        result[0] += -1.4310915569691232e-06;
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3687216492462311868) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05963150000000001089) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)247.5000000000000284) ) ) {
              result[0] += 4.140976332616494e-05;
            } else {
              result[0] += 0.0009343022443350965;
            }
          } else {
            result[0] += 2.3329540871311056e-05;
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.379624920427135748) ) ) {
            result[0] += -0.0059263680901470665;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003808500000000000687) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)262.5000000000000568) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.553675928821614205) ) ) {
                    result[0] += 0.00034733679528364337;
                  } else {
                    result[0] += -3.328573101771735e-05;
                  }
                } else {
                  result[0] += -0.0002683908881301971;
                }
              } else {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.5724391781153673753) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)50.50000000000000711) ) ) {
                    result[0] += 0.00041395644436141956;
                  } else {
                    result[0] += -0.0007078240289622186;
                  }
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3103687546836865763) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1016030000000000127) ) ) {
                      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.5140174937654242715) ) ) {
                        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.5412335719706470316) ) ) {
                          result[0] += 0.00020147137951250424;
                        } else {
                          result[0] += -0.002908721621044911;
                        }
                      } else {
                        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)39.50000000000000711) ) ) {
                          result[0] += 0.000456879377319243;
                        } else {
                          result[0] += 0.00042718338226213897;
                        }
                      }
                    } else {
                      result[0] += -0.0004154340344246026;
                    }
                  } else {
                    result[0] += 8.969756944169038e-05;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1165587384072143268) ) ) {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3932416254517326903) ) ) {
                    result[0] += -0.0003980297416924271;
                  } else {
                    result[0] += 0.00013821933667161986;
                  }
                } else {
                  result[0] += -0.00012294782962384094;
                }
              } else {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2450759342279490716) ) ) {
                  if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4323286620486300191) ) ) {
                    result[0] += 2.1228868566464314e-05;
                  } else {
                    result[0] += -2.5393355692928272e-05;
                  }
                } else {
                  result[0] += 2.5285507624728486e-05;
                }
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -7.960428122608478e-09;
            } else {
              result[0] += -1.891124140743955e-08;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.891124140743955e-08;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -1.891124140743955e-08;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -1.891124140743955e-08;
                } else {
                  result[0] += -1.891124140743955e-08;
                }
              }
            }
          }
        } else {
          result[0] += 1.8363176581267536e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -1.891124140743955e-08;
                } else {
                  result[0] += -1.891124140743955e-08;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.06536400211476856) ) ) {
                    result[0] += -1.891124140743955e-08;
                  } else {
                    result[0] += -1.891124140743955e-08;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -1.891124140743955e-08;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -1.891124140743955e-08;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -1.891124140743955e-08;
                      } else {
                        result[0] += -1.891124140743955e-08;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -1.891124140743955e-08;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -1.891124140743955e-08;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02928050000000000444) ) ) {
                      result[0] += -1.891124140743955e-08;
                    } else {
                      result[0] += -1.891124140743955e-08;
                    }
                  }
                }
              } else {
                result[0] += -1.891124140743955e-08;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -1.891124140743955e-08;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -1.891124140743955e-08;
                } else {
                  result[0] += -1.891124140743955e-08;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -1.891124140743955e-08;
                } else {
                  result[0] += -1.891124140743955e-08;
                }
              }
            }
          }
        } else {
          result[0] += 2.591428209091308e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
        result[0] += -1.2751334061973476e-06;
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2669585275879397535) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00338750000000000032) ) ) {
            result[0] += -4.5199349927329075e-05;
          } else {
            result[0] += 2.078712348717273e-05;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2162432673096428282) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9567162861906464144) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8523239353217898495) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6650804020351760437) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5423446055643508235) ) ) {
                      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1828583041203602211) ) ) {
                        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.629632012766062954) ) ) {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01668250000000000288) ) ) {
                            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002726500000000000191) ) ) {
                              result[0] += 0.0011656658152207338;
                            } else {
                              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3498337084924623697) ) ) {
                                result[0] += -0.0005162859597582612;
                              } else {
                                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006979000000000000828) ) ) {
                                  result[0] += -2.1345418365641372e-05;
                                } else {
                                  result[0] += -0.0010010204763500968;
                                }
                              }
                            }
                          } else {
                            result[0] += 3.8103345866197584e-05;
                          }
                        } else {
                          result[0] += 0.00014406381239428853;
                        }
                      } else {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005491500000000000721) ) ) {
                          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5758421811557790093) ) ) {
                            result[0] += 0.00012114322184708109;
                          } else {
                            result[0] += 0.00040619042213755203;
                          }
                        } else {
                          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006853500000000001084) ) ) {
                            result[0] += -0.0006524527824361064;
                          } else {
                            result[0] += 0.00010117575050153843;
                          }
                        }
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06439350000000000629) ) ) {
                        result[0] += -0.009074569785441834;
                      } else {
                        result[0] += 0.0005974731382538646;
                      }
                    }
                  } else {
                    result[0] += 0.0005026086454954571;
                  }
                } else {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.735388073517588059) ) ) {
                    result[0] += -0.0022720728149729567;
                  } else {
                    result[0] += 0.00048531664156781766;
                  }
                }
              } else {
                result[0] += 0.0008530384511778216;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)82.50000000000001421) ) ) {
                result[0] += -0.0020555971337552145;
              } else {
                result[0] += 0.0007470157544348162;
              }
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0131020000000000008) ) ) {
              result[0] += -9.392648760629685e-05;
            } else {
              result[0] += 2.2529932000403906e-05;
            }
          }
        }
      }
    }
  }
}

