
#include "header.h"

void predict_unit11(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -3.1276883263740983e-07;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.1276883263740983e-07;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -3.1276883263740983e-07;
              } else {
                result[0] += -3.1276883263740983e-07;
              }
            }
          }
        } else {
          result[0] += -2.3160937342824695e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -3.1276883263740983e-07;
              } else {
                result[0] += -3.1276883263740983e-07;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -3.1276883263740983e-07;
                  } else {
                    result[0] += -3.1276883263740983e-07;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -3.1276883263740983e-07;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -3.1276883263740983e-07;
                        } else {
                          result[0] += -3.1276883263740983e-07;
                        }
                      } else {
                        result[0] += -3.1276883263740983e-07;
                      }
                    }
                  } else {
                    result[0] += -3.1276883263740983e-07;
                  }
                }
              } else {
                result[0] += -3.1276883263740983e-07;
              }
            }
          } else {
            result[0] += -3.1276883263740983e-07;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -3.1276883263740983e-07;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -3.1276883263740983e-07;
                } else {
                  result[0] += -3.1276883263740983e-07;
                }
              } else {
                result[0] += -3.1276883263740983e-07;
              }
            } else {
              result[0] += -3.1276883263740983e-07;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1605461427107033601) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.146109394227906586) ) ) {
            result[0] += 0.0005308275766512486;
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7983975536720421262) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.9159493641278110276) ) ) {
                result[0] += 1.8373366594894447e-05;
              } else {
                result[0] += -0.0004843427848480451;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3115605993075549196) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2888738239382729889) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2739990068871500095) ) ) {
                    result[0] += 2.7865220458677862e-05;
                  } else {
                    result[0] += -0.00043443736059414566;
                  }
                } else {
                  result[0] += 0.0004184522258082259;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3466557816143853721) ) ) {
                  result[0] += -0.00020823648377080338;
                } else {
                  result[0] += -3.611737093243344e-07;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1643367459977091716) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1044543990012605922) ) ) {
              result[0] += 0.0007562411493276691;
            } else {
              result[0] += 0.0007447290812480811;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4868404241646586694) ) ) {
              result[0] += -0.001482762209143387;
            } else {
              result[0] += 0.00047329520021106863;
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0001802305097838545;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4133512684738382403) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1773295000000000288) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
                  result[0] += 0.0002661483934298771;
                } else {
                  result[0] += 0.00013175416138055693;
                }
              } else {
                result[0] += 0.00024119817308538457;
              }
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3750409390474713223) ) ) {
                result[0] += -0.0013741323283101865;
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3245708964283948172) ) ) {
                  result[0] += 0.0003442660356238108;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004460500000000000922) ) ) {
                    result[0] += 0.0002637440264117095;
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006839500000000000961) ) ) {
                      result[0] += -2.198203121586739e-05;
                    } else {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0102480000000000019) ) ) {
                        result[0] += 0.0003198534877737584;
                      } else {
                        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.294841568336650095) ) ) {
                          result[0] += -9.46007680046386e-05;
                        } else {
                          result[0] += 8.783511248832481e-05;
                        }
                      }
                    }
                  }
                }
              }
            }
          } else {
            result[0] += 0.00018987330262849915;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -3.00319180279268e-07;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.00319180279268e-07;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -3.00319180279268e-07;
              } else {
                result[0] += -3.00319180279268e-07;
              }
            }
          }
        } else {
          result[0] += -2.223902445343795e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -3.00319180279268e-07;
              } else {
                result[0] += -3.00319180279268e-07;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -3.00319180279268e-07;
                  } else {
                    result[0] += -3.00319180279268e-07;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -3.00319180279268e-07;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -3.00319180279268e-07;
                        } else {
                          result[0] += -3.00319180279268e-07;
                        }
                      } else {
                        result[0] += -3.00319180279268e-07;
                      }
                    }
                  } else {
                    result[0] += -3.00319180279268e-07;
                  }
                }
              } else {
                result[0] += -3.00319180279268e-07;
              }
            }
          } else {
            result[0] += -3.00319180279268e-07;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -3.00319180279268e-07;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -3.00319180279268e-07;
                } else {
                  result[0] += -3.00319180279268e-07;
                }
              } else {
                result[0] += -3.00319180279268e-07;
              }
            } else {
              result[0] += -3.00319180279268e-07;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08951570884523896154) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08666957264163686891) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08404042173159891049) ) ) {
              result[0] += 1.7160655054794426e-06;
            } else {
              result[0] += 0.0011794748541094733;
            }
          } else {
            result[0] += -0.0010635541957247463;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9450000000000000622) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9150000000000001465) ) ) {
              result[0] += 0.00014853425903844775;
            } else {
              result[0] += -0.00023553063295055706;
            }
          } else {
            result[0] += 0.0003341445882681447;
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.00017305649831915953;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.0141436144428988015) ) ) {
                result[0] += 0.00024266898804507344;
              } else {
                result[0] += 7.53622087441645e-05;
              }
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3245708964283948172) ) ) {
                result[0] += 0.00023074918011933696;
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.294841568336650095) ) ) {
                  result[0] += -9.08352180150848e-05;
                } else {
                  result[0] += 4.9529806700173566e-05;
                }
              }
            }
          } else {
            result[0] += 0.00018231546321756915;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -2.883650819139317e-07;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.883650819139317e-07;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -2.883650819139317e-07;
              } else {
                result[0] += -2.883650819139317e-07;
              }
            }
          }
        } else {
          result[0] += -2.135380797935759e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -2.883650819139317e-07;
              } else {
                result[0] += -2.883650819139317e-07;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -2.883650819139317e-07;
                  } else {
                    result[0] += -2.883650819139317e-07;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -2.883650819139317e-07;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -2.883650819139317e-07;
                        } else {
                          result[0] += -2.883650819139317e-07;
                        }
                      } else {
                        result[0] += -2.883650819139317e-07;
                      }
                    }
                  } else {
                    result[0] += -2.883650819139317e-07;
                  }
                }
              } else {
                result[0] += -2.883650819139317e-07;
              }
            }
          } else {
            result[0] += -2.883650819139317e-07;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -2.883650819139317e-07;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -2.883650819139317e-07;
                } else {
                  result[0] += -2.883650819139317e-07;
                }
              } else {
                result[0] += -2.883650819139317e-07;
              }
            } else {
              result[0] += -2.883650819139317e-07;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07954367714673930834) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.146109394227906586) ) ) {
            result[0] += 0.0006618556278485905;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9750000000000000888) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8050000000000001599) ) ) {
                result[0] += -5.142477327828705e-07;
              } else {
                result[0] += 0.0002224543458610606;
              }
            } else {
              result[0] += -0.0001171165375446626;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3931761618090452437) ) ) {
            result[0] += -0.000605948390545619;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9450000000000000622) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9250000000000001554) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5950000000000000844) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5350000000000001421) ) ) {
                    result[0] += 7.062484200715178e-05;
                  } else {
                    result[0] += -0.00035383094040049545;
                  }
                } else {
                  result[0] += 0.0005923714388309253;
                }
              } else {
                result[0] += -0.0002740176958335918;
              }
            } else {
              result[0] += 0.0003889007383392454;
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.00016616804583422795;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.0141436144428988015) ) ) {
                result[0] += 0.00023300963511726697;
              } else {
                result[0] += 7.236244277677303e-05;
              }
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3245708964283948172) ) ) {
                result[0] += 0.00022156429091478388;
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.294841568336650095) ) ) {
                  result[0] += -8.721955440618796e-05;
                } else {
                  result[0] += 4.755829032629751e-05;
                }
              }
            }
          } else {
            result[0] += 0.00017505846092155208;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -2.768868121906263e-07;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.768868121906263e-07;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -2.768868121906263e-07;
              } else {
                result[0] += -2.768868121906263e-07;
              }
            }
          }
        } else {
          result[0] += -2.0503827232798642e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -2.768868121906263e-07;
              } else {
                result[0] += -2.768868121906263e-07;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -2.768868121906263e-07;
                  } else {
                    result[0] += -2.768868121906263e-07;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -2.768868121906263e-07;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -2.768868121906263e-07;
                        } else {
                          result[0] += -2.768868121906263e-07;
                        }
                      } else {
                        result[0] += -2.768868121906263e-07;
                      }
                    }
                  } else {
                    result[0] += -2.768868121906263e-07;
                  }
                }
              } else {
                result[0] += -2.768868121906263e-07;
              }
            }
          } else {
            result[0] += -2.768868121906263e-07;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -2.768868121906263e-07;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -2.768868121906263e-07;
                } else {
                  result[0] += -2.768868121906263e-07;
                }
              } else {
                result[0] += -2.768868121906263e-07;
              }
            } else {
              result[0] += -2.768868121906263e-07;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.146109394227906586) ) ) {
          result[0] += 0.0005050484465008912;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08951570884523896154) ) ) {
            result[0] += 1.1682115403043798e-06;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9450000000000000622) ) ) {
              result[0] += 7.34144386695966e-05;
            } else {
              result[0] += 0.00029133226604954166;
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.00015955378575523081;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004460500000000000922) ) ) {
              result[0] += 0.00022567839228624376;
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3245708964283948172) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3721023948335018816) ) ) {
                  if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4133512684738382403) ) ) {
                    result[0] += 0.00022026774697526206;
                  } else {
                    result[0] += -0.0012861366112877002;
                  }
                } else {
                  result[0] += 0.00033372905793387363;
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006839500000000000961) ) ) {
                  result[0] += -2.698717158167473e-05;
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.294841568336650095) ) ) {
                    result[0] += -0.0001010415979906404;
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02405800000000000646) ) ) {
                      result[0] += 0.00020285733702878612;
                    } else {
                      result[0] += 2.109038572586028e-05;
                    }
                  }
                }
              }
            }
          } else {
            result[0] += 0.000168090321025875;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -2.6586543091916297e-07;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.6586543091916297e-07;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -2.6586543091916297e-07;
              } else {
                result[0] += -2.6586543091916297e-07;
              }
            }
          }
        } else {
          result[0] += -1.9687679668134898e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -2.6586543091916297e-07;
              } else {
                result[0] += -2.6586543091916297e-07;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -2.6586543091916297e-07;
                  } else {
                    result[0] += -2.6586543091916297e-07;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -2.6586543091916297e-07;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -2.6586543091916297e-07;
                        } else {
                          result[0] += -2.6586543091916297e-07;
                        }
                      } else {
                        result[0] += -2.6586543091916297e-07;
                      }
                    }
                  } else {
                    result[0] += -2.6586543091916297e-07;
                  }
                }
              } else {
                result[0] += -2.6586543091916297e-07;
              }
            }
          } else {
            result[0] += -2.6586543091916297e-07;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -2.6586543091916297e-07;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -2.6586543091916297e-07;
                } else {
                  result[0] += -2.6586543091916297e-07;
                }
              } else {
                result[0] += -2.6586543091916297e-07;
              }
            } else {
              result[0] += -2.6586543091916297e-07;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.146109394227906586) ) ) {
          result[0] += 0.00048494517236729153;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08951570884523896154) ) ) {
            result[0] += 1.1217112946278052e-06;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9450000000000000622) ) ) {
              result[0] += 7.049220299861416e-05;
            } else {
              result[0] += 0.00027973588861499526;
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.00015320280395078291;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004460500000000000922) ) ) {
              result[0] += 0.00021669534399138525;
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3245708964283948172) ) ) {
                result[0] += 0.00020591958235757605;
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.294841568336650095) ) ) {
                  result[0] += -7.396187679970256e-05;
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2302999793555680907) ) ) {
                    result[0] += 0.00027952933770111375;
                  } else {
                    result[0] += 3.250453283110388e-05;
                  }
                }
              }
            }
          } else {
            result[0] += 0.0001613995454652359;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -2.552827518168998e-07;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.552827518168998e-07;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -2.552827518168998e-07;
              } else {
                result[0] += -2.552827518168998e-07;
              }
            }
          }
        } else {
          result[0] += -1.890401856757094e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -2.552827518168998e-07;
              } else {
                result[0] += -2.552827518168998e-07;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -2.552827518168998e-07;
                  } else {
                    result[0] += -2.552827518168998e-07;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -2.552827518168998e-07;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -2.552827518168998e-07;
                        } else {
                          result[0] += -2.552827518168998e-07;
                        }
                      } else {
                        result[0] += -2.552827518168998e-07;
                      }
                    }
                  } else {
                    result[0] += -2.552827518168998e-07;
                  }
                }
              } else {
                result[0] += -2.552827518168998e-07;
              }
            }
          } else {
            result[0] += -2.552827518168998e-07;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -2.552827518168998e-07;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -2.552827518168998e-07;
                } else {
                  result[0] += -2.552827518168998e-07;
                }
              } else {
                result[0] += -2.552827518168998e-07;
              }
            } else {
              result[0] += -2.552827518168998e-07;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.146109394227906586) ) ) {
          result[0] += 0.00046564210192442815;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08951570884523896154) ) ) {
            result[0] += 1.077061974724187e-06;
          } else {
            result[0] += 0.00016591207807753987;
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.00014710462072262435;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004460500000000000922) ) ) {
              result[0] += 0.00020806986274515075;
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3245708964283948172) ) ) {
                result[0] += 0.0001977230264780523;
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.294841568336650095) ) ) {
                  result[0] += -7.101785054827572e-05;
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2302999793555680907) ) ) {
                    result[0] += 0.0002684027716397336;
                  } else {
                    result[0] += 3.1210701440045324e-05;
                  }
                }
              }
            }
          } else {
            result[0] += 0.0001549750938507308;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -2.4512131249972e-07;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.4512131249972e-07;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -2.4512131249972e-07;
              } else {
                result[0] += -2.4512131249972e-07;
              }
            }
          }
        } else {
          result[0] += -1.815155081893515e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.384300133116745416e-05) ) ) {
                result[0] += -2.4512131249972e-07;
              } else {
                result[0] += -2.4512131249972e-07;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -2.4512131249972e-07;
                  } else {
                    result[0] += -2.4512131249972e-07;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -2.4512131249972e-07;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -2.4512131249972e-07;
                        } else {
                          result[0] += -2.4512131249972e-07;
                        }
                      } else {
                        result[0] += -2.4512131249972e-07;
                      }
                    }
                  } else {
                    result[0] += -2.4512131249972e-07;
                  }
                }
              } else {
                result[0] += -2.4512131249972e-07;
              }
            }
          } else {
            result[0] += -2.4512131249972e-07;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -2.4512131249972e-07;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -2.4512131249972e-07;
                } else {
                  result[0] += -2.4512131249972e-07;
                }
              } else {
                result[0] += -2.4512131249972e-07;
              }
            } else {
              result[0] += -2.4512131249972e-07;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1605461427107033601) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3115605993075549196) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2888738239382729889) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2739990068871500095) ) ) {
                result[0] += 2.2169707164267174e-05;
              } else {
                result[0] += -0.0004173265952349057;
              }
            } else {
              result[0] += 0.000401614023934858;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3561404984221285264) ) ) {
              result[0] += -0.00017057238117678062;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3763200711443456803) ) ) {
                result[0] += 0.0006775429299320326;
              } else {
                result[0] += -9.085439614123808e-07;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1643367459977091716) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1044543990012605922) ) ) {
              result[0] += 0.0006716997722298616;
            } else {
              result[0] += 0.0006569696054109853;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4868404241646586694) ) ) {
              result[0] += -0.001452066065219622;
            } else {
              result[0] += 0.0003997560142894467;
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.00014124917351316274;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004460500000000000922) ) ) {
              result[0] += 0.00019978771571809646;
            } else {
              result[0] += 0.00010208527493852329;
            }
          } else {
            result[0] += 0.00014880636525222267;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -2.3536434566750773e-07;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.3536434566750773e-07;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -2.3536434566750773e-07;
              } else {
                result[0] += -2.3536434566750773e-07;
              }
            }
          }
        } else {
          result[0] += -1.742903478192687e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.384300133116745416e-05) ) ) {
                result[0] += -2.3536434566750773e-07;
              } else {
                result[0] += -2.3536434566750773e-07;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -2.3536434566750773e-07;
                  } else {
                    result[0] += -2.3536434566750773e-07;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -2.3536434566750773e-07;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -2.3536434566750773e-07;
                        } else {
                          result[0] += -2.3536434566750773e-07;
                        }
                      } else {
                        result[0] += -2.3536434566750773e-07;
                      }
                    }
                  } else {
                    result[0] += -2.3536434566750773e-07;
                  }
                }
              } else {
                result[0] += -2.3536434566750773e-07;
              }
            }
          } else {
            result[0] += -2.3536434566750773e-07;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -2.3536434566750773e-07;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -2.3536434566750773e-07;
                } else {
                  result[0] += -2.3536434566750773e-07;
                }
              } else {
                result[0] += -2.3536434566750773e-07;
              }
            } else {
              result[0] += -2.3536434566750773e-07;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3115605993075549196) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02577363736079425413) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02328402533912880476) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3850000000000000644) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3550000000000000377) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2932818109908455484) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.243144592614154248) ) ) {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3150000000000000577) ) ) {
                        result[0] += -1.4666795175782037e-05;
                      } else {
                        result[0] += 0.0005261793558247515;
                      }
                    } else {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1050000000000000239) ) ) {
                        result[0] += -2.273295852996283e-05;
                      } else {
                        result[0] += -0.0007767915639582134;
                      }
                    }
                  } else {
                    result[0] += 0.00046097685701492375;
                  }
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2302999793555680907) ) ) {
                    result[0] += -0.0005000988045490488;
                  } else {
                    result[0] += -0.00016892487988840005;
                  }
                }
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.244955337349149066) ) ) {
                  if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.378188349821562797) ) ) {
                    if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4026472078210281969) ) ) {
                      result[0] += 0.00016113410110065983;
                    } else {
                      result[0] += -0.00123645593392904;
                    }
                  } else {
                    result[0] += 0.0008586551867614566;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5750000000000000666) ) ) {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1920506035764254771) ) ) {
                      result[0] += -0.0005826859546071337;
                    } else {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5350000000000001421) ) ) {
                        result[0] += 0.00039130100087156827;
                      } else {
                        result[0] += 0.0013030901405135487;
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6350000000000001199) ) ) {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.009014249010710599294) ) ) {
                        result[0] += -0.0013225345370018796;
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1165587384072143268) ) ) {
                          result[0] += 0.0010595278201957015;
                        } else {
                          result[0] += -0.00048692564520223347;
                        }
                      }
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1507499186893259402) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.06355808660527756393) ) ) {
                          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9650000000000000799) ) ) {
                            result[0] += 0.00014902382839117;
                          } else {
                            result[0] += -0.0010364632800040003;
                          }
                        } else {
                          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1076318469022627677) ) ) {
                            result[0] += -0.0013351993461250915;
                          } else {
                            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1206324332205917643) ) ) {
                              result[0] += 0.0018818678831604204;
                            } else {
                              result[0] += -0.001715911023045866;
                            }
                          }
                        }
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1908722399174398732) ) ) {
                          result[0] += 0.0012085585197944464;
                        } else {
                          result[0] += 0.00012806941643881946;
                        }
                      }
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.244955337349149066) ) ) {
                result[0] += -0.0013241141258099362;
              } else {
                result[0] += 1.7158566800548896e-05;
              }
            }
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6782348568386622478) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03409611752714010457) ) ) {
                result[0] += 0.0011222958092609236;
              } else {
                result[0] += -0.0006740014911751333;
              }
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6130861605291061389) ) ) {
                result[0] += 0.0006536400133534134;
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5261805248634544574) ) ) {
                  result[0] += -0.0008836876603046266;
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4601878067544193374) ) ) {
                    result[0] += 0.0010092858132971592;
                  } else {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1044543990012605922) ) ) {
                      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                        if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2545696998002126565) ) ) {
                          result[0] += -9.658767577233066e-05;
                        } else {
                          if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1711110322396684202) ) ) {
                            result[0] += 0.000771176685947876;
                          } else {
                            result[0] += -0.00013519656174767133;
                          }
                        }
                      } else {
                        result[0] += -0.0013727016570075595;
                      }
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1250629713251516228) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1051257686552766607) ) ) {
                          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.08110515786938453375) ) ) {
                            result[0] += 0.001095312808415136;
                          } else {
                            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.07196201389915944657) ) ) {
                              result[0] += -0.00023099208217330008;
                            } else {
                              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.05751864358971629093) ) ) {
                                result[0] += 0.0007633626202730562;
                              } else {
                                result[0] += 0.00026754946431290064;
                              }
                            }
                          }
                        } else {
                          result[0] += 0.001141571367753337;
                        }
                      } else {
                        result[0] += 2.1775607135262557e-05;
                      }
                    }
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3665106630729573767) ) ) {
            result[0] += -0.00018764945817368065;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3763200711443456803) ) ) {
              result[0] += 0.0010154093763811765;
            } else {
              result[0] += -5.868107523574325e-07;
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0001356268003013377;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004460500000000000922) ) ) {
              result[0] += 0.00019183523661350343;
            } else {
              result[0] += 9.802180680727599e-05;
            }
          } else {
            result[0] += 0.00014288318070583542;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -2.259957514365763e-07;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.259957514365763e-07;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -2.259957514365763e-07;
              } else {
                result[0] += -2.259957514365763e-07;
              }
            }
          }
        } else {
          result[0] += -1.6735278239296863e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.384300133116745416e-05) ) ) {
                result[0] += -2.259957514365763e-07;
              } else {
                result[0] += -2.259957514365763e-07;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -2.259957514365763e-07;
                  } else {
                    result[0] += -2.259957514365763e-07;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -2.259957514365763e-07;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -2.259957514365763e-07;
                        } else {
                          result[0] += -2.259957514365763e-07;
                        }
                      } else {
                        result[0] += -2.259957514365763e-07;
                      }
                    }
                  } else {
                    result[0] += -2.259957514365763e-07;
                  }
                }
              } else {
                result[0] += -2.259957514365763e-07;
              }
            }
          } else {
            result[0] += -2.259957514365763e-07;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -2.259957514365763e-07;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -2.259957514365763e-07;
                } else {
                  result[0] += -2.259957514365763e-07;
                }
              } else {
                result[0] += -2.259957514365763e-07;
              }
            } else {
              result[0] += -2.259957514365763e-07;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.146109394227906586) ) ) {
          result[0] += 0.0004601261592906374;
        } else {
          result[0] += 2.592999079870405e-06;
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0001302282236594122;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004460500000000000922) ) ) {
              result[0] += 0.00018419930311673962;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7211604863065327331) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6077784371608041525) ) ) {
                  result[0] += 8.155257171839169e-05;
                } else {
                  result[0] += 0.00021223765855650885;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
                  result[0] += -0.00036526289995078044;
                } else {
                  result[0] += 0.0003947024488286951;
                }
              }
            }
          } else {
            result[0] += 0.00013719576641773744;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -2.1700007077339414e-07;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.1700007077339414e-07;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -2.1700007077339414e-07;
              } else {
                result[0] += -2.1700007077339414e-07;
              }
            }
          }
        } else {
          result[0] += -1.6069136429580297e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.384300133116745416e-05) ) ) {
                result[0] += -2.1700007077339414e-07;
              } else {
                result[0] += -2.1700007077339414e-07;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -2.1700007077339414e-07;
                  } else {
                    result[0] += -2.1700007077339414e-07;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -2.1700007077339414e-07;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -2.1700007077339414e-07;
                        } else {
                          result[0] += -2.1700007077339414e-07;
                        }
                      } else {
                        result[0] += -2.1700007077339414e-07;
                      }
                    }
                  } else {
                    result[0] += -2.1700007077339414e-07;
                  }
                }
              } else {
                result[0] += -2.1700007077339414e-07;
              }
            }
          } else {
            result[0] += -2.1700007077339414e-07;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -2.1700007077339414e-07;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -2.1700007077339414e-07;
                } else {
                  result[0] += -2.1700007077339414e-07;
                }
              } else {
                result[0] += -2.1700007077339414e-07;
              }
            } else {
              result[0] += -2.1700007077339414e-07;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.146109394227906586) ) ) {
          result[0] += 0.0004418110008531735;
        } else {
          result[0] += 2.4897856719449784e-06;
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.00012504453544436183;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004460500000000000922) ) ) {
              result[0] += 0.00017686731524225075;
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2302999793555680907) ) ) {
                result[0] += 0.00018078715299441931;
              } else {
                result[0] += 1.5761167779836865e-05;
              }
            }
          } else {
            result[0] += 0.0001317347376364933;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -2.0836245998577183e-07;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.0836245998577183e-07;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -2.0836245998577183e-07;
              } else {
                result[0] += -2.0836245998577183e-07;
              }
            }
          }
        } else {
          result[0] += -1.542951015813608e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.384300133116745416e-05) ) ) {
                result[0] += -2.0836245998577183e-07;
              } else {
                result[0] += -2.0836245998577183e-07;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -2.0836245998577183e-07;
                  } else {
                    result[0] += -2.0836245998577183e-07;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -2.0836245998577183e-07;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -2.0836245998577183e-07;
                        } else {
                          result[0] += -2.0836245998577183e-07;
                        }
                      } else {
                        result[0] += -2.0836245998577183e-07;
                      }
                    }
                  } else {
                    result[0] += -2.0836245998577183e-07;
                  }
                }
              } else {
                result[0] += -2.0836245998577183e-07;
              }
            }
          } else {
            result[0] += -2.0836245998577183e-07;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -2.0836245998577183e-07;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -2.0836245998577183e-07;
                } else {
                  result[0] += -2.0836245998577183e-07;
                }
              } else {
                result[0] += -2.0836245998577183e-07;
              }
            } else {
              result[0] += -2.0836245998577183e-07;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.146109394227906586) ) ) {
          result[0] += 0.0004242248707958952;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.002347679878538096e-06) ) ) {
            result[0] += -2.822449116323539e-05;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
              result[0] += 0.000148058974279872;
            } else {
              result[0] += 3.1461167417159884e-06;
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.00012006718209863206;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004460500000000000922) ) ) {
              result[0] += 0.00016982717454243706;
            } else {
              result[0] += 8.547843784597781e-05;
            }
          } else {
            result[0] += 0.00012649108316735774;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -2.000686662294184e-07;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.000686662294184e-07;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -2.000686662294184e-07;
              } else {
                result[0] += -2.000686662294184e-07;
              }
            }
          }
        } else {
          result[0] += -1.4815343983375621e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.384300133116745416e-05) ) ) {
                result[0] += -2.000686662294184e-07;
              } else {
                result[0] += -2.000686662294184e-07;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -2.000686662294184e-07;
                  } else {
                    result[0] += -2.000686662294184e-07;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -2.000686662294184e-07;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -2.000686662294184e-07;
                        } else {
                          result[0] += -2.000686662294184e-07;
                        }
                      } else {
                        result[0] += -2.000686662294184e-07;
                      }
                    }
                  } else {
                    result[0] += -2.000686662294184e-07;
                  }
                }
              } else {
                result[0] += -2.000686662294184e-07;
              }
            }
          } else {
            result[0] += -2.000686662294184e-07;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -2.000686662294184e-07;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -2.000686662294184e-07;
                } else {
                  result[0] += -2.000686662294184e-07;
                }
              } else {
                result[0] += -2.000686662294184e-07;
              }
            } else {
              result[0] += -2.000686662294184e-07;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9450000000000000622) ) ) {
        result[0] += 6.733847272536915e-07;
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.00011528795053599401;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.314196657149456993) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7733398996305392847) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2929122217587940002) ) ) {
                    result[0] += -0.0004611578429191872;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6487823756783920315) ) ) {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004460500000000000922) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5424744603768845153) ) ) {
                          result[0] += 0.0002252916886034272;
                        } else {
                          result[0] += -7.798031546437242e-05;
                        }
                      } else {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006839500000000000961) ) ) {
                          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006186000000000001393) ) ) {
                            result[0] += 2.2761146459709464e-05;
                          } else {
                            result[0] += -0.0006857135630166683;
                          }
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3044676633919599085) ) ) {
                            result[0] += 0.0002827129332414552;
                          } else {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4693077114572864472) ) ) {
                              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4639489995477387718) ) ) {
                                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2428155000000000174) ) ) {
                                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04928050000000000486) ) ) {
                                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3644118032412060892) ) ) {
                                      result[0] += -0.00024603436631875003;
                                    } else {
                                      result[0] += 0.00022517086043785434;
                                    }
                                  } else {
                                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3687216492462311868) ) ) {
                                      result[0] += 0.0002111331737988636;
                                    } else {
                                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4129968667336683663) ) ) {
                                        result[0] += -0.0013797682962058608;
                                      } else {
                                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4405029099497487777) ) ) {
                                          result[0] += 0.0002581087182472071;
                                        } else {
                                          result[0] += -0.000564810801751969;
                                        }
                                      }
                                    }
                                  }
                                } else {
                                  result[0] += 0.00018934405962130985;
                                }
                              } else {
                                result[0] += -0.0013894089150702181;
                              }
                            } else {
                              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4088125000000000786) ) ) {
                                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4797597438944724013) ) ) {
                                  result[0] += 0.0004041747419194152;
                                } else {
                                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.51994285276381913) ) ) {
                                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.505061141934673441) ) ) {
                                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4838161673366834781) ) ) {
                                        result[0] += -0.00019365478617905006;
                                      } else {
                                        result[0] += 0.0001847422148698703;
                                      }
                                    } else {
                                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
                                        result[0] += -0.0002871695741512272;
                                      } else {
                                        result[0] += -2.65899602743409e-06;
                                      }
                                    }
                                  } else {
                                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5353359946984925788) ) ) {
                                      result[0] += 0.00029930079258909165;
                                    } else {
                                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5400528323115579843) ) ) {
                                        result[0] += -0.0009214444766249135;
                                      } else {
                                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5701775282412061552) ) ) {
                                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5612777274623116375) ) ) {
                                            result[0] += 0.0002925780448734731;
                                          } else {
                                            result[0] += 0.0003870504306928315;
                                          }
                                        } else {
                                          result[0] += 4.25598610032332e-05;
                                        }
                                      }
                                    }
                                  }
                                }
                              } else {
                                result[0] += -0.0008950007181044559;
                              }
                            }
                          }
                        }
                      }
                    } else {
                      result[0] += 0.00030467700483107976;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7412676365326634764) ) ) {
                    result[0] += -0.0010596558132802256;
                  } else {
                    result[0] += 0.0003402057070043853;
                  }
                }
              } else {
                result[0] += 0.00042305914969647504;
              }
            } else {
              result[0] += -0.0007546097611524014;
            }
          } else {
            result[0] += 0.0001214561505030041;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -1.9210500398945052e-07;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.9210500398945052e-07;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -1.9210500398945052e-07;
              } else {
                result[0] += -1.9210500398945052e-07;
              }
            }
          }
        } else {
          result[0] += -1.4225624475188111e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.384300133116745416e-05) ) ) {
                result[0] += -1.9210500398945052e-07;
              } else {
                result[0] += -1.9210500398945052e-07;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -1.9210500398945052e-07;
                  } else {
                    result[0] += -1.9210500398945052e-07;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -1.9210500398945052e-07;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -1.9210500398945052e-07;
                        } else {
                          result[0] += -1.9210500398945052e-07;
                        }
                      } else {
                        result[0] += -1.9210500398945052e-07;
                      }
                    }
                  } else {
                    result[0] += -1.9210500398945052e-07;
                  }
                }
              } else {
                result[0] += -1.9210500398945052e-07;
              }
            }
          } else {
            result[0] += -1.9210500398945052e-07;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -1.9210500398945052e-07;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -1.9210500398945052e-07;
                } else {
                  result[0] += -1.9210500398945052e-07;
                }
              } else {
                result[0] += -1.9210500398945052e-07;
              }
            } else {
              result[0] += -1.9210500398945052e-07;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9450000000000000622) ) ) {
        result[0] += 6.465808872197199e-07;
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0001106989545892044;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2929122217587940002) ) ) {
            result[0] += -0.0003511480787139666;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3763200711443456803) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6077784371608041525) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1165587384072143268) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1051257686552766607) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08407783631914581002) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5041457217085428821) ) ) {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3044676633919599085) ) ) {
                              result[0] += 0.00023868356580755812;
                            } else {
                              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3457619648241206378) ) ) {
                                result[0] += -0.00023225510221772813;
                              } else {
                                result[0] += 0.00015506066545785223;
                              }
                            }
                          } else {
                            result[0] += -0.000275740517406815;
                          }
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5353359946984925788) ) ) {
                            result[0] += 0.000277488422762221;
                          } else {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5392784256532664466) ) ) {
                              result[0] += -0.0006595646136434415;
                            } else {
                              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5493276582412061071) ) ) {
                                result[0] += 0.00032685376469110227;
                              } else {
                                result[0] += 0.00010667934108054682;
                              }
                            }
                          }
                        }
                      } else {
                        result[0] += -0.00047117701747999036;
                      }
                    } else {
                      result[0] += 0.00095866254389228;
                    }
                  } else {
                    result[0] += 0.0001166216315460817;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5612777274623116375) ) ) {
                    result[0] += -0.0012840504673199795;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5859181088693469208) ) ) {
                      result[0] += 0.00021157341170989328;
                    } else {
                      result[0] += -5.559509573224736e-06;
                    }
                  }
                }
              } else {
                result[0] += 0.00013010691005495558;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5834559473869348478) ) ) {
                result[0] += -0.0019622424942959057;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07316210697219156789) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6577150591959800563) ) ) {
                    result[0] += -0.0005830068900561158;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04653956279752540642) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7642320229909970175) ) ) {
                        result[0] += 0.001001932025803599;
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02328402533912880476) ) ) {
                          result[0] += -0.0008906453579448256;
                        } else {
                          result[0] += 0.0011292297971454723;
                        }
                      }
                    } else {
                      result[0] += -0.0004218333105685328;
                    }
                  }
                } else {
                  result[0] += 0.00016624169373163932;
                }
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -1.844583324980468e-07;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.844583324980468e-07;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -1.844583324980468e-07;
              } else {
                result[0] += -1.844583324980468e-07;
              }
            }
          }
        } else {
          result[0] += -1.3659378542688561e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.384300133116745416e-05) ) ) {
                result[0] += -1.844583324980468e-07;
              } else {
                result[0] += -1.844583324980468e-07;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -1.844583324980468e-07;
                  } else {
                    result[0] += -1.844583324980468e-07;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -1.844583324980468e-07;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -1.844583324980468e-07;
                        } else {
                          result[0] += -1.844583324980468e-07;
                        }
                      } else {
                        result[0] += -1.844583324980468e-07;
                      }
                    }
                  } else {
                    result[0] += -1.844583324980468e-07;
                  }
                }
              } else {
                result[0] += -1.844583324980468e-07;
              }
            }
          } else {
            result[0] += -1.844583324980468e-07;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -1.844583324980468e-07;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -1.844583324980468e-07;
                } else {
                  result[0] += -1.844583324980468e-07;
                }
              } else {
                result[0] += -1.844583324980468e-07;
              }
            } else {
              result[0] += -1.844583324980468e-07;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9450000000000000622) ) ) {
        result[0] += 6.208439645237076e-07;
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.00010629262199710006;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2929122217587940002) ) ) {
            result[0] += -0.0003371707540894056;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3763200711443456803) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9750000000000000888) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1250629713251516228) ) ) {
                  result[0] += 0.0010850880487490843;
                } else {
                  result[0] += 2.4299920831684956e-05;
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5719332634924624292) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08407783631914581002) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
                        result[0] += -8.842282278767057e-05;
                      } else {
                        result[0] += 0.00014490604589519412;
                      }
                    } else {
                      result[0] += -0.00046625380584400846;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2533229942273665936) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5859181088693469208) ) ) {
                        result[0] += 0.00035771293137295233;
                      } else {
                        result[0] += -1.3240006167127561e-05;
                      }
                    } else {
                      result[0] += 0.0003235554667962208;
                    }
                  }
                } else {
                  result[0] += 0.00011197954890010456;
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5834559473869348478) ) ) {
                result[0] += -0.0018841361283566964;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08666957264163686891) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9993516786272610419) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7425707671105529206) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7210440605025126848) ) ) {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6577150591959800563) ) ) {
                          result[0] += -0.00029438964782461393;
                        } else {
                          result[0] += 0.0003423231748996487;
                        }
                      } else {
                        result[0] += -0.0003971507989808464;
                      }
                    } else {
                      result[0] += 0.000692140970709042;
                    }
                  } else {
                    result[0] += -0.0009807393493493747;
                  }
                } else {
                  result[0] += 0.00015962450212422743;
                }
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -1.7711603405098426e-07;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.7711603405098426e-07;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -1.7711603405098426e-07;
              } else {
                result[0] += -1.7711603405098426e-07;
              }
            }
          }
        } else {
          result[0] += -1.3115671828529234e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.384300133116745416e-05) ) ) {
                result[0] += -1.7711603405098426e-07;
              } else {
                result[0] += -1.7711603405098426e-07;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -1.7711603405098426e-07;
                  } else {
                    result[0] += -1.7711603405098426e-07;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -1.7711603405098426e-07;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -1.7711603405098426e-07;
                        } else {
                          result[0] += -1.7711603405098426e-07;
                        }
                      } else {
                        result[0] += -1.7711603405098426e-07;
                      }
                    }
                  } else {
                    result[0] += -1.7711603405098426e-07;
                  }
                }
              } else {
                result[0] += -1.7711603405098426e-07;
              }
            }
          } else {
            result[0] += -1.7711603405098426e-07;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -1.7711603405098426e-07;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -1.7711603405098426e-07;
                } else {
                  result[0] += -1.7711603405098426e-07;
                }
              } else {
                result[0] += -1.7711603405098426e-07;
              }
            } else {
              result[0] += -1.7711603405098426e-07;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9450000000000000622) ) ) {
        result[0] += 5.961314908994413e-07;
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.000102061681909685;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2929122217587940002) ) ) {
              result[0] += -0.00041540333187706756;
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4734952854020100799) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004460500000000000922) ) ) {
                    result[0] += 0.00020217664941129073;
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2428155000000000174) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03873000000000000748) ) ) {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00583050000000000148) ) ) {
                          result[0] += -0.00019522364975911333;
                        } else {
                          result[0] += 0.00020426794580321312;
                        }
                      } else {
                        result[0] += -0.0001381552151203963;
                      }
                    } else {
                      result[0] += 0.00016920334005726554;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4797597438944724013) ) ) {
                    result[0] += 0.000537208739277388;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4838161673366834781) ) ) {
                      result[0] += -0.0001980631312207536;
                    } else {
                      result[0] += 0.00019341439489589684;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4693879269597989734) ) ) {
                  result[0] += -0.0026137470414237906;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.51994285276381913) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0816878293504414571) ) ) {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03603011311338780859) ) ) {
                        result[0] += -0.00014024278020749784;
                      } else {
                        result[0] += 0.0003798891940282606;
                      }
                    } else {
                      result[0] += -0.0007340796199237686;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.04446937286580055632) ) ) {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005372500000000001406) ) ) {
                        result[0] += -9.503704661360252e-05;
                      } else {
                        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.08377477200961473691) ) ) {
                          result[0] += -7.091339707474617e-05;
                        } else {
                          result[0] += 0.00027954302230059094;
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5612777274623116375) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09956041386891252565) ) ) {
                          result[0] += 0.0003368570956341444;
                        } else {
                          result[0] += -0.001376113266864714;
                        }
                      } else {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002965500000000000688) ) ) {
                          result[0] += -0.000640984007618883;
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5508018452917812224) ) ) {
                            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06008500000000000646) ) ) {
                              result[0] += 0.00027453254746995345;
                            } else {
                              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.09229200000000001292) ) ) {
                                result[0] += -0.0006680400231170483;
                              } else {
                                result[0] += 0.00030351548889012567;
                              }
                            }
                          } else {
                            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5986852915639623296) ) ) {
                              result[0] += -0.0004504207053524498;
                            } else {
                              result[0] += 8.07437708138484e-05;
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          } else {
            result[0] += 0.00010752224270603224;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -1.7006599318727762e-07;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.7006599318727762e-07;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += -1.7006599318727762e-07;
              } else {
                result[0] += -1.7006599318727762e-07;
              }
            }
          }
        } else {
          result[0] += -1.2593607167124948e-08;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.384300133116745416e-05) ) ) {
                result[0] += -1.7006599318727762e-07;
              } else {
                result[0] += -1.7006599318727762e-07;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -1.7006599318727762e-07;
                  } else {
                    result[0] += -1.7006599318727762e-07;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -1.7006599318727762e-07;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -1.7006599318727762e-07;
                        } else {
                          result[0] += -1.7006599318727762e-07;
                        }
                      } else {
                        result[0] += -1.7006599318727762e-07;
                      }
                    }
                  } else {
                    result[0] += -1.7006599318727762e-07;
                  }
                }
              } else {
                result[0] += -1.7006599318727762e-07;
              }
            }
          } else {
            result[0] += -1.7006599318727762e-07;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -1.7006599318727762e-07;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -1.7006599318727762e-07;
                } else {
                  result[0] += -1.7006599318727762e-07;
                }
              } else {
                result[0] += -1.7006599318727762e-07;
              }
            } else {
              result[0] += -1.7006599318727762e-07;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3115605993075549196) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2888738239382729889) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2739990068871500095) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.146109394227906586) ) ) {
                result[0] += 0.00040723776836418154;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3150000000000000577) ) ) {
                  result[0] += -1.0053600882023055e-05;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3550000000000000377) ) ) {
                    result[0] += 0.0004858941660602717;
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3850000000000000644) ) ) {
                      result[0] += -0.0001509446230419495;
                    } else {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4250000000000000444) ) ) {
                        result[0] += 0.0008632215550894622;
                      } else {
                        result[0] += 5.2639869378418867e-05;
                      }
                    }
                  }
                }
              }
            } else {
              result[0] += -0.0003812578763319933;
            }
          } else {
            result[0] += 0.00035991873535836256;
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3466557816143853721) ) ) {
            result[0] += -0.00024811801415022805;
          } else {
            result[0] += -6.510271298467558e-07;
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 9.79991528905723e-05;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004460500000000000922) ) ) {
              result[0] += 0.00013776112485115502;
            } else {
              result[0] += 7.966238395384112e-05;
            }
          } else {
            result[0] += 0.00010324235800278273;
          }
        }
      }
    }
  }
}

