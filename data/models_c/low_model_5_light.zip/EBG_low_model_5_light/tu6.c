
#include "header.h"

void predict_unit6(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -8.062234258581571e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -8.062234258581571e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                result[0] += -8.062234258581571e-06;
              } else {
                result[0] += -8.062234258581571e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6802634857286432579) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4781247323869347032) ) ) {
              result[0] += 6.494623481873425e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6425364825628142595) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5674119023366835934) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.020650504707780553) ) ) {
                    result[0] += -5.5398991282585395e-05;
                  } else {
                    result[0] += 1.5608008835876543e-05;
                  }
                } else {
                  result[0] += -1.2822147772364388e-05;
                }
              } else {
                result[0] += 2.9666765230051546e-05;
              }
            }
          } else {
            result[0] += -2.0765699660057188e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -8.062234258581571e-06;
              } else {
                result[0] += -8.062234258581571e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -8.062234258581571e-06;
                  } else {
                    result[0] += -8.062234258581571e-06;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -8.062234258581571e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -8.062234258581571e-06;
                        } else {
                          result[0] += -8.062234258581571e-06;
                        }
                      } else {
                        result[0] += -8.062234258581571e-06;
                      }
                    }
                  } else {
                    result[0] += -8.062234258581571e-06;
                  }
                }
              } else {
                result[0] += -8.062234258581571e-06;
              }
            }
          } else {
            result[0] += -8.062234258581571e-06;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -8.062234258581571e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -8.062234258581571e-06;
                } else {
                  result[0] += -8.062234258581571e-06;
                }
              } else {
                result[0] += -8.062234258581571e-06;
              }
            } else {
              result[0] += -8.062234258581571e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8850000000000001199) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3115605993075549196) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01359050000000000188) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)5.045799003287211847e-06) ) ) {
                  result[0] += 1.6113676399444494e-05;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0007504883022448001527) ) ) {
                    result[0] += -4.474251054684174e-05;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006626010166593451593) ) ) {
                      result[0] += 0.00035916242551222756;
                    } else {
                      result[0] += -0.00013467198278124123;
                    }
                  }
                }
              } else {
                result[0] += 0.0003314429999611439;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.578971790991679312e-05) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7149244603266332598) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6881801856532664408) ) ) {
                      result[0] += -7.4704670200887725e-06;
                    } else {
                      result[0] += -1.709869081665062e-05;
                    }
                  } else {
                    result[0] += 5.4559207299551294e-05;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.097216905567068856) ) ) {
                      result[0] += -1.7532857881480237e-05;
                    } else {
                      result[0] += -9.562671904702823e-06;
                    }
                  } else {
                    result[0] += -8.062234258581571e-06;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6532207681155780543) ) ) {
                  result[0] += -0.00011313309211331198;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8419399877135679278) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8022705390703518402) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
                        result[0] += 1.6414176961823876e-05;
                      } else {
                        result[0] += -6.61655447032243e-05;
                      }
                    } else {
                      result[0] += 8.355732539296194e-05;
                    }
                  } else {
                    result[0] += -8.062234258581571e-06;
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9808239647505231362) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1050000000000000239) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1738383111593791719) ) ) {
                  result[0] += -0.0001451106215449432;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5986852915639623296) ) ) {
                    result[0] += 0.00024986301664952547;
                  } else {
                    result[0] += -8.346698541955039e-05;
                  }
                }
              } else {
                result[0] += 0.0011700850129925913;
              }
            } else {
              result[0] += 0.0002765183257170229;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5050000000000001155) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002339521674937150662) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001074448343160400252) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4450000000000000622) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8282572652763819931) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4251092621105527214) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4052145559547739029) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3644118032412060892) ) ) {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.317357466959798995) ) ) {
                            result[0] += -5.201982778208085e-05;
                          } else {
                            result[0] += 0.001098844273388898;
                          }
                        } else {
                          result[0] += -0.0008468713439253978;
                        }
                      } else {
                        result[0] += 0.000886784135009947;
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5528143519346734314) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5449942632663317132) ) ) {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5072261056783921029) ) ) {
                            result[0] += -0.00010662850766320273;
                          } else {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5190499213819096402) ) ) {
                              result[0] += 0.0003336227109755501;
                            } else {
                              result[0] += 6.0959931485051195e-06;
                            }
                          }
                        } else {
                          result[0] += -0.00024531739737574017;
                        }
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5745673188442211865) ) ) {
                          result[0] += 0.0006233873330616538;
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6077784371608041525) ) ) {
                            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.590591194899497629) ) ) {
                              result[0] += 2.2788605240594505e-05;
                            } else {
                              result[0] += -0.00012802579740233048;
                            }
                          } else {
                            result[0] += 7.143450876576286e-06;
                          }
                        }
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8643464628140704598) ) ) {
                      result[0] += -0.00015228562947951452;
                    } else {
                      result[0] += 1.0589164959494975e-05;
                    }
                  }
                } else {
                  result[0] += 0.0016033456073985032;
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08500000000000000611) ) ) {
                  result[0] += -0.0003894337886692391;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1550000000000000266) ) ) {
                    result[0] += 0.0006026629784178343;
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0008045000000000002019) ) ) {
                      result[0] += 5.5596255860060014e-05;
                    } else {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001499500000000000182) ) ) {
                        result[0] += -0.0008346560534966669;
                      } else {
                        result[0] += -0.0001096199000383826;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.96280210579579717) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4850000000000000422) ) ) {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2795185878002977575) ) ) {
                      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4026472078210281969) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4347441410050251753) ) ) {
                          result[0] += 0.0008073886460307657;
                        } else {
                          result[0] += -0.0005423772168530138;
                        }
                      } else {
                        result[0] += 0.0010132410633885878;
                      }
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6732382808793971884) ) ) {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0416474308606116575) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3966559369710560001) ) ) {
                            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3466557816143853721) ) ) {
                              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2177889902755587859) ) ) {
                                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2350000000000000144) ) ) {
                                  result[0] += -0.0009262602977204006;
                                } else {
                                  result[0] += 0.00030723279999020906;
                                }
                              } else {
                                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2739990068871500095) ) ) {
                                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1908722399174398732) ) ) {
                                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05463331189772155372) ) ) {
                                      result[0] += 0.0003312850020639519;
                                    } else {
                                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1129321246270776624) ) ) {
                                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09956041386891252565) ) ) {
                                          result[0] += -7.126849888368242e-05;
                                        } else {
                                          result[0] += -0.0009004161225508466;
                                        }
                                      } else {
                                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1206324332205917643) ) ) {
                                          result[0] += 0.0011321274626181804;
                                        } else {
                                          result[0] += -2.0481605864811374e-05;
                                        }
                                      }
                                    }
                                  } else {
                                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.243144592614154248) ) ) {
                                      result[0] += 0.0007742186088099398;
                                    } else {
                                      result[0] += -3.6682834983607646e-06;
                                    }
                                  }
                                } else {
                                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01444878842564100048) ) ) {
                                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007107894154605750962) ) ) {
                                      result[0] += -6.393844003431057e-05;
                                    } else {
                                      result[0] += -0.0006124668826199463;
                                    }
                                  } else {
                                    result[0] += 0.0007333566759530129;
                                  }
                                }
                              }
                            } else {
                              result[0] += 0.0011735029594211715;
                            }
                          } else {
                            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4287309711685468594) ) ) {
                              result[0] += -0.000889763590523571;
                            } else {
                              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6647073645226131422) ) ) {
                                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6481803955276382867) ) ) {
                                  result[0] += -2.8560235373365503e-06;
                                } else {
                                  result[0] += 0.0006939858819376001;
                                }
                              } else {
                                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5508018452917812224) ) ) {
                                  result[0] += -0.000451574939702384;
                                } else {
                                  result[0] += 9.886519481527755e-05;
                                }
                              }
                            }
                          }
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.531569796683417195) ) ) {
                            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5041457217085428821) ) ) {
                              result[0] += 0.0023523185372215966;
                            } else {
                              result[0] += -0.0008001397129969809;
                            }
                          } else {
                            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2145423861003193655) ) ) {
                              result[0] += 0.0018613928590911393;
                            } else {
                              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3763200711443456803) ) ) {
                                result[0] += -0.0005408427705508093;
                              } else {
                                result[0] += 0.0012355774364854592;
                              }
                            }
                          }
                        }
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6836184685175880071) ) ) {
                          result[0] += 0.0013710657720590734;
                        } else {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03500000000000001027) ) ) {
                            result[0] += -1.6175636448269236e-05;
                          } else {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1750000000000000167) ) ) {
                              result[0] += 0.0007170988259181379;
                            } else {
                              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
                                result[0] += 0.0002506528427847785;
                              } else {
                                result[0] += -0.0002444993508746751;
                              }
                            }
                          }
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008332142139858200389) ) ) {
                      result[0] += -0.0003151635597804694;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0240756843176193544) ) ) {
                        result[0] += 0.0007611366308830148;
                      } else {
                        result[0] += -0.0009917467793416543;
                      }
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7890731911809046872) ) ) {
                    result[0] += -0.00018662177941410768;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02661305910200095423) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.314196657149456993) ) ) {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008157865216470052208) ) ) {
                          result[0] += 0.00019566473022492414;
                        } else {
                          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01170971943545395279) ) ) {
                            result[0] += -0.0003506791624285161;
                          } else {
                            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01822956926157560595) ) ) {
                              result[0] += 0.0001791854704341471;
                            } else {
                              result[0] += -0.00025778024117299855;
                            }
                          }
                        }
                      } else {
                        result[0] += 0.00015297764069216284;
                      }
                    } else {
                      result[0] += 0.0005459961363981923;
                    }
                  }
                }
              } else {
                result[0] += -0.0005487799092743072;
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001653500000000000239) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5550000000000001599) ) ) {
                result[0] += -0.000337622884543493;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001350500000000000355) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.052300094327177008e-06) ) ) {
                    result[0] += -0.00033011461380955554;
                  } else {
                    result[0] += 0.0007573564748567968;
                  }
                } else {
                  result[0] += 0.001006697697915827;
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006290243127013950622) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002237500000000000339) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002867412157011550635) ) ) {
                    result[0] += 0.00019692437821374406;
                  } else {
                    result[0] += 0.0009457611754973722;
                  }
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00424585153689335023) ) ) {
                    result[0] += 1.303258413442007e-05;
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004867285882244350333) ) ) {
                      result[0] += -0.000841095188431575;
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.020650504707780553) ) ) {
                        result[0] += 0.0005189619335548159;
                      } else {
                        result[0] += -0.0003266672616059449;
                      }
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06508917425002432033) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.063944343817919913) ) ) {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.008306500000000001382) ) ) {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001980500000000000489) ) ) {
                          result[0] += -0.0001260236827590566;
                        } else {
                          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004371500000000001253) ) ) {
                            result[0] += 0.001301367242645495;
                          } else {
                            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005707500000000000767) ) ) {
                              result[0] += -7.46632849935545e-05;
                            } else {
                              result[0] += 0.0012642571364820387;
                            }
                          }
                        }
                      } else {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01085750000000000083) ) ) {
                          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9550000000000000711) ) ) {
                            result[0] += -0.0006564883713798177;
                          } else {
                            result[0] += 0.0013551702004749161;
                          }
                        } else {
                          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9150000000000001465) ) ) {
                            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.08110515786938453375) ) ) {
                              result[0] += 0.001045057100698952;
                            } else {
                              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7350000000000000977) ) ) {
                                result[0] += 0.0024195287259914746;
                              } else {
                                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8950000000000001288) ) ) {
                                  result[0] += -0.00015619282814781588;
                                } else {
                                  result[0] += 0.0020188850206478356;
                                }
                              }
                            }
                          } else {
                            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.378188349821562797) ) ) {
                              result[0] += -0.0017694157303154963;
                            } else {
                              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.06355808660527756393) ) ) {
                                result[0] += 0.0013265737968565056;
                              } else {
                                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.564374608675820677) ) ) {
                                  result[0] += -0.0011029348481378307;
                                } else {
                                  result[0] += 0.000651742623613825;
                                }
                              }
                            }
                          }
                        }
                      }
                    } else {
                      result[0] += 0.0013988403852093756;
                    }
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06949760265420222571) ) ) {
                      result[0] += 0.002125617726357729;
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1168105000000000254) ) ) {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03545400000000000634) ) ) {
                          result[0] += 0.0015748501938758533;
                        } else {
                          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05311250000000000693) ) ) {
                            result[0] += -0.0010593638744873285;
                          } else {
                            result[0] += 0.0021920211139119295;
                          }
                        }
                      } else {
                        result[0] += 0.0035727891420125417;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04953562823777350743) ) ) {
                    result[0] += 0.00013549562983417704;
                  } else {
                    result[0] += -0.0007618009213476782;
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3837516359296482826) ) ) {
            if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6269304705026225166) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003091000000000000431) ) ) {
                result[0] += 0.0037624051716730043;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01129950000000000225) ) ) {
                  result[0] += -0.0010383665433000766;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03240100000000000618) ) ) {
                    result[0] += 0.004250675020908005;
                  } else {
                    result[0] += 0.0021427107045790556;
                  }
                }
              }
            } else {
              result[0] += -0.0022380239495413254;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01332150000000000174) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008506177121675452882) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006124087708088651362) ) ) {
                  result[0] += 0.0031058757587357137;
                } else {
                  result[0] += -0.00017986191643089872;
                }
              } else {
                result[0] += 0.0036024827912042837;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04953562823777350743) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1587324468652908105) ) ) {
                  result[0] += 0.002607335279259301;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01542071772829775068) ) ) {
                    result[0] += -0.0008709406611962375;
                  } else {
                    result[0] += 0.00029632056767268217;
                  }
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9808239647505231362) ) ) {
                  result[0] += 0.0026532725865532182;
                } else {
                  result[0] += 0.0005857911192115985;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01881166515770610337) ) ) {
            if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2302999793555680907) ) ) {
              result[0] += 0.004333167227721109;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5153685380402011074) ) ) {
                result[0] += -0.0019760442932556022;
              } else {
                result[0] += 0.0027019485313334785;
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1206324332205917643) ) ) {
              result[0] += 0.0035844452175434706;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06081637682680595541) ) ) {
                result[0] += 0.001813551272716198;
              } else {
                result[0] += 0.003186399146896115;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -7.741319885807088e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -7.741319885807088e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                result[0] += -7.741319885807088e-06;
              } else {
                result[0] += -7.741319885807088e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6802634857286432579) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4781247323869347032) ) ) {
              result[0] += 6.236107299603811e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6425364825628142595) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5674119023366835934) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.020650504707780553) ) ) {
                    result[0] += -5.319385409981667e-05;
                  } else {
                    result[0] += 1.4986737584611111e-05;
                  }
                } else {
                  result[0] += -1.2311766731822177e-05;
                }
              } else {
                result[0] += 2.848589017101734e-05;
              }
            }
          } else {
            result[0] += -1.9939128356384474e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -7.741319885807088e-06;
              } else {
                result[0] += -7.741319885807088e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -7.741319885807088e-06;
                  } else {
                    result[0] += -7.741319885807088e-06;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -7.741319885807088e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -7.741319885807088e-06;
                        } else {
                          result[0] += -7.741319885807088e-06;
                        }
                      } else {
                        result[0] += -7.741319885807088e-06;
                      }
                    }
                  } else {
                    result[0] += -7.741319885807088e-06;
                  }
                }
              } else {
                result[0] += -7.741319885807088e-06;
              }
            }
          } else {
            result[0] += -7.741319885807088e-06;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -7.741319885807088e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -7.741319885807088e-06;
                } else {
                  result[0] += -7.741319885807088e-06;
                }
              } else {
                result[0] += -7.741319885807088e-06;
              }
            } else {
              result[0] += -7.741319885807088e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8850000000000001199) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.578971790991679312e-05) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                  result[0] += -2.658946964204769e-07;
                } else {
                  result[0] += -2.3453390685468572e-05;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.097216905567068856) ) ) {
                    result[0] += -1.683496869722708e-05;
                  } else {
                    result[0] += -9.18203314404173e-06;
                  }
                } else {
                  result[0] += -7.741319885807088e-06;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2739990068871500095) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003504500000000000236) ) ) {
                  result[0] += -1.1311480216816725e-05;
                } else {
                  result[0] += 0.0002816706270816073;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4287309711685468594) ) ) {
                  result[0] += -0.00011614638495791295;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                    result[0] += 0.0002906271146251903;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7894192122613066243) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
                        result[0] += -8.048671734371425e-06;
                      } else {
                        result[0] += -0.00011604068655221926;
                      }
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
                        result[0] += 9.354808093134112e-05;
                      } else {
                        result[0] += -7.741319885807088e-06;
                      }
                    }
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9808239647505231362) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5986852915639623296) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3212986210119083141) ) ) {
                  result[0] += -1.325789401488202e-06;
                } else {
                  result[0] += 0.0004783642191537852;
                }
              } else {
                result[0] += -9.976441623450284e-05;
              }
            } else {
              result[0] += 0.000265511611918838;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4950000000000000511) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004099190464141650413) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003941149135554950639) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4693879269597989734) ) ) {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7983975536720421262) ) ) {
                      result[0] += -9.431210459280118e-05;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3569067370100503234) ) ) {
                        result[0] += 0.000654391070059385;
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4052145559547739029) ) ) {
                          result[0] += -0.00011262666013535572;
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.421180086331658321) ) ) {
                            result[0] += 0.0005930991881327645;
                          } else {
                            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4636504894974874946) ) ) {
                              result[0] += -2.479083709201506e-06;
                            } else {
                              result[0] += 0.0007868295777392519;
                            }
                          }
                        }
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0006710000000000000469) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4908111093216080412) ) ) {
                        result[0] += -0.0002906271533299449;
                      } else {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8507017292462312197) ) ) {
                          result[0] += 1.0211194930947414e-05;
                        } else {
                          result[0] += -0.00013944041461803707;
                        }
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003719500000000000584) ) ) {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003024500000000000712) ) ) {
                          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002579500000000000629) ) ) {
                            result[0] += -0.00016254352239018446;
                          } else {
                            result[0] += 0.0008426157605765584;
                          }
                        } else {
                          result[0] += -0.0001775588561317296;
                        }
                      } else {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005473500000000000067) ) ) {
                          result[0] += 0.0003791586444224733;
                        } else {
                          result[0] += -8.15314429804029e-05;
                        }
                      }
                    }
                  }
                } else {
                  result[0] += -0.0005314176927937244;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5508018452917812224) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6577150591959800563) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4287309711685468594) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4036106884780860105) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3466557816143853721) ) ) {
                            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3115605993075549196) ) ) {
                              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2795185878002977575) ) ) {
                                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4635963316561722558) ) ) {
                                  result[0] += 0.00022851193806117226;
                                } else {
                                  result[0] += 0.0009866603809381438;
                                }
                              } else {
                                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.244955337349149066) ) ) {
                                  result[0] += -0.0005013868803088902;
                                } else {
                                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1643367459977091716) ) ) {
                                    result[0] += 0.00016769110739411146;
                                  } else {
                                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2323027026914575854) ) ) {
                                      result[0] += 0.0009437841740966667;
                                    } else {
                                      result[0] += 0.00010454605191737049;
                                    }
                                  }
                                }
                              }
                            } else {
                              result[0] += -0.0005964922283267551;
                            }
                          } else {
                            result[0] += 0.0009883808213963293;
                          }
                        } else {
                          result[0] += -0.0004565331674081678;
                        }
                      } else {
                        result[0] += 0.0010088686314219325;
                      }
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6722423356281408413) ) ) {
                        result[0] += -0.00047680026397100493;
                      } else {
                        result[0] += 0.00015703348135794292;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.051391296366422923) ) ) {
                      result[0] += 0.0002999349538806811;
                    } else {
                      result[0] += -0.00014151348057067048;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7954292854522614364) ) ) {
                    result[0] += -0.00012172237313558161;
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004132000000000001123) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.234671350732867934) ) ) {
                        result[0] += -0.00039218705891769077;
                      } else {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002154500000000000599) ) ) {
                          result[0] += 0.0006286160007757289;
                        } else {
                          result[0] += -3.951556658921174e-05;
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
                        result[0] += 0.0008052273303436125;
                      } else {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04562750000000000833) ) ) {
                          result[0] += -0.0005914960254880091;
                        } else {
                          result[0] += 0.0005775711356413277;
                        }
                      }
                    }
                  }
                }
              }
            } else {
              result[0] += -0.00031221449558435323;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003965500000000001142) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00135663295830650032) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6802634857286432579) ) ) {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1126213758155867467) ) ) {
                    if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3539353041941689093) ) ) {
                      result[0] += -0.0004929425282603897;
                    } else {
                      result[0] += 0.00164635986275289;
                    }
                  } else {
                    result[0] += -0.00036609256567249213;
                  }
                } else {
                  result[0] += 0.0014418258141315492;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.767254320477387064) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001653500000000000239) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001306500000000000153) ) ) {
                      result[0] += 0.0008056899822452028;
                    } else {
                      result[0] += 0.0011262911949444568;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6784611311055277483) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5701775282412061552) ) ) {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001980500000000000489) ) ) {
                          result[0] += -0.0003086385291235655;
                        } else {
                          result[0] += 0.001072250043973883;
                        }
                      } else {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003226000000000000135) ) ) {
                          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002154500000000000599) ) ) {
                            result[0] += 0.0003806818683286989;
                          } else {
                            result[0] += -0.0006921005377362949;
                          }
                        } else {
                          result[0] += 0.0012490737233853445;
                        }
                      }
                    } else {
                      result[0] += 0.001907409353662741;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02261952378991480619) ) ) {
                    result[0] += 0.00019627013830778633;
                  } else {
                    result[0] += -0.00014384614260536756;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006290243127013950622) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002867412157011550635) ) ) {
                  result[0] += 0.0009072571490151198;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5392784256532664466) ) ) {
                    result[0] += -0.0008638189257226505;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6059258460552764403) ) ) {
                      result[0] += 0.0008894978515761275;
                    } else {
                      result[0] += -0.0006723179665801182;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1304295000000000038) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4129968667336683663) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3044676633919599085) ) ) {
                      result[0] += 0.0008371025530422907;
                    } else {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9450000000000000622) ) ) {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02192319026750580435) ) ) {
                          result[0] += 0.000758539940085154;
                        } else {
                          result[0] += -4.800544332433995e-05;
                        }
                      } else {
                        result[0] += -0.0016293581701279736;
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5361772370603016258) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5179236987437186857) ) ) {
                        result[0] += 0.0007580092773395711;
                      } else {
                        result[0] += 0.0021824750652084017;
                      }
                    } else {
                      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7150000000000000799) ) ) {
                        result[0] += 0.001993898275134129;
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4364163272837385255) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3251271839107726103) ) ) {
                            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03350035677887956004) ) ) {
                              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5455059598241206453) ) ) {
                                result[0] += -0.0013084244641848564;
                              } else {
                                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2326999203141443262) ) ) {
                                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5612777274623116375) ) ) {
                                    result[0] += 0.0011418068205980717;
                                  } else {
                                    result[0] += -0.0003428651286230438;
                                  }
                                } else {
                                  result[0] += 0.0025266030749808745;
                                }
                              }
                            } else {
                              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
                                result[0] += 0.002082318020791344;
                              } else {
                                result[0] += -0.0002054564348842037;
                              }
                            }
                          } else {
                            result[0] += -0.0018877648897368158;
                          }
                        } else {
                          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5018975334485012985) ) ) {
                            result[0] += 0.0021768633190944985;
                          } else {
                            result[0] += 0.0005144539055545707;
                          }
                        }
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7640286906783920751) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07136094095721451369) ) ) {
                      result[0] += 0.002995431059363908;
                    } else {
                      result[0] += 0.004228314600363568;
                    }
                  } else {
                    result[0] += 3.797661021391289e-05;
                  }
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05473596564878090848) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002710500000000000669) ) ) {
            result[0] += 0.004141159193138575;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2145423861003193655) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01351316588546045208) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007787546829340650199) ) ) {
                      result[0] += 0.0007391363214135039;
                    } else {
                      result[0] += -0.0005755196733443325;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4347441410050251753) ) ) {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03350035677887956004) ) ) {
                        result[0] += 0.002413787319348478;
                      } else {
                        result[0] += -0.0007526883282353344;
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4814085394974874643) ) ) {
                        result[0] += 0.0036857206444654367;
                      } else {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5493276582412061071) ) ) {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.52572947701005035) ) ) {
                            result[0] += 0.0019455626962456716;
                          } else {
                            result[0] += -0.00036162631563026285;
                          }
                        } else {
                          result[0] += 0.0024270868555258027;
                        }
                      }
                    }
                  }
                } else {
                  result[0] += -0.0010213112688737091;
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02031150000000000316) ) ) {
                  result[0] += 0.0026257966180542277;
                } else {
                  result[0] += 0.0014081361454255526;
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01881166515770610337) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.05751864358971629093) ) ) {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
                    result[0] += 0.004869273458409011;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3837516359296482826) ) ) {
                      result[0] += -0.0002560655940967633;
                    } else {
                      result[0] += 0.0025442212874049095;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5748180127889448432) ) ) {
                    result[0] += -0.0026494048351994623;
                  } else {
                    result[0] += 0.0018604947402368727;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01287800000000000229) ) ) {
                  result[0] += 0.003974201216644257;
                } else {
                  result[0] += 0.002536641323543559;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3998546246231156065) ) ) {
              result[0] += -0.00016124276533303477;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03468100000000001043) ) ) {
                  result[0] += 0.0036234023497830397;
                } else {
                  result[0] += 0.0022095749645567172;
                }
              } else {
                result[0] += 0.0001344939562305426;
              }
            }
          } else {
            result[0] += 0.003439127895267791;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -7.433179395724442e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -7.433179395724442e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                result[0] += -7.433179395724442e-06;
              } else {
                result[0] += -7.433179395724442e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6802634857286432579) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4781247323869347032) ) ) {
              result[0] += 5.987881262202754e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6425364825628142595) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5674119023366835934) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.020650504707780553) ) ) {
                    result[0] += -5.107649161984039e-05;
                  } else {
                    result[0] += 1.4390195814966793e-05;
                  }
                } else {
                  result[0] += -1.182170122742646e-05;
                }
              } else {
                result[0] += 2.7352019424527398e-05;
              }
            }
          } else {
            result[0] += -1.9145458430042642e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -7.433179395724442e-06;
              } else {
                result[0] += -7.433179395724442e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -7.433179395724442e-06;
                  } else {
                    result[0] += -7.433179395724442e-06;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -7.433179395724442e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -7.433179395724442e-06;
                        } else {
                          result[0] += -7.433179395724442e-06;
                        }
                      } else {
                        result[0] += -7.433179395724442e-06;
                      }
                    }
                  } else {
                    result[0] += -7.433179395724442e-06;
                  }
                }
              } else {
                result[0] += -7.433179395724442e-06;
              }
            }
          } else {
            result[0] += -7.433179395724442e-06;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -7.433179395724442e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -7.433179395724442e-06;
                } else {
                  result[0] += -7.433179395724442e-06;
                }
              } else {
                result[0] += -7.433179395724442e-06;
              }
            } else {
              result[0] += -7.433179395724442e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8150000000000000577) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.578971790991679312e-05) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                  result[0] += -2.5531085241532513e-07;
                } else {
                  result[0] += -2.2519836794591422e-05;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
                    result[0] += -7.316107928010412e-06;
                  } else {
                    result[0] += -0.00012007246860950887;
                  }
                } else {
                  result[0] += -7.433179395724442e-06;
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003690377133234250349) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001504690974371400121) ) ) {
                  result[0] += -7.2636379530984245e-06;
                } else {
                  result[0] += 0.00013596698579841935;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2888738239382729889) ) ) {
                  result[0] += 4.061241147565631e-05;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7894192122613066243) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7519737796733669821) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6914593314070353047) ) ) {
                        result[0] += -6.522064006916106e-05;
                      } else {
                        result[0] += 1.7910577266682887e-05;
                      }
                    } else {
                      result[0] += -0.00011584733659677666;
                    }
                  } else {
                    result[0] += 1.2558349072530698e-05;
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9808239647505231362) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1050000000000000239) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3763200711443456803) ) ) {
                  result[0] += -3.6518185089248505e-05;
                } else {
                  result[0] += 6.916267877879211e-05;
                }
              } else {
                result[0] += 0.0011168799887580512;
              }
            } else {
              result[0] += 0.00025494301645628603;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4950000000000000511) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4693879269597989734) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01622350000000000528) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01278116174711865262) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.690815535104635854e-06) ) ) {
                    result[0] += -8.976299089536878e-05;
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1450000000000000455) ) ) {
                      result[0] += 0.0005950508953472945;
                    } else {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4150000000000000355) ) ) {
                        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3550000000000000377) ) ) {
                          result[0] += 0.00017220007559326663;
                        } else {
                          result[0] += -0.00022105438513326563;
                        }
                      } else {
                        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4850000000000000422) ) ) {
                          result[0] += 0.0010688631957641661;
                        } else {
                          result[0] += 0.000592776250101937;
                        }
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4450000000000000622) ) ) {
                    result[0] += -0.0008137892547522024;
                  } else {
                    result[0] += 0.000845979301232059;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01397330054109465099) ) ) {
                  result[0] += 0.00030785642843404374;
                } else {
                  result[0] += 0.0017140331889492714;
                }
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8507017292462312197) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02577363736079425413) ) ) {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6050000000000000933) ) ) {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02446805795595660346) ) ) {
                          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002726474613321750156) ) ) {
                            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0007504883022448001527) ) ) {
                              result[0] += 4.435356803330206e-06;
                            } else {
                              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001237226668511850168) ) ) {
                                result[0] += -0.00035224144138678275;
                              } else {
                                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                                  result[0] += 0.0002048876106571546;
                                } else {
                                  result[0] += -0.00012023410501199956;
                                }
                              }
                            }
                          } else {
                            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002998483312272000063) ) ) {
                              result[0] += 0.0007867352710954014;
                            } else {
                              result[0] += 9.3944344320406e-05;
                            }
                          }
                        } else {
                          result[0] += -0.00010349530919203429;
                        }
                      } else {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7875164333668343009) ) ) {
                          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004718492901569751492) ) ) {
                            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.670427493643216188) ) ) {
                              result[0] += -0.00034080983299609265;
                            } else {
                              result[0] += 0.00011487079838683214;
                            }
                          } else {
                            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007787546829340650199) ) ) {
                              result[0] += 0.0010319542993440117;
                            } else {
                              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01397330054109465099) ) ) {
                                result[0] += -0.0009308526198408907;
                              } else {
                                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01822956926157560595) ) ) {
                                  result[0] += 0.0010833798507169097;
                                } else {
                                  result[0] += -0.00012587462273614;
                                }
                              }
                            }
                          }
                        } else {
                          result[0] += -0.0008560789308878422;
                        }
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1149262718553918233) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7269841738944724518) ) ) {
                          result[0] += 0.0005775252899178132;
                        } else {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7954292854522614364) ) ) {
                            result[0] += -0.0001927599650361602;
                          } else {
                            result[0] += 0.0006999307006412558;
                          }
                        }
                      } else {
                        result[0] += -0.00036717057013285596;
                      }
                    }
                  } else {
                    result[0] += -0.0002826003528252993;
                  }
                } else {
                  result[0] += -0.00031505472720717555;
                }
              } else {
                result[0] += 0.00017390175161055186;
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002154500000000000599) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00135663295830650032) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0007504883022448001527) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6481803955276382867) ) ) {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1126213758155867467) ) ) {
                      result[0] += 0.0012142865640741751;
                    } else {
                      result[0] += -0.0007866342425094361;
                    }
                  } else {
                    result[0] += 0.0018014971171580023;
                  }
                } else {
                  result[0] += -0.0003929454930044653;
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02261952378991480619) ) ) {
                  result[0] += 0.0008155471791861155;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05473596564878090848) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02930104421257910194) ) ) {
                      result[0] += -0.0007006319839369481;
                    } else {
                      result[0] += 0.0007164722144176834;
                    }
                  } else {
                    result[0] += 0.0014658843054262511;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006290243127013950622) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3091220225414461065) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002205503205843300455) ) ) {
                    result[0] += 0.001577903649127983;
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006452000000000001137) ) ) {
                      result[0] += 0.00015753428416815082;
                    } else {
                      result[0] += -0.00027899230669231297;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4868404241646586694) ) ) {
                    result[0] += -0.0014687920225008907;
                  } else {
                    result[0] += -1.3232072924151453e-06;
                  }
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.039722088301102687) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3644118032412060892) ) ) {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03127843326018551334) ) ) {
                        result[0] += 0.0014053994446260958;
                      } else {
                        result[0] += -0.001404262425029637;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1304295000000000038) ) ) {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004460500000000000922) ) ) {
                          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002399500000000000157) ) ) {
                            result[0] += -0.0006588908661133266;
                          } else {
                            result[0] += 0.0008915312777882654;
                          }
                        } else {
                          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01148539754569130079) ) ) {
                            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006308000000000001106) ) ) {
                              result[0] += -0.0006052407596108489;
                            } else {
                              result[0] += 0.00011651864611676328;
                            }
                          } else {
                            result[0] += 0.00045823552958063274;
                          }
                        }
                      } else {
                        result[0] += 0.0027011570628768917;
                      }
                    }
                  } else {
                    result[0] += 0.0020235191187364288;
                  }
                } else {
                  result[0] += -0.0003224892331501708;
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4093335132160804135) ) ) {
            if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4323286620486300191) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03705350000000001004) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004867285882244350333) ) ) {
                  result[0] += -9.213238387109495e-05;
                } else {
                  result[0] += 0.0022200856864453477;
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0758825000000000055) ) ) {
                  result[0] += -0.0010934507266139241;
                } else {
                  result[0] += 0.004771266441024094;
                }
              }
            } else {
              result[0] += -0.001805198446964928;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01172600000000000205) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008506177121675452882) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5792515097236182742) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725302343969849939) ) ) {
                    result[0] += 0.0034528862231418354;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5190499213819096402) ) ) {
                      result[0] += -0.0019117080008840544;
                    } else {
                      result[0] += 6.885260900140447e-05;
                    }
                  }
                } else {
                  result[0] += 0.0030490911062904325;
                }
              } else {
                result[0] += 0.003338273054259215;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03350035677887956004) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.505061141934673441) ) ) {
                  result[0] += 0.0020709389307362273;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5455059598241206453) ) ) {
                    result[0] += -0.001553799537200695;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5701775282412061552) ) ) {
                      result[0] += 0.002049905423854629;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6577150591959800563) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3091220225414461065) ) ) {
                          result[0] += -0.0007192892559758924;
                        } else {
                          result[0] += -0.0017170349581760729;
                        }
                      } else {
                        result[0] += 0.001636886605895102;
                      }
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9993516786272610419) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.07196200000000001207) ) ) {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02300100000000000408) ) ) {
                      result[0] += 0.002723421363079863;
                    } else {
                      result[0] += 0.0019206702132043517;
                    }
                  } else {
                    result[0] += 0.0028824702561968886;
                  }
                } else {
                  result[0] += -0.0003462180853186239;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01881166515770610337) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
              result[0] += 0.0046754537568654215;
            } else {
              result[0] += 0.0014832391449846004;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09956041386891252565) ) ) {
                result[0] += 0.003253216774411239;
              } else {
                result[0] += 0.001728531810392778;
              }
            } else {
              result[0] += 0.003320718465523927;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -7.137304328467489e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -7.137304328467489e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                result[0] += -7.137304328467489e-06;
              } else {
                result[0] += -7.137304328467489e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6802634857286432579) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4781247323869347032) ) ) {
              result[0] += 5.749535774106512e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6425364825628142595) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5674119023366835934) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.020650504707780553) ) ) {
                    result[0] += -4.9043410001769655e-05;
                  } else {
                    result[0] += 1.381739917870602e-05;
                  }
                } else {
                  result[0] += -1.1351142606472374e-05;
                }
              } else {
                result[0] += 2.6263282000606147e-05;
              }
            }
          } else {
            result[0] += -1.8383380253386182e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -7.137304328467489e-06;
              } else {
                result[0] += -7.137304328467489e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -7.137304328467489e-06;
                  } else {
                    result[0] += -7.137304328467489e-06;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -7.137304328467489e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -7.137304328467489e-06;
                        } else {
                          result[0] += -7.137304328467489e-06;
                        }
                      } else {
                        result[0] += -7.137304328467489e-06;
                      }
                    }
                  } else {
                    result[0] += -7.137304328467489e-06;
                  }
                }
              } else {
                result[0] += -7.137304328467489e-06;
              }
            }
          } else {
            result[0] += -7.137304328467489e-06;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -7.137304328467489e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -7.137304328467489e-06;
                } else {
                  result[0] += -7.137304328467489e-06;
                }
              } else {
                result[0] += -7.137304328467489e-06;
              }
            } else {
              result[0] += -7.137304328467489e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8150000000000000577) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.578971790991679312e-05) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                  result[0] += -2.451482945637701e-07;
                } else {
                  result[0] += -2.162344268495273e-05;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
                    result[0] += -7.02489284896842e-06;
                  } else {
                    result[0] += -0.0001152930266191835;
                  }
                } else {
                  result[0] += -7.137304328467489e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.321871344966293327) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02563650000000000304) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004460500000000000922) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002194500000000000704) ) ) {
                        result[0] += -1.2434621189412157e-06;
                      } else {
                        result[0] += 4.126739506538795e-05;
                      }
                    } else {
                      result[0] += -2.9025608551974005e-05;
                    }
                  } else {
                    result[0] += 8.433266621019085e-05;
                  }
                } else {
                  result[0] += -7.1440528654083134e-06;
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00342950000000000069) ) ) {
                  result[0] += 1.9336369549382888e-05;
                } else {
                  result[0] += -0.00010974370666909219;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9808239647505231362) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1050000000000000239) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.07500000000000002498) ) ) {
                  result[0] += 1.7298372253056138e-05;
                } else {
                  result[0] += -0.00014276693997920874;
                }
              } else {
                result[0] += 0.0010724229772695608;
              }
            } else {
              result[0] += 0.00024479510018453804;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5050000000000001155) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005013289129500051074) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8327395279648243109) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0006710000000000000469) ) ) {
                    result[0] += 1.569936568240353e-05;
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001306500000000000153) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5224889643718594323) ) ) {
                        result[0] += 0.00019462800919386558;
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5701775282412061552) ) ) {
                          result[0] += -0.0009957988188587221;
                        } else {
                          result[0] += -0.00011356065973058232;
                        }
                      }
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7686690743216081367) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7218051716834171794) ) ) {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3998546246231156065) ) ) {
                            result[0] += -7.176780653377258e-05;
                          } else {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4639489995477387718) ) ) {
                              result[0] += 0.0005754248059567703;
                            } else {
                              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6481803955276382867) ) ) {
                                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5719332634924624292) ) ) {
                                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5336217185678392427) ) ) {
                                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4908111093216080412) ) ) {
                                      result[0] += 0.00028522227527811407;
                                    } else {
                                      result[0] += -0.0009899689858836223;
                                    }
                                  } else {
                                    result[0] += 0.00037939454406384413;
                                  }
                                } else {
                                  result[0] += -0.00021165751108206948;
                                }
                              } else {
                                result[0] += 0.00013601044746664451;
                              }
                            }
                          }
                        } else {
                          result[0] += -0.00017018893387810047;
                        }
                      } else {
                        result[0] += 0.0005607637393829101;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8643464628140704598) ) ) {
                    result[0] += -0.0001712244230371374;
                  } else {
                    result[0] += 1.592638720007045e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6558660377084782889) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6055650374709939943) ) ) {
                        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.316132418552224348) ) ) {
                          if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4635963316561722558) ) ) {
                            result[0] += 0.00019310427476373104;
                          } else {
                            result[0] += 0.0012004889802076227;
                          }
                        } else {
                          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2177889902755587859) ) ) {
                            result[0] += -0.00010557146474287265;
                          } else {
                            result[0] += 0.00015052097793266488;
                          }
                        }
                      } else {
                        result[0] += 0.002047472054517973;
                      }
                    } else {
                      result[0] += -0.0002708705611838719;
                    }
                  } else {
                    result[0] += 0.0003537484048242717;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7954292854522614364) ) ) {
                    result[0] += -0.00010869343823300568;
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004132000000000001123) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.234671350732867934) ) ) {
                        result[0] += -0.00039239049664909327;
                      } else {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002154500000000000599) ) ) {
                          result[0] += 0.0005844920479015446;
                        } else {
                          result[0] += -2.7899088439974272e-05;
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01287800000000000229) ) ) {
                        result[0] += 0.0010269459004806462;
                      } else {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04562750000000000833) ) ) {
                          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02563650000000000304) ) ) {
                            result[0] += 0.00029015511731460877;
                          } else {
                            result[0] += -0.0005576800677309157;
                          }
                        } else {
                          result[0] += 0.0005504468822859028;
                        }
                      }
                    }
                  }
                }
              }
            } else {
              result[0] += -0.00028571110917076684;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.039722088301102687) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9808239647505231362) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003965500000000001142) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001237226668511850168) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6802634857286432579) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5353359946984925788) ) ) {
                          result[0] += 0.0004823982670887317;
                        } else {
                          result[0] += -0.00039314224363297775;
                        }
                      } else {
                        result[0] += 0.00240208003130881;
                      }
                    } else {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001653500000000000239) ) ) {
                        result[0] += 0.0007779108101662834;
                      } else {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001798500000000000185) ) ) {
                          result[0] += -0.00044554577270153095;
                        } else {
                          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003637500000000000542) ) ) {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5515127872864322711) ) ) {
                              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4751828078391960308) ) ) {
                                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4405029099497487777) ) ) {
                                  result[0] += 0.001930882595848089;
                                } else {
                                  result[0] += -0.0002669120132793237;
                                }
                              } else {
                                result[0] += 0.0009867425532758566;
                              }
                            } else {
                              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6717423563567840317) ) ) {
                                result[0] += -0.0001441422582068779;
                              } else {
                                result[0] += 0.0013782388702346306;
                              }
                            }
                          } else {
                            result[0] += 0.0012903596830783934;
                          }
                        }
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0846450000000000119) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01148539754569130079) ) ) {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002867412157011550635) ) ) {
                          result[0] += 0.0010067964129398433;
                        } else {
                          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01085750000000000083) ) ) {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5041457217085428821) ) ) {
                              result[0] += 2.2679172059243603e-05;
                            } else {
                              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007384500000000001306) ) ) {
                                result[0] += -0.00025032911014505425;
                              } else {
                                result[0] += -0.0012030255541176237;
                              }
                            }
                          } else {
                            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01590200000000000294) ) ) {
                              result[0] += 0.0014461559646301628;
                            } else {
                              result[0] += -0.00013952233573198388;
                            }
                          }
                        }
                      } else {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7397481077386934833) ) ) {
                          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01351316588546045208) ) ) {
                            result[0] += 0.0008025960909942346;
                          } else {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
                              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4394533747236181176) ) ) {
                                result[0] += -3.271898739996685e-05;
                              } else {
                                result[0] += -0.0010298412410414204;
                              }
                            } else {
                              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2677063317952667609) ) ) {
                                result[0] += 0.0020130453523691124;
                              } else {
                                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7326471166347855446) ) ) {
                                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.52031910737473408) ) ) {
                                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3115605993075549196) ) ) {
                                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1051257686552766607) ) ) {
                                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.06355808660527756393) ) ) {
                                          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.08658216373408549049) ) ) {
                                            if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.181114681928726734) ) ) {
                                              result[0] += 0.0011930074746326633;
                                            } else {
                                              result[0] += -0.000668862093987841;
                                            }
                                          } else {
                                            result[0] += 0.0010892454926522373;
                                          }
                                        } else {
                                          result[0] += -0.0013670172371483132;
                                        }
                                      } else {
                                        result[0] += 0.0013812928784085472;
                                      }
                                    } else {
                                      result[0] += -0.0005653025920529312;
                                    }
                                  } else {
                                    result[0] += 0.0010881668594372694;
                                  }
                                } else {
                                  result[0] += -0.001897424760257807;
                                }
                              }
                            }
                          }
                        } else {
                          result[0] += 0.0017081427236292984;
                        }
                      }
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1507499186893259402) ) ) {
                        result[0] += 0.002021466590967043;
                      } else {
                        result[0] += 0.0005107147467921314;
                      }
                    }
                  }
                } else {
                  result[0] += -0.0013698177165364308;
                }
              } else {
                result[0] += 0.001425850968862673;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02366047096071570086) ) ) {
                result[0] += 0.0006986142504600572;
              } else {
                result[0] += -0.0006941789623639953;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007090500000000000448) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008506177121675452882) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5792515097236182742) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4484214422864321592) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3966785421356783803) ) ) {
                    result[0] += 1.7376638928788132e-06;
                  } else {
                    result[0] += 0.002988709517726271;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4992002680402010117) ) ) {
                    result[0] += -0.002409414426654723;
                  } else {
                    result[0] += 6.0697897698378095e-05;
                  }
                }
              } else {
                result[0] += 0.003015428553643932;
              }
            } else {
              result[0] += 0.0035317487810819686;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4129968667336683663) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4601878067544193374) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.07000300000000002354) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03389850000000000502) ) ) {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01129950000000000225) ) ) {
                      result[0] += -0.00029474983576920506;
                    } else {
                      result[0] += 0.002380642820042888;
                    }
                  } else {
                    result[0] += -0.0010482833754631921;
                  }
                } else {
                  result[0] += 0.005151818343566741;
                }
              } else {
                result[0] += -0.0019569802635604435;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03350035677887956004) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08407783631914581002) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02796916660693585244) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008506177121675452882) ) ) {
                      result[0] += 0.0035853452835740407;
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01210357511382575101) ) ) {
                        result[0] += -0.002012987124314417;
                      } else {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01676384620505355291) ) ) {
                          result[0] += 0.002300200175678754;
                        } else {
                          result[0] += 5.965481338953381e-06;
                        }
                      }
                    }
                  } else {
                    result[0] += 0.0023241281910759424;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6577150591959800563) ) ) {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01172600000000000205) ) ) {
                      result[0] += 0.0003877230230033367;
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02405800000000000646) ) ) {
                        result[0] += -0.0015001568175537275;
                      } else {
                        result[0] += -0.0004320273092984356;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8440161800932387548) ) ) {
                      result[0] += 0.003674133953586608;
                    } else {
                      result[0] += 0.0008417661594307736;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9993516786272610419) ) ) {
                  result[0] += 0.002453831134770094;
                } else {
                  result[0] += 3.3465783554243155e-05;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06081637682680595541) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1206324332205917643) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
                result[0] += 0.003971473385376637;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01881166515770610337) ) ) {
                  result[0] += 0.001585359200404245;
                } else {
                  result[0] += 0.0029311352405206503;
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5834559473869348478) ) ) {
                result[0] += -0.0014491524521972456;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                  result[0] += 0.0030383675600590618;
                } else {
                  result[0] += 0.0014065554365915018;
                }
              }
            }
          } else {
            result[0] += 0.0031726943632285716;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -6.853206463234567e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -6.853206463234567e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                result[0] += -6.853206463234567e-06;
              } else {
                result[0] += -6.853206463234567e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6802634857286432579) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4781247323869347032) ) ) {
              result[0] += 5.520677543557345e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6425364825628142595) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01231177969451185093) ) ) {
                    result[0] += -1.3163458368350531e-05;
                  } else {
                    result[0] += -5.166966618408076e-05;
                  }
                } else {
                  result[0] += -5.285634741482027e-07;
                }
              } else {
                result[0] += 2.5217881383369984e-05;
              }
            }
          } else {
            result[0] += -1.7651636328033137e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -6.853206463234567e-06;
              } else {
                result[0] += -6.853206463234567e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -6.853206463234567e-06;
                  } else {
                    result[0] += -6.853206463234567e-06;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -6.853206463234567e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -6.853206463234567e-06;
                        } else {
                          result[0] += -6.853206463234567e-06;
                        }
                      } else {
                        result[0] += -6.853206463234567e-06;
                      }
                    }
                  } else {
                    result[0] += -6.853206463234567e-06;
                  }
                }
              } else {
                result[0] += -6.853206463234567e-06;
              }
            }
          } else {
            result[0] += -6.853206463234567e-06;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -6.853206463234567e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -6.853206463234567e-06;
                } else {
                  result[0] += -6.853206463234567e-06;
                }
              } else {
                result[0] += -6.853206463234567e-06;
              }
            } else {
              result[0] += -6.853206463234567e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.578971790991679312e-05) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                  result[0] += -2.3539025372008538e-07;
                } else {
                  result[0] += -2.0762729224651023e-05;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
                    result[0] += -6.745269482773738e-06;
                  } else {
                    result[0] += -0.00011070382862070254;
                  }
                } else {
                  result[0] += -6.853206463234567e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8022705390703518402) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7211604863065327331) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6100010069597990858) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5528143519346734314) ) ) {
                        result[0] += -1.0110781919123814e-05;
                      } else {
                        result[0] += 0.0004115274290689055;
                      }
                    } else {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00421750000000000163) ) ) {
                        result[0] += 3.345300367466065e-06;
                      } else {
                        result[0] += -8.740945133071814e-05;
                      }
                    }
                  } else {
                    result[0] += 5.153201844605067e-05;
                  }
                } else {
                  result[0] += -5.733687068255815e-05;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
                  result[0] += 0.00014523149627081178;
                } else {
                  result[0] += -6.938579869207084e-06;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9808239647505231362) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5986852915639623296) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3665106630729573767) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.0650000000000000161) ) ) {
                    result[0] += -8.98915489810587e-05;
                  } else {
                    result[0] += 0.00012365803786654658;
                  }
                } else {
                  result[0] += 0.00047979077753624477;
                }
              } else {
                result[0] += -9.859770732394821e-05;
              }
            } else {
              result[0] += 0.00023505111811773446;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5050000000000001155) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.96280210579579717) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04562750000000000833) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8282572652763819931) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.321871344966293327) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00424585153689335023) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.08110515786938453375) ) ) {
                          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.690815535104635854e-06) ) ) {
                            result[0] += -8.609336614446917e-05;
                          } else {
                            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001074448343160400252) ) ) {
                              result[0] += 0.0005470500834816159;
                            } else {
                              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001939744889791500219) ) ) {
                                result[0] += -0.00036150690661690925;
                              } else {
                                result[0] += 0.0002690935171435034;
                              }
                            }
                          }
                        } else {
                          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.001779740531418749641) ) ) {
                            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.05751864358971629093) ) ) {
                              result[0] += 5.374626794700715e-06;
                            } else {
                              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0003680466634131000282) ) ) {
                                result[0] += -0.00011026021693399459;
                              } else {
                                result[0] += -0.0006388368812001593;
                              }
                            }
                          } else {
                            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6269974968039345731) ) ) {
                              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5681735652491761712) ) ) {
                                result[0] += -7.904668666169388e-06;
                              } else {
                                result[0] += 0.0003080734993706321;
                              }
                            } else {
                              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.578971790991679312e-05) ) ) {
                                result[0] += -6.200793112794102e-06;
                              } else {
                                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002205503205843300455) ) ) {
                                  result[0] += -0.0005340416158761568;
                                } else {
                                  result[0] += -2.4701198275281514e-05;
                                }
                              }
                            }
                          }
                        }
                      } else {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                          result[0] += 0.0004588548250414636;
                        } else {
                          result[0] += 1.037387334091326e-05;
                        }
                      }
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.063944343817919913) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9808239647505231362) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8466324982590252013) ) ) {
                            result[0] += 0.00014289189050794437;
                          } else {
                            result[0] += -0.00010088381926865575;
                          }
                        } else {
                          result[0] += 0.0010479107233491432;
                        }
                      } else {
                        result[0] += -0.00018338085144915632;
                      }
                    }
                  } else {
                    result[0] += 0.0005870446848291816;
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.234671350732867934) ) ) {
                    result[0] += -0.0005415857355942493;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.540399458636966701) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.363906689523952442) ) ) {
                        result[0] += 1.4637515784608777e-05;
                      } else {
                        result[0] += -0.0003139206334914882;
                      }
                    } else {
                      result[0] += 0.00018315935490858555;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5950000000000000844) ) ) {
                  result[0] += 0.00048626758087401395;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02930104421257910194) ) ) {
                    result[0] += -0.00033087651305802306;
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6850000000000001643) ) ) {
                      result[0] += -0.0006159612443795286;
                    } else {
                      result[0] += 0.0027056828909701033;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.00011908188810899579;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004552500000000000123) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7750000000000001332) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.767254320477387064) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6558660377084782889) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
                      result[0] += -0.00025861965548183875;
                    } else {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4702452205161443133) ) ) {
                        result[0] += 0.00023204568330447854;
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1148003695523622109) ) ) {
                          result[0] += 0.0006541142733005322;
                        } else {
                          result[0] += 0.00032905088206540515;
                        }
                      }
                    }
                  } else {
                    result[0] += 0.001482715274331969;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5950000000000000844) ) ) {
                    result[0] += 0.001122381533098915;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8025985781909549255) ) ) {
                      result[0] += -0.0007600838099089701;
                    } else {
                      result[0] += 6.0116042683032115e-05;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006782232836504950395) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004099190464141650413) ) ) {
                    result[0] += 0.0012345405112053937;
                  } else {
                    result[0] += -0.0003100364325502213;
                  }
                } else {
                  result[0] += 0.0032138657498354106;
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01444878842564100048) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6750000000000001554) ) ) {
                  result[0] += -0.0011622105978200707;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09956041386891252565) ) ) {
                    if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.05035649857444463723) ) ) {
                      result[0] += -1.0498348877168601e-05;
                    } else {
                      result[0] += 0.0012324543280841224;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2323027026914575854) ) ) {
                      result[0] += -0.0004894086652593629;
                    } else {
                      result[0] += -1.1313913965343144e-05;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0956005000000000188) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9650000000000000799) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02616152934301940389) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0170586839503055511) ) ) {
                        result[0] += 0.0011198504217025998;
                      } else {
                        result[0] += -0.00013190752281026766;
                      }
                    } else {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01469650000000000123) ) ) {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00799750000000000287) ) ) {
                          result[0] += 0.0009093943954787938;
                        } else {
                          result[0] += -0.00022740513099078785;
                        }
                      } else {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03705350000000001004) ) ) {
                          result[0] += 0.0017337620409748975;
                        } else {
                          result[0] += 0.0013713314286970815;
                        }
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01469650000000000123) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1738383111593791719) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08407783631914581002) ) ) {
                          result[0] += 0.0012124702421794763;
                        } else {
                          result[0] += 0.00334493720093876;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05831812793683335133) ) ) {
                          result[0] += 0.0011602120314082916;
                        } else {
                          result[0] += -0.0010004928760234562;
                        }
                      }
                    } else {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4323286620486300191) ) ) {
                        result[0] += -0.0014622344274737335;
                      } else {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0240756843176193544) ) ) {
                          result[0] += 0.0019682640352061383;
                        } else {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06508917425002432033) ) ) {
                            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5834559473869348478) ) ) {
                              result[0] += -0.002558048716075424;
                            } else {
                              result[0] += 0.000579504039846277;
                            }
                          } else {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.564198853668341882) ) ) {
                              result[0] += 0.0031927392134871425;
                            } else {
                              result[0] += -0.00032204267642698233;
                            }
                          }
                        }
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6208328749497488142) ) ) {
                    result[0] += 0.0021972542955516474;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7983409114572864729) ) ) {
                      result[0] += -9.144510249312539e-05;
                    } else {
                      result[0] += 0.0012472750172112857;
                    }
                  }
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021562361187840079) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02300100000000000408) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01676384620505355291) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00421750000000000163) ) ) {
                result[0] += 0.003885481204983104;
              } else {
                result[0] += 0.0014149619433272186;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01387300000000000165) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
                  result[0] += 0.002998309349481568;
                } else {
                  result[0] += 0.003485953245684689;
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9650000000000000799) ) ) {
                  result[0] += 0.0018297269102192893;
                } else {
                  result[0] += 0.0025776240187462894;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01376440091032050082) ) ) {
              result[0] += -0.0012647577048263182;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09341808925382111273) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3998546246231156065) ) ) {
                    result[0] += -0.0009690879662454918;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4674830972361809223) ) ) {
                      result[0] += 0.0031359509720143234;
                    } else {
                      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.03941486779484403707) ) ) {
                        result[0] += 6.280888645593131e-05;
                      } else {
                        result[0] += 0.0025944301899070757;
                      }
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3278371989949749321) ) ) {
                    result[0] += 0.0037717622306883557;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4731110269597990081) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4592177672613065309) ) ) {
                        result[0] += 0.0019273942182523993;
                      } else {
                        result[0] += -0.00014889851474839306;
                      }
                    } else {
                      result[0] += 0.002777192150155464;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5499504253266332965) ) ) {
                  result[0] += -0.002451421244293094;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4036106884780860105) ) ) {
                    result[0] += 0.002108204790958384;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6665289424874373259) ) ) {
                      result[0] += -0.002228591409341101;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7269841738944724518) ) ) {
                        result[0] += 0.002688986082885392;
                      } else {
                        result[0] += 2.8256185759682788e-05;
                      }
                    }
                  }
                }
              }
            }
          }
        } else {
          result[0] += 0.003179804224609968;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -6.580417012679716e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -6.580417012679716e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                result[0] += -6.580417012679716e-06;
              } else {
                result[0] += -6.580417012679716e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6802634857286432579) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4781247323869347032) ) ) {
              result[0] += 5.300928933636325e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6425364825628142595) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3561404984221285264) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1076318469022627677) ) ) {
                    result[0] += -3.9518955877185825e-05;
                  } else {
                    result[0] += 4.638475167400186e-06;
                  }
                } else {
                  result[0] += -1.859327614095403e-06;
                }
              } else {
                result[0] += 2.4214092566612218e-05;
              }
            }
          } else {
            result[0] += -1.6949019209878266e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -6.580417012679716e-06;
              } else {
                result[0] += -6.580417012679716e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -6.580417012679716e-06;
                  } else {
                    result[0] += -6.580417012679716e-06;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -6.580417012679716e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -6.580417012679716e-06;
                        } else {
                          result[0] += -6.580417012679716e-06;
                        }
                      } else {
                        result[0] += -6.580417012679716e-06;
                      }
                    }
                  } else {
                    result[0] += -6.580417012679716e-06;
                  }
                }
              } else {
                result[0] += -6.580417012679716e-06;
              }
            }
          } else {
            result[0] += -6.580417012679716e-06;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -6.580417012679716e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -6.580417012679716e-06;
                } else {
                  result[0] += -6.580417012679716e-06;
                }
              } else {
                result[0] += -6.580417012679716e-06;
              }
            } else {
              result[0] += -6.580417012679716e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.578971790991679312e-05) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                  result[0] += -2.2602062822834363e-07;
                } else {
                  result[0] += -1.9936276158105197e-05;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
                    result[0] += -6.4767764254112446e-06;
                  } else {
                    result[0] += -0.00010629730201950244;
                  }
                } else {
                  result[0] += -6.580417012679716e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02563650000000000304) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004657500000000001049) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003091000000000000431) ) ) {
                      result[0] += -4.841102782696778e-06;
                    } else {
                      result[0] += -7.424781384909755e-05;
                    }
                  } else {
                    result[0] += 6.778350856486121e-05;
                  }
                } else {
                  result[0] += -7.719362021633893e-05;
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
                  result[0] += 6.764760915223066e-05;
                } else {
                  result[0] += -2.839130805296906e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9808239647505231362) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1050000000000000239) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.07500000000000002498) ) ) {
                  result[0] += 2.051714037952792e-05;
                } else {
                  result[0] += -0.00014200631691378918;
                }
              } else {
                result[0] += 0.0010248133970404442;
              }
            } else {
              result[0] += 0.00022569499179823395;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5550000000000001599) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.96280210579579717) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002339521674937150662) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001074448343160400252) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8507017292462312197) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3644118032412060892) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.317357466959798995) ) ) {
                        result[0] += 1.2950882760519203e-05;
                      } else {
                        result[0] += 0.0009048780431932639;
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4052145559547739029) ) ) {
                        result[0] += -0.0008089580693916852;
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4251092621105527214) ) ) {
                          result[0] += 0.0010489362592276156;
                        } else {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7463838234422112139) ) ) {
                            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7382388927638191545) ) ) {
                              result[0] += 5.1892464025631794e-08;
                            } else {
                              result[0] += -0.0002509731029978076;
                            }
                          } else {
                            result[0] += 0.00011413891560543118;
                          }
                        }
                      }
                    }
                  } else {
                    result[0] += -0.00019006705490050776;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5612777274623116375) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5153685380402011074) ) ) {
                      result[0] += -0.0001909251612332492;
                    } else {
                      result[0] += 0.0011551629397614698;
                    }
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001939744889791500219) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00135663295830650032) ) ) {
                        result[0] += -0.00032247776685332893;
                      } else {
                        result[0] += 1.0000910446349866e-05;
                      }
                    } else {
                      result[0] += -0.0007918794818605241;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2669585275879397535) ) ) {
                    result[0] += -0.000972577429565797;
                  } else {
                    result[0] += 0.00017797335855355956;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7954292854522614364) ) ) {
                    result[0] += -0.00013898817822654265;
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0683765000000000206) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004132000000000001123) ) ) {
                          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001499500000000000182) ) ) {
                            result[0] += 0.0006351202797452456;
                          } else {
                            result[0] += -0.00017980264242864529;
                          }
                        } else {
                          result[0] += 0.00044846305496744235;
                        }
                      } else {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04562750000000000833) ) ) {
                          result[0] += -0.0005305133767707752;
                        } else {
                          result[0] += 3.4526012913961534e-05;
                        }
                      }
                    } else {
                      result[0] += 0.0007781368171535152;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006782232836504950395) ) ) {
                result[0] += 0.0001236269838580851;
              } else {
                result[0] += -0.0008114975046552058;
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004552500000000000123) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004867285882244350333) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2888738239382729889) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05463331189772155372) ) ) {
                      result[0] += 0.0003850979399226553;
                    } else {
                      result[0] += -0.0006962867623241025;
                    }
                  } else {
                    result[0] += 0.000792109255931375;
                  }
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0003680466634131000282) ) ) {
                    result[0] += 0.002003083293724721;
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00135663295830650032) ) ) {
                      result[0] += -0.0004241875812733347;
                    } else {
                      result[0] += 0.0006452441930688427;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7990273242713569202) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3569067370100503234) ) ) {
                    result[0] += -3.17278906432229e-05;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01650738594486505367) ) ) {
                      result[0] += 0.0005836196666074063;
                    } else {
                      result[0] += 0.001538344294319579;
                    }
                  }
                } else {
                  result[0] += -0.0002202013129260106;
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01444878842564100048) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01351316588546045208) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7350000000000000977) ) ) {
                    result[0] += -0.000327713488417906;
                  } else {
                    result[0] += -3.3507455290471485e-05;
                  }
                } else {
                  result[0] += -0.0004355645603364265;
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9650000000000000799) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05052567209861091174) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9808239647505231362) ) ) {
                      result[0] += 0.0009453318077563152;
                    } else {
                      result[0] += -0.0005560820397105649;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4484214422864321592) ) ) {
                      result[0] += 3.470286085668934e-05;
                    } else {
                      result[0] += 0.0020834193704818;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0173600348455768029) ) ) {
                    result[0] += 0.002436838663441846;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4183012963065327328) ) ) {
                      result[0] += -0.0007707182469017216;
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02159955403810970287) ) ) {
                        result[0] += -0.0010277726287304906;
                      } else {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
                          result[0] += 0.0014175598049884599;
                        } else {
                          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05860550000000001175) ) ) {
                            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03545400000000000634) ) ) {
                              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02615650000000000266) ) ) {
                                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01868100000000000316) ) ) {
                                  result[0] += 0.0007171641143918061;
                                } else {
                                  result[0] += -0.0015663458572747636;
                                }
                              } else {
                                result[0] += 0.0029651326875641463;
                              }
                            } else {
                              result[0] += -0.0020531415646638925;
                            }
                          } else {
                            result[0] += 0.0017474593053046581;
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021562361187840079) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01108250000000000207) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0110643527143887508) ) ) {
              result[0] += 0.001609404018555008;
            } else {
              result[0] += 0.0033620358998718057;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.009662942724727452) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.421180086331658321) ) ) {
                  if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6269304705026225166) ) ) {
                    result[0] += 0.0030920554415827164;
                  } else {
                    result[0] += -0.0019907779087767513;
                  }
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
                    result[0] += 0.003090193348541704;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6116569490452262725) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08407783631914581002) ) ) {
                        if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.03941486779484403707) ) ) {
                          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02577363736079425413) ) ) {
                            result[0] += -0.0006745309451032304;
                          } else {
                            result[0] += 0.0010344037146793885;
                          }
                        } else {
                          result[0] += 0.0030319514898376485;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04557577292723340862) ) ) {
                          result[0] += -0.000810059901773755;
                        } else {
                          result[0] += 0.00013371276749766386;
                        }
                      }
                    } else {
                      result[0] += 0.0024510157724281258;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01881166515770610337) ) ) {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3197884335317744964) ) ) {
                    result[0] += 0.0036483272630751895;
                  } else {
                    result[0] += -0.0010341971837077633;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3278371989949749321) ) ) {
                    result[0] += 0.0036216285739755845;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4129968667336683663) ) ) {
                      result[0] += 0.0014100344479340097;
                    } else {
                      result[0] += 0.002448558511946535;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.0012617681775921557;
            }
          }
        } else {
          result[0] += 0.0030532332461990913;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -6.318485849370876e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -6.318485849370876e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                result[0] += -6.318485849370876e-06;
              } else {
                result[0] += -6.318485849370876e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6802634857286432579) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.07196201389915944657) ) ) {
                result[0] += -4.499424967768909e-05;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01467829982783020078) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007291314867598450676) ) ) {
                    result[0] += -7.167101163232151e-07;
                  } else {
                    result[0] += -8.789712615394465e-06;
                  }
                } else {
                  result[0] += 1.4371310300515485e-05;
                }
              }
            } else {
              result[0] += 0.0016092556778889808;
            }
          } else {
            result[0] += -1.6274369516700323e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -6.318485849370876e-06;
              } else {
                result[0] += -6.318485849370876e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -6.318485849370876e-06;
                  } else {
                    result[0] += -6.318485849370876e-06;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -6.318485849370876e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -6.318485849370876e-06;
                        } else {
                          result[0] += -6.318485849370876e-06;
                        }
                      } else {
                        result[0] += -6.318485849370876e-06;
                      }
                    }
                  } else {
                    result[0] += -6.318485849370876e-06;
                  }
                }
              } else {
                result[0] += -6.318485849370876e-06;
              }
            }
          } else {
            result[0] += -6.318485849370876e-06;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -6.318485849370876e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -6.318485849370876e-06;
                } else {
                  result[0] += -6.318485849370876e-06;
                }
              } else {
                result[0] += -6.318485849370876e-06;
              }
            } else {
              result[0] += -6.318485849370876e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02500000000000000486) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0009685000000000000683) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7114754460552764614) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                    result[0] += -2.170239573532684e-07;
                  } else {
                    result[0] += -1.636631791691555e-05;
                  }
                } else {
                  result[0] += 4.4219877576664114e-05;
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.729199597233659459e-06) ) ) {
                  result[0] += -6.218970638888851e-06;
                } else {
                  result[0] += -6.354643069978983e-06;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.04446937286580055632) ) ) {
                result[0] += 0.0004204125142934319;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6208328749497488142) ) ) {
                  result[0] += -9.237691821279428e-05;
                } else {
                  result[0] += 1.64115031676865e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1450000000000000455) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008506177121675452882) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.08500000000000000611) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.485713013107980879e-05) ) ) {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
                          result[0] += 1.6371963673113465e-05;
                        } else {
                          result[0] += -3.392845553392071e-05;
                        }
                      } else {
                        result[0] += -0.00010680929653548128;
                      }
                    } else {
                      result[0] += 2.7322734676724584e-05;
                    }
                  } else {
                    result[0] += -0.00015598616992214295;
                  }
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02577363736079425413) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
                      result[0] += 6.131420018588355e-06;
                    } else {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.05500000000000000722) ) ) {
                        result[0] += -0.0001552770020527412;
                      } else {
                        result[0] += -3.525651423094338e-05;
                      }
                    }
                  } else {
                    result[0] += -4.354560978595821e-07;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.120890988778383868e-05) ) ) {
                  result[0] += -1.1138398032581384e-05;
                } else {
                  result[0] += 2.6208451383143605e-05;
                }
              }
            } else {
              result[0] += 0.0009713478979883272;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5550000000000001599) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04258450000000000429) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8282572652763819931) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002339521674937150662) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001074448343160400252) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.310012234630710122e-06) ) ) {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.903059230149356746e-07) ) ) {
                          result[0] += 0.0005213492407009232;
                        } else {
                          result[0] += -7.818254163125324e-05;
                        }
                      } else {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.038494786985569569e-06) ) ) {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.794554612313755398e-06) ) ) {
                            result[0] += 0.0001244428555157569;
                          } else {
                            result[0] += 0.00038423535575053127;
                          }
                        } else {
                          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.125515493975159704e-06) ) ) {
                            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.690815535104635854e-06) ) ) {
                                result[0] += -8.279563476743638e-05;
                              } else {
                                result[0] += 0.00011414159942939153;
                              }
                            } else {
                              result[0] += -0.0003965516531269369;
                            }
                          } else {
                            result[0] += 8.732220873086654e-05;
                          }
                        }
                      }
                    } else {
                      result[0] += -0.00013533378369568442;
                    }
                  } else {
                    result[0] += 0.00010867916432854725;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02207100000000000381) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003882500000000000534) ) ) {
                      result[0] += -5.755198573198105e-05;
                    } else {
                      result[0] += 0.00034559072620563583;
                    }
                  } else {
                    result[0] += -0.0005325342725342286;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1405997886577425304) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5392784256532664466) ) ) {
                    result[0] += 0.0008552834471007408;
                  } else {
                    result[0] += 0.0012092417416800498;
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3346339054385528144) ) ) {
                    result[0] += -0.00046279489083783486;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04247438584267165113) ) ) {
                      result[0] += 4.945664186155871e-05;
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06081637682680595541) ) ) {
                        result[0] += 0.0016751904194726723;
                      } else {
                        result[0] += 0.0013742415686696767;
                      }
                    }
                  }
                }
              }
            } else {
              result[0] += -0.00030203103564550247;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0816878293504414571) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003965500000000001142) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.767254320477387064) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004867285882244350333) ) ) {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2888738239382729889) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.001151299667459350319) ) ) {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4931942899748744114) ) ) {
                            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8550000000000000933) ) ) {
                              result[0] += 0.0011005276406173834;
                            } else {
                              result[0] += -0.00040638849566630443;
                            }
                          } else {
                            result[0] += 0.00170725146094801;
                          }
                        } else {
                          result[0] += -0.0005602685747769413;
                        }
                      } else {
                        result[0] += 0.0010866820129741641;
                      }
                    } else {
                      result[0] += 0.0007268717619290499;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3687216492462311868) ) ) {
                      result[0] += -0.00011164833285654823;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6553322322110554099) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6299505656030152112) ) ) {
                          result[0] += 0.0010320355834978698;
                        } else {
                          result[0] += -0.0003258043104365048;
                        }
                      } else {
                        result[0] += 0.001152015882788391;
                      }
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                    result[0] += -0.0006146256899285935;
                  } else {
                    result[0] += 5.821461550105133e-05;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01444878842564100048) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002867412157011550635) ) ) {
                    result[0] += 0.0008225452363647253;
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005013289129500051074) ) ) {
                      result[0] += -0.0008177843926447923;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01351316588546045208) ) ) {
                        result[0] += 1.803403423847423e-05;
                      } else {
                        result[0] += -0.00045490613333109534;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4405029099497487777) ) ) {
                        result[0] += 0.0005321534153096396;
                      } else {
                        result[0] += -0.0015233278546563065;
                      }
                    } else {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2795185878002977575) ) ) {
                        result[0] += 0.00389854986745674;
                      } else {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6722423356281408413) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5380790363330137938) ) ) {
                            result[0] += 0.00090422996464343;
                          } else {
                            result[0] += -0.0005975631424120981;
                          }
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7210440605025126848) ) ) {
                            result[0] += 0.0027526235522436155;
                          } else {
                            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
                              result[0] += 0.00019975068828062765;
                            } else {
                              result[0] += 0.0013704708726888174;
                            }
                          }
                        }
                      }
                    }
                  } else {
                    result[0] += -0.0004045014237707209;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006969500000000000868) ) ) {
                result[0] += 0.0019409077492272867;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2932818109908455484) ) ) {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3539353041941689093) ) ) {
                    result[0] += 0.00017207104718193437;
                  } else {
                    result[0] += 0.00297233175372385;
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5876805463210391656) ) ) {
                    result[0] += -0.001108075056950937;
                  } else {
                    result[0] += 0.0007960776721092781;
                  }
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021562361187840079) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01108250000000000207) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0110643527143887508) ) ) {
              result[0] += 0.0015453422628939678;
            } else {
              result[0] += 0.003228211254314746;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.009662942724727452) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.421180086331658321) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03468100000000001043) ) ) {
                    result[0] += 0.00042722498390060923;
                  } else {
                    result[0] += -0.001437523272377917;
                  }
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
                    result[0] += 0.002967189299243141;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6116569490452262725) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08407783631914581002) ) ) {
                        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1068151278937841814) ) ) {
                          result[0] += -0.0004713170519404354;
                        } else {
                          result[0] += 0.0022335828084177334;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04557577292723340862) ) ) {
                          result[0] += -0.0007778157549343383;
                        } else {
                          result[0] += 0.00012839037825205648;
                        }
                      }
                    } else {
                      result[0] += 0.00235345395965496;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3278371989949749321) ) ) {
                  result[0] += 0.003478202945976096;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01881166515770610337) ) ) {
                    result[0] += -0.00021336981051322802;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4129968667336683663) ) ) {
                      result[0] += 0.0013539085272604077;
                    } else {
                      result[0] += 0.0023510945095545715;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.00121154394317875;
            }
          }
        } else {
          result[0] += 0.0029317003806543767;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -6.066980763038635e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -6.066980763038635e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                result[0] += -6.066980763038635e-06;
              } else {
                result[0] += -6.066980763038635e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6802634857286432579) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4781247323869347032) ) ) {
              result[0] += 4.281262600962748e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6425364825628142595) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3561404984221285264) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1076318469022627677) ) ) {
                    result[0] += -5.35511198901601e-05;
                  } else {
                    result[0] += 3.8817974048407346e-06;
                  }
                } else {
                  result[0] += -1.7567893466640446e-06;
                }
              } else {
                result[0] += 2.3139172450120535e-05;
              }
            }
          } else {
            result[0] += -1.5626574015075824e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -6.066980763038635e-06;
              } else {
                result[0] += -6.066980763038635e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -6.066980763038635e-06;
                  } else {
                    result[0] += -6.066980763038635e-06;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -6.066980763038635e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -6.066980763038635e-06;
                        } else {
                          result[0] += -6.066980763038635e-06;
                        }
                      } else {
                        result[0] += -6.066980763038635e-06;
                      }
                    }
                  } else {
                    result[0] += -6.066980763038635e-06;
                  }
                }
              } else {
                result[0] += -6.066980763038635e-06;
              }
            }
          } else {
            result[0] += -6.066980763038635e-06;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -6.066980763038635e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -6.066980763038635e-06;
                } else {
                  result[0] += -6.066980763038635e-06;
                }
              } else {
                result[0] += -6.066980763038635e-06;
              }
            } else {
              result[0] += -6.066980763038635e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001504690974371400121) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5859181088693469208) ) ) {
              result[0] += -2.0838539576879476e-07;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.125515493975159704e-06) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6881801856532664408) ) ) {
                    result[0] += -1.1084966861692902e-06;
                  } else {
                    result[0] += -7.324117639574028e-06;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8025985781909549255) ) ) {
                    result[0] += -5.971426720184475e-06;
                  } else {
                    result[0] += -6.021184325425488e-06;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                  result[0] += -1.649578694717246e-05;
                } else {
                  result[0] += 9.549507816508717e-06;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01359050000000000188) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                result[0] += -1.2642678524556845e-05;
              } else {
                result[0] += 0.0001459158043528419;
              }
            } else {
              result[0] += 6.386432566342912e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5050000000000001155) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.115000000000000005) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1050000000000000239) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01326604349644140181) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01210357511382575101) ) ) {
                    result[0] += 1.2071984133919492e-06;
                  } else {
                    result[0] += 0.0005264339825064372;
                  }
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01467829982783020078) ) ) {
                    result[0] += -0.0003933441571487028;
                  } else {
                    result[0] += -1.0055285945500552e-05;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
                  result[0] += 0.00016821198307406552;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01881166515770610337) ) ) {
                    result[0] += -0.0004378188134420759;
                  } else {
                    result[0] += -8.668481757783113e-05;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.310012234630710122e-06) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                  result[0] += -5.8716274628161403e-05;
                } else {
                  result[0] += -0.000579461108222546;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5792515097236182742) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.564198853668341882) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5612777274623116375) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5528143519346734314) ) ) {
                        result[0] += 0.00022515010491749515;
                      } else {
                        result[0] += 0.0011418548299082006;
                      }
                    } else {
                      result[0] += -0.0006345594756411259;
                    }
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007962674928513501643) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001939744889791500219) ) ) {
                        result[0] += 0.0010391549312712784;
                      } else {
                        result[0] += -0.00017423393156217875;
                      }
                    } else {
                      result[0] += 0.0011761217692762556;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5859181088693469208) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007384500000000001306) ) ) {
                      result[0] += -0.0006075131544890012;
                    } else {
                      result[0] += 0.0001287230797290946;
                    }
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.883880929790755059e-06) ) ) {
                      result[0] += 0.0011729705602980933;
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1413595000000000268) ) ) {
                        result[0] += 1.1873340275242062e-05;
                      } else {
                        result[0] += 0.002351422518656583;
                      }
                    }
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0816878293504414571) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003965500000000001142) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004867285882244350333) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002237500000000000339) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5550000000000001599) ) ) {
                      result[0] += -0.0004059835531973446;
                    } else {
                      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7150000000000000799) ) ) {
                        result[0] += 0.0016677709351794754;
                      } else {
                        result[0] += 0.00046770505920053294;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
                      result[0] += -0.0005422528342864213;
                    } else {
                      result[0] += 0.0011121494721819936;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7990273242713569202) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8350000000000000755) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006124087708088651362) ) ) {
                        result[0] += 0.001125982812954456;
                      } else {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6553322322110554099) ) ) {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6299505656030152112) ) ) {
                            result[0] += 0.0005279502101495741;
                          } else {
                            result[0] += -0.0004526106967466623;
                          }
                        } else {
                          result[0] += 0.0009900550199862447;
                        }
                      }
                    } else {
                      result[0] += 0.0040179732474078765;
                    }
                  } else {
                    result[0] += -0.00039954109001259666;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006290243127013950622) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002867412157011550635) ) ) {
                    result[0] += 0.0008673396675618763;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5455059598241206453) ) ) {
                      result[0] += -0.000764135492783312;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6242129639949749453) ) ) {
                        result[0] += 0.001095176036026714;
                      } else {
                        result[0] += -0.00048591977343969165;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.272781830548367354) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7990273242713569202) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9808239647505231362) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6468042868844222637) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4143094250104821241) ) ) {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4129968667336683663) ) ) {
                              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6269304705026225166) ) ) {
                                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6782348568386622478) ) ) {
                                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
                                    result[0] += 0.0021250685472207326;
                                  } else {
                                    result[0] += -0.00034315117587025064;
                                  }
                                } else {
                                  result[0] += 0.0020101974519758205;
                                }
                              } else {
                                result[0] += -0.00015972866262959303;
                              }
                            } else {
                              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.06355808660527756393) ) ) {
                                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5612777274623116375) ) ) {
                                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.0286104669690836512) ) ) {
                                    result[0] += 0.0007294971044215841;
                                  } else {
                                    result[0] += 0.002722412221761213;
                                  }
                                } else {
                                  result[0] += -0.0007773636942107798;
                                }
                              } else {
                                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5528143519346734314) ) ) {
                                  result[0] += -0.002415108146478403;
                                } else {
                                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09956041386891252565) ) ) {
                                    result[0] += -0.0010456523663111318;
                                  } else {
                                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
                                      result[0] += 0.0023190614666210928;
                                    } else {
                                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2888738239382729889) ) ) {
                                        result[0] += -0.00039477116557242863;
                                      } else {
                                        result[0] += 0.0004901789039620381;
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          } else {
                            result[0] += -0.001944796794121922;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8440161800932387548) ) ) {
                            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6968016071608041928) ) ) {
                              result[0] += 0.0003945064358790187;
                            } else {
                              result[0] += 0.0019743154064187627;
                            }
                          } else {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7601236426381910993) ) ) {
                              result[0] += -0.0006804180270918695;
                            } else {
                              result[0] += 0.0008986323191797407;
                            }
                          }
                        }
                      } else {
                        result[0] += -0.0004060864481761553;
                      }
                    } else {
                      result[0] += 0.002247814426707002;
                    }
                  } else {
                    result[0] += -0.0005173157280228166;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006969500000000000868) ) ) {
                result[0] += 0.0016414699443700854;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2888738239382729889) ) ) {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3245708964283948172) ) ) {
                    result[0] += 0.00018673667914115497;
                  } else {
                    result[0] += 0.002695289417060017;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1168105000000000254) ) ) {
                    result[0] += -0.00043738406033643715;
                  } else {
                    result[0] += 0.002714168088573214;
                  }
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021562361187840079) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01905700000000000102) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0110643527143887508) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002710500000000000669) ) ) {
                result[0] += 0.003876718123893166;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007090500000000000448) ) ) {
                    result[0] += 0.001088295728496534;
                  } else {
                    result[0] += -0.0006105745787302388;
                  }
                } else {
                  result[0] += 0.002159039298263315;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01108250000000000207) ) ) {
                result[0] += 0.003099713451269737;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9650000000000000799) ) ) {
                  result[0] += 0.0006542195468152823;
                } else {
                  result[0] += 0.0024413908273501162;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4052145559547739029) ) ) {
                result[0] += -0.000999386787144462;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0184998371148766029) ) ) {
                  result[0] += -0.0007913450970323579;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.505061141934673441) ) ) {
                    result[0] += 0.0020701649201886017;
                  } else {
                    result[0] += 0.0008301479682632645;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3278371989949749321) ) ) {
                result[0] += 0.0033806503669392657;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01881166515770610337) ) ) {
                  result[0] += -0.0006741738202852126;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09956041386891252565) ) ) {
                    result[0] += 0.002321150106603221;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.564374608675820677) ) ) {
                      result[0] += 0.0006069876411123324;
                    } else {
                      result[0] += 0.0014358134690223233;
                    }
                  }
                }
              }
            }
          }
        } else {
          result[0] += 0.0028150050876815896;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -5.825486747389932e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -5.825486747389932e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                result[0] += -5.825486747389932e-06;
              } else {
                result[0] += -5.825486747389932e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6802634857286432579) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6425364825628142595) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5674119023366835934) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.07196201389915944657) ) ) {
                  result[0] += -2.800035323414295e-05;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009152500000000002647) ) ) {
                    result[0] += 1.195336347401831e-07;
                  } else {
                    result[0] += 0.0004143748814667132;
                  }
                }
              } else {
                result[0] += -1.0277377809080982e-05;
              }
            } else {
              result[0] += 2.221812590456191e-05;
            }
          } else {
            result[0] += -1.500456378344254e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -5.825486747389932e-06;
              } else {
                result[0] += -5.825486747389932e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -5.825486747389932e-06;
                  } else {
                    result[0] += -5.825486747389932e-06;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -5.825486747389932e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -5.825486747389932e-06;
                        } else {
                          result[0] += -5.825486747389932e-06;
                        }
                      } else {
                        result[0] += -5.825486747389932e-06;
                      }
                    }
                  } else {
                    result[0] += -5.825486747389932e-06;
                  }
                }
              } else {
                result[0] += -5.825486747389932e-06;
              }
            }
          } else {
            result[0] += -5.825486747389932e-06;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -5.825486747389932e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -5.825486747389932e-06;
                } else {
                  result[0] += -5.825486747389932e-06;
                }
              } else {
                result[0] += -5.825486747389932e-06;
              }
            } else {
              result[0] += -5.825486747389932e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001504690974371400121) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6858832018090453841) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)5.045799003287211847e-06) ) ) {
                result[0] += 8.64055110907152e-06;
              } else {
                result[0] += -1.583917800332558e-05;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.125515493975159704e-06) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
                    result[0] += -7.03258373680649e-06;
                  } else {
                    result[0] += -5.733736199292324e-06;
                  }
                } else {
                  result[0] += -5.733736199292324e-06;
                }
              } else {
                result[0] += -4.061103770755629e-06;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03500000000000001027) ) ) {
              result[0] += -1.5134856091597964e-06;
            } else {
              result[0] += 0.0012323379092378213;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3850000000000000644) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02577363736079425413) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01278116174711865262) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0119121105025029022) ) ) {
                  result[0] += -1.6432005140619039e-06;
                } else {
                  result[0] += 0.00031103802683066467;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01397330054109465099) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6881801856532664408) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5392784256532664466) ) ) {
                      result[0] += -0.0010996157949049149;
                    } else {
                      result[0] += -0.0003418421345802826;
                    }
                  } else {
                    result[0] += 0.00035340277583958556;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725302343969849939) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3687216492462311868) ) ) {
                      result[0] += -0.0003023952263772273;
                    } else {
                      result[0] += 0.0011087236812119673;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6273136390703518694) ) ) {
                      result[0] += -0.00011045854634794833;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.714147492562814179) ) ) {
                          result[0] += 0.00013272808534954062;
                        } else {
                          result[0] += 0.0010304953616418842;
                        }
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8022705390703518402) ) ) {
                          result[0] += -0.0001660863197423066;
                        } else {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
                            result[0] += 0.0007012210054829813;
                          } else {
                            result[0] += -0.00017994166823269588;
                          }
                        }
                      }
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01262450000000000204) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7789937396482412568) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7382388927638191545) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6161319161557790025) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.55780239615577909) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.497782690150753826) ) ) {
                          result[0] += -0.0004682367612194478;
                        } else {
                          result[0] += 0.0010405536277574299;
                        }
                      } else {
                        result[0] += -0.0006236721744009516;
                      }
                    } else {
                      result[0] += 0.0002693212968473308;
                    }
                  } else {
                    result[0] += -0.00021470118093144553;
                  }
                } else {
                  result[0] += 0.00018040133182646288;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4405029099497487777) ) ) {
                  result[0] += 0.0015288055506458486;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02979533478473985267) ) ) {
                    result[0] += 0.0007002368569274174;
                  } else {
                    result[0] += 0.00019495415710195943;
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3115605993075549196) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0846450000000000119) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3998546246231156065) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004657500000000001049) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00135663295830650032) ) ) {
                      result[0] += -0.0004606162290510393;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01000276686157755036) ) ) {
                        result[0] += 0.001073806556932756;
                      } else {
                        result[0] += -0.000275935711425506;
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01021941412521685209) ) ) {
                      result[0] += -0.0018120672970426148;
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02192319026750580435) ) ) {
                        result[0] += 0.0004897117172475065;
                      } else {
                        result[0] += -0.000779348828568283;
                      }
                    }
                  }
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2302999793555680907) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0229305563329877532) ) ) {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.009795390075261452625) ) ) {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0044229535828532009) ) ) {
                          result[0] += 0.0013708021784270843;
                        } else {
                          result[0] += 3.974050134094493e-05;
                        }
                      } else {
                        result[0] += 0.0020072044011642735;
                      }
                    } else {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007090500000000000448) ) ) {
                        result[0] += 0.001499495272553754;
                      } else {
                        result[0] += -6.717117956089335e-05;
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4751828078391960308) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4643511832914573034) ) ) {
                        result[0] += 9.163453876491132e-05;
                      } else {
                        result[0] += -0.0007514489646834676;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03536062175606080604) ) ) {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05311250000000000693) ) ) {
                          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001715500000000000228) ) ) {
                            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                              result[0] += -1.8909256203075317e-05;
                            } else {
                              result[0] += 0.0006829253409127216;
                            }
                          } else {
                            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001980500000000000489) ) ) {
                              result[0] += -0.0001652034282689633;
                            } else {
                              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03076611039958550634) ) ) {
                                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01415250000000000188) ) ) {
                                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.008962500000000001715) ) ) {
                                    result[0] += 0.0002500153527967966;
                                  } else {
                                    result[0] += -0.0003796913476277474;
                                  }
                                } else {
                                  result[0] += 0.0014988501241768894;
                                }
                              } else {
                                result[0] += -0.00047579843545232994;
                              }
                            }
                          }
                        } else {
                          result[0] += -0.0010317658111980731;
                        }
                      } else {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01691750000000000545) ) ) {
                          result[0] += 0.0015843869071818395;
                        } else {
                          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02511600000000000291) ) ) {
                            result[0] += -0.0010528733354540911;
                          } else {
                            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03545400000000000634) ) ) {
                              result[0] += 0.003356211069063303;
                            } else {
                              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05185700000000000726) ) ) {
                                result[0] += -0.0001010884518353159;
                              } else {
                                result[0] += 0.0026268383066673914;
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              } else {
                result[0] += 0.0019874456562142813;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6449783570351760309) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001886500000000000373) ) ) {
                  result[0] += 0.0006748844641336818;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006782232836504950395) ) ) {
                    result[0] += -0.001536428690586283;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4218023131278703652) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3561404984221285264) ) ) {
                        result[0] += -0.0012212123686306535;
                      } else {
                        result[0] += 0.0005655647665592572;
                      }
                    } else {
                      result[0] += -0.0011402911537298256;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0005095000000000000787) ) ) {
                  result[0] += 0.0019176039711801848;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6647073645226131422) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5380790363330137938) ) ) {
                      result[0] += 0.001219530465526115;
                    } else {
                      result[0] += 1.036117461552506e-05;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4677590045467516222) ) ) {
                      result[0] += -0.0011052361057141255;
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
                        result[0] += 0.0005418307902221505;
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8466324982590252013) ) ) {
                          result[0] += -0.0006784883297429716;
                        } else {
                          result[0] += 4.32078691354895e-05;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021562361187840079) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00583050000000000148) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01278116174711865262) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3837516359296482826) ) ) {
                result[0] += 0.00014892905110401177;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4484214422864321592) ) ) {
                  result[0] += 0.004120283267743672;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.497782690150753826) ) ) {
                    result[0] += -0.0014898347985913703;
                  } else {
                    result[0] += 0.003230015269156723;
                  }
                }
              }
            } else {
              result[0] += 0.0030273168731738587;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1127930000000000182) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02300100000000000408) ) ) {
                    result[0] += 0.0011382668200219273;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4093335132160804135) ) ) {
                      result[0] += -0.0009781912173279007;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5041457217085428821) ) ) {
                        result[0] += 0.0023987578774051547;
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5400528323115579843) ) ) {
                          result[0] += -0.0016257696984053828;
                        } else {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5792515097236182742) ) ) {
                            result[0] += 0.0014851847219536968;
                          } else {
                            result[0] += -0.0010891379136611099;
                          }
                        }
                      }
                    }
                  }
                } else {
                  result[0] += 0.001612872381908143;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7875164333668343009) ) ) {
                  result[0] += 0.0022385146229079405;
                } else {
                  result[0] += 0.00035745408007640617;
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
                result[0] += -0.0001757162474465115;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8440161800932387548) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3278371989949749321) ) ) {
                    result[0] += 0.003204456712772721;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.564374608675820677) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4036106884780860105) ) ) {
                        result[0] += 0.0022570610120179074;
                      } else {
                        result[0] += -0.00034479225645750873;
                      }
                    } else {
                      result[0] += 0.0025780202657043373;
                    }
                  }
                } else {
                  result[0] += -0.00015812917878524322;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
            result[0] += 0.0025695569751379133;
          } else {
            result[0] += 0.0032922259346467517;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -5.593605315309885e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -5.593605315309885e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                result[0] += -5.593605315309885e-06;
              } else {
                result[0] += -5.593605315309885e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6802634857286432579) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6425364825628142595) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5674119023366835934) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.07196201389915944657) ) ) {
                  result[0] += -2.6885809113071984e-05;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009152500000000002647) ) ) {
                    result[0] += 1.147756408407462e-07;
                  } else {
                    result[0] += 0.0003978808364024872;
                  }
                }
              } else {
                result[0] += -9.868290433598554e-06;
              }
            } else {
              result[0] += 2.1333741289801102e-05;
            }
          } else {
            result[0] += -1.440731244828159e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -5.593605315309885e-06;
              } else {
                result[0] += -5.593605315309885e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -5.593605315309885e-06;
                  } else {
                    result[0] += -5.593605315309885e-06;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -5.593605315309885e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -5.593605315309885e-06;
                        } else {
                          result[0] += -5.593605315309885e-06;
                        }
                      } else {
                        result[0] += -5.593605315309885e-06;
                      }
                    }
                  } else {
                    result[0] += -5.593605315309885e-06;
                  }
                }
              } else {
                result[0] += -5.593605315309885e-06;
              }
            }
          } else {
            result[0] += -5.593605315309885e-06;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -5.593605315309885e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -5.593605315309885e-06;
                } else {
                  result[0] += -5.593605315309885e-06;
                }
              } else {
                result[0] += -5.593605315309885e-06;
              }
            } else {
              result[0] += -5.593605315309885e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001504690974371400121) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6858832018090453841) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)5.045799003287211847e-06) ) ) {
                result[0] += 8.296617039351044e-06;
              } else {
                result[0] += -1.520870514540903e-05;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.125515493975159704e-06) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
                    result[0] += -6.752654237551484e-06;
                  } else {
                    result[0] += -5.505506865210189e-06;
                  }
                } else {
                  result[0] += -5.505506865210189e-06;
                }
              } else {
                result[0] += -3.8994529767493745e-06;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03500000000000001027) ) ) {
              result[0] += -1.4532418517361345e-06;
            } else {
              result[0] += 0.0011832851362092625;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3850000000000000644) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009323500000000001925) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.008624500000000001956) ) ) {
                result[0] += -2.7580778488286557e-06;
              } else {
                result[0] += -0.0001834182788304808;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725302343969849939) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03018900000000000403) ) ) {
                  result[0] += 0.0004906049379921675;
                } else {
                  result[0] += 0.001691170115721228;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4838161673366834781) ) ) {
                  result[0] += -0.0003911321081781262;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0102480000000000019) ) ) {
                    result[0] += 0.0004894733359063328;
                  } else {
                    result[0] += 2.6393278438700623e-05;
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.16917529420057901e-06) ) ) {
              result[0] += -0.0007988453740080119;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001653500000000000239) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6782348568386622478) ) ) {
                    result[0] += -0.0006522278656113234;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001074448343160400252) ) ) {
                      result[0] += 0.0010428156744384835;
                    } else {
                      result[0] += -0.00011225514463039782;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5876805463210391656) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1534042965400678749) ) ) {
                      result[0] += 0.0006949603694385838;
                    } else {
                      result[0] += 0.0010708201202454034;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7322719660050253099) ) ) {
                      result[0] += -8.10079219361362e-05;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.767254320477387064) ) ) {
                        result[0] += 0.001116454494881568;
                      } else {
                        result[0] += -0.0001139443614595225;
                      }
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006782232836504950395) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3684892717336683554) ) ) {
                    result[0] += -0.00039005500440518134;
                  } else {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4133512684738382403) ) ) {
                      result[0] += 0.0019564169368152117;
                    } else {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.625000000000000111) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9186477097784532253) ) ) {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6716133195226131614) ) ) {
                            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6208328749497488142) ) ) {
                              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5284121414321608645) ) ) {
                                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4950000000000000511) ) ) {
                                  result[0] += -0.0005561446858363769;
                                } else {
                                  result[0] += 0.0006468308723428324;
                                }
                              } else {
                                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.555096866909547848) ) ) {
                                  result[0] += 0.0014489717691273758;
                                } else {
                                  result[0] += 0.0008720143332261401;
                                }
                              }
                            } else {
                              result[0] += -0.00021683543746908046;
                            }
                          } else {
                            result[0] += 0.001599616142041122;
                          }
                        } else {
                          result[0] += -0.0002705179161874514;
                        }
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01704648841990550126) ) ) {
                          if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1828583041203602211) ) ) {
                            result[0] += -0.0007439990479298143;
                          } else {
                            result[0] += 0.0009683020279220428;
                          }
                        } else {
                          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1529448915625084837) ) ) {
                            result[0] += -0.0005160210305307985;
                          } else {
                            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3346339054385528144) ) ) {
                              result[0] += 0.0011088136408737073;
                            } else {
                              result[0] += -0.00017241739411149906;
                            }
                          }
                        }
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7250000000000000888) ) ) {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001886500000000000373) ) ) {
                      result[0] += -0.00022147534310715917;
                    } else {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4250000000000000444) ) ) {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05052567209861091174) ) ) {
                          result[0] += 0.0008538298723149253;
                        } else {
                          result[0] += -0.0004055257657245513;
                        }
                      } else {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4350000000000000533) ) ) {
                          result[0] += -0.0004908115776397035;
                        } else {
                          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004749500000000001117) ) ) {
                            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0229305563329877532) ) ) {
                              result[0] += 0.0005963929866404116;
                            } else {
                              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02930104421257910194) ) ) {
                                result[0] += -0.000819254969599072;
                              } else {
                                result[0] += 0.0005891999506372472;
                              }
                            }
                          } else {
                            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06508917425002432033) ) ) {
                              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03312950000000000617) ) ) {
                                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02563650000000000304) ) ) {
                                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02162700000000000386) ) ) {
                                    result[0] += -9.948104612758522e-05;
                                  } else {
                                    result[0] += 0.0025710908495727523;
                                  }
                                } else {
                                  result[0] += -0.0007196154528500378;
                                }
                              } else {
                                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                                  result[0] += 0.0007471252592714077;
                                } else {
                                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.168924500000000033) ) ) {
                                    result[0] += -0.00030068333223383413;
                                  } else {
                                    result[0] += 0.0012629068458964762;
                                  }
                                }
                              }
                            } else {
                              result[0] += 0.0009691209084889267;
                            }
                          }
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004749500000000001117) ) ) {
                      result[0] += 0.002259900718181246;
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.07196200000000001207) ) ) {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05052800000000001041) ) ) {
                          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5724391781153673753) ) ) {
                            result[0] += -9.67779849978478e-05;
                          } else {
                            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1206324332205917643) ) ) {
                              result[0] += 0.001664128593926166;
                            } else {
                              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6059258460552764403) ) ) {
                                result[0] += -0.00023808267224986155;
                              } else {
                                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7322719660050253099) ) ) {
                                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6722423356281408413) ) ) {
                                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6425364825628142595) ) ) {
                                      result[0] += 0.0012975295783248615;
                                    } else {
                                      result[0] += -0.0004895234216908817;
                                    }
                                  } else {
                                    result[0] += 0.002253399521534647;
                                  }
                                } else {
                                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.762281072713567931) ) ) {
                                    result[0] += -0.0005531021876069795;
                                  } else {
                                    result[0] += 0.000987459762398662;
                                  }
                                }
                              }
                            }
                          }
                        } else {
                          result[0] += -0.0008525746125603252;
                        }
                      } else {
                        result[0] += 0.0015438680552438261;
                      }
                    }
                  }
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021562361187840079) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01905700000000000102) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0110643527143887508) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002710500000000000669) ) ) {
                result[0] += 0.003584977923477332;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007090500000000000448) ) ) {
                    result[0] += 0.001044135343588028;
                  } else {
                    result[0] += -0.0005792765515075419;
                  }
                } else {
                  result[0] += 0.0020212222200031047;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01108250000000000207) ) ) {
                result[0] += 0.0028704463985426026;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9650000000000000799) ) ) {
                  result[0] += 0.0005828702632704503;
                } else {
                  result[0] += 0.002298809411013434;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.009662942724727452) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4052145559547739029) ) ) {
                  result[0] += -0.0009206699966663928;
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
                    result[0] += 0.0026854681946821782;
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.09856950000000001821) ) ) {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.03941486779484403707) ) ) {
                        result[0] += -0.0010987668397009008;
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.04446937286580055632) ) ) {
                          result[0] += 0.003622413106335908;
                        } else {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6116569490452262725) ) ) {
                            result[0] += -0.0008326832034787717;
                          } else {
                            result[0] += 0.002468766478197266;
                          }
                        }
                      }
                    } else {
                      result[0] += 0.001497559061070463;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3278371989949749321) ) ) {
                  result[0] += 0.0031185325171770627;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01881166515770610337) ) ) {
                    result[0] += -0.0004560456173883137;
                  } else {
                    result[0] += 0.0017645603873886612;
                  }
                }
              }
            } else {
              result[0] += -0.0013153092820977802;
            }
          }
        } else {
          result[0] += 0.002600674506153804;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -5.370953841321766e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -5.370953841321766e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                result[0] += -5.370953841321766e-06;
              } else {
                result[0] += -5.370953841321766e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6802634857286432579) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4781247323869347032) ) ) {
              result[0] += 4.329320883774648e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6425364825628142595) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006937836693866150477) ) ) {
                  result[0] += -8.849697971362758e-07;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01376440091032050082) ) ) {
                    result[0] += -3.888696201410614e-05;
                  } else {
                    result[0] += -1.886915054573155e-05;
                  }
                }
              } else {
                result[0] += 2.0484559290696806e-05;
              }
            }
          } else {
            result[0] += -1.383383449050767e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -5.370953841321766e-06;
              } else {
                result[0] += -5.370953841321766e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -5.370953841321766e-06;
                  } else {
                    result[0] += -5.370953841321766e-06;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -5.370953841321766e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -5.370953841321766e-06;
                        } else {
                          result[0] += -5.370953841321766e-06;
                        }
                      } else {
                        result[0] += -5.370953841321766e-06;
                      }
                    }
                  } else {
                    result[0] += -5.370953841321766e-06;
                  }
                }
              } else {
                result[0] += -5.370953841321766e-06;
              }
            }
          } else {
            result[0] += -5.370953841321766e-06;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -5.370953841321766e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -5.370953841321766e-06;
                } else {
                  result[0] += -5.370953841321766e-06;
                }
              } else {
                result[0] += -5.370953841321766e-06;
              }
            } else {
              result[0] += -5.370953841321766e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9350000000000001643) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001504690974371400121) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6858832018090453841) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)5.045799003287211847e-06) ) ) {
                result[0] += 7.966373143187945e-06;
              } else {
                result[0] += -1.4603328035800001e-05;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.125515493975159704e-06) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
                    result[0] += -6.483867232646463e-06;
                  } else {
                    result[0] += -5.286362118755577e-06;
                  }
                } else {
                  result[0] += -5.286362118755577e-06;
                }
              } else {
                result[0] += -3.744236635216614e-06;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03500000000000001027) ) ) {
              result[0] += -1.395396075691718e-06;
            } else {
              result[0] += 0.0011361848913986167;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5050000000000001155) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02577363736079425413) ) ) {
              result[0] += 1.5184792811701592e-06;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02796916660693585244) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6541365753517588422) ) ) {
                  result[0] += 0.0009177521516130704;
                } else {
                  result[0] += 0.0002850943348383477;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4082869870603015872) ) ) {
                  result[0] += 0.001252279706781308;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4443392717336683839) ) ) {
                    result[0] += -0.0009416147335622851;
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0650000000000000161) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7322719660050253099) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6334213184170854882) ) ) {
                          result[0] += -4.99319670849932e-05;
                        } else {
                          result[0] += 0.0003469639097261727;
                        }
                      } else {
                        result[0] += -6.793907026724678e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7890731911809046872) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6100010069597990858) ) ) {
                          result[0] += 0.0006742150170336459;
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6359282793467337935) ) ) {
                            result[0] += -0.0001635635682221784;
                          } else {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6635233717587941671) ) ) {
                              result[0] += 0.0009671069540535176;
                            } else {
                              result[0] += -0.00015784570000924723;
                            }
                          }
                        }
                      } else {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8480072969597991506) ) ) {
                          result[0] += 0.0010536479712010202;
                        } else {
                          result[0] += 4.404105113968437e-05;
                        }
                      }
                    }
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0816878293504414571) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003965500000000001142) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01620974339269775494) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4950000000000000511) ) ) {
                      result[0] += -0.00027086877408865847;
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002769500000000000694) ) ) {
                        result[0] += 0.0004513060510599382;
                      } else {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003637500000000000542) ) ) {
                          result[0] += -0.00019942403642995779;
                        } else {
                          result[0] += 0.001041108823518005;
                        }
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7250000000000000888) ) ) {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001653500000000000239) ) ) {
                        result[0] += 0.0010279380306553233;
                      } else {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002289500000000000302) ) ) {
                          result[0] += -0.0009383850485272095;
                        } else {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02979533478473985267) ) ) {
                            result[0] += 0.0018456770400852986;
                          } else {
                            result[0] += 0.00036967297924191475;
                          }
                        }
                      }
                    } else {
                      result[0] += 0.002889869054998805;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.068802141605957212) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8440161800932387548) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6722423356281408413) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.543101476988260834) ) ) {
                          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2004855000000000109) ) ) {
                            result[0] += 6.852945552573838e-05;
                          } else {
                            result[0] += 0.0030363396358826645;
                          }
                        } else {
                          result[0] += -0.0006217162940003549;
                        }
                      } else {
                        result[0] += 0.0014590373458779427;
                      }
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01940114940222455522) ) ) {
                        result[0] += -0.0005483000599014451;
                      } else {
                        result[0] += 6.162858676662994e-05;
                      }
                    }
                  } else {
                    result[0] += 0.0018583453724408876;
                  }
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02366047096071570086) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                    result[0] += -0.00016470687486827662;
                  } else {
                    result[0] += 0.00129608724221073;
                  }
                } else {
                  result[0] += -0.0011573695473562197;
                }
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006969500000000000868) ) ) {
                result[0] += 0.0016068960371695392;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6425364825628142595) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05052800000000001041) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03018900000000000403) ) ) {
                      result[0] += 0.002519305102120774;
                    } else {
                      result[0] += -0.0006180005807171251;
                    }
                  } else {
                    result[0] += 0.0024224864363718295;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                    result[0] += -0.0027963533028530245;
                  } else {
                    result[0] += 0.0007945203732883664;
                  }
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021562361187840079) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01905700000000000102) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01021941412521685209) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002710500000000000669) ) ) {
                result[0] += 0.003503314676051348;
              } else {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.08110515786938453375) ) ) {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5470680148669562204) ) ) {
                    result[0] += -0.0004710405336730973;
                  } else {
                    result[0] += 0.001842461086717029;
                  }
                } else {
                  result[0] += -0.0003995122334991878;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01108250000000000207) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
                  result[0] += 0.002596441030644046;
                } else {
                  result[0] += 0.002848021158649912;
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9650000000000000799) ) ) {
                  result[0] += 0.0008993186623574642;
                } else {
                  result[0] += 0.0023437512004298865;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0184998371148766029) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4601878067544193374) ) ) {
                result[0] += 0.0035112132998524697;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5400528323115579843) ) ) {
                  result[0] += -0.0011124776272698512;
                } else {
                  result[0] += -0.000889519633795105;
                }
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08693186820944626136) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4093335132160804135) ) ) {
                    result[0] += -0.0009573833766211604;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4674830972361809223) ) ) {
                      result[0] += 0.0027405372852003255;
                    } else {
                      result[0] += 0.0017726319321843054;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3278371989949749321) ) ) {
                    result[0] += 0.0029527723709751224;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4731110269597990081) ) ) {
                      result[0] += 0.0014141318438278033;
                    } else {
                      result[0] += 0.002106596974919994;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5499504253266332965) ) ) {
                  result[0] += -0.001712561084358107;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3830383354773237436) ) ) {
                    result[0] += 0.00210869322690232;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.564374608675820677) ) ) {
                      result[0] += -0.0009053079891867862;
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8440161800932387548) ) ) {
                        result[0] += 0.0020512998689036313;
                      } else {
                        result[0] += 2.524227723245539e-05;
                      }
                    }
                  }
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
            result[0] += 0.002363757746325933;
          } else {
            result[0] += 0.0028904656961787054;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -5.157164930220128e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -5.157164930220128e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                result[0] += -5.157164930220128e-06;
              } else {
                result[0] += -5.157164930220128e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6802634857286432579) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1643367459977091716) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -3.112269071476239e-05;
              } else {
                result[0] += 7.595656738918783e-05;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01326604349644140181) ) ) {
                result[0] += 1.116084393340069e-06;
              } else {
                result[0] += 2.0246739615574635e-05;
              }
            }
          } else {
            result[0] += -1.3283183619272834e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -5.157164930220128e-06;
              } else {
                result[0] += -5.157164930220128e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -5.157164930220128e-06;
                  } else {
                    result[0] += -5.157164930220128e-06;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -5.157164930220128e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -5.157164930220128e-06;
                        } else {
                          result[0] += -5.157164930220128e-06;
                        }
                      } else {
                        result[0] += -5.157164930220128e-06;
                      }
                    }
                  } else {
                    result[0] += -5.157164930220128e-06;
                  }
                }
              } else {
                result[0] += -5.157164930220128e-06;
              }
            }
          } else {
            result[0] += -5.157164930220128e-06;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -5.157164930220128e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -5.157164930220128e-06;
                } else {
                  result[0] += -5.157164930220128e-06;
                }
              } else {
                result[0] += -5.157164930220128e-06;
              }
            } else {
              result[0] += -5.157164930220128e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9350000000000001643) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.125515493975159704e-06) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6881801856532664408) ) ) {
                result[0] += -2.6867961375247873e-07;
              } else {
                result[0] += -6.225779199059127e-06;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8025985781909549255) ) ) {
                result[0] += -5.075940351142773e-06;
              } else {
                result[0] += -5.123717372569853e-06;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01238050000000000088) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6208328749497488142) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5400528323115579843) ) ) {
                  result[0] += 0.00016800461583146604;
                } else {
                  result[0] += -0.00021278302668748366;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8168185667587940513) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7114754460552764614) ) ) {
                    result[0] += -2.0055373623507084e-06;
                  } else {
                    result[0] += 2.2027192085441758e-05;
                  }
                } else {
                  result[0] += -6.052065602031956e-06;
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0142099505541319511) ) ) {
                result[0] += -2.876952433792038e-06;
              } else {
                result[0] += 0.00010044945883259169;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5050000000000001155) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02577363736079425413) ) ) {
              result[0] += 1.458036752404718e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3837516359296482826) ) ) {
                result[0] += 0.0024449048226609506;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4443392717336683839) ) ) {
                  result[0] += -0.0005781209676709028;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0650000000000000161) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04500000000000000527) ) ) {
                      result[0] += 1.516513687234683e-05;
                    } else {
                      result[0] += -0.00022185217612989995;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7890731911809046872) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6100010069597990858) ) ) {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.531569796683417195) ) ) {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4797597438944724013) ) ) {
                            result[0] += 0.0022902436768861218;
                          } else {
                            result[0] += -0.0002676498744933094;
                          }
                        } else {
                          result[0] += 0.0007797180716729775;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05831812793683335133) ) ) {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04953562823777350743) ) ) {
                            result[0] += -0.00013242933303460477;
                          } else {
                            result[0] += 0.0005471570295417479;
                          }
                        } else {
                          result[0] += -0.00023184314559052065;
                        }
                      }
                    } else {
                      result[0] += 0.0005613592708826414;
                    }
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1301603066321575797) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3998546246231156065) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03350035677887956004) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00135663295830650032) ) ) {
                      result[0] += -0.000728906141881315;
                    } else {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.8537219630417757221) ) ) {
                        result[0] += 0.001657107771129873;
                      } else {
                        result[0] += -4.771582572921979e-05;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3644118032412060892) ) ) {
                      result[0] += -0.0013816236671615652;
                    } else {
                      result[0] += 0.0015121243437781352;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.039722088301102687) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9993516786272610419) ) ) {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003965500000000001142) ) ) {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01620974339269775494) ) ) {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4389499174623116007) ) ) {
                            result[0] += 0.0015989651033758896;
                          } else {
                            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6802634857286432579) ) ) {
                              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6647073645226131422) ) ) {
                                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6481803955276382867) ) ) {
                                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05463331189772155372) ) ) {
                                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3750409390474713223) ) ) {
                                      result[0] += -0.00030568694155514033;
                                    } else {
                                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5353359946984925788) ) ) {
                                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.497782690150753826) ) ) {
                                          result[0] += 0.00040433014685136944;
                                        } else {
                                          result[0] += 0.001447893362209422;
                                        }
                                      } else {
                                        result[0] += 1.3046126084706381e-05;
                                      }
                                    }
                                  } else {
                                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5750000000000000666) ) ) {
                                      result[0] += 0.0007435072176151822;
                                    } else {
                                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5814822343216081713) ) ) {
                                        result[0] += -0.0008294698583715566;
                                      } else {
                                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6950000000000000622) ) ) {
                                          result[0] += -0.0003753106360373464;
                                        } else {
                                          result[0] += 0.0011764830479934834;
                                        }
                                      }
                                    }
                                  }
                                } else {
                                  result[0] += 0.001336480457401512;
                                }
                              } else {
                                result[0] += -0.00014464986226995737;
                              }
                            } else {
                              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.762281072713567931) ) ) {
                                result[0] += 0.0014610291228631526;
                              } else {
                                result[0] += -7.103777103056665e-05;
                              }
                            }
                          }
                        } else {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5650000000000000577) ) ) {
                            result[0] += 0.00022344000122801293;
                          } else {
                            result[0] += 0.0014198482465937231;
                          }
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0270604707267506038) ) ) {
                          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00421750000000000163) ) ) {
                            result[0] += -0.0010168121781483914;
                          } else {
                            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6449783570351760309) ) ) {
                              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6242129639949749453) ) ) {
                                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03389850000000000502) ) ) {
                                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0173600348455768029) ) ) {
                                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01444878842564100048) ) ) {
                                        result[0] += 3.665892011938408e-05;
                                      } else {
                                        result[0] += 0.0015554843585856067;
                                      }
                                    } else {
                                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02159955403810970287) ) ) {
                                        result[0] += -0.00048461100841311577;
                                      } else {
                                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02328402533912880476) ) ) {
                                          result[0] += 0.002648002833441435;
                                        } else {
                                          result[0] += -9.954308426101469e-05;
                                        }
                                      }
                                    }
                                  } else {
                                    result[0] += 0.0018584169744211858;
                                  }
                                } else {
                                  result[0] += -0.0016646222544775048;
                                }
                              } else {
                                result[0] += -0.0009374772390587577;
                              }
                            } else {
                              result[0] += 0.0004268451183150908;
                            }
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1523979577405769892) ) ) {
                            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06646350000000002256) ) ) {
                              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01044150000000000113) ) ) {
                                result[0] += 0.0016574497379910115;
                              } else {
                                result[0] += 0.0002129698072568702;
                              }
                            } else {
                              result[0] += 0.002409015879850486;
                            }
                          } else {
                            result[0] += 0.00031124009703849433;
                          }
                        }
                      }
                    } else {
                      result[0] += -0.001402510207501543;
                    }
                  } else {
                    result[0] += 0.001311345488010836;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8025985781909549255) ) ) {
                  result[0] += -0.000865274330995201;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02366047096071570086) ) ) {
                    result[0] += 0.0012643769214220155;
                  } else {
                    result[0] += -9.061729759678378e-05;
                  }
                }
              }
            } else {
              result[0] += 0.001450486560084213;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021562361187840079) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01905700000000000102) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01021941412521685209) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002710500000000000669) ) ) {
                result[0] += 0.0033638664789588384;
              } else {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.08110515786938453375) ) ) {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5470680148669562204) ) ) {
                    result[0] += -0.0004522909324376637;
                  } else {
                    result[0] += 0.0017691225771871387;
                  }
                } else {
                  result[0] += -0.0003836097908614457;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01108250000000000207) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
                  result[0] += 0.002493090617089868;
                } else {
                  result[0] += 0.002734656687405015;
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9650000000000000799) ) ) {
                  result[0] += 0.0008635216022376041;
                } else {
                  result[0] += 0.0022504590158689136;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4052145559547739029) ) ) {
                result[0] += -0.0008832380670841213;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0184998371148766029) ) ) {
                  result[0] += -0.0009077156983518587;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4674830972361809223) ) ) {
                    result[0] += 0.002196865428772986;
                  } else {
                    result[0] += 0.0010306300455234058;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3278371989949749321) ) ) {
                result[0] += 0.0028768663812631687;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01881166515770610337) ) ) {
                  result[0] += -0.0007667677601303196;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09956041386891252565) ) ) {
                    result[0] += 0.001986202141169264;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.564374608675820677) ) ) {
                      result[0] += 0.00039280024225221466;
                    } else {
                      result[0] += 0.0012932692959587075;
                    }
                  }
                }
              }
            }
          }
        } else {
          result[0] += 0.0023840989682717257;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -4.951885810835257e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -4.951885810835257e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                result[0] += -4.951885810835257e-06;
              } else {
                result[0] += -4.951885810835257e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4781247323869347032) ) ) {
            result[0] += 4.216938888324288e-05;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1643367459977091716) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006708500000000000921) ) ) {
                result[0] += -1.3266736805813627e-06;
              } else {
                result[0] += -6.65775134708939e-05;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6334213184170854882) ) ) {
                  result[0] += 4.474340566363935e-06;
                } else {
                  result[0] += -6.301693115008997e-07;
                }
              } else {
                result[0] += -1.2805586366928903e-05;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -4.951885810835257e-06;
              } else {
                result[0] += -4.951885810835257e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -4.951885810835257e-06;
                  } else {
                    result[0] += -4.951885810835257e-06;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -4.951885810835257e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -4.951885810835257e-06;
                        } else {
                          result[0] += -4.951885810835257e-06;
                        }
                      } else {
                        result[0] += -4.951885810835257e-06;
                      }
                    }
                  } else {
                    result[0] += -4.951885810835257e-06;
                  }
                }
              } else {
                result[0] += -4.951885810835257e-06;
              }
            }
          } else {
            result[0] += -4.951885810835257e-06;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -4.951885810835257e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -4.951885810835257e-06;
                } else {
                  result[0] += -4.951885810835257e-06;
                }
              } else {
                result[0] += -4.951885810835257e-06;
              }
            } else {
              result[0] += -4.951885810835257e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.125515493975159704e-06) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6881801856532664408) ) ) {
                result[0] += -2.5798491710150486e-07;
              } else {
                result[0] += -5.97796426803404e-06;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8025985781909549255) ) ) {
                result[0] += -4.873894347295415e-06;
              } else {
                result[0] += -4.91976962134422e-06;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01238050000000000088) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6208328749497488142) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5400528323115579843) ) ) {
                  result[0] += 0.00016131725173566529;
                } else {
                  result[0] += -0.0002043132738427574;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8168185667587940513) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7114754460552764614) ) ) {
                    result[0] += -1.925707659557155e-06;
                  } else {
                    result[0] += 2.115040752357436e-05;
                  }
                } else {
                  result[0] += -5.811165279072621e-06;
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0142099505541319511) ) ) {
                result[0] += -2.7624363634099795e-06;
              } else {
                result[0] += 9.64511037807665e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5050000000000001155) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02577363736079425413) ) ) {
              result[0] += 1.400000117041275e-06;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02796916660693585244) ) ) {
                result[0] += 0.0005771490138302746;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0650000000000000161) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7322719660050253099) ) ) {
                    result[0] += 5.26316846921069e-05;
                  } else {
                    result[0] += -6.583842258186844e-05;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7890731911809046872) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4850000000000000422) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7640286906783920751) ) ) {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4082869870603015872) ) ) {
                          result[0] += 0.0011142133664424595;
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4443392717336683839) ) ) {
                            result[0] += -0.0006266537369873023;
                          } else {
                            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7342470301758795559) ) ) {
                              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6100010069597990858) ) ) {
                                result[0] += 0.000661500002508279;
                              } else {
                                result[0] += -0.00015102900361131706;
                              }
                            } else {
                              result[0] += 0.0003399489034054308;
                            }
                          }
                        }
                      } else {
                        result[0] += -0.00036634367743795365;
                      }
                    } else {
                      result[0] += -0.0004700389985116253;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8480072969597991506) ) ) {
                      result[0] += 0.0009893631812164252;
                    } else {
                      result[0] += 1.99433062233207e-05;
                    }
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0816878293504414571) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.272781830548367354) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003965500000000001142) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006782232836504950395) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002237500000000000339) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001074448343160400252) ) ) {
                          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.72638075848137134e-06) ) ) {
                            result[0] += -0.0008313799325829118;
                          } else {
                            result[0] += 0.0005464303362168531;
                          }
                        } else {
                          result[0] += -5.241024502079781e-05;
                        }
                      } else {
                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7850000000000001421) ) ) {
                          result[0] += 0.0006808447663615091;
                        } else {
                          result[0] += -4.322947943944017e-05;
                        }
                      }
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05463331189772155372) ) ) {
                        result[0] += 0.00018817684335297474;
                      } else {
                        result[0] += -0.00045427525445729353;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8050000000000001599) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003504500000000000236) ) ) {
                        result[0] += 0.00034590098566468876;
                      } else {
                        result[0] += 0.0008175452615280522;
                      }
                    } else {
                      result[0] += 0.003368677901524081;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.068802141605957212) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8440161800932387548) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03091100000000000445) ) ) {
                        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.03941486779484403707) ) ) {
                          if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1711110322396684202) ) ) {
                            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02455150000000000388) ) ) {
                              result[0] += 0.0002638465197228853;
                            } else {
                              result[0] += -0.0012307589854419559;
                            }
                          } else {
                            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.09893965937729458371) ) ) {
                              result[0] += -0.0012073614750084628;
                            } else {
                              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
                                result[0] += -0.0003681493205507573;
                              } else {
                                result[0] += 0.0011036823041799411;
                              }
                            }
                          }
                        } else {
                          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.06355808660527756393) ) ) {
                            result[0] += 0.0010302213130632893;
                          } else {
                            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4364163272837385255) ) ) {
                              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3251271839107726103) ) ) {
                                result[0] += 0.00012351863033397813;
                              } else {
                                result[0] += -0.0008704050226972062;
                              }
                            } else {
                              result[0] += 0.0005518291051889158;
                            }
                          }
                        }
                      } else {
                        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.08110515786938453375) ) ) {
                          result[0] += 0.0013313674815660444;
                        } else {
                          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03873000000000000748) ) ) {
                            result[0] += 0.0018167236986710849;
                          } else {
                            result[0] += -4.208106248212496e-05;
                          }
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01940114940222455522) ) ) {
                        result[0] += -0.0005302314719995621;
                      } else {
                        result[0] += 1.1074984232689093e-05;
                      }
                    }
                  } else {
                    result[0] += 0.0009221652821709408;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01170971943545395279) ) ) {
                  result[0] += 0.0007008631146254105;
                } else {
                  result[0] += -0.001096721632038228;
                }
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006969500000000000868) ) ) {
                result[0] += 0.001440229701351216;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1311798687976579447) ) ) {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3245708964283948172) ) ) {
                    result[0] += 0.00011515613650431583;
                  } else {
                    result[0] += 0.0025486514749309113;
                  }
                } else {
                  result[0] += 0.00016182107319240893;
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021562361187840079) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02300100000000000408) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0110643527143887508) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002710500000000000669) ) ) {
                result[0] += 0.0031888754078243857;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007090500000000000448) ) ) {
                    result[0] += 0.0009526100001380699;
                  } else {
                    result[0] += -0.0005515595818868008;
                  }
                } else {
                  result[0] += 0.0025150188002329584;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01108250000000000207) ) ) {
                result[0] += 0.0025497629287175834;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02884459794480960168) ) ) {
                  result[0] += 0.0009689731795346196;
                } else {
                  result[0] += 0.002257041737277706;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01444878842564100048) ) ) {
                result[0] += -0.0010728763382612493;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3837516359296482826) ) ) {
                  result[0] += -0.0008107549345831522;
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                    result[0] += 0.002211074453083905;
                  } else {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.03941486779484403707) ) ) {
                      result[0] += -0.0005421924159896531;
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.04446937286580055632) ) ) {
                        result[0] += 0.003261528614252899;
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1507499186893259402) ) ) {
                          result[0] += -0.0010172822409215544;
                        } else {
                          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3561404984221285264) ) ) {
                            result[0] += 0.0014138762144812365;
                          } else {
                            result[0] += -6.032580273091983e-05;
                          }
                        }
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09956041386891252565) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01881166515770610337) ) ) {
                  result[0] += 0.00015375604547979643;
                } else {
                  result[0] += 0.0020602143334350446;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5748180127889448432) ) ) {
                  result[0] += -0.001602751501657183;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4218023131278703652) ) ) {
                    result[0] += 0.001987044004647321;
                  } else {
                    result[0] += 4.186239734632336e-05;
                  }
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
            result[0] += 0.0021747709951698965;
          } else {
            result[0] += 0.0028037078918226955;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -4.754777753928628e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -4.754777753928628e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                result[0] += -4.754777753928628e-06;
              } else {
                result[0] += -4.754777753928628e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002399500000000000157) ) ) {
            result[0] += 1.0267849100618319e-06;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01086462614096590264) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1643367459977091716) ) ) {
                  result[0] += -2.2658783864610532e-05;
                } else {
                  result[0] += -8.69085565848161e-07;
                }
              } else {
                result[0] += -1.1676051242961526e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01332150000000000174) ) ) {
                result[0] += -2.3433549708582274e-05;
              } else {
                result[0] += 0.0004453799847406539;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -4.754777753928628e-06;
              } else {
                result[0] += -4.754777753928628e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -4.754777753928628e-06;
                  } else {
                    result[0] += -4.754777753928628e-06;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -4.754777753928628e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -4.754777753928628e-06;
                        } else {
                          result[0] += -4.754777753928628e-06;
                        }
                      } else {
                        result[0] += -4.754777753928628e-06;
                      }
                    }
                  } else {
                    result[0] += -4.754777753928628e-06;
                  }
                }
              } else {
                result[0] += -4.754777753928628e-06;
              }
            }
          } else {
            result[0] += -4.754777753928628e-06;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -4.754777753928628e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -4.754777753928628e-06;
                } else {
                  result[0] += -4.754777753928628e-06;
                }
              } else {
                result[0] += -4.754777753928628e-06;
              }
            } else {
              result[0] += -4.754777753928628e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.125515493975159704e-06) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6881801856532664408) ) ) {
                result[0] += -2.477159190543761e-07;
              } else {
                result[0] += -5.740013522370401e-06;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8025985781909549255) ) ) {
                result[0] += -4.679890712910002e-06;
              } else {
                result[0] += -4.723939937959851e-06;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01238050000000000088) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.0255903056102470966) ) ) {
                result[0] += 0.000307244985127605;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3346339054385528144) ) ) {
                  result[0] += -0.00017283021495059713;
                } else {
                  result[0] += -1.8490555497457827e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9186477097784532253) ) ) {
                result[0] += 0.0002912110530271367;
              } else {
                result[0] += -4.72694667987631e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5050000000000001155) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8841271910804021639) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8507017292462312197) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02500000000000000486) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6047319804020101497) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5748180127889448432) ) ) {
                        result[0] += -1.0125127615209717e-05;
                      } else {
                        result[0] += 8.422514312041067e-05;
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6334213184170854882) ) ) {
                        result[0] += -8.982406843738372e-05;
                      } else {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7712418641206031378) ) ) {
                          result[0] += -1.0505440486621305e-05;
                        } else {
                          result[0] += -5.7147333233195134e-05;
                        }
                      }
                    }
                  } else {
                    result[0] += 5.1150109142906244e-05;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4693879269597989734) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2669585275879397535) ) ) {
                      result[0] += -0.0002338775766248196;
                    } else {
                      result[0] += 0.00020523080671493163;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4734952854020100799) ) ) {
                      result[0] += -0.00048601783724139903;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4797597438944724013) ) ) {
                        result[0] += 0.000366590665433129;
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4832433377889447379) ) ) {
                          result[0] += -0.0008481106806060925;
                        } else {
                          result[0] += 1.2443178049366955e-05;
                        }
                      }
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2050000000000000433) ) ) {
                  result[0] += -7.904890740520122e-06;
                } else {
                  result[0] += -0.0003236922748002217;
                }
              }
            } else {
              result[0] += 7.510039161786046e-05;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1301603066321575797) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6802634857286432579) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5986852915639623296) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3998546246231156065) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2929122217587940002) ) ) {
                        result[0] += 0.0007424290922087029;
                      } else {
                        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7572008430306190752) ) ) {
                          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.8537219630417757221) ) ) {
                            result[0] += 0.0005826165421829803;
                          } else {
                            result[0] += -0.0010612048276449812;
                          }
                        } else {
                          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6269304705026225166) ) ) {
                            result[0] += 0.002004800916113801;
                          } else {
                            result[0] += -0.0005506852933507319;
                          }
                        }
                      }
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.06355808660527756393) ) ) {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0683765000000000206) ) ) {
                          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003965500000000001142) ) ) {
                            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0004715000000000000766) ) ) {
                              result[0] += 1.583342953954476e-05;
                            } else {
                              result[0] += 0.0006987368509517876;
                            }
                          } else {
                            result[0] += 0.0003386930653982753;
                          }
                        } else {
                          result[0] += 0.001376192078076652;
                        }
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5528143519346734314) ) ) {
                          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004848500000000001246) ) ) {
                            result[0] += -0.00022687207797229055;
                          } else {
                            result[0] += -0.0020881485303795534;
                          }
                        } else {
                          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01949300000000000338) ) ) {
                            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003226000000000000135) ) ) {
                              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002063500000000000664) ) ) {
                                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0003305000000000000646) ) ) {
                                  result[0] += -0.00022032372164295966;
                                } else {
                                  result[0] += 0.0004630221139251679;
                                }
                              } else {
                                result[0] += -0.0004291791772000682;
                              }
                            } else {
                              result[0] += 0.0008031786428939288;
                            }
                          } else {
                            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
                              result[0] += -0.0012844669702792896;
                            } else {
                              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0480970000000000078) ) ) {
                                result[0] += 0.0009061396804304714;
                              } else {
                                result[0] += -4.4702983359971156e-05;
                              }
                            }
                          }
                        }
                      }
                    }
                  } else {
                    result[0] += -0.0011421834667981415;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8440161800932387548) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5053668411911326208) ) ) {
                      result[0] += 9.417887305498483e-05;
                    } else {
                      result[0] += 0.0013528264513675958;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8764371766733816127) ) ) {
                      result[0] += -0.0008539141747748569;
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.039722088301102687) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9993516786272610419) ) ) {
                          result[0] += 0.0007913515357064995;
                        } else {
                          result[0] += -0.0008666334442589394;
                        }
                      } else {
                        result[0] += 0.0011257117597612215;
                      }
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8025985781909549255) ) ) {
                  result[0] += -0.0007027084681745498;
                } else {
                  result[0] += 0.0003382471350641236;
                }
              }
            } else {
              result[0] += 0.001269494075079513;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021562361187840079) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01905700000000000102) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0110643527143887508) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002710500000000000669) ) ) {
                result[0] += 0.003061943354185697;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007090500000000000448) ) ) {
                    result[0] += 0.0009146916972349267;
                  } else {
                    result[0] += -0.0005296049485194371;
                  }
                } else {
                  result[0] += 0.0018566301003973362;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01108250000000000207) ) ) {
                result[0] += 0.002448270520441049;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9650000000000000799) ) ) {
                  result[0] += 0.00043811267699856647;
                } else {
                  result[0] += 0.001985865578144622;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.009662942724727452) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3278371989949749321) ) ) {
                result[0] += 0.002678417172293707;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3644118032412060892) ) ) {
                  result[0] += -0.0006855066648827385;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0173600348455768029) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5400528323115579843) ) ) {
                      result[0] += -0.000841131666174896;
                    } else {
                      result[0] += 0.0021529024571202964;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08693186820944626136) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4093335132160804135) ) ) {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3687216492462311868) ) ) {
                          result[0] += 0.003187143652392336;
                        } else {
                          result[0] += -0.0017973698215269717;
                        }
                      } else {
                        result[0] += 0.0018520632835931127;
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5499504253266332965) ) ) {
                        result[0] += -0.0021048258896584596;
                      } else {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03350035677887956004) ) ) {
                          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02577363736079425413) ) ) {
                            result[0] += 0.0023898129218176425;
                          } else {
                            result[0] += -0.0010144606192722626;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3830383354773237436) ) ) {
                            result[0] += 0.002204026263165961;
                          } else {
                            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5876805463210391656) ) ) {
                              result[0] += -0.0003426865859055903;
                            } else {
                              result[0] += 0.0015765638164736853;
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            } else {
              result[0] += -0.0012342158555498288;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
            result[0] += 0.002088205007695614;
          } else {
            result[0] += 0.0026921072944337708;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -4.565515513258816e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -4.565515513258816e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                result[0] += -4.565515513258816e-06;
              } else {
                result[0] += -4.565515513258816e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002399500000000000157) ) ) {
            result[0] += 9.8591410119938e-07;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01376440091032050082) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5528143519346734314) ) ) {
                  result[0] += -1.897177481888731e-05;
                } else {
                  result[0] += -1.100875555628729e-06;
                }
              } else {
                result[0] += 1.899164714501723e-05;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02446805795595660346) ) ) {
                result[0] += 2.006554050979383e-05;
              } else {
                result[0] += -1.219825328332023e-05;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -4.565515513258816e-06;
              } else {
                result[0] += -4.565515513258816e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -4.565515513258816e-06;
                  } else {
                    result[0] += -4.565515513258816e-06;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -4.565515513258816e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -4.565515513258816e-06;
                        } else {
                          result[0] += -4.565515513258816e-06;
                        }
                      } else {
                        result[0] += -4.565515513258816e-06;
                      }
                    }
                  } else {
                    result[0] += -4.565515513258816e-06;
                  }
                }
              } else {
                result[0] += -4.565515513258816e-06;
              }
            }
          } else {
            result[0] += -4.565515513258816e-06;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -4.565515513258816e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -4.565515513258816e-06;
                } else {
                  result[0] += -4.565515513258816e-06;
                }
              } else {
                result[0] += -4.565515513258816e-06;
              }
            } else {
              result[0] += -4.565515513258816e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9350000000000001643) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3115605993075549196) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002194500000000000704) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5531655541959800138) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5224889643718594323) ) ) {
                  result[0] += -3.797160533891667e-05;
                } else {
                  result[0] += -3.302170208302814e-05;
                }
              } else {
                result[0] += 8.765459184200703e-06;
              }
            } else {
              result[0] += 0.00011723967922467129;
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.125515493975159704e-06) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
                    result[0] += -5.511534321671433e-06;
                  } else {
                    result[0] += -4.493609324324938e-06;
                  }
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.038494786985569569e-06) ) ) {
                    result[0] += 1.6701003658675716e-05;
                  } else {
                    result[0] += -4.3921252012400614e-05;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.714147492562814179) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00421750000000000163) ) ) {
                    result[0] += -1.452011475234074e-05;
                  } else {
                    result[0] += -6.707356598221299e-05;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
                    result[0] += 5.396395546994552e-05;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.068802141605957212) ) ) {
                      result[0] += -4.083743324510062e-05;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8419399877135679278) ) ) {
                        result[0] += 2.1137395711208583e-05;
                      } else {
                        result[0] += -5.506252908165304e-06;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001425500000000000335) ) ) {
                result[0] += 0.00019166746483739348;
              } else {
                result[0] += -4.9650986204282024e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5050000000000001155) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.96280210579579717) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04562750000000000833) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8282572652763819931) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.373325504271297691e-06) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.16917529420057901e-06) ) ) {
                      result[0] += -2.2941874808781123e-05;
                    } else {
                      result[0] += -0.0002008669428999745;
                    }
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.038494786985569569e-06) ) ) {
                      result[0] += 0.00012274978355812795;
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002339521674937150662) ) ) {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001074448343160400252) ) ) {
                          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.381175493840676405e-06) ) ) {
                            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.835029170797551251e-06) ) ) {
                              result[0] += -7.11930170599735e-06;
                            } else {
                              result[0] += -0.00011997294752121383;
                            }
                          } else {
                            result[0] += 1.9722783458510322e-05;
                          }
                        } else {
                          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00135663295830650032) ) ) {
                            result[0] += -0.000282094197761771;
                          } else {
                            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002055218118527550337) ) ) {
                              result[0] += -3.7888576699196603e-05;
                            } else {
                              result[0] += -0.0005036419027858244;
                            }
                          }
                        }
                      } else {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002998483312272000063) ) ) {
                          result[0] += 0.0002993199190787012;
                        } else {
                          result[0] += 6.545800431710422e-05;
                        }
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                    result[0] += -0.00017167050678259697;
                  } else {
                    result[0] += 0.0001644870728616642;
                  }
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5950000000000000844) ) ) {
                  result[0] += 0.00041293586850095845;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02616152934301940389) ) ) {
                    result[0] += -0.00035197424140253096;
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6750000000000001554) ) ) {
                      result[0] += -0.0007642596884553739;
                    } else {
                      result[0] += 0.001825370060399794;
                    }
                  }
                }
              }
            } else {
              result[0] += -5.7278619418545484e-05;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1301603066321575797) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6914593314070353047) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6156410786045318773) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00135663295830650032) ) ) {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001074448343160400252) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05463331189772155372) ) ) {
                          result[0] += 0.0003974727438059255;
                        } else {
                          result[0] += -0.0007688217777416912;
                        }
                      } else {
                        result[0] += -0.00044186187524543065;
                      }
                    } else {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001653500000000000239) ) ) {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0004715000000000000766) ) ) {
                          result[0] += 2.528661415511601e-05;
                        } else {
                          result[0] += 0.0007695509847799862;
                        }
                      } else {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001798500000000000185) ) ) {
                          result[0] += -0.0005515406826412934;
                        } else {
                          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003965500000000001142) ) ) {
                            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003637500000000000542) ) ) {
                              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05463331189772155372) ) ) {
                                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003024500000000000712) ) ) {
                                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002063500000000000664) ) ) {
                                    result[0] += 4.2282828346124826e-05;
                                  } else {
                                    result[0] += 0.001716339813532136;
                                  }
                                } else {
                                  result[0] += 0.00010234294667184972;
                                }
                              } else {
                                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6950000000000000622) ) ) {
                                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6150000000000001021) ) ) {
                                    result[0] += 0.00034046196444565845;
                                  } else {
                                    result[0] += -0.0005955158337152105;
                                  }
                                } else {
                                  result[0] += 0.0013835412329347716;
                                }
                              }
                            } else {
                              result[0] += 0.00173308303261572;
                            }
                          } else {
                            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08720350000000000323) ) ) {
                              result[0] += 5.70348576991857e-05;
                            } else {
                              result[0] += 0.001023087787484456;
                            }
                          }
                        }
                      }
                    }
                  } else {
                    result[0] += -0.0009699950107440801;
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8440161800932387548) ) ) {
                    result[0] += 0.0013833446619213664;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8764371766733816127) ) ) {
                      result[0] += -0.0008181143142555842;
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.039722088301102687) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                          result[0] += 0.0015956919374682137;
                        } else {
                          result[0] += -0.00010303904554470133;
                        }
                      } else {
                        result[0] += 0.0011358246551474223;
                      }
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8025985781909549255) ) ) {
                  result[0] += -0.0008033727019197693;
                } else {
                  result[0] += 0.00041516063072768067;
                }
              }
            } else {
              result[0] += 0.001262224935811042;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021562361187840079) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01195250000000000305) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0110643527143887508) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002710500000000000669) ) ) {
                result[0] += 0.0031907278828625756;
              } else {
                result[0] += -4.171422242915097e-05;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
                result[0] += 0.002170468798200262;
              } else {
                result[0] += 0.002404737448289789;
              }
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.421180086331658321) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03468100000000001043) ) ) {
                  result[0] += 0.0007266804628320549;
                } else {
                  result[0] += -0.0013440319074699014;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03181986453917805963) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5041457217085428821) ) ) {
                    result[0] += 0.0017345416432427113;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
                      result[0] += -0.0006699711050333885;
                    } else {
                      result[0] += 0.0005595223792173183;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03795623917694670307) ) ) {
                    result[0] += 0.002299064542488939;
                  } else {
                    result[0] += 0.0011854872028068625;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1206324332205917643) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
                  result[0] += 0.0026028424257567365;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4731110269597990081) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4639489995477387718) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4129968667336683663) ) ) {
                        result[0] += 0.0008445701372144397;
                      } else {
                        result[0] += 0.002353638073475965;
                      }
                    } else {
                      result[0] += -0.00029460814071893604;
                    }
                  } else {
                    result[0] += 0.001931163549270468;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5748180127889448432) ) ) {
                  result[0] += -0.0014725429796193096;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7269841738944724518) ) ) {
                    result[0] += 0.0015623846261482222;
                  } else {
                    result[0] += -0.0006740070337791052;
                  }
                }
              }
            }
          }
        } else {
          result[0] += 0.002119514508588365;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += -4.3837867888955775e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -4.3837867888955775e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                result[0] += -4.3837867888955775e-06;
              } else {
                result[0] += -4.3837867888955775e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4781247323869347032) ) ) {
            result[0] += 4.041073655812098e-05;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002710500000000000669) ) ) {
              result[0] += 5.642016266979377e-07;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03705350000000001004) ) ) {
                result[0] += -1.5762959871440956e-05;
              } else {
                result[0] += 9.585673675384338e-06;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                result[0] += -4.3837867888955775e-06;
              } else {
                result[0] += -4.3837867888955775e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                    result[0] += -4.3837867888955775e-06;
                  } else {
                    result[0] += -4.3837867888955775e-06;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      result[0] += -4.3837867888955775e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -4.3837867888955775e-06;
                        } else {
                          result[0] += -4.3837867888955775e-06;
                        }
                      } else {
                        result[0] += -4.3837867888955775e-06;
                      }
                    }
                  } else {
                    result[0] += -4.3837867888955775e-06;
                  }
                }
              } else {
                result[0] += -4.3837867888955775e-06;
              }
            }
          } else {
            result[0] += -4.3837867888955775e-06;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -4.3837867888955775e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  result[0] += -4.3837867888955775e-06;
                } else {
                  result[0] += -4.3837867888955775e-06;
                }
              } else {
                result[0] += -4.3837867888955775e-06;
              }
            } else {
              result[0] += -4.3837867888955775e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02500000000000000486) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3346339054385528144) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1908722399174398732) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1165587384072143268) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4389499174623116007) ) ) {
                    result[0] += 0.00035500902068006686;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4693879269597989734) ) ) {
                      result[0] += -0.00016446409265725206;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5041457217085428821) ) ) {
                        result[0] += 0.0004809821435850767;
                      } else {
                        result[0] += -8.870802906931992e-06;
                      }
                    }
                  }
                } else {
                  result[0] += 0.00027688250812532003;
                }
              } else {
                result[0] += -3.1723863794641515e-05;
              }
            } else {
              result[0] += 0.0002957451499012935;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.883880929790755059e-06) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
                result[0] += -3.232601288715131e-06;
              } else {
                result[0] += -1.1958685043515467e-05;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6334213184170854882) ) ) {
                result[0] += -8.373898975503163e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.723113719091885043) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6858832018090453841) ) ) {
                      result[0] += 1.3592759920696187e-06;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7114754460552764614) ) ) {
                        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
                          result[0] += -4.316152039939212e-05;
                        } else {
                          result[0] += -1.7499654103220277e-05;
                        }
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7218051716834171794) ) ) {
                              result[0] += 1.5392407869042303e-05;
                            } else {
                              result[0] += -0.00015615006858681784;
                            }
                          } else {
                            result[0] += 0.00015706324752873724;
                          }
                        } else {
                          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9567162861906464144) ) ) {
                            result[0] += 1.9658787901674053e-05;
                          } else {
                            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                              result[0] += -0.00013018214999384168;
                            } else {
                              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.121680358022378199) ) ) {
                                result[0] += 6.298153215700814e-06;
                              } else {
                                result[0] += -1.3005344708216257e-05;
                              }
                            }
                          }
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.121680358022378199) ) ) {
                      result[0] += -4.969640080828656e-05;
                    } else {
                      result[0] += 6.620419728971146e-05;
                    }
                  }
                } else {
                  result[0] += -5.214764024519478e-06;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02577363736079425413) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0240756843176193544) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5361772370603016258) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6150000000000001021) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01622350000000000528) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5750000000000000666) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.008306500000000001382) ) ) {
                        result[0] += 4.870315661879836e-05;
                      } else {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4797597438944724013) ) ) {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4592177672613065309) ) ) {
                            result[0] += -0.00011861192253785879;
                          } else {
                            result[0] += 0.001269756732646036;
                          }
                        } else {
                          result[0] += -0.0008130950357343596;
                        }
                      }
                    } else {
                      result[0] += -0.0006223671237059807;
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4150000000000000355) ) ) {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02031150000000000316) ) ) {
                        result[0] += 0.001476769698866806;
                      } else {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0683765000000000206) ) ) {
                          result[0] += 0.00041783635484337846;
                        } else {
                          result[0] += -0.00027118881187888834;
                        }
                      }
                    } else {
                      result[0] += 0.0018916237912452085;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007851000000000002074) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6850000000000001643) ) ) {
                      result[0] += 0.0008855199332955837;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4052145559547739029) ) ) {
                        result[0] += -4.7718299389168804e-05;
                      } else {
                        result[0] += 0.0007446654238662161;
                      }
                    }
                  } else {
                    result[0] += 4.866613520590298e-05;
                  }
                }
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.07196201389915944657) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5455059598241206453) ) ) {
                    result[0] += -0.0013013544267293509;
                  } else {
                    result[0] += -3.728245091301161e-05;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02120250000000000259) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01724500000000000338) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.249304608119721216) ) ) {
                        result[0] += 9.586001351071713e-06;
                      } else {
                        result[0] += 0.0001482733722381916;
                      }
                    } else {
                      result[0] += 0.0008828160107958578;
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3050000000000000488) ) ) {
                      result[0] += 6.829926305723911e-07;
                    } else {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7350000000000000977) ) ) {
                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6150000000000001021) ) ) {
                          result[0] += -0.0004985808546410014;
                        } else {
                          result[0] += -0.0011311270605315201;
                        }
                      } else {
                        result[0] += 0.00033920758686484243;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01415250000000000188) ) ) {
                result[0] += 3.950459162832008e-06;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05439750000000000835) ) ) {
                  result[0] += -0.0007597712910552494;
                } else {
                  result[0] += 0.0001024459878076054;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.194581012612933923) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0683765000000000206) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7835979262278595092) ) ) {
                  result[0] += -0.0010985506804088822;
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6130861605291061389) ) ) {
                    result[0] += 0.0017247950003286363;
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05185700000000000726) ) ) {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6150000000000001021) ) ) {
                        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1044543990012605922) ) ) {
                          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4250000000000000444) ) ) {
                            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3050000000000000488) ) ) {
                              result[0] += -0.0005397434997556576;
                            } else {
                              result[0] += 0.002362716191607546;
                            }
                          } else {
                            result[0] += -0.0007335006772923135;
                          }
                        } else {
                          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3115605993075549196) ) ) {
                            result[0] += 0.000632487195401107;
                          } else {
                            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6558660377084782889) ) ) {
                              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5986852915639623296) ) ) {
                                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4287309711685468594) ) ) {
                                  result[0] += -0.0005220466354348055;
                                } else {
                                  result[0] += 0.0003018816165647419;
                                }
                              } else {
                                result[0] += -0.0002475385629744538;
                              }
                            } else {
                              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8466324982590252013) ) ) {
                                result[0] += 0.0014838190460955754;
                              } else {
                                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9112103514676580529) ) ) {
                                  result[0] += -0.00040874165560327106;
                                } else {
                                  result[0] += 0.00042160314566536074;
                                }
                              }
                            }
                          }
                        }
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.52031910737473408) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3115605993075549196) ) ) {
                            result[0] += 0.0008498960492718364;
                          } else {
                            result[0] += -0.00028566156341549865;
                          }
                        } else {
                          result[0] += 0.0014054354008626413;
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05860550000000001175) ) ) {
                        result[0] += -0.0007388130662630149;
                      } else {
                        result[0] += 0.001017552030359528;
                      }
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03940025850376690369) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5041457217085428821) ) ) {
                    result[0] += 0.003438792171582615;
                  } else {
                    result[0] += -0.00019473267182657476;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
                    result[0] += 0.0022700730616023197;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3892782419974109565) ) ) {
                      result[0] += 0.0002778224776120268;
                    } else {
                      result[0] += 0.0016256423055924702;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8022705390703518402) ) ) {
                result[0] += -0.0011732189840202778;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.540399458636966701) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004848500000000001246) ) ) {
                    result[0] += -0.0001287008051022927;
                  } else {
                    result[0] += 0.0006028341058637106;
                  }
                } else {
                  result[0] += 0.0004951225405284842;
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00583050000000000148) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008506177121675452882) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5012509875628141653) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4251092621105527214) ) ) {
                  result[0] += 0.0013413659546571354;
                } else {
                  result[0] += -0.001559463956122372;
                }
              } else {
                result[0] += 0.0025696360019526123;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3687216492462311868) ) ) {
                result[0] += 0.0023165116118005276;
              } else {
                result[0] += 0.0024421021572411873;
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021562361187840079) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4931942899748744114) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4129968667336683663) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3687216492462311868) ) ) {
                      result[0] += 0.0011370876244133593;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03127843326018551334) ) ) {
                        result[0] += -9.348753771398432e-05;
                      } else {
                        result[0] += -0.0027373208079678776;
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02159955403810970287) ) ) {
                      result[0] += 0.0001865476583493226;
                    } else {
                      result[0] += 0.002094511680481504;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
                    result[0] += -0.0006948379363720727;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05585367585607920599) ) ) {
                      result[0] += -0.00022605667340091145;
                    } else {
                      result[0] += 0.0014895527891243493;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7875164333668343009) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0183355000000000011) ) ) {
                    result[0] += 0.0018537449083761675;
                  } else {
                    result[0] += 0.002072699821471255;
                  }
                } else {
                  result[0] += -0.00013100899786459388;
                }
              }
            } else {
              result[0] += 0.0019133457511833541;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09956041386891252565) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01881166515770610337) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
                result[0] += 0.0030405991873534368;
              } else {
                result[0] += 0.000972293875847514;
              }
            } else {
              result[0] += 0.0021052181671192384;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5612777274623116375) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05311250000000000693) ) ) {
                result[0] += -0.0014156660630434545;
              } else {
                result[0] += -0.00010684608817839934;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1960530738562874242) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7269841738944724518) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1604180000000000328) ) ) {
                    result[0] += 0.0019365623085293427;
                  } else {
                    result[0] += -0.00010814698246068406;
                  }
                } else {
                  result[0] += -5.367041724916144e-05;
                }
              } else {
                result[0] += 0.002235804648728339;
              }
            }
          }
        }
      }
    }
  }
}

