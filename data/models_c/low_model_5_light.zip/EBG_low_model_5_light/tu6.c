
#include "header.h"

void predict_unit6(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -1.803810173396032e-06;
            } else {
              result[0] += -4.2852330448691414e-06;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -4.2852330448691414e-06;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -4.2852330448691414e-06;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -4.2852330448691414e-06;
                } else {
                  result[0] += -4.2852330448691414e-06;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6135097231155780539) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.09274867639439776656) ) ) {
                result[0] += -0.0002249529706983126;
              } else {
                result[0] += 1.2984179791110708e-05;
              }
            } else {
              result[0] += 0.004642017778543308;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01344341525633075199) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.640890220251256415) ) ) {
                result[0] += -4.281456013536511e-06;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6461954822149375) ) ) {
                  result[0] += 6.938805723072214e-06;
                } else {
                  result[0] += -4.2852330448691414e-06;
                }
              }
            } else {
              result[0] += 5.9018124206183854e-06;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -4.2852330448691414e-06;
                } else {
                  result[0] += -4.2852330448691414e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -4.2852330448691414e-06;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -4.2852330448691414e-06;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -4.2852330448691414e-06;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -4.2852330448691414e-06;
                      } else {
                        result[0] += -4.2852330448691414e-06;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -4.2852330448691414e-06;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -4.2852330448691414e-06;
                  } else {
                    result[0] += -4.2852330448691414e-06;
                  }
                }
              } else {
                result[0] += -4.2852330448691414e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -4.2852330448691414e-06;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -4.2852330448691414e-06;
                } else {
                  result[0] += -4.2852330448691414e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -4.2852330448691414e-06;
                } else {
                  result[0] += -4.2852330448691414e-06;
                }
              }
            }
          }
        } else {
          result[0] += -4.789462238565711e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7750000000000001332) ) ) {
            result[0] += 1.972979304932143e-05;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007100500000000000908) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.008408953333664601418) ) ) {
                result[0] += 0.000603363831981719;
              } else {
                result[0] += 0.004834113902735028;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02116634333934230491) ) ) {
                result[0] += -0.0009745438673968613;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)44.50000000000000711) ) ) {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4131576219849246168) ) ) {
                    result[0] += -0.00838551707609683;
                  } else {
                    result[0] += 0.000995095458406428;
                  }
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4992188184422110542) ) ) {
                    result[0] += 0.0047685727627666714;
                  } else {
                    result[0] += 0.0008066499923210489;
                  }
                }
              }
            }
          }
        } else {
          result[0] += 0.004234927992028963;
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.9546544174008676498) ) ) {
          result[0] += 0.004696997272200876;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1271566581126106488) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9993516786272610419) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02374450000000000519) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01667338205697885267) ) ) {
                  result[0] += 0.0004898910182133482;
                } else {
                  result[0] += 0.0037206451491953456;
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)109.5000000000000142) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01926987714285620379) ) ) {
                    result[0] += -0.0063517981714839135;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3872449054220527542) ) ) {
                      result[0] += 0.0005700509682921358;
                    } else {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)45.50000000000000711) ) ) {
                        result[0] += 0.00247070116221666;
                      } else {
                        result[0] += -0.010792332704494083;
                      }
                    }
                  }
                } else {
                  result[0] += 0.0027496245402822512;
                }
              }
            } else {
              result[0] += -0.004466853074527207;
            }
          } else {
            result[0] += 0.0036542385786490134;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -1.6072337226285406e-06;
            } else {
              result[0] += -3.818234956547041e-06;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.818234956547041e-06;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -3.818234956547041e-06;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -3.818234956547041e-06;
                } else {
                  result[0] += -3.818234956547041e-06;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6135097231155780539) ) ) {
            result[0] += 1.1569183902348106e-05;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01344341525633075199) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.640890220251256415) ) ) {
                result[0] += -3.814869540263908e-06;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6461954822149375) ) ) {
                  result[0] += 6.182625376756295e-06;
                } else {
                  result[0] += -3.818234956547041e-06;
                }
              }
            } else {
              result[0] += 5.2586420050994134e-06;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -3.818234956547041e-06;
                } else {
                  result[0] += -3.818234956547041e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -3.818234956547041e-06;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -3.818234956547041e-06;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -3.818234956547041e-06;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -3.818234956547041e-06;
                      } else {
                        result[0] += -3.818234956547041e-06;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -3.818234956547041e-06;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -3.818234956547041e-06;
                  } else {
                    result[0] += -3.818234956547041e-06;
                  }
                }
              } else {
                result[0] += -3.818234956547041e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -3.818234956547041e-06;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -3.818234956547041e-06;
                } else {
                  result[0] += -3.818234956547041e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -3.818234956547041e-06;
                } else {
                  result[0] += -3.818234956547041e-06;
                }
              }
            }
          }
        } else {
          result[0] += -4.267514030362865e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03603979634774020363) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005169500000000001351) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8450000000000000844) ) ) {
              result[0] += 3.177916186764753e-05;
            } else {
              result[0] += 0.005495871879596354;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4795364038944723295) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4543227793467337072) ) ) {
                result[0] += -6.637063365536177e-05;
              } else {
                result[0] += 0.0020414162927171937;
              }
            } else {
              result[0] += -0.00037182620154815806;
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)2.500000000000000444) ) ) {
            result[0] += -0.004907596444923648;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2397171522356433271) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5308132790452262384) ) ) {
                result[0] += 0.0012125890741578151;
              } else {
                result[0] += 0.0036391037450400642;
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5792515097236182742) ) ) {
                result[0] += -0.004914057287319338;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8050000000000001599) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06779550000000000853) ) ) {
                    result[0] += -0.0005358175375648862;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.247314011309283543) ) ) {
                      result[0] += 0.002413001417792914;
                    } else {
                      result[0] += -0.0007314656120205477;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6059238433417085679) ) ) {
                    result[0] += -0.002979484189201089;
                  } else {
                    result[0] += 0.003240738857491629;
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.9546544174008676498) ) ) {
          result[0] += 0.004185125753428226;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1271566581126106488) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)117.5000000000000142) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9351570282820221847) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02374450000000000519) ) ) {
                  result[0] += 0.003078377487383464;
                } else {
                  result[0] += -0.0003963289843394763;
                }
              } else {
                result[0] += -0.007001193629788743;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02803443610476625408) ) ) {
                result[0] += 0.0005203480204366843;
              } else {
                result[0] += 0.0033198742057132594;
              }
            }
          } else {
            result[0] += 0.003256005294103328;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -1.4320798702953221e-06;
            } else {
              result[0] += -3.4021295996617114e-06;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.4021295996617114e-06;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -3.4021295996617114e-06;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -3.4021295996617114e-06;
                } else {
                  result[0] += -3.4021295996617114e-06;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6135097231155780539) ) ) {
            result[0] += 1.0308392083263233e-05;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01344341525633075199) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.640890220251256415) ) ) {
                result[0] += -3.3991309412547944e-06;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6461954822149375) ) ) {
                  result[0] += 5.508852398361622e-06;
                } else {
                  result[0] += -3.4021295996617114e-06;
                }
              }
            } else {
              result[0] += 4.685563309532993e-06;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -3.4021295996617114e-06;
                } else {
                  result[0] += -3.4021295996617114e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -3.4021295996617114e-06;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -3.4021295996617114e-06;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -3.4021295996617114e-06;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -3.4021295996617114e-06;
                      } else {
                        result[0] += -3.4021295996617114e-06;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -3.4021295996617114e-06;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -3.4021295996617114e-06;
                  } else {
                    result[0] += -3.4021295996617114e-06;
                  }
                }
              } else {
                result[0] += -3.4021295996617114e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -3.4021295996617114e-06;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -3.4021295996617114e-06;
                } else {
                  result[0] += -3.4021295996617114e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -3.4021295996617114e-06;
                } else {
                  result[0] += -3.4021295996617114e-06;
                }
              }
            }
          }
        } else {
          result[0] += -3.8024469329144803e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02180250462562445188) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004064500000000001272) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4650000000000000244) ) ) {
              result[0] += -1.1181208523541206e-05;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.004769259728134950423) ) ) {
                result[0] += 0.0003475569664040429;
              } else {
                result[0] += 0.0015330333050122677;
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)86.50000000000001421) ) ) {
              result[0] += -0.0005658583133870543;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4737195465326633492) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3895344436180904757) ) ) {
                  result[0] += -0.0007907888632721933;
                } else {
                  result[0] += 0.001976982095237077;
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)643.5000000000001137) ) ) {
                  result[0] += -0.00032341954828322424;
                } else {
                  result[0] += 0.0005743218507990059;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.895681724436047322) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7550000000000001155) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02182250000000000509) ) ) {
                result[0] += -0.00012132669976545707;
              } else {
                result[0] += 0.0012212752156118766;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0159540000000000029) ) ) {
                result[0] += 0.003707330123686554;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
                  result[0] += 0.004092953722827166;
                } else {
                  result[0] += -0.0013671752621750792;
                }
              }
            }
          } else {
            result[0] += -0.0015975482136626224;
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.9546544174008676498) ) ) {
          result[0] += 0.0037290372033367217;
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06270917377236372159) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)11.50000000000000178) ) ) {
              result[0] += -0.005427701434392709;
            } else {
              result[0] += 0.0017143909555303479;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)34.50000000000000711) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03049200000000000174) ) ) {
                result[0] += 0.0032038854582743053;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3801755927260667134) ) ) {
                  result[0] += -0.0011883441517525056;
                } else {
                  result[0] += 0.004085960687821035;
                }
              }
            } else {
              result[0] += 0.0028723015329834467;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -1.2760140146580882e-06;
            } else {
              result[0] += -3.0313707628305708e-06;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.0313707628305708e-06;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -3.0313707628305708e-06;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -3.0313707628305708e-06;
                } else {
                  result[0] += -3.0313707628305708e-06;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6135097231155780539) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4754075198241206057) ) ) {
              result[0] += 0.0001598056993831109;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.09274867639439776656) ) ) {
                result[0] += -0.00022959441593072957;
              } else {
                result[0] += 9.184999412163837e-06;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01344341525633075199) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.640890220251256415) ) ) {
                result[0] += -3.028698893592154e-06;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6461954822149375) ) ) {
                  result[0] += 4.908506160024891e-06;
                } else {
                  result[0] += -3.0313707628305708e-06;
                }
              }
            } else {
              result[0] += 4.1749378463777825e-06;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -3.0313707628305708e-06;
                } else {
                  result[0] += -3.0313707628305708e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.06536400211476856) ) ) {
                    result[0] += -3.0313707628305708e-06;
                  } else {
                    result[0] += -3.0313707628305708e-06;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -3.0313707628305708e-06;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -3.0313707628305708e-06;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -3.0313707628305708e-06;
                      } else {
                        result[0] += -3.0313707628305708e-06;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -3.0313707628305708e-06;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -3.0313707628305708e-06;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02928050000000000444) ) ) {
                      result[0] += -3.0313707628305708e-06;
                    } else {
                      result[0] += -3.0313707628305708e-06;
                    }
                  }
                }
              } else {
                result[0] += -3.0313707628305708e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -3.0313707628305708e-06;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -3.0313707628305708e-06;
                } else {
                  result[0] += -3.0313707628305708e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -3.0313707628305708e-06;
                } else {
                  result[0] += -3.0313707628305708e-06;
                }
              }
            }
          }
        } else {
          result[0] += -3.388062130495521e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0465984882276438625) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.641728423423682037e-06) ) ) {
            result[0] += -0.00017429363491226464;
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)89.50000000000001421) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001475500000000000249) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3150000000000000577) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1550000000000000266) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1750000000000000167) ) ) {
                      result[0] += -2.8305721477656997e-05;
                    } else {
                      result[0] += 0.0012678440226460354;
                    }
                  } else {
                    result[0] += -0.002008945019892984;
                  }
                } else {
                  result[0] += 0.0018921541970783153;
                }
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)3.500000000000000444) ) ) {
                  result[0] += 0.0017492662488640392;
                } else {
                  result[0] += -0.0003193702247963247;
                }
              }
            } else {
              result[0] += 0.0002182521986919347;
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)2.500000000000000444) ) ) {
            result[0] += -0.004509406741054454;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.335710565658207782) ) ) {
              result[0] += 0.001657902688688096;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.25500000000000006) ) ) {
                result[0] += 0.0012445561164231606;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09998752698574815689) ) ) {
                  result[0] += -0.010960752712440512;
                } else {
                  result[0] += 0.000470543340043053;
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4516066347997827468) ) ) {
          result[0] += 0.003322652480030869;
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06270917377236372159) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4086612272110553001) ) ) {
              result[0] += -0.006330152927773161;
            } else {
              result[0] += 0.0010552476649148546;
            }
          } else {
            result[0] += 0.0023930517314237868;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -1.1369559752753731e-06;
            } else {
              result[0] += -2.7010166522338593e-06;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.7010166522338593e-06;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -2.7010166522338593e-06;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -2.7010166522338593e-06;
                } else {
                  result[0] += -2.7010166522338593e-06;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6135097231155780539) ) ) {
            result[0] += 1.992002089946788e-06;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01344341525633075199) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.640890220251256415) ) ) {
                result[0] += -2.6986359591843504e-06;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6461954822149375) ) ) {
                  result[0] += 4.373584728857096e-06;
                } else {
                  result[0] += -2.7010166522338593e-06;
                }
              }
            } else {
              result[0] += 3.7199595586843137e-06;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -2.7010166522338593e-06;
                } else {
                  result[0] += -2.7010166522338593e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -2.7010166522338593e-06;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -2.7010166522338593e-06;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -2.7010166522338593e-06;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -2.7010166522338593e-06;
                      } else {
                        result[0] += -2.7010166522338593e-06;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -2.7010166522338593e-06;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -2.7010166522338593e-06;
                  } else {
                    result[0] += -2.7010166522338593e-06;
                  }
                }
              } else {
                result[0] += -2.7010166522338593e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -2.7010166522338593e-06;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -2.7010166522338593e-06;
                } else {
                  result[0] += -2.7010166522338593e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -2.7010166522338593e-06;
                } else {
                  result[0] += -2.7010166522338593e-06;
                }
              }
            }
          }
        } else {
          result[0] += -3.0188363447585344e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08030541277720280868) ) ) {
          result[0] += 1.0949543528527065e-05;
        } else {
          result[0] += 0.002089030217115051;
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1725637113259415323) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
            result[0] += 0.0015828380564464517;
          } else {
            result[0] += 0.002960554937123383;
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5196530228391961215) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.09900846148772847466) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1271566581126106488) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)37.50000000000000711) ) ) {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4693565335929648641) ) ) {
                    result[0] += -0.0074783271563458;
                  } else {
                    result[0] += -0.002035166496222894;
                  }
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
                    result[0] += 0.002653823144854359;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05995868851020505486) ) ) {
                      result[0] += -0.0005735895894352725;
                    } else {
                      result[0] += -0.005722897718802445;
                    }
                  }
                }
              } else {
                result[0] += 0.0019725121311046758;
              }
            } else {
              result[0] += -0.009307052666350794;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9993516786272610419) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1466079245622486649) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01738250000000000559) ) ) {
                  result[0] += 0.003083328829124819;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1245513101099625097) ) ) {
                    result[0] += 0.002503664665412519;
                  } else {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6059238433417085679) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3872449054220527542) ) ) {
                        result[0] += -0.0023217412691581597;
                      } else {
                        result[0] += -0.006121608193008046;
                      }
                    } else {
                      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6533526130653267705) ) ) {
                        result[0] += 0.002273694161694307;
                      } else {
                        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6628367744974875686) ) ) {
                          result[0] += -0.00932630295562292;
                        } else {
                          result[0] += 0.0006074173786770784;
                        }
                      }
                    }
                  }
                }
              } else {
                result[0] += 0.0029704061588439507;
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)82.50000000000001421) ) ) {
                result[0] += -0.0031052802801632244;
              } else {
                result[0] += 0.0025805408692033227;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -1.0130522665621147e-06;
            } else {
              result[0] += -2.406664023120805e-06;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.406664023120805e-06;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -2.406664023120805e-06;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -2.406664023120805e-06;
                } else {
                  result[0] += -2.406664023120805e-06;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6135097231155780539) ) ) {
            result[0] += 1.7749167743528458e-06;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01344341525633075199) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.640890220251256415) ) ) {
                result[0] += -2.404542774328204e-06;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6461954822149375) ) ) {
                  result[0] += 3.896958210274468e-06;
                } else {
                  result[0] += -2.406664023120805e-06;
                }
              }
            } else {
              result[0] += 3.3145641030927576e-06;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -2.406664023120805e-06;
                } else {
                  result[0] += -2.406664023120805e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -2.406664023120805e-06;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -2.406664023120805e-06;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -2.406664023120805e-06;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -2.406664023120805e-06;
                      } else {
                        result[0] += -2.406664023120805e-06;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -2.406664023120805e-06;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -2.406664023120805e-06;
                  } else {
                    result[0] += -2.406664023120805e-06;
                  }
                }
              } else {
                result[0] += -2.406664023120805e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -2.406664023120805e-06;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -2.406664023120805e-06;
                } else {
                  result[0] += -2.406664023120805e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -2.406664023120805e-06;
                } else {
                  result[0] += -2.406664023120805e-06;
                }
              }
            }
          }
        } else {
          result[0] += -2.6898482157120864e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1387316860263769769) ) ) {
          result[0] += 1.4424798826992626e-05;
        } else {
          result[0] += 0.002683937780908623;
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)32.50000000000000711) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02374450000000000519) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04324794178047625809) ) ) {
              result[0] += -0.0002444785647732075;
            } else {
              result[0] += 0.002826796108616663;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                result[0] += -0.0016210003488042136;
              } else {
                result[0] += -0.002119703880778351;
              }
            } else {
              result[0] += 0.0030799349708104224;
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03358130704046471265) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06439350000000000629) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1536978514979052968) ) ) {
                result[0] += 0.002909810655577977;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005491500000000000721) ) ) {
                  result[0] += 0.004765803627458421;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)171.5000000000000284) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03340700000000001307) ) ) {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)94.50000000000001421) ) ) {
                        result[0] += -0.0002841746081602642;
                      } else {
                        result[0] += -0.009056220892733054;
                      }
                    } else {
                      result[0] += 0.004070163102112883;
                    }
                  } else {
                    result[0] += 0.0035013366102852345;
                  }
                }
              }
            } else {
              result[0] += -0.004393028535583355;
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4516066347997827468) ) ) {
              result[0] += 0.002637918225996423;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2394849609754011732) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
                  result[0] += 0.002749793915864499;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)121.5000000000000142) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9567162861906464144) ) ) {
                      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3932416254517326903) ) ) {
                        result[0] += -0.0049960289359404705;
                      } else {
                        result[0] += 0.0010073730519095264;
                      }
                    } else {
                      result[0] += -0.006437644865257281;
                    }
                  } else {
                    result[0] += 0.0020066749703849247;
                  }
                }
              } else {
                result[0] += 0.00304640919195101;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -9.026513929337223e-07;
            } else {
              result[0] += -2.1443894895626633e-06;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.1443894895626633e-06;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -2.1443894895626633e-06;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -2.1443894895626633e-06;
                } else {
                  result[0] += -2.1443894895626633e-06;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6135097231155780539) ) ) {
            result[0] += 1.5814890816522754e-06;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01344341525633075199) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.640890220251256415) ) ) {
                result[0] += -2.1424994111919803e-06;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6461954822149375) ) ) {
                  result[0] += 3.4722737146089573e-06;
                } else {
                  result[0] += -2.1443894895626633e-06;
                }
              }
            } else {
              result[0] += 2.953348019029627e-06;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -2.1443894895626633e-06;
                } else {
                  result[0] += -2.1443894895626633e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -2.1443894895626633e-06;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -2.1443894895626633e-06;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -2.1443894895626633e-06;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -2.1443894895626633e-06;
                      } else {
                        result[0] += -2.1443894895626633e-06;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -2.1443894895626633e-06;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -2.1443894895626633e-06;
                  } else {
                    result[0] += -2.1443894895626633e-06;
                  }
                }
              } else {
                result[0] += -2.1443894895626633e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -2.1443894895626633e-06;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -2.1443894895626633e-06;
                } else {
                  result[0] += -2.1443894895626633e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -2.1443894895626633e-06;
                } else {
                  result[0] += -2.1443894895626633e-06;
                }
              }
            }
          }
        } else {
          result[0] += -2.396712705586635e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.641728423423682037e-06) ) ) {
            result[0] += -0.0001580646400804566;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)43.50000000000000711) ) ) {
              result[0] += -7.557349624066242e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3111804673197418603) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09500000000000001499) ) ) {
                  result[0] += -0.0002576905662628669;
                } else {
                  result[0] += 0.001010347226694734;
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007850500000000001574) ) ) {
                  result[0] += 0.00015028012498973463;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)564.5000000000001137) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04407393373669900999) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4150000000000000355) ) ) {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03188050000000000606) ) ) {
                          result[0] += 0.00015394498945718504;
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2050000000000000433) ) ) {
                            result[0] += -0.000719734580776807;
                          } else {
                            result[0] += 0.002185386689507441;
                          }
                        }
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4650000000000000244) ) ) {
                          result[0] += -0.0054495401221260915;
                        } else {
                          result[0] += -0.0022999681705472026;
                        }
                      }
                    } else {
                      result[0] += 0.00045279385466220543;
                    }
                  } else {
                    result[0] += 0.0004852556206236463;
                  }
                }
              }
            }
          }
        } else {
          result[0] += 0.002597039681410539;
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4516066347997827468) ) ) {
          result[0] += 0.002350441966061068;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2712534726811091645) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9993516786272610419) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06439350000000000629) ) ) {
                result[0] += 0.0017254151873500752;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4838161673366834781) ) ) {
                    result[0] += -0.008795881188551822;
                  } else {
                    result[0] += -0.0012913564658298116;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03603979634774020363) ) ) {
                    result[0] += -0.003484389990605461;
                  } else {
                    result[0] += 0.0009534803044779825;
                  }
                }
              }
            } else {
              result[0] += -0.002581736661038871;
            }
          } else {
            result[0] += 0.0027144162165417987;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -8.0428183624737e-07;
            } else {
              result[0] += -1.910697230178355e-06;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.910697230178355e-06;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -1.910697230178355e-06;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -1.910697230178355e-06;
                } else {
                  result[0] += -1.910697230178355e-06;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6214144784636018715) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
              result[0] += -1.9090131296335327e-06;
            } else {
              result[0] += 0.006312987897133882;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)69.50000000000001421) ) ) {
              result[0] += -1.910697230178355e-06;
            } else {
              result[0] += -0.00023820522217446848;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -1.910697230178355e-06;
                } else {
                  result[0] += -1.910697230178355e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -1.910697230178355e-06;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -1.910697230178355e-06;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -1.910697230178355e-06;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -1.910697230178355e-06;
                      } else {
                        result[0] += -1.910697230178355e-06;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -1.910697230178355e-06;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -1.910697230178355e-06;
                  } else {
                    result[0] += -1.910697230178355e-06;
                  }
                }
              } else {
                result[0] += -1.910697230178355e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -1.910697230178355e-06;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -1.910697230178355e-06;
                } else {
                  result[0] += -1.910697230178355e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -1.910697230178355e-06;
                } else {
                  result[0] += -1.910697230178355e-06;
                }
              }
            }
          }
        } else {
          result[0] += -2.1355226512659317e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02180250462562445188) ) ) {
          result[0] += -1.4560780055460212e-05;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)31.50000000000000355) ) ) {
                result[0] += -0.0037923670494570375;
              } else {
                result[0] += 0.002428591298089437;
              }
            } else {
              result[0] += 0.001185064494290073;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8352912313316583903) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
                result[0] += 0.0008872820704727224;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1550000000000000266) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)99.50000000000001421) ) ) {
                    result[0] += -0.00026389813426205567;
                  } else {
                    result[0] += -0.0010956399322376096;
                  }
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)32.50000000000000711) ) ) {
                    result[0] += -0.0036073317991486835;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08936750000000000249) ) ) {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07576791765615910335) ) ) {
                        result[0] += -0.0005687309136155117;
                      } else {
                        result[0] += 0.0027370803975215064;
                      }
                    } else {
                      result[0] += -0.005539609275577644;
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)197.5000000000000284) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)141.5000000000000284) ) ) {
                  result[0] += 0.00023046545480689227;
                } else {
                  result[0] += -0.002350144179567666;
                }
              } else {
                result[0] += 0.0033456796306343766;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4516066347997827468) ) ) {
          result[0] += 0.0020942944255727385;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2712534726811091645) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9993516786272610419) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02812450000000000366) ) ) {
                result[0] += 0.001578581210882692;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5272802516080402624) ) ) {
                    if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05740595745564833902) ) ) {
                      result[0] += -0.0004527307320546604;
                    } else {
                      result[0] += -0.016013379304113354;
                    }
                  } else {
                    result[0] += 0.000812222704457674;
                  }
                } else {
                  result[0] += 0.0009201825244388917;
                }
              }
            } else {
              result[0] += -0.002300382981406481;
            }
          } else {
            result[0] += 0.002418603323575967;
          }
        }
      }
    }
  }
}

