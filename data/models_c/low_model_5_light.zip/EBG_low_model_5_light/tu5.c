
#include "header.h"

void predict_unit5(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                  result[0] += -1.5441937905263426e-05;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                    result[0] += -1.5441937905263426e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      result[0] += -1.5441937905263426e-05;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        result[0] += -1.5441937905263426e-05;
                      } else {
                        result[0] += -1.5441937905263426e-05;
                      }
                    }
                  }
                }
              } else {
                result[0] += -1.6825046953662233e-05;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5687531224874372571) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4781247323869347032) ) ) {
                  result[0] += 3.7615493141398964e-05;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.51994285276381913) ) ) {
                    result[0] += -0.00014360964097066026;
                  } else {
                    result[0] += 2.0519364539817455e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6402694681155779444) ) ) {
                    result[0] += -1.6397801532316443e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7114754460552764614) ) ) {
                      result[0] += -3.409613565057297e-06;
                    } else {
                      result[0] += -1.5441937905263426e-05;
                    }
                  }
                } else {
                  result[0] += -1.706013096271359e-07;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -1.5441937905263426e-05;
                  } else {
                    result[0] += -1.5441937905263426e-05;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                    result[0] += -1.5441937905263426e-05;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      result[0] += -1.5441937905263426e-05;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                        result[0] += -1.5441937905263426e-05;
                      } else {
                        result[0] += -1.5441937905263426e-05;
                      }
                    }
                  }
                }
              } else {
                result[0] += -1.5441937905263426e-05;
              }
            } else {
              result[0] += -1.5441937905263426e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001504690974371400121) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5920309527638191183) ) ) {
              result[0] += 9.030384147962846e-07;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.883880929790755059e-06) ) ) {
                  result[0] += -1.5441937905263426e-05;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7093978733165829942) ) ) {
                    result[0] += -1.5441937905263426e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
                      result[0] += 0.00010054320481222258;
                    } else {
                      result[0] += -1.5992680621176283e-05;
                    }
                  }
                }
              } else {
                result[0] += -2.8535277001161125e-06;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01359050000000000188) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                result[0] += -1.2213169924905321e-05;
              } else {
                result[0] += 0.00030655082234864117;
              }
            } else {
              result[0] += 0.00014454129156501701;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                result[0] += -1.5441937905263426e-05;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.858234205283420677e-05) ) ) {
                    result[0] += -1.5441937905263426e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                      result[0] += -1.5441937905263426e-05;
                    } else {
                      result[0] += -1.5441937905263426e-05;
                    }
                  }
                } else {
                  result[0] += -1.5441937905263426e-05;
                }
              }
            } else {
              result[0] += -1.5441937905263426e-05;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
              result[0] += -1.5441937905263426e-05;
            } else {
              result[0] += -1.5441937905263426e-05;
            }
          }
        } else {
          result[0] += -1.5441937905263426e-05;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7750000000000001332) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5050000000000001155) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.05751864358971629093) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3450000000000000289) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09500000000000001499) ) ) {
                  result[0] += 5.143959507314757e-05;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.576152860085799078e-06) ) ) {
                    result[0] += -0.0002897156259535386;
                  } else {
                    result[0] += -1.7604161330930788e-06;
                  }
                }
              } else {
                result[0] += 0.0021730822093592025;
              }
            } else {
              result[0] += -0.000416662187227603;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4850000000000000422) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.115000000000000005) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.008624500000000001956) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002579500000000000629) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001174500000000000197) ) ) {
                      result[0] += 0.0002889368906000099;
                    } else {
                      result[0] += -0.00025746346857544704;
                    }
                  } else {
                    result[0] += 0.0005440027497568233;
                  }
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01622350000000000528) ) ) {
                    result[0] += -0.0005317684745645442;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5041457217085428821) ) ) {
                      result[0] += 0.0010004125209991776;
                    } else {
                      result[0] += -0.0001940504834845175;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06473550000000001525) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002965500000000000688) ) ) {
                    result[0] += 0.0008268314198765896;
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005473500000000000067) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00421750000000000163) ) ) {
                        result[0] += 0.0008166656402892225;
                      } else {
                        result[0] += -0.00017201513678321493;
                      }
                    } else {
                      result[0] += 0.0006312696357571504;
                    }
                  }
                } else {
                  result[0] += 0.0023247919436489733;
                }
              }
            } else {
              result[0] += -0.0008486570321798949;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03729562354052295275) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -4.390244674118165e-05;
              } else {
                result[0] += -3.54228240559447e-06;
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5850000000000000755) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3250000000000000666) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                    result[0] += 0.00010973729471916984;
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02500000000000000486) ) ) {
                      result[0] += -0.00010737312694343816;
                    } else {
                      result[0] += 3.81946980762831e-05;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2650000000000000688) ) ) {
                    result[0] += -0.0002547779314154799;
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03468100000000001043) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003024500000000000712) ) ) {
                        result[0] += 0.0010343848988603403;
                      } else {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006708500000000000921) ) ) {
                          result[0] += -0.00037447319004406686;
                        } else {
                          result[0] += 0.0006785100699367604;
                        }
                      }
                    } else {
                      result[0] += 0.0034544697015088206;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001004500000000000184) ) ) {
                  result[0] += 0.0008206509121604072;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001574500000000000162) ) ) {
                    result[0] += -0.0009447432031121326;
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05185700000000000726) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02722700000000000467) ) ) {
                        result[0] += -6.869115960190854e-05;
                      } else {
                        result[0] += 0.0006386865580789749;
                      }
                    } else {
                      result[0] += -0.0005882897753702448;
                    }
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.723113719091885043) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2564454682769619631) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.04446937286580055632) ) ) {
                  result[0] += 0.001670152377566963;
                } else {
                  result[0] += 0.0014457006980731178;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4450000000000000622) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.29500000000000004) ) ) {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01590200000000000294) ) ) {
                      result[0] += -4.2120574192263855e-05;
                    } else {
                      result[0] += 0.0005464131428417823;
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05574000000000000482) ) ) {
                      result[0] += 0.00011302348060820271;
                    } else {
                      result[0] += -0.0005328116967224171;
                    }
                  }
                } else {
                  result[0] += 0.0018288414283730355;
                }
              }
            } else {
              result[0] += -0.0003711631461383958;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004460500000000000922) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5550000000000001599) ) ) {
            result[0] += -0.0005305386593672784;
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7572008430306190752) ) ) {
              result[0] += 0.0002859987284677875;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0119121105025029022) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  result[0] += 0.00038931511080685934;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01021941412521685209) ) ) {
                    result[0] += 0.001115225349519399;
                  } else {
                    result[0] += 0.0003968528241003669;
                  }
                }
              } else {
                result[0] += 0.0016227161353530182;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06217080128912850362) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4129968667336683663) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5724391781153673753) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8350000000000000755) ) ) {
                  result[0] += 0.0018567458262006475;
                } else {
                  result[0] += -0.0015642393052195996;
                }
              } else {
                result[0] += -0.0008665942354160524;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5361772370603016258) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02192319026750580435) ) ) {
                  result[0] += 0.001086300755384574;
                } else {
                  result[0] += 0.0023498853053859235;
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05311250000000000693) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.020650504707780553) ) ) {
                    result[0] += -0.0003453532033996629;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02063185379234615258) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008332142139858200389) ) ) {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005479696504671500816) ) ) {
                          result[0] += 6.870515732085343e-05;
                        } else {
                          result[0] += 0.0009494565268606041;
                        }
                      } else {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01148539754569130079) ) ) {
                          result[0] += -0.0011352116485628017;
                        } else {
                          result[0] += 0.00015282620130037877;
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03028287126648195396) ) ) {
                        result[0] += 0.003188245478451059;
                      } else {
                        result[0] += 0.000992616766814313;
                      }
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0956005000000000188) ) ) {
                    result[0] += -0.0016197353709423324;
                  } else {
                    result[0] += 0.0008635838006315175;
                  }
                }
              }
            }
          } else {
            result[0] += 0.0019506532951889023;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03469629566125685682) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006186000000000001393) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
            result[0] += 0.001871137827322875;
          } else {
            result[0] += 0.004560852860670761;
          }
        } else {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
            result[0] += 0.007998260094265023;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8850000000000001199) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05574000000000000482) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4000638056452025526) ) ) {
                  result[0] += -0.00038005476242217087;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09341808925382111273) ) ) {
                    result[0] += 0.0027815993676822475;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.564374608675820677) ) ) {
                      result[0] += -0.00048470905261913;
                    } else {
                      result[0] += 0.0013273421283819266;
                    }
                  }
                }
              } else {
                result[0] += -0.0007336687344173512;
              }
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1828583041203602211) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7983975536720421262) ) ) {
                  result[0] += 0.0014146689099595363;
                } else {
                  result[0] += 0.0042321913008663194;
                }
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1068151278937841814) ) ) {
                  result[0] += -0.0006286524922873765;
                } else {
                  result[0] += 0.0022018207221893194;
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01622350000000000528) ) ) {
            result[0] += 0.005645395988720587;
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6782348568386622478) ) ) {
              result[0] += -0.0009358070996882034;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.051391296366422923) ) ) {
                result[0] += 0.003899342652756857;
              } else {
                result[0] += -0.00023138303263470239;
              }
            }
          }
        } else {
          result[0] += 0.006273442329266627;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                  result[0] += -1.48272770484401e-05;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                    result[0] += -1.48272770484401e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      result[0] += -1.48272770484401e-05;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        result[0] += -1.48272770484401e-05;
                      } else {
                        result[0] += -1.48272770484401e-05;
                      }
                    }
                  }
                }
              } else {
                result[0] += -1.6155331932135966e-05;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5687531224874372571) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4781247323869347032) ) ) {
                  result[0] += 3.61182217894501e-05;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5271332674874372737) ) ) {
                    result[0] += -0.00010604268136849629;
                  } else {
                    result[0] += 2.6229561805723e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6402694681155779444) ) ) {
                    result[0] += -1.5745092863125575e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7114754460552764614) ) ) {
                      result[0] += -3.2738951074263886e-06;
                    } else {
                      result[0] += -1.48272770484401e-05;
                    }
                  }
                } else {
                  result[0] += -1.6381058505653179e-07;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -1.48272770484401e-05;
                  } else {
                    result[0] += -1.48272770484401e-05;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                    result[0] += -1.48272770484401e-05;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      result[0] += -1.48272770484401e-05;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                        result[0] += -1.48272770484401e-05;
                      } else {
                        result[0] += -1.48272770484401e-05;
                      }
                    }
                  }
                }
              } else {
                result[0] += -1.48272770484401e-05;
              }
            } else {
              result[0] += -1.48272770484401e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001504690974371400121) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5920309527638191183) ) ) {
              result[0] += 8.670932912510404e-07;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.883880929790755059e-06) ) ) {
                  result[0] += -1.48272770484401e-05;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7093978733165829942) ) ) {
                    result[0] += -1.48272770484401e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
                      result[0] += 9.654111823495565e-05;
                    } else {
                      result[0] += -1.5356097646045716e-05;
                    }
                  }
                }
              } else {
                result[0] += -2.739944042942809e-06;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01359050000000000188) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                result[0] += -1.1727029031409568e-05;
              } else {
                result[0] += 0.00029434867568280804;
              }
            } else {
              result[0] += 0.0001387878767627582;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                result[0] += -1.48272770484401e-05;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.858234205283420677e-05) ) ) {
                    result[0] += -1.48272770484401e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                      result[0] += -1.48272770484401e-05;
                    } else {
                      result[0] += -1.48272770484401e-05;
                    }
                  }
                } else {
                  result[0] += -1.48272770484401e-05;
                }
              }
            } else {
              result[0] += -1.48272770484401e-05;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
              result[0] += -1.48272770484401e-05;
            } else {
              result[0] += -1.48272770484401e-05;
            }
          }
        } else {
          result[0] += -1.48272770484401e-05;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7750000000000001332) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5050000000000001155) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.05751864358971629093) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3450000000000000289) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09500000000000001499) ) ) {
                  result[0] += 4.93920602510104e-05;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.576152860085799078e-06) ) ) {
                    result[0] += -0.00027818359830414564;
                  } else {
                    result[0] += -1.6903433938184485e-06;
                  }
                }
              } else {
                result[0] += 0.002086583443404641;
              }
            } else {
              result[0] += -0.00040007709676950033;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4850000000000000422) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.115000000000000005) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5179236987437186857) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5041457217085428821) ) ) {
                    result[0] += 0.0001244614513520454;
                  } else {
                    result[0] += -0.00036853637853560025;
                  }
                } else {
                  result[0] += 0.0004602801476442565;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4643511832914573034) ) ) {
                  result[0] += 0.0008315087848956992;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4693879269597989734) ) ) {
                    result[0] += -0.00023578058076541378;
                  } else {
                    result[0] += 0.0006828546659845545;
                  }
                }
              }
            } else {
              result[0] += -0.0008148765402656618;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03729562354052295275) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -4.215492543290222e-05;
              } else {
                result[0] += -3.4012831118600626e-06;
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7050000000000000711) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3966559369710560001) ) ) {
                    result[0] += -3.529424173601901e-05;
                  } else {
                    result[0] += 0.000320735199376101;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09500000000000001499) ) ) {
                    result[0] += -3.760018582426423e-06;
                  } else {
                    result[0] += 0.00014638546268890668;
                  }
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5508018452917812224) ) ) {
                  result[0] += 0.0002698825879508367;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8577098326317653676) ) ) {
                    result[0] += -0.0005704480817878241;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.121680358022378199) ) ) {
                      result[0] += 0.0003079027304420438;
                    } else {
                      result[0] += -0.0005413544500626793;
                    }
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.723113719091885043) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2564454682769619631) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.04446937286580055632) ) ) {
                  result[0] += 0.001603672555039577;
                } else {
                  result[0] += 0.0013881550949733398;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4450000000000000622) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.29500000000000004) ) ) {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01590200000000000294) ) ) {
                      result[0] += -4.044397968827414e-05;
                    } else {
                      result[0] += 0.0005246633616537502;
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05574000000000000482) ) ) {
                      result[0] += 0.00010852462108305739;
                    } else {
                      result[0] += -0.0005116033162689983;
                    }
                  }
                } else {
                  result[0] += 0.0017560450445088958;
                }
              }
            } else {
              result[0] += -0.0003563891288598453;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004460500000000000922) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5550000000000001599) ) ) {
            result[0] += -0.0005094207563589113;
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7572008430306190752) ) ) {
              result[0] += 0.0002746146506034102;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0119121105025029022) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.003774417747733249413) ) ) {
                  result[0] += 0.0011866993631866865;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6413622072216433878) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5380790363330137938) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09221529126392057074) ) ) {
                        result[0] += -4.553624063383268e-05;
                      } else {
                        result[0] += 0.0009423011502776232;
                      }
                    } else {
                      result[0] += -0.00018342642577532858;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8440161800932387548) ) ) {
                      result[0] += 0.0025076809736510673;
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.051391296366422923) ) ) {
                        result[0] += 7.055774061596379e-05;
                      } else {
                        result[0] += 0.001668109661958005;
                      }
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.068802141605957212) ) ) {
                  result[0] += 0.0016915490099376003;
                } else {
                  result[0] += 0.0002818678936940834;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06217080128912850362) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4129968667336683663) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.317357466959798995) ) ) {
                result[0] += 0.0013707692452740528;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02032228342586875347) ) ) {
                  result[0] += -0.0002473641533033109;
                } else {
                  result[0] += -0.002014864180689837;
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5361772370603016258) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02192319026750580435) ) ) {
                  result[0] += 0.0010430609394256637;
                } else {
                  result[0] += 0.0022563489549546254;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8054659791206031372) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9808239647505231362) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7250000000000000888) ) ) {
                      result[0] += 0.0023708351193701344;
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.52031910737473408) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3466557816143853721) ) ) {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5455059598241206453) ) ) {
                            result[0] += -0.0013656126238397238;
                          } else {
                            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5951110425376885393) ) ) {
                              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5531655541959800138) ) ) {
                                result[0] += 0.002396521424854755;
                              } else {
                                result[0] += -0.00015046964202299477;
                              }
                            } else {
                              result[0] += 0.0013095500287234282;
                            }
                          }
                        } else {
                          result[0] += -0.0007189224320292558;
                        }
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6915080527790725684) ) ) {
                          result[0] += 0.001975195144987211;
                        } else {
                          result[0] += 0.0004424455778100399;
                        }
                      }
                    }
                  } else {
                    result[0] += -0.0014621476774718397;
                  }
                } else {
                  result[0] += 0.0012345035243170625;
                }
              }
            }
          } else {
            result[0] += 0.001873008233206273;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03469629566125685682) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006186000000000001393) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
            result[0] += 0.0017966578503126852;
          } else {
            result[0] += 0.004379309731538667;
          }
        } else {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
            result[0] += 0.007679892190391955;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8850000000000001199) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05574000000000000482) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4000638056452025526) ) ) {
                  result[0] += -0.0003649268175137413;
                } else {
                  result[0] += 0.0012634939713399964;
                }
              } else {
                result[0] += -0.0007044653108776305;
              }
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1828583041203602211) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7983975536720421262) ) ) {
                  result[0] += 0.0013583585161701219;
                } else {
                  result[0] += 0.0040637304284557385;
                }
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1068151278937841814) ) ) {
                  result[0] += -0.000603629202987542;
                } else {
                  result[0] += 0.002114178029932996;
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01622350000000000528) ) ) {
            result[0] += 0.005420683005361728;
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6782348568386622478) ) ) {
              result[0] += -0.000898557630272862;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.051391296366422923) ) ) {
                result[0] += 0.0037441307026314574;
              } else {
                result[0] += -0.0002221729131557768;
              }
            }
          }
        } else {
          result[0] += 0.0060237301842628295;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                  result[0] += -1.4237082548833633e-05;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                    result[0] += -1.4237082548833633e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      result[0] += -1.4237082548833633e-05;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        result[0] += -1.4237082548833633e-05;
                      } else {
                        result[0] += -1.4237082548833633e-05;
                      }
                    }
                  }
                }
              } else {
                result[0] += -1.5512274679309734e-05;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5687531224874372571) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.07196201389915944657) ) ) {
                  result[0] += -7.46833985686471e-05;
                } else {
                  result[0] += 3.7958667131173165e-05;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6402694681155779444) ) ) {
                    result[0] += -1.5118365030816854e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7114754460552764614) ) ) {
                      result[0] += -3.143578874824869e-06;
                    } else {
                      result[0] += -1.4237082548833633e-05;
                    }
                  }
                } else {
                  result[0] += -1.5729016286694964e-07;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -1.4237082548833633e-05;
                  } else {
                    result[0] += -1.4237082548833633e-05;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                    result[0] += -1.4237082548833633e-05;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      result[0] += -1.4237082548833633e-05;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                        result[0] += -1.4237082548833633e-05;
                      } else {
                        result[0] += -1.4237082548833633e-05;
                      }
                    }
                  }
                }
              } else {
                result[0] += -1.4237082548833633e-05;
              }
            } else {
              result[0] += -1.4237082548833633e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001504690974371400121) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5920309527638191183) ) ) {
              result[0] += 8.325789505888722e-07;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.883880929790755059e-06) ) ) {
                  result[0] += -1.4237082548833633e-05;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7093978733165829942) ) ) {
                    result[0] += -1.4237082548833633e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
                      result[0] += 9.269833329325774e-05;
                    } else {
                      result[0] += -1.4744853630269438e-05;
                    }
                  }
                }
              } else {
                result[0] += -2.6308815429240094e-06;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01359050000000000188) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                result[0] += -1.1260238803611743e-05;
              } else {
                result[0] += 0.00028263223113355636;
              }
            } else {
              result[0] += 0.00013326347459438723;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                result[0] += -1.4237082548833633e-05;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.858234205283420677e-05) ) ) {
                    result[0] += -1.4237082548833633e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                      result[0] += -1.4237082548833633e-05;
                    } else {
                      result[0] += -1.4237082548833633e-05;
                    }
                  }
                } else {
                  result[0] += -1.4237082548833633e-05;
                }
              }
            } else {
              result[0] += -1.4237082548833633e-05;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
              result[0] += -1.4237082548833633e-05;
            } else {
              result[0] += -1.4237082548833633e-05;
            }
          }
        } else {
          result[0] += -1.4237082548833633e-05;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8050000000000001599) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5050000000000001155) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4643511832914573034) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)5.354107497039817852e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4052145559547739029) ) ) {
                result[0] += -0.0001878371891391478;
              } else {
                result[0] += 0.0005205139347021453;
              }
            } else {
              result[0] += -0.0004295298181288689;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.07196200000000001207) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4419864859045226635) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4389499174623116007) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004848500000000001246) ) ) {
                    result[0] += 0.0007473202121239739;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3569067370100503234) ) ) {
                      result[0] += -0.001107387784206689;
                    } else {
                      result[0] += 0.00090852593081587;
                    }
                  }
                } else {
                  result[0] += -0.0002886528215017286;
                }
              } else {
                result[0] += 0.0013031477602075028;
              }
            } else {
              result[0] += 0.0032275404639911464;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02577363736079425413) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
                  result[0] += -1.7981271787292958e-05;
                } else {
                  result[0] += -6.716825762900278e-05;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9112103514676580529) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6732382808793971884) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3346339054385528144) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.590591194899497629) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5408295445477387942) ) ) {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5072068278894473758) ) ) {
                            result[0] += 0.00021941216983454483;
                          } else {
                            result[0] += -8.607883197050625e-05;
                          }
                        } else {
                          result[0] += 0.00027133404731573263;
                        }
                      } else {
                        result[0] += -6.438366316844858e-05;
                      }
                    } else {
                      result[0] += 0.0002579418485962546;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7492319095182128352) ) ) {
                      result[0] += -7.294067801785534e-05;
                    } else {
                      result[0] += -3.43055644500293e-06;
                    }
                  }
                } else {
                  result[0] += 4.8258978363156214e-05;
                }
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6050000000000000933) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2750000000000000777) ) ) {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.244955337349149066) ) ) {
                    if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2795185878002977575) ) ) {
                      result[0] += 0.00032235814201539;
                    } else {
                      result[0] += -0.0005078541710577385;
                    }
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3850000000000000644) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9808239647505231362) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5681735652491761712) ) ) {
                            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.07274795227358500649) ) ) {
                              result[0] += 9.985270997626951e-05;
                            } else {
                              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1129321246270776624) ) ) {
                                result[0] += -0.00019254879998260649;
                              } else {
                                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1405997886577425304) ) ) {
                                  result[0] += 0.0005447349256228085;
                                } else {
                                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2888738239382729889) ) ) {
                                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2533229942273665936) ) ) {
                                      result[0] += -1.7719448386860204e-05;
                                    } else {
                                      result[0] += -0.0007204258312805538;
                                    }
                                  } else {
                                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                                      result[0] += 9.855955306163913e-05;
                                    } else {
                                      result[0] += -9.276712183877113e-05;
                                    }
                                  }
                                }
                              }
                            }
                          } else {
                            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6156410786045318773) ) ) {
                              result[0] += 0.0007408203143387148;
                            } else {
                              result[0] += 5.0487099761806996e-05;
                            }
                          }
                        } else {
                          result[0] += -0.00011512208273196975;
                        }
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.051391296366422923) ) ) {
                          result[0] += 0.0006602748754096902;
                        } else {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                            result[0] += 0.00030102999228189957;
                          } else {
                            result[0] += 1.601724442158067e-05;
                          }
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05721739154190200877) ) ) {
                        result[0] += -0.00033044249206075463;
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3763200711443456803) ) ) {
                          result[0] += 0.00034392461160117114;
                        } else {
                          result[0] += -0.000182927345196229;
                        }
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8099155601256282644) ) ) {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.545000000000000151) ) ) {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5150000000000001243) ) ) {
                        result[0] += 0.0006914278226059286;
                      } else {
                        result[0] += -0.00017151034837203073;
                      }
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
                        result[0] += 0.0018396427247448896;
                      } else {
                        result[0] += 0.00041965162606743016;
                      }
                    }
                  } else {
                    result[0] += -0.00016556444710690216;
                  }
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8764371766733816127) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7642320229909970175) ) ) {
                      result[0] += -4.358992338177707e-05;
                    } else {
                      result[0] += -0.000561891517764779;
                    }
                  } else {
                    result[0] += 0.0007746738718661098;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.224356303145077041) ) ) {
                    result[0] += -0.0011126380108405951;
                  } else {
                    result[0] += 0.00040421684063111663;
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.891911223721401525) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02251500000000000376) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.03588532983514210878) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01195250000000000305) ) ) {
                    result[0] += 0.0018326113803896803;
                  } else {
                    result[0] += 0.0005564061980993914;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6161319161557790025) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5800027599246232457) ) ) {
                      result[0] += 0.0005601654663351356;
                    } else {
                      result[0] += -0.0005215121372336151;
                    }
                  } else {
                    result[0] += 0.00010226111306746774;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5309997332914574431) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05574000000000000482) ) ) {
                    result[0] += -0.0007058498284335426;
                  } else {
                    result[0] += 0.0021190885976844656;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2623980000000000756) ) ) {
                    result[0] += 0.0008101649902523152;
                  } else {
                    result[0] += -0.0001002670325749922;
                  }
                }
              }
            } else {
              result[0] += -0.0004325329001591813;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004460500000000000922) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5550000000000001599) ) ) {
            result[0] += -0.0004888440277771863;
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7572008430306190752) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.8537219630417757221) ) ) {
                result[0] += 0.0016574905141804278;
              } else {
                result[0] += -0.00041935815592135476;
              }
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.003774417747733249413) ) ) {
                result[0] += 0.0014344255991334913;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003549689586176700464) ) ) {
                  result[0] += 0.0005025143385907067;
                } else {
                  result[0] += 0.0012088722909993205;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0119121105025029022) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1206324332205917643) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4093335132160804135) ) ) {
                result[0] += -0.0006670545589673915;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6050000000000000933) ) ) {
                  result[0] += 0.0015568813424855915;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6850000000000001643) ) ) {
                    result[0] += -0.0008488333376207567;
                  } else {
                    result[0] += 0.0013731646057572548;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.670427493643216188) ) ) {
                result[0] += -0.001024488919708694;
              } else {
                result[0] += 0.0005223635113211266;
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08404042173159891049) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1469960000000000155) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05185700000000000726) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7150000000000000799) ) ) {
                    result[0] += 0.0020605065068662882;
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005046500000000001505) ) ) {
                      result[0] += -0.00011041872451943434;
                    } else {
                      result[0] += 0.0009195097344403697;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.564198853668341882) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4751828078391960308) ) ) {
                      result[0] += -0.00025882412271323264;
                    } else {
                      result[0] += 0.0026139748420286983;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6468042868844222637) ) ) {
                      result[0] += -0.001960560322263311;
                    } else {
                      result[0] += 8.088600831988529e-05;
                    }
                  }
                }
              } else {
                result[0] += 0.0029804410268837547;
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9550000000000000711) ) ) {
                result[0] += 0.003346514331104284;
              } else {
                result[0] += 0.0007474721249434212;
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03469629566125685682) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007543500000000000726) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005814890055470450791) ) ) {
              result[0] += -0.0014633996319354085;
            } else {
              result[0] += 0.004581906158996042;
            }
          } else {
            result[0] += 0.004828238586483868;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01969319515722280436) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06008500000000000646) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2669585275879397535) ) ) {
                result[0] += 0.0074541472118541865;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3931761618090452437) ) ) {
                  result[0] += -0.0003906485471110554;
                } else {
                  result[0] += 0.0017449638878884448;
                }
              }
            } else {
              result[0] += -0.0016480192231223484;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9450000000000000622) ) ) {
              result[0] += 0.0012669120103513546;
            } else {
              result[0] += 0.004249779721728162;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01657900000000000346) ) ) {
            result[0] += 0.005281648039405525;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1211830000000000129) ) ) {
              result[0] += 0.0026161699538354206;
            } else {
              result[0] += 0.0044559343519243256;
            }
          }
        } else {
          result[0] += 0.005783957742549441;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                  result[0] += -1.3670380531779946e-05;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                    result[0] += -1.3670380531779946e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      result[0] += -1.3670380531779946e-05;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        result[0] += -1.3670380531779946e-05;
                      } else {
                        result[0] += -1.3670380531779946e-05;
                      }
                    }
                  }
                }
              } else {
                result[0] += -1.4894814092163258e-05;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5687531224874372571) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4781247323869347032) ) ) {
                  result[0] += 3.7653294961488e-05;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.51994285276381913) ) ) {
                    result[0] += -0.0001306995727308669;
                  } else {
                    result[0] += 1.7147608850520717e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6402694681155779444) ) ) {
                    result[0] += -1.451658387740072e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7114754460552764614) ) ) {
                      result[0] += -3.018449833603101e-06;
                    } else {
                      result[0] += -1.3670380531779946e-05;
                    }
                  }
                } else {
                  result[0] += -1.5102928376805733e-07;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -1.3670380531779946e-05;
                  } else {
                    result[0] += -1.3670380531779946e-05;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                    result[0] += -1.3670380531779946e-05;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      result[0] += -1.3670380531779946e-05;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                        result[0] += -1.3670380531779946e-05;
                      } else {
                        result[0] += -1.3670380531779946e-05;
                      }
                    }
                  }
                }
              } else {
                result[0] += -1.3670380531779946e-05;
              }
            } else {
              result[0] += -1.3670380531779946e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001504690974371400121) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5920309527638191183) ) ) {
              result[0] += 7.994384410050909e-07;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.883880929790755059e-06) ) ) {
                  result[0] += -1.3670380531779946e-05;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7093978733165829942) ) ) {
                    result[0] += -1.3670380531779946e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
                      result[0] += 8.90085090420731e-05;
                    } else {
                      result[0] += -1.4157939965565034e-05;
                    }
                  }
                }
              } else {
                result[0] += -2.5261602370040447e-06;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01359050000000000188) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                result[0] += -1.0812028995132724e-05;
              } else {
                result[0] += 0.0002713821555005475;
              }
            } else {
              result[0] += 0.0001279589692933058;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                result[0] += -1.3670380531779946e-05;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.858234205283420677e-05) ) ) {
                    result[0] += -1.3670380531779946e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                      result[0] += -1.3670380531779946e-05;
                    } else {
                      result[0] += -1.3670380531779946e-05;
                    }
                  }
                } else {
                  result[0] += -1.3670380531779946e-05;
                }
              }
            } else {
              result[0] += -1.3670380531779946e-05;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
              result[0] += -1.3670380531779946e-05;
            } else {
              result[0] += -1.3670380531779946e-05;
            }
          }
        } else {
          result[0] += -1.3670380531779946e-05;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8850000000000001199) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5050000000000001155) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4643511832914573034) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)5.354107497039817852e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
              result[0] += 0.00016120162629810035;
            } else {
              result[0] += -0.0004124325361904228;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.07196200000000001207) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0004315000000000000801) ) ) {
                result[0] += 0.000594547086036736;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3644118032412060892) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3278371989949749321) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2929122217587940002) ) ) {
                      result[0] += -0.0005737789451757899;
                    } else {
                      result[0] += 0.0015218251550752188;
                    }
                  } else {
                    result[0] += -0.0003400960939314738;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4082869870603015872) ) ) {
                    result[0] += 0.0013161732447182722;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4419864859045226635) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4389499174623116007) ) ) {
                        result[0] += 0.0005745132477202262;
                      } else {
                        result[0] += -0.00034973984128460617;
                      }
                    } else {
                      result[0] += 0.0012503250297150224;
                    }
                  }
                }
              }
            } else {
              result[0] += 0.0030990693615168536;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02577363736079425413) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5499504253266332965) ) ) {
                  result[0] += 0.00010383997325286947;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
                      result[0] += -3.443634120941446e-05;
                    } else {
                      result[0] += -9.704808192415119e-05;
                    }
                  } else {
                    result[0] += 1.0544694621608631e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001939744889791500219) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07500000000000002498) ) ) {
                    result[0] += 1.5432279168920468e-06;
                  } else {
                    result[0] += -5.45560563352677e-05;
                  }
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01254618095428180168) ) ) {
                    result[0] += 0.0004228925956499058;
                  } else {
                    result[0] += -1.561430864445385e-05;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6050000000000000933) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3650000000000000466) ) ) {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.244955337349149066) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4737195465326633492) ) ) {
                      result[0] += 0.0006825762627667779;
                    } else {
                      result[0] += -0.0003314108578111317;
                    }
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6299505656030152112) ) ) {
                        result[0] += 4.150925435872606e-05;
                      } else {
                        result[0] += 0.00029598605663300247;
                      }
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8327395279648243109) ) ) {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.373325504271297691e-06) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
                            result[0] += -0.00010057580886888803;
                          } else {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08500000000000000611) ) ) {
                              result[0] += 0.000295579607331333;
                            } else {
                              result[0] += -0.00010138369656745587;
                            }
                          }
                        } else {
                          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                            result[0] += 0.00014528251941072385;
                          } else {
                            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002490043859502850346) ) ) {
                              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001939744889791500219) ) ) {
                                result[0] += -4.842584964629459e-06;
                              } else {
                                result[0] += -0.000691676742004709;
                              }
                            } else {
                              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02446805795595660346) ) ) {
                                result[0] += 0.00012494408088809965;
                              } else {
                                result[0] += -0.00011739100188788357;
                              }
                            }
                          }
                        }
                      } else {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8841271910804021639) ) ) {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.009038634387355000757) ) ) {
                            result[0] += -0.00022957596996072636;
                          } else {
                            result[0] += 5.028924785979285e-05;
                          }
                        } else {
                          result[0] += 0.00035249481608839485;
                        }
                      }
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3650000000000000466) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.729199597233659459e-06) ) ) {
                      result[0] += 0.0011185025269300308;
                    } else {
                      result[0] += -0.0003431081630841728;
                    }
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008883026007095952761) ) ) {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002998483312272000063) ) ) {
                        result[0] += 0.0015291853813475481;
                      } else {
                        result[0] += -4.5365800307034365e-05;
                      }
                    } else {
                      result[0] += 0.0016851541873133694;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004867285882244350333) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003549689586176700464) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3466557816143853721) ) ) {
                        result[0] += -0.0004850044031407756;
                      } else {
                        result[0] += 4.436408145174496e-05;
                      }
                    } else {
                      result[0] += -0.00015929410283429583;
                    }
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007787546829340650199) ) ) {
                      result[0] += 0.0010744519904028259;
                    } else {
                      result[0] += -4.779920704503368e-06;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.224356303145077041) ) ) {
                    result[0] += -0.001068349849777314;
                  } else {
                    result[0] += 0.0003881271327765048;
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.891911223721401525) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05720850000000000934) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4908111093216080412) ) ) {
                  result[0] += -0.0005410756473618127;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3115605993075549196) ) ) {
                    result[0] += 0.0007752736241159662;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6116569490452262725) ) ) {
                      result[0] += -0.0010211530062073754;
                    } else {
                      result[0] += 9.940785295517832e-05;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2623980000000000756) ) ) {
                  result[0] += 0.0007857064928975951;
                } else {
                  result[0] += -0.00010890120453762065;
                }
              }
            } else {
              result[0] += -0.00041531608160653695;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004552500000000000123) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5550000000000001599) ) ) {
            result[0] += -0.0004681881913225783;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0119121105025029022) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.052300094327177008e-06) ) ) {
                result[0] += -0.0003173491345340746;
              } else {
                result[0] += 0.0009915780703222993;
              }
            } else {
              result[0] += 0.0015885194624258123;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0270604707267506038) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005013289129500051074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002867412157011550635) ) ) {
                  result[0] += 0.0010387314089550619;
                } else {
                  result[0] += -0.0009494463150135818;
                }
              } else {
                result[0] += 0.00038195570941396774;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08720350000000000323) ) ) {
                result[0] += -0.0027453801653203294;
              } else {
                result[0] += 0.000709772922735336;
              }
            }
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6782348568386622478) ) ) {
              result[0] += -0.00123117137419749;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9150000000000001465) ) ) {
                  result[0] += 0.00230545939994661;
                } else {
                  result[0] += 0.002058701409530009;
                }
              } else {
                result[0] += -0.0006539416797554462;
              }
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0526089167981486569) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007384500000000001306) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9250000000000001554) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008506177121675452882) ) ) {
              result[0] += 0.00398412002498631;
            } else {
              result[0] += 0.004860732989081599;
            }
          } else {
            result[0] += 0.005938995100897678;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01444878842564100048) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0044229535828532009) ) ) {
              result[0] += -0.0010002728980945438;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3278371989949749321) ) ) {
                result[0] += 0.007074769800398594;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5920309527638191183) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01170971943545395279) ) ) {
                    result[0] += 0.0018596428861003995;
                  } else {
                    result[0] += -0.0015760383481165769;
                  }
                } else {
                  result[0] += 0.0031327098870161415;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
              result[0] += 0.0020033057382933734;
            } else {
              result[0] += 0.004695289172135587;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
          result[0] += 0.0046318584353306335;
        } else {
          result[0] += 0.005951775428412683;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                  result[0] += -1.3126235887350264e-05;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                    result[0] += -1.3126235887350264e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      result[0] += -1.3126235887350264e-05;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        result[0] += -1.3126235887350264e-05;
                      } else {
                        result[0] += -1.3126235887350264e-05;
                      }
                    }
                  }
                }
              } else {
                result[0] += -1.4301931304505327e-05;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5687531224874372571) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4781247323869347032) ) ) {
                  result[0] += 3.615451892150917e-05;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.51994285276381913) ) ) {
                    result[0] += -0.00012549712263334287;
                  } else {
                    result[0] += 1.646505436719128e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6402694681155779444) ) ) {
                    result[0] += -1.3938756409179293e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7114754460552764614) ) ) {
                      result[0] += -2.8983015094495413e-06;
                    } else {
                      result[0] += -1.3126235887350264e-05;
                    }
                  }
                } else {
                  result[0] += -1.4501761673921385e-07;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -1.3126235887350264e-05;
                  } else {
                    result[0] += -1.3126235887350264e-05;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                    result[0] += -1.3126235887350264e-05;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      result[0] += -1.3126235887350264e-05;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                        result[0] += -1.3126235887350264e-05;
                      } else {
                        result[0] += -1.3126235887350264e-05;
                      }
                    }
                  }
                }
              } else {
                result[0] += -1.3126235887350264e-05;
              }
            } else {
              result[0] += -1.3126235887350264e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001504690974371400121) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5920309527638191183) ) ) {
              result[0] += 7.676170776412265e-07;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.883880929790755059e-06) ) ) {
                  result[0] += -1.3126235887350264e-05;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7093978733165829942) ) ) {
                    result[0] += -1.3126235887350264e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
                      result[0] += 8.546555693541296e-05;
                    } else {
                      result[0] += -1.359438819094475e-05;
                    }
                  }
                }
              } else {
                result[0] += -2.4256073254928308e-06;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01359050000000000188) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                result[0] += -1.0381660018977073e-05;
              } else {
                result[0] += 0.00026057988513461934;
              }
            } else {
              result[0] += 0.0001228656079427693;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                result[0] += -1.3126235887350264e-05;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.858234205283420677e-05) ) ) {
                    result[0] += -1.3126235887350264e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                      result[0] += -1.3126235887350264e-05;
                    } else {
                      result[0] += -1.3126235887350264e-05;
                    }
                  }
                } else {
                  result[0] += -1.3126235887350264e-05;
                }
              }
            } else {
              result[0] += -1.3126235887350264e-05;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
              result[0] += -1.3126235887350264e-05;
            } else {
              result[0] += -1.3126235887350264e-05;
            }
          }
        } else {
          result[0] += -1.3126235887350264e-05;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8850000000000001199) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5050000000000001155) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4643511832914573034) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)5.354107497039817852e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
              result[0] += 0.0001547850527857868;
            } else {
              result[0] += -0.0003960158054904356;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.07196200000000001207) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0004315000000000000801) ) ) {
                result[0] += 0.000570881350326156;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3644118032412060892) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3278371989949749321) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2929122217587940002) ) ) {
                      result[0] += -0.0005509398779400171;
                    } else {
                      result[0] += 0.001461249444986721;
                    }
                  } else {
                    result[0] += -0.0003265586896380049;
                  }
                } else {
                  result[0] += 0.0005704973212525257;
                }
              }
            } else {
              result[0] += 0.002975712005672573;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02577363736079425413) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.03500000000000001027) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6059258460552764403) ) ) {
                  result[0] += 3.881275927468207e-05;
                } else {
                  result[0] += -3.502766326133435e-05;
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03500000000000001027) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7211604863065327331) ) ) {
                    result[0] += 3.697931635218738e-06;
                  } else {
                    result[0] += 0.00036475142218748437;
                  }
                } else {
                  result[0] += -9.719471870578067e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6050000000000000933) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5550000000000001599) ) ) {
                    result[0] += 4.703675155126801e-05;
                  } else {
                    result[0] += 0.000795650759931159;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8841271910804021639) ) ) {
                    result[0] += -0.00014219643559795967;
                  } else {
                    result[0] += 0.0002571997024750991;
                  }
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8764371766733816127) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7642320229909970175) ) ) {
                      result[0] += -3.9874453112598885e-05;
                    } else {
                      result[0] += -0.0005407046680334203;
                    }
                  } else {
                    result[0] += 0.0007418804631780686;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.224356303145077041) ) ) {
                    result[0] += -0.0010258245632439854;
                  } else {
                    result[0] += 0.000372677870031608;
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.891911223721401525) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0650000000000000161) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01332150000000000174) ) ) {
                  result[0] += -4.6013869538465816e-05;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
                    result[0] += -3.3224409715636464e-05;
                  } else {
                    result[0] += 0.0005924166550506333;
                  }
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7990273242713569202) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7269841738944724518) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.531569796683417195) ) ) {
                      result[0] += 0.0003366094337445805;
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.020650504707780553) ) ) {
                        result[0] += 0.0019193017795134401;
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6503673217403566076) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3115605993075549196) ) ) {
                            result[0] += 0.000990213899992709;
                          } else {
                            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4287309711685468594) ) ) {
                              result[0] += -0.00035613284334227996;
                            } else {
                              result[0] += 0.0005259439083367385;
                            }
                          }
                        } else {
                          result[0] += 0.0013083582762464132;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7425707671105529206) ) ) {
                      result[0] += -0.00033946894791550385;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7640286906783920751) ) ) {
                        result[0] += 0.0003675889538847204;
                      } else {
                        result[0] += -5.880161101003526e-05;
                      }
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003882500000000000534) ) ) {
                    result[0] += 0.00014060790901869916;
                  } else {
                    result[0] += 0.0019175510654654533;
                  }
                }
              }
            } else {
              result[0] += -0.0003987845724048474;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004552500000000000123) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5550000000000001599) ) ) {
            result[0] += -0.0004495521265618967;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0119121105025029022) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.052300094327177008e-06) ) ) {
                result[0] += -0.00030471716488482696;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.171316810410465458e-05) ) ) {
                  result[0] += 0.003157144135192231;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00135663295830650032) ) ) {
                    result[0] += 0.0004122047618648199;
                  } else {
                    result[0] += 0.0009831029924045659;
                  }
                }
              }
            } else {
              result[0] += 0.0015252890091080101;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0270604707267506038) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005013289129500051074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002867412157011550635) ) ) {
                  result[0] += 0.000997385073944869;
                } else {
                  result[0] += -0.0009116539414737887;
                }
              } else {
                result[0] += 0.0003667520979853168;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0956005000000000188) ) ) {
                result[0] += -0.0024466136972196733;
              } else {
                result[0] += 0.0009643636006716806;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4183012963065327328) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9550000000000000711) ) ) {
                result[0] += 8.181822277410683e-05;
              } else {
                result[0] += -0.0015140459474459775;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9150000000000001465) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5834559473869348478) ) ) {
                    result[0] += 0.00248221879232178;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4364163272837385255) ) ) {
                      result[0] += 0.00038875716858094;
                    } else {
                      result[0] += 0.002526934457461831;
                    }
                  }
                } else {
                  result[0] += 0.0019951493245221564;
                }
              } else {
                result[0] += -0.0006279117633254643;
              }
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0526089167981486569) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007384500000000001306) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9250000000000001554) ) ) {
            result[0] += 0.0044485805195059866;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003549689586176700464) ) ) {
              result[0] += 0.004926600865625912;
            } else {
              result[0] += 0.005825188532321293;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01444878842564100048) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0044229535828532009) ) ) {
              result[0] += -0.0009604573904573584;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3278371989949749321) ) ) {
                result[0] += 0.006793161099857286;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5920309527638191183) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008157865216470052208) ) ) {
                    result[0] += 0.0028417090633424324;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5072068278894473758) ) ) {
                      result[0] += 0.00022300329551633042;
                    } else {
                      result[0] += -0.0032399047801409697;
                    }
                  }
                } else {
                  result[0] += 0.003008013481995891;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
              result[0] += 0.0019235648645032541;
            } else {
              result[0] += 0.0045083948533471115;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
          result[0] += 0.004447488954504378;
        } else {
          result[0] += 0.005714867120213801;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                  result[0] += -1.2603750727334579e-05;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                    result[0] += -1.2603750727334579e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      result[0] += -1.2603750727334579e-05;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        result[0] += -1.2603750727334579e-05;
                      } else {
                        result[0] += -1.2603750727334579e-05;
                      }
                    }
                  }
                }
              } else {
                result[0] += -1.373264800575179e-05;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5687531224874372571) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.07196201389915944657) ) ) {
                  result[0] += -7.228500726663347e-05;
                } else {
                  result[0] += 3.515044993061084e-05;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6402694681155779444) ) ) {
                    result[0] += -1.3383929158216349e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7114754460552764614) ) ) {
                      result[0] += -2.78293564668932e-06;
                    } else {
                      result[0] += -1.2603750727334579e-05;
                    }
                  }
                } else {
                  result[0] += -1.392452419824613e-07;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -1.2603750727334579e-05;
                  } else {
                    result[0] += -1.2603750727334579e-05;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                    result[0] += -1.2603750727334579e-05;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      result[0] += -1.2603750727334579e-05;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                        result[0] += -1.2603750727334579e-05;
                      } else {
                        result[0] += -1.2603750727334579e-05;
                      }
                    }
                  }
                }
              } else {
                result[0] += -1.2603750727334579e-05;
              }
            } else {
              result[0] += -1.2603750727334579e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001504690974371400121) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5920309527638191183) ) ) {
              result[0] += 7.370623523502813e-07;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.883880929790755059e-06) ) ) {
                  result[0] += -1.2603750727334579e-05;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                    result[0] += -1.2603750727334579e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
                      result[0] += 8.206363077970048e-05;
                    } else {
                      result[0] += -1.3053268394666662e-05;
                    }
                  }
                }
              } else {
                result[0] += -2.32905688693059e-06;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01359050000000000188) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                result[0] += -9.968421727147263e-06;
              } else {
                result[0] += 0.0002502075953060754;
              }
            } else {
              result[0] += 0.00011797498603277701;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                result[0] += -1.2603750727334579e-05;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.858234205283420677e-05) ) ) {
                    result[0] += -1.2603750727334579e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                      result[0] += -1.2603750727334579e-05;
                    } else {
                      result[0] += -1.2603750727334579e-05;
                    }
                  }
                } else {
                  result[0] += -1.2603750727334579e-05;
                }
              }
            } else {
              result[0] += -1.2603750727334579e-05;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
              result[0] += -1.2603750727334579e-05;
            } else {
              result[0] += -1.2603750727334579e-05;
            }
          }
        } else {
          result[0] += -1.2603750727334579e-05;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8850000000000001199) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5050000000000001155) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09500000000000001499) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4295075599497487628) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.05500000000000000722) ) ) {
              result[0] += 4.524729601967331e-05;
            } else {
              result[0] += 0.0010641792642917612;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9310018456912946272) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8377933889099087317) ) ) {
                result[0] += -8.511137950762193e-06;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8466324982590252013) ) ) {
                  result[0] += -0.00029888207959521355;
                } else {
                  result[0] += -3.9961842971769203e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
                result[0] += 0.00017402135243846812;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7954292854522614364) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.097216905567068856) ) ) {
                    result[0] += -1.1194665006372998e-06;
                  } else {
                    result[0] += -0.00021012376562569692;
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -0.0001000675802916586;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.249304608119721216) ) ) {
                      result[0] += 0.00015568347591958965;
                    } else {
                      result[0] += 1.3567638861330392e-05;
                    }
                  }
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0119121105025029022) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8327395279648243109) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.625000000000000111) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.310012234630710122e-06) ) ) {
                  result[0] += -0.00012777672697043921;
                } else {
                  result[0] += 0.00021038702463514508;
                }
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3539353041941689093) ) ) {
                  result[0] += 0.0009189220249364086;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7550000000000001155) ) ) {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7050000000000000711) ) ) {
                      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6550000000000001377) ) ) {
                        result[0] += -0.0007485904978472088;
                      } else {
                        result[0] += 0.0003624493890777489;
                      }
                    } else {
                      result[0] += -0.0011567910312918362;
                    }
                  } else {
                    result[0] += 2.9995119732898736e-05;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.540399458636966701) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8393503195226131863) ) ) {
                  result[0] += -0.00010332902701981508;
                } else {
                  result[0] += -0.0006676215289945921;
                }
              } else {
                result[0] += 0.0003646874726186528;
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1050000000000000239) ) ) {
              result[0] += 0.0015812840362527622;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01278116174711865262) ) ) {
                result[0] += 0.0011592642965650975;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5800027599246232457) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5623076833668342323) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03705350000000001004) ) ) {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003226000000000000135) ) ) {
                        result[0] += 0.001026334497228484;
                      } else {
                        result[0] += 1.5557760717167327e-06;
                      }
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.0141436144428988015) ) ) {
                        result[0] += 0.0017519640560949986;
                      } else {
                        result[0] += 0.00013748527778378763;
                      }
                    }
                  } else {
                    result[0] += 0.0014436618654150217;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5859181088693469208) ) ) {
                    result[0] += -0.0004980530663412655;
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02483316262871755262) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7425707671105529206) ) ) {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
                          result[0] += 0.000866235707097402;
                        } else {
                          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02722700000000000467) ) ) {
                            result[0] += -0.0006409638417916413;
                          } else {
                            result[0] += 0.00018714587330572924;
                          }
                        }
                      } else {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01676384620505355291) ) ) {
                          result[0] += 0.0002236298468251238;
                        } else {
                          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0435660000000000075) ) ) {
                            result[0] += -0.0003697387052103393;
                          } else {
                            result[0] += -7.617230043657613e-05;
                          }
                        }
                      }
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7990273242713569202) ) ) {
                        result[0] += 0.00015231306610248316;
                      } else {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8480072969597991506) ) ) {
                          result[0] += 0.0014954448371925745;
                        } else {
                          result[0] += 8.545877037813045e-05;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004552500000000000123) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5050000000000001155) ) ) {
            result[0] += -0.0004401482254282427;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0119121105025029022) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.052300094327177008e-06) ) ) {
                result[0] += -7.716858758362752e-06;
              } else {
                result[0] += 0.0009124965279849171;
              }
            } else {
              result[0] += 0.001471696816476724;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0270604707267506038) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005479696504671500816) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0044229535828532009) ) ) {
                result[0] += -1.6807191014123616e-05;
              } else {
                result[0] += -0.0008057524855352233;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.317357466959798995) ) ) {
                result[0] += 0.0023968848235544605;
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4323286620486300191) ) ) {
                  result[0] += -0.0012832479994221771;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.488887876708542779) ) ) {
                    result[0] += 0.0015423522724068645;
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008332142139858200389) ) ) {
                      result[0] += 0.0006819142619128216;
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03705350000000001004) ) ) {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005707500000000000767) ) ) {
                          result[0] += -0.0005259294154978748;
                        } else {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6635233717587941671) ) ) {
                            result[0] += 0.00011522233360539835;
                          } else {
                            result[0] += 0.002309872553512118;
                          }
                        }
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5386386389447237466) ) ) {
                          result[0] += 0.002468983602022574;
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6716133195226131614) ) ) {
                            result[0] += -0.001546826107947532;
                          } else {
                            result[0] += -0.0004582072770483885;
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4183012963065327328) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9550000000000000711) ) ) {
                result[0] += 7.856147745997489e-05;
              } else {
                result[0] += -0.0014537798859557403;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06508917425002432033) ) ) {
                  result[0] += 0.001613531238466844;
                } else {
                  result[0] += 0.002709649441288411;
                }
              } else {
                result[0] += -0.0006029179584790203;
              }
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0526089167981486569) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007384500000000001306) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9250000000000001554) ) ) {
            result[0] += 0.004271506351060126;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003549689586176700464) ) ) {
              result[0] += 0.0047304992669878285;
            } else {
              result[0] += 0.0055933189705861955;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01444878842564100048) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02300100000000000408) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5748180127889448432) ) ) {
                  result[0] += -0.00021447876204471985;
                } else {
                  result[0] += 0.0027126635392673653;
                }
              } else {
                result[0] += -0.0010405137941237141;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01287800000000000229) ) ) {
                result[0] += 0.0036981586405113783;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05052800000000001041) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03705350000000001004) ) ) {
                    result[0] += 0.0019477582171734628;
                  } else {
                    result[0] += -0.0006545844766473303;
                  }
                } else {
                  result[0] += 0.0021182157481312736;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008506177121675452882) ) ) {
              result[0] += -0.00010491862622271213;
            } else {
              result[0] += 0.00445322721796231;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
          result[0] += 0.0042704582354159285;
        } else {
          result[0] += 0.0054873888631263405;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                  result[0] += -1.2102062903644359e-05;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                    result[0] += -1.2102062903644359e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      result[0] += -1.2102062903644359e-05;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        result[0] += -1.2102062903644359e-05;
                      } else {
                        result[0] += -1.2102062903644359e-05;
                      }
                    }
                  }
                }
              } else {
                result[0] += -1.318602482662403e-05;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5687531224874372571) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4781247323869347032) ) ) {
                  result[0] += 3.7592680184681286e-05;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5271332674874372737) ) ) {
                    result[0] += -8.577384633920492e-05;
                  } else {
                    result[0] += 2.0937480828369856e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6402694681155779444) ) ) {
                    result[0] += -1.2851186609028403e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7114754460552764614) ) ) {
                      result[0] += -2.6721618811443007e-06;
                    } else {
                      result[0] += -1.2102062903644359e-05;
                    }
                  }
                } else {
                  result[0] += -1.337026345538649e-07;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -1.2102062903644359e-05;
                  } else {
                    result[0] += -1.2102062903644359e-05;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                    result[0] += -1.2102062903644359e-05;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      result[0] += -1.2102062903644359e-05;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                        result[0] += -1.2102062903644359e-05;
                      } else {
                        result[0] += -1.2102062903644359e-05;
                      }
                    }
                  }
                }
              } else {
                result[0] += -1.2102062903644359e-05;
              }
            } else {
              result[0] += -1.2102062903644359e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001504690974371400121) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5920309527638191183) ) ) {
              result[0] += 7.077238470534155e-07;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.883880929790755059e-06) ) ) {
                  result[0] += -1.2102062903644359e-05;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7093978733165829942) ) ) {
                    result[0] += -1.2102062903644359e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
                      result[0] += 7.879711708701871e-05;
                    } else {
                      result[0] += -1.2533687679795642e-05;
                    }
                  }
                }
              } else {
                result[0] += -2.2363496043023772e-06;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01359050000000000188) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006124087708088651362) ) ) {
                result[0] += 0.00017789786424288423;
              } else {
                result[0] += -4.4259519923707234e-05;
              }
            } else {
              result[0] += 0.00011327903359186542;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                result[0] += -1.2102062903644359e-05;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.858234205283420677e-05) ) ) {
                    result[0] += -1.2102062903644359e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                      result[0] += -1.2102062903644359e-05;
                    } else {
                      result[0] += -1.2102062903644359e-05;
                    }
                  }
                } else {
                  result[0] += -1.2102062903644359e-05;
                }
              }
            } else {
              result[0] += -1.2102062903644359e-05;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
              result[0] += -1.2102062903644359e-05;
            } else {
              result[0] += -1.2102062903644359e-05;
            }
          }
        } else {
          result[0] += -1.2102062903644359e-05;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8250000000000000666) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5050000000000001155) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09500000000000001499) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4295075599497487628) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.05500000000000000722) ) ) {
              result[0] += 4.344624346325091e-05;
            } else {
              result[0] += 0.0010218199864332328;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.03500000000000001027) ) ) {
              result[0] += -7.988103613519281e-06;
            } else {
              result[0] += -2.2186538438027615e-06;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5792515097236182742) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03968700000000000699) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.72638075848137134e-06) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2650000000000000688) ) ) {
                  result[0] += -0.00019527044191556975;
                } else {
                  result[0] += 0.0005574183284554244;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.564198853668341882) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5612777274623116375) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5493276582412061071) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4643511832914573034) ) ) {
                        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1050000000000000239) ) ) {
                          result[0] += 0.0018207573666393065;
                        } else {
                          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4150000000000000355) ) ) {
                            result[0] += 9.888903001159e-05;
                          } else {
                            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5750000000000000666) ) ) {
                              result[0] += 0.0011618260787387479;
                            } else {
                              result[0] += 0.0003446109775560067;
                            }
                          }
                        }
                      } else {
                        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3850000000000000644) ) ) {
                          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2350000000000000144) ) ) {
                            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1750000000000000167) ) ) {
                              result[0] += 0.0004950937195032808;
                            } else {
                              result[0] += -0.000496445927323536;
                            }
                          } else {
                            result[0] += 0.0007053872384995014;
                          }
                        } else {
                          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7650000000000001243) ) ) {
                            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6450000000000001288) ) ) {
                              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.545000000000000151) ) ) {
                                result[0] += -0.00025869600780224484;
                              } else {
                                result[0] += 0.0008261788101022145;
                              }
                            } else {
                              result[0] += -0.0009014323091004722;
                            }
                          } else {
                            result[0] += 0.0007808266119918461;
                          }
                        }
                      }
                    } else {
                      result[0] += 0.001073241869538739;
                    }
                  } else {
                    result[0] += -0.0009137996673550565;
                  }
                } else {
                  result[0] += 0.0010573330004565373;
                }
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1950000000000000344) ) ) {
                result[0] += 0.0016906129727714803;
              } else {
                result[0] += 0.0012199569943417252;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5834559473869348478) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4250000000000000444) ) ) {
                result[0] += -4.7706357672966555e-05;
              } else {
                result[0] += -0.0011110185052361212;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02483316262871755262) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7382388927638191545) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01439850000000000158) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5018975334485012985) ) ) {
                        result[0] += 0.0002686258188911715;
                      } else {
                        result[0] += -0.00011710493377657643;
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7190147863316583843) ) ) {
                        result[0] += 0.0009383758156350659;
                      } else {
                        result[0] += 0.0001566226710666481;
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3251271839107726103) ) ) {
                      result[0] += -0.0005281441976804427;
                    } else {
                      result[0] += 2.8479889718042125e-06;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01542071772829775068) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01210357511382575101) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9567162861906464144) ) ) {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004718492901569751492) ) ) {
                          result[0] += -0.000360870259327551;
                        } else {
                          result[0] += 0.0013377188894244353;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
                          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.121680358022378199) ) ) {
                            result[0] += 0.0003634712557679202;
                          } else {
                            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.052300094327177008e-06) ) ) {
                              result[0] += 0.0009434335869468107;
                            } else {
                              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.249304608119721216) ) ) {
                                result[0] += -0.0008644359020562922;
                              } else {
                                result[0] += 3.123675409121457e-05;
                              }
                            }
                          }
                        } else {
                          result[0] += -0.0002411593450837513;
                        }
                      }
                    } else {
                      result[0] += 0.0007209948630266566;
                    }
                  } else {
                    result[0] += -0.00027670467731549504;
                  }
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7990273242713569202) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.051391296366422923) ) ) {
                    result[0] += 0.0003318242992565028;
                  } else {
                    result[0] += -0.00065066505467998;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8480072969597991506) ) ) {
                    result[0] += 0.0015015652747592644;
                  } else {
                    result[0] += 0.00010292667020312823;
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002154500000000000599) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5550000000000001599) ) ) {
            result[0] += -0.0004168324829905361;
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7572008430306190752) ) ) {
              result[0] += -6.567017219290993e-06;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.384724495646039899e-06) ) ) {
                result[0] += 0.0006006438887862575;
              } else {
                result[0] += 0.0011095879570709975;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01148539754569130079) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1206324332205917643) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4129968667336683663) ) ) {
                result[0] += -0.00033370121975113634;
              } else {
                result[0] += 0.0007155070625936381;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6716133195226131614) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6208328749497488142) ) ) {
                  result[0] += -0.0002167188689147075;
                } else {
                  result[0] += -0.0010892897293340751;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7269841738944724518) ) ) {
                  result[0] += 0.0010505727518649735;
                } else {
                  result[0] += 5.1537407774161874e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.321871344966293327) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004460500000000000922) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002519500000000000472) ) ) {
                  result[0] += 0.0014702075032969506;
                } else {
                  result[0] += 0.0014756612347144211;
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08404042173159891049) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005046500000000001505) ) ) {
                    result[0] += -0.0003036488973314469;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
                      result[0] += -1.6626410706785804e-05;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.488887876708542779) ) ) {
                        result[0] += 0.002810491912845378;
                      } else {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.168924500000000033) ) ) {
                          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05311250000000000693) ) ) {
                            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
                              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.008306500000000001382) ) ) {
                                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006839500000000000961) ) ) {
                                  result[0] += 0.0012227471728013394;
                                } else {
                                  result[0] += 0.0025814797426614235;
                                }
                              } else {
                                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01287800000000000229) ) ) {
                                  result[0] += -0.00037093467930458763;
                                } else {
                                  result[0] += 0.0012283706495072582;
                                }
                              }
                            } else {
                              result[0] += 0.0023355607172091397;
                            }
                          } else {
                            result[0] += -0.00018478880412745518;
                          }
                        } else {
                          result[0] += 0.0026213922323067114;
                        }
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6665289424874373259) ) ) {
                    result[0] += 0.003069630297245022;
                  } else {
                    result[0] += 0.0009261471146698424;
                  }
                }
              }
            } else {
              result[0] += -0.000423790136798695;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00583050000000000148) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006937836693866150477) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5719332634924624292) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00135663295830650032) ) ) {
                result[0] += -0.0012839942600159247;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4389499174623116007) ) ) {
                  result[0] += 0.004076882408534855;
                } else {
                  result[0] += -0.00010596154570379014;
                }
              }
            } else {
              result[0] += 0.004002916314696296;
            }
          } else {
            result[0] += 0.005327249846235907;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04953562823777350743) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01657900000000000346) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5455059598241206453) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02751676046985590193) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0064655058205014505) ) ) {
                    result[0] += -0.0005743561457816185;
                  } else {
                    result[0] += 0.0007975497994011899;
                  }
                } else {
                  result[0] += 0.00417424553039706;
                }
              } else {
                result[0] += 0.0030606967185948315;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01444878842564100048) ) ) {
                result[0] += -0.0005409724286132738;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03940025850376690369) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.505061141934673441) ) ) {
                    result[0] += 0.0031402479406692635;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03350035677887956004) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02366047096071570086) ) ) {
                        result[0] += 0.0013633018098388719;
                      } else {
                        result[0] += -0.0005568096526602905;
                      }
                    } else {
                      result[0] += 0.004251126298994527;
                    }
                  }
                } else {
                  result[0] += -0.00046892406934617855;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3931761618090452437) ) ) {
              result[0] += -8.211477895858154e-06;
            } else {
              result[0] += 0.0037553043506585587;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01881166515770610337) ) ) {
          result[0] += 0.003164231604115304;
        } else {
          result[0] += 0.004870919226665889;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                  result[0] += -1.1620344585689695e-05;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                    result[0] += -1.1620344585689695e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      result[0] += -1.1620344585689695e-05;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        result[0] += -1.1620344585689695e-05;
                      } else {
                        result[0] += -1.1620344585689695e-05;
                      }
                    }
                  }
                }
              } else {
                result[0] += -1.2661159789104106e-05;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5687531224874372571) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4781247323869347032) ) ) {
                  result[0] += 3.609631689437656e-05;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.51994285276381913) ) ) {
                    result[0] += -0.00011421027765431063;
                  } else {
                    result[0] += 1.3577108548710618e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6402694681155779444) ) ) {
                    result[0] += -1.2339649687900814e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7114754460552764614) ) ) {
                      result[0] += -2.565797426014941e-06;
                    } else {
                      result[0] += -1.1620344585689695e-05;
                    }
                  }
                } else {
                  result[0] += -1.283806486464782e-07;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -1.1620344585689695e-05;
                  } else {
                    result[0] += -1.1620344585689695e-05;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                    result[0] += -1.1620344585689695e-05;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      result[0] += -1.1620344585689695e-05;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                        result[0] += -1.1620344585689695e-05;
                      } else {
                        result[0] += -1.1620344585689695e-05;
                      }
                    }
                  }
                }
              } else {
                result[0] += -1.1620344585689695e-05;
              }
            } else {
              result[0] += -1.1620344585689695e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001504690974371400121) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5920309527638191183) ) ) {
              result[0] += 6.79553150545475e-07;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.883880929790755059e-06) ) ) {
                  result[0] += -1.1620344585689695e-05;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7093978733165829942) ) ) {
                    result[0] += -1.1620344585689695e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
                      result[0] += 7.566062581234478e-05;
                    } else {
                      result[0] += -1.2034788690842107e-05;
                    }
                  }
                }
              } else {
                result[0] += -2.147332502150396e-06;
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01595548253114795548) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0110643527143887508) ) ) {
                result[0] += 6.589180792498197e-05;
              } else {
                result[0] += -7.90548147060323e-05;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02446805795595660346) ) ) {
                result[0] += 0.00019474818632897177;
              } else {
                result[0] += 3.967991060953702e-05;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                result[0] += -1.1620344585689695e-05;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.858234205283420677e-05) ) ) {
                    result[0] += -1.1620344585689695e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                      result[0] += -1.1620344585689695e-05;
                    } else {
                      result[0] += -1.1620344585689695e-05;
                    }
                  }
                } else {
                  result[0] += -1.1620344585689695e-05;
                }
              }
            } else {
              result[0] += -1.1620344585689695e-05;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
              result[0] += -1.1620344585689695e-05;
            } else {
              result[0] += -1.1620344585689695e-05;
            }
          }
        } else {
          result[0] += -1.1620344585689695e-05;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8850000000000001199) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5050000000000001155) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.115000000000000005) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.03500000000000001027) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7890731911809046872) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
                result[0] += -1.1404628179691037e-05;
              } else {
                result[0] += -0.00012567052559548845;
              }
            } else {
              result[0] += 6.513565992802971e-06;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3931761618090452437) ) ) {
              result[0] += 0.0009754033635843034;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5179236987437186857) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5041457217085428821) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4908111093216080412) ) ) {
                    result[0] += -0.00011374740540313533;
                  } else {
                    result[0] += 0.0005528954300917498;
                  }
                } else {
                  result[0] += -0.00033696068378348814;
                }
              } else {
                result[0] += 8.996831515378252e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5792515097236182742) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01000276686157755036) ) ) {
              result[0] += 0.0001535688554372667;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5493276582412061071) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5072261056783921029) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06473550000000001525) ) ) {
                    result[0] += 0.0007600146989380188;
                  } else {
                    result[0] += 0.0022135714861598477;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02251500000000000376) ) ) {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007384500000000001306) ) ) {
                      result[0] += 0.00023022306592490775;
                    } else {
                      result[0] += -0.0007571372719023871;
                    }
                  } else {
                    result[0] += 0.0008047407936188605;
                  }
                }
              } else {
                result[0] += 0.001260441677948465;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5834559473869348478) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3550000000000000377) ) ) {
                result[0] += 8.748901077859526e-06;
              } else {
                result[0] += -0.0008196477432685302;
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2326999203141443262) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1534042965400678749) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3850000000000000644) ) ) {
                    result[0] += -0.00010527205010166556;
                  } else {
                    result[0] += 0.000498900780694179;
                  }
                } else {
                  result[0] += 0.0017012943834426462;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3251271839107726103) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2650000000000000688) ) ) {
                    result[0] += -0.00040125302741646094;
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5750000000000000666) ) ) {
                      result[0] += 0.00024262621225324508;
                    } else {
                      result[0] += -0.0006774641326442245;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6850000000000001643) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003504500000000000236) ) ) {
                      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1250000000000000278) ) ) {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -0.0005788293198233941;
                        } else {
                          result[0] += -3.1536511703068065e-05;
                        }
                      } else {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.578971790991679312e-05) ) ) {
                          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5380790363330137938) ) ) {
                            result[0] += 0.0008224392844270606;
                          } else {
                            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8440161800932387548) ) ) {
                              result[0] += -0.0003337130830662676;
                            } else {
                              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.224356303145077041) ) ) {
                                result[0] += 0.0009564149135846465;
                              } else {
                                result[0] += 6.340023059350521e-05;
                              }
                            }
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7760221401809592745) ) ) {
                            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5053668411911326208) ) ) {
                              result[0] += -0.00023857281315737148;
                            } else {
                              result[0] += 0.0009315261102252067;
                            }
                          } else {
                            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2450000000000000233) ) ) {
                              result[0] += 0.0008390378998191449;
                            } else {
                              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9112103514676580529) ) ) {
                                result[0] += -0.0010624749599983782;
                              } else {
                                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3550000000000000377) ) ) {
                                  result[0] += -0.00025330135548089016;
                                } else {
                                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5050000000000001155) ) ) {
                                    result[0] += 0.0005509073445196041;
                                  } else {
                                    result[0] += -0.00013482723948953393;
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1350000000000000366) ) ) {
                        result[0] += 0.0013897839471716641;
                      } else {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01351316588546045208) ) ) {
                          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01868100000000000316) ) ) {
                            result[0] += 0.0004959523204236;
                          } else {
                            result[0] += -0.0004998550472512079;
                          }
                        } else {
                          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01568578759365070463) ) ) {
                            result[0] += 0.0015515016482964892;
                          } else {
                            result[0] += 0.0005588044869903678;
                          }
                        }
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02616152934301940389) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003637500000000000542) ) ) {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0009285000000000001802) ) ) {
                          result[0] += 0.0006626427590905558;
                        } else {
                          result[0] += -5.708407109312402e-05;
                        }
                      } else {
                        result[0] += -0.0006381016137101581;
                      }
                    } else {
                      result[0] += 0.00032946265436855233;
                    }
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004552500000000000123) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5550000000000001599) ) ) {
            result[0] += -0.00039754605085145757;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0119121105025029022) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.052300094327177008e-06) ) ) {
                result[0] += -0.00031618925625966543;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.171316810410465458e-05) ) ) {
                  result[0] += 0.0029509867784578508;
                } else {
                  result[0] += 0.0007654486032571823;
                }
              }
            } else {
              result[0] += 0.0013618282974187741;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02616152934301940389) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006290243127013950622) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002867412157011550635) ) ) {
                result[0] += 0.000988136549484349;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005013289129500051074) ) ) {
                  result[0] += -0.0010583733705631494;
                } else {
                  result[0] += -9.90272507601871e-06;
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008332142139858200389) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08693186820944626136) ) ) {
                  result[0] += 0.00018410507484812303;
                } else {
                  result[0] += 0.001322331860474677;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09221529126392057074) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.020650504707780553) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02328402533912880476) ) ) {
                      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1494199460089949139) ) ) {
                        result[0] += 0.0011195467688162705;
                      } else {
                        result[0] += -5.3481602081745624e-05;
                      }
                    } else {
                      result[0] += -0.0007281752614889602;
                    }
                  } else {
                    result[0] += 0.0029238651182080205;
                  }
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01302823237808665123) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3830383354773237436) ) ) {
                      result[0] += -0.0025356373818131587;
                    } else {
                      result[0] += -6.386685746366366e-05;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1948292836308671283) ) ) {
                      result[0] += -0.0012847058215291116;
                    } else {
                      result[0] += 0.000383087548967763;
                    }
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
              result[0] += -1.5964602330556422e-05;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5386386389447237466) ) ) {
                result[0] += 0.0025908861350905613;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9550000000000000711) ) ) {
                  result[0] += 0.001487959183218852;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5671541132663318052) ) ) {
                    result[0] += -0.0008823520947322263;
                  } else {
                    result[0] += 0.0010900402807218193;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0526089167981486569) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01657900000000000346) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003690377133234250349) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002769500000000000694) ) ) {
              result[0] += 0.005394358752289978;
            } else {
              result[0] += -0.0004875478775805935;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9250000000000001554) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9150000000000001465) ) ) {
                result[0] += 0.003296571654433784;
              } else {
                result[0] += 0.0006143588346258411;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007090500000000000448) ) ) {
                result[0] += 0.005355410099528914;
              } else {
                result[0] += 0.004209542581714783;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01444878842564100048) ) ) {
              result[0] += -0.0006120130537199078;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04014449846134480332) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.590591194899497629) ) ) {
                  result[0] += 0.0026948765882450643;
                } else {
                  result[0] += -0.0002450325863657183;
                }
              } else {
                result[0] += -0.00024394168325248482;
              }
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01881166515770610337) ) ) {
              result[0] += 0.001709537131799089;
            } else {
              result[0] += 0.004020141128975278;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02511600000000000291) ) ) {
            result[0] += 0.005080928388093594;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.07392400000000001747) ) ) {
              result[0] += 0.0019260488983415779;
            } else {
              result[0] += 0.0033751737695572044;
            }
          }
        } else {
          result[0] += 0.005075080086548395;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                  result[0] += -1.1157800894383451e-05;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                    result[0] += -1.1157800894383451e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      result[0] += -1.1157800894383451e-05;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        result[0] += -1.1157800894383451e-05;
                      } else {
                        result[0] += -1.1157800894383451e-05;
                      }
                    }
                  }
                }
              } else {
                result[0] += -1.2157186818088908e-05;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5687531224874372571) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4781247323869347032) ) ) {
                  result[0] += 3.465951581367145e-05;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.51994285276381913) ) ) {
                    result[0] += -0.00010966417809402806;
                  } else {
                    result[0] += 1.303667656245785e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6402694681155779444) ) ) {
                    result[0] += -1.1848474312336095e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7114754460552764614) ) ) {
                      result[0] += -2.4636667702653193e-06;
                    } else {
                      result[0] += -1.1157800894383451e-05;
                    }
                  }
                } else {
                  result[0] += -1.2327050249897068e-07;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -1.1157800894383451e-05;
                  } else {
                    result[0] += -1.1157800894383451e-05;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                    result[0] += -1.1157800894383451e-05;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      result[0] += -1.1157800894383451e-05;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                        result[0] += -1.1157800894383451e-05;
                      } else {
                        result[0] += -1.1157800894383451e-05;
                      }
                    }
                  }
                }
              } else {
                result[0] += -1.1157800894383451e-05;
              }
            } else {
              result[0] += -1.1157800894383451e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001504690974371400121) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5920309527638191183) ) ) {
              result[0] += 6.525037786120909e-07;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.883880929790755059e-06) ) ) {
                  result[0] += -1.1157800894383451e-05;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7093978733165829942) ) ) {
                    result[0] += -1.1157800894383451e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
                      result[0] += 7.264898145948455e-05;
                    } else {
                      result[0] += -1.1555748199047401e-05;
                    }
                  }
                }
              } else {
                result[0] += -2.0618586941508007e-06;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01359050000000000188) ) ) {
              result[0] += 5.579188134446439e-08;
            } else {
              result[0] += 0.00010970654489215594;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                result[0] += -1.1157800894383451e-05;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.858234205283420677e-05) ) ) {
                    result[0] += -1.1157800894383451e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                      result[0] += -1.1157800894383451e-05;
                    } else {
                      result[0] += -1.1157800894383451e-05;
                    }
                  }
                } else {
                  result[0] += -1.1157800894383451e-05;
                }
              }
            } else {
              result[0] += -1.1157800894383451e-05;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
              result[0] += -1.1157800894383451e-05;
            } else {
              result[0] += -1.1157800894383451e-05;
            }
          }
        } else {
          result[0] += -1.1157800894383451e-05;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8850000000000001199) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5050000000000001155) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.115000000000000005) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.03500000000000001027) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7890731911809046872) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
                result[0] += -1.0950671003351693e-05;
              } else {
                result[0] += -0.00012066825493400425;
              }
            } else {
              result[0] += 6.254295810609898e-06;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3931761618090452437) ) ) {
              result[0] += 0.000936577778940246;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5179236987437186857) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5041457217085428821) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4908111093216080412) ) ) {
                    result[0] += -0.00010921973030850303;
                  } else {
                    result[0] += 0.0005308876237607801;
                  }
                } else {
                  result[0] += -0.0003235480833779694;
                }
              } else {
                result[0] += 8.638715830555268e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5792515097236182742) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01000276686157755036) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3650556104053715445) ) ) {
                result[0] += 0.0003791481017951202;
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2677063317952667609) ) ) {
                  result[0] += -0.0002817449126739861;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2145423861003193655) ) ) {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.05751864358971629093) ) ) {
                      result[0] += 0.0004543210420870008;
                    } else {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.002753795023577549923) ) ) {
                        result[0] += -0.00039992562806981017;
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1206324332205917643) ) ) {
                          result[0] += 0.000479892938382267;
                        } else {
                          result[0] += -0.00013588814553654993;
                        }
                      }
                    }
                  } else {
                    result[0] += 0.0009458235335956402;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5493276582412061071) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5072261056783921029) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06473550000000001525) ) ) {
                    result[0] += 0.0007297625836327033;
                  } else {
                    result[0] += 0.0021254610589149007;
                  }
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.01363135066340469791) ) ) {
                    if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.08110515786938453375) ) ) {
                      result[0] += -1.8285377524178272e-05;
                    } else {
                      result[0] += -0.0013397886115522689;
                    }
                  } else {
                    result[0] += 0.0005264115566586928;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01704648841990550126) ) ) {
                  result[0] += 0.0016896039586663427;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09221529126392057074) ) ) {
                    result[0] += -0.00013335262848227574;
                  } else {
                    result[0] += 0.001376679194460512;
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5834559473869348478) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3550000000000000377) ) ) {
                result[0] += 8.400654176093176e-06;
              } else {
                result[0] += -0.0007870219558018534;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1413595000000000268) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2326999203141443262) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1534042965400678749) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3850000000000000644) ) ) {
                      result[0] += -0.00010108173351627242;
                    } else {
                      result[0] += 0.00046433140888757393;
                    }
                  } else {
                    result[0] += 0.0016323846533191368;
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6850000000000001643) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3251271839107726103) ) ) {
                      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2650000000000000688) ) ) {
                        result[0] += -0.0003916635935746812;
                      } else {
                        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5050000000000001155) ) ) {
                          result[0] += 0.0002256349792891013;
                        } else {
                          result[0] += -0.00030453057722866554;
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1250000000000000278) ) ) {
                        result[0] += -8.06736281758069e-05;
                      } else {
                        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2850000000000000866) ) ) {
                          result[0] += 0.00043325568411647144;
                        } else {
                          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7760221401809592745) ) ) {
                            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4287309711685468594) ) ) {
                              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3763200711443456803) ) ) {
                                result[0] += 0.0015012499979678128;
                              } else {
                                result[0] += -0.0004133325080437529;
                              }
                            } else {
                              result[0] += 0.0006136154702803468;
                            }
                          } else {
                            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.194581012612933923) ) ) {
                              result[0] += -0.00013401831426413584;
                            } else {
                              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                                result[0] += 0.0010399981474133557;
                              } else {
                                result[0] += -5.504615724850231e-05;
                              }
                            }
                          }
                        }
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8466324982590252013) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3966559369710560001) ) ) {
                        result[0] += 0.0006884840251903569;
                      } else {
                        result[0] += -0.00025104599752001145;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                        result[0] += 0.0009327382631106602;
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.249304608119721216) ) ) {
                          result[0] += -0.0007226659326569182;
                        } else {
                          result[0] += 0.00030546918686189016;
                        }
                      }
                    }
                  }
                }
              } else {
                result[0] += 0.0027061387618194767;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004552500000000000123) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5050000000000001155) ) ) {
            result[0] += -0.00039061052997790195;
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                result[0] += -0.0007462582105725276;
              } else {
                result[0] += 0.0009733974796180701;
              }
            } else {
              result[0] += 0.0009695262694043896;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02616152934301940389) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.317357466959798995) ) ) {
              result[0] += 0.0019444114846412506;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4129968667336683663) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01326604349644140181) ) ) {
                  result[0] += -0.002780294795189106;
                } else {
                  result[0] += -2.219304571527777e-05;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.488887876708542779) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.008143500000000001432) ) ) {
                    result[0] += 0.0019390222641689804;
                  } else {
                    result[0] += 0.0009305938533770466;
                  }
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.09893965937729458371) ) ) {
                    result[0] += -0.0008796313269741253;
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03705350000000001004) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.06355808660527756393) ) ) {
                        result[0] += 0.0014235184949904062;
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5719332634924624292) ) ) {
                          result[0] += -0.0011927833035948242;
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5876205025125629255) ) ) {
                            result[0] += 0.0017989019865303042;
                          } else {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6449783570351760309) ) ) {
                              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6161319161557790025) ) ) {
                                result[0] += -1.5859213073054772e-06;
                              } else {
                                result[0] += -0.0008765144984480749;
                              }
                            } else {
                              result[0] += 0.0005826766651876014;
                            }
                          }
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5408295445477387942) ) ) {
                        result[0] += 0.0021641349859818945;
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5986852915639623296) ) ) {
                          result[0] += -0.002004669212978936;
                        } else {
                          result[0] += -0.0004746464119429218;
                        }
                      }
                    }
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
              result[0] += -1.5329137001817008e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
                result[0] += 0.0023661060890195575;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6959555468592965033) ) ) {
                  result[0] += 0.00012127104655720855;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
                    result[0] += 0.0019109637243149874;
                  } else {
                    result[0] += -6.500584763002501e-05;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0526089167981486569) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01657900000000000346) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03127843326018551334) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5719332634924624292) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006186000000000001393) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00135663295830650032) ) ) {
                  result[0] += 0.0022309385021598758;
                } else {
                  result[0] += 0.004662564666311522;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
                  result[0] += -1.2336680168558823e-06;
                } else {
                  result[0] += 0.004353560321355441;
                }
              }
            } else {
              result[0] += 0.004203384674623328;
            }
          } else {
            result[0] += 0.004639493894936912;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3278371989949749321) ) ) {
            result[0] += 0.005850353564162896;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0184998371148766029) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2177889902755587859) ) ) {
                result[0] += 0.002813090864276193;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5392784256532664466) ) ) {
                  result[0] += -0.0012615320378268479;
                } else {
                  result[0] += 0.001159775100762727;
                }
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9450000000000000622) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.009014249010710599294) ) ) {
                  result[0] += 0.001519359419093863;
                } else {
                  result[0] += -0.0002298688206950792;
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0409003745630781082) ) ) {
                  result[0] += 0.003110922885010316;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4693077114572864472) ) ) {
                    result[0] += -0.0017343703017888557;
                  } else {
                    result[0] += 0.0028447666370148878;
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02511600000000000291) ) ) {
            result[0] += 0.0048786838372060345;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.07392400000000001747) ) ) {
              result[0] += 0.0018493832056415225;
            } else {
              result[0] += 0.003240826175760928;
            }
          }
        } else {
          result[0] += 0.004873068325227842;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                  result[0] += -1.0713668590518392e-05;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                    result[0] += -1.0713668590518392e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      result[0] += -1.0713668590518392e-05;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        result[0] += -1.0713668590518392e-05;
                      } else {
                        result[0] += -1.0713668590518392e-05;
                      }
                    }
                  }
                }
              } else {
                result[0] += -1.167327431228737e-05;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6059258460552764403) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4781247323869347032) ) ) {
                  result[0] += 3.327990608995594e-05;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1129321246270776624) ) ) {
                    result[0] += -6.676984284851351e-05;
                  } else {
                    result[0] += 1.0074078202640022e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005479696504671500816) ) ) {
                    result[0] += -1.0713668590518392e-05;
                  } else {
                    result[0] += -1.1178469031331005e-05;
                  }
                } else {
                  result[0] += 9.896889583502128e-07;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -1.0713668590518392e-05;
                  } else {
                    result[0] += -1.0713668590518392e-05;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                    result[0] += -1.0713668590518392e-05;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      result[0] += -1.0713668590518392e-05;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                        result[0] += -1.0713668590518392e-05;
                      } else {
                        result[0] += -1.0713668590518392e-05;
                      }
                    }
                  }
                }
              } else {
                result[0] += -1.0713668590518392e-05;
              }
            } else {
              result[0] += -1.0713668590518392e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001504690974371400121) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5920309527638191183) ) ) {
              result[0] += 6.265310973266715e-07;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.883880929790755059e-06) ) ) {
                  result[0] += -1.0713668590518392e-05;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7093978733165829942) ) ) {
                    result[0] += -1.0713668590518392e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
                      result[0] += 6.975721454103266e-05;
                    } else {
                      result[0] += -1.1095775743981379e-05;
                    }
                  }
                }
              } else {
                result[0] += -1.979787140737558e-06;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01359050000000000188) ) ) {
              result[0] += 5.3571105312266055e-08;
            } else {
              result[0] += 0.00010533971481576019;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                result[0] += -1.0713668590518392e-05;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.858234205283420677e-05) ) ) {
                    result[0] += -1.0713668590518392e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                      result[0] += -1.0713668590518392e-05;
                    } else {
                      result[0] += -1.0713668590518392e-05;
                    }
                  }
                } else {
                  result[0] += -1.0713668590518392e-05;
                }
              }
            } else {
              result[0] += -1.0713668590518392e-05;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
              result[0] += -1.0713668590518392e-05;
            } else {
              result[0] += -1.0713668590518392e-05;
            }
          }
        } else {
          result[0] += -1.0713668590518392e-05;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8850000000000001199) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3850000000000000644) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002490043859502850346) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.0650000000000000161) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.175366324986798601e-07) ) ) {
                result[0] += -3.071893889102902e-05;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5671541132663318052) ) ) {
                  result[0] += -6.643927287900663e-05;
                } else {
                  result[0] += 6.853868941774059e-05;
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.485713013107980879e-05) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6487823756783920315) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5814822343216081713) ) ) {
                    result[0] += -0.00021338907874528202;
                  } else {
                    result[0] += -5.609271454338058e-05;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6968016071608041928) ) ) {
                    result[0] += 5.531481894050146e-05;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7990273242713569202) ) ) {
                      result[0] += -4.897121746952288e-05;
                    } else {
                      result[0] += -2.810260615988985e-06;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6647073645226131422) ) ) {
                  result[0] += 0.0002989832607475126;
                } else {
                  result[0] += -2.2956641011380876e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8393503195226131863) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.25500000000000006) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)5.045799003287211847e-06) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5072261056783921029) ) ) {
                        result[0] += -0.00019602774475119793;
                      } else {
                        result[0] += -9.074628329966222e-06;
                      }
                    } else {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2250000000000000333) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6881801856532664408) ) ) {
                          result[0] += 0.00026921986486128563;
                        } else {
                          result[0] += -8.268235612202311e-06;
                        }
                      } else {
                        result[0] += -0.0003363563447846923;
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.115000000000000005) ) ) {
                      result[0] += 0.00020096472012617883;
                    } else {
                      result[0] += 0.00039088671534299557;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.310012234630710122e-06) ) ) {
                    result[0] += -4.967946522358149e-05;
                  } else {
                    result[0] += 0.0011173659532858794;
                  }
                }
              } else {
                result[0] += -0.0001424269158493568;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5347873053015076428) ) ) {
                result[0] += 0.00037177571237393195;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1148003695523622109) ) ) {
                  result[0] += -0.0006838544382917104;
                } else {
                  result[0] += -0.0002339962527420834;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.96280210579579717) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4737195465326633492) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03018900000000000403) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4323286620486300191) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4183012963065327328) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3644118032412060892) ) ) {
                      result[0] += -0.0002914589892862321;
                    } else {
                      result[0] += 0.0016879763482340875;
                    }
                  } else {
                    result[0] += -0.0005119747339642917;
                  }
                } else {
                  if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2672247508226724966) ) ) {
                    result[0] += 0.0008892446943496965;
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3150000000000000577) ) ) {
                      result[0] += 0.0007267336606330428;
                    } else {
                      result[0] += -0.000403518830437558;
                    }
                  }
                }
              } else {
                result[0] += 0.001674933932826753;
              }
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.244955337349149066) ) ) {
                result[0] += -0.0008832492676574445;
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
                  result[0] += 0.0010596058534851865;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4838161673366834781) ) ) {
                    result[0] += -0.0006874085608990049;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.505061141934673441) ) ) {
                      result[0] += 0.0008491447894298437;
                    } else {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02500000000000000486) ) ) {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002342500000000000398) ) ) {
                          result[0] += -0.00013832566683123803;
                        } else {
                          result[0] += -1.852150548731645e-06;
                        }
                      } else {
                        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1050000000000000239) ) ) {
                          result[0] += 0.0003754994649303211;
                        } else {
                          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5950000000000000844) ) ) {
                            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04562750000000000833) ) ) {
                              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03873000000000000748) ) ) {
                                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0006235000000000000308) ) ) {
                                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0004715000000000000766) ) ) {
                                    result[0] += 3.9419485779787954e-05;
                                  } else {
                                    result[0] += -0.0002786929740344458;
                                  }
                                } else {
                                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5050000000000001155) ) ) {
                                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3850000000000000644) ) ) {
                                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3650000000000000466) ) ) {
                                        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3450000000000000289) ) ) {
                                          result[0] += 0.00015807121589190805;
                                        } else {
                                          result[0] += -0.0002732075030481632;
                                        }
                                      } else {
                                        result[0] += 0.0006144148652397288;
                                      }
                                    } else {
                                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4450000000000000622) ) ) {
                                        result[0] += -0.00032669544292644314;
                                      } else {
                                        result[0] += 0.00027556462825050664;
                                      }
                                    }
                                  } else {
                                    result[0] += 0.00041663969661615686;
                                  }
                                }
                              } else {
                                result[0] += -0.0005632533366697111;
                              }
                            } else {
                              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1550000000000000266) ) ) {
                                result[0] += -0.00016325644708786401;
                              } else {
                                result[0] += 0.0008038993201548722;
                              }
                            }
                          } else {
                            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03091100000000000445) ) ) {
                              result[0] += -1.1308206591050044e-05;
                            } else {
                              result[0] += -0.0005751668603150606;
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          } else {
            result[0] += -0.0003332664331176266;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004552500000000000123) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004867285882244350333) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003941149135554950639) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9450000000000000622) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2177889902755587859) ) ) {
                  result[0] += 0.0010262288036842063;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5012509875628141653) ) ) {
                    result[0] += -0.0006566900085361961;
                  } else {
                    result[0] += 0.0003018057510426066;
                  }
                }
              } else {
                result[0] += 0.0007085756985499041;
              }
            } else {
              result[0] += -8.282402418727094e-05;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7990273242713569202) ) ) {
              result[0] += 0.0011769202626083289;
            } else {
              result[0] += -0.00033651436164367534;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02616152934301940389) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4250000000000000444) ) ) {
              result[0] += 0.0009272564683562688;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.06355808660527756393) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.002753795023577549923) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4129968667336683663) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01000276686157755036) ) ) {
                        result[0] += -0.001434851099011402;
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01822956926157560595) ) ) {
                          result[0] += 0.001022894891390953;
                        } else {
                          result[0] += -0.0012079725964711213;
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.008143500000000001432) ) ) {
                        result[0] += 0.001753919220028442;
                      } else {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03389850000000000502) ) ) {
                          result[0] += -5.39463181965784e-05;
                        } else {
                          result[0] += 0.0021412158936707356;
                        }
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0173600348455768029) ) ) {
                      result[0] += 0.0002051066949965237;
                    } else {
                      result[0] += -0.0008225948554688182;
                    }
                  }
                } else {
                  result[0] += 0.0023424761191832297;
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05311250000000000693) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4650000000000000244) ) ) {
                    result[0] += -0.0007103032782248821;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6449783570351760309) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3346339054385528144) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1129321246270776624) ) ) {
                          result[0] += -0.002303645343885597;
                        } else {
                          result[0] += 0.0011483590463948307;
                        }
                      } else {
                        result[0] += -0.0013894389438594333;
                      }
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8440161800932387548) ) ) {
                        result[0] += 0.0009992272586964877;
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7712418641206031378) ) ) {
                          result[0] += -0.0006611003164325731;
                        } else {
                          result[0] += 0.00035057774394466187;
                        }
                      }
                    }
                  }
                } else {
                  result[0] += -0.0012608613770845546;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4183012963065327328) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03795623917694670307) ) ) {
                result[0] += 0.0025280822184363164;
              } else {
                result[0] += -0.0007343137141817153;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.243144592614154248) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0816878293504414571) ) ) {
                  result[0] += 0.0014828268051457164;
                } else {
                  result[0] += 0.003313886061036236;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7990273242713569202) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9808239647505231362) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.543101476988260834) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6553322322110554099) ) ) {
                        result[0] += 0.000421134453360064;
                      } else {
                        result[0] += -0.0018846015528556775;
                      }
                    } else {
                      result[0] += 0.0017494435938362237;
                    }
                  } else {
                    result[0] += -0.0008073417186294238;
                  }
                } else {
                  result[0] += 0.0018429147655490234;
                }
              }
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0526089167981486569) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01657900000000000346) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03127843326018551334) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5719332634924624292) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002769500000000000694) ) ) {
                result[0] += 0.005687565970786232;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3837516359296482826) ) ) {
                    result[0] += -0.0009973747465098137;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5361772370603016258) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9150000000000001465) ) ) {
                        result[0] += -0.0004521869088110316;
                      } else {
                        result[0] += 0.0038663534101214853;
                      }
                    } else {
                      result[0] += -0.0006164483658498077;
                    }
                  }
                } else {
                  result[0] += 0.0044165442896382774;
                }
              }
            } else {
              result[0] += 0.004036070439744726;
            }
          } else {
            result[0] += 0.004454820487351423;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1828583041203602211) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03409611752714010457) ) ) {
                result[0] += 0.0037077297904846646;
              } else {
                result[0] += -0.0002300636690836637;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01444878842564100048) ) ) {
                result[0] += -0.0008704671604411899;
              } else {
                result[0] += 0.000566642614832601;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3278371989949749321) ) ) {
              result[0] += 0.0056174823172682915;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01881166515770610337) ) ) {
                result[0] += -0.00025596468134930376;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4693077114572864472) ) ) {
                  result[0] += 0.0024800030320913306;
                } else {
                  result[0] += 0.003871791745051342;
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02511600000000000291) ) ) {
            result[0] += 0.004684489558874877;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.07392400000000001747) ) ) {
              result[0] += 0.0017757691636250187;
            } else {
              result[0] += 0.003111826240245729;
            }
          }
        } else {
          result[0] += 0.004679097570357613;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                  result[0] += -1.0287214815352997e-05;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                    result[0] += -1.0287214815352997e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      result[0] += -1.0287214815352997e-05;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        result[0] += -1.0287214815352997e-05;
                      } else {
                        result[0] += -1.0287214815352997e-05;
                      }
                    }
                  }
                }
              } else {
                result[0] += -1.1208623772002614e-05;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5687531224874372571) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.07196201389915944657) ) ) {
                  result[0] += -5.648672938828542e-05;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009152500000000002647) ) ) {
                    result[0] += 3.3114237095295515e-06;
                  } else {
                    result[0] += 0.00038624588438129716;
                  }
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6402694681155779444) ) ) {
                    result[0] += -1.0950396223075554e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7114754460552764614) ) ) {
                      result[0] += -1.9261968187219164e-06;
                    } else {
                      result[0] += -1.0287214815352997e-05;
                    }
                  }
                } else {
                  result[0] += -1.5775798157761648e-07;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -1.0287214815352997e-05;
                  } else {
                    result[0] += -1.0287214815352997e-05;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                    result[0] += -1.0287214815352997e-05;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      result[0] += -1.0287214815352997e-05;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                        result[0] += -1.0287214815352997e-05;
                      } else {
                        result[0] += -1.0287214815352997e-05;
                      }
                    }
                  }
                }
              } else {
                result[0] += -1.0287214815352997e-05;
              }
            } else {
              result[0] += -1.0287214815352997e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001504690974371400121) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5920309527638191183) ) ) {
              result[0] += 6.01592249400236e-07;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.883880929790755059e-06) ) ) {
                  result[0] += -1.0287214815352997e-05;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7093978733165829942) ) ) {
                    result[0] += -1.0287214815352997e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
                      result[0] += 6.698055337826597e-05;
                    } else {
                      result[0] += -1.065411232921072e-05;
                    }
                  }
                }
              } else {
                result[0] += -1.9009824163746546e-06;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01359050000000000188) ) ) {
              result[0] += 5.1438726481639994e-08;
            } else {
              result[0] += 0.00010114670486044163;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                result[0] += -1.0287214815352997e-05;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.858234205283420677e-05) ) ) {
                    result[0] += -1.0287214815352997e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                      result[0] += -1.0287214815352997e-05;
                    } else {
                      result[0] += -1.0287214815352997e-05;
                    }
                  }
                } else {
                  result[0] += -1.0287214815352997e-05;
                }
              }
            } else {
              result[0] += -1.0287214815352997e-05;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
              result[0] += -1.0287214815352997e-05;
            } else {
              result[0] += -1.0287214815352997e-05;
            }
          }
        } else {
          result[0] += -1.0287214815352997e-05;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8250000000000000666) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3850000000000000644) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002339521674937150662) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.0650000000000000161) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.175366324986798601e-07) ) ) {
                result[0] += -2.9496182432914526e-05;
              } else {
                result[0] += 1.1718466954045455e-05;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.485713013107980879e-05) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)5.85801459308964273e-06) ) ) {
                  result[0] += -0.00020873229534770806;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                    result[0] += 0.0003632431255355895;
                  } else {
                    result[0] += -4.206849912048847e-05;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.000584175175977650024) ) ) {
                  result[0] += 5.06637054921573e-05;
                } else {
                  result[0] += -2.389508777280393e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8282572652763819931) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.485713013107980879e-05) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.25500000000000006) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7789937396482412568) ) ) {
                      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.07500000000000002498) ) ) {
                        result[0] += 6.544431694917198e-05;
                      } else {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7292744312814071206) ) ) {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6665289424874373259) ) ) {
                            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6481803955276382867) ) ) {
                              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5179236987437186857) ) ) {
                                result[0] += -0.00016182148514344273;
                              } else {
                                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5745673188442211865) ) ) {
                                  result[0] += 0.0003564088494194782;
                                } else {
                                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5951110425376885393) ) ) {
                                    result[0] += -0.00010502942885445926;
                                  } else {
                                    result[0] += 0.00011042547131247532;
                                  }
                                }
                              }
                            } else {
                              result[0] += -0.00032986528609478435;
                            }
                          } else {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6881801856532664408) ) ) {
                              result[0] += 0.0010242724063935238;
                            } else {
                              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7093978733165829942) ) ) {
                                result[0] += -0.0001254643123575586;
                              } else {
                                result[0] += 0.00018349395468175147;
                              }
                            }
                          }
                        } else {
                          result[0] += -0.00020913042978396628;
                        }
                      }
                    } else {
                      result[0] += 0.0003006116762798074;
                    }
                  } else {
                    result[0] += 0.0007520850502774091;
                  }
                } else {
                  result[0] += 0.0007196674071145096;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8643464628140704598) ) ) {
                  result[0] += -0.00020077678994556442;
                } else {
                  result[0] += 8.952754903204609e-06;
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5347873053015076428) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001074448343160400252) ) ) {
                  result[0] += 0.0005752616232536556;
                } else {
                  result[0] += -0.00011757920063467171;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0003680466634131000282) ) ) {
                  result[0] += -0.000702749814271602;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001939744889791500219) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6161319161557790025) ) ) {
                      result[0] += -0.00024957142324311327;
                    } else {
                      result[0] += 0.00019638615604795567;
                    }
                  } else {
                    result[0] += -0.0008760174638873398;
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5041457217085428821) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3644118032412060892) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3278371989949749321) ) ) {
                result[0] += 0.0011892294490098861;
              } else {
                result[0] += -0.0006521477971635204;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4183012963065327328) ) ) {
                result[0] += 0.0016012564400342117;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4419864859045226635) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4389499174623116007) ) ) {
                    result[0] += 0.0005750816605478613;
                  } else {
                    result[0] += -0.00043244749176083683;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4639489995477387718) ) ) {
                    result[0] += 0.0014497845030740104;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4838161673366834781) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4797597438944724013) ) ) {
                        result[0] += 0.00027992870971318664;
                      } else {
                        result[0] += -0.000783360164043937;
                      }
                    } else {
                      result[0] += 0.0011308902501291408;
                    }
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1494199460089949139) ) ) {
              result[0] += -0.0007740922575954702;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.96280210579579717) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02577363736079425413) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6722423356281408413) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6647073645226131422) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04500000000000000527) ) ) {
                          result[0] += -8.252360642183283e-05;
                        } else {
                          result[0] += 4.437529896596142e-05;
                        }
                      } else {
                        result[0] += -0.0003198276475505724;
                      }
                    } else {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02500000000000000486) ) ) {
                        result[0] += -2.1933614376097785e-05;
                      } else {
                        result[0] += 0.0005177644955944035;
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7875164333668343009) ) ) {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1750000000000000167) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
                          result[0] += -0.00012891739135993799;
                        } else {
                          result[0] += -0.00047578208686819494;
                        }
                      } else {
                        result[0] += -6.8794077956181004e-06;
                      }
                    } else {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1750000000000000167) ) ) {
                        result[0] += 3.341415134461225e-05;
                      } else {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2650000000000000688) ) ) {
                          result[0] += -0.00027125388126331986;
                        } else {
                          result[0] += 0.0003426902764741071;
                        }
                      }
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.555096866909547848) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5400528323115579843) ) ) {
                      result[0] += 0.001020789066857456;
                    } else {
                      result[0] += 0.0014504607899549797;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7954292854522614364) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7686690743216081367) ) ) {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6116569490452262725) ) ) {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5800027599246232457) ) ) {
                            result[0] += 0.0007598698630566854;
                          } else {
                            result[0] += -0.0003484939726014102;
                          }
                        } else {
                          result[0] += 0.0003449770131947632;
                        }
                      } else {
                        result[0] += -0.00023106594785617189;
                      }
                    } else {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09500000000000001499) ) ) {
                        result[0] += -6.381061863802363e-06;
                      } else {
                        result[0] += 0.0009244543338308586;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.00032000088104849715;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002154500000000000599) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002055218118527550337) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6782348568386622478) ) ) {
              result[0] += -0.0005644944974743859;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.002347679878538096e-06) ) ) {
                result[0] += -0.0008706224741905536;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9450000000000000622) ) ) {
                  result[0] += 0.00048368853844441305;
                } else {
                  result[0] += 0.0008511161305586153;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.767254320477387064) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001653500000000000239) ) ) {
                result[0] += 0.0011785253225232069;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001798500000000000185) ) ) {
                  result[0] += -0.0003086389928804614;
                } else {
                  result[0] += 0.0007138624060038666;
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03350035677887956004) ) ) {
                result[0] += -0.00042299816701907837;
              } else {
                result[0] += 0.0013496639618304144;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006290243127013950622) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3091220225414461065) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002339521674937150662) ) ) {
                result[0] += 0.0014629287513485772;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4443392717336683839) ) ) {
                  result[0] += -0.00047581775430427005;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5650000000000000577) ) ) {
                    result[0] += 0.0009363389623506262;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7250000000000000888) ) ) {
                      result[0] += -0.00038543835107100174;
                    } else {
                      result[0] += 0.001979076684631974;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6716133195226131614) ) ) {
                result[0] += -0.0013292372772609451;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8440161800932387548) ) ) {
                  result[0] += 0.0017134574050275719;
                } else {
                  result[0] += -0.0005057049584799682;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002289500000000000302) ) ) {
              result[0] += -0.0017334551535053593;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004552500000000000123) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.767254320477387064) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7114754460552764614) ) ) {
                    result[0] += 0.0011163307006682337;
                  } else {
                    result[0] += 0.0019410931308301688;
                  }
                } else {
                  result[0] += -0.00013603278357351344;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4183012963065327328) ) ) {
                  if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5470680148669562204) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3644118032412060892) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3044676633919599085) ) ) {
                        result[0] += 0.0007898719959097567;
                      } else {
                        result[0] += -0.0013917233113225369;
                      }
                    } else {
                      result[0] += 0.002115510836552481;
                    }
                  } else {
                    result[0] += -0.0006258417632119393;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5792515097236182742) ) ) {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01415250000000000188) ) ) {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3539353041941689093) ) ) {
                        result[0] += 0.0016252158444320015;
                      } else {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00799750000000000287) ) ) {
                          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006308000000000001106) ) ) {
                            result[0] += -0.00046632592564169444;
                          } else {
                            result[0] += 0.0016784351580290185;
                          }
                        } else {
                          result[0] += -0.0001384065380681148;
                        }
                      }
                    } else {
                      result[0] += 0.002008567799388624;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7990273242713569202) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9808239647505231362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4364163272837385255) ) ) {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6299505656030152112) ) ) {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5951110425376885393) ) ) {
                              result[0] += -0.0011463288387576324;
                            } else {
                              result[0] += 0.0014428162417350495;
                            }
                          } else {
                            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3466557816143853721) ) ) {
                              result[0] += 0.00041036167723449194;
                            } else {
                              result[0] += -0.000814229350818834;
                            }
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
                            result[0] += 0.0009796121325363154;
                          } else {
                            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9186477097784532253) ) ) {
                              result[0] += -0.0012219522561326324;
                            } else {
                              result[0] += 0.002839973182938398;
                            }
                          }
                        }
                      } else {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05311250000000000693) ) ) {
                          result[0] += 0.00037125132594463723;
                        } else {
                          result[0] += -0.001733194975458167;
                        }
                      }
                    } else {
                      result[0] += 0.001007752715559675;
                    }
                  }
                }
              }
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01657900000000000346) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02751676046985590193) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5719332634924624292) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007090500000000000448) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008506177121675452882) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4484214422864321592) ) ) {
                    result[0] += 0.0022050309235785463;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4992002680402010117) ) ) {
                      result[0] += -0.0023783607315616463;
                    } else {
                      result[0] += 0.00010090025693135027;
                    }
                  }
                } else {
                  result[0] += 0.00485055112314499;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.421180086331658321) ) ) {
                  result[0] += -0.0009808008232404155;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4931942899748744114) ) ) {
                    result[0] += 0.0032057263056608745;
                  } else {
                    result[0] += -0.00030308361558625287;
                  }
                }
              }
            } else {
              result[0] += 0.003286729896076779;
            }
          } else {
            result[0] += 0.0041497523159556154;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04953562823777350743) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04477003072051350535) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01444878842564100048) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03018900000000000403) ) ) {
                  result[0] += 0.0014901628131612763;
                } else {
                  result[0] += -0.0012953707283203171;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09221529126392057074) ) ) {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4323286620486300191) ) ) {
                    result[0] += 0.0002487776944810045;
                  } else {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1494199460089949139) ) ) {
                      result[0] += 0.0030043677598382296;
                    } else {
                      result[0] += 0.0009530279128516882;
                    }
                  }
                } else {
                  result[0] += -0.0001294779859289279;
                }
              }
            } else {
              result[0] += -0.0007494086236137276;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4093335132160804135) ) ) {
              result[0] += -0.0009189547155282478;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9993516786272610419) ) ) {
                result[0] += 0.003333071003061659;
              } else {
                result[0] += 0.0005657777121480143;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01881166515770610337) ) ) {
          result[0] += 0.002807448733929897;
        } else {
          result[0] += 0.004285266202775503;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                  result[0] += -9.877735881327801e-06;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                    result[0] += -9.877735881327801e-06;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      result[0] += -9.877735881327801e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        result[0] += -9.877735881327801e-06;
                      } else {
                        result[0] += -9.877735881327801e-06;
                      }
                    }
                  }
                }
              } else {
                result[0] += -1.0762468481534754e-05;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6059258460552764403) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4781247323869347032) ) ) {
                  result[0] += 3.4203645453513226e-05;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006452000000000001137) ) ) {
                    result[0] += 3.9064274604687875e-06;
                  } else {
                    result[0] += -6.961211566913205e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005479696504671500816) ) ) {
                    result[0] += -9.877735881327801e-06;
                  } else {
                    result[0] += -1.0297637405064375e-05;
                  }
                } else {
                  result[0] += 9.565742411341636e-07;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -9.877735881327801e-06;
                  } else {
                    result[0] += -9.877735881327801e-06;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                    result[0] += -9.877735881327801e-06;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      result[0] += -9.877735881327801e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                        result[0] += -9.877735881327801e-06;
                      } else {
                        result[0] += -9.877735881327801e-06;
                      }
                    }
                  }
                }
              } else {
                result[0] += -9.877735881327801e-06;
              }
            } else {
              result[0] += -9.877735881327801e-06;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001504690974371400121) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5920309527638191183) ) ) {
              result[0] += 5.776460834628375e-07;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.883880929790755059e-06) ) ) {
                  result[0] += -9.877735881327801e-06;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7093978733165829942) ) ) {
                    result[0] += -9.877735881327801e-06;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
                      result[0] += 6.431441622743901e-05;
                    } else {
                      result[0] += -1.0230029169885715e-05;
                    }
                  }
                }
              } else {
                result[0] += -1.8253144860913234e-06;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01359050000000000188) ) ) {
              result[0] += 4.939122623347509e-08;
            } else {
              result[0] += 9.712059617798256e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                result[0] += -9.877735881327801e-06;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.858234205283420677e-05) ) ) {
                    result[0] += -9.877735881327801e-06;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                      result[0] += -9.877735881327801e-06;
                    } else {
                      result[0] += -9.877735881327801e-06;
                    }
                  }
                } else {
                  result[0] += -9.877735881327801e-06;
                }
              }
            } else {
              result[0] += -9.877735881327801e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
              result[0] += -9.877735881327801e-06;
            } else {
              result[0] += -9.877735881327801e-06;
            }
          }
        } else {
          result[0] += -9.877735881327801e-06;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8850000000000001199) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5050000000000001155) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.115000000000000005) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1050000000000000239) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4295075599497487628) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07500000000000002498) ) ) {
                result[0] += 0.00017907583921793812;
              } else {
                result[0] += 0.001290247576158351;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4443392717336683839) ) ) {
                result[0] += -0.0002085952038875656;
              } else {
                result[0] += -2.9464054220055077e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5336217185678392427) ) ) {
              result[0] += -0.0003115507608744286;
            } else {
              result[0] += -3.440579909113868e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2323027026914575854) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06473550000000001525) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1534042965400678749) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.05751864358971629093) ) ) {
                  if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.06765554132556478306) ) ) {
                    if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.08110515786938453375) ) ) {
                      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1494199460089949139) ) ) {
                        result[0] += 0.00020477062911843205;
                      } else {
                        result[0] += 0.0008773614340486347;
                      }
                    } else {
                      result[0] += -0.00034198572106484835;
                    }
                  } else {
                    result[0] += 0.0018946687618997717;
                  }
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.03941486779484403707) ) ) {
                    result[0] += -0.00036141963709301704;
                  } else {
                    result[0] += 4.641755477217094e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.590591194899497629) ) ) {
                  result[0] += 0.0009383675882051063;
                } else {
                  result[0] += 0.001651575412988428;
                }
              }
            } else {
              result[0] += 0.0016046565588591927;
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7850000000000001421) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3346339054385528144) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3115605993075549196) ) ) {
                  result[0] += 4.370981410302997e-06;
                } else {
                  result[0] += -0.0004507526901085287;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3892782419974109565) ) ) {
                  result[0] += 0.0007957032666614641;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4287309711685468594) ) ) {
                    result[0] += -0.00037392954709226304;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5018975334485012985) ) ) {
                      result[0] += 0.000592421191727367;
                    } else {
                      result[0] += 4.2988980307635756e-05;
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8577098326317653676) ) ) {
                result[0] += -0.0002633113805147577;
              } else {
                result[0] += 0.00013174393675251147;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004552500000000000123) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5550000000000001599) ) ) {
            result[0] += -0.0003924210919205183;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.052300094327177008e-06) ) ) {
              result[0] += -0.00029977493997687503;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7990273242713569202) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01568578759365070463) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.171316810410465458e-05) ) ) {
                    result[0] += 0.002796048399577144;
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001237226668511850168) ) ) {
                      result[0] += 0.0002168610404678736;
                    } else {
                      result[0] += 0.000738535202043677;
                    }
                  }
                } else {
                  result[0] += 0.0015015051108862073;
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02261952378991480619) ) ) {
                  result[0] += 0.0011238555403122606;
                } else {
                  result[0] += -0.000226791533092846;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1050145000000000106) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4093335132160804135) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.317357466959798995) ) ) {
                result[0] += 0.0010518517780995522;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01326604349644140181) ) ) {
                  result[0] += -0.0027628471190758504;
                } else {
                  result[0] += -0.00024530898450527636;
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02192319026750580435) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0173600348455768029) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03873000000000000748) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01044150000000000113) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009152500000000002647) ) ) {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005707500000000000767) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1148003695523622109) ) ) {
                            result[0] += 0.0009172052468502683;
                          } else {
                            result[0] += -0.0003064619246611281;
                          }
                        } else {
                          result[0] += 0.000474243701415633;
                        }
                      } else {
                        result[0] += -0.001202581071231374;
                      }
                    } else {
                      result[0] += 0.0011337532296272072;
                    }
                  } else {
                    result[0] += -0.0007761690207945442;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2533229942273665936) ) ) {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.03659918966571634041) ) ) {
                      result[0] += -5.709849265970497e-05;
                    } else {
                      result[0] += -0.001512853305626146;
                    }
                  } else {
                    result[0] += 0.00010101837399059453;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03705350000000001004) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02511600000000000291) ) ) {
                    result[0] += 0.000998449931524712;
                  } else {
                    result[0] += 0.0027285474866203005;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4143094250104821241) ) ) {
                    result[0] += 0.0011352188623855737;
                  } else {
                    result[0] += -0.0016269212236499292;
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03028287126648195396) ) ) {
              result[0] += 0.0004668122413846981;
            } else {
              result[0] += 0.0023623786433273897;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0526089167981486569) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01287800000000000229) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01397330054109465099) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5719332634924624292) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4484214422864321592) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3644118032412060892) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2929122217587940002) ) ) {
                    result[0] += 0.005499448639256121;
                  } else {
                    result[0] += -0.0002435941772972471;
                  }
                } else {
                  result[0] += 0.003605207139163888;
                }
              } else {
                result[0] += 0.0010689223740941597;
              }
            } else {
              result[0] += 0.003940047281987223;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
              result[0] += 0.0035655183959226134;
            } else {
              result[0] += 0.004903373623763321;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3278371989949749321) ) ) {
            result[0] += 0.005223306927652111;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4347441410050251753) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4133512684738382403) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
                  result[0] += -0.00019328769724803166;
                } else {
                  result[0] += 0.0031327690368137024;
                }
              } else {
                result[0] += -0.004899821776152273;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01910124190761275029) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9550000000000000711) ) ) {
                  result[0] += 0.002062204187800904;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
                    result[0] += -0.0016279254697981129;
                  } else {
                    result[0] += 0.001610502989203429;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9550000000000000711) ) ) {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.009014249010710599294) ) ) {
                    result[0] += 0.0027456377873224364;
                  } else {
                    result[0] += -0.00022063472335594376;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1206324332205917643) ) ) {
                    result[0] += 0.0035262103955529247;
                  } else {
                    result[0] += 0.0020258294535308195;
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02511600000000000291) ) ) {
          result[0] += 0.004489139068889384;
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
            result[0] += 0.0024959288027576717;
          } else {
            result[0] += 0.003924228181842113;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                  result[0] += -9.48455611091686e-06;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                    result[0] += -9.48455611091686e-06;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      result[0] += -9.48455611091686e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        result[0] += -9.48455611091686e-06;
                      } else {
                        result[0] += -9.48455611091686e-06;
                      }
                    }
                  }
                }
              } else {
                result[0] += -1.0334072244030173e-05;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6059258460552764403) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4781247323869347032) ) ) {
                  result[0] += 3.284218148766137e-05;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006452000000000001137) ) ) {
                    result[0] += 3.750933502087312e-06;
                  } else {
                    result[0] += -6.684123011545496e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005479696504671500816) ) ) {
                    result[0] += -9.48455611091686e-06;
                  } else {
                    result[0] += -9.887743603555472e-06;
                  }
                } else {
                  result[0] += 9.184981430253928e-07;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -9.48455611091686e-06;
                  } else {
                    result[0] += -9.48455611091686e-06;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                    result[0] += -9.48455611091686e-06;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      result[0] += -9.48455611091686e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                        result[0] += -9.48455611091686e-06;
                      } else {
                        result[0] += -9.48455611091686e-06;
                      }
                    }
                  }
                }
              } else {
                result[0] += -9.48455611091686e-06;
              }
            } else {
              result[0] += -9.48455611091686e-06;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001504690974371400121) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5920309527638191183) ) ) {
              result[0] += 5.546530861602927e-07;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.883880929790755059e-06) ) ) {
                  result[0] += -9.48455611091686e-06;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7093978733165829942) ) ) {
                    result[0] += -9.48455611091686e-06;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
                      result[0] += 6.175440371948977e-05;
                    } else {
                      result[0] += -9.822826490178898e-06;
                    }
                  }
                }
              } else {
                result[0] += -1.7526584909127038e-06;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01359050000000000188) ) ) {
              result[0] += 4.742522600586412e-08;
            } else {
              result[0] += 9.325474532246245e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                result[0] += -9.48455611091686e-06;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.858234205283420677e-05) ) ) {
                    result[0] += -9.48455611091686e-06;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                      result[0] += -9.48455611091686e-06;
                    } else {
                      result[0] += -9.48455611091686e-06;
                    }
                  }
                } else {
                  result[0] += -9.48455611091686e-06;
                }
              }
            } else {
              result[0] += -9.48455611091686e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
              result[0] += -9.48455611091686e-06;
            } else {
              result[0] += -9.48455611091686e-06;
            }
          }
        } else {
          result[0] += -9.48455611091686e-06;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5050000000000001155) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5800027599246232457) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.72638075848137134e-06) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2650000000000000688) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09500000000000001499) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03500000000000001027) ) ) {
                  result[0] += -0.00014456188371243106;
                } else {
                  result[0] += 6.470090140694481e-05;
                }
              } else {
                result[0] += -0.0001961701224401774;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3050000000000000488) ) ) {
                result[0] += -0.00015681901442763933;
              } else {
                result[0] += 0.0022248250354470985;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5748180127889448432) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09500000000000001499) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5612777274623116375) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08201150000000001494) ) ) {
                    result[0] += 6.182443327373985e-05;
                  } else {
                    result[0] += -0.0004095528576151878;
                  }
                } else {
                  result[0] += -0.00014454979556941804;
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06473550000000001525) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1050000000000000239) ) ) {
                    result[0] += 0.0009311284835730652;
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.115000000000000005) ) ) {
                      result[0] += -0.00041243228454964823;
                    } else {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4850000000000000422) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1550000000000000266) ) ) {
                          result[0] += 0.000658546569929074;
                        } else {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2350000000000000144) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1850000000000000255) ) ) {
                              result[0] += 0.0003036036858019051;
                            } else {
                              result[0] += -0.00018403927620765833;
                            }
                          } else {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2450000000000000233) ) ) {
                              result[0] += 0.0008226087279092119;
                            } else {
                              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.25500000000000006) ) ) {
                                result[0] += -0.00035129720494374956;
                              } else {
                                result[0] += 0.00043956377419099226;
                              }
                            }
                          }
                        }
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4838161673366834781) ) ) {
                          result[0] += -0.0019726373668020286;
                        } else {
                          result[0] += 0.0005382433615520582;
                        }
                      }
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.09229200000000001292) ) ) {
                    result[0] += 0.0017857153809303016;
                  } else {
                    result[0] += 0.0011384667423264758;
                  }
                }
              }
            } else {
              result[0] += 0.0013248699862049404;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1127930000000000182) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08965900000000000258) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8507017292462312197) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                      result[0] += -2.2191531419867297e-05;
                    } else {
                      result[0] += 7.626965854315368e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8550000000000000933) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6249533869346735049) ) ) {
                        result[0] += -4.537321704187696e-05;
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7211604863065327331) ) ) {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6836184685175880071) ) ) {
                              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6796249047236181395) ) ) {
                                result[0] += 3.6841499952939435e-05;
                              } else {
                                result[0] += 0.0014756621984184874;
                              }
                            } else {
                              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6881801856532664408) ) ) {
                                result[0] += -0.00035621271125046825;
                              } else {
                                result[0] += 3.0744182365360184e-06;
                              }
                            }
                          } else {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7104391779899498216) ) ) {
                              result[0] += 0.0013317040543069194;
                            } else {
                              result[0] += 0.00011021803210800841;
                            }
                          }
                        } else {
                          result[0] += -7.259519886649278e-06;
                        }
                      }
                    } else {
                      result[0] += -0.0003387291967807621;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01469650000000000123) ) ) {
                    result[0] += -0.00026053784803362664;
                  } else {
                    result[0] += 1.9302579416618908e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003504500000000000236) ) ) {
                  result[0] += 1.3774668389097396e-05;
                } else {
                  result[0] += 0.00029289889347767074;
                }
              }
            } else {
              result[0] += -0.00024317415494795098;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6732382808793971884) ) ) {
              result[0] += 0.0020214123282575247;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7890731911809046872) ) ) {
                result[0] += -0.0009700586517090811;
              } else {
                result[0] += 0.00038481815342941185;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004552500000000000123) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5550000000000001599) ) ) {
            result[0] += -0.0003768009096561416;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.767254320477387064) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01568578759365070463) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7114754460552764614) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5336217185678392427) ) ) {
                    result[0] += 0.0008432472185445003;
                  } else {
                    result[0] += 0.00037032930821136135;
                  }
                } else {
                  result[0] += 0.0016173213309967705;
                }
              } else {
                result[0] += 0.0012977819525912412;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002726474613321750156) ) ) {
                result[0] += 0.0008652963871730751;
              } else {
                result[0] += -1.404098443957867e-05;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02616152934301940389) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.488887876708542779) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4129968667336683663) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.009795390075261452625) ) ) {
                  result[0] += -0.0020488911987826468;
                } else {
                  result[0] += 0.0006768150299380889;
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.008143500000000001432) ) ) {
                  result[0] += 0.001797775590271001;
                } else {
                  result[0] += 0.0009914167268014187;
                }
              }
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.09893965937729458371) ) ) {
                result[0] += -0.0009776070089051827;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03705350000000001004) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.670427493643216188) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3466557816143853721) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5455059598241206453) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.020650504707780553) ) ) {
                          result[0] += 0.0015385230450284647;
                        } else {
                          result[0] += -0.0010329815798736793;
                        }
                      } else {
                        result[0] += 0.0006293654022729361;
                      }
                    } else {
                      result[0] += -0.0007230121524273413;
                    }
                  } else {
                    result[0] += 0.0007232346724337203;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5494686760804020631) ) ) {
                    result[0] += 0.00026329904608310314;
                  } else {
                    result[0] += -0.000794940449020045;
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
              result[0] += -5.6478067638864714e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5800027599246232457) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06646350000000002256) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03545400000000000634) ) ) {
                      result[0] += 0.0020526476034329667;
                    } else {
                      result[0] += 0.00020884495527598182;
                    }
                  } else {
                    result[0] += 0.003292814122907156;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6959555468592965033) ) ) {
                    result[0] += 0.0005862592229176111;
                  } else {
                    result[0] += 0.001682350536874449;
                  }
                }
              } else {
                result[0] += -0.0010132275114769582;
              }
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01798150000000000096) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5748180127889448432) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02751676046985590193) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007090500000000000448) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5361772370603016258) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5012509875628141653) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4484214422864321592) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3569067370100503234) ) ) {
                        result[0] += 0.0010951734109368838;
                      } else {
                        result[0] += 0.004695914320181358;
                      }
                    } else {
                      result[0] += -0.00024713565125227135;
                    }
                  } else {
                    result[0] += 0.005280102378527203;
                  }
                } else {
                  result[0] += 0.0006508104913073371;
                }
              } else {
                result[0] += -0.0002586595505729212;
              }
            } else {
              result[0] += 0.00408212658153282;
            }
          } else {
            result[0] += 0.003726396634190871;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04953562823777350743) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03940025850376690369) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1828583041203602211) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.378188349821562797) ) ) {
                  result[0] += 0.0018544614985219515;
                } else {
                  result[0] += 0.00449355852536927;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01444878842564100048) ) ) {
                  result[0] += -0.0007949973097370601;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03350035677887956004) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0240756843176193544) ) ) {
                      result[0] += 0.0017947108262161005;
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1250629713251516228) ) ) {
                        result[0] += 0.0004264605211545915;
                      } else {
                        result[0] += -0.00122268100194719;
                      }
                    }
                  } else {
                    result[0] += 0.004219900296912426;
                  }
                }
              }
            } else {
              result[0] += -0.0006941136273259372;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4093335132160804135) ) ) {
              result[0] += -0.0009972716192489183;
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.009014249010710599294) ) ) {
                result[0] += 0.0038967014072895075;
              } else {
                result[0] += 0.002006746721915008;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01881166515770610337) ) ) {
          if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.05580247069824354617) ) ) {
            result[0] += 0.0036063720374962436;
          } else {
            result[0] += -0.00011053406892495633;
          }
        } else {
          result[0] += 0.003932122890092781;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                  result[0] += -9.107026721698296e-06;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                    result[0] += -9.107026721698296e-06;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      result[0] += -9.107026721698296e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        result[0] += -9.107026721698296e-06;
                      } else {
                        result[0] += -9.107026721698296e-06;
                      }
                    }
                  }
                }
              } else {
                result[0] += -9.922728166689681e-06;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6059258460552764403) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1643367459977091716) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4781247323869347032) ) ) {
                    result[0] += 3.153491011168513e-05;
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006708500000000000921) ) ) {
                      result[0] += 3.91969424453966e-08;
                    } else {
                      result[0] += -9.496137331657484e-05;
                    }
                  }
                } else {
                  result[0] += 0.00037921465777023157;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005479696504671500816) ) ) {
                    result[0] += -9.107026721698296e-06;
                  } else {
                    result[0] += -9.494165479313746e-06;
                  }
                } else {
                  result[0] += 8.819376504857554e-07;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -9.107026721698296e-06;
                  } else {
                    result[0] += -9.107026721698296e-06;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                    result[0] += -9.107026721698296e-06;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      result[0] += -9.107026721698296e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                        result[0] += -9.107026721698296e-06;
                      } else {
                        result[0] += -9.107026721698296e-06;
                      }
                    }
                  }
                }
              } else {
                result[0] += -9.107026721698296e-06;
              }
            } else {
              result[0] += -9.107026721698296e-06;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001504690974371400121) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5920309527638191183) ) ) {
              result[0] += 5.325753169534639e-07;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.883880929790755059e-06) ) ) {
                  result[0] += -9.107026721698296e-06;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7093978733165829942) ) ) {
                    result[0] += -9.107026721698296e-06;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
                      result[0] += 5.9296291600680074e-05;
                    } else {
                      result[0] += -9.431832368591197e-06;
                    }
                  }
                }
              } else {
                result[0] += -1.6828945418311348e-06;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01359050000000000188) ) ) {
              result[0] += 4.55374817194719e-08;
            } else {
              result[0] += 8.954277328796748e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                result[0] += -9.107026721698296e-06;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.858234205283420677e-05) ) ) {
                    result[0] += -9.107026721698296e-06;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                      result[0] += -9.107026721698296e-06;
                    } else {
                      result[0] += -9.107026721698296e-06;
                    }
                  }
                } else {
                  result[0] += -9.107026721698296e-06;
                }
              }
            } else {
              result[0] += -9.107026721698296e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
              result[0] += -9.107026721698296e-06;
            } else {
              result[0] += -9.107026721698296e-06;
            }
          }
        } else {
          result[0] += -9.107026721698296e-06;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9250000000000001554) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5050000000000001155) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.115000000000000005) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1050000000000000239) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4295075599497487628) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07500000000000002498) ) ) {
                result[0] += 0.00017071910935654523;
              } else {
                result[0] += 0.0012364288297741235;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4443392717336683839) ) ) {
                result[0] += -0.00020275304546317743;
              } else {
                result[0] += -3.2974802937015633e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5336217185678392427) ) ) {
              result[0] += -0.0002827328727469127;
            } else {
              result[0] += -3.423944819760116e-05;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005479696504671500816) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.08500000000000000611) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6161319161557790025) ) ) {
                result[0] += 0.00025760082300852887;
              } else {
                result[0] += -0.00016771176293517876;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0007535000000000001549) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.25500000000000006) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5041457217085428821) ) ) {
                    result[0] += -0.00021588044122338481;
                  } else {
                    result[0] += 2.880504176422339e-05;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8099155601256282644) ) ) {
                    result[0] += 0.0006760168226759446;
                  } else {
                    result[0] += -7.169681824423548e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6050000000000000933) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6796249047236181395) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006308000000000001106) ) ) {
                        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5350000000000001421) ) ) {
                          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3950000000000000733) ) ) {
                            result[0] += 0.000201390267308504;
                          } else {
                            result[0] += -0.00024188628336925934;
                          }
                        } else {
                          result[0] += 0.001467854917316271;
                        }
                      } else {
                        result[0] += -0.00012292648350671663;
                      }
                    } else {
                      result[0] += 0.0011397940681390898;
                    }
                  } else {
                    result[0] += -0.00018840238486353468;
                  }
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001350500000000000355) ) ) {
                    result[0] += -0.00167240824313848;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5628434130653267031) ) ) {
                      result[0] += 0.0007210092650460988;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6784611311055277483) ) ) {
                        result[0] += -0.0004608330447127924;
                      } else {
                        result[0] += -5.757290448676482e-05;
                      }
                    }
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1050000000000000239) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.52031910737473408) ) ) {
                result[0] += 0.001984982287519201;
              } else {
                result[0] += 0.0013161730632618401;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2326999203141443262) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1908722399174398732) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06473550000000001525) ) ) {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003091000000000000431) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002579500000000000629) ) ) {
                        result[0] += 0.00039810947693235267;
                      } else {
                        result[0] += 0.001035636915518697;
                      }
                    } else {
                      result[0] += 0.00013429826246978035;
                    }
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04853104146385620737) ) ) {
                      result[0] += 0.0009752072176791736;
                    } else {
                      result[0] += 0.004081911490704228;
                    }
                  }
                } else {
                  result[0] += 0.001361221052052478;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3346339054385528144) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006708500000000000921) ) ) {
                    result[0] += 0.0003274654735593403;
                  } else {
                    result[0] += -0.0005238539498669068;
                  }
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0008045000000000002019) ) ) {
                    result[0] += -0.00028918860168194196;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3763200711443456803) ) ) {
                      result[0] += 0.002002967906260934;
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4287309711685468594) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3966559369710560001) ) ) {
                          result[0] += 0.0008474226266473808;
                        } else {
                          result[0] += -0.0005674312778365593;
                        }
                      } else {
                        result[0] += 0.00021932219761677387;
                      }
                    }
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004552500000000000123) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004867285882244350333) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5550000000000001599) ) ) {
              result[0] += -0.00038836180363150346;
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.01051018765715429869) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7572008430306190752) ) ) {
                  result[0] += 0.0002675455768981562;
                } else {
                  result[0] += 0.0010425350466709176;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09221529126392057074) ) ) {
                  result[0] += -0.0006133618851341805;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.384300133116745416e-05) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.381175493840676405e-06) ) ) {
                      result[0] += 0.0012203402526483264;
                    } else {
                      result[0] += 0.0028767320904237352;
                    }
                  } else {
                    result[0] += 0.00024728120941216027;
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7990273242713569202) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01650738594486505367) ) ) {
                result[0] += 0.0009309736438816093;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5650000000000000577) ) ) {
                  result[0] += 0.0006244244963263075;
                } else {
                  result[0] += 0.0017693585190515957;
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03536062175606080604) ) ) {
                result[0] += -0.00046320675341865003;
              } else {
                result[0] += 0.0006344732704981898;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06508917425002432033) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03291917222295825951) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.317357466959798995) ) ) {
                  result[0] += 0.0024386051536647753;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008883026007095952761) ) ) {
                    result[0] += -0.0021304188711713254;
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01905700000000000102) ) ) {
                      result[0] += 0.0009708293131445577;
                    } else {
                      result[0] += -0.00036348868843700567;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04073300000000000531) ) ) {
                  result[0] += -0.001138070401336303;
                } else {
                  result[0] += 0.0018299154808895113;
                }
              }
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.181114681928726734) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02528885254406800301) ) ) {
                  if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2108839252750100701) ) ) {
                    result[0] += 0.00013650424403352724;
                  } else {
                    result[0] += 0.001250997095639275;
                  }
                } else {
                  result[0] += 0.00258600151602093;
                }
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1044543990012605922) ) ) {
                  result[0] += -0.0009681121838253512;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5179236987437186857) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08201150000000001494) ) ) {
                      result[0] += -0.0010253244954023684;
                    } else {
                      result[0] += 0.0035993490350449144;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05721739154190200877) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.555096866909547848) ) ) {
                        result[0] += 0.0018785085962167458;
                      } else {
                        result[0] += -0.0007331773428280102;
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5528143519346734314) ) ) {
                        result[0] += -0.002737750967812872;
                      } else {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05311250000000000693) ) ) {
                          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01940114940222455522) ) ) {
                            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0173600348455768029) ) ) {
                              result[0] += 0.0001610593385261767;
                            } else {
                              result[0] += -0.0011745178138579384;
                            }
                          } else {
                            result[0] += 0.0016130129594397627;
                          }
                        } else {
                          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1469960000000000155) ) ) {
                            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6732382808793971884) ) ) {
                              result[0] += -0.0013462081129152928;
                            } else {
                              result[0] += -2.8697411594012223e-05;
                            }
                          } else {
                            result[0] += 0.0006008581533560478;
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6425364825628142595) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4419864859045226635) ) ) {
                result[0] += 0.00029429415110337874;
              } else {
                result[0] += 0.002708911606599232;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6836184685175880071) ) ) {
                result[0] += -0.0030155449784350194;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9993516786272610419) ) ) {
                  result[0] += 0.002884709804446052;
                } else {
                  result[0] += 0.0006560783430441145;
                }
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03181986453917805963) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.07000300000000002354) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007384500000000001306) ) ) {
            result[0] += 0.004215538478110992;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3763200711443456803) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2669585275879397535) ) ) {
                result[0] += 0.0052684482521136175;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3931761618090452437) ) ) {
                  result[0] += -0.00023040892916627236;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5515127872864322711) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5386386389447237466) ) ) {
                      result[0] += 0.0025826949415278955;
                    } else {
                      result[0] += -0.0008573431578549712;
                    }
                  } else {
                    result[0] += 0.003807290502403271;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6717423563567840317) ) ) {
                result[0] += -0.002068102003541347;
              } else {
                result[0] += 0.0023117247685198366;
              }
            }
          }
        } else {
          result[0] += -0.0010949900902672185;
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02615650000000000266) ) ) {
            result[0] += 0.0037592866712495288;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1168105000000000254) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08720350000000000323) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05052800000000001041) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03468100000000001043) ) ) {
                    result[0] += 0.0016688014359729471;
                  } else {
                    result[0] += -0.0007939764524235053;
                  }
                } else {
                  result[0] += 0.0029828894104940175;
                }
              } else {
                result[0] += -0.0007887583638817804;
              }
            } else {
              result[0] += 0.002997691418622916;
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02722700000000000467) ) ) {
            result[0] += 0.0042816829023310165;
          } else {
            result[0] += 0.003611508916228797;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                  result[0] += -8.744524755804234e-06;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                    result[0] += -8.744524755804234e-06;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      result[0] += -8.744524755804234e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        result[0] += -8.744524755804234e-06;
                      } else {
                        result[0] += -8.744524755804234e-06;
                      }
                    }
                  }
                }
              } else {
                result[0] += -9.52775749433103e-06;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5687531224874372571) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.07196201389915944657) ) ) {
                  result[0] += -4.6340529799910384e-05;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009152500000000002647) ) ) {
                    result[0] += 2.873254908916966e-06;
                  } else {
                    result[0] += 0.00038008288480845183;
                  }
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6402694681155779444) ) ) {
                    result[0] += -1.1060592726579824e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7114754460552764614) ) ) {
                      result[0] += -6.825933787309205e-07;
                    } else {
                      result[0] += -8.744524755804234e-06;
                    }
                  }
                } else {
                  result[0] += -2.6122028688155265e-07;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -8.744524755804234e-06;
                  } else {
                    result[0] += -8.744524755804234e-06;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                    result[0] += -8.744524755804234e-06;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      result[0] += -8.744524755804234e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                        result[0] += -8.744524755804234e-06;
                      } else {
                        result[0] += -8.744524755804234e-06;
                      }
                    }
                  }
                }
              } else {
                result[0] += -8.744524755804234e-06;
              }
            } else {
              result[0] += -8.744524755804234e-06;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001504690974371400121) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5920309527638191183) ) ) {
              result[0] += 5.113763455128555e-07;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.883880929790755059e-06) ) ) {
                  result[0] += -8.744524755804234e-06;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                    result[0] += -8.744524755804234e-06;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
                      result[0] += 5.693602376219222e-05;
                    } else {
                      result[0] += -9.056401629220318e-06;
                    }
                  }
                }
              } else {
                result[0] += -1.6159075219783776e-06;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03500000000000001027) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
                result[0] += -5.403315975746768e-06;
              } else {
                result[0] += 7.523302437258638e-05;
              }
            } else {
              result[0] += 0.0014228826813968058;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                result[0] += -8.744524755804234e-06;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.858234205283420677e-05) ) ) {
                    result[0] += -8.744524755804234e-06;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                      result[0] += -8.744524755804234e-06;
                    } else {
                      result[0] += -8.744524755804234e-06;
                    }
                  }
                } else {
                  result[0] += -8.744524755804234e-06;
                }
              }
            } else {
              result[0] += -8.744524755804234e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
              result[0] += -8.744524755804234e-06;
            } else {
              result[0] += -8.744524755804234e-06;
            }
          }
        } else {
          result[0] += -8.744524755804234e-06;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8850000000000001199) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5050000000000001155) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4643511832914573034) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01622350000000000528) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02840822384442750342) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4052145559547739029) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5470680148669562204) ) ) {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7983975536720421262) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2750000000000000777) ) ) {
                      result[0] += -0.0002786373606886793;
                    } else {
                      result[0] += 0.0007526975286417906;
                    }
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007107894154605750962) ) ) {
                      result[0] += 0.0007207832930606659;
                    } else {
                      result[0] += -0.0001740417123322088;
                    }
                  }
                } else {
                  result[0] += -0.0002903783520652908;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.421180086331658321) ) ) {
                  result[0] += 0.0008197018681713939;
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4601878067544193374) ) ) {
                    result[0] += -0.0001892705608723325;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4636504894974874946) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4484214422864321592) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4405029099497487777) ) ) {
                          result[0] += 0.0004058840855384204;
                        } else {
                          result[0] += 0.0015715412746223176;
                        }
                      } else {
                        result[0] += -0.00010092237152894102;
                      }
                    } else {
                      result[0] += 0.001703221651580642;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.0006800548947722995;
            }
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7572008430306190752) ) ) {
              result[0] += -7.760886538145498e-05;
            } else {
              result[0] += 0.0018995873812838006;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02577363736079425413) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4734952854020100799) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2302999793555680907) ) ) {
                result[0] += 0.0002071325287083154;
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1494199460089949139) ) ) {
                  result[0] += -0.00036995766472200034;
                } else {
                  result[0] += -0.0001246245809868451;
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02446805795595660346) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6732382808793971884) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6577150591959800563) ) ) {
                      result[0] += -6.869205735095341e-06;
                    } else {
                      result[0] += 0.00037640316208339215;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6959555468592965033) ) ) {
                      result[0] += -0.00011743143749981382;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                        result[0] += -2.2827726997803903e-05;
                      } else {
                        result[0] += 1.215864896177203e-05;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6050000000000000933) ) ) {
                    result[0] += 2.9334700725721308e-05;
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6550000000000001377) ) ) {
                      result[0] += -0.0003996554328119243;
                    } else {
                      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6750000000000001554) ) ) {
                        result[0] += 0.0007680488857694736;
                      } else {
                        result[0] += -6.394497234255503e-05;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.0001230572063531659;
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.194581012612933923) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.121680358022378199) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02796916660693585244) ) ) {
                  result[0] += 0.0007501904999843018;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0416474308606116575) ) ) {
                    result[0] += 8.881342725785894e-06;
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04397260539440395882) ) ) {
                      result[0] += 0.0002910207053907691;
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04953562823777350743) ) ) {
                        result[0] += -0.0001569480048030313;
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1149262718553918233) ) ) {
                          result[0] += 0.0008402766754185162;
                        } else {
                          result[0] += -0.0003953706405498693;
                        }
                      }
                    }
                  }
                }
              } else {
                result[0] += 0.0022403676872366812;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06628065069736611969) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04397260539440395882) ) ) {
                  result[0] += -2.678921915682597e-05;
                } else {
                  result[0] += 0.0005745400647825276;
                }
              } else {
                result[0] += -0.0003369112102915004;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001653500000000000239) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5550000000000001599) ) ) {
            result[0] += -0.00036094808475258303;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001350500000000000355) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.052300094327177008e-06) ) ) {
                result[0] += -0.00035312856063695637;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.171316810410465458e-05) ) ) {
                  result[0] += 0.0024919664623957857;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.000584175175977650024) ) ) {
                      result[0] += 0.0020368125971580906;
                    } else {
                      result[0] += -0.0006239798785924262;
                    }
                  } else {
                    result[0] += 0.0008248931057726541;
                  }
                }
              }
            } else {
              result[0] += 0.0010557716144951024;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006290243127013950622) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002237500000000000339) ) ) {
              result[0] += 0.00046762138038063464;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00424585153689335023) ) ) {
                result[0] += 3.349432502820866e-05;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004867285882244350333) ) ) {
                  result[0] += -0.0008920335795452548;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.020650504707780553) ) ) {
                    result[0] += 0.0005299927722619148;
                  } else {
                    result[0] += -0.000341522373569694;
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1304295000000000038) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.008306500000000001382) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002289500000000000302) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7750000000000001332) ) ) {
                    result[0] += -9.298297822334834e-05;
                  } else {
                    result[0] += 0.0028757259798618366;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6150000000000001021) ) ) {
                    result[0] += 0.00047736715540215596;
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004552500000000000123) ) ) {
                      result[0] += 0.001588959195321401;
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007543500000000000726) ) ) {
                        result[0] += 0.000490881668933665;
                      } else {
                        result[0] += 0.003195016442643464;
                      }
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.317357466959798995) ) ) {
                    result[0] += 0.001015372393251217;
                  } else {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4999497468491173047) ) ) {
                      result[0] += -0.001525753565228483;
                    } else {
                      result[0] += -8.786391045161217e-05;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09221529126392057074) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5612777274623116375) ) ) {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03127843326018551334) ) ) {
                        result[0] += 0.0009547341748331662;
                      } else {
                        result[0] += 0.00229011947853972;
                      }
                    } else {
                      result[0] += -0.00032320507534111396;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5674119023366835934) ) ) {
                      result[0] += -0.0011343507157565377;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5829435000502513065) ) ) {
                        result[0] += 0.003726088357708135;
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6059258460552764403) ) ) {
                          result[0] += -0.0014374201272672523;
                        } else {
                          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03705350000000001004) ) ) {
                            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02251500000000000376) ) ) {
                              result[0] += 0.00035666990652037287;
                            } else {
                              result[0] += 0.0021231744602412932;
                            }
                          } else {
                            result[0] += -0.00023826732739025736;
                          }
                        }
                      }
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0409003745630781082) ) ) {
                result[0] += 0.00010478053531799818;
              } else {
                result[0] += 0.0027242521281547177;
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3837516359296482826) ) ) {
          if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6269304705026225166) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003091000000000000431) ) ) {
              result[0] += 0.0040112169716193646;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01129950000000000225) ) ) {
                result[0] += -0.0010211583123629498;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03240100000000000618) ) ) {
                  result[0] += 0.004424888408693719;
                } else {
                  result[0] += 0.002312219223665624;
                }
              }
            }
          } else {
            result[0] += -0.0023050681089616582;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01172600000000000205) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008506177121675452882) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006124087708088651362) ) ) {
                result[0] += 0.0031457140950747874;
              } else {
                result[0] += -0.00023715917197030377;
              }
            } else {
              result[0] += 0.004018995412803379;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04953562823777350743) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1587324468652908105) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4405029099497487777) ) ) {
                  result[0] += 8.290022673118172e-05;
                } else {
                  result[0] += 0.0031681360507070096;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5400528323115579843) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02366047096071570086) ) ) {
                    result[0] += -0.0037416934138519635;
                  } else {
                    result[0] += 0.00010679199958632093;
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1311798687976579447) ) ) {
                    result[0] += 0.002240945355625726;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
                      result[0] += -0.0005923439820674424;
                    } else {
                      result[0] += 0.0018517173306700238;
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9808239647505231362) ) ) {
                result[0] += 0.0028262610078054;
              } else {
                result[0] += 0.001004180613926964;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01881166515770610337) ) ) {
          if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2302999793555680907) ) ) {
            result[0] += 0.004626379799535696;
          } else {
            result[0] += -4.1680101433471933e-05;
          }
        } else {
          result[0] += 0.003749904141634146;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                  result[0] += -8.396452051983596e-06;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                    result[0] += -8.396452051983596e-06;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      result[0] += -8.396452051983596e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        result[0] += -8.396452051983596e-06;
                      } else {
                        result[0] += -8.396452051983596e-06;
                      }
                    }
                  }
                }
              } else {
                result[0] += -9.148508489381058e-06;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                  result[0] += -8.396452051983596e-06;
                } else {
                  result[0] += -9.13437575263145e-06;
                }
              } else {
                result[0] += 2.7760138938166423e-06;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7412676365326634764) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5472997959798996392) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.01778816268138619719) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4838161673366834781) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4443392717336683839) ) ) {
                      result[0] += -1.83886828923118e-06;
                    } else {
                      result[0] += 0.0002758028066558852;
                    }
                  } else {
                    result[0] += -5.243812918292669e-05;
                  }
                } else {
                  result[0] += 0.0004814311153277412;
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01254618095428180168) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5380790363330137938) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6161319161557790025) ) ) {
                      result[0] += -7.302533224190371e-05;
                    } else {
                      result[0] += -0.00011644162943960946;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6858832018090453841) ) ) {
                      result[0] += 4.188700191135763e-05;
                    } else {
                      result[0] += -8.458570176055322e-06;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                    result[0] += -1.02937967406363e-05;
                  } else {
                    result[0] += 0.00032751447792710555;
                  }
                }
              }
            } else {
              result[0] += -8.131397181575874e-06;
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -8.396452051983596e-06;
                  } else {
                    result[0] += -8.396452051983596e-06;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                    result[0] += -8.396452051983596e-06;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      result[0] += -8.396452051983596e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                        result[0] += -8.396452051983596e-06;
                      } else {
                        result[0] += -8.396452051983596e-06;
                      }
                    }
                  }
                }
              } else {
                result[0] += -8.396452051983596e-06;
              }
            } else {
              result[0] += -8.396452051983596e-06;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.729199597233659459e-06) ) ) {
              result[0] += -8.396452051983596e-06;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.166761325528187454) ) ) {
                result[0] += -5.1354558347373304e-05;
              } else {
                result[0] += 4.1121119783686206e-05;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                result[0] += -8.396452051983596e-06;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.858234205283420677e-05) ) ) {
                    result[0] += -8.396452051983596e-06;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                      result[0] += -8.396452051983596e-06;
                    } else {
                      result[0] += -8.396452051983596e-06;
                    }
                  }
                } else {
                  result[0] += -8.396452051983596e-06;
                }
              }
            } else {
              result[0] += -8.396452051983596e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
              result[0] += -8.396452051983596e-06;
            } else {
              result[0] += -8.396452051983596e-06;
            }
          }
        } else {
          result[0] += -8.396452051983596e-06;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9350000000000001643) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5050000000000001155) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.115000000000000005) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06628065069736611969) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.421180086331658321) ) ) {
                result[0] += 0.00036090536001350025;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4419864859045226635) ) ) {
                  result[0] += -0.0002842929622903918;
                } else {
                  result[0] += -8.201231442064881e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05378344711570890585) ) ) {
                result[0] += 0.0005167380210036452;
              } else {
                result[0] += 1.850644471833095e-05;
              }
            }
          } else {
            result[0] += -0.0002638678003137317;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0119121105025029022) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03240100000000000618) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3539353041941689093) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.381175493840676405e-06) ) ) {
                  result[0] += -0.00018267047850688606;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4050000000000000822) ) ) {
                    result[0] += 0.00012399425949495376;
                  } else {
                    result[0] += 0.0008741351154538645;
                  }
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.625000000000000111) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.08500000000000000611) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6650804020351760437) ) ) {
                      result[0] += 0.0008661787590213283;
                    } else {
                      result[0] += -0.0002214056887960704;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5153685380402011074) ) ) {
                      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.07196201389915944657) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.497782690150753826) ) ) {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4643511832914573034) ) ) {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4347441410050251753) ) ) {
                              result[0] += -9.418752312793097e-05;
                            } else {
                              result[0] += 0.0006228439086544028;
                            }
                          } else {
                            result[0] += -0.00026907593866490456;
                          }
                        } else {
                          result[0] += 0.0011215533975575862;
                        }
                      } else {
                        result[0] += -0.0006166645559194247;
                      }
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8393503195226131863) ) ) {
                        result[0] += 0.00028664960504560735;
                      } else {
                        result[0] += -0.00035108522168578394;
                      }
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6550000000000001377) ) ) {
                    result[0] += -0.0006582644200402076;
                  } else {
                    result[0] += -7.137279699010933e-05;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3850000000000000644) ) ) {
                result[0] += -4.818638467679585e-05;
              } else {
                result[0] += -0.00048419274301630965;
              }
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01278116174711865262) ) ) {
              result[0] += 0.0011228877718627184;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5650000000000000577) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4450000000000000622) ) ) {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4050000000000000822) ) ) {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.04779931491322893938) ) ) {
                        if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1878414568672973628) ) ) {
                          if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.294841568336650095) ) ) {
                            if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4323286620486300191) ) ) {
                              result[0] += 3.3712017819016436e-05;
                            } else {
                              result[0] += 0.0019326531451727776;
                            }
                          } else {
                            result[0] += -0.00014717769056804105;
                          }
                        } else {
                          result[0] += 0.0026175750979876315;
                        }
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1129321246270776624) ) ) {
                          result[0] += -0.0001147044904848015;
                        } else {
                          result[0] += 0.0005088266526913171;
                        }
                      }
                    } else {
                      result[0] += -0.0004590149982988269;
                    }
                  } else {
                    result[0] += 0.0010954159364756893;
                  }
                } else {
                  result[0] += -0.00028206925039447406;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0142099505541319511) ) ) {
                  result[0] += -0.000791867183017047;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01676384620505355291) ) ) {
                    result[0] += 0.0014553814421697584;
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02261952378991480619) ) ) {
                      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6350000000000001199) ) ) {
                        result[0] += -0.0009271730678846716;
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01969319515722280436) ) ) {
                          result[0] += 0.0005813479359426816;
                        } else {
                          result[0] += -0.00034132442001914745;
                        }
                      }
                    } else {
                      result[0] += 0.00010521798881081919;
                    }
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004552500000000000123) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00135663295830650032) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4052145559547739029) ) ) {
              result[0] += -0.000693106598093504;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7650000000000001243) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5950000000000000844) ) ) {
                  result[0] += 0.0012745261642665515;
                } else {
                  result[0] += -0.0002250438313718755;
                }
              } else {
                result[0] += 0.0019531152470753672;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.767254320477387064) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01650738594486505367) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3278371989949749321) ) ) {
                  result[0] += 0.002212257246335712;
                } else {
                  result[0] += 0.0006907243618700386;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7350000000000000977) ) ) {
                  result[0] += 0.0008877253889636254;
                } else {
                  result[0] += 0.0035068576461703203;
                }
              }
            } else {
              result[0] += 4.8680959904706314e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06508917425002432033) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006290243127013950622) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002867412157011550635) ) ) {
                result[0] += 0.0009480330497123344;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5455059598241206453) ) ) {
                  result[0] += -0.0006572711230097032;
                } else {
                  result[0] += -4.8614864120652704e-05;
                }
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.272781830548367354) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005046500000000001505) ) ) {
                  result[0] += -0.00032205819573411795;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.008306500000000001382) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006585500000000000208) ) ) {
                      result[0] += 0.0006034091444751746;
                    } else {
                      result[0] += 0.0018567663793274674;
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0956005000000000188) ) ) {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4026472078210281969) ) ) {
                        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
                          result[0] += 0.0022147472298441385;
                        } else {
                          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03312950000000000617) ) ) {
                            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01622350000000000528) ) ) {
                              result[0] += -4.055591082015967e-05;
                            } else {
                              result[0] += -0.0018280887536671108;
                            }
                          } else {
                            result[0] += 0.0009498949503559513;
                          }
                        }
                      } else {
                        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3539353041941689093) ) ) {
                          result[0] += 0.007386786778629641;
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.564374608675820677) ) ) {
                            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09221529126392057074) ) ) {
                              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
                                result[0] += -0.00044112776070067507;
                              } else {
                                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.03588532983514210878) ) ) {
                                  if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.01051018765715429869) ) ) {
                                    if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.03941486779484403707) ) ) {
                                      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1587324468652908105) ) ) {
                                        result[0] += 0.0012856317480040166;
                                      } else {
                                        result[0] += -0.0007312036161216766;
                                      }
                                    } else {
                                      result[0] += 0.004174195354622593;
                                    }
                                  } else {
                                    result[0] += -0.000691391289541115;
                                  }
                                } else {
                                  result[0] += 0.00216159106837799;
                                }
                              }
                            } else {
                              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1148003695523622109) ) ) {
                                result[0] += -0.002012906020054362;
                              } else {
                                result[0] += -3.489226709551633e-05;
                              }
                            }
                          } else {
                            result[0] += 0.0009990924299868005;
                          }
                        }
                      }
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3763200711443456803) ) ) {
                        result[0] += 0.0026123270554770034;
                      } else {
                        result[0] += 2.522568953636714e-05;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.0004972715574592046;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6425364825628142595) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4093335132160804135) ) ) {
                result[0] += 0.0003727275314855556;
              } else {
                result[0] += 0.0025464506219910793;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6902865188442212085) ) ) {
                result[0] += -0.0029219043252100138;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
                  result[0] += 0.0024238592591218798;
                } else {
                  result[0] += 0.0011978890638879248;
                }
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0526089167981486569) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.008143500000000001432) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01210357511382575101) ) ) {
            result[0] += 0.0027516485617641883;
          } else {
            result[0] += 0.004072601053064947;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.009602467408789250661) ) ) {
            if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.05580247069824354617) ) ) {
              result[0] += 0.0011289383852911236;
            } else {
              result[0] += -0.0030398920351907806;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6577150591959800563) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5800027599246232457) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4394533747236181176) ) ) {
                    result[0] += -0.0008298399082091991;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4797597438944724013) ) ) {
                      result[0] += 0.0030722557762090583;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5472997959798996392) ) ) {
                        result[0] += 0.00011042330152998725;
                      } else {
                        result[0] += 0.003181116229572862;
                      }
                    }
                  }
                } else {
                  result[0] += -0.0010793432764075485;
                }
              } else {
                result[0] += 0.003023903421262782;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2669585275879397535) ) ) {
                result[0] += 0.004565859860048182;
              } else {
                result[0] += 0.002634275431463249;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02511600000000000291) ) ) {
          result[0] += 0.003927993891497094;
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06217080128912850362) ) ) {
              result[0] += 0.003115477484377306;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021562361187840079) ) ) {
                result[0] += -0.0002925225592317294;
              } else {
                result[0] += 0.003629322472716543;
              }
            }
          } else {
            result[0] += 0.003318490482575198;
          }
        }
      }
    }
  }
}

