
#include "header.h"

void predict_unit3(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -5.3996242817412725e-05;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -5.3996242817412725e-05;
                  } else {
                    result[0] += -5.3996242817412725e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -5.3996242817412725e-05;
                    } else {
                      result[0] += -5.3996242817412725e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -5.3996242817412725e-05;
                    } else {
                      result[0] += -5.3996242817412725e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -5.678426358599646e-05;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
              result[0] += 3.323261953856542e-05;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002091500000000000477) ) ) {
                  result[0] += -4.8413362798769954e-05;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01660200000000000217) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01009750000000000057) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004748500000000000117) ) ) {
                        result[0] += -5.3996242817412725e-05;
                      } else {
                        result[0] += -5.236663205229745e-05;
                      }
                    } else {
                      result[0] += -5.3996242817412725e-05;
                    }
                  } else {
                    result[0] += -5.835955992441601e-05;
                  }
                }
              } else {
                result[0] += 4.425451360526951e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -5.3996242817412725e-05;
                    } else {
                      result[0] += -5.3996242817412725e-05;
                    }
                  } else {
                    result[0] += -5.3996242817412725e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -5.3996242817412725e-05;
                  } else {
                    result[0] += -5.3996242817412725e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -5.3996242817412725e-05;
                        } else {
                          result[0] += -5.3996242817412725e-05;
                        }
                      } else {
                        result[0] += -5.3996242817412725e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -5.3996242817412725e-05;
                          } else {
                            result[0] += -5.3996242817412725e-05;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -5.3996242817412725e-05;
                            } else {
                              result[0] += -5.3996242817412725e-05;
                            }
                          } else {
                            result[0] += -5.3996242817412725e-05;
                          }
                        }
                      } else {
                        result[0] += -5.3996242817412725e-05;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -5.3996242817412725e-05;
                      } else {
                        result[0] += -5.3996242817412725e-05;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -5.3996242817412725e-05;
                      } else {
                        result[0] += -5.3996242817412725e-05;
                      }
                    }
                  }
                } else {
                  result[0] += -5.3996242817412725e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -5.3996242817412725e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -5.3996242817412725e-05;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -5.3996242817412725e-05;
                    } else {
                      result[0] += -5.3996242817412725e-05;
                    }
                  }
                } else {
                  result[0] += -5.3996242817412725e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -5.3996242817412725e-05;
              } else {
                result[0] += 2.6572525730812654e-06;
              }
            } else {
              result[0] += -5.3996242817412725e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
            result[0] += -5.705684562221836e-05;
          } else {
            result[0] += 1.0673602644406371e-06;
          }
        } else {
          result[0] += 5.352748052598777e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4850000000000000422) ) ) {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.25500000000000006) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04215400000000000397) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03500000000000001027) ) ) {
            result[0] += -1.6249772183019535e-05;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0009565000000000001019) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3550000000000000377) ) ) {
                result[0] += -8.484526010919702e-06;
              } else {
                result[0] += -0.000913342531752143;
              }
            } else {
              result[0] += 0.0005845680039203494;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.051391296366422923) ) ) {
            result[0] += 0.0008742662980994771;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8022705390703518402) ) ) {
              result[0] += -0.001214883946562504;
            } else {
              result[0] += 0.0005255448635887304;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7273815826884423297) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01626400000000000415) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += 0.001122057163182384;
              } else {
                result[0] += 5.053388300220834e-05;
              }
            } else {
              result[0] += 0.0018872750985279745;
            }
          } else {
            result[0] += 0.002733546968639366;
          }
        } else {
          result[0] += 0.0002990202885117248;
        }
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6650000000000001465) ) ) {
        result[0] += 0.0033154063038434915;
      } else {
        result[0] += 0.00911713090555596;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -5.146362494142259e-05;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -5.146362494142259e-05;
                  } else {
                    result[0] += -5.146362494142259e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -5.146362494142259e-05;
                    } else {
                      result[0] += -5.146362494142259e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -5.146362494142259e-05;
                    } else {
                      result[0] += -5.146362494142259e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -5.4120877514503854e-05;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.709112113944723732) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
                result[0] += 3.167389022856594e-05;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5131783528140704265) ) ) {
                  result[0] += -5.5622286792296715e-05;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5694467910050252657) ) ) {
                    result[0] += 9.127918591932561e-05;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4364163272837385255) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6169593235427136557) ) ) {
                        result[0] += -8.635350507048739e-05;
                      } else {
                        result[0] += -5.146362494142259e-05;
                      }
                    } else {
                      result[0] += 4.217881784567841e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -5.146362494142259e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -5.146362494142259e-05;
                    } else {
                      result[0] += -5.146362494142259e-05;
                    }
                  } else {
                    result[0] += -5.146362494142259e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -5.146362494142259e-05;
                  } else {
                    result[0] += -5.146362494142259e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -5.146362494142259e-05;
                        } else {
                          result[0] += -5.146362494142259e-05;
                        }
                      } else {
                        result[0] += -5.146362494142259e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -5.146362494142259e-05;
                          } else {
                            result[0] += -5.146362494142259e-05;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -5.146362494142259e-05;
                            } else {
                              result[0] += -5.146362494142259e-05;
                            }
                          } else {
                            result[0] += -5.146362494142259e-05;
                          }
                        }
                      } else {
                        result[0] += -5.146362494142259e-05;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -5.146362494142259e-05;
                      } else {
                        result[0] += -5.146362494142259e-05;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -5.146362494142259e-05;
                      } else {
                        result[0] += -5.146362494142259e-05;
                      }
                    }
                  }
                } else {
                  result[0] += -5.146362494142259e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -5.146362494142259e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -5.146362494142259e-05;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -5.146362494142259e-05;
                    } else {
                      result[0] += -5.146362494142259e-05;
                    }
                  }
                } else {
                  result[0] += -5.146362494142259e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -5.146362494142259e-05;
              } else {
                result[0] += 2.5326178759901233e-06;
              }
            } else {
              result[0] += -5.146362494142259e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7472528898492464267) ) ) {
              result[0] += -5.43806744734391e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8066186623115578769) ) ) {
                result[0] += -4.2666307459900294e-05;
              } else {
                result[0] += -5.7819378546557907e-05;
              }
            }
          } else {
            result[0] += 1.0172972314443643e-06;
          }
        } else {
          result[0] += 5.10168492864171e-06;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5250000000000001332) ) ) {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.25500000000000006) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02741500000000000534) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4795216591959799435) ) ) {
            result[0] += 0.0007441476588048693;
          } else {
            result[0] += 2.605037808708439e-06;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.527988611169282529) ) ) {
            result[0] += 0.0017022590770675238;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03500000000000001027) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05256900000000001155) ) ) {
                result[0] += -0.0003655447243259328;
              } else {
                result[0] += 0.00021511817697315378;
              }
            } else {
              result[0] += 0.0004892760866256355;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8299222285691966183) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2650000000000000688) ) ) {
              result[0] += -0.0004800336314993061;
            } else {
              result[0] += 0.0014301126587306385;
            }
          } else {
            result[0] += 0.002011334744451766;
          }
        } else {
          result[0] += 0.00044257259433389283;
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
        result[0] += 0.003876450295459198;
      } else {
        result[0] += 0.009193088791326343;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -4.904979594723436e-05;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -4.904979594723436e-05;
                  } else {
                    result[0] += -4.904979594723436e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -4.904979594723436e-05;
                    } else {
                      result[0] += -4.904979594723436e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -4.904979594723436e-05;
                    } else {
                      result[0] += -4.904979594723436e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -5.1582413823224516e-05;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
              result[0] += 3.0188270926010582e-05;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002091500000000000477) ) ) {
                  result[0] += -4.356297560594943e-05;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01660200000000000217) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01009750000000000057) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004748500000000000117) ) ) {
                        result[0] += -4.904979594723436e-05;
                      } else {
                        result[0] += -5.0746667147126455e-05;
                      }
                    } else {
                      result[0] += -4.904979594723436e-05;
                    }
                  } else {
                    result[0] += -5.301340160911889e-05;
                  }
                }
              } else {
                result[0] += 4.0200479678237534e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -4.904979594723436e-05;
                    } else {
                      result[0] += -4.904979594723436e-05;
                    }
                  } else {
                    result[0] += -4.904979594723436e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -4.904979594723436e-05;
                  } else {
                    result[0] += -4.904979594723436e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -4.904979594723436e-05;
                        } else {
                          result[0] += -4.904979594723436e-05;
                        }
                      } else {
                        result[0] += -4.904979594723436e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -4.904979594723436e-05;
                          } else {
                            result[0] += -4.904979594723436e-05;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -4.904979594723436e-05;
                            } else {
                              result[0] += -4.904979594723436e-05;
                            }
                          } else {
                            result[0] += -4.904979594723436e-05;
                          }
                        }
                      } else {
                        result[0] += -4.904979594723436e-05;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -4.904979594723436e-05;
                      } else {
                        result[0] += -4.904979594723436e-05;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -4.904979594723436e-05;
                      } else {
                        result[0] += -4.904979594723436e-05;
                      }
                    }
                  }
                } else {
                  result[0] += -4.904979594723436e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -4.904979594723436e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -4.904979594723436e-05;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -4.904979594723436e-05;
                    } else {
                      result[0] += -4.904979594723436e-05;
                    }
                  }
                } else {
                  result[0] += -4.904979594723436e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -4.904979594723436e-05;
              } else {
                result[0] += 2.4138289941882455e-06;
              }
            } else {
              result[0] += -4.904979594723436e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
            result[0] += -5.1830025370953436e-05;
          } else {
            result[0] += 9.695823346456162e-07;
          }
        } else {
          result[0] += 4.862397567637001e-06;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5350000000000001421) ) ) {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2050000000000000433) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04215400000000000397) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4292508528894472541) ) ) {
            result[0] += 0.0011614180596471908;
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4188836135812591954) ) ) {
              result[0] += -0.0009553900649758165;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5012509875628141653) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  result[0] += -1.826616665383625e-05;
                } else {
                  result[0] += 0.0014391716968250009;
                }
              } else {
                result[0] += 2.5022015013929254e-07;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6754021834779359024) ) ) {
            result[0] += 0.0016417740706960394;
          } else {
            result[0] += 7.990368179922516e-05;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2450000000000000233) ) ) {
            result[0] += -0.0004901054925711875;
          } else {
            result[0] += 0.0012955523348585696;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8299222285691966183) ) ) {
            result[0] += 0.0018240230765004702;
          } else {
            result[0] += 0.0004450087419574213;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8150000000000000577) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003977500000000001) ) ) {
          result[0] += 0.004176078844704777;
        } else {
          result[0] += 0.003157955509752873;
        }
      } else {
        result[0] += 0.013417711848861667;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -4.6749184209308515e-05;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -4.6749184209308515e-05;
                  } else {
                    result[0] += -4.6749184209308515e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -4.6749184209308515e-05;
                    } else {
                      result[0] += -4.6749184209308515e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -4.6749184209308515e-05;
                    } else {
                      result[0] += -4.6749184209308515e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -4.9163013203496764e-05;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
              result[0] += 2.877233250875845e-05;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002091500000000000477) ) ) {
                  result[0] += -4.151971546423878e-05;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01660200000000000217) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01009750000000000057) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004748500000000000117) ) ) {
                        result[0] += -4.6749184209308515e-05;
                      } else {
                        result[0] += -4.836646605057372e-05;
                      }
                    } else {
                      result[0] += -4.6749184209308515e-05;
                    }
                  } else {
                    result[0] += -5.0526882518590585e-05;
                  }
                }
              } else {
                result[0] += 3.831493268192591e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -4.6749184209308515e-05;
                    } else {
                      result[0] += -4.6749184209308515e-05;
                    }
                  } else {
                    result[0] += -4.6749184209308515e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -4.6749184209308515e-05;
                  } else {
                    result[0] += -4.6749184209308515e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -4.6749184209308515e-05;
                        } else {
                          result[0] += -4.6749184209308515e-05;
                        }
                      } else {
                        result[0] += -4.6749184209308515e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -4.6749184209308515e-05;
                          } else {
                            result[0] += -4.6749184209308515e-05;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -4.6749184209308515e-05;
                            } else {
                              result[0] += -4.6749184209308515e-05;
                            }
                          } else {
                            result[0] += -4.6749184209308515e-05;
                          }
                        }
                      } else {
                        result[0] += -4.6749184209308515e-05;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -4.6749184209308515e-05;
                      } else {
                        result[0] += -4.6749184209308515e-05;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -4.6749184209308515e-05;
                      } else {
                        result[0] += -4.6749184209308515e-05;
                      }
                    }
                  }
                } else {
                  result[0] += -4.6749184209308515e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -4.6749184209308515e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -4.6749184209308515e-05;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -4.6749184209308515e-05;
                    } else {
                      result[0] += -4.6749184209308515e-05;
                    }
                  }
                } else {
                  result[0] += -4.6749184209308515e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -4.6749184209308515e-05;
              } else {
                result[0] += 2.300611737925836e-06;
              }
            } else {
              result[0] += -4.6749184209308515e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7472528898492464267) ) ) {
            result[0] += -4.939901087960501e-05;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8066186623115578769) ) ) {
              result[0] += -4.487941549313018e-05;
            } else {
              result[0] += -5.2676427371377276e-05;
            }
          }
        } else {
          result[0] += 6.989262030232467e-06;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8850000000000001199) ) ) {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04215400000000000397) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4795216591959799435) ) ) {
            result[0] += 0.0008589606862650232;
          } else {
            result[0] += 6.7313927299577146e-06;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8440161800932387548) ) ) {
            result[0] += 0.0016133634480448873;
          } else {
            result[0] += 0.00011666407385168688;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2750000000000000777) ) ) {
            result[0] += -0.0008768681649504476;
          } else {
            result[0] += 0.0013965302958397275;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9993516786272610419) ) ) {
            result[0] += 0.0021279131168921136;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02804500000000000395) ) ) {
              result[0] += 0.0007903733308435874;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
                result[0] += 0.001751512127118404;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1414455000000000295) ) ) {
                  result[0] += -0.0032071973840626074;
                } else {
                  result[0] += 0.0014016253259388834;
                }
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8350000000000000755) ) ) {
        result[0] += 0.004110039923904017;
      } else {
        result[0] += 0.013337168936949882;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -4.4556479431370355e-05;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -4.4556479431370355e-05;
                  } else {
                    result[0] += -4.4556479431370355e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -4.4556479431370355e-05;
                    } else {
                      result[0] += -4.4556479431370355e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -4.4556479431370355e-05;
                    } else {
                      result[0] += -4.4556479431370355e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -4.685709116929622e-05;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.709112113944723732) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
                result[0] += 2.742280669282309e-05;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5131783528140704265) ) ) {
                  result[0] += -4.8156990111125355e-05;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5694467910050252657) ) ) {
                    result[0] += 8.331520893849533e-05;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4364163272837385255) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6169593235427136557) ) ) {
                        result[0] += -8.043552920359703e-05;
                      } else {
                        result[0] += -4.4556479431370355e-05;
                      }
                    } else {
                      result[0] += 3.651782461728273e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -4.4556479431370355e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -4.4556479431370355e-05;
                    } else {
                      result[0] += -4.4556479431370355e-05;
                    }
                  } else {
                    result[0] += -4.4556479431370355e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -4.4556479431370355e-05;
                  } else {
                    result[0] += -4.4556479431370355e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -4.4556479431370355e-05;
                        } else {
                          result[0] += -4.4556479431370355e-05;
                        }
                      } else {
                        result[0] += -4.4556479431370355e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -4.4556479431370355e-05;
                          } else {
                            result[0] += -4.4556479431370355e-05;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -4.4556479431370355e-05;
                            } else {
                              result[0] += -4.4556479431370355e-05;
                            }
                          } else {
                            result[0] += -4.4556479431370355e-05;
                          }
                        }
                      } else {
                        result[0] += -4.4556479431370355e-05;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -4.4556479431370355e-05;
                      } else {
                        result[0] += -4.4556479431370355e-05;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -4.4556479431370355e-05;
                      } else {
                        result[0] += -4.4556479431370355e-05;
                      }
                    }
                  }
                } else {
                  result[0] += -4.4556479431370355e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -4.4556479431370355e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -4.4556479431370355e-05;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -4.4556479431370355e-05;
                    } else {
                      result[0] += -4.4556479431370355e-05;
                    }
                  }
                } else {
                  result[0] += -4.4556479431370355e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -4.4556479431370355e-05;
              } else {
                result[0] += 2.1927047779381394e-06;
              }
            } else {
              result[0] += -4.4556479431370355e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
            result[0] += -4.708201970610852e-05;
          } else {
            result[0] += 5.962839261086492e-07;
          }
        } else {
          result[0] += 6.951324817471083e-06;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8850000000000001199) ) ) {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04215400000000000397) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4795216591959799435) ) ) {
            result[0] += 0.0008186723425711161;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7593447680904524821) ) ) {
              result[0] += 3.34015189231602e-05;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.786764172562814168) ) ) {
                result[0] += -0.0003743326400590287;
              } else {
                result[0] += 7.71456021560582e-06;
              }
            }
          }
        } else {
          result[0] += 0.000611639506902955;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2750000000000000777) ) ) {
            result[0] += -0.0008357398961383071;
          } else {
            result[0] += 0.0013310280051791468;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9993516786272610419) ) ) {
            result[0] += 0.0020281063429908584;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02804500000000000395) ) ) {
              result[0] += 0.0007533019806541106;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
                result[0] += 0.0016693599125994513;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1414455000000000295) ) ) {
                  result[0] += -0.0030567682985765637;
                } else {
                  result[0] += 0.00133588406005272;
                }
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9150000000000001465) ) ) {
        result[0] += 0.004413753282731505;
      } else {
        result[0] += 0.014977027550404445;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -4.246662038912816e-05;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -4.246662038912816e-05;
                  } else {
                    result[0] += -4.246662038912816e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -4.246662038912816e-05;
                    } else {
                      result[0] += -4.246662038912816e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -4.246662038912816e-05;
                    } else {
                      result[0] += -4.246662038912816e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -4.465932516706635e-05;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
              result[0] += 2.613657848848462e-05;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002091500000000000477) ) ) {
                  result[0] += -3.733888742416862e-05;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01660200000000000217) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01009750000000000057) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004748500000000000117) ) ) {
                        result[0] += -4.246662038912816e-05;
                      } else {
                        result[0] += -4.692242836008605e-05;
                      }
                    } else {
                      result[0] += -4.246662038912816e-05;
                    }
                  } else {
                    result[0] += -4.5898254176076454e-05;
                  }
                }
              } else {
                result[0] += 3.480500738052157e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -4.246662038912816e-05;
                    } else {
                      result[0] += -4.246662038912816e-05;
                    }
                  } else {
                    result[0] += -4.246662038912816e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -4.246662038912816e-05;
                  } else {
                    result[0] += -4.246662038912816e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -4.246662038912816e-05;
                        } else {
                          result[0] += -4.246662038912816e-05;
                        }
                      } else {
                        result[0] += -4.246662038912816e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -4.246662038912816e-05;
                          } else {
                            result[0] += -4.246662038912816e-05;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -4.246662038912816e-05;
                            } else {
                              result[0] += -4.246662038912816e-05;
                            }
                          } else {
                            result[0] += -4.246662038912816e-05;
                          }
                        }
                      } else {
                        result[0] += -4.246662038912816e-05;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -4.246662038912816e-05;
                      } else {
                        result[0] += -4.246662038912816e-05;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -4.246662038912816e-05;
                      } else {
                        result[0] += -4.246662038912816e-05;
                      }
                    }
                  }
                } else {
                  result[0] += -4.246662038912816e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -4.246662038912816e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -4.246662038912816e-05;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -4.246662038912816e-05;
                    } else {
                      result[0] += -4.246662038912816e-05;
                    }
                  }
                } else {
                  result[0] += -4.246662038912816e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -4.246662038912816e-05;
              } else {
                result[0] += 2.0898590422421303e-06;
              }
            } else {
              result[0] += -4.246662038912816e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7536081807788946874) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03500000000000001027) ) ) {
            result[0] += 5.683160666497091e-07;
          } else {
            result[0] += 0.0006229015822813969;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8066186623115578769) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7974125133417085953) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7664523331407036011) ) ) {
                  result[0] += -0.00023298624685242188;
                } else {
                  result[0] += -4.056609362970243e-05;
                }
              } else {
                result[0] += -0.00021105551492108277;
              }
            } else {
              result[0] += 0.0001439286002385315;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8715165423366836306) ) ) {
              result[0] += 4.7006513200857e-05;
            } else {
              result[0] += -4.7997397624737554e-05;
            }
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8850000000000001199) ) ) {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09500000000000001499) ) ) {
        result[0] += -8.850772041260932e-07;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.08500000000000000611) ) ) {
            result[0] += -0.000648876056165635;
          } else {
            result[0] += 0.00035559455947011773;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8299222285691966183) ) ) {
            result[0] += 0.001500025596150938;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6902798926130654378) ) ) {
              result[0] += -0.0034648218471895337;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1850000000000000255) ) ) {
                result[0] += 0.0016551725240668755;
              } else {
                result[0] += 0.00012385838821185908;
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8350000000000000755) ) ) {
        result[0] += 0.003710243383997231;
      } else {
        result[0] += 0.012398406338594145;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -4.0474783247901926e-05;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -4.0474783247901926e-05;
                  } else {
                    result[0] += -4.0474783247901926e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -4.0474783247901926e-05;
                    } else {
                      result[0] += -4.0474783247901926e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -4.0474783247901926e-05;
                    } else {
                      result[0] += -4.0474783247901926e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -4.256464229014414e-05;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
              result[0] += 2.4910679010237817e-05;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002091500000000000477) ) ) {
                  result[0] += -3.558755939047927e-05;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01660200000000000217) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01009750000000000057) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004748500000000000117) ) ) {
                        result[0] += -4.0474783247901926e-05;
                      } else {
                        result[0] += -4.472159780875556e-05;
                      }
                    } else {
                      result[0] += -4.0474783247901926e-05;
                    }
                  } else {
                    result[0] += -4.374546107533902e-05;
                  }
                }
              } else {
                result[0] += 3.3172527428834026e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -4.0474783247901926e-05;
                    } else {
                      result[0] += -4.0474783247901926e-05;
                    }
                  } else {
                    result[0] += -4.0474783247901926e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -4.0474783247901926e-05;
                  } else {
                    result[0] += -4.0474783247901926e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -4.0474783247901926e-05;
                        } else {
                          result[0] += -4.0474783247901926e-05;
                        }
                      } else {
                        result[0] += -4.0474783247901926e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -4.0474783247901926e-05;
                          } else {
                            result[0] += -4.0474783247901926e-05;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -4.0474783247901926e-05;
                            } else {
                              result[0] += -4.0474783247901926e-05;
                            }
                          } else {
                            result[0] += -4.0474783247901926e-05;
                          }
                        }
                      } else {
                        result[0] += -4.0474783247901926e-05;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -4.0474783247901926e-05;
                      } else {
                        result[0] += -4.0474783247901926e-05;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -4.0474783247901926e-05;
                      } else {
                        result[0] += -4.0474783247901926e-05;
                      }
                    }
                  }
                } else {
                  result[0] += -4.0474783247901926e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -4.0474783247901926e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -4.0474783247901926e-05;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -4.0474783247901926e-05;
                    } else {
                      result[0] += -4.0474783247901926e-05;
                    }
                  }
                } else {
                  result[0] += -4.0474783247901926e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -4.0474783247901926e-05;
              } else {
                result[0] += 1.991837141226174e-06;
              }
            } else {
              result[0] += -4.0474783247901926e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7472528898492464267) ) ) {
              result[0] += -4.4900359813324054e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8066186623115578769) ) ) {
                result[0] += -2.369447716711335e-05;
              } else {
                result[0] += -4.574614715095059e-05;
              }
            }
          } else {
            result[0] += -2.7300738465084106e-05;
          }
        } else {
          result[0] += 9.717688128682032e-06;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5350000000000001421) ) ) {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09500000000000001499) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4292508528894472541) ) ) {
          result[0] += 0.0010355947985645083;
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4421126575628140931) ) ) {
            result[0] += -0.0009315279226857944;
          } else {
            result[0] += -2.420980109960219e-06;
          }
        }
      } else {
        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.05751864358971629093) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
            result[0] += 0.00014012859322827607;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3684892717336683554) ) ) {
              result[0] += 0.0008584393217097603;
            } else {
              result[0] += 0.002059498339148896;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04215400000000000397) ) ) {
              result[0] += 0.00042562792517679193;
            } else {
              result[0] += 0.0017187308021541607;
            }
          } else {
            result[0] += -0.002033464368700717;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.7450000000000001066) ) ) {
          result[0] += 0.002338414706386051;
        } else {
          result[0] += 0.005605858310222473;
        }
      } else {
        result[0] += 0.007621974278584466;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -3.857637042819726e-05;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -3.857637042819726e-05;
                  } else {
                    result[0] += -3.857637042819726e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -3.857637042819726e-05;
                    } else {
                      result[0] += -3.857637042819726e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -3.857637042819726e-05;
                    } else {
                      result[0] += -3.857637042819726e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -4.056820756942352e-05;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.709112113944723732) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
                result[0] += 2.3742278623979158e-05;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5131783528140704265) ) ) {
                  result[0] += -4.169364170917552e-05;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5694467910050252657) ) ) {
                    result[0] += 7.621903543955253e-05;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4364163272837385255) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6169593235427136557) ) ) {
                        result[0] += -7.504579753471799e-05;
                      } else {
                        result[0] += -3.857637042819726e-05;
                      }
                    } else {
                      result[0] += 3.161661665478019e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -3.857637042819726e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -3.857637042819726e-05;
                    } else {
                      result[0] += -3.857637042819726e-05;
                    }
                  } else {
                    result[0] += -3.857637042819726e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -3.857637042819726e-05;
                  } else {
                    result[0] += -3.857637042819726e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -3.857637042819726e-05;
                        } else {
                          result[0] += -3.857637042819726e-05;
                        }
                      } else {
                        result[0] += -3.857637042819726e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -3.857637042819726e-05;
                          } else {
                            result[0] += -3.857637042819726e-05;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -3.857637042819726e-05;
                            } else {
                              result[0] += -3.857637042819726e-05;
                            }
                          } else {
                            result[0] += -3.857637042819726e-05;
                          }
                        }
                      } else {
                        result[0] += -3.857637042819726e-05;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -3.857637042819726e-05;
                      } else {
                        result[0] += -3.857637042819726e-05;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -3.857637042819726e-05;
                      } else {
                        result[0] += -3.857637042819726e-05;
                      }
                    }
                  }
                } else {
                  result[0] += -3.857637042819726e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -3.857637042819726e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -3.857637042819726e-05;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -3.857637042819726e-05;
                    } else {
                      result[0] += -3.857637042819726e-05;
                    }
                  }
                } else {
                  result[0] += -3.857637042819726e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -3.857637042819726e-05;
              } else {
                result[0] += 1.8984128197046197e-06;
              }
            } else {
              result[0] += -3.857637042819726e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -4.279437154510065e-05;
          } else {
            result[0] += -2.602023569939715e-05;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.387204325943492078) ) ) {
            result[0] += 2.208533674712218e-05;
          } else {
            result[0] += -2.2029585893285417e-05;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8850000000000001199) ) ) {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04625700000000000645) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4795216591959799435) ) ) {
            result[0] += 0.0006733628278084016;
          } else {
            result[0] += 1.8223667634258076e-06;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8440161800932387548) ) ) {
            result[0] += 0.0018375785582864452;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7418777389447237525) ) ) {
              result[0] += -0.0012208271220503328;
            } else {
              result[0] += 0.0004026336667720498;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2750000000000000777) ) ) {
            result[0] += -0.0008280159249084726;
          } else {
            result[0] += 0.0012009266887109528;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9993516786272610419) ) ) {
            result[0] += 0.0018146093930771917;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7894192122613066243) ) ) {
              result[0] += -0.000792861844401436;
            } else {
              result[0] += 0.0009501069687316427;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4950000000000000511) ) ) {
          result[0] += -0.0001183973698333689;
        } else {
          result[0] += 0.003729744290542131;
        }
      } else {
        result[0] += 0.008645162744995853;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -3.676699999352392e-05;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -3.676699999352392e-05;
                  } else {
                    result[0] += -3.676699999352392e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -3.676699999352392e-05;
                    } else {
                      result[0] += -3.676699999352392e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -3.676699999352392e-05;
                    } else {
                      result[0] += -3.676699999352392e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -3.8665412813228605e-05;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
              result[0] += 2.2628680415615683e-05;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002091500000000000477) ) ) {
                  result[0] += -3.198472518128008e-05;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01660200000000000217) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01009750000000000057) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004748500000000000117) ) ) {
                        result[0] += -3.676699999352392e-05;
                      } else {
                        result[0] += -4.343367665431753e-05;
                      }
                    } else {
                      result[0] += -3.676699999352392e-05;
                    }
                  } else {
                    result[0] += -3.973806004648744e-05;
                  }
                }
              } else {
                result[0] += 3.013368368870345e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -3.676699999352392e-05;
                    } else {
                      result[0] += -3.676699999352392e-05;
                    }
                  } else {
                    result[0] += -3.676699999352392e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -3.676699999352392e-05;
                  } else {
                    result[0] += -3.676699999352392e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -3.676699999352392e-05;
                        } else {
                          result[0] += -3.676699999352392e-05;
                        }
                      } else {
                        result[0] += -3.676699999352392e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -3.676699999352392e-05;
                          } else {
                            result[0] += -3.676699999352392e-05;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -3.676699999352392e-05;
                            } else {
                              result[0] += -3.676699999352392e-05;
                            }
                          } else {
                            result[0] += -3.676699999352392e-05;
                          }
                        }
                      } else {
                        result[0] += -3.676699999352392e-05;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -3.676699999352392e-05;
                      } else {
                        result[0] += -3.676699999352392e-05;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -3.676699999352392e-05;
                      } else {
                        result[0] += -3.676699999352392e-05;
                      }
                    }
                  }
                } else {
                  result[0] += -3.676699999352392e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -3.676699999352392e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -3.676699999352392e-05;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -3.676699999352392e-05;
                    } else {
                      result[0] += -3.676699999352392e-05;
                    }
                  }
                } else {
                  result[0] += -3.676699999352392e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -3.676699999352392e-05;
              } else {
                result[0] += 1.8093704346733307e-06;
              }
            } else {
              result[0] += -3.676699999352392e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01314200000000000264) ) ) {
            result[0] += -4.0787161696567744e-05;
          } else {
            result[0] += 7.205205824846614e-06;
          }
        } else {
          result[0] += 9.099571979820197e-06;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8950000000000001288) ) ) {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02500000000000000486) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0003865000000000000705) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
              result[0] += 1.3309147348195354e-05;
            } else {
              result[0] += -7.779550510533096e-05;
            }
          } else {
            result[0] += -0.00012684386312728033;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02804500000000000395) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4795216591959799435) ) ) {
              result[0] += 0.0009075500658144831;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4839721393467337207) ) ) {
                result[0] += -0.000810285660922105;
              } else {
                result[0] += 4.280688489231711e-05;
              }
            }
          } else {
            result[0] += 0.0010404645102083233;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2750000000000000777) ) ) {
            result[0] += -0.0007891790017521927;
          } else {
            result[0] += 0.00116174114105723;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.992027305872230758) ) ) {
            result[0] += 0.0017366470632175159;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02804500000000000395) ) ) {
              result[0] += 0.0007820743042040502;
            } else {
              result[0] += -0.0008035492283460562;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9150000000000001465) ) ) {
        result[0] += 0.0035587767499978924;
      } else {
        result[0] += 0.012930034102709964;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -3.5042495535963785e-05;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -3.5042495535963785e-05;
                  } else {
                    result[0] += -3.5042495535963785e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -3.5042495535963785e-05;
                    } else {
                      result[0] += -3.5042495535963785e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -3.5042495535963785e-05;
                    } else {
                      result[0] += -3.5042495535963785e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -3.685186597063715e-05;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
              result[0] += 2.1567313966019367e-05;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002091500000000000477) ) ) {
                  result[0] += -3.0484526602155628e-05;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01660200000000000217) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01009750000000000057) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004748500000000000117) ) ) {
                        result[0] += -3.5042495535963785e-05;
                      } else {
                        result[0] += -4.139648109819954e-05;
                      }
                    } else {
                      result[0] += -3.5042495535963785e-05;
                    }
                  } else {
                    result[0] += -3.7874202193058266e-05;
                  }
                }
              } else {
                result[0] += 2.872030560909317e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -3.5042495535963785e-05;
                    } else {
                      result[0] += -3.5042495535963785e-05;
                    }
                  } else {
                    result[0] += -3.5042495535963785e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -3.5042495535963785e-05;
                  } else {
                    result[0] += -3.5042495535963785e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -3.5042495535963785e-05;
                        } else {
                          result[0] += -3.5042495535963785e-05;
                        }
                      } else {
                        result[0] += -3.5042495535963785e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -3.5042495535963785e-05;
                          } else {
                            result[0] += -3.5042495535963785e-05;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -3.5042495535963785e-05;
                            } else {
                              result[0] += -3.5042495535963785e-05;
                            }
                          } else {
                            result[0] += -3.5042495535963785e-05;
                          }
                        }
                      } else {
                        result[0] += -3.5042495535963785e-05;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -3.5042495535963785e-05;
                      } else {
                        result[0] += -3.5042495535963785e-05;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -3.5042495535963785e-05;
                      } else {
                        result[0] += -3.5042495535963785e-05;
                      }
                    }
                  }
                } else {
                  result[0] += -3.5042495535963785e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -3.5042495535963785e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -3.5042495535963785e-05;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -3.5042495535963785e-05;
                    } else {
                      result[0] += -3.5042495535963785e-05;
                    }
                  }
                } else {
                  result[0] += -3.5042495535963785e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -3.5042495535963785e-05;
              } else {
                result[0] += 1.7245044575601534e-06;
              }
            } else {
              result[0] += -3.5042495535963785e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7568047583165830039) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0003425000000000000852) ) ) {
            result[0] += -3.8874097204785813e-05;
          } else {
            result[0] += 0.00034016796720943624;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8066186623115578769) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7974125133417085953) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7664523331407036011) ) ) {
                  result[0] += -0.00021998421169811455;
                } else {
                  result[0] += -3.363176753634855e-05;
                }
              } else {
                result[0] += -0.00019908210992370453;
              }
            } else {
              result[0] += 0.0001392519742553124;
            }
          } else {
            result[0] += -1.1989886189356108e-05;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8950000000000001288) ) ) {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0650000000000000161) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
            result[0] += -2.3704402761590503e-05;
          } else {
            result[0] += 6.509879591623211e-05;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02919300000000000367) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1701831610694422292) ) ) {
              result[0] += 0.0008890676716680783;
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1185261981962025396) ) ) {
                result[0] += -0.000977344617192578;
              } else {
                result[0] += 0.00011827171689025737;
              }
            }
          } else {
            result[0] += 0.0013838377925873958;
          }
        }
      } else {
        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.0491948752242571466) ) ) {
          result[0] += 0.0020281709326300406;
        } else {
          result[0] += 0.000970279760755251;
        }
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9150000000000001465) ) ) {
        result[0] += 0.0033918573285081394;
      } else {
        result[0] += 0.01232356902667832;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -3.339887653614207e-05;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -3.339887653614207e-05;
                  } else {
                    result[0] += -3.339887653614207e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -3.339887653614207e-05;
                    } else {
                      result[0] += -3.339887653614207e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -3.339887653614207e-05;
                    } else {
                      result[0] += -3.339887653614207e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -3.5123380993702227e-05;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.709112113944723732) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
                result[0] += 2.0555729417958565e-05;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5131783528140704265) ) ) {
                  result[0] += -3.609776597253532e-05;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5694467910050252657) ) ) {
                    result[0] += 6.988362506348922e-05;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4364163272837385255) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6169593235427136557) ) ) {
                        result[0] += -6.952571931990286e-05;
                      } else {
                        result[0] += -3.339887653614207e-05;
                      }
                    } else {
                      result[0] += 2.7373220041761213e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -3.339887653614207e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -3.339887653614207e-05;
                    } else {
                      result[0] += -3.339887653614207e-05;
                    }
                  } else {
                    result[0] += -3.339887653614207e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -3.339887653614207e-05;
                  } else {
                    result[0] += -3.339887653614207e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -3.339887653614207e-05;
                        } else {
                          result[0] += -3.339887653614207e-05;
                        }
                      } else {
                        result[0] += -3.339887653614207e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -3.339887653614207e-05;
                          } else {
                            result[0] += -3.339887653614207e-05;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -3.339887653614207e-05;
                            } else {
                              result[0] += -3.339887653614207e-05;
                            }
                          } else {
                            result[0] += -3.339887653614207e-05;
                          }
                        }
                      } else {
                        result[0] += -3.339887653614207e-05;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -3.339887653614207e-05;
                      } else {
                        result[0] += -3.339887653614207e-05;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -3.339887653614207e-05;
                      } else {
                        result[0] += -3.339887653614207e-05;
                      }
                    }
                  }
                } else {
                  result[0] += -3.339887653614207e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -3.339887653614207e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -3.339887653614207e-05;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -3.339887653614207e-05;
                    } else {
                      result[0] += -3.339887653614207e-05;
                    }
                  }
                } else {
                  result[0] += -3.339887653614207e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -3.339887653614207e-05;
              } else {
                result[0] += 1.643618999821708e-06;
              }
            } else {
              result[0] += -3.339887653614207e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02562400000000000441) ) ) {
            result[0] += -3.705076231412062e-05;
          } else {
            result[0] += 0.0002622763371761636;
          }
        } else {
          result[0] += 1.0496104236496949e-05;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8950000000000001288) ) ) {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02804500000000000395) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4795216591959799435) ) ) {
            result[0] += 0.0005149776062593854;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4839721393467337207) ) ) {
              result[0] += -0.0007351931612039432;
            } else {
              result[0] += 9.907365244787121e-07;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.527988611169282529) ) ) {
            result[0] += 0.0013967287981961245;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7013523401005025137) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2150000000000000244) ) ) {
                result[0] += -0.0005996308089815925;
              } else {
                result[0] += 0.0009710097871116362;
              }
            } else {
              result[0] += 0.00019620025799552251;
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.0491948752242571466) ) ) {
          result[0] += 0.001933042425690926;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2750000000000000777) ) ) {
              result[0] += -0.001249211344420169;
            } else {
              result[0] += 0.0004949128946115824;
            }
          } else {
            result[0] += 0.001095462684627424;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9450000000000000622) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4950000000000000511) ) ) {
          result[0] += -0.00043053014690460105;
        } else {
          result[0] += 0.0034828712242476654;
        }
      } else {
        result[0] += 0.012914171131245928;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -3.1832349175350536e-05;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -3.1832349175350536e-05;
                  } else {
                    result[0] += -3.1832349175350536e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -3.1832349175350536e-05;
                    } else {
                      result[0] += -3.1832349175350536e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -3.1832349175350536e-05;
                    } else {
                      result[0] += -3.1832349175350536e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -3.347596817517226e-05;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
              result[0] += 1.9591591821311754e-05;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002091500000000000477) ) ) {
                  result[0] += -2.7380566087879682e-05;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01660200000000000217) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01009750000000000057) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004748500000000000117) ) ) {
                        result[0] += -3.1832349175350536e-05;
                      } else {
                        result[0] += -4.024717645310561e-05;
                      }
                    } else {
                      result[0] += -3.1832349175350536e-05;
                    }
                  } else {
                    result[0] += -3.44046509961009e-05;
                  }
                }
              } else {
                result[0] += 2.6089317629595308e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -3.1832349175350536e-05;
                    } else {
                      result[0] += -3.1832349175350536e-05;
                    }
                  } else {
                    result[0] += -3.1832349175350536e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -3.1832349175350536e-05;
                  } else {
                    result[0] += -3.1832349175350536e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -3.1832349175350536e-05;
                        } else {
                          result[0] += -3.1832349175350536e-05;
                        }
                      } else {
                        result[0] += -3.1832349175350536e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -3.1832349175350536e-05;
                          } else {
                            result[0] += -3.1832349175350536e-05;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -3.1832349175350536e-05;
                            } else {
                              result[0] += -3.1832349175350536e-05;
                            }
                          } else {
                            result[0] += -3.1832349175350536e-05;
                          }
                        }
                      } else {
                        result[0] += -3.1832349175350536e-05;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -3.1832349175350536e-05;
                      } else {
                        result[0] += -3.1832349175350536e-05;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -3.1832349175350536e-05;
                      } else {
                        result[0] += -3.1832349175350536e-05;
                      }
                    }
                  }
                } else {
                  result[0] += -3.1832349175350536e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -3.1832349175350536e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -3.1832349175350536e-05;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -3.1832349175350536e-05;
                    } else {
                      result[0] += -3.1832349175350536e-05;
                    }
                  }
                } else {
                  result[0] += -3.1832349175350536e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -3.1832349175350536e-05;
              } else {
                result[0] += 1.5665273607915706e-06;
              }
            } else {
              result[0] += -3.1832349175350536e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7536081807788946874) ) ) {
            result[0] += -3.5312948383749466e-05;
          } else {
            result[0] += -3.031650282015655e-05;
          }
        } else {
          result[0] += 1.000379921987763e-05;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8950000000000001288) ) ) {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04625700000000000645) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7593447680904524821) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.05500000000000000722) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04500000000000000527) ) ) {
                result[0] += -2.267845904890029e-05;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.01778816268138619719) ) ) {
                    result[0] += -0.0005581825282352549;
                  } else {
                    result[0] += -4.1032234272276514e-05;
                  }
                } else {
                  result[0] += 0.0014093799324943804;
                }
              }
            } else {
              result[0] += 0.0001779936708678077;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001379500000000000301) ) ) {
              result[0] += 7.863415771795767e-06;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.992027305872230758) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002257500000000000392) ) ) {
                  result[0] += -0.0015863782177664163;
                } else {
                  result[0] += -0.0004231969752632133;
                }
              } else {
                result[0] += -6.129062661853936e-05;
              }
            }
          }
        } else {
          result[0] += 0.0005550241631743271;
        }
      } else {
        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.0491948752242571466) ) ) {
          result[0] += 0.0018423757876637815;
        } else {
          result[0] += 0.0008825920101715811;
        }
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9450000000000000622) ) ) {
        result[0] += 0.0032313194473805123;
      } else {
        result[0] += 0.012308450085594917;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -3.03392975786151e-05;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -3.03392975786151e-05;
                  } else {
                    result[0] += -3.03392975786151e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -3.03392975786151e-05;
                    } else {
                      result[0] += -3.03392975786151e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -3.03392975786151e-05;
                    } else {
                      result[0] += -3.03392975786151e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -3.1905824939406655e-05;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
              result[0] += 1.867267574351096e-05;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002091500000000000477) ) ) {
                  result[0] += -2.6096319119745615e-05;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01660200000000000217) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01009750000000000057) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004748500000000000117) ) ) {
                        result[0] += -3.03392975786151e-05;
                      } else {
                        result[0] += -3.8359439210202594e-05;
                      }
                    } else {
                      result[0] += -3.03392975786151e-05;
                    }
                  } else {
                    result[0] += -3.279094919791157e-05;
                  }
                }
              } else {
                result[0] += 2.486563485550807e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -3.03392975786151e-05;
                    } else {
                      result[0] += -3.03392975786151e-05;
                    }
                  } else {
                    result[0] += -3.03392975786151e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -3.03392975786151e-05;
                  } else {
                    result[0] += -3.03392975786151e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -3.03392975786151e-05;
                        } else {
                          result[0] += -3.03392975786151e-05;
                        }
                      } else {
                        result[0] += -3.03392975786151e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -3.03392975786151e-05;
                          } else {
                            result[0] += -3.03392975786151e-05;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -3.03392975786151e-05;
                            } else {
                              result[0] += -3.03392975786151e-05;
                            }
                          } else {
                            result[0] += -3.03392975786151e-05;
                          }
                        }
                      } else {
                        result[0] += -3.03392975786151e-05;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -3.03392975786151e-05;
                      } else {
                        result[0] += -3.03392975786151e-05;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -3.03392975786151e-05;
                      } else {
                        result[0] += -3.03392975786151e-05;
                      }
                    }
                  }
                } else {
                  result[0] += -3.03392975786151e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -3.03392975786151e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -3.03392975786151e-05;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -3.03392975786151e-05;
                    } else {
                      result[0] += -3.03392975786151e-05;
                    }
                  }
                } else {
                  result[0] += -3.03392975786151e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -3.03392975786151e-05;
              } else {
                result[0] += 1.4930515967354498e-06;
              }
            } else {
              result[0] += -3.03392975786151e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7536081807788946874) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01366150000000000177) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7322719660050253099) ) ) {
                result[0] += -3.365664417323206e-05;
              } else {
                result[0] += 0.0003925017864389363;
              }
            } else {
              result[0] += 0.00048394861063606005;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7673948280402010935) ) ) {
              result[0] += -4.571064276990579e-06;
            } else {
              result[0] += -2.889454986614336e-05;
            }
          }
        } else {
          result[0] += 9.534585078113166e-06;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8950000000000001288) ) ) {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02804500000000000395) ) ) {
          result[0] += 7.494593307289579e-06;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.527988611169282529) ) ) {
            result[0] += 0.001306067477835757;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7013523401005025137) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2150000000000000244) ) ) {
                result[0] += -0.0005868905012371236;
              } else {
                result[0] += 0.0008994333095605775;
              }
            } else {
              result[0] += 0.00018214172383547523;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1196770600947829194) ) ) {
          result[0] += 0.0016749933879137116;
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5126512388693468258) ) ) {
            result[0] += -0.0024555522808989093;
          } else {
            result[0] += 0.0006772880986244059;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9050000000000001377) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4950000000000000511) ) ) {
          result[0] += -0.0005618972324489273;
        } else {
          result[0] += 0.002911500073666571;
        }
      } else {
        result[0] += 0.010961594168790714;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -2.8916275468495137e-05;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -2.8916275468495137e-05;
                  } else {
                    result[0] += -2.8916275468495137e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -2.8916275468495137e-05;
                    } else {
                      result[0] += -2.8916275468495137e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -2.8916275468495137e-05;
                    } else {
                      result[0] += -2.8916275468495137e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -3.0409327065230588e-05;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.709112113944723732) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
                result[0] += 1.779686013277495e-05;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5131783528140704265) ) ) {
                  result[0] += -3.1252935814459376e-05;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5694467910050252657) ) ) {
                    result[0] += 6.421586142586632e-05;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4364163272837385255) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6169593235427136557) ) ) {
                        result[0] += -6.311299799407318e-05;
                      } else {
                        result[0] += -2.8916275468495137e-05;
                      }
                    } else {
                      result[0] += 2.3699347202016132e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -2.8916275468495137e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -2.8916275468495137e-05;
                    } else {
                      result[0] += -2.8916275468495137e-05;
                    }
                  } else {
                    result[0] += -2.8916275468495137e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -2.8916275468495137e-05;
                  } else {
                    result[0] += -2.8916275468495137e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -2.8916275468495137e-05;
                        } else {
                          result[0] += -2.8916275468495137e-05;
                        }
                      } else {
                        result[0] += -2.8916275468495137e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -2.8916275468495137e-05;
                          } else {
                            result[0] += -2.8916275468495137e-05;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -2.8916275468495137e-05;
                            } else {
                              result[0] += -2.8916275468495137e-05;
                            }
                          } else {
                            result[0] += -2.8916275468495137e-05;
                          }
                        }
                      } else {
                        result[0] += -2.8916275468495137e-05;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -2.8916275468495137e-05;
                      } else {
                        result[0] += -2.8916275468495137e-05;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -2.8916275468495137e-05;
                      } else {
                        result[0] += -2.8916275468495137e-05;
                      }
                    }
                  }
                } else {
                  result[0] += -2.8916275468495137e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -2.8916275468495137e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -2.8916275468495137e-05;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -2.8916275468495137e-05;
                    } else {
                      result[0] += -2.8916275468495137e-05;
                    }
                  }
                } else {
                  result[0] += -2.8916275468495137e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -2.8916275468495137e-05;
              } else {
                result[0] += 1.423022110119973e-06;
              }
            } else {
              result[0] += -2.8916275468495137e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          result[0] += -3.2078026583723063e-05;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9567162861906464144) ) ) {
            result[0] += 0.00013131183065542612;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8066186623115578769) ) ) {
                result[0] += -0.00021308390077535286;
              } else {
                result[0] += 2.584307709338903e-05;
              }
            } else {
              result[0] += 0.00013142488693630198;
            }
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8950000000000001288) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.25500000000000006) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001040500000000000192) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
            result[0] += 1.4462430969568245e-05;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.03500000000000001027) ) ) {
              result[0] += -6.030803709227828e-05;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3550000000000000377) ) ) {
                result[0] += -5.361346908319767e-05;
              } else {
                result[0] += -0.0015662746127718427;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02500000000000000486) ) ) {
            result[0] += -0.00011281849490552504;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.280667053512810405) ) ) {
              result[0] += 0.0004986871335000046;
            } else {
              result[0] += -0.0011113685908752343;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7760221401809592745) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01626400000000000415) ) ) {
            result[0] += 0.0008652618083129639;
          } else {
            result[0] += 0.00236762349067813;
          }
        } else {
          result[0] += 1.8010169235561107e-05;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
        result[0] += 0.0031678982358972698;
      } else {
        result[0] += 0.012393559860598978;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0;
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5742980588693468169) ) ) {
                result[0] += -2.7559998210349514e-05;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4655737892380691911) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
                    result[0] += -2.7559998210349514e-05;
                  } else {
                    result[0] += -2.7559998210349514e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6990533298743719648) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5686440254418744233) ) ) {
                      result[0] += -2.7559998210349514e-05;
                    } else {
                      result[0] += -2.7559998210349514e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7261071330150754566) ) ) {
                      result[0] += -2.7559998210349514e-05;
                    } else {
                      result[0] += -2.7559998210349514e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += -2.8983020320469493e-05;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
              result[0] += 1.6962123422275053e-05;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002091500000000000477) ) ) {
                  result[0] += -2.3422872755802768e-05;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01660200000000000217) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01009750000000000057) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004748500000000000117) ) ) {
                        result[0] += -2.7559998210349514e-05;
                      } else {
                        result[0] += -3.733328347711041e-05;
                      }
                    } else {
                      result[0] += -2.7559998210349514e-05;
                    }
                  } else {
                    result[0] += -2.978706078703345e-05;
                  }
                }
              } else {
                result[0] += 2.2587762631658473e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                      result[0] += -2.7559998210349514e-05;
                    } else {
                      result[0] += -2.7559998210349514e-05;
                    }
                  } else {
                    result[0] += -2.7559998210349514e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                    result[0] += -2.7559998210349514e-05;
                  } else {
                    result[0] += -2.7559998210349514e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                          result[0] += -2.7559998210349514e-05;
                        } else {
                          result[0] += -2.7559998210349514e-05;
                        }
                      } else {
                        result[0] += -2.7559998210349514e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                            result[0] += -2.7559998210349514e-05;
                          } else {
                            result[0] += -2.7559998210349514e-05;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
                              result[0] += -2.7559998210349514e-05;
                            } else {
                              result[0] += -2.7559998210349514e-05;
                            }
                          } else {
                            result[0] += -2.7559998210349514e-05;
                          }
                        }
                      } else {
                        result[0] += -2.7559998210349514e-05;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                        result[0] += -2.7559998210349514e-05;
                      } else {
                        result[0] += -2.7559998210349514e-05;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                        result[0] += -2.7559998210349514e-05;
                      } else {
                        result[0] += -2.7559998210349514e-05;
                      }
                    }
                  }
                } else {
                  result[0] += -2.7559998210349514e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
                result[0] += -2.7559998210349514e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                    result[0] += -2.7559998210349514e-05;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                      result[0] += -2.7559998210349514e-05;
                    } else {
                      result[0] += -2.7559998210349514e-05;
                    }
                  }
                } else {
                  result[0] += -2.7559998210349514e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.629563023060444982) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                result[0] += -2.7559998210349514e-05;
              } else {
                result[0] += 1.3562772581456407e-06;
              }
            } else {
              result[0] += -2.7559998210349514e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7536081807788946874) ) ) {
            result[0] += -3.057345183345498e-05;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7673948280402010935) ) ) {
              result[0] += -2.8520901815800533e-06;
            } else {
              result[0] += -2.603471686657197e-05;
            }
          }
        } else {
          result[0] += 2.9283819120501416e-06;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6950000000000000622) ) ) {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04625700000000000645) ) ) {
          result[0] += 6.935745007843717e-06;
        } else {
          result[0] += 0.0005257400262869141;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2750000000000000777) ) ) {
            result[0] += -0.000740667118765866;
          } else {
            result[0] += 0.0008945409668427765;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003805500000000000289) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4950000000000000511) ) ) {
              result[0] += 0.0009365557461491166;
            } else {
              result[0] += 0.0020615996380093297;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9808239647505231362) ) ) {
              result[0] += 0.0011323546027832007;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
                result[0] += 0.0011472258274519333;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02361250000000000501) ) ) {
                  result[0] += 0.0015145208625113363;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1414455000000000295) ) ) {
                    result[0] += -0.002912579450926515;
                  } else {
                    result[0] += 0.0005132557096464012;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
        result[0] += 0.0038230040305515718;
      } else {
        result[0] += 0.011812257354862696;
      }
    }
  }
}

