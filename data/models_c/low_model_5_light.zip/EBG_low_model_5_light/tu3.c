
#include "header.h"

void predict_unit3(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -2.8765632866130334e-05;
            } else {
              result[0] += -6.833725761865772e-05;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -6.833725761865772e-05;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -6.833725761865772e-05;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -6.833725761865772e-05;
                } else {
                  result[0] += -6.833725761865772e-05;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6135097231155780539) ) ) {
            result[0] += 3.9376680898585037e-05;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01344341525633075199) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.640890220251256415) ) ) {
                result[0] += -6.827702473038556e-05;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6461954822149375) ) ) {
                  result[0] += 5.000922946804609e-05;
                } else {
                  result[0] += -6.833725761865772e-05;
                }
              }
            } else {
              result[0] += 3.527432729513161e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -6.833725761865772e-05;
                } else {
                  result[0] += -6.833725761865772e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -6.833725761865772e-05;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -6.833725761865772e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -6.833725761865772e-05;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -6.833725761865772e-05;
                      } else {
                        result[0] += -6.833725761865772e-05;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -6.833725761865772e-05;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -6.833725761865772e-05;
                  } else {
                    result[0] += -6.833725761865772e-05;
                  }
                }
              } else {
                result[0] += -6.833725761865772e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -6.833725761865772e-05;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -6.833725761865772e-05;
                } else {
                  result[0] += -6.833725761865772e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -6.833725761865772e-05;
                } else {
                  result[0] += -6.833725761865772e-05;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.316725863161028132) ) ) {
            result[0] += -5.356541118469175e-05;
          } else {
            result[0] += -7.637827661288672e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9350000000000001643) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2650000000000000688) ) ) {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05227730674148379358) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.002217727144458050623) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2850000000000000866) ) ) {
                result[0] += 9.86879310530846e-05;
              } else {
                result[0] += -0.003051203953138676;
              }
            } else {
              result[0] += 0.0016752112975558075;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07149150000000001337) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.0650000000000000161) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03241729119215525784) ) ) {
                    result[0] += -7.700905990729654e-05;
                  } else {
                    result[0] += -0.0003684173260364017;
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)91.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.115000000000000005) ) ) {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)77.50000000000001421) ) ) {
                        result[0] += 0.0009581572873765074;
                      } else {
                        result[0] += -0.0012605483471604033;
                      }
                    } else {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02581470935451520357) ) ) {
                        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6555524765326633529) ) ) {
                          result[0] += -0.0006651721641813724;
                        } else {
                          result[0] += -0.0013973397830868632;
                        }
                      } else {
                        result[0] += 0.003527765934467471;
                      }
                    }
                  } else {
                    result[0] += 0.0006989035644097666;
                  }
                }
              } else {
                result[0] += 0.0016829805235946556;
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8789704397738694608) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05500000000000000722) ) ) {
                  result[0] += -0.0009512036329210245;
                } else {
                  result[0] += -3.163212087403066e-05;
                }
              } else {
                result[0] += 0.00020002124984387412;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1165587384072143268) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01668250000000000288) ) ) {
              result[0] += 0.0024364562645354526;
            } else {
              result[0] += 0.0074842887274849685;
            }
          } else {
            result[0] += 0.0012235158946174581;
          }
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9450000000000000622) ) ) {
          result[0] += 0.007849392882523842;
        } else {
          result[0] += 0.0303044014361249;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -2.563079856022425e-05;
            } else {
              result[0] += -6.08899686766248e-05;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -6.08899686766248e-05;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -6.08899686766248e-05;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -6.08899686766248e-05;
                } else {
                  result[0] += -6.08899686766248e-05;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6135097231155780539) ) ) {
            result[0] += 3.508547094300841e-05;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01344341525633075199) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.640890220251256415) ) ) {
                result[0] += -6.083629987562227e-05;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6461954822149375) ) ) {
                  result[0] += 4.455930076743522e-05;
                } else {
                  result[0] += -6.08899686766248e-05;
                }
              }
            } else {
              result[0] += 3.1430185508397633e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -6.08899686766248e-05;
                } else {
                  result[0] += -6.08899686766248e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -6.08899686766248e-05;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -6.08899686766248e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -6.08899686766248e-05;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -6.08899686766248e-05;
                      } else {
                        result[0] += -6.08899686766248e-05;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -6.08899686766248e-05;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -6.08899686766248e-05;
                  } else {
                    result[0] += -6.08899686766248e-05;
                  }
                }
              } else {
                result[0] += -6.08899686766248e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -6.08899686766248e-05;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -6.08899686766248e-05;
                } else {
                  result[0] += -6.08899686766248e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -6.08899686766248e-05;
                } else {
                  result[0] += -6.08899686766248e-05;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.179099372612799401) ) ) {
            result[0] += 0.00016441080941585824;
          } else {
            result[0] += -6.805468982213755e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6950000000000000622) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.25500000000000006) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4737195465326633492) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.130629626450776108e-06) ) ) {
              result[0] += -0.0002786010061169261;
            } else {
              result[0] += 0.002066970826280636;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.508252903391186006) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04770400000000000335) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2450759342279490716) ) ) {
                  result[0] += -0.001978753058498602;
                } else {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7593447680904524821) ) ) {
                    result[0] += 2.5934183938239005e-05;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.003859773430623800444) ) ) {
                      result[0] += 1.321237118024368e-05;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9911809338528255742) ) ) {
                        result[0] += -0.0007610830055974429;
                      } else {
                        result[0] += -0.0005065759145559528;
                      }
                    }
                  }
                }
              } else {
                result[0] += 0.0012379609758199769;
              }
            } else {
              result[0] += -0.0009163075282208212;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.004923558837848901124) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00526800000000000098) ) ) {
                result[0] += 0.001092075422077259;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.002919240565596450347) ) ) {
                  result[0] += 0.0014286961284040631;
                } else {
                  result[0] += -0.0025740772346014816;
                }
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)45.50000000000000711) ) ) {
                result[0] += 0.0016407048672382797;
              } else {
                result[0] += 0.0035423325594905555;
              }
            }
          } else {
            result[0] += 0.0070351518963126915;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)60.50000000000000711) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006853500000000001084) ) ) {
              result[0] += 0.008186844286193705;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06563467004728905374) ) ) {
                result[0] += 0.0012206851606011097;
              } else {
                result[0] += 0.011744885483187407;
              }
            }
          } else {
            result[0] += 0.011239685661061214;
          }
        } else {
          result[0] += 0.03027122511918094;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -2.2837593662272385e-05;
            } else {
              result[0] += -5.425427379790096e-05;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -5.425427379790096e-05;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -5.425427379790096e-05;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -5.425427379790096e-05;
                } else {
                  result[0] += -5.425427379790096e-05;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6135097231155780539) ) ) {
            result[0] += 3.126191043026475e-05;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01344341525633075199) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.640890220251256415) ) ) {
                result[0] += -5.4206453740060894e-05;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6461954822149375) ) ) {
                  result[0] += 3.970329689145535e-05;
                } else {
                  result[0] += -5.425427379790096e-05;
                }
              }
            } else {
              result[0] += 2.8004972364947968e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -5.425427379790096e-05;
                } else {
                  result[0] += -5.425427379790096e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -5.425427379790096e-05;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -5.425427379790096e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -5.425427379790096e-05;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -5.425427379790096e-05;
                      } else {
                        result[0] += -5.425427379790096e-05;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -5.425427379790096e-05;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -5.425427379790096e-05;
                  } else {
                    result[0] += -5.425427379790096e-05;
                  }
                }
              } else {
                result[0] += -5.425427379790096e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -5.425427379790096e-05;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -5.425427379790096e-05;
                } else {
                  result[0] += -5.425427379790096e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -5.425427379790096e-05;
                } else {
                  result[0] += -5.425427379790096e-05;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.179099372612799401) ) ) {
            result[0] += 0.00014649357296856038;
          } else {
            result[0] += -6.063819468277874e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.25500000000000006) ) ) {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05227730674148379358) ) ) {
            result[0] += 0.0006816014628487169;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1377635000000000109) ) ) {
              result[0] += -3.8390684410253037e-05;
            } else {
              result[0] += 0.0038373272089733752;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02664459509800340062) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)33.50000000000000711) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003977500000000001) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.29500000000000004) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3150000000000000577) ) ) {
                    result[0] += 0.0008981431998168638;
                  } else {
                    result[0] += -0.006620619392019092;
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.29500000000000004) ) ) {
                    result[0] += -0.002846589252603815;
                  } else {
                    result[0] += 0.002744099964134902;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5150000000000001243) ) ) {
                  result[0] += 0.0018919829959470084;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3850000000000000644) ) ) {
                    result[0] += -0.006745442675469222;
                  } else {
                    result[0] += -0.0015737660446844793;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3111804673197418603) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.750591121697756835e-06) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)185.5000000000000284) ) ) {
                    result[0] += -0.003942922023801399;
                  } else {
                    result[0] += 0.007626455048523107;
                  }
                } else {
                  result[0] += 0.0031444385153405053;
                }
              } else {
                result[0] += 0.0008582387652208656;
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8050000000000001599) ) ) {
              result[0] += 0.004582849645920044;
            } else {
              result[0] += 0.019868060651397894;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01244450000000000243) ) ) {
            result[0] += 0.007848661695988376;
          } else {
            result[0] += 0.007228629010333933;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.003991969522573301198) ) ) {
            result[0] += 0.008445974055545995;
          } else {
            result[0] += 0.02697231369153953;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -2.0348787926274464e-05;
            } else {
              result[0] += -4.8341726713149066e-05;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -4.8341726713149066e-05;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -4.8341726713149066e-05;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -4.8341726713149066e-05;
                } else {
                  result[0] += -4.8341726713149066e-05;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6135097231155780539) ) ) {
            result[0] += 2.7855035645307415e-05;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01344341525633075199) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.640890220251256415) ) ) {
                result[0] += -4.829911801146184e-05;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6461954822149375) ) ) {
                  result[0] += 3.5376492828699645e-05;
                } else {
                  result[0] += -4.8341726713149066e-05;
                }
              }
            } else {
              result[0] += 2.4953033667330903e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -4.8341726713149066e-05;
                } else {
                  result[0] += -4.8341726713149066e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -4.8341726713149066e-05;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -4.8341726713149066e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -4.8341726713149066e-05;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -4.8341726713149066e-05;
                      } else {
                        result[0] += -4.8341726713149066e-05;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -4.8341726713149066e-05;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -4.8341726713149066e-05;
                  } else {
                    result[0] += -4.8341726713149066e-05;
                  }
                }
              } else {
                result[0] += -4.8341726713149066e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -4.8341726713149066e-05;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -4.8341726713149066e-05;
                } else {
                  result[0] += -4.8341726713149066e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -4.8341726713149066e-05;
                } else {
                  result[0] += -4.8341726713149066e-05;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.179099372612799401) ) ) {
            result[0] += 0.00013052892931640143;
          } else {
            result[0] += -5.402993774560539e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2750000000000000777) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4795364038944723295) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.130629626450776108e-06) ) ) {
              result[0] += -0.00037904912568324046;
            } else {
              result[0] += 0.0019318582946396782;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04770400000000000335) ) ) {
              result[0] += -4.394609587586082e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
                result[0] += 0.0012805906715791576;
              } else {
                result[0] += -0.001465216933018826;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.004923558837848901124) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2750000000000000777) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1828583041203602211) ) ) {
                result[0] += -0.003263160439464533;
              } else {
                result[0] += -0.0009391997378453587;
              }
            } else {
              result[0] += 0.000948238617805679;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)27.50000000000000355) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)24.50000000000000355) ) ) {
                result[0] += 0.0018423642960968688;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05995868851020505486) ) ) {
                  result[0] += -0.005171289585977458;
                } else {
                  result[0] += 0.004067240860800209;
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.07172822906307056712) ) ) {
                result[0] += 0.005438155443817933;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7550000000000001155) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004773500000000000833) ) ) {
                    result[0] += 0.0032781470313081105;
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01896216239618550223) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8150000000000000577) ) ) {
                        result[0] += 0.0008966513217767016;
                      } else {
                        result[0] += -0.004410507536288491;
                      }
                    } else {
                      result[0] += 0.002074797565517028;
                    }
                  }
                } else {
                  result[0] += 0.011826394823104285;
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005862500000000000523) ) ) {
            result[0] += 0.006924080306851734;
          } else {
            result[0] += 0.0070289333418759575;
          }
        } else {
          result[0] += 0.02403291254353088;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -1.813120840102085e-05;
            } else {
              result[0] += -4.3073519891057924e-05;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -4.3073519891057924e-05;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -4.3073519891057924e-05;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -4.3073519891057924e-05;
                } else {
                  result[0] += -4.3073519891057924e-05;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6135097231155780539) ) ) {
            result[0] += 2.481943682015645e-05;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01344341525633075199) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.640890220251256415) ) ) {
                result[0] += -4.303555461996723e-05;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6461954822149375) ) ) {
                  result[0] += 3.152121719968241e-05;
                } else {
                  result[0] += -4.3073519891057924e-05;
                }
              }
            } else {
              result[0] += 2.2233690542122597e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -4.3073519891057924e-05;
                } else {
                  result[0] += -4.3073519891057924e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -4.3073519891057924e-05;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -4.3073519891057924e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -4.3073519891057924e-05;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -4.3073519891057924e-05;
                      } else {
                        result[0] += -4.3073519891057924e-05;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -4.3073519891057924e-05;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -4.3073519891057924e-05;
                  } else {
                    result[0] += -4.3073519891057924e-05;
                  }
                }
              } else {
                result[0] += -4.3073519891057924e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -4.3073519891057924e-05;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -4.3073519891057924e-05;
                } else {
                  result[0] += -4.3073519891057924e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -4.3073519891057924e-05;
                } else {
                  result[0] += -4.3073519891057924e-05;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.179099372612799401) ) ) {
            result[0] += 0.00011630408790795678;
          } else {
            result[0] += -4.814183845785002e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2850000000000000866) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4795364038944723295) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)3.928223887174962991e-06) ) ) {
              result[0] += -0.000359880733534928;
            } else {
              result[0] += 0.0018775544020326466;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.508252903391186006) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04528350000000001124) ) ) {
                result[0] += -3.559330969751531e-05;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02937690275817125482) ) ) {
                    result[0] += -0.000544041841357185;
                  } else {
                    result[0] += 0.001142802915089029;
                  }
                } else {
                  result[0] += 0.002201311815146232;
                }
              }
            } else {
              result[0] += -0.0008901204239667046;
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01184520638735680163) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004873500000000000228) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.004923558837848901124) ) ) {
                result[0] += 0.0006763282793395374;
              } else {
                result[0] += 0.0027846874313823167;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7550000000000001155) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4250000000000000444) ) ) {
                  result[0] += 0.0008520817397204954;
                } else {
                  result[0] += -0.0024523371748903944;
                }
              } else {
                result[0] += 0.003941807692602542;
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)31.50000000000000355) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.7835979262278595092) ) ) {
                result[0] += -0.002777163185133842;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05995868851020505486) ) ) {
                  result[0] += 0.0005144778396456325;
                } else {
                  result[0] += 0.0058090995399401;
                }
              }
            } else {
              result[0] += 0.0050758801683803865;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005862500000000000523) ) ) {
            result[0] += 0.0063362233082609985;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.00933301618409165118) ) ) {
              result[0] += -0.0016481505733085093;
            } else {
              result[0] += 0.008336427625994697;
            }
          }
        } else {
          result[0] += 0.02250362633751986;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -1.615529727236367e-05;
            } else {
              result[0] += -3.837943412353761e-05;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.837943412353761e-05;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -3.837943412353761e-05;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -3.837943412353761e-05;
                } else {
                  result[0] += -3.837943412353761e-05;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6135097231155780539) ) ) {
            result[0] += 2.2114652873313156e-05;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01344341525633075199) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.640890220251256415) ) ) {
                result[0] += -3.8345606249138374e-05;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6461954822149375) ) ) {
                  result[0] += 2.8086083562910208e-05;
                } else {
                  result[0] += -3.837943412353761e-05;
                }
              }
            } else {
              result[0] += 1.9810697236787933e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -3.837943412353761e-05;
                } else {
                  result[0] += -3.837943412353761e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -3.837943412353761e-05;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -3.837943412353761e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -3.837943412353761e-05;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -3.837943412353761e-05;
                      } else {
                        result[0] += -3.837943412353761e-05;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -3.837943412353761e-05;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -3.837943412353761e-05;
                  } else {
                    result[0] += -3.837943412353761e-05;
                  }
                }
              } else {
                result[0] += -3.837943412353761e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -3.837943412353761e-05;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -3.837943412353761e-05;
                } else {
                  result[0] += -3.837943412353761e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -3.837943412353761e-05;
                } else {
                  result[0] += -3.837943412353761e-05;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.179099372612799401) ) ) {
            result[0] += 0.00010362944777791931;
          } else {
            result[0] += -4.289541514954338e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7450000000000001066) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09500000000000001499) ) ) {
          result[0] += -4.868621094957743e-05;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.32337995336020553) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02664459509800340062) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)89.50000000000001421) ) ) {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4543227793467337072) ) ) {
                    result[0] += 0.0010711104037683158;
                  } else {
                    result[0] += -0.00023624662414928595;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.05463331189772155372) ) ) {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3498337084924623697) ) ) {
                      result[0] += -0.0010014101201146972;
                    } else {
                      result[0] += 0.0029171928714864653;
                    }
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)276.5000000000000568) ) ) {
                      result[0] += 0.0011477978517141583;
                    } else {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3450000000000000289) ) ) {
                        result[0] += 0.0012028505876055505;
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5050000000000001155) ) ) {
                          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7250000000000000888) ) ) {
                            result[0] += -0.0016715783417568808;
                          } else {
                            result[0] += -0.00579061046578479;
                          }
                        } else {
                          result[0] += 0.0009736743054001048;
                        }
                      }
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0036495000000000004) ) ) {
                  result[0] += 0.00390842263178318;
                } else {
                  result[0] += -0.0005876642127382397;
                }
              }
            } else {
              result[0] += 0.0031620667516209723;
            }
          } else {
            result[0] += -0.006952120847953409;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)59.50000000000000711) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007548500000000000522) ) ) {
              result[0] += 0.007150500069459295;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09069971400431196817) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.00933301618409165118) ) ) {
                  result[0] += -0.011259669421754683;
                } else {
                  result[0] += 0.0011030285385907476;
                }
              } else {
                result[0] += 0.011979101703287063;
              }
            }
          } else {
            result[0] += 0.010608660658837804;
          }
        } else {
          result[0] += 0.020051215845511818;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -1.439471789115541e-05;
            } else {
              result[0] += -3.419690258350013e-05;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.419690258350013e-05;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -3.419690258350013e-05;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -3.419690258350013e-05;
                } else {
                  result[0] += -3.419690258350013e-05;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6135097231155780539) ) ) {
            result[0] += 1.9704632109539428e-05;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01344341525633075199) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.640890220251256415) ) ) {
                result[0] += -3.416676121868183e-05;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6461954822149375) ) ) {
                  result[0] += 2.502530549203301e-05;
                } else {
                  result[0] += -3.419690258350013e-05;
                }
              }
            } else {
              result[0] += 1.7651758005003333e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -3.419690258350013e-05;
                } else {
                  result[0] += -3.419690258350013e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -3.419690258350013e-05;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -3.419690258350013e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -3.419690258350013e-05;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -3.419690258350013e-05;
                      } else {
                        result[0] += -3.419690258350013e-05;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -3.419690258350013e-05;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -3.419690258350013e-05;
                  } else {
                    result[0] += -3.419690258350013e-05;
                  }
                }
              } else {
                result[0] += -3.419690258350013e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -3.419690258350013e-05;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -3.419690258350013e-05;
                } else {
                  result[0] += -3.419690258350013e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -3.419690258350013e-05;
                } else {
                  result[0] += -3.419690258350013e-05;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.179099372612799401) ) ) {
            result[0] += 9.233607038176856e-05;
          } else {
            result[0] += -3.822073896207098e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8450000000000000844) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.25500000000000006) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4184049418341709292) ) ) {
            result[0] += 0.0013606936010662142;
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3932416254517326903) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.006697829966773901147) ) ) {
                result[0] += -0.0023117286636692006;
              } else {
                result[0] += 0.00030333672111784813;
              }
            } else {
              result[0] += 1.824430270435248e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03945037468542575421) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00526800000000000098) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.004923558837848901124) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2750000000000000777) ) ) {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2450759342279490716) ) ) {
                    result[0] += -0.003369976245606828;
                  } else {
                    result[0] += -1.3408668940247473e-05;
                  }
                } else {
                  result[0] += 0.0013220669123321345;
                }
              } else {
                result[0] += 0.0025044369603298097;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01244450000000000243) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4007818937688442662) ) ) {
                  result[0] += -0.0053039427530729545;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3172900446231167737) ) ) {
                    result[0] += 0.000890288249285321;
                  } else {
                    result[0] += -0.0018575500148611222;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5366611211306534512) ) ) {
                  result[0] += 0.004013931234121899;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01096925634721525149) ) ) {
                    result[0] += -0.0038273731088644416;
                  } else {
                    result[0] += 0.000754762699387346;
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
              result[0] += -0.0033665965941421616;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.194581012612933923) ) ) {
                result[0] += 0.005071310014120986;
              } else {
                result[0] += -0.001884092887771755;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01369138287730510203) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03507550000000000251) ) ) {
            result[0] += 0.008054743274288132;
          } else {
            result[0] += -0.006510937093793048;
          }
        } else {
          result[0] += 0.015930537130137676;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += 0;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
              result[0] += -1.2826003735654729e-05;
            } else {
              result[0] += -3.0470176880179755e-05;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.0470176880179755e-05;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -3.0470176880179755e-05;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
                  result[0] += -3.0470176880179755e-05;
                } else {
                  result[0] += -3.0470176880179755e-05;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6135097231155780539) ) ) {
            result[0] += 1.7557251691743285e-05;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01344341525633075199) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.640890220251256415) ) ) {
                result[0] += -3.044332027481379e-05;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6461954822149375) ) ) {
                  result[0] += 2.2298086294830032e-05;
                } else {
                  result[0] += -3.0470176880179755e-05;
                }
              }
            } else {
              result[0] += 1.5728096641071037e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -3.0470176880179755e-05;
                } else {
                  result[0] += -3.0470176880179755e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -3.0470176880179755e-05;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -3.0470176880179755e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                      result[0] += -3.0470176880179755e-05;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.557096113715400021) ) ) {
                        result[0] += -3.0470176880179755e-05;
                      } else {
                        result[0] += -3.0470176880179755e-05;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += -3.0470176880179755e-05;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002541500000000000356) ) ) {
                    result[0] += -3.0470176880179755e-05;
                  } else {
                    result[0] += -3.0470176880179755e-05;
                  }
                }
              } else {
                result[0] += -3.0470176880179755e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -3.0470176880179755e-05;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                  result[0] += -3.0470176880179755e-05;
                } else {
                  result[0] += -3.0470176880179755e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                  result[0] += -3.0470176880179755e-05;
                } else {
                  result[0] += -3.0470176880179755e-05;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.179099372612799401) ) ) {
            result[0] += 8.227342783702045e-05;
          } else {
            result[0] += -3.4055501775982254e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8850000000000001199) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2150000000000000244) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03675833313733020691) ) ) {
            result[0] += -1.99922289197055e-05;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002165500000000000324) ) ) {
              result[0] += -0.0006852306315101687;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.335710565658207782) ) ) {
                result[0] += 0.001691218674685837;
              } else {
                result[0] += -0.0005291579441065364;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)88.50000000000001421) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09069971400431196817) ) ) {
                result[0] += 0.00026702880136766205;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8722100575184922322) ) ) {
                  result[0] += 0.009150435624550602;
                } else {
                  result[0] += -0.0007922503116845194;
                }
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01369138287730510203) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00574050000000000081) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.002336892070558550458) ) ) {
                    result[0] += 0.00044207541405164036;
                  } else {
                    result[0] += 0.0028776848395457837;
                  }
                } else {
                  result[0] += -0.000475421928444894;
                }
              } else {
                result[0] += 0.004436480503522722;
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006853500000000001084) ) ) {
              result[0] += 0.003931119231200706;
            } else {
              result[0] += 0.0006893014407204662;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05403737693237045669) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)34.50000000000000711) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.003045380818265600552) ) ) {
              result[0] += -0.0171655460765366;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01265500000000000132) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
                  result[0] += -0.0021554522634879337;
                } else {
                  result[0] += 0.013712817534101347;
                }
              } else {
                result[0] += -0.0020949184232100693;
              }
            }
          } else {
            result[0] += 0.012742231384791051;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8025985781909549255) ) ) {
            result[0] += 0.01761315092860336;
          } else {
            result[0] += -0.0015798791186544278;
          }
        }
      }
    }
  }
}

