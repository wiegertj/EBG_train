
#include "header.h"

void predict_unit7(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -3.280203917889081e-05;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -3.9435310442833486e-05;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -4.100254859174753e-05;
            } else {
              result[0] += -4.100254859174753e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6135097231155780539) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.07196201389915944657) ) ) {
              result[0] += -7.931550002067318e-05;
            } else {
              result[0] += 0.00013722858893012874;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6488668789195980446) ) ) {
              result[0] += -6.020937884372586e-05;
            } else {
              result[0] += -3.082126225445477e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -4.100254859174753e-05;
                } else {
                  result[0] += -4.100254859174753e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -4.100254859174753e-05;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -4.100254859174753e-05;
                    } else {
                      result[0] += -4.100254859174753e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -4.100254859174753e-05;
                    } else {
                      result[0] += -4.100254859174753e-05;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -4.100254859174753e-05;
              } else {
                result[0] += -4.100254859174753e-05;
              }
            }
          } else {
            result[0] += -4.787205027924214e-05;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -4.100254859174753e-05;
              } else {
                result[0] += -4.100254859174753e-05;
              }
            } else {
              result[0] += -4.100254859174753e-05;
            }
          } else {
            result[0] += -4.100254859174753e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7750000000000001332) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2150000000000000244) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0009875000000000003133) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)117.5000000000000142) ) ) {
                result[0] += -0.00010259995890985165;
              } else {
                result[0] += 9.761424096326215e-06;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.25500000000000006) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4737195465326633492) ) ) {
                  result[0] += 0.0006747075593659897;
                } else {
                  result[0] += -7.75580237289075e-06;
                }
              } else {
                result[0] += 0.0023059317353476562;
              }
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0005035000000000001497) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
                result[0] += -3.9519142452152375e-05;
              } else {
                result[0] += 0.0007842122145588381;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.009516766579768852138) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1550000000000000266) ) ) {
                  result[0] += -0.0005411432284530557;
                } else {
                  result[0] += -5.670346688794155e-05;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.194581012612933923) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1645630000000000426) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)35.50000000000000711) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001543500000000000384) ) ) {
                        result[0] += 0.000960740343778329;
                      } else {
                        result[0] += -8.205018633930197e-05;
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.05368089823796016319) ) ) {
                        result[0] += 0.000924151500089598;
                      } else {
                        result[0] += 0.000247842121182076;
                      }
                    }
                  } else {
                    result[0] += 0.003393593275073829;
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05732259783002840309) ) ) {
                    result[0] += -2.6590515781509443e-05;
                  } else {
                    result[0] += -0.0015957965391938103;
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02447420998234165271) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00526800000000000098) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001427453683264650122) ) ) {
                result[0] += -0.0008327316512534385;
              } else {
                result[0] += 0.0020048256736865857;
              }
            } else {
              result[0] += -0.00018338991728440534;
            }
          } else {
            result[0] += 0.00202639919557094;
          }
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01244450000000000243) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.00802520011231920051) ) ) {
              result[0] += 0.0009569264581531183;
            } else {
              result[0] += 0.0025773067127305557;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01611044660174075147) ) ) {
              result[0] += -0.0002605182514435588;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)43.50000000000000711) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09998752698574815689) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03420850000000000973) ) ) {
                    result[0] += 0.0011036559790779167;
                  } else {
                    result[0] += -0.0016360140385528524;
                  }
                } else {
                  result[0] += 0.0019915862309222627;
                }
              } else {
                result[0] += 0.0017849817230696872;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01751223853061240412) ) ) {
            if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1341510627350609164) ) ) {
              result[0] += 0.0022403315779930843;
            } else {
              result[0] += 0.00020716850088202274;
            }
          } else {
            result[0] += 0.0025315269408644745;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -3.1409878178855146e-05;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -3.77616248245887e-05;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.9262347357909856e-05;
            } else {
              result[0] += -3.9262347357909856e-05;
            }
          }
        } else {
          result[0] += -2.3182265310701905e-05;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -3.9262347357909856e-05;
                } else {
                  result[0] += -3.9262347357909856e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -3.9262347357909856e-05;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -3.9262347357909856e-05;
                    } else {
                      result[0] += -3.9262347357909856e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -3.9262347357909856e-05;
                    } else {
                      result[0] += -3.9262347357909856e-05;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -3.9262347357909856e-05;
              } else {
                result[0] += -3.9262347357909856e-05;
              }
            }
          } else {
            result[0] += -4.5840298502255217e-05;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -3.9262347357909856e-05;
              } else {
                result[0] += -3.9262347357909856e-05;
              }
            } else {
              result[0] += -3.9262347357909856e-05;
            }
          } else {
            result[0] += -3.9262347357909856e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7750000000000001332) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.32337995336020553) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01265500000000000132) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2150000000000000244) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)43.50000000000000711) ) ) {
                  result[0] += -9.528486467778124e-05;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7573260829648241765) ) ) {
                      result[0] += -5.1160582810736715e-05;
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
                        result[0] += -0.00011431961991630221;
                      } else {
                        result[0] += -3.229115120025743e-05;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9993516786272610419) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9567162861906464144) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8722100575184922322) ) ) {
                          result[0] += -3.1030287632866288e-06;
                        } else {
                          result[0] += 0.0003418477895484581;
                        }
                      } else {
                        result[0] += -0.00039250834296564847;
                      }
                    } else {
                      result[0] += 0.0001408775455070791;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0005035000000000001497) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
                    result[0] += -4.062656514958907e-05;
                  } else {
                    result[0] += 0.0007362280232358175;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.003328854385626850345) ) ) {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)425.5000000000000568) ) ) {
                      result[0] += -8.091887801119889e-05;
                    } else {
                      result[0] += -0.000923702058107543;
                    }
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)84.50000000000001421) ) ) {
                      result[0] += -5.940423889132739e-05;
                    } else {
                      result[0] += 0.00034376976224621467;
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08495625534650631805) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)938.5000000000001137) ) ) {
                    result[0] += 0.0005906505829745847;
                  } else {
                    result[0] += 0.0028246536995157933;
                  }
                } else {
                  result[0] += 0.0032880490068071424;
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01096925634721525149) ) ) {
                  result[0] += -0.000372355931152038;
                } else {
                  result[0] += 0.00011029402184603396;
                }
              }
            }
          } else {
            result[0] += -0.0005001100554136296;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02447420998234165271) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002252500000000000595) ) ) {
              result[0] += 0.0019555638229719714;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)40.50000000000000711) ) ) {
                result[0] += -0.000506725202588529;
              } else {
                result[0] += 0.0007693588238809898;
              }
            }
          } else {
            result[0] += 0.001940396190843329;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09998752698574815689) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)34.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02374450000000000519) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04324794178047625809) ) ) {
                result[0] += 0.0010117088135206378;
              } else {
                result[0] += 0.0024415577811204635;
              }
            } else {
              result[0] += -0.00012562400275782876;
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2450759342279490716) ) ) {
              result[0] += 0.002718937930051001;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
                result[0] += 0.00245009981898191;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01611044660174075147) ) ) {
                  result[0] += -0.00020531355753090446;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1689458221662812065) ) ) {
                    result[0] += 0.002026991763322145;
                  } else {
                    result[0] += 0.000975051623160825;
                  }
                }
              }
            }
          }
        } else {
          result[0] += 0.0025320414135136656;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -3.0076802293603055e-05;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -3.615897259031538e-05;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.759600251686381e-05;
            } else {
              result[0] += -3.759600251686381e-05;
            }
          }
        } else {
          result[0] += -2.2198379964975976e-05;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -3.759600251686381e-05;
                } else {
                  result[0] += -3.759600251686381e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -3.759600251686381e-05;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -3.759600251686381e-05;
                    } else {
                      result[0] += -3.759600251686381e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -3.759600251686381e-05;
                    } else {
                      result[0] += -3.759600251686381e-05;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -3.759600251686381e-05;
              } else {
                result[0] += -3.759600251686381e-05;
              }
            }
          } else {
            result[0] += -4.3894776900479255e-05;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -3.759600251686381e-05;
              } else {
                result[0] += -3.759600251686381e-05;
              }
            } else {
              result[0] += -3.759600251686381e-05;
            }
          } else {
            result[0] += -3.759600251686381e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7350000000000000977) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.32337995336020553) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1132595000000000129) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.006697829966773901147) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2150000000000000244) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5226454670100503241) ) ) {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)3.217614006880118073e-05) ) ) {
                        result[0] += -0.00018318720259576327;
                      } else {
                        result[0] += 0.00011847387312305635;
                      }
                    } else {
                      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5492268452512564236) ) ) {
                        result[0] += -0.0004992108381101077;
                      } else {
                        result[0] += 0.00012502546677443363;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002917500000000000388) ) ) {
                      result[0] += 0.0004684728471589835;
                    } else {
                      result[0] += -0.0004604855379665759;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)102.5000000000000142) ) ) {
                    if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1055683853265851346) ) ) {
                      if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3197884335317744964) ) ) {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5550000000000001599) ) ) {
                          result[0] += 0.0013331287793243384;
                        } else {
                          result[0] += -0.0001354275707294871;
                        }
                      } else {
                        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2321635079408217728) ) ) {
                          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3650000000000000466) ) ) {
                            result[0] += -0.0011940607740824716;
                          } else {
                            result[0] += -0.00038382863255191743;
                          }
                        } else {
                          result[0] += 0.00011877760876236001;
                        }
                      }
                    } else {
                      result[0] += 0.0012321382222126615;
                    }
                  } else {
                    result[0] += 0.0009348751833109668;
                  }
                }
              } else {
                result[0] += 1.1665955727652314e-06;
              }
            } else {
              result[0] += 0.0012001977872880848;
            }
          } else {
            result[0] += -0.00040833516370575583;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02116634333934230491) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)113.5000000000000142) ) ) {
              result[0] += -0.0001235901396251033;
            } else {
              result[0] += 0.0011740318558045191;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004773500000000000833) ) ) {
              result[0] += 0.0022588867591459257;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9750000000000000888) ) ) {
                result[0] += 0.0026266520315248384;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8050000000000001599) ) ) {
                  result[0] += -0.0010678838147306728;
                } else {
                  result[0] += 0.0010888872838918312;
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01265500000000000132) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.008408953333664601418) ) ) {
              result[0] += 0.0008074454065629808;
            } else {
              result[0] += 0.0023751444477282486;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01611044660174075147) ) ) {
              result[0] += -0.0003533383655227227;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)21.50000000000000355) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03507550000000000251) ) ) {
                  result[0] += 0.0015950300559793521;
                } else {
                  result[0] += -0.0013299287879459164;
                }
              } else {
                result[0] += 0.0016393600254326845;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06116598190050365896) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01244450000000000243) ) ) {
                result[0] += 0.0024218411080206143;
              } else {
                result[0] += 8.936527247858493e-06;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3872449054220527542) ) ) {
                result[0] += 0.0023222473797885647;
              } else {
                result[0] += 0.0003808219575746934;
              }
            }
          } else {
            result[0] += 0.0023640716649119486;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -2.880030387438638e-05;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -3.462433899125579e-05;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.600037950770339e-05;
            } else {
              result[0] += -3.600037950770339e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6135097231155780539) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.07196201389915944657) ) ) {
              result[0] += -7.402323421397685e-05;
            } else {
              result[0] += 0.0001333304433181484;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6488668789195980446) ) ) {
              result[0] += -5.5728001549766174e-05;
            } else {
              result[0] += -2.7587154667020302e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -3.600037950770339e-05;
                } else {
                  result[0] += -3.600037950770339e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -3.600037950770339e-05;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -3.600037950770339e-05;
                    } else {
                      result[0] += -3.600037950770339e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -3.600037950770339e-05;
                    } else {
                      result[0] += -3.600037950770339e-05;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -3.600037950770339e-05;
              } else {
                result[0] += -3.600037950770339e-05;
              }
            }
          } else {
            result[0] += -4.203182575366648e-05;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -3.600037950770339e-05;
              } else {
                result[0] += -3.600037950770339e-05;
              }
            } else {
              result[0] += -3.600037950770339e-05;
            }
          } else {
            result[0] += -3.600037950770339e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7750000000000001332) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.32337995336020553) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01265500000000000132) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2150000000000000244) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)43.50000000000000711) ) ) {
                  result[0] += -9.129036351508571e-05;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                    result[0] += -7.914070256259324e-05;
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)661.5000000000001137) ) ) {
                      result[0] += 1.1408501351269304e-05;
                    } else {
                      result[0] += 0.00045836570411957614;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0005035000000000001497) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
                    result[0] += -3.895183296578007e-05;
                  } else {
                    result[0] += 0.0007035507470674649;
                  }
                } else {
                  result[0] += 3.5896656924236865e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
                result[0] += 0.0007211875381271013;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01096925634721525149) ) ) {
                  result[0] += -0.0003566021753015432;
                } else {
                  result[0] += 9.638585964337879e-05;
                }
              }
            }
          } else {
            result[0] += -0.0004615544644691278;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02116634333934230491) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004677500000000000234) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001427453683264650122) ) ) {
                result[0] += -0.0006613638003183828;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)55.50000000000000711) ) ) {
                  result[0] += 0.0006625789231668041;
                } else {
                  result[0] += 0.00231878248730528;
                }
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)149.5000000000000284) ) ) {
                result[0] += -0.000732962472527174;
              } else {
                result[0] += 0.0008633999330048565;
              }
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004773500000000000833) ) ) {
              result[0] += 0.0021630166761266887;
            } else {
              result[0] += 0.001518314392591126;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01244450000000000243) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03869870194826590531) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)32.50000000000000711) ) ) {
                result[0] += 0.00048368114468801403;
              } else {
                result[0] += 0.002046294142040531;
              }
            } else {
              result[0] += 0.0023503588148615874;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01611044660174075147) ) ) {
              result[0] += -0.0003234736596021399;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)21.50000000000000355) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03420850000000000973) ) ) {
                  result[0] += 0.0016900776909719911;
                } else {
                  result[0] += -0.0012326014968141422;
                }
              } else {
                result[0] += 0.0015411358657152596;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03603979634774020363) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.9546544174008676498) ) ) {
              result[0] += 0.002648100733929317;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)56.50000000000000711) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02321150000000000296) ) ) {
                  result[0] += 0.001883523430978492;
                } else {
                  result[0] += -0.0015384452438713956;
                }
              } else {
                result[0] += 0.0016286451708048333;
              }
            }
          } else {
            result[0] += 0.0022637374035195134;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -2.757798170031561e-05;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -3.31548372284916e-05;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.447247680434463e-05;
            } else {
              result[0] += -3.447247680434463e-05;
            }
          }
        } else {
          result[0] += -1.8891083469563664e-05;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -3.447247680434463e-05;
                } else {
                  result[0] += -3.447247680434463e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -3.447247680434463e-05;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -3.447247680434463e-05;
                    } else {
                      result[0] += -3.447247680434463e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -3.447247680434463e-05;
                    } else {
                      result[0] += -3.447247680434463e-05;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -3.447247680434463e-05;
              } else {
                result[0] += -3.447247680434463e-05;
              }
            }
          } else {
            result[0] += -4.0247940664833186e-05;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -3.447247680434463e-05;
              } else {
                result[0] += -3.447247680434463e-05;
              }
            } else {
              result[0] += -3.447247680434463e-05;
            }
          } else {
            result[0] += -3.447247680434463e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7350000000000000977) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.32337995336020553) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1466079245622486649) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01265500000000000132) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.09500000000000001499) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01247021903101905131) ) ) {
                    result[0] += -1.050060755015541e-05;
                  } else {
                    result[0] += -0.00020082138153083352;
                  }
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001543500000000000384) ) ) {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.29500000000000004) ) ) {
                      result[0] += -1.96373521102757e-06;
                    } else {
                      result[0] += 0.0003955944726307432;
                    }
                  } else {
                    result[0] += -3.487596979932409e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7269841738944724518) ) ) {
                  result[0] += 0.00046960115071849453;
                } else {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8352912313316583903) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05151350000000001067) ) ) {
                      result[0] += -8.619742932494344e-05;
                    } else {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02937690275817125482) ) ) {
                        result[0] += -0.0005550896028559561;
                      } else {
                        result[0] += -0.0004715265501912552;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02180250462562445188) ) ) {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)564.5000000000001137) ) ) {
                        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)262.5000000000000568) ) ) {
                          result[0] += 4.978172790805038e-05;
                        } else {
                          result[0] += -0.00035945037466058493;
                        }
                      } else {
                        result[0] += 0.00012809845224136254;
                      }
                    } else {
                      result[0] += 0.0014410401494039144;
                    }
                  }
                }
              }
            } else {
              result[0] += 0.0019339752656864287;
            }
          } else {
            result[0] += -0.0003714159219453252;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02116634333934230491) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)113.5000000000000142) ) ) {
              result[0] += -0.00010052593155939621;
            } else {
              result[0] += 0.0010742052671833364;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004773500000000000833) ) ) {
              result[0] += 0.0020712154538670828;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
                result[0] += 0.002663168994924095;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8050000000000001599) ) ) {
                  result[0] += -0.0009383947329353738;
                } else {
                  result[0] += 0.0010642353923707027;
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01244450000000000243) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.008408953333664601418) ) ) {
              result[0] += 0.0007474247410833411;
            } else {
              result[0] += 0.0021752024658194184;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01611044660174075147) ) ) {
              result[0] += -0.00030974501880084646;
            } else {
              result[0] += 0.0012617352513345198;
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03603979634774020363) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.9546544174008676498) ) ) {
              result[0] += 0.0025357119112150704;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)56.50000000000000711) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02321150000000000296) ) ) {
                  result[0] += 0.0018035842586312711;
                } else {
                  result[0] += -0.0014731516364365766;
                }
              } else {
                result[0] += 0.0015595233617207804;
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)34.50000000000000711) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03049200000000000174) ) ) {
                result[0] += 0.0021415247017982364;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
                  result[0] += 0.0012257141866723856;
                } else {
                  result[0] += 0.002498951802884392;
                }
              }
            } else {
              result[0] += 0.002213176024590995;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -2.6407536461423772e-05;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -3.174770302258712e-05;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.300942026935561e-05;
            } else {
              result[0] += -3.300942026935561e-05;
            }
          }
        } else {
          result[0] += -1.808932143546216e-05;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -3.300942026935561e-05;
                } else {
                  result[0] += -3.300942026935561e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -3.300942026935561e-05;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -3.300942026935561e-05;
                    } else {
                      result[0] += -3.300942026935561e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -3.300942026935561e-05;
                    } else {
                      result[0] += -3.300942026935561e-05;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -3.300942026935561e-05;
              } else {
                result[0] += -3.300942026935561e-05;
              }
            }
          } else {
            result[0] += -3.853976596813972e-05;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -3.300942026935561e-05;
              } else {
                result[0] += -3.300942026935561e-05;
              }
            } else {
              result[0] += -3.300942026935561e-05;
            }
          } else {
            result[0] += -3.300942026935561e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6950000000000000622) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.32337995336020553) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08495625534650631805) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)810.5000000000001137) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3103687546836865763) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.858234205283420677e-05) ) ) {
                    result[0] += -0.0002129198001116032;
                  } else {
                    result[0] += 0.0006041137758158305;
                  }
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08500000000000000611) ) ) {
                    result[0] += -3.307203230300739e-05;
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001009954059381500341) ) ) {
                      result[0] += 0.00024912145144605387;
                    } else {
                      result[0] += -9.687297625022567e-06;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01271386927770580197) ) ) {
                  result[0] += 0.00010704343839723228;
                } else {
                  result[0] += 0.001830863996538736;
                }
              }
            } else {
              result[0] += 0.0010790792796689123;
            }
          } else {
            result[0] += -0.0003909273376098701;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)59.50000000000000711) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3622054098241206943) ) ) {
              result[0] += -0.001445554878404655;
            } else {
              result[0] += 0.0005389222473802172;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3111804673197418603) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04250871378122500488) ) ) {
                result[0] += 0.0012910154496290729;
              } else {
                result[0] += 0.002823942176351808;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008486000000000002222) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.004769259728134950423) ) ) {
                  result[0] += -0.00014943161956864902;
                } else {
                  result[0] += 0.0018133521223394693;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02278050000000000561) ) ) {
                  result[0] += -0.002037543797206718;
                } else {
                  result[0] += 0.001045076606908766;
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01244450000000000243) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.009141018394375902481) ) ) {
              result[0] += 0.0009177954956480554;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)27.50000000000000355) ) ) {
                result[0] += 0.0011802188739427522;
              } else {
                result[0] += 0.0021514090116826526;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09998752698574815689) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)102.5000000000000142) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02085144663384500344) ) ) {
                  result[0] += -0.0017938776881917529;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02687100000000000252) ) ) {
                    result[0] += 0.0014184468982225684;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06997050552869731044) ) ) {
                      result[0] += 0.0001899923518672817;
                    } else {
                      result[0] += -0.0017832006645990414;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
                  result[0] += 0.003126757695893363;
                } else {
                  result[0] += 0.0009183202624827173;
                }
              }
            } else {
              result[0] += 0.001797684037713186;
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03603979634774020363) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.9546544174008676498) ) ) {
              result[0] += 0.002428093015607166;
            } else {
              result[0] += 0.0013001530122767513;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)34.50000000000000711) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03049200000000000174) ) ) {
                result[0] += 0.0020506356215737667;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
                  result[0] += 0.001173693290088193;
                } else {
                  result[0] += 0.002392893053854446;
                }
              }
            } else {
              result[0] += 0.0021192459694853857;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -2.5286766433435053e-05;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -3.0400289413703852e-05;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.1608457747417146e-05;
            } else {
              result[0] += -3.1608457747417146e-05;
            }
          }
        } else {
          result[0] += -1.732158721984774e-05;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -3.1608457747417146e-05;
                } else {
                  result[0] += -3.1608457747417146e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -3.1608457747417146e-05;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -3.1608457747417146e-05;
                    } else {
                      result[0] += -3.1608457747417146e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -3.1608457747417146e-05;
                    } else {
                      result[0] += -3.1608457747417146e-05;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -3.1608457747417146e-05;
              } else {
                result[0] += -3.1608457747417146e-05;
              }
            }
          } else {
            result[0] += -3.690408841654794e-05;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -3.1608457747417146e-05;
              } else {
                result[0] += -3.1608457747417146e-05;
              }
            } else {
              result[0] += -3.1608457747417146e-05;
            }
          } else {
            result[0] += -3.1608457747417146e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7350000000000000977) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1840395000000000225) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.32337995336020553) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.005393752740946750925) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2150000000000000244) ) ) {
                    if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1296381427427941713) ) ) {
                      result[0] += -4.737494658334757e-05;
                    } else {
                      result[0] += -0.0002233505680034817;
                    }
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002917500000000000388) ) ) {
                      result[0] += 0.0004917598146145929;
                    } else {
                      result[0] += -0.0005100103517581581;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)115.5000000000000142) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5196530228391961215) ) ) {
                      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
                        result[0] += 0.00016732667679593603;
                      } else {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6850000000000001643) ) ) {
                          result[0] += -0.0012310414984352794;
                        } else {
                          result[0] += 0.00039701382345249466;
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.545000000000000151) ) ) {
                        result[0] += 0.0015714550979285577;
                      } else {
                        result[0] += 0.00018071460910302375;
                      }
                    }
                  } else {
                    result[0] += 0.0008119884450786654;
                  }
                }
              } else {
                result[0] += 1.9399784245852355e-06;
              }
            } else {
              result[0] += -0.00040961066353903207;
            }
          } else {
            result[0] += 0.002238524030630189;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)59.50000000000000711) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6280024623366835534) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8150000000000000577) ) ) {
                result[0] += -0.0005447717816902762;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2291474556034803212) ) ) {
                  result[0] += 0.0009255394985617683;
                } else {
                  result[0] += -0.0011786661523297767;
                }
              }
            } else {
              result[0] += 0.0018735648180970245;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04250871378122500488) ) ) {
              result[0] += 0.0010512625053285582;
            } else {
              result[0] += 0.0022414039248148544;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01265500000000000132) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.009141018394375902481) ) ) {
              result[0] += 0.0008278608398382177;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)27.50000000000000355) ) ) {
                result[0] += 0.0013684417257486872;
              } else {
                result[0] += 0.002059965297600577;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09998752698574815689) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)85.50000000000001421) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
                  result[0] += 0.001977428131299789;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03507550000000000251) ) ) {
                    result[0] += 0.00012148265306886018;
                  } else {
                    result[0] += -0.0017129643813080602;
                  }
                }
              } else {
                result[0] += 0.0013396429777283105;
              }
            } else {
              result[0] += 0.001721388000322271;
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03603979634774020363) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.9546544174008676498) ) ) {
              result[0] += 0.002325041605225258;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02687100000000000252) ) ) {
                result[0] += 0.0016850566376241118;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)92.50000000000001421) ) ) {
                  result[0] += -0.0009805484120037821;
                } else {
                  result[0] += 0.0009921547516803092;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)34.50000000000000711) ) ) {
              result[0] += 0.0018966185539050163;
            } else {
              result[0] += 0.002029302427496722;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -2.4213563336101596e-05;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -2.911006178240492e-05;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.0266953888244056e-05;
            } else {
              result[0] += -3.0266953888244056e-05;
            }
          }
        } else {
          result[0] += -1.6586436638059934e-05;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -3.0266953888244056e-05;
                } else {
                  result[0] += -3.0266953888244056e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -3.0266953888244056e-05;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -3.0266953888244056e-05;
                    } else {
                      result[0] += -3.0266953888244056e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -3.0266953888244056e-05;
                    } else {
                      result[0] += -3.0266953888244056e-05;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -3.0266953888244056e-05;
              } else {
                result[0] += -3.0266953888244056e-05;
              }
            }
          } else {
            result[0] += -3.53378311373832e-05;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -3.0266953888244056e-05;
              } else {
                result[0] += -3.0266953888244056e-05;
              }
            } else {
              result[0] += -3.0266953888244056e-05;
            }
          } else {
            result[0] += -3.0266953888244056e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7350000000000000977) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1466079245622486649) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.32337995336020553) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1132595000000000129) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.005393752740946750925) ) ) {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2450000000000000233) ) ) {
                      result[0] += -0.00010133734453743425;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002917500000000000388) ) ) {
                        result[0] += 0.0004944623787359536;
                      } else {
                        result[0] += -0.00044555704209000614;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)115.5000000000000142) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5550000000000001599) ) ) {
                        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5196530228391961215) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.29500000000000004) ) ) {
                            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4184049418341709292) ) ) {
                              result[0] += 0.0013050354201801276;
                            } else {
                              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2185860198827210554) ) ) {
                                result[0] += -0.0003593548412534126;
                              } else {
                                result[0] += 0.0004031716532401635;
                              }
                            }
                          } else {
                            result[0] += 0.0013441787165421903;
                          }
                        } else {
                          result[0] += 0.0014400542056386561;
                        }
                      } else {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003808500000000000687) ) ) {
                          result[0] += 0.0005176339697297242;
                        } else {
                          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005862500000000000523) ) ) {
                            result[0] += -0.0015501212369291265;
                          } else {
                            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9250000000000001554) ) ) {
                              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6550000000000001377) ) ) {
                                result[0] += -0.001246430648689809;
                              } else {
                                result[0] += 0.000642344549793815;
                              }
                            } else {
                              result[0] += -0.001842210199699493;
                            }
                          }
                        }
                      }
                    } else {
                      result[0] += 0.0007023324619111853;
                    }
                  }
                } else {
                  result[0] += -2.566650651508148e-06;
                }
              } else {
                result[0] += 0.0009718653904069852;
              }
            } else {
              result[0] += -0.00039222625679932136;
            }
          } else {
            result[0] += 0.001747683625852126;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)59.50000000000000711) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6280024623366835534) ) ) {
              result[0] += -7.528996545671424e-05;
            } else {
              result[0] += 0.0017940483021704164;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3084325690180824142) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04250871378122500488) ) ) {
                result[0] += 0.0014340263043019332;
              } else {
                result[0] += 0.0026277100342273897;
              }
            } else {
              result[0] += 0.0004402706820415098;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02321150000000000296) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0416553728637082607) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)32.50000000000000711) ) ) {
                result[0] += 0.00021578788278965821;
              } else {
                result[0] += 0.0016132218143845032;
              }
            } else {
              result[0] += 0.00198721696987359;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.08693186820944626136) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)20.50000000000000355) ) ) {
                result[0] += -0.0004663449870339483;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08260095417535827378) ) ) {
                  result[0] += 0.0008681801753666436;
                } else {
                  result[0] += 0.00256378259395527;
                }
              }
            } else {
              result[0] += -6.010850654101327e-05;
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03603979634774020363) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.9546544174008676498) ) ) {
              result[0] += 0.002226363830084439;
            } else {
              result[0] += 0.0011879332839169635;
            }
          } else {
            result[0] += 0.001897661639305502;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -2.3185908367318212e-05;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -2.7874593081783037e-05;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.898238518922833e-05;
            } else {
              result[0] += -2.898238518922833e-05;
            }
          }
        } else {
          result[0] += -1.5882486798504554e-05;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -2.898238518922833e-05;
                } else {
                  result[0] += -2.898238518922833e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -2.898238518922833e-05;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -2.898238518922833e-05;
                    } else {
                      result[0] += -2.898238518922833e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -2.898238518922833e-05;
                    } else {
                      result[0] += -2.898238518922833e-05;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -2.898238518922833e-05;
              } else {
                result[0] += -2.898238518922833e-05;
              }
            }
          } else {
            result[0] += -3.38380478444296e-05;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -2.898238518922833e-05;
              } else {
                result[0] += -2.898238518922833e-05;
              }
            } else {
              result[0] += -2.898238518922833e-05;
            }
          } else {
            result[0] += -2.898238518922833e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03139221484724531025) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2650000000000000688) ) ) {
            result[0] += -1.0949575309460185e-05;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001193500000000000333) ) ) {
              result[0] += 0.0004173673743241133;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)45.50000000000000711) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
                  result[0] += -0.00029038296813511515;
                } else {
                  result[0] += 0.0006943710089204192;
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.007016451597998800589) ) ) {
                  result[0] += -0.00012772645435319237;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03842800000000001076) ) ) {
                    result[0] += 0.0005315721784060416;
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01247021903101905131) ) ) {
                      result[0] += -0.0015369162427834634;
                    } else {
                      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5395721621608041696) ) ) {
                        result[0] += 0.001253140845173546;
                      } else {
                        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)367.5000000000000568) ) ) {
                          result[0] += -0.0013197410340176328;
                        } else {
                          result[0] += 0.0013142024179453946;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.194581012612933923) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
              result[0] += -0.002154251663067514;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1245513101099625097) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)87.50000000000001421) ) ) {
                  result[0] += 0.0007996618680521154;
                } else {
                  result[0] += 0.003087812895853396;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5733499648994976328) ) ) {
                  result[0] += -0.0005735903719254771;
                } else {
                  result[0] += 0.00043749441714095494;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8371684470603016903) ) ) {
              result[0] += -0.0015205834085832255;
            } else {
              result[0] += 8.170548224442871e-05;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01265500000000000132) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.009141018394375902481) ) ) {
              result[0] += 0.0007242581323803429;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)27.50000000000000355) ) ) {
                result[0] += 0.001226023227313317;
              } else {
                result[0] += 0.0018883327746611511;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09998752698574815689) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)105.5000000000000142) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
                  result[0] += 0.002121455110371466;
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4131576219849246168) ) ) {
                    result[0] += -0.0019597649526260055;
                  } else {
                    result[0] += -7.696965757384783e-05;
                  }
                }
              } else {
                result[0] += 0.0014169177425500626;
              }
            } else {
              result[0] += 0.0015882591810542138;
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03603979634774020363) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.9546544174008676498) ) ) {
              result[0] += 0.002131874067444067;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02687100000000000252) ) ) {
                result[0] += 0.0015631232267025476;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)92.50000000000001421) ) ) {
                  result[0] += -0.00098935009439616;
                } else {
                  result[0] += 0.0008996289936549951;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)34.50000000000000711) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03049200000000000174) ) ) {
                result[0] += 0.0018025698290339309;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
                  result[0] += 0.0009628460651659536;
                } else {
                  result[0] += 0.002130301412888086;
                }
              }
            } else {
              result[0] += 0.0018626369896399904;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -2.2201868405554135e-05;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -2.6691559271943107e-05;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.775233524847892e-05;
            } else {
              result[0] += -2.775233524847892e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
            result[0] += -4.9680163064249216e-05;
          } else {
            result[0] += 0.0006618887329936678;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -2.775233524847892e-05;
                } else {
                  result[0] += -2.775233524847892e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -2.775233524847892e-05;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -2.775233524847892e-05;
                    } else {
                      result[0] += -2.775233524847892e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -2.775233524847892e-05;
                    } else {
                      result[0] += -2.775233524847892e-05;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -2.775233524847892e-05;
              } else {
                result[0] += -2.775233524847892e-05;
              }
            }
          } else {
            result[0] += -3.240191729567181e-05;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -2.775233524847892e-05;
              } else {
                result[0] += -2.775233524847892e-05;
              }
            } else {
              result[0] += -2.775233524847892e-05;
            }
          } else {
            result[0] += -2.775233524847892e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8850000000000001199) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1840395000000000225) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01461911667849610276) ) ) {
              result[0] += 1.7572591144538875e-05;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)119.5000000000000142) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.6699946881477002458) ) ) {
                  result[0] += -0.0011842345565840685;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001657500000000000336) ) ) {
                    result[0] += 0.0010236877826269052;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03415342701090800376) ) ) {
                      result[0] += -3.0516402951551863e-05;
                    } else {
                      result[0] += 0.0006312812667796431;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.04446937286580055632) ) ) {
                  result[0] += 0.0017691215844506598;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6010141514957837439) ) ) {
                    result[0] += 9.180535188744433e-05;
                  } else {
                    result[0] += 0.0015789710683670284;
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7080301875628142172) ) ) {
              result[0] += -0.0006029015338344967;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7269841738944724518) ) ) {
                result[0] += 0.0004464964715435984;
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -0.0012191434549475193;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8458243956458841861) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2850000000000000866) ) ) {
                      result[0] += -0.00030043844504075846;
                    } else {
                      result[0] += 0.00022900243152974904;
                    }
                  } else {
                    result[0] += 7.512324763059796e-06;
                  }
                }
              }
            }
          }
        } else {
          result[0] += 0.002375836834513657;
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007249500000000001602) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.008408953333664601418) ) ) {
              result[0] += 0.0010796623830068158;
            } else {
              result[0] += 0.0018052490846030486;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03037232950945140467) ) ) {
              result[0] += 0.00019603269861702275;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02374450000000000519) ) ) {
                result[0] += 0.0016844553664449168;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
                  result[0] += 0.0028951971561659877;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)78.50000000000001421) ) ) {
                      result[0] += -0.0012598651301341972;
                    } else {
                      result[0] += 0.0008203973045775584;
                    }
                  } else {
                    result[0] += 0.0023350947440111836;
                  }
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9993516786272610419) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03603979634774020363) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.9546544174008676498) ) ) {
                result[0] += 0.002041394572632873;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06439350000000000629) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)22.50000000000000355) ) ) {
                    result[0] += -0.0004787945731143883;
                  } else {
                    result[0] += 0.0014827469700888526;
                  }
                } else {
                  result[0] += -0.00033515465732548034;
                }
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)34.50000000000000711) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03049200000000000174) ) ) {
                  result[0] += 0.0017840223172644225;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1076044449659239177) ) ) {
                    result[0] += 7.274806542221283e-05;
                  } else {
                    result[0] += 0.001770806709376231;
                  }
                }
              } else {
                result[0] += 0.0018189373481380844;
              }
            }
          } else {
            result[0] += -7.680104474006461e-05;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -2.125959237345836e-05;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -2.55587349482513e-05;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.6574490219328703e-05;
            } else {
              result[0] += -2.6574490219328703e-05;
            }
          }
        } else {
          result[0] += -1.3099923077385165e-05;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -2.6574490219328703e-05;
                } else {
                  result[0] += -2.6574490219328703e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -2.6574490219328703e-05;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -2.6574490219328703e-05;
                    } else {
                      result[0] += -2.6574490219328703e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -2.6574490219328703e-05;
                    } else {
                      result[0] += -2.6574490219328703e-05;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -2.6574490219328703e-05;
              } else {
                result[0] += -2.6574490219328703e-05;
              }
            }
          } else {
            result[0] += -3.102673798625732e-05;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -2.6574490219328703e-05;
              } else {
                result[0] += -2.6574490219328703e-05;
              }
            } else {
              result[0] += -2.6574490219328703e-05;
            }
          } else {
            result[0] += -2.6574490219328703e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7350000000000000977) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1466079245622486649) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.005393752740946750925) ) ) {
                result[0] += -1.967032972381123e-05;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)115.5000000000000142) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5550000000000001599) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5196530228391961215) ) ) {
                      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
                        result[0] += 0.0005805218239017943;
                      } else {
                        result[0] += -0.0006631352269911081;
                      }
                    } else {
                      result[0] += 0.0013948578023274824;
                    }
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003808500000000000687) ) ) {
                      result[0] += 0.00046624141299889447;
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0131020000000000008) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6450000000000001288) ) ) {
                          result[0] += -0.0017308331249660885;
                        } else {
                          result[0] += 2.4373863793322496e-05;
                        }
                      } else {
                        result[0] += 0.0003583200252219578;
                      }
                    }
                  }
                } else {
                  result[0] += 0.000803329195381394;
                }
              }
            } else {
              result[0] += -2.1223326959042163e-06;
            }
          } else {
            result[0] += 0.001613180920086864;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)59.50000000000000711) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6280024623366835534) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07802786554345496339) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007100500000000000908) ) ) {
                  result[0] += 0.00032221109559720613;
                } else {
                  result[0] += -0.0010624654346019346;
                }
              } else {
                result[0] += 0.0015751306346574552;
              }
            } else {
              result[0] += 0.0017091763405864089;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3084325690180824142) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04250871378122500488) ) ) {
                result[0] += 0.001307055510731464;
              } else {
                result[0] += 0.002458562702988761;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008486000000000002222) ) ) {
                result[0] += 0.0012713973601309976;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02472850000000000395) ) ) {
                  result[0] += -0.001959962376763893;
                } else {
                  result[0] += 0.001610811078270851;
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01265500000000000132) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.009141018394375902481) ) ) {
              result[0] += 0.0006476974108047673;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)27.50000000000000355) ) ) {
                result[0] += 0.0010973721068715863;
              } else {
                result[0] += 0.0017382123661504555;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09998752698574815689) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)105.5000000000000142) ) ) {
                result[0] += -0.0001060136654858249;
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
                  result[0] += 0.002834215056964316;
                } else {
                  result[0] += 0.0007071197792080765;
                }
              }
            } else {
              result[0] += 0.00145236399066516;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9993516786272610419) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)34.50000000000000711) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09637729146099090205) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01775050000000000239) ) ) {
                  result[0] += 0.0017024314391777488;
                } else {
                  result[0] += 0.00025312182339738004;
                }
              } else {
                result[0] += 0.0016956513805885763;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03358130704046471265) ) ) {
                result[0] += 0.0014716431761459072;
              } else {
                result[0] += 0.001741739292743537;
              }
            }
          } else {
            result[0] += -7.354150899394822e-05;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -2.0357307755798657e-05;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -2.4473989155126898e-05;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.5446634457758053e-05;
            } else {
              result[0] += -2.5446634457758053e-05;
            }
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4754075198241206057) ) ) {
            result[0] += 0.00035987847974410105;
          } else {
            result[0] += -4.7015694949062445e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -2.5446634457758053e-05;
                } else {
                  result[0] += -2.5446634457758053e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -2.5446634457758053e-05;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -2.5446634457758053e-05;
                    } else {
                      result[0] += -2.5446634457758053e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -2.5446634457758053e-05;
                    } else {
                      result[0] += -2.5446634457758053e-05;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -2.5446634457758053e-05;
              } else {
                result[0] += -2.5446634457758053e-05;
              }
            }
          } else {
            result[0] += -2.9709923066696202e-05;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -2.5446634457758053e-05;
              } else {
                result[0] += -2.5446634457758053e-05;
              }
            } else {
              result[0] += -2.5446634457758053e-05;
            }
          } else {
            result[0] += -2.5446634457758053e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7650000000000001243) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1377635000000000109) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.32337995336020553) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09500000000000001499) ) ) {
                result[0] += -1.5380741509862676e-05;
              } else {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)189.5000000000000284) ) ) {
                    result[0] += 0.00011960618375447779;
                  } else {
                    result[0] += 0.0007564966984937319;
                  }
                } else {
                  result[0] += 3.759559994684524e-05;
                }
              }
            } else {
              result[0] += -0.00032170336140980877;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)82.50000000000001421) ) ) {
              result[0] += -2.829418419600819e-05;
            } else {
              result[0] += 0.001712246722093332;
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)59.50000000000000711) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8050000000000001599) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4814085394974874643) ) ) {
                result[0] += -0.0008125665975434538;
              } else {
                result[0] += 0.00023990953442757498;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002855500000000000399) ) ) {
                result[0] += 0.0017996193599811216;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02149820807722475566) ) ) {
                  result[0] += -0.0007004860768533014;
                } else {
                  result[0] += 0.0010485634225824358;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02403426826619565679) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00799650000000000187) ) ) {
                result[0] += 0.001562662342969469;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2756227488107761969) ) ) {
                  result[0] += 0.0004298370150442576;
                } else {
                  result[0] += -0.001694635559170608;
                }
              }
            } else {
              result[0] += 0.0017675851847534375;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02321150000000000296) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0416553728637082607) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)32.50000000000000711) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)15.50000000000000178) ) ) {
                  result[0] += 0.0018188695676461272;
                } else {
                  result[0] += -0.0010438867465013993;
                }
              } else {
                result[0] += 0.0013858747118540315;
              }
            } else {
              result[0] += 0.0016777639306653834;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09637729146099090205) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)60.50000000000000711) ) ) {
                result[0] += -0.0006030700127516707;
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
                  result[0] += 0.002085202585528219;
                } else {
                  result[0] += 8.423405333103701e-05;
                }
              }
            } else {
              result[0] += 0.0013303895902307445;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1271566581126106488) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8722100575184922322) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4516066347997827468) ) ) {
                result[0] += 0.0018922967034781361;
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4086612272110553001) ) ) {
                  result[0] += -0.00018398380776035855;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02231150000000000147) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01667338205697885267) ) ) {
                      result[0] += 0.0012492485554408232;
                    } else {
                      result[0] += 0.0016296613772780926;
                    }
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)115.5000000000000142) ) ) {
                      result[0] += 0.0007381248954830376;
                    } else {
                      result[0] += 0.0014950565602560885;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.0006662816254589955;
            }
          } else {
            result[0] += 0.0018927676954274704;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -1.949331726518354e-05;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -2.343528137750223e-05;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.436664635454733e-05;
            } else {
              result[0] += -2.436664635454733e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6135097231155780539) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.07196201389915944657) ) ) {
              result[0] += -7.29005097789341e-05;
            } else {
              result[0] += 0.00013576336363917377;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6488668789195980446) ) ) {
              result[0] += -4.502028800071092e-05;
            } else {
              result[0] += -1.8073775083743147e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -2.436664635454733e-05;
                } else {
                  result[0] += -2.436664635454733e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -2.436664635454733e-05;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -2.436664635454733e-05;
                    } else {
                      result[0] += -2.436664635454733e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -2.436664635454733e-05;
                    } else {
                      result[0] += -2.436664635454733e-05;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -2.436664635454733e-05;
              } else {
                result[0] += -2.436664635454733e-05;
              }
            }
          } else {
            result[0] += -2.8448995476739163e-05;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -2.436664635454733e-05;
              } else {
                result[0] += -2.436664635454733e-05;
              }
            } else {
              result[0] += -2.436664635454733e-05;
            }
          } else {
            result[0] += -2.436664635454733e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02403426826619565679) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)47.50000000000000711) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
              result[0] += -6.50072321021509e-05;
            } else {
              result[0] += 0.000735566461545584;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
              result[0] += -9.119320979779314e-05;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06279750000000001997) ) ) {
                result[0] += 8.650834945056119e-05;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)446.5000000000000568) ) ) {
                  result[0] += -0.0006493964907431977;
                } else {
                  result[0] += 0.0007110934482881575;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.194581012612933923) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)121.5000000000000142) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06279750000000001997) ) ) {
                result[0] += 0.00014521306417843217;
              } else {
                result[0] += 0.0011600239658364746;
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.568345700351758909) ) ) {
                result[0] += 0.002738254654498403;
              } else {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8009873338190955927) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4350000000000000533) ) ) {
                    result[0] += -0.00027602346370381674;
                  } else {
                    result[0] += 0.0013466587802530199;
                  }
                } else {
                  result[0] += 0.0018000209201291962;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8257879984924624273) ) ) {
              result[0] += -0.0020084096766313482;
            } else {
              result[0] += -2.490829070094826e-05;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01265500000000000132) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01035297934913455113) ) ) {
              result[0] += 0.0005676268542036594;
            } else {
              result[0] += 0.0015925757213155422;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09998752698574815689) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)44.50000000000000711) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03507550000000000251) ) ) {
                  result[0] += 0.0003156713799608471;
                } else {
                  result[0] += -0.0017448529077481593;
                }
              } else {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2070606536698188782) ) ) {
                  result[0] += 0.0018972606046463562;
                } else {
                  result[0] += 0.0004711454008538667;
                }
              }
            } else {
              result[0] += 0.0013342603268378822;
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04250871378122500488) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.9546544174008676498) ) ) {
              result[0] += 0.0018119851820903568;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01154850000000000147) ) ) {
                result[0] += 0.0017100204117510742;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
                  result[0] += -0.0010586744686209434;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3460056117438527479) ) ) {
                    result[0] += 0.0011162554204195271;
                  } else {
                    result[0] += -0.00012081623098295381;
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)34.50000000000000711) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03049200000000000174) ) ) {
                result[0] += 0.001581595906264378;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
                  result[0] += 0.0010487438405189797;
                } else {
                  result[0] += 0.0018124361845317334;
                }
              }
            } else {
              result[0] += 0.001636490646785699;
            }
          }
        }
      }
    }
  }
}

