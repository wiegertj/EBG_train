
#include "header.h"

void predict_unit7(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -7.189119042323917e-05;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2323027026914575854) ) ) {
              result[0] += -0.0001159670476735706;
            } else {
              result[0] += 8.322176635028859e-05;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -9.585492056431883e-05;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.652905739716803768) ) ) {
                result[0] += -9.585492056431883e-05;
              } else {
                result[0] += -9.585492056431883e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
            result[0] += -0.00012480120012859023;
          } else {
            result[0] += 0.002917471735478839;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                  result[0] += -9.585492056431883e-05;
                } else {
                  result[0] += -9.585492056431883e-05;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += 9.922465507443001e-06;
                } else {
                  result[0] += -9.635006375149255e-05;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06983950000000001268) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                        result[0] += -9.585492056431883e-05;
                      } else {
                        result[0] += -9.585492056431883e-05;
                      }
                    } else {
                      result[0] += -9.585492056431883e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                          result[0] += -9.585492056431883e-05;
                        } else {
                          result[0] += -9.585492056431883e-05;
                        }
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                          result[0] += -9.585492056431883e-05;
                        } else {
                          result[0] += -9.585492056431883e-05;
                        }
                      }
                    } else {
                      result[0] += -9.585492056431883e-05;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.483243480726212482) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                      result[0] += -9.585492056431883e-05;
                    } else {
                      result[0] += -9.585492056431883e-05;
                    }
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.598708736933611707) ) ) {
                      result[0] += -9.585492056431883e-05;
                    } else {
                      result[0] += -9.585492056431883e-05;
                    }
                  }
                }
              } else {
                result[0] += -9.585492056431883e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
              result[0] += -9.585492056431883e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                  result[0] += -9.585492056431883e-05;
                } else {
                  result[0] += -9.585492056431883e-05;
                }
              } else {
                result[0] += -9.585492056431883e-05;
              }
            }
          }
        } else {
          result[0] += -0.00018267693688697053;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8850000000000001199) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3150000000000000577) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05256900000000001155) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4795216591959799435) ) ) {
              result[0] += 0.0006621750206562317;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0650000000000000161) ) ) {
                result[0] += -0.00011818797683742491;
              } else {
                result[0] += 3.0082485395610713e-05;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6754021834779359024) ) ) {
              result[0] += 0.002243001153658645;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7240686518592965859) ) ) {
                result[0] += -0.002616793528915057;
              } else {
                result[0] += 0.00029505204512047297;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.145614105386054682) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1627210000000000323) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.7650000000000001243) ) ) {
                result[0] += 0.0008968601815601288;
              } else {
                result[0] += 0.0034930493211889875;
              }
            } else {
              result[0] += 0.009660284385640379;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7894192122613066243) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007599500000000001219) ) ) {
                result[0] += 0.0009184716926174197;
              } else {
                result[0] += -0.007061128052007247;
              }
            } else {
              result[0] += 0.00010257422075057609;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007599500000000001219) ) ) {
            result[0] += 0.006640805548702905;
          } else {
            result[0] += 0.004571553596471692;
          }
        } else {
          result[0] += 0.007648338767601138;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -6.612679889467362e-05;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2323027026914575854) ) ) {
              result[0] += -0.00010666855834175116;
            } else {
              result[0] += 7.654886467599953e-05;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -8.816906519289808e-05;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.652905739716803768) ) ) {
                result[0] += -8.816906519289808e-05;
              } else {
                result[0] += -8.816906519289808e-05;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4751828078391960308) ) ) {
            result[0] += 0.0008008330152177446;
          } else {
            result[0] += -0.00012662969828434683;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                  result[0] += -8.816906519289808e-05;
                } else {
                  result[0] += -8.816906519289808e-05;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += 9.126860708345174e-06;
                } else {
                  result[0] += -8.862450672571375e-05;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06983950000000001268) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                        result[0] += -8.816906519289808e-05;
                      } else {
                        result[0] += -8.816906519289808e-05;
                      }
                    } else {
                      result[0] += -8.816906519289808e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                          result[0] += -8.816906519289808e-05;
                        } else {
                          result[0] += -8.816906519289808e-05;
                        }
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                          result[0] += -8.816906519289808e-05;
                        } else {
                          result[0] += -8.816906519289808e-05;
                        }
                      }
                    } else {
                      result[0] += -8.816906519289808e-05;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.483243480726212482) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                      result[0] += -8.816906519289808e-05;
                    } else {
                      result[0] += -8.816906519289808e-05;
                    }
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.598708736933611707) ) ) {
                      result[0] += -8.816906519289808e-05;
                    } else {
                      result[0] += -8.816906519289808e-05;
                    }
                  }
                }
              } else {
                result[0] += -8.816906519289808e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
              result[0] += -8.816906519289808e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                  result[0] += -8.816906519289808e-05;
                } else {
                  result[0] += -8.816906519289808e-05;
                }
              } else {
                result[0] += -8.816906519289808e-05;
              }
            }
          }
        } else {
          result[0] += -0.00016802950399211664;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.7350000000000000977) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09500000000000001499) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4292508528894472541) ) ) {
              result[0] += 0.0013882250647015318;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4394533747236181176) ) ) {
                result[0] += -0.0027315488086620894;
              } else {
                result[0] += -6.022264228973153e-05;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01594650000000000234) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9650000000000000799) ) ) {
                result[0] += 0.000227832216013813;
              } else {
                result[0] += 0.0009399692152751312;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7593447680904524821) ) ) {
                result[0] += 0.0020945993792664272;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5850000000000000755) ) ) {
                  result[0] += 0.0008355883792772326;
                } else {
                  result[0] += -0.0022637083312818562;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006671500000000001214) ) ) {
            result[0] += 0.0036618735977888605;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02562400000000000441) ) ) {
              result[0] += 0.0006293047328260625;
            } else {
              result[0] += 0.004453275245525907;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01243050000000000231) ) ) {
            result[0] += 0.006768579200421175;
          } else {
            result[0] += 0.0042049965166856525;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.316725863161028132) ) ) {
            result[0] += 0.0070350783814536275;
          } else {
            result[0] += -2.09515862901226e-05;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -6.082460877769929e-05;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2323027026914575854) ) ) {
              result[0] += -9.811564204631129e-05;
            } else {
              result[0] += 7.041101072669271e-05;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -8.10994783702657e-05;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.652905739716803768) ) ) {
                result[0] += -8.10994783702657e-05;
              } else {
                result[0] += -8.10994783702657e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
            result[0] += -0.00010464092552055347;
          } else {
            result[0] += 0.002619329998231824;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                  result[0] += -8.10994783702657e-05;
                } else {
                  result[0] += -8.10994783702657e-05;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += 8.395049227135175e-06;
                } else {
                  result[0] += -8.151840161345418e-05;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06983950000000001268) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                        result[0] += -8.10994783702657e-05;
                      } else {
                        result[0] += -8.10994783702657e-05;
                      }
                    } else {
                      result[0] += -8.10994783702657e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                          result[0] += -8.10994783702657e-05;
                        } else {
                          result[0] += -8.10994783702657e-05;
                        }
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                          result[0] += -8.10994783702657e-05;
                        } else {
                          result[0] += -8.10994783702657e-05;
                        }
                      }
                    } else {
                      result[0] += -8.10994783702657e-05;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.483243480726212482) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                      result[0] += -8.10994783702657e-05;
                    } else {
                      result[0] += -8.10994783702657e-05;
                    }
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.598708736933611707) ) ) {
                      result[0] += -8.10994783702657e-05;
                    } else {
                      result[0] += -8.10994783702657e-05;
                    }
                  }
                }
              } else {
                result[0] += -8.10994783702657e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
              result[0] += -8.10994783702657e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                  result[0] += -8.10994783702657e-05;
                } else {
                  result[0] += -8.10994783702657e-05;
                }
              } else {
                result[0] += -8.10994783702657e-05;
              }
            }
          }
        } else {
          result[0] += -0.00015455653402654862;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9350000000000001643) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.7650000000000001243) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05663800000000000778) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.29500000000000004) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4230630641206030718) ) ) {
                result[0] += 0.001090748369073059;
              } else {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4188836135812591954) ) ) {
                  result[0] += -0.0024163586187134554;
                } else {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3477174365476807805) ) ) {
                    result[0] += 0.001892227927249408;
                  } else {
                    result[0] += -4.6960828755481706e-05;
                  }
                }
              }
            } else {
              result[0] += 0.0005674059086118165;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6754021834779359024) ) ) {
              result[0] += 0.00284023126838585;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7136104594723619021) ) ) {
                result[0] += -0.005246519630096514;
              } else {
                result[0] += 0.00020418594441251245;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005797500000000001437) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
              result[0] += -0.0019193405337810927;
            } else {
              result[0] += 0.004811292423106097;
            }
          } else {
            result[0] += 0.002461484387668015;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01264450000000000122) ) ) {
            result[0] += 0.006225859843937678;
          } else {
            result[0] += 0.003877269190033448;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.316725863161028132) ) ) {
            result[0] += 0.00647099054278936;
          } else {
            result[0] += -1.9271642672417097e-05;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -5.5947559760951524e-05;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2323027026914575854) ) ) {
              result[0] += -9.024851712458092e-05;
            } else {
              result[0] += 6.476530321564435e-05;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -7.459674634793535e-05;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.652905739716803768) ) ) {
                result[0] += -7.459674634793535e-05;
              } else {
                result[0] += -7.459674634793535e-05;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4306236034422111225) ) ) {
            result[0] += 0.0035882140103303825;
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1464732738946245838) ) ) {
              result[0] += -0.00047785397638876393;
            } else {
              result[0] += -7.736495649379899e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                  result[0] += -7.459674634793535e-05;
                } else {
                  result[0] += -7.459674634793535e-05;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += 7.721915977262744e-06;
                } else {
                  result[0] += -7.498207941714092e-05;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06983950000000001268) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                        result[0] += -7.459674634793535e-05;
                      } else {
                        result[0] += -7.459674634793535e-05;
                      }
                    } else {
                      result[0] += -7.459674634793535e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                          result[0] += -7.459674634793535e-05;
                        } else {
                          result[0] += -7.459674634793535e-05;
                        }
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                          result[0] += -7.459674634793535e-05;
                        } else {
                          result[0] += -7.459674634793535e-05;
                        }
                      }
                    } else {
                      result[0] += -7.459674634793535e-05;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.483243480726212482) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                      result[0] += -7.459674634793535e-05;
                    } else {
                      result[0] += -7.459674634793535e-05;
                    }
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.598708736933611707) ) ) {
                      result[0] += -7.459674634793535e-05;
                    } else {
                      result[0] += -7.459674634793535e-05;
                    }
                  }
                }
              } else {
                result[0] += -7.459674634793535e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
              result[0] += -7.459674634793535e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                  result[0] += -7.459674634793535e-05;
                } else {
                  result[0] += -7.459674634793535e-05;
                }
              } else {
                result[0] += -7.459674634793535e-05;
              }
            }
          }
        } else {
          result[0] += -0.00014216385600602865;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9350000000000001643) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.7650000000000001243) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06441400000000001291) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0650000000000000161) ) ) {
              result[0] += -7.588840870427572e-05;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.09500000000000001499) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                  result[0] += -0.00019281502190946677;
                } else {
                  result[0] += 0.0028274356446534015;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.29500000000000004) ) ) {
                  result[0] += -4.018502032842698e-05;
                } else {
                  result[0] += 0.000527423849367098;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.316725863161028132) ) ) {
              result[0] += 0.0017547161429404576;
            } else {
              result[0] += -0.0009024868743875408;
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005797500000000001437) ) ) {
            result[0] += 0.004059008821436449;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.145614105386054682) ) ) {
              result[0] += 0.002666042897327329;
            } else {
              result[0] += -0.002550858282334822;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4100284358542713448) ) ) {
            if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4612588522637047217) ) ) {
              result[0] += 0.004924831204845349;
            } else {
              result[0] += -0.0028030423780213733;
            }
          } else {
            result[0] += 0.005029120691492254;
          }
        } else {
          result[0] += 0.0059521324901311455;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -5.1461563109187976e-05;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2323027026914575854) ) ) {
              result[0] += -8.30121953372264e-05;
            } else {
              result[0] += 5.957228077432221e-05;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -6.861541747891733e-05;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.652905739716803768) ) ) {
                result[0] += -6.861541747891733e-05;
              } else {
                result[0] += -6.861541747891733e-05;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4306236034422111225) ) ) {
            result[0] += 0.0033005032307194416;
          } else {
            result[0] += -9.00472992604228e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                  result[0] += -6.861541747891733e-05;
                } else {
                  result[0] += -6.861541747891733e-05;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += 7.102756010908332e-06;
                } else {
                  result[0] += -6.896985370712293e-05;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06983950000000001268) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                        result[0] += -6.861541747891733e-05;
                      } else {
                        result[0] += -6.861541747891733e-05;
                      }
                    } else {
                      result[0] += -6.861541747891733e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                          result[0] += -6.861541747891733e-05;
                        } else {
                          result[0] += -6.861541747891733e-05;
                        }
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                          result[0] += -6.861541747891733e-05;
                        } else {
                          result[0] += -6.861541747891733e-05;
                        }
                      }
                    } else {
                      result[0] += -6.861541747891733e-05;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.483243480726212482) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                      result[0] += -6.861541747891733e-05;
                    } else {
                      result[0] += -6.861541747891733e-05;
                    }
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.598708736933611707) ) ) {
                      result[0] += -6.861541747891733e-05;
                    } else {
                      result[0] += -6.861541747891733e-05;
                    }
                  }
                }
              } else {
                result[0] += -6.861541747891733e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
              result[0] += -6.861541747891733e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                  result[0] += -6.861541747891733e-05;
                } else {
                  result[0] += -6.861541747891733e-05;
                }
              } else {
                result[0] += -6.861541747891733e-05;
              }
            }
          }
        } else {
          result[0] += -0.0001307648497800243;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9350000000000001643) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.7650000000000001243) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06441400000000001291) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0650000000000000161) ) ) {
              result[0] += -6.980351154683714e-05;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.496729916098519464) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.09500000000000001499) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                    result[0] += -0.0001827164727446377;
                  } else {
                    result[0] += 0.002883453542576193;
                  }
                } else {
                  result[0] += 0.0002435711942294279;
                }
              } else {
                result[0] += -0.0022816741705657608;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9993516786272610419) ) ) {
              result[0] += 0.0022225870307237203;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7496778360301509236) ) ) {
                result[0] += -0.005113256281360467;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5350000000000001421) ) ) {
                  result[0] += 0.0003993630098716756;
                } else {
                  result[0] += -0.004456298960217632;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006546500000000001103) ) ) {
            result[0] += 0.0037081517112924904;
          } else {
            result[0] += 0.0020457025957615993;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4100284358542713448) ) ) {
            if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4314418144595498217) ) ) {
              result[0] += 0.0036282471399322375;
            } else {
              result[0] += -0.005457050337764543;
            }
          } else {
            result[0] += 0.004625874889892605;
          }
        } else {
          result[0] += 0.005474877601166045;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -4.733526339587209e-05;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2323027026914575854) ) ) {
              result[0] += -7.635609752117389e-05;
            } else {
              result[0] += 5.47956461322864e-05;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -6.311368452782955e-05;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.652905739716803768) ) ) {
                result[0] += -6.311368452782955e-05;
              } else {
                result[0] += -6.311368452782955e-05;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4306236034422111225) ) ) {
            result[0] += 0.003035861725256035;
          } else {
            result[0] += -8.282711155771368e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                  result[0] += -6.311368452782955e-05;
                } else {
                  result[0] += -6.311368452782955e-05;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += 6.533241633170134e-06;
                } else {
                  result[0] += -6.343970129073966e-05;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06983950000000001268) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                        result[0] += -6.311368452782955e-05;
                      } else {
                        result[0] += -6.311368452782955e-05;
                      }
                    } else {
                      result[0] += -6.311368452782955e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                          result[0] += -6.311368452782955e-05;
                        } else {
                          result[0] += -6.311368452782955e-05;
                        }
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                          result[0] += -6.311368452782955e-05;
                        } else {
                          result[0] += -6.311368452782955e-05;
                        }
                      }
                    } else {
                      result[0] += -6.311368452782955e-05;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.483243480726212482) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                      result[0] += -6.311368452782955e-05;
                    } else {
                      result[0] += -6.311368452782955e-05;
                    }
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.598708736933611707) ) ) {
                      result[0] += -6.311368452782955e-05;
                    } else {
                      result[0] += -6.311368452782955e-05;
                    }
                  }
                }
              } else {
                result[0] += -6.311368452782955e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
              result[0] += -6.311368452782955e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                  result[0] += -6.311368452782955e-05;
                } else {
                  result[0] += -6.311368452782955e-05;
                }
              } else {
                result[0] += -6.311368452782955e-05;
              }
            }
          }
        } else {
          result[0] += -0.00012027984058948989;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9450000000000000622) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3150000000000000577) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4230630641206030718) ) ) {
            result[0] += 0.0009990254446425161;
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4188836135812591954) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1750000000000000167) ) ) {
                result[0] += -0.0026796726279682613;
              } else {
                result[0] += 0.0006607380321014953;
              }
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3477174365476807805) ) ) {
                result[0] += 0.0021251166334390146;
              } else {
                result[0] += -1.8167654356520924e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8050000000000001599) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.145614105386054682) ) ) {
              result[0] += 0.0007585918489461407;
            } else {
              result[0] += -0.0004575353983557796;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005358500000000001283) ) ) {
              result[0] += 0.003915982027162726;
            } else {
              result[0] += 0.0018996850255163626;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4100284358542713448) ) ) {
            if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4612588522637047217) ) ) {
              result[0] += 0.004654038604642418;
            } else {
              result[0] += -0.002530547221580617;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01264450000000000122) ) ) {
              result[0] += 0.005595802437309937;
            } else {
              result[0] += 0.0035757612323311294;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.075834742120705068) ) ) {
            result[0] += 0.005837710962172782;
          } else {
            result[0] += 0.0009232881013789918;
          }
        }
      }
    }
  }
}

