
#include "header.h"

void predict_unit14(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -1.034246455500991e-06;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6299505656030152112) ) ) {
            result[0] += 3.701372892282877e-08;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.2928080573359248e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                result[0] += 1.4281591204088992e-08;
              } else {
                result[0] += -1.2928080573359248e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001776826981475250261) ) ) {
            result[0] += 9.13317121262733e-06;
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2867376717052229629) ) ) {
              result[0] += -4.035860712271318e-05;
            } else {
              result[0] += 8.109779599295791e-07;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -1.2928080573359248e-06;
                } else {
                  result[0] += -1.2928080573359248e-06;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -1.2720328596507211e-06;
                } else {
                  result[0] += -1.2928080573359248e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -1.2928080573359248e-06;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -1.2928080573359248e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -1.2928080573359248e-06;
                      } else {
                        result[0] += -1.2928080573359248e-06;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -1.2928080573359248e-06;
                      } else {
                        result[0] += -1.2928080573359248e-06;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.310012234630710122e-06) ) ) {
                            result[0] += -1.2928080573359248e-06;
                          } else {
                            result[0] += -1.2928080573359248e-06;
                          }
                        } else {
                          result[0] += -1.2928080573359248e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -1.2928080573359248e-06;
                        } else {
                          result[0] += -1.2928080573359248e-06;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -1.2928080573359248e-06;
                    } else {
                      result[0] += -1.2928080573359248e-06;
                    }
                  }
                }
              } else {
                result[0] += -1.2928080573359248e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -1.2928080573359248e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -1.2928080573359248e-06;
                  } else {
                    result[0] += -1.2928080573359248e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -1.2928080573359248e-06;
                  } else {
                    result[0] += -1.2928080573359248e-06;
                  }
                }
              } else {
                result[0] += -1.2928080573359248e-06;
              }
            }
          }
        } else {
          result[0] += 4.616533661103583e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1773295000000000288) ) ) {
            result[0] += 1.4380119843394914e-05;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03291917222295825951) ) ) {
              result[0] += -0.0022774444307818854;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05964584249592785187) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6518611175125629265) ) ) {
                  result[0] += 0.0018046754266217693;
                } else {
                  result[0] += 0.0005330108228327587;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7890731911809046872) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6002102120603015623) ) ) {
                      result[0] += -0.00026141014975473623;
                    } else {
                      result[0] += 0.001858749835560671;
                    }
                  } else {
                    result[0] += -0.000575432022624243;
                  }
                } else {
                  result[0] += 0.0011514987522313837;
                }
              }
            }
          }
        } else {
          result[0] += 0.0006077809622670107;
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 9.593335140927969e-05;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4601878067544193374) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4129968667336683663) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5470680148669562204) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3644118032412060892) ) ) {
                    if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7572008430306190752) ) ) {
                      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7983975536720421262) ) ) {
                        result[0] += 7.070732110613643e-05;
                      } else {
                        result[0] += 0.00015089325102928536;
                      }
                    } else {
                      result[0] += -0.00023253267564390723;
                    }
                  } else {
                    result[0] += 0.00016106028919337886;
                  }
                } else {
                  result[0] += -0.00019486569435279286;
                }
              } else {
                result[0] += 0.00014285572388625058;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4052145559547739029) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4133512684738382403) ) ) {
                  result[0] += 5.2692580302074226e-05;
                } else {
                  result[0] += -0.0015088768297271396;
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1828583041203602211) ) ) {
                    result[0] += 0.0001682195402611152;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.51994285276381913) ) ) {
                      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.04779931491322893938) ) ) {
                        result[0] += -1.915987435527602e-05;
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.020650504707780553) ) ) {
                          result[0] += -0.0008867879363638868;
                        } else {
                          result[0] += -0.00010750101628835586;
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08407783631914581002) ) ) {
                        result[0] += 0.0002285909320615207;
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5499504253266332965) ) ) {
                          result[0] += -0.0015546720636985512;
                        } else {
                          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3665106630729573767) ) ) {
                            result[0] += 0.00023155616994681002;
                          } else {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6100010069597990858) ) ) {
                              result[0] += -0.0007719076041044594;
                            } else {
                              result[0] += 1.836102623253134e-05;
                            }
                          }
                        }
                      }
                    }
                  }
                } else {
                  result[0] += 0.00010944918883568555;
                }
              }
            }
          } else {
            result[0] += 0.00011054254400337941;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -9.895533284187738e-07;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6299505656030152112) ) ) {
            result[0] += 3.5414246244656e-08;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.2369416490034307e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                result[0] += 1.3664437558334699e-08;
              } else {
                result[0] += -1.2369416490034307e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001776826981475250261) ) ) {
            result[0] += 8.73849740978398e-06;
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2867376717052229629) ) ) {
              result[0] += -3.8614581462868116e-05;
            } else {
              result[0] += 7.759329850773486e-07;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -1.2369416490034307e-06;
                } else {
                  result[0] += -1.2369416490034307e-06;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -1.217064214656322e-06;
                } else {
                  result[0] += -1.2369416490034307e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -1.2369416490034307e-06;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -1.2369416490034307e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -1.2369416490034307e-06;
                      } else {
                        result[0] += -1.2369416490034307e-06;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -1.2369416490034307e-06;
                      } else {
                        result[0] += -1.2369416490034307e-06;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.310012234630710122e-06) ) ) {
                            result[0] += -1.2369416490034307e-06;
                          } else {
                            result[0] += -1.2369416490034307e-06;
                          }
                        } else {
                          result[0] += -1.2369416490034307e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -1.2369416490034307e-06;
                        } else {
                          result[0] += -1.2369416490034307e-06;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -1.2369416490034307e-06;
                    } else {
                      result[0] += -1.2369416490034307e-06;
                    }
                  }
                }
              } else {
                result[0] += -1.2369416490034307e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -1.2369416490034307e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -1.2369416490034307e-06;
                  } else {
                    result[0] += -1.2369416490034307e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -1.2369416490034307e-06;
                  } else {
                    result[0] += -1.2369416490034307e-06;
                  }
                }
              } else {
                result[0] += -1.2369416490034307e-06;
              }
            }
          }
        } else {
          result[0] += 4.4170383430411424e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07316210697219156789) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06949760265420222571) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1773295000000000288) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3103100527046326884) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4636504894974874946) ) ) {
                    result[0] += 9.134259668285046e-05;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4931942899748744114) ) ) {
                      result[0] += 0.0009757698696552117;
                    } else {
                      result[0] += -0.0006694899612331132;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4529241356532663354) ) ) {
                      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1189475733471909297) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4295075599497487628) ) ) {
                          result[0] += -0.00024345778760845538;
                        } else {
                          result[0] += 0.0005771750448195619;
                        }
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.07274795227358500649) ) ) {
                          result[0] += -0.0008829215844090244;
                        } else {
                          result[0] += 0.00024027466244485508;
                        }
                      }
                    } else {
                      result[0] += -0.0008308955065898954;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4643511832914573034) ) ) {
                      result[0] += 0.000939410078687802;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4674830972361809223) ) ) {
                        result[0] += -0.0006913290527193828;
                      } else {
                        result[0] += -4.422803084086296e-06;
                      }
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03291917222295825951) ) ) {
                  result[0] += -0.0021790287071153627;
                } else {
                  result[0] += 0.0008500673274550346;
                }
              }
            } else {
              result[0] += -0.0006366721983870261;
            }
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6782348568386622478) ) ) {
              result[0] += -0.0008740090405051143;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5493276582412061071) ) ) {
                  result[0] += 0.00018229927096360195;
                } else {
                  result[0] += 0.0006007428296537566;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5628434130653267031) ) ) {
                  result[0] += -0.0013512434731624598;
                } else {
                  result[0] += 7.341127139286782e-05;
                }
              }
            }
          }
        } else {
          result[0] += 0.0005815167854450518;
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 9.178776169693157e-05;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4601878067544193374) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4129968667336683663) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5470680148669562204) ) ) {
                  result[0] += 0.0001155973679158169;
                } else {
                  result[0] += -0.00018644491882549506;
                }
              } else {
                result[0] += 0.00013668246703038673;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3931761618090452437) ) ) {
                result[0] += -0.0007220420634499732;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2302999793555680907) ) ) {
                    result[0] += 0.00016123929876477215;
                  } else {
                    result[0] += 2.276269497732504e-05;
                  }
                } else {
                  result[0] += 0.00010471953616956889;
                }
              }
            }
          } else {
            result[0] += 0.00010576564393197286;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -9.467915355922523e-07;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6299505656030152112) ) ) {
            result[0] += 3.3883882374888315e-08;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.18348940846813e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.016289495364576286e-06) ) ) {
                  result[0] += 1.3073953113303552e-08;
                } else {
                  result[0] += -1.9855199379880507e-05;
                }
              } else {
                result[0] += -1.18348940846813e-06;
              }
            }
          }
        } else {
          result[0] += 5.258166910475111e-07;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -1.18348940846813e-06;
                } else {
                  result[0] += -1.18348940846813e-06;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -1.1644709422079981e-06;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0110643527143887508) ) ) {
                    result[0] += -1.18348940846813e-06;
                  } else {
                    result[0] += -1.6333757786028513e-06;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -1.18348940846813e-06;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -1.18348940846813e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -1.18348940846813e-06;
                      } else {
                        result[0] += -1.18348940846813e-06;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -1.18348940846813e-06;
                      } else {
                        result[0] += -1.18348940846813e-06;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.310012234630710122e-06) ) ) {
                            result[0] += -1.18348940846813e-06;
                          } else {
                            result[0] += -1.18348940846813e-06;
                          }
                        } else {
                          result[0] += -1.18348940846813e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -1.18348940846813e-06;
                        } else {
                          result[0] += -1.18348940846813e-06;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -1.18348940846813e-06;
                    } else {
                      result[0] += -1.18348940846813e-06;
                    }
                  }
                }
              } else {
                result[0] += -1.18348940846813e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -1.18348940846813e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -1.18348940846813e-06;
                  } else {
                    result[0] += -1.18348940846813e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -1.18348940846813e-06;
                  } else {
                    result[0] += -1.18348940846813e-06;
                  }
                }
              } else {
                result[0] += -1.18348940846813e-06;
              }
            }
          }
        } else {
          result[0] += 4.2261638614873033e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1773295000000000288) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.175366324986798601e-07) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6750000000000001554) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.186721136015642994e-07) ) ) {
                  result[0] += 0.00013199186707824482;
                } else {
                  result[0] += -0.00020869636858977675;
                }
              } else {
                result[0] += -0.0037947607221907494;
              }
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.9159493641278110276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01376440091032050082) ) ) {
                  result[0] += 0.0009596186293964518;
                } else {
                  result[0] += -0.00019406428792616558;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2929122217587940002) ) ) {
                  result[0] += -0.0032423880180900916;
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7983975536720421262) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3044676633919599085) ) ) {
                      result[0] += 0.0008872985003686158;
                    } else {
                      result[0] += -0.0009472821045679437;
                    }
                  } else {
                    result[0] += 2.05573517737012e-05;
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03291917222295825951) ) ) {
              result[0] += -0.0020848658444775864;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05964584249592785187) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6518611175125629265) ) ) {
                  result[0] += 0.0016899554247812717;
                } else {
                  result[0] += 0.0004732435524624351;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7890731911809046872) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6002102120603015623) ) ) {
                      result[0] += -0.00026703266166406783;
                    } else {
                      result[0] += 0.0017752549186217526;
                    }
                  } else {
                    result[0] += -0.0005445324926920716;
                  }
                } else {
                  result[0] += 0.0010952100507501709;
                }
              }
            }
          }
        } else {
          result[0] += 0.0005563875684638253;
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 8.78213162947783e-05;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4601878067544193374) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4129968667336683663) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5470680148669562204) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02366047096071570086) ) ) {
                    result[0] += -8.445815166298647e-07;
                  } else {
                    result[0] += 0.0001166020357940544;
                  }
                } else {
                  result[0] += -0.0001783880321844213;
                }
              } else {
                result[0] += 0.00013077597652572047;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3931761618090452437) ) ) {
                result[0] += -0.0006908402957002772;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1706267463716274191) ) ) {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2302999793555680907) ) ) {
                    if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.294841568336650095) ) ) {
                      result[0] += 0.0001390342221372453;
                    } else {
                      result[0] += 0.0001623115435722336;
                    }
                  } else {
                    result[0] += 2.157701418301086e-05;
                  }
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.01537695356895864805) ) ) {
                    result[0] += 0.00010019426705878384;
                  } else {
                    result[0] += 0.00011224963839223763;
                  }
                }
              }
            }
          } else {
            result[0] += 0.0001011951691287548;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -9.05877617835473e-07;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6299505656030152112) ) ) {
            result[0] += 3.241965046675298e-08;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.132347011748458e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                result[0] += 1.2508985406764953e-08;
              } else {
                result[0] += -1.132347011748458e-06;
              }
            }
          }
        } else {
          result[0] += 5.81851784447263e-07;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -1.132347011748458e-06;
                } else {
                  result[0] += -1.132347011748458e-06;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -1.114150394792186e-06;
                } else {
                  result[0] += -1.132347011748458e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -1.132347011748458e-06;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -1.132347011748458e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -1.132347011748458e-06;
                      } else {
                        result[0] += -1.132347011748458e-06;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -1.132347011748458e-06;
                      } else {
                        result[0] += -1.132347011748458e-06;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -1.132347011748458e-06;
                        } else {
                          result[0] += -1.132347011748458e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -1.132347011748458e-06;
                        } else {
                          result[0] += -1.132347011748458e-06;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -1.132347011748458e-06;
                    } else {
                      result[0] += -1.132347011748458e-06;
                    }
                  }
                }
              } else {
                result[0] += -1.132347011748458e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -1.132347011748458e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -1.132347011748458e-06;
                  } else {
                    result[0] += -1.132347011748458e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -1.132347011748458e-06;
                  } else {
                    result[0] += -1.132347011748458e-06;
                  }
                }
              } else {
                result[0] += -1.132347011748458e-06;
              }
            }
          }
        } else {
          result[0] += 4.0435376822752014e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
            result[0] += 0.00039658439185957794;
          } else {
            result[0] += 8.402627379903973e-05;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03603011311338780859) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.316132418552224348) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4931942899748744114) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4052145559547739029) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001504690974371400121) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3644118032412060892) ) ) {
                      result[0] += -5.779838299122653e-05;
                    } else {
                      result[0] += -0.0007112596298146104;
                    }
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00421750000000000163) ) ) {
                      result[0] += 0.00019132361499360966;
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01657900000000000346) ) ) {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02261952378991480619) ) ) {
                          result[0] += -0.0010663137329319503;
                        } else {
                          result[0] += 0.00013624898767553758;
                        }
                      } else {
                        result[0] += 0.0006039092637310622;
                      }
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001841500000000000255) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.835029170797551251e-06) ) ) {
                      result[0] += 0.000979713680606648;
                    } else {
                      result[0] += -0.0003483358528797021;
                    }
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002289500000000000302) ) ) {
                      result[0] += 0.0021507450764740423;
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001939744889791500219) ) ) {
                        result[0] += 0.0021577060728083055;
                      } else {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4575776583165829803) ) ) {
                          result[0] += 0.00014387356837858805;
                        } else {
                          result[0] += 0.0009720875854258999;
                        }
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.0008020739443621145;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4295075599497487628) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003024500000000000712) ) ) {
                  result[0] += 0.00033773586602174556;
                } else {
                  result[0] += -0.0014175710993373871;
                }
              } else {
                result[0] += -6.130647421118356e-06;
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.243144592614154248) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05439750000000000835) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04689300000000001106) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.8537219630417757221) ) ) {
                      result[0] += -0.0020684306604492496;
                    } else {
                      result[0] += 5.862845153929465e-05;
                    }
                  } else {
                    result[0] += 0.00011306496666697836;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5499504253266332965) ) ) {
                    result[0] += -0.0007201249791375929;
                  } else {
                    result[0] += 0.00023887269786161997;
                  }
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5400528323115579843) ) ) {
                  if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.02125964230697484705) ) ) {
                    result[0] += 0.00010859643274575415;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.020650504707780553) ) ) {
                      result[0] += -0.0021368587956427983;
                    } else {
                      result[0] += 0.00013535569688115517;
                    }
                  }
                } else {
                  result[0] += 0.0002565462036858681;
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5748180127889448432) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8550000000000000933) ) ) {
                  result[0] += -0.00043199367088379907;
                } else {
                  result[0] += -0.0028176403496115734;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2739990068871500095) ) ) {
                  result[0] += -0.0008562554337769311;
                } else {
                  result[0] += 7.88098036117083e-05;
                }
              }
            }
          }
        }
      } else {
        result[0] += 9.682219929170621e-05;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -8.667317225031642e-07;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6299505656030152112) ) ) {
            result[0] += 3.1018692744765533e-08;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.0834146430387684e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                result[0] += 1.1968431778100526e-08;
              } else {
                result[0] += -1.0834146430387684e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001776826981475250261) ) ) {
            result[0] += 8.313012806145308e-06;
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2867376717052229629) ) ) {
              result[0] += -3.6993786709653304e-05;
            } else {
              result[0] += 6.9453648717117e-07;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -1.0834146430387684e-06;
                } else {
                  result[0] += -1.0834146430387684e-06;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -1.066004360625649e-06;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0110643527143887508) ) ) {
                    result[0] += -1.0834146430387684e-06;
                  } else {
                    result[0] += -1.513859971238028e-06;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -1.0834146430387684e-06;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -1.0834146430387684e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -1.0834146430387684e-06;
                      } else {
                        result[0] += -1.0834146430387684e-06;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -1.0834146430387684e-06;
                      } else {
                        result[0] += -1.0834146430387684e-06;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.310012234630710122e-06) ) ) {
                            result[0] += -1.0834146430387684e-06;
                          } else {
                            result[0] += -1.0834146430387684e-06;
                          }
                        } else {
                          result[0] += -1.0834146430387684e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -1.0834146430387684e-06;
                        } else {
                          result[0] += -1.0834146430387684e-06;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -1.0834146430387684e-06;
                    } else {
                      result[0] += -1.0834146430387684e-06;
                    }
                  }
                }
              } else {
                result[0] += -1.0834146430387684e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -1.0834146430387684e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -1.0834146430387684e-06;
                  } else {
                    result[0] += -1.0834146430387684e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -1.0834146430387684e-06;
                  } else {
                    result[0] += -1.0834146430387684e-06;
                  }
                }
              } else {
                result[0] += -1.0834146430387684e-06;
              }
            }
          }
        } else {
          result[0] += 3.86880336964157e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1773295000000000288) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1050000000000000239) ) ) {
              result[0] += -1.3220370966355518e-05;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.115000000000000005) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002295101748406000225) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7211604863065327331) ) ) {
                    result[0] += -1.0267842985904113e-05;
                  } else {
                    result[0] += -0.0007323665735224033;
                  }
                } else {
                  result[0] += 0.0014156046911153672;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.039722088301102687) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7983409114572864729) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6722423356281408413) ) ) {
                        result[0] += -7.530974868193174e-07;
                      } else {
                        result[0] += 0.0002215217295678281;
                      }
                    } else {
                      result[0] += -0.001242184886332335;
                    }
                  } else {
                    result[0] += 0.0007127630781678028;
                  }
                } else {
                  result[0] += -0.00019334602326927307;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7983409114572864729) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8030059940338053481) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03469629566125685682) ) ) {
                  result[0] += -0.002036432215651051;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05964584249592785187) ) ) {
                    result[0] += 0.0013749972678653796;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6002102120603015623) ) ) {
                      result[0] += -0.00022736976591199065;
                    } else {
                      result[0] += 0.0017708268059813622;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6150000000000001021) ) ) {
                  result[0] += 2.5346979149544672e-05;
                } else {
                  result[0] += -0.0015988920829120626;
                }
              }
            } else {
              result[0] += 0.0011285690861352216;
            }
          }
        } else {
          result[0] += 0.0005281602663479883;
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 8.039522733697931e-05;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2302999793555680907) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2929122217587940002) ) ) {
                result[0] += -0.00015822024997305271;
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.8537219630417757221) ) ) {
                  result[0] += -0.00012428616713969855;
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6269304705026225166) ) ) {
                    result[0] += 0.0001252837494424472;
                  } else {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5724391781153673753) ) ) {
                      result[0] += -0.0004075302192661578;
                    } else {
                      result[0] += 0.00012244074312730494;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4737195465326633492) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1251234928765115051) ) ) {
                  result[0] += -0.0011069925073777904;
                } else {
                  result[0] += 0.00021616551675464468;
                }
              } else {
                result[0] += 8.120076219562365e-05;
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
              result[0] += 9.152313780099995e-05;
            } else {
              result[0] += 9.26381995938475e-05;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -8.292774476405612e-07;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6299505656030152112) ) ) {
            result[0] += 2.9678274927142846e-08;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.0365967998965053e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                result[0] += 1.1451237216215748e-08;
              } else {
                result[0] += -1.0365967998965053e-06;
              }
            }
          }
        } else {
          result[0] += 1.9747597980980248e-07;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -1.0365967998965053e-06;
                } else {
                  result[0] += -1.0365967998965053e-06;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -1.0199388719732547e-06;
                } else {
                  result[0] += -1.0365967998965053e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -1.0365967998965053e-06;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -1.0365967998965053e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -1.0365967998965053e-06;
                      } else {
                        result[0] += -1.0365967998965053e-06;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -1.0365967998965053e-06;
                      } else {
                        result[0] += -1.0365967998965053e-06;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.310012234630710122e-06) ) ) {
                            result[0] += -1.0365967998965053e-06;
                          } else {
                            result[0] += -1.0365967998965053e-06;
                          }
                        } else {
                          result[0] += -1.0365967998965053e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -1.0365967998965053e-06;
                        } else {
                          result[0] += -1.0365967998965053e-06;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -1.0365967998965053e-06;
                    } else {
                      result[0] += -1.0365967998965053e-06;
                    }
                  }
                }
              } else {
                result[0] += -1.0365967998965053e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -1.0365967998965053e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -1.0365967998965053e-06;
                  } else {
                    result[0] += -1.0365967998965053e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -1.0365967998965053e-06;
                  } else {
                    result[0] += -1.0365967998965053e-06;
                  }
                }
              } else {
                result[0] += -1.0365967998965053e-06;
              }
            }
          }
        } else {
          result[0] += 3.7016198905627696e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05473596564878090848) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3103100527046326884) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01021941412521685209) ) ) {
              result[0] += 6.162276493063329e-06;
            } else {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4026472078210281969) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4405029099497487777) ) ) {
                  result[0] += 0.0003777829903299221;
                } else {
                  result[0] += -0.00484125083433499;
                }
              } else {
                result[0] += 0.0007427884910767854;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004054500000000000812) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1189475733471909297) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4529241356532663354) ) ) {
                    result[0] += 0.0007911788884710019;
                  } else {
                    result[0] += -0.0003427331737031068;
                  }
                } else {
                  result[0] += -0.0008374621807206308;
                }
              } else {
                result[0] += -0.0012230845082606768;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4643511832914573034) ) ) {
                result[0] += 0.0008924489844971938;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4751828078391960308) ) ) {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2302999793555680907) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4650000000000000244) ) ) {
                      result[0] += -0.0005961382067889135;
                    } else {
                      result[0] += 0.001536500648567173;
                    }
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1750000000000000167) ) ) {
                      result[0] += 0.00038739813537845807;
                    } else {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003292500000000000288) ) ) {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001134500000000000309) ) ) {
                          result[0] += -0.0015465354616496796;
                        } else {
                          result[0] += -0.002135956534590744;
                        }
                      } else {
                        result[0] += -0.0006002044678912579;
                      }
                    }
                  }
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2672247508226724966) ) ) {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2795185878002977575) ) ) {
                      result[0] += 0.00027465821640227175;
                    } else {
                      result[0] += -0.0022189817896943256;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4797597438944724013) ) ) {
                      result[0] += 0.0008915653277168521;
                    } else {
                      result[0] += -2.5420216942226093e-06;
                    }
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2929122217587940002) ) ) {
            result[0] += -0.0019681686137778594;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
              result[0] += 0.00022581181889959524;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08666957264163686891) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                  result[0] += -0.001507122203074659;
                } else {
                  result[0] += 0.00010529123473593177;
                }
              } else {
                result[0] += 8.154157713369389e-05;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 7.692109011072746e-05;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2302999793555680907) ) ) {
              result[0] += 0.00011624762908107375;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4088125000000000786) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
                  result[0] += -0.001593923298475768;
                } else {
                  result[0] += 0.00010036603881535194;
                }
              } else {
                result[0] += -0.00036530078192689464;
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
              result[0] += 8.756812765138814e-05;
            } else {
              result[0] += 8.863500402562043e-05;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -7.934416928679064e-07;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6299505656030152112) ) ) {
            result[0] += 2.8395780889241778e-08;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -9.918021068478626e-07;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                result[0] += 1.0956392300450243e-08;
              } else {
                result[0] += -9.918021068478626e-07;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001776826981475250261) ) ) {
            result[0] += 7.94524712049118e-06;
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2867376717052229629) ) ) {
              result[0] += -3.5403699373255516e-05;
            } else {
              result[0] += 6.559897497531419e-07;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -9.918021068478626e-07;
                } else {
                  result[0] += -9.918021068478626e-07;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -9.758640217489606e-07;
                } else {
                  result[0] += -9.918021068478626e-07;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -9.918021068478626e-07;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -9.918021068478626e-07;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -9.918021068478626e-07;
                      } else {
                        result[0] += -9.918021068478626e-07;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -9.918021068478626e-07;
                      } else {
                        result[0] += -9.918021068478626e-07;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.310012234630710122e-06) ) ) {
                            result[0] += -9.918021068478626e-07;
                          } else {
                            result[0] += -9.918021068478626e-07;
                          }
                        } else {
                          result[0] += -9.918021068478626e-07;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -9.918021068478626e-07;
                        } else {
                          result[0] += -9.918021068478626e-07;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -9.918021068478626e-07;
                    } else {
                      result[0] += -9.918021068478626e-07;
                    }
                  }
                }
              } else {
                result[0] += -9.918021068478626e-07;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -9.918021068478626e-07;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -9.918021068478626e-07;
                  } else {
                    result[0] += -9.918021068478626e-07;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -9.918021068478626e-07;
                  } else {
                    result[0] += -9.918021068478626e-07;
                  }
                }
              } else {
                result[0] += -9.918021068478626e-07;
              }
            }
          }
        } else {
          result[0] += 3.541660949152701e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02577363736079425413) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2646519339949748861) ) ) {
            result[0] += 0.000906508778479162;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03312950000000000617) ) ) {
              result[0] += 5.945020234006741e-06;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01467829982783020078) ) ) {
                result[0] += -0.00029307489996454304;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01881166515770610337) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                    result[0] += 0.0007049732391776381;
                  } else {
                    result[0] += -0.00024809377184799823;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.039722088301102687) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8440161800932387548) ) ) {
                      result[0] += -0.0003321955145405984;
                    } else {
                      result[0] += -0.0009928715561942374;
                    }
                  } else {
                    result[0] += 0.0006929131130427309;
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02120250000000000259) ) ) {
            result[0] += -1.877364190413323e-05;
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5499504253266332965) ) ) {
                  result[0] += 0.0009319613777295404;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5792515097236182742) ) ) {
                    result[0] += 0.0023570955416832825;
                  } else {
                    result[0] += 7.569893705319035e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.314196657149456993) ) ) {
                  result[0] += 0.0001931340861757865;
                } else {
                  result[0] += -0.00034754003497506844;
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4093335132160804135) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.469327283602055445) ) ) {
                  result[0] += -0.00014263186062827302;
                } else {
                  result[0] += -0.0030783818114522676;
                }
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                  result[0] += 0.0007894010757000183;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6116569490452262725) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.590591194899497629) ) ) {
                      result[0] += -0.00022834499720300705;
                    } else {
                      result[0] += -0.0022540110369439962;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6553322322110554099) ) ) {
                      result[0] += 0.001150574585636341;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7077536600502513098) ) ) {
                        result[0] += -0.0012819089874051253;
                      } else {
                        result[0] += 0.0002454410836105068;
                      }
                    }
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 7.35970815658236e-05;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1828583041203602211) ) ) {
              result[0] += 0.00011141364253549162;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.51994285276381913) ) ) {
                result[0] += -0.00016894121526211654;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5309997332914574431) ) ) {
                  result[0] += 0.00026440374041434406;
                } else {
                  result[0] += 6.934535263583658e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
              result[0] += 8.378402625402545e-05;
            } else {
              result[0] += 8.480479945708268e-05;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -7.59154516708769e-07;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6299505656030152112) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5309997332914574431) ) ) {
              result[0] += -8.713311343704376e-05;
            } else {
              result[0] += 2.716870755760782e-08;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -9.489431370481459e-07;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.016289495364576286e-06) ) ) {
                  result[0] += 1.0482931230467987e-08;
                } else {
                  result[0] += -1.8999218191771134e-05;
                }
              } else {
                result[0] += -9.489431370481459e-07;
              }
            }
          }
        } else {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3721023948335018816) ) ) {
            result[0] += -3.361936037540019e-05;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4781247323869347032) ) ) {
              result[0] += 0.0009461993495216896;
            } else {
              result[0] += -3.856260416075234e-06;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -9.489431370481459e-07;
                } else {
                  result[0] += -9.489431370481459e-07;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -9.336937880420621e-07;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0110643527143887508) ) ) {
                    result[0] += -9.489431370481459e-07;
                  } else {
                    result[0] += -1.3607875334744796e-06;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -9.489431370481459e-07;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -9.489431370481459e-07;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -9.489431370481459e-07;
                      } else {
                        result[0] += -9.489431370481459e-07;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -9.489431370481459e-07;
                      } else {
                        result[0] += -9.489431370481459e-07;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.310012234630710122e-06) ) ) {
                            result[0] += -9.489431370481459e-07;
                          } else {
                            result[0] += -9.489431370481459e-07;
                          }
                        } else {
                          result[0] += -9.489431370481459e-07;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -9.489431370481459e-07;
                        } else {
                          result[0] += -9.489431370481459e-07;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -9.489431370481459e-07;
                    } else {
                      result[0] += -9.489431370481459e-07;
                    }
                  }
                }
              } else {
                result[0] += -9.489431370481459e-07;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -9.489431370481459e-07;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -9.489431370481459e-07;
                  } else {
                    result[0] += -9.489431370481459e-07;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -9.489431370481459e-07;
                  } else {
                    result[0] += -9.489431370481459e-07;
                  }
                }
              } else {
                result[0] += -9.489431370481459e-07;
              }
            }
          }
        } else {
          result[0] += 3.388614349823531e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1773295000000000288) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5361772370603016258) ) ) {
            result[0] += 8.315608626482729e-05;
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.07196201389915944657) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5400528323115579843) ) ) {
                result[0] += -0.001861236104242132;
              } else {
                result[0] += -0.00035790258929972236;
              }
            } else {
              result[0] += 2.7015592866184045e-07;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7983409114572864729) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8030059940338053481) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03469629566125685682) ) ) {
                result[0] += -0.001959717600057091;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05964584249592785187) ) ) {
                  result[0] += 0.001279443502156316;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5920309527638191183) ) ) {
                    result[0] += -0.0001296019054143224;
                  } else {
                    result[0] += 0.001654477992864868;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6150000000000001021) ) ) {
                result[0] += 8.533077481649703e-05;
              } else {
                result[0] += -0.0015302451583731754;
              }
            }
          } else {
            result[0] += 0.001107358050825988;
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 7.041671415744732e-05;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4601878067544193374) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1604180000000000328) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1050145000000000106) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2929122217587940002) ) ) {
                      result[0] += -3.905620884335741e-05;
                    } else {
                      result[0] += 0.00010585484093352867;
                    }
                  } else {
                    result[0] += 8.401863827233353e-05;
                  }
                } else {
                  result[0] += -0.00019300219895890318;
                }
              } else {
                result[0] += 0.00013341730153814999;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3931761618090452437) ) ) {
                result[0] += -0.0006239653125925257;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3251271839107726103) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1706267463716274191) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4088125000000000786) ) ) {
                      result[0] += 0.00012704715697672012;
                    } else {
                      result[0] += -0.0003927128216232336;
                    }
                  } else {
                    result[0] += 8.547404166083026e-05;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0435660000000000075) ) ) {
                    result[0] += 8.192521701016963e-05;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4868404241646586694) ) ) {
                      result[0] += -0.00037736948549323417;
                    } else {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08720350000000000323) ) ) {
                        result[0] += -0.0003502869646962722;
                      } else {
                        result[0] += 0.00012782490659025864;
                      }
                    }
                  }
                }
              }
            }
          } else {
            result[0] += 8.114011038886489e-05;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -7.263490000837727e-07;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6299505656030152112) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5309997332914574431) ) ) {
              result[0] += -8.191495462546279e-05;
            } else {
              result[0] += 2.5994660024668405e-08;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -9.07936241648766e-07;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                result[0] += 1.0029929941282328e-08;
              } else {
                result[0] += -9.07936241648766e-07;
              }
            }
          }
        } else {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3329403679585331566) ) ) {
            result[0] += -3.331151774433682e-05;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001776826981475250261) ) ) {
              result[0] += 4.890681854281503e-06;
            } else {
              result[0] += 5.776980475811424e-07;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -9.07936241648766e-07;
                } else {
                  result[0] += -9.07936241648766e-07;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -8.933458662262275e-07;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0110643527143887508) ) ) {
                    result[0] += -9.07936241648766e-07;
                  } else {
                    result[0] += -1.3019835125933666e-06;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -9.07936241648766e-07;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -9.07936241648766e-07;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -9.07936241648766e-07;
                      } else {
                        result[0] += -9.07936241648766e-07;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -9.07936241648766e-07;
                      } else {
                        result[0] += -9.07936241648766e-07;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.310012234630710122e-06) ) ) {
                            result[0] += -9.07936241648766e-07;
                          } else {
                            result[0] += -9.07936241648766e-07;
                          }
                        } else {
                          result[0] += -9.07936241648766e-07;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -9.07936241648766e-07;
                        } else {
                          result[0] += -9.07936241648766e-07;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -9.07936241648766e-07;
                    } else {
                      result[0] += -9.07936241648766e-07;
                    }
                  }
                }
              } else {
                result[0] += -9.07936241648766e-07;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -9.07936241648766e-07;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -9.07936241648766e-07;
                  } else {
                    result[0] += -9.07936241648766e-07;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -9.07936241648766e-07;
                  } else {
                    result[0] += -9.07936241648766e-07;
                  }
                }
              } else {
                result[0] += -9.07936241648766e-07;
              }
            }
          }
        } else {
          result[0] += 3.242181387966301e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1773295000000000288) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1350000000000000366) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.234671350732867934) ) ) {
                result[0] += -1.5955907677578717e-05;
              } else {
                result[0] += 0.00020961267159142649;
              }
            } else {
              result[0] += -7.863843940074614e-05;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.002347679878538096e-06) ) ) {
              result[0] += -0.0004547994704018699;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.038494786985569569e-06) ) ) {
                result[0] += 0.0005866895523252124;
              } else {
                result[0] += 5.0141373787424135e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7983409114572864729) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8030059940338053481) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03469629566125685682) ) ) {
                result[0] += -0.0018750318781203218;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05964584249592785187) ) ) {
                  result[0] += 0.00122415461938348;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5920309527638191183) ) ) {
                    result[0] += -0.0001240013888276091;
                  } else {
                    result[0] += 0.0015829826594300005;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6450000000000001288) ) ) {
                result[0] += 7.007384902668312e-05;
              } else {
                result[0] += -0.001476179741569424;
              }
            }
          } else {
            result[0] += 0.001059505535762613;
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 6.737378068853206e-05;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4601878067544193374) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1604180000000000328) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1050145000000000106) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2929122217587940002) ) ) {
                      result[0] += -3.736846401628765e-05;
                    } else {
                      result[0] += 0.00010128051164001481;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3044676633919599085) ) ) {
                      result[0] += 0.00012633624272263044;
                    } else {
                      result[0] += -1.0936389523292702e-05;
                    }
                  }
                } else {
                  result[0] += -0.00018466195108148326;
                }
              } else {
                result[0] += 0.00012765190937180675;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4082869870603015872) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4133512684738382403) ) ) {
                  result[0] += 9.009479315624758e-05;
                } else {
                  result[0] += -0.0013130211895284144;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3251271839107726103) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
                    result[0] += 0.00012086045302169469;
                  } else {
                    result[0] += 7.746087879889987e-05;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5748180127889448432) ) ) {
                    result[0] += -0.004111301247025494;
                  } else {
                    result[0] += 8.650841929424824e-06;
                  }
                }
              }
            }
          } else {
            result[0] += 7.763378436203926e-05;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -6.949611157027101e-07;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6299505656030152112) ) ) {
            result[0] += 2.4871346874536063e-08;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -8.687013865378344e-07;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                result[0] += 9.59650429973685e-09;
              } else {
                result[0] += -8.687013865378344e-07;
              }
            }
          }
        } else {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3329403679585331566) ) ) {
            result[0] += -3.187201955903354e-05;
          } else {
            result[0] += 1.3484068077477167e-06;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -8.687013865378344e-07;
                } else {
                  result[0] += -8.687013865378344e-07;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -8.547415083236437e-07;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0110643527143887508) ) ) {
                    result[0] += -8.687013865378344e-07;
                  } else {
                    result[0] += -1.2457206032279928e-06;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -8.687013865378344e-07;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -8.687013865378344e-07;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -8.687013865378344e-07;
                      } else {
                        result[0] += -8.687013865378344e-07;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -8.687013865378344e-07;
                      } else {
                        result[0] += -8.687013865378344e-07;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.310012234630710122e-06) ) ) {
                            result[0] += -8.687013865378344e-07;
                          } else {
                            result[0] += -8.687013865378344e-07;
                          }
                        } else {
                          result[0] += -8.687013865378344e-07;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -8.687013865378344e-07;
                        } else {
                          result[0] += -8.687013865378344e-07;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -8.687013865378344e-07;
                    } else {
                      result[0] += -8.687013865378344e-07;
                    }
                  }
                }
              } else {
                result[0] += -8.687013865378344e-07;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -8.687013865378344e-07;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -8.687013865378344e-07;
                  } else {
                    result[0] += -8.687013865378344e-07;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -8.687013865378344e-07;
                  } else {
                    result[0] += -8.687013865378344e-07;
                  }
                }
              } else {
                result[0] += -8.687013865378344e-07;
              }
            }
          }
        } else {
          result[0] += 3.1020762669621914e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1773295000000000288) ) ) {
          result[0] += 1.1016814352759564e-05;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7983409114572864729) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8030059940338053481) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2863695000000000546) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04247438584267165113) ) ) {
                  result[0] += 0.000106117469698788;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06772339094926521641) ) ) {
                    result[0] += 0.0016970344948222971;
                  } else {
                    result[0] += 0.001071083489429692;
                  }
                }
              } else {
                result[0] += -4.293725595454004e-05;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6450000000000001288) ) ) {
                result[0] += 6.704573186656771e-05;
              } else {
                result[0] += -0.0014123892509805762;
              }
            }
          } else {
            result[0] += 0.0010137208823056828;
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 6.446234219501987e-05;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4601878067544193374) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1604180000000000328) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1050145000000000106) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2929122217587940002) ) ) {
                      result[0] += -3.5753652089920155e-05;
                    } else {
                      result[0] += 9.690385387763481e-05;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3044676633919599085) ) ) {
                      result[0] += 0.0001208768459598353;
                    } else {
                      result[0] += -1.0463792837863615e-05;
                    }
                  }
                } else {
                  result[0] += -0.0001766821122306556;
                }
              } else {
                result[0] += 0.00012213565840715578;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4082869870603015872) ) ) {
                result[0] += -0.0004660468356147445;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1494199460089949139) ) ) {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.378188349821562797) ) ) {
                      result[0] += -0.0003774105852788584;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4295075599497487628) ) ) {
                        result[0] += 0.00011990910141526961;
                      } else {
                        result[0] += 0.00011736332196250105;
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5072068278894473758) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4643511832914573034) ) ) {
                        result[0] += 0.0003567859870833141;
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4908111093216080412) ) ) {
                          result[0] += -0.0009127594716521628;
                        } else {
                          result[0] += -3.776648580950319e-05;
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08407783631914581002) ) ) {
                        result[0] += 0.00019035520436435683;
                      } else {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.762281072713567931) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9186477097784532253) ) ) {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5424744603768845153) ) ) {
                              result[0] += -0.0014534970151560765;
                            } else {
                              result[0] += 6.294855811060487e-05;
                            }
                          } else {
                            result[0] += -0.0010025968535289757;
                          }
                        } else {
                          result[0] += 0.00035870865561766574;
                        }
                      }
                    }
                  }
                } else {
                  result[0] += 7.795326143365308e-05;
                }
              }
            }
          } else {
            result[0] += 7.427897799851695e-05;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -6.649296031012978e-07;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6299505656030152112) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5309997332914574431) ) ) {
              result[0] += -7.83762198497444e-05;
            } else {
              result[0] += 2.3796575710798727e-08;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -8.311619961357245e-07;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                result[0] += 9.18180837892211e-09;
              } else {
                result[0] += -8.311619961357245e-07;
              }
            }
          }
        } else {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3329403679585331566) ) ) {
            result[0] += -3.0494726735893482e-05;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001776826981475250261) ) ) {
              result[0] += 4.6210706982883824e-06;
            } else {
              result[0] += 4.944648408197758e-07;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -8.311619961357245e-07;
                } else {
                  result[0] += -8.311619961357245e-07;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -8.178053693107563e-07;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0110643527143887508) ) ) {
                    result[0] += -8.311619961357245e-07;
                  } else {
                    result[0] += -1.1918889957490393e-06;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -8.311619961357245e-07;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -8.311619961357245e-07;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -8.311619961357245e-07;
                      } else {
                        result[0] += -8.311619961357245e-07;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -8.311619961357245e-07;
                      } else {
                        result[0] += -8.311619961357245e-07;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.310012234630710122e-06) ) ) {
                            result[0] += -8.311619961357245e-07;
                          } else {
                            result[0] += -8.311619961357245e-07;
                          }
                        } else {
                          result[0] += -8.311619961357245e-07;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -8.311619961357245e-07;
                        } else {
                          result[0] += -8.311619961357245e-07;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -8.311619961357245e-07;
                    } else {
                      result[0] += -8.311619961357245e-07;
                    }
                  }
                }
              } else {
                result[0] += -8.311619961357245e-07;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -8.311619961357245e-07;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -8.311619961357245e-07;
                  } else {
                    result[0] += -8.311619961357245e-07;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -8.311619961357245e-07;
                  } else {
                    result[0] += -8.311619961357245e-07;
                  }
                }
              } else {
                result[0] += -8.311619961357245e-07;
              }
            }
          }
        } else {
          result[0] += 2.968025540386608e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1773295000000000288) ) ) {
          result[0] += 1.0540742250901422e-05;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03291917222295825951) ) ) {
            result[0] += -0.001756056290619752;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05964584249592785187) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6449783570351760309) ) ) {
                result[0] += 0.0014260455917513353;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8327395279648243109) ) ) {
                  result[0] += -0.0005126854799345013;
                } else {
                  result[0] += 0.0009164592092485953;
                }
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6002102120603015623) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4082869870603015872) ) ) {
                  result[0] += 0.0008453593049269572;
                } else {
                  result[0] += -0.0004037123891221249;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                  result[0] += 0.0014413070689768047;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7890731911809046872) ) ) {
                    result[0] += -0.0002447402102469483;
                  } else {
                    result[0] += 0.0008643472886804865;
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 6.167671635466269e-05;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1828583041203602211) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004295500000000001574) ) ) {
                result[0] += 0.00011013387871592064;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03350035677887956004) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
                    result[0] += 0.00013253641855093885;
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02229191548174745338) ) ) {
                      result[0] += 0.00013087771706314758;
                    } else {
                      result[0] += -0.0008906782759300198;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01063150000000000206) ) ) {
                    result[0] += 9.337346381804933e-05;
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1773295000000000288) ) ) {
                      result[0] += 9.446885231224353e-05;
                    } else {
                      result[0] += 0.00012181150042597269;
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4088125000000000786) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
                  result[0] += -0.0014703002572638848;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3346339054385528144) ) ) {
                    result[0] += 0.00015465763967975266;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.762281072713567931) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9186477097784532253) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6784611311055277483) ) ) {
                          result[0] += -0.00011797104957886528;
                        } else {
                          result[0] += 0.0002842437419036191;
                        }
                      } else {
                        result[0] += -0.0009771798937756055;
                      }
                    } else {
                      result[0] += 0.0003577204261559522;
                    }
                  }
                }
              } else {
                result[0] += -0.0003285886012971897;
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
              result[0] += 6.94025016574602e-05;
            } else {
              result[0] += 7.106914364465647e-05;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -6.361958490776659e-07;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6299505656030152112) ) ) {
            result[0] += 2.2768248877568636e-08;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -7.952448039407321e-07;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                result[0] += 8.78503280716042e-09;
              } else {
                result[0] += -7.952448039407321e-07;
              }
            }
          }
        } else {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3329403679585331566) ) ) {
            result[0] += -2.9176951180467066e-05;
          } else {
            result[0] += 1.2687703764623135e-06;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -7.952448039407321e-07;
                } else {
                  result[0] += -7.952448039407321e-07;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -7.824653600656333e-07;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0110643527143887508) ) ) {
                    result[0] += -7.952448039407321e-07;
                  } else {
                    result[0] += -1.1403836257556494e-06;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -7.952448039407321e-07;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -7.952448039407321e-07;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -7.952448039407321e-07;
                      } else {
                        result[0] += -7.952448039407321e-07;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -7.952448039407321e-07;
                      } else {
                        result[0] += -7.952448039407321e-07;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.310012234630710122e-06) ) ) {
                            result[0] += -7.952448039407321e-07;
                          } else {
                            result[0] += -7.952448039407321e-07;
                          }
                        } else {
                          result[0] += -7.952448039407321e-07;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -7.952448039407321e-07;
                        } else {
                          result[0] += -7.952448039407321e-07;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -7.952448039407321e-07;
                    } else {
                      result[0] += -7.952448039407321e-07;
                    }
                  }
                }
              } else {
                result[0] += -7.952448039407321e-07;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -7.952448039407321e-07;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -7.952448039407321e-07;
                  } else {
                    result[0] += -7.952448039407321e-07;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -7.952448039407321e-07;
                  } else {
                    result[0] += -7.952448039407321e-07;
                  }
                }
              } else {
                result[0] += -7.952448039407321e-07;
              }
            }
          }
        } else {
          result[0] += 2.8397675783174365e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0956005000000000188) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08720350000000000323) ) ) {
              result[0] += 9.033371461941347e-06;
            } else {
              result[0] += -0.000631491185437398;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.314196657149456993) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6269304705026225166) ) ) {
                result[0] += 0.0014542069565848476;
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3245708964283948172) ) ) {
                  result[0] += -0.0020243425483169003;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7983409114572864729) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8030059940338053481) ) ) {
                      result[0] += 0.0005943025392707967;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                        result[0] += -0.0010002071001488503;
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7601236426381910993) ) ) {
                          result[0] += 0.0007897193433795491;
                        } else {
                          result[0] += -0.000253921939938;
                        }
                      }
                    }
                  } else {
                    result[0] += 0.0009698983038319445;
                  }
                }
              }
            } else {
              result[0] += -0.0006779374191670215;
            }
          }
        } else {
          result[0] += 0.0004686852677264196;
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 5.901146639669137e-05;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1828583041203602211) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004295500000000001574) ) ) {
                result[0] += 0.00010537463839043459;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2929122217587940002) ) ) {
                  result[0] += -0.00020598983373348436;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4838161673366834781) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4734952854020100799) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4405029099497487777) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4129968667336683663) ) ) {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3687216492462311868) ) ) {
                            result[0] += 9.697996631597518e-05;
                          } else {
                            result[0] += -0.00015681740992274374;
                          }
                        } else {
                          result[0] += 9.013822119413078e-05;
                        }
                      } else {
                        result[0] += -4.941848999287586e-06;
                      }
                    } else {
                      result[0] += 0.00016212241577512267;
                    }
                  } else {
                    result[0] += -9.322031225076338e-05;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
                result[0] += -0.0014067638381662633;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4088125000000000786) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5701775282412061552) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5494686760804020631) ) ) {
                      result[0] += 7.982760783153086e-05;
                    } else {
                      result[0] += 0.00020327330945138565;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7211604863065327331) ) ) {
                        result[0] += -1.33209140587091e-07;
                      } else {
                        result[0] += -0.0009528619660442236;
                      }
                    } else {
                      result[0] += 0.000342262172099517;
                    }
                  }
                } else {
                  result[0] += -0.00031438922740769103;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
              result[0] += 6.64033955837553e-05;
            } else {
              result[0] += 6.799801659206573e-05;
            }
          }
        }
      }
    }
  }
}

