
#include "header.h"

void predict_unit14(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -6.338012098511006e-07;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -7.619693194442858e-07;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -7.922515049355419e-07;
            } else {
              result[0] += -7.922515049355419e-07;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6285027855690678011) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1129321246270776624) ) ) {
              result[0] += -4.26362102052813e-05;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6242923255276383587) ) ) {
                result[0] += 6.44295809694247e-05;
              } else {
                result[0] += -1.4267662845653396e-06;
              }
            }
          } else {
            result[0] += -3.145225873425454e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -7.922515049355419e-07;
                } else {
                  result[0] += -7.922515049355419e-07;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -7.922515049355419e-07;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -7.922515049355419e-07;
                    } else {
                      result[0] += -7.922515049355419e-07;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -7.922515049355419e-07;
                    } else {
                      result[0] += -7.922515049355419e-07;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -7.922515049355419e-07;
              } else {
                result[0] += -7.922515049355419e-07;
              }
            }
          } else {
            result[0] += -9.249840602764435e-07;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -7.922515049355419e-07;
              } else {
                result[0] += -7.922515049355419e-07;
              }
            } else {
              result[0] += -7.922515049355419e-07;
            }
          } else {
            result[0] += -7.922515049355419e-07;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07802786554345496339) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)183.5000000000000284) ) ) {
            result[0] += -5.0115693705575205e-06;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)241.5000000000000284) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4832433377889447379) ) ) {
                result[0] += 0.0008312731303937212;
              } else {
                result[0] += 9.325666086597703e-05;
              }
            } else {
              result[0] += -2.728404379664958e-06;
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)27.50000000000000355) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6050000000000000933) ) ) {
              result[0] += 0.0004598477843875605;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1405997886577425304) ) ) {
                if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.08646919771395843168) ) ) {
                  result[0] += -0.000226780663227013;
                } else {
                  result[0] += 0.0008659633962112372;
                }
              } else {
                result[0] += -0.0004229474338019024;
              }
            }
          } else {
            result[0] += 0.0002785571521553853;
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 5.891446720012607e-05;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4589535259190716254) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
                result[0] += -7.62914750368394e-05;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02633100000000000371) ) ) {
                    result[0] += 0.00011636085316137297;
                  } else {
                    result[0] += -0.0002009483974087222;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
                    result[0] += 0.0001759855570448884;
                  } else {
                    result[0] += 6.342754887863277e-05;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4086612272110553001) ) ) {
                result[0] += -0.00034435384565081694;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004677500000000000234) ) ) {
                  result[0] += 0.00010908828750096459;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0129473293797221032) ) ) {
                    result[0] += -0.000716097107460591;
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)189.5000000000000284) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04014591590259960346) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2461338418913805726) ) ) {
                          result[0] += 0.00011086561174840554;
                        } else {
                          result[0] += 0.000491632429446096;
                        }
                      } else {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1245513101099625097) ) ) {
                          result[0] += 6.724587197425956e-05;
                        } else {
                          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6037488751507539275) ) ) {
                            result[0] += -0.0006882789022012763;
                          } else {
                            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6541365753517588422) ) ) {
                              result[0] += 6.415557868264568e-05;
                            } else {
                              result[0] += -0.0001297229035243299;
                            }
                          }
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5072068278894473758) ) ) {
                        result[0] += 8.33069076715938e-05;
                      } else {
                        result[0] += 6.814462730317521e-05;
                      }
                    }
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)48.50000000000000711) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3801755927260667134) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1207797749301366269) ) ) {
                  result[0] += 6.62766550154223e-05;
                } else {
                  result[0] += 8.276308372484908e-06;
                }
              } else {
                result[0] += 5.725314706045284e-05;
              }
            } else {
              result[0] += 6.393959368391006e-05;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -6.069018661450869e-07;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -7.296303552729153e-07;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -7.586273256162089e-07;
            } else {
              result[0] += -7.586273256162089e-07;
            }
          }
        } else {
          result[0] += 4.1320905945768076e-07;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -7.586273256162089e-07;
                } else {
                  result[0] += -7.586273256162089e-07;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -7.586273256162089e-07;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -7.586273256162089e-07;
                    } else {
                      result[0] += -7.586273256162089e-07;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -7.586273256162089e-07;
                    } else {
                      result[0] += -7.586273256162089e-07;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -7.586273256162089e-07;
              } else {
                result[0] += -7.586273256162089e-07;
              }
            }
          } else {
            result[0] += -8.85726539506178e-07;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -7.586273256162089e-07;
              } else {
                result[0] += -7.586273256162089e-07;
              }
            } else {
              result[0] += -7.586273256162089e-07;
            }
          } else {
            result[0] += -7.586273256162089e-07;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1990485499246814893) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4007915000000000227) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1377635000000000109) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1255.500000000000227) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8155157533417086713) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.489742655943457672) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.335710565658207782) ) ) {
                        result[0] += 5.538545251355696e-07;
                      } else {
                        result[0] += 0.0003718049048313546;
                      }
                    } else {
                      result[0] += -0.0006124671393394304;
                    }
                  } else {
                    result[0] += 0.0005635396381123523;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -6.848447069818378e-05;
                  } else {
                    result[0] += 0.0002236582348092419;
                  }
                }
              } else {
                result[0] += 0.0004767805663978886;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03037232950945140467) ) ) {
                result[0] += -0.0004140076047156349;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2450000000000000233) ) ) {
                  result[0] += -0.00046960390948964844;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8030059940338053481) ) ) {
                    result[0] += 0.001229823005732286;
                  } else {
                    result[0] += 7.797721197899417e-05;
                  }
                }
              }
            }
          } else {
            result[0] += -0.0005017777897625249;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2712534726811091645) ) ) {
            result[0] += 0.0005693576832713726;
          } else {
            result[0] += -2.831190705079385e-05;
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 5.6414060956278625e-05;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
            if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1000116863636408421) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)201.5000000000000284) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02007650000000000406) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)19.50000000000000355) ) ) {
                    result[0] += -2.3406539768862347e-05;
                  } else {
                    result[0] += 7.126578235119418e-05;
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07184972061993401271) ) ) {
                    result[0] += -0.00012156326222509815;
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)58.50000000000000711) ) ) {
                      result[0] += 0.000138528695145443;
                    } else {
                      result[0] += 6.325786276482506e-05;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
                  result[0] += 0.0001727303342429669;
                } else {
                  result[0] += 6.718706368821218e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5196530228391961215) ) ) {
                result[0] += -0.00014770593309357304;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1245513101099625097) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02747750000000000539) ) ) {
                    result[0] += 1.1145129228410478e-05;
                  } else {
                    result[0] += 0.00012767876054213396;
                  }
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02278050000000000561) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6468042868844222637) ) ) {
                      result[0] += 0.00013665910240293094;
                    } else {
                      result[0] += 2.3279136673826874e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6571412079648242255) ) ) {
                      result[0] += -0.00033691607957194917;
                    } else {
                      result[0] += 0.00012896306256018108;
                    }
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
                result[0] += -1.886884009110076e-06;
              } else {
                result[0] += 6.582196062708156e-05;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5932867452288201893) ) ) {
                result[0] += 5.4841485336757686e-05;
              } else {
                result[0] += 6.068634087926249e-05;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -5.811441654031486e-07;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -6.986638985988807e-07;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -7.264301999886081e-07;
            } else {
              result[0] += -7.264301999886081e-07;
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)15.50000000000000178) ) ) {
            result[0] += -3.31400137135203e-05;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5494686760804020631) ) ) {
              result[0] += 0.0002721344857575603;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.640890220251256415) ) ) {
                result[0] += -1.051703603984461e-05;
              } else {
                result[0] += 5.9135843237649745e-05;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -7.264301999886081e-07;
                } else {
                  result[0] += -7.264301999886081e-07;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -7.264301999886081e-07;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -7.264301999886081e-07;
                    } else {
                      result[0] += -7.264301999886081e-07;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -7.264301999886081e-07;
                    } else {
                      result[0] += -7.264301999886081e-07;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -7.264301999886081e-07;
              } else {
                result[0] += -7.264301999886081e-07;
              }
            }
          } else {
            result[0] += -8.481351587303466e-07;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -7.264301999886081e-07;
              } else {
                result[0] += -7.264301999886081e-07;
              }
            } else {
              result[0] += -7.264301999886081e-07;
            }
          } else {
            result[0] += -7.264301999886081e-07;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07802786554345496339) ) ) {
          result[0] += 2.4278232020553523e-06;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.741363993241206054) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
                result[0] += 0.00037600749864578464;
              } else {
                result[0] += -0.0001685165386678634;
              }
            } else {
              result[0] += -0.0004831063383462224;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6551236496733668924) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)65.50000000000001421) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8950000000000001288) ) ) {
                  result[0] += 0.0010243904106498108;
                } else {
                  result[0] += 0.0004807882999903681;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8850000000000001199) ) ) {
                  result[0] += 0.002056665657969852;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                    result[0] += 0.00030790744546593205;
                  } else {
                    result[0] += -0.0005218560493981003;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7831470153266332224) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03759900000000000742) ) ) {
                  result[0] += 0.00020005471650025764;
                } else {
                  result[0] += -0.0013470218621445347;
                }
              } else {
                result[0] += 0.0005136459591541738;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 5.401977518981752e-05;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
            if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1000116863636408421) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)201.5000000000000284) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02007650000000000406) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)19.50000000000000355) ) ) {
                    result[0] += -2.2413135924843453e-05;
                  } else {
                    result[0] += 6.824117030542307e-05;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03296628516090911037) ) ) {
                    result[0] += -0.000613054802472172;
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03588950000000001167) ) ) {
                      result[0] += -3.211755203730872e-05;
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0501585000000000017) ) ) {
                        result[0] += 0.0001778701463792472;
                      } else {
                        result[0] += 5.171430163889354e-05;
                      }
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
                  result[0] += 0.0001653994352843782;
                } else {
                  result[0] += 6.433555774178067e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5196530228391961215) ) ) {
                result[0] += -0.0001414371021100701;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8440161800932387548) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6010141514957837439) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3872449054220527542) ) ) {
                      result[0] += 6.87579477730027e-05;
                    } else {
                      result[0] += -0.00033383837379965414;
                    }
                  } else {
                    result[0] += 0.0002080686224094278;
                  }
                } else {
                  result[0] += -0.0002090945024428216;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
                result[0] += -1.8068022094754903e-06;
              } else {
                result[0] += 6.302839142148474e-05;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5932867452288201893) ) ) {
                result[0] += 5.251394171504977e-05;
              } else {
                result[0] += 5.8110734023046024e-05;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -5.564796548201276e-07;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -6.690116984274914e-07;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -6.95599562046957e-07;
            } else {
              result[0] += -6.95599562046957e-07;
            }
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4754075198241206057) ) ) {
            result[0] += 0.0002998949280882495;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.06355808660527756393) ) ) {
              result[0] += -0.00020815129163681253;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01848850000000000146) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.006053013595436600516) ) ) {
                  result[0] += 1.6598905723264203e-05;
                } else {
                  result[0] += -3.624115169493731e-05;
                }
              } else {
                result[0] += 5.627157709965147e-05;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -6.95599562046957e-07;
                } else {
                  result[0] += -6.95599562046957e-07;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -6.95599562046957e-07;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -6.95599562046957e-07;
                    } else {
                      result[0] += -6.95599562046957e-07;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -6.95599562046957e-07;
                    } else {
                      result[0] += -6.95599562046957e-07;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -6.95599562046957e-07;
              } else {
                result[0] += -6.95599562046957e-07;
              }
            }
          } else {
            result[0] += -8.121392048109923e-07;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -6.95599562046957e-07;
              } else {
                result[0] += -6.95599562046957e-07;
              }
            } else {
              result[0] += -6.95599562046957e-07;
            }
          } else {
            result[0] += -6.95599562046957e-07;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07802786554345496339) ) ) {
          result[0] += 2.3247832429101663e-06;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6050000000000000933) ) ) {
              result[0] += 0.0005255490912743871;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9650000000000000799) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5064897371608040322) ) ) {
                  result[0] += 0.0004925839488801645;
                } else {
                  result[0] += -0.00043135343197089784;
                }
              } else {
                result[0] += 9.449948619573115e-05;
              }
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6551236496733668924) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)65.50000000000001421) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8950000000000001288) ) ) {
                  result[0] += 0.0009809139557032246;
                } else {
                  result[0] += 0.0004603830222309689;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8850000000000001199) ) ) {
                  result[0] += 0.001969378105402669;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                    result[0] += 0.00029483945494069246;
                  } else {
                    result[0] += -0.0004997078031978368;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7831470153266332224) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03759900000000000742) ) ) {
                  result[0] += 0.00019156413539138113;
                } else {
                  result[0] += -0.0012898525107988476;
                }
              } else {
                result[0] += 0.0004918461598105863;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 5.1727106010324753e-05;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
            if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1000116863636408421) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)201.5000000000000284) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02007650000000000406) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)19.50000000000000355) ) ) {
                    result[0] += -2.1461893425773525e-05;
                  } else {
                    result[0] += 6.534492670977519e-05;
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07184972061993401271) ) ) {
                    result[0] += -0.00011577738717637696;
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)58.50000000000000711) ) ) {
                      result[0] += 0.00013081032745555047;
                    } else {
                      result[0] += 5.837829529343665e-05;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
                  result[0] += 0.00015837966916633123;
                } else {
                  result[0] += 6.160507339856125e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01724593443360410497) ) ) {
                result[0] += -0.0003459286859661691;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04014591590259960346) ) ) {
                  result[0] += 0.00020191619447269043;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05732259783002840309) ) ) {
                    result[0] += -0.0001814747793862311;
                  } else {
                    result[0] += 6.186129110710158e-05;
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
                result[0] += -1.7301191850712477e-06;
              } else {
                result[0] += 6.035338490882802e-05;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5932867452288201893) ) ) {
                result[0] += 5.02851820573015e-05;
              } else {
                result[0] += 5.5644439255542155e-05;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -5.328619379907408e-07;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -6.406179760116689e-07;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -6.660774162851519e-07;
            } else {
              result[0] += -6.660774162851519e-07;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6285027855690678011) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.07196201389915944657) ) ) {
              result[0] += -6.857439344981515e-05;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5458973873869347182) ) ) {
                result[0] += 0.0006553768920003646;
              } else {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.640890220251256415) ) ) {
                  result[0] += -5.594367286975036e-06;
                } else {
                  result[0] += 0.0001170410130932533;
                }
              }
            }
          } else {
            result[0] += -2.719029482732569e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -6.660774162851519e-07;
                } else {
                  result[0] += -6.660774162851519e-07;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -6.660774162851519e-07;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -6.660774162851519e-07;
                    } else {
                      result[0] += -6.660774162851519e-07;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -6.660774162851519e-07;
                    } else {
                      result[0] += -6.660774162851519e-07;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -6.660774162851519e-07;
              } else {
                result[0] += -6.660774162851519e-07;
              }
            }
          } else {
            result[0] += -7.776709657673555e-07;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -6.660774162851519e-07;
              } else {
                result[0] += -6.660774162851519e-07;
              }
            } else {
              result[0] += -6.660774162851519e-07;
            }
          } else {
            result[0] += -6.660774162851519e-07;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)183.5000000000000284) ) ) {
            result[0] += -3.4688043841067896e-06;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)241.5000000000000284) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4832433377889447379) ) ) {
                result[0] += 0.0008103849172642128;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
                  result[0] += -3.612629714969154e-05;
                } else {
                  result[0] += 0.0001914711141279204;
                }
              }
            } else {
              result[0] += -4.725084294126714e-07;
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.0017632667112893554;
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.0194836725655387448) ) ) {
              result[0] += 0.0003018097391269971;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
                result[0] += -0.0003293122181455694;
              } else {
                result[0] += 0.00017797507407363398;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 4.9531740678323996e-05;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4589535259190716254) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
                result[0] += -7.89590309390161e-05;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02633100000000000371) ) ) {
                    result[0] += 0.00010292854049287259;
                  } else {
                    result[0] += -0.00017621510634311231;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
                    result[0] += 0.0001572762697326348;
                  } else {
                    result[0] += 5.40451301143053e-05;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4086612272110553001) ) ) {
                result[0] += -0.0003207719499550996;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004677500000000000234) ) ) {
                  result[0] += 9.551962345369343e-05;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0129473293797221032) ) ) {
                    result[0] += -0.0006514140643615946;
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)189.5000000000000284) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1245513101099625097) ) ) {
                        result[0] += 5.770139863551273e-05;
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2542665105872564113) ) ) {
                          result[0] += -0.000468510593214127;
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3830383354773237436) ) ) {
                            result[0] += 7.478476472617795e-05;
                          } else {
                            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)59.50000000000000711) ) ) {
                              result[0] += 0.00011389217080022837;
                            } else {
                              result[0] += -0.00017567488069418914;
                            }
                          }
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5072068278894473758) ) ) {
                        result[0] += 7.191041356399324e-05;
                      } else {
                        result[0] += 5.9235817842422675e-05;
                      }
                    }
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)48.50000000000000711) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3801755927260667134) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1207797749301366269) ) ) {
                  result[0] += 5.6773316498911924e-05;
                } else {
                  result[0] += 6.409991892289196e-06;
                }
              } else {
                result[0] += 4.813277790112302e-05;
              }
            } else {
              result[0] += 5.4499188347324324e-05;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -5.102465876331475e-07;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -6.134293199265572e-07;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -6.37808228601435e-07;
            } else {
              result[0] += -6.37808228601435e-07;
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)15.50000000000000178) ) ) {
            result[0] += -3.1350516433015766e-05;
          } else {
            result[0] += 8.893835252724884e-06;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -6.37808228601435e-07;
                } else {
                  result[0] += -6.37808228601435e-07;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -6.37808228601435e-07;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -6.37808228601435e-07;
                    } else {
                      result[0] += -6.37808228601435e-07;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -6.37808228601435e-07;
                    } else {
                      result[0] += -6.37808228601435e-07;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -6.37808228601435e-07;
              } else {
                result[0] += -6.37808228601435e-07;
              }
            }
          } else {
            result[0] += -7.44665603402609e-07;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -6.37808228601435e-07;
              } else {
                result[0] += -6.37808228601435e-07;
              }
            } else {
              result[0] += -6.37808228601435e-07;
            }
          } else {
            result[0] += -6.37808228601435e-07;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1054010000000000086) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8155157533417086713) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.80526473097989959) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9150000000000001465) ) ) {
                  result[0] += -1.6828967842618132e-06;
                } else {
                  result[0] += 9.488244102727426e-05;
                }
              } else {
                result[0] += -0.00017168971311934812;
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05500000000000000722) ) ) {
                result[0] += 0.000325705329026832;
              } else {
                result[0] += 0.0010369945997512312;
              }
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.130629626450776108e-06) ) ) {
              result[0] += -0.00013627674004104123;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.256922594654586334) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)27.50000000000000355) ) ) {
                  result[0] += -0.0006179047528952445;
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                    result[0] += 0.0001272879008197486;
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)461.5000000000000568) ) ) {
                      result[0] += -0.0005454678964499812;
                    } else {
                      result[0] += -9.517247453015294e-07;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05732259783002840309) ) ) {
                  result[0] += 4.863634399656014e-05;
                } else {
                  result[0] += -0.00038293473779629804;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8352912313316583903) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.966590843157139501) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5366611211306534512) ) ) {
                  result[0] += 0.00023295237061273153;
                } else {
                  result[0] += 0.0013265796487588804;
                }
              } else {
                result[0] += 0.00012091843013195722;
              }
            } else {
              result[0] += -0.0013935691300509313;
            }
          } else {
            result[0] += 0.0007042665486965276;
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 4.742954949258074e-05;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4589535259190716254) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
                result[0] += -0.00011202918462382554;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)105.5000000000000142) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02633100000000000371) ) ) {
                    result[0] += 6.50942053874804e-05;
                  } else {
                    result[0] += 8.723108817470925e-05;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03945037468542575421) ) ) {
                    result[0] += 0.00015060126127481522;
                  } else {
                    result[0] += 4.7470696670065696e-05;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4086612272110553001) ) ) {
                result[0] += -0.00045666589449242553;
              } else {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1000116863636408421) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)201.5000000000000284) ) ) {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)100.5000000000000142) ) ) {
                      result[0] += 9.08712681033288e-05;
                    } else {
                      result[0] += -6.233703446873667e-05;
                    }
                  } else {
                    result[0] += 7.539516105492896e-05;
                  }
                } else {
                  result[0] += 5.6721773061375386e-05;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
                result[0] += -1.928739040154939e-06;
              } else {
                result[0] += 5.57490917402252e-05;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5932867452288201893) ) ) {
                result[0] += 4.60899605063891e-05;
              } else {
                result[0] += 5.096980113579266e-05;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -4.885910620169033e-07;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -5.87394585597305e-07;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -6.107388218332073e-07;
            } else {
              result[0] += -6.107388218332073e-07;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6285027855690678011) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1129321246270776624) ) ) {
              result[0] += -5.950041012454942e-05;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6059238433417085679) ) ) {
                result[0] += 0.0004181656861039351;
              } else {
                result[0] += 8.864374697561842e-06;
              }
            }
          } else {
            result[0] += -2.470574702520179e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -6.107388218332073e-07;
                } else {
                  result[0] += -6.107388218332073e-07;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -6.107388218332073e-07;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -6.107388218332073e-07;
                    } else {
                      result[0] += -6.107388218332073e-07;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -6.107388218332073e-07;
                    } else {
                      result[0] += -6.107388218332073e-07;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -6.107388218332073e-07;
              } else {
                result[0] += -6.107388218332073e-07;
              }
            }
          } else {
            result[0] += -7.130610313370897e-07;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -6.107388218332073e-07;
              } else {
                result[0] += -6.107388218332073e-07;
              }
            } else {
              result[0] += -6.107388218332073e-07;
            }
          } else {
            result[0] += -6.107388218332073e-07;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1054010000000000086) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8155157533417086713) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5694274749246232004) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5492268452512564236) ) ) {
                    result[0] += 2.6416371168004144e-05;
                  } else {
                    result[0] += 0.0004622251479880008;
                  }
                } else {
                  result[0] += -0.0004872016977594395;
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05151350000000001067) ) ) {
                  result[0] += -1.647548913466134e-06;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06116598190050365896) ) ) {
                    result[0] += -9.894445531093324e-05;
                  } else {
                    result[0] += -0.0005864063105071607;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05500000000000000722) ) ) {
                result[0] += 0.000311881973286597;
              } else {
                result[0] += 0.000992983206704962;
              }
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.130629626450776108e-06) ) ) {
              result[0] += -0.00013049297880405006;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.194581012612933923) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)58.50000000000000711) ) ) {
                  result[0] += -0.0005005392695911304;
                } else {
                  result[0] += -4.451341655374741e-05;
                }
              } else {
                result[0] += 8.283301519471722e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.247314011309283543) ) ) {
            result[0] += 0.00026930229563186503;
          } else {
            result[0] += -0.0005252093698549391;
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 4.541657802173141e-05;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4589535259190716254) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
                result[0] += -0.00010727452102353766;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)105.5000000000000142) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02633100000000000371) ) ) {
                    result[0] += 6.233152305622254e-05;
                  } else {
                    result[0] += 8.352888788511335e-05;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03945037468542575421) ) ) {
                    result[0] += 0.00014420954881573227;
                  } else {
                    result[0] += 4.545597885974217e-05;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4086612272110553001) ) ) {
                result[0] += -0.0004372844028451652;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004677500000000000234) ) ) {
                  result[0] += 0.00010100809059072597;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0129473293797221032) ) ) {
                    result[0] += -0.0006216268433754143;
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)189.5000000000000284) ) ) {
                      result[0] += 4.046556081628406e-05;
                    } else {
                      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5072068278894473758) ) ) {
                        result[0] += 7.677214313217578e-05;
                      } else {
                        result[0] += 5.829290796052385e-05;
                      }
                    }
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
                result[0] += -1.8468808588298427e-06;
              } else {
                result[0] += 5.338302812799435e-05;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5932867452288201893) ) ) {
                result[0] += 4.4133842926008885e-05;
              } else {
                result[0] += 4.880657680288144e-05;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -4.678546249375988e-07;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -5.624647990910162e-07;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -5.848182757254801e-07;
            } else {
              result[0] += -5.848182757254801e-07;
            }
          }
        } else {
          result[0] += 2.7228858245822763e-06;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -5.848182757254801e-07;
                } else {
                  result[0] += -5.848182757254801e-07;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -5.848182757254801e-07;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -5.848182757254801e-07;
                    } else {
                      result[0] += -5.848182757254801e-07;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -5.848182757254801e-07;
                    } else {
                      result[0] += -5.848182757254801e-07;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -5.848182757254801e-07;
              } else {
                result[0] += -5.848182757254801e-07;
              }
            }
          } else {
            result[0] += -6.827977982173656e-07;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -5.848182757254801e-07;
              } else {
                result[0] += -5.848182757254801e-07;
              }
            } else {
              result[0] += -5.848182757254801e-07;
            }
          } else {
            result[0] += -5.848182757254801e-07;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07184972061993401271) ) ) {
          result[0] += 1.8749511507448298e-06;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9750000000000000888) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8030059940338053481) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6586934769095478259) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01962450000000000652) ) ) {
                  result[0] += -0.0007395719568188469;
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5308132790452262384) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4737195465326633492) ) ) {
                      result[0] += 0.001719034293872737;
                    } else {
                      result[0] += -0.0007695832496498075;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.09274867639439776656) ) ) {
                      result[0] += 0.0026110047830928064;
                    } else {
                      result[0] += 0.0012859185381638408;
                    }
                  }
                }
              } else {
                result[0] += 0.0015979223161775664;
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7753767533919598831) ) ) {
                result[0] += -0.0006214339499487978;
              } else {
                result[0] += 0.00045418047322822006;
              }
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00526800000000000098) ) ) {
              result[0] += 0.00044035378351015974;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)21.50000000000000355) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02472850000000000395) ) ) {
                  result[0] += -8.608493080397992e-06;
                } else {
                  result[0] += -0.001546071744980806;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.09900846148772847466) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1177750000000000186) ) ) {
                    result[0] += 0.00032732966843519045;
                  } else {
                    result[0] += -0.0005444218793759467;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3783101257612192514) ) ) {
                    result[0] += -0.00044266930529487274;
                  } else {
                    result[0] += -3.219513203371657e-05;
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 4.3489039665592124e-05;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4589535259190716254) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
                result[0] += -0.00010272165150063936;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02633100000000000371) ) ) {
                    result[0] += 0.00012476201963785313;
                  } else {
                    result[0] += -0.0002998150485958999;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
                    result[0] += 0.00013808910890651896;
                  } else {
                    result[0] += 4.966297121496708e-05;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)189.5000000000000284) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4086612272110553001) ) ) {
                  result[0] += -0.0004471944365454357;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)137.5000000000000284) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6541365753517588422) ) ) {
                      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6067453057537689487) ) ) {
                        result[0] += 5.292670361564519e-05;
                      } else {
                        result[0] += 0.00016001728874531933;
                      }
                    } else {
                      result[0] += -0.00020382900351313012;
                    }
                  } else {
                    result[0] += -8.335562744499543e-05;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03358130704046471265) ) ) {
                  result[0] += 2.35598031810568e-05;
                } else {
                  result[0] += 6.412094280450126e-05;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
                result[0] += -1.7684968446740517e-06;
              } else {
                result[0] += 5.1117383317979577e-05;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5932867452288201893) ) ) {
                result[0] += 4.226074550763778e-05;
              } else {
                result[0] += 4.673516251062961e-05;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -4.479982690881373e-07;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -5.385930649918962e-07;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -5.599978311447954e-07;
            } else {
              result[0] += -5.599978311447954e-07;
            }
          }
        } else {
          result[0] += 2.6073230258227176e-06;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -5.599978311447954e-07;
                } else {
                  result[0] += -5.599978311447954e-07;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -5.599978311447954e-07;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -5.599978311447954e-07;
                    } else {
                      result[0] += -5.599978311447954e-07;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -5.599978311447954e-07;
                    } else {
                      result[0] += -5.599978311447954e-07;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -5.599978311447954e-07;
              } else {
                result[0] += -5.599978311447954e-07;
              }
            }
          } else {
            result[0] += -6.538189758824009e-07;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -5.599978311447954e-07;
              } else {
                result[0] += -5.599978311447954e-07;
              }
            } else {
              result[0] += -5.599978311447954e-07;
            }
          } else {
            result[0] += -5.599978311447954e-07;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07184972061993401271) ) ) {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3329403679585331566) ) ) {
            result[0] += 0.00012671618381786831;
          } else {
            result[0] += -2.562814656715964e-06;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.213351496714494937) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7831470153266332224) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)10.50000000000000178) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01112050000000000191) ) ) {
                  result[0] += -0.0006155922727277754;
                } else {
                  result[0] += 5.4282820035091195e-05;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5308132790452262384) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
                      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4725302343969849939) ) ) {
                        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)50.50000000000000711) ) ) {
                          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03842800000000001076) ) ) {
                            result[0] += 0.00030116412806211634;
                          } else {
                            result[0] += -0.0010122734446297082;
                          }
                        } else {
                          result[0] += 0.0006623934772421786;
                        }
                      } else {
                        result[0] += 0.0005556319972544894;
                      }
                    } else {
                      result[0] += -0.0013492370897658244;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1165587384072143268) ) ) {
                      result[0] += 0.0005369755651659909;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2756227488107761969) ) ) {
                        result[0] += -0.0003297688540269934;
                      } else {
                        result[0] += 0.0003666616004114765;
                      }
                    }
                  }
                } else {
                  result[0] += -0.000389632356536887;
                }
              }
            } else {
              result[0] += 0.0008736577226907534;
            }
          } else {
            result[0] += -0.00036487371498591123;
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 4.1643308532195e-05;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4589535259190716254) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
                result[0] += -6.194073449489982e-05;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02633100000000000371) ) ) {
                    result[0] += 8.836498325676963e-05;
                  } else {
                    result[0] += -0.00016325904482535408;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
                    result[0] += 0.0001322284283890376;
                  } else {
                    result[0] += 4.612856910075465e-05;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)189.5000000000000284) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1177750000000000186) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08702700000000000713) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008311500000000001179) ) ) {
                      result[0] += 6.046783228831388e-05;
                    } else {
                      result[0] += 1.9208261961088844e-05;
                    }
                  } else {
                    result[0] += 9.912626891207136e-05;
                  }
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5064897371608040322) ) ) {
                    result[0] += -0.00028807353429462733;
                  } else {
                    result[0] += 4.1771862278483496e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)346.5000000000000568) ) ) {
                  result[0] += 6.22229448106526e-05;
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)488.5000000000000568) ) ) {
                    result[0] += -0.0001615184915999534;
                  } else {
                    result[0] += 6.293348216217262e-05;
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)48.50000000000000711) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3801755927260667134) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1207797749301366269) ) ) {
                  result[0] += 4.874096772397455e-05;
                } else {
                  result[0] += 4.029994023111965e-06;
                }
              } else {
                result[0] += 4.046714476814483e-05;
              }
            } else {
              result[0] += 4.656335651465484e-05;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -4.289846426819805e-07;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -5.157344781862957e-07;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -5.362307983584302e-07;
            } else {
              result[0] += -5.362307983584302e-07;
            }
          }
        } else {
          result[0] += 2.496664861821094e-06;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -5.362307983584302e-07;
                } else {
                  result[0] += -5.362307983584302e-07;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -5.362307983584302e-07;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -5.362307983584302e-07;
                    } else {
                      result[0] += -5.362307983584302e-07;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -5.362307983584302e-07;
                    } else {
                      result[0] += -5.362307983584302e-07;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -5.362307983584302e-07;
              } else {
                result[0] += -5.362307983584302e-07;
              }
            }
          } else {
            result[0] += -6.260700522761068e-07;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -5.362307983584302e-07;
              } else {
                result[0] += -5.362307983584302e-07;
              }
            } else {
              result[0] += -5.362307983584302e-07;
            }
          } else {
            result[0] += -5.362307983584302e-07;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)183.5000000000000284) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)151.5000000000000284) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)121.5000000000000142) ) ) {
              result[0] += -1.633258060198288e-06;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.005566725998003100966) ) ) {
                result[0] += -3.3501327982742565e-05;
              } else {
                result[0] += 0.0003242232709051393;
              }
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)3.928223887174962991e-06) ) ) {
              result[0] += -0.0003099921928395144;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.000726282482777400166) ) ) {
                result[0] += 0.00032028943042455746;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)157.5000000000000284) ) ) {
                  result[0] += -0.0008145075439418103;
                } else {
                  result[0] += -6.590056574425067e-05;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)241.5000000000000284) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.115000000000000005) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2542665105872564113) ) ) {
                result[0] += -0.00032077771768986593;
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                  result[0] += 0.0008390783689120482;
                } else {
                  result[0] += -3.2150108057321373e-05;
                }
              }
            } else {
              result[0] += 0.0003697670155316041;
            }
          } else {
            result[0] += 9.431672327284686e-07;
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 3.9875912617118446e-05;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4589535259190716254) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
                result[0] += -5.931188955001232e-05;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02633100000000000371) ) ) {
                    result[0] += 8.461465899223093e-05;
                  } else {
                    result[0] += -0.0001563301196487984;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
                    result[0] += 0.00012661648273848669;
                  } else {
                    result[0] += 4.417081292165372e-05;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4086612272110553001) ) ) {
                result[0] += -0.00025122838852167847;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00448250000000000124) ) ) {
                  result[0] += 9.190856546515845e-05;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0129473293797221032) ) ) {
                    result[0] += -0.000583604919892436;
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)189.5000000000000284) ) ) {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)95.50000000000001421) ) ) {
                        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)76.50000000000001421) ) ) {
                          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)64.50000000000001421) ) ) {
                            result[0] += 6.71866518520425e-05;
                          } else {
                            result[0] += -0.00011247032326953713;
                          }
                        } else {
                          result[0] += 9.48327360067472e-05;
                        }
                      } else {
                        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)117.5000000000000142) ) ) {
                          result[0] += -0.00034932557692185235;
                        } else {
                          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)137.5000000000000284) ) ) {
                            result[0] += 6.0486773900976835e-05;
                          } else {
                            result[0] += -6.135304087593979e-05;
                          }
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5072068278894473758) ) ) {
                        result[0] += 5.937627763383593e-05;
                      } else {
                        result[0] += 5.042652724697639e-05;
                      }
                    }
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)48.50000000000000711) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3801755927260667134) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1207797749301366269) ) ) {
                  result[0] += 4.6672337965949595e-05;
                } else {
                  result[0] += 3.858955860550781e-06;
                }
              } else {
                result[0] += 3.874966676558082e-05;
              }
            } else {
              result[0] += 4.458714739494351e-05;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -4.1077797919075945e-07;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -4.938460393917117e-07;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -5.134724692063513e-07;
            } else {
              result[0] += -5.134724692063513e-07;
            }
          }
        } else {
          result[0] += 2.390703173529974e-06;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -5.134724692063513e-07;
                } else {
                  result[0] += -5.134724692063513e-07;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -5.134724692063513e-07;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -5.134724692063513e-07;
                    } else {
                      result[0] += -5.134724692063513e-07;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -5.134724692063513e-07;
                    } else {
                      result[0] += -5.134724692063513e-07;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -5.134724692063513e-07;
              } else {
                result[0] += -5.134724692063513e-07;
              }
            }
          } else {
            result[0] += -5.994988289044017e-07;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -5.134724692063513e-07;
              } else {
                result[0] += -5.134724692063513e-07;
              }
            } else {
              result[0] += -5.134724692063513e-07;
            }
          } else {
            result[0] += -5.134724692063513e-07;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)183.5000000000000284) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4330073079623726895) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4014600540350321545) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6628367744974875686) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3561404984221285264) ) ) {
                  result[0] += -1.4755581378776769e-05;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3872449054220527542) ) ) {
                    result[0] += 0.0012336039495730534;
                  } else {
                    result[0] += -0.00019419309461046503;
                  }
                }
              } else {
                result[0] += -0.00045872605907522915;
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)71.50000000000001421) ) ) {
                result[0] += -0.00020887061742943066;
              } else {
                result[0] += -0.0014842057604657001;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5951110425376885393) ) ) {
                result[0] += -0.0007140132080386029;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.341544232904992332e-05) ) ) {
                  result[0] += -8.021697169947707e-05;
                } else {
                  result[0] += 0.0002846873254454716;
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7080301875628142172) ) ) {
                result[0] += -0.0005480590817300913;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8458243956458841861) ) ) {
                  result[0] += -0.0002362194439151215;
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7269841738944724518) ) ) {
                    result[0] += 0.0005785390808556933;
                  } else {
                    result[0] += -3.684232056714686e-06;
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)241.5000000000000284) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4832433377889447379) ) ) {
              result[0] += 0.0007459804601227043;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1450000000000000455) ) ) {
                  result[0] += -0.000604521261488905;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)221.5000000000000284) ) ) {
                    result[0] += -1.9451392892091725e-05;
                  } else {
                    result[0] += 0.0005864172255697281;
                  }
                }
              } else {
                result[0] += 0.00018092357600638301;
              }
            }
          } else {
            result[0] += 9.031379945839936e-07;
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 3.81835272723042e-05;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
            if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1000116863636408421) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)153.5000000000000284) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03296628516090911037) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02447420998234165271) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4086612272110553001) ) ) {
                      result[0] += -0.00032973748416026606;
                    } else {
                      result[0] += 0.0004250946167900713;
                    }
                  } else {
                    result[0] += -0.00016233135063003799;
                  }
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01112050000000000191) ) ) {
                    result[0] += 3.961066550691912e-05;
                  } else {
                    result[0] += 6.454323361572387e-05;
                  }
                }
              } else {
                if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2185860198827210554) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03139221484724531025) ) ) {
                    result[0] += 0.0001264257465223166;
                  } else {
                    result[0] += 3.7514072897440844e-05;
                  }
                } else {
                  result[0] += 6.416335001336177e-05;
                }
              }
            } else {
              result[0] += 4.43380359203383e-05;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
                result[0] += -2.028256793652989e-06;
              } else {
                result[0] += 4.558583139055327e-05;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5932867452288201893) ) ) {
                result[0] += 3.710508075246268e-05;
              } else {
                result[0] += 4.088311635559245e-05;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -3.933440300638746e-07;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -4.728865742708467e-07;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -4.916800330007049e-07;
            } else {
              result[0] += -4.916800330007049e-07;
            }
          }
        } else {
          result[0] += 2.2892386364413266e-06;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -4.916800330007049e-07;
                } else {
                  result[0] += -4.916800330007049e-07;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -4.916800330007049e-07;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -4.916800330007049e-07;
                    } else {
                      result[0] += -4.916800330007049e-07;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -4.916800330007049e-07;
                    } else {
                      result[0] += -4.916800330007049e-07;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -4.916800330007049e-07;
              } else {
                result[0] += -4.916800330007049e-07;
              }
            }
          } else {
            result[0] += -5.740553226450642e-07;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -4.916800330007049e-07;
              } else {
                result[0] += -4.916800330007049e-07;
              }
            } else {
              result[0] += -4.916800330007049e-07;
            }
          } else {
            result[0] += -4.916800330007049e-07;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1255.500000000000227) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07184972061993401271) ) ) {
            result[0] += 8.546339640280345e-07;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.213351496714494937) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)20.50000000000000355) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3750409390474713223) ) ) {
                  result[0] += -0.0006511917945984886;
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.00000001800250948e-35) ) ) {
                    result[0] += 0.000662505982891879;
                  } else {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5951110425376885393) ) ) {
                      result[0] += -0.0005444051345040292;
                    } else {
                      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6903617355527639221) ) ) {
                        result[0] += 0.000663892662754319;
                      } else {
                        result[0] += -0.000373761321159011;
                      }
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004873500000000000228) ) ) {
                  result[0] += 0.0003998243453274376;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01221850000000000193) ) ) {
                    result[0] += -3.5737021530793546e-05;
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03588950000000001167) ) ) {
                      result[0] += 0.0005252075310657392;
                    } else {
                      result[0] += 0.00017079399802139776;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.0003492839374940549;
            }
          }
        } else {
          result[0] += 0.0004181850068645062;
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 3.656296895206312e-05;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
            if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1000116863636408421) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)201.5000000000000284) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02007650000000000406) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)19.50000000000000355) ) ) {
                    result[0] += 1.4040311670099794e-05;
                  } else {
                    result[0] += 4.5918622085532484e-05;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03296628516090911037) ) ) {
                    result[0] += -0.0005730130439530178;
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03588950000000001167) ) ) {
                      result[0] += -5.108073594461848e-05;
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0501585000000000017) ) ) {
                        result[0] += 0.00015879301710366276;
                      } else {
                        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)93.50000000000001421) ) ) {
                          result[0] += -6.334103196744681e-05;
                        } else {
                          result[0] += 4.0941727260356497e-05;
                        }
                      }
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
                  result[0] += 0.00011025860427945147;
                } else {
                  result[0] += 4.530316872826222e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5196530228391961215) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06116598190050365896) ) ) {
                  result[0] += -0.0005197919867898532;
                } else {
                  result[0] += 0.00010528328105898829;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8440161800932387548) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6010141514957837439) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3872449054220527542) ) ) {
                      result[0] += 5.203276672085289e-05;
                    } else {
                      result[0] += -0.00032219086097699985;
                    }
                  } else {
                    result[0] += 0.00018258012756401833;
                  }
                } else {
                  result[0] += -0.00021100569050692727;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
                result[0] += -1.942174950059405e-06;
              } else {
                result[0] += 4.365110970236598e-05;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5932867452288201893) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2394849609754011732) ) ) {
                  result[0] += 3.7446781515282515e-05;
                } else {
                  result[0] += 3.5530293098406006e-05;
                }
              } else {
                result[0] += 3.9147983980442214e-05;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -3.7665000030352534e-07;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -4.5281665597857186e-07;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -4.7081249599464227e-07;
            } else {
              result[0] += -4.7081249599464227e-07;
            }
          }
        } else {
          result[0] += 2.1920803856372322e-06;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -4.7081249599464227e-07;
                } else {
                  result[0] += -4.7081249599464227e-07;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -4.7081249599464227e-07;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -4.7081249599464227e-07;
                    } else {
                      result[0] += -4.7081249599464227e-07;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -4.7081249599464227e-07;
                    } else {
                      result[0] += -4.7081249599464227e-07;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -4.7081249599464227e-07;
              } else {
                result[0] += -4.7081249599464227e-07;
              }
            }
          } else {
            result[0] += -5.496916717241111e-07;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -4.7081249599464227e-07;
              } else {
                result[0] += -4.7081249599464227e-07;
              }
            } else {
              result[0] += -4.7081249599464227e-07;
            }
          } else {
            result[0] += -4.7081249599464227e-07;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1054010000000000086) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8155157533417086713) ) ) {
              result[0] += 2.248288313310541e-06;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05500000000000000722) ) ) {
                result[0] += 0.0002977834050020821;
              } else {
                result[0] += 0.0009378492857110415;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.179099372612799401) ) ) {
              result[0] += -0.00036449919541496406;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)18.50000000000000355) ) ) {
                result[0] += 0.00014946334102727824;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6150000000000001021) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.96280210579579717) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)95.50000000000001421) ) ) {
                      result[0] += -0.0001931733360662986;
                    } else {
                      result[0] += -1.0534409532086436e-05;
                    }
                  } else {
                    result[0] += 0.0002528677259646618;
                  }
                } else {
                  result[0] += -0.0004821187246046835;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8352912313316583903) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.966590843157139501) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5366611211306534512) ) ) {
                  result[0] += 0.00022311365316461556;
                } else {
                  result[0] += 0.001326808399733734;
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03869870194826590531) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03037232950945140467) ) ) {
                    result[0] += -0.00010867150565994717;
                  } else {
                    result[0] += 0.0015804511761959579;
                  }
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5233231360301507928) ) ) {
                    result[0] += -0.000628911439560164;
                  } else {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5745673188442211865) ) ) {
                      result[0] += 0.0012897918473432342;
                    } else {
                      result[0] += -0.0006054126488084662;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.001310269906192394;
            }
          } else {
            result[0] += 0.0006628615892677524;
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 3.5011189224499365e-05;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004143500000000000481) ) ) {
              result[0] += 8.26858281184113e-05;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.009723928609266600451) ) ) {
                result[0] += -0.0005722437573111818;
              } else {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2545696998002126565) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03296628516090911037) ) ) {
                    result[0] += -3.024707101716146e-06;
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)103.5000000000000142) ) ) {
                      result[0] += 4.746746328038523e-05;
                    } else {
                      result[0] += 3.672259417533136e-05;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4693565335929648641) ) ) {
                    result[0] += -0.0005024035580084096;
                  } else {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                      result[0] += 0.00011767436333074944;
                    } else {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)410.5000000000000568) ) ) {
                        result[0] += 2.411797199836346e-05;
                      } else {
                        result[0] += 4.974381047955386e-05;
                      }
                    }
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
                result[0] += -1.8597465313256925e-06;
              } else {
                result[0] += 4.1798500106830394e-05;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5932867452288201893) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2394849609754011732) ) ) {
                  result[0] += 3.585749163857278e-05;
                } else {
                  result[0] += 3.402234147071221e-05;
                }
              } else {
                result[0] += 3.748649286916319e-05;
              }
            }
          }
        }
      }
    }
  }
}

