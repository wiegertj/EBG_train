
#include "header.h"

void predict_unit14(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -2.148583858763961e-06;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6263671874874373602) ) ) {
            result[0] += -1.0056122887371753e-05;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.864778478351716e-06;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.652905739716803768) ) ) {
                result[0] += -2.864778478351716e-06;
              } else {
                result[0] += -2.864778478351716e-06;
              }
            }
          }
        } else {
          result[0] += -3.587141743301736e-06;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                  result[0] += -2.864778478351716e-06;
                } else {
                  result[0] += -2.864778478351716e-06;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7496778360301509236) ) ) {
                  result[0] += 1.9099276116777618e-07;
                } else {
                  result[0] += -2.879576628910571e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06983950000000001268) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                        result[0] += -2.864778478351716e-06;
                      } else {
                        result[0] += -2.864778478351716e-06;
                      }
                    } else {
                      result[0] += -2.864778478351716e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                          result[0] += -2.864778478351716e-06;
                        } else {
                          result[0] += -2.864778478351716e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8032211286180904741) ) ) {
                            result[0] += -2.864778478351716e-06;
                          } else {
                            result[0] += -2.864778478351716e-06;
                          }
                        } else {
                          result[0] += -2.864778478351716e-06;
                        }
                      }
                    } else {
                      result[0] += -2.864778478351716e-06;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.483243480726212482) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                      result[0] += -2.864778478351716e-06;
                    } else {
                      result[0] += -2.864778478351716e-06;
                    }
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.598708736933611707) ) ) {
                      result[0] += -2.864778478351716e-06;
                    } else {
                      result[0] += -2.864778478351716e-06;
                    }
                  }
                }
              } else {
                result[0] += -2.864778478351716e-06;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.828053558455352334) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.96280210579579717) ) ) {
                result[0] += -2.864778478351716e-06;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8715165423366836306) ) ) {
                    result[0] += -2.864778478351716e-06;
                  } else {
                    result[0] += -2.864778478351716e-06;
                  }
                } else {
                  result[0] += -2.864778478351716e-06;
                }
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003377500000000000294) ) ) {
                result[0] += -2.864778478351716e-06;
              } else {
                result[0] += -2.864778478351716e-06;
              }
            }
          }
        } else {
          result[0] += -5.4595940845191485e-06;
        }
      }
    } else {
      if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.8975410753335467673) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9850000000000000977) ) ) {
          result[0] += 0.0009906777487299868;
        } else {
          result[0] += 0.0003248685617329449;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9450000000000000622) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.7939576624218304124) ) ) {
            result[0] += -0.0020478619119057417;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9284011333411857914) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02170000000000000401) ) ) {
                result[0] += -2.4834642158451536e-05;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1850000000000000255) ) ) {
                    result[0] += -1.3075906542884146e-05;
                  } else {
                    result[0] += 0.0019943602330988338;
                  }
                } else {
                  result[0] += -0.0013639002351265293;
                }
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9310018456912946272) ) ) {
                result[0] += -0.0012745570361359494;
              } else {
                result[0] += -4.8460445508496996e-05;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3597967273366834418) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009908500000000002375) ) ) {
              result[0] += -0.002872293253440274;
            } else {
              result[0] += 6.051077333787226e-06;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3687216492462311868) ) ) {
              result[0] += 0.0006884485720313123;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3789418506030151068) ) ) {
                result[0] += -0.0020781924455401043;
              } else {
                result[0] += 0.0003115449582377526;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -1.9763057462308926e-06;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6263671874874373602) ) ) {
            result[0] += -9.249801149744192e-06;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.6350743283076314e-06;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.652905739716803768) ) ) {
                result[0] += -2.6350743283076314e-06;
              } else {
                result[0] += -2.6350743283076314e-06;
              }
            }
          }
        } else {
          result[0] += -3.2995169403861297e-06;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                  result[0] += -2.6350743283076314e-06;
                } else {
                  result[0] += -2.6350743283076314e-06;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7496778360301509236) ) ) {
                  result[0] += 1.7567854745102865e-07;
                } else {
                  result[0] += -2.648685931068102e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06983950000000001268) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                        result[0] += -2.6350743283076314e-06;
                      } else {
                        result[0] += -2.6350743283076314e-06;
                      }
                    } else {
                      result[0] += -2.6350743283076314e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                          result[0] += -2.6350743283076314e-06;
                        } else {
                          result[0] += -2.6350743283076314e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                          result[0] += -2.6350743283076314e-06;
                        } else {
                          result[0] += -2.6350743283076314e-06;
                        }
                      }
                    } else {
                      result[0] += -2.6350743283076314e-06;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.483243480726212482) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                      result[0] += -2.6350743283076314e-06;
                    } else {
                      result[0] += -2.6350743283076314e-06;
                    }
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.598708736933611707) ) ) {
                      result[0] += -2.6350743283076314e-06;
                    } else {
                      result[0] += -2.6350743283076314e-06;
                    }
                  }
                }
              } else {
                result[0] += -2.6350743283076314e-06;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.828053558455352334) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.96280210579579717) ) ) {
                result[0] += -2.6350743283076314e-06;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                  result[0] += -2.6350743283076314e-06;
                } else {
                  result[0] += -2.6350743283076314e-06;
                }
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003377500000000000294) ) ) {
                result[0] += -2.6350743283076314e-06;
              } else {
                result[0] += -2.6350743283076314e-06;
              }
            }
          }
        } else {
          result[0] += -5.021831992878562e-06;
        }
      }
    } else {
      if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.8975410753335467673) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9850000000000000977) ) ) {
          result[0] += 0.000911243058767315;
        } else {
          result[0] += 0.000298819896046287;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.7650000000000001243) ) ) {
          result[0] += -1.2875422601010817e-05;
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3120632405527638542) ) ) {
            result[0] += -0.0032349941337174344;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09277402050424696234) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5090080881909548882) ) ) {
                if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1815989264960422844) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3597967273366834418) ) ) {
                    result[0] += -0.0007792556575564275;
                  } else {
                    result[0] += 0.0006290747682243193;
                  }
                } else {
                  result[0] += -0.0008834856883865605;
                }
              } else {
                result[0] += 0.0006648368538908518;
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5613540176884422861) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
                  result[0] += -0.005870180056451878;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3115605993075549196) ) ) {
                    result[0] += -0.0001802554139446841;
                  } else {
                    result[0] += -0.00760584684761687;
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3075945000000000484) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01173150000000000061) ) ) {
                    result[0] += 0.0007481064791483522;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9808239647505231362) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1324529432504036319) ) ) {
                        result[0] += 0.0014442673789813038;
                      } else {
                        result[0] += -6.839582494780946e-05;
                      }
                    } else {
                      result[0] += -0.0017465875092776265;
                    }
                  }
                } else {
                  result[0] += 0.0012990894045288165;
                }
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -1.8178412663083591e-06;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6263671874874373602) ) ) {
            result[0] += -8.508132037373148e-06;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.423788355077634e-06;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.652905739716803768) ) ) {
                result[0] += -2.423788355077634e-06;
              } else {
                result[0] += -2.423788355077634e-06;
              }
            }
          }
        } else {
          result[0] += -3.0349545178202043e-06;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                  result[0] += -2.423788355077634e-06;
                } else {
                  result[0] += -2.423788355077634e-06;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7496778360301509236) ) ) {
                  result[0] += 1.6159226059563587e-07;
                } else {
                  result[0] += -2.436308550014967e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06983950000000001268) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                        result[0] += -2.423788355077634e-06;
                      } else {
                        result[0] += -2.423788355077634e-06;
                      }
                    } else {
                      result[0] += -2.423788355077634e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                          result[0] += -2.423788355077634e-06;
                        } else {
                          result[0] += -2.423788355077634e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8032211286180904741) ) ) {
                            result[0] += -2.423788355077634e-06;
                          } else {
                            result[0] += -2.423788355077634e-06;
                          }
                        } else {
                          result[0] += -2.423788355077634e-06;
                        }
                      }
                    } else {
                      result[0] += -2.423788355077634e-06;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.483243480726212482) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                      result[0] += -2.423788355077634e-06;
                    } else {
                      result[0] += -2.423788355077634e-06;
                    }
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.598708736933611707) ) ) {
                      result[0] += -2.423788355077634e-06;
                    } else {
                      result[0] += -2.423788355077634e-06;
                    }
                  }
                }
              } else {
                result[0] += -2.423788355077634e-06;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.828053558455352334) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.96280210579579717) ) ) {
                result[0] += -2.423788355077634e-06;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8715165423366836306) ) ) {
                    result[0] += -2.423788355077634e-06;
                  } else {
                    result[0] += -2.423788355077634e-06;
                  }
                } else {
                  result[0] += -2.423788355077634e-06;
                }
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003377500000000000294) ) ) {
                result[0] += -2.423788355077634e-06;
              } else {
                result[0] += -2.423788355077634e-06;
              }
            }
          }
        } else {
          result[0] += -4.619170614937723e-06;
        }
      }
    } else {
      if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.8975410753335467673) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9850000000000000977) ) ) {
          result[0] += 0.0008381776144827174;
        } else {
          result[0] += 0.00027485986885525973;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9450000000000000622) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.7939576624218304124) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3550000000000000377) ) ) {
              result[0] += -0.0033975666042040434;
            } else {
              result[0] += -0.0007850345039738652;
            }
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3477174365476807805) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01314200000000000264) ) ) {
                if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3715165125194505591) ) ) {
                  result[0] += -5.237337351495846e-05;
                } else {
                  result[0] += 0.0024463838189921774;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5750000000000000666) ) ) {
                  result[0] += 0.0028506846706206953;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4529241356532663354) ) ) {
                    if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4612588522637047217) ) ) {
                      result[0] += 0.0020302128562626784;
                    } else {
                      result[0] += -0.0056624792070652154;
                    }
                  } else {
                    result[0] += 0.009623110373945296;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.420247012311557866) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3050000000000000488) ) ) {
                  result[0] += 0.00045947211464725013;
                } else {
                  result[0] += -0.0028598736015813414;
                }
              } else {
                result[0] += -1.0922455194155621e-06;
              }
            }
          }
        } else {
          result[0] += 0.00023878760695952787;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -1.6720828119818849e-06;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6263671874874373602) ) ) {
            result[0] += -7.82593156258038e-06;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.229443749308956e-06;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.652905739716803768) ) ) {
                result[0] += -2.229443749308956e-06;
              } else {
                result[0] += -2.229443749308956e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4364163272837385255) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6152470170603016042) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.16821429881140601) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5072068278894473758) ) ) {
                  result[0] += 0.0002129846042076758;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5190499213819096402) ) ) {
                    result[0] += -0.00046519269576303905;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5525538534170856275) ) ) {
                      result[0] += 0.0006825139788499605;
                    } else {
                      result[0] += -0.00037058439495431863;
                    }
                  }
                }
              } else {
                result[0] += 0.0008228694385157559;
              }
            } else {
              result[0] += -0.00012819849798819638;
            }
          } else {
            result[0] += 5.298715710385606e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                  result[0] += -2.229443749308956e-06;
                } else {
                  result[0] += -2.229443749308956e-06;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7496778360301509236) ) ) {
                  result[0] += 1.486354427633617e-07;
                } else {
                  result[0] += -2.24096004786889e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06983950000000001268) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                        result[0] += -2.229443749308956e-06;
                      } else {
                        result[0] += -2.229443749308956e-06;
                      }
                    } else {
                      result[0] += -2.229443749308956e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                          result[0] += -2.229443749308956e-06;
                        } else {
                          result[0] += -2.229443749308956e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8032211286180904741) ) ) {
                            result[0] += -2.229443749308956e-06;
                          } else {
                            result[0] += -2.229443749308956e-06;
                          }
                        } else {
                          result[0] += -2.229443749308956e-06;
                        }
                      }
                    } else {
                      result[0] += -2.229443749308956e-06;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.483243480726212482) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                      result[0] += -2.229443749308956e-06;
                    } else {
                      result[0] += -2.229443749308956e-06;
                    }
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.598708736933611707) ) ) {
                      result[0] += -2.229443749308956e-06;
                    } else {
                      result[0] += -2.229443749308956e-06;
                    }
                  }
                }
              } else {
                result[0] += -2.229443749308956e-06;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.828053558455352334) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.96280210579579717) ) ) {
                result[0] += -2.229443749308956e-06;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8715165423366836306) ) ) {
                    result[0] += -2.229443749308956e-06;
                  } else {
                    result[0] += -2.229443749308956e-06;
                  }
                } else {
                  result[0] += -2.229443749308956e-06;
                }
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003377500000000000294) ) ) {
                result[0] += -2.229443749308956e-06;
              } else {
                result[0] += -2.229443749308956e-06;
              }
            }
          }
        } else {
          result[0] += -4.248795499363913e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9550000000000000711) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1350000000000000366) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2150000000000000244) ) ) {
            result[0] += -9.530764473513103e-05;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7273815826884423297) ) ) {
              result[0] += 0.0017504139846909815;
            } else {
              result[0] += -0.0008332585780468646;
            }
          }
        } else {
          result[0] += 0.00011530835384994563;
        }
      } else {
        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.00025282100859652705;
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.255367500000000025) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01990600000000000355) ) ) {
              result[0] += 0.00034987589824657535;
            } else {
              result[0] += 9.919935687429559e-05;
            }
          } else {
            result[0] += 0.0005636601857613787;
          }
        }
      }
    }
  }
}

