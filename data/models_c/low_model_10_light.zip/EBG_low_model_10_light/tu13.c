
#include "header.h"

void predict_unit13(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -1.113788544033619e-06;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -1.3390203201117688e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.3922356670758155e-06;
            } else {
              result[0] += -1.3922356670758155e-06;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6285027855690678011) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1129321246270776624) ) ) {
              result[0] += -2.2698237793988424e-05;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6242923255276383587) ) ) {
                result[0] += 7.645001149677478e-05;
              } else {
                result[0] += -7.329460390461761e-06;
              }
            }
          } else {
            result[0] += -3.313766058929058e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -1.3922356670758155e-06;
                } else {
                  result[0] += -1.3922356670758155e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -1.3922356670758155e-06;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -1.3922356670758155e-06;
                    } else {
                      result[0] += -1.3922356670758155e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -1.3922356670758155e-06;
                    } else {
                      result[0] += -1.3922356670758155e-06;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -1.3922356670758155e-06;
              } else {
                result[0] += -1.3922356670758155e-06;
              }
            }
          } else {
            result[0] += -1.6254886133643885e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -1.3922356670758155e-06;
              } else {
                result[0] += -1.3922356670758155e-06;
              }
            } else {
              result[0] += -1.3922356670758155e-06;
            }
          } else {
            result[0] += -1.3922356670758155e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1255.500000000000227) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
            result[0] += -7.320462428032516e-05;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)3.058716661128509106e-06) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5326995889949749374) ) ) {
                  result[0] += -0.0003277389835860989;
                } else {
                  result[0] += 5.126879761462008e-05;
                }
              } else {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6628367744974875686) ) ) {
                  result[0] += 0.001875750591710444;
                } else {
                  result[0] += 0.0002515519320234771;
                }
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.004923558837848901124) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.004621314935084650834) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)8.500000000000001776) ) ) {
                    result[0] += -0.00015768356213283885;
                  } else {
                    result[0] += -2.348495641479901e-06;
                  }
                } else {
                  result[0] += -0.00048472104771749903;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.895681724436047322) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7536081807788946874) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.09900846148772847466) ) ) {
                        result[0] += -9.905314794952508e-05;
                      } else {
                        result[0] += 0.00013760970256612771;
                      }
                    } else {
                      result[0] += -0.0001544081592118603;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.573103097775156778) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.231660934306704425) ) ) {
                        result[0] += 7.171884351832398e-05;
                      } else {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6050000000000000933) ) ) {
                          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1850000000000000255) ) ) {
                            result[0] += 2.60950946658039e-05;
                          } else {
                            result[0] += -0.0004607872680854886;
                          }
                        } else {
                          result[0] += 2.160273853951676e-05;
                        }
                      }
                    } else {
                      result[0] += 0.0007662077507087145;
                    }
                  }
                } else {
                  result[0] += -0.0005195927546372831;
                }
              }
            }
          }
        } else {
          result[0] += 0.0006477376325238143;
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.00010353129281774956;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)14.50000000000000178) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4592177672613065309) ) ) {
                result[0] += -0.0006081285257490511;
              } else {
                result[0] += 0.00023287629635401286;
              }
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2450759342279490716) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)153.5000000000000284) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01439950000000000084) ) ) {
                    result[0] += 0.00013115260044011836;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08780304645514057371) ) ) {
                      result[0] += -6.319136823381494e-05;
                    } else {
                      result[0] += 0.0001355711247735143;
                    }
                  }
                } else {
                  result[0] += 0.00011722628520239254;
                }
              } else {
                result[0] += 8.995558963384498e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
                result[0] += -1.532263211627472e-06;
              } else {
                result[0] += 0.00011834632881050963;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5932867452288201893) ) ) {
                result[0] += 0.00010182763682236723;
              } else {
                result[0] += 0.00011135463242750577;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -1.0665179165938161e-06;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -1.282190564566739e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.3331473833264052e-06;
            } else {
              result[0] += -1.3331473833264052e-06;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6285027855690678011) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1129321246270776624) ) ) {
              result[0] += -2.1734895202572267e-05;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6152470170603016042) ) ) {
                result[0] += 0.00034710080136595795;
              } else {
                result[0] += -3.527872794705392e-06;
              }
            }
          } else {
            result[0] += -3.1731255382186364e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -1.3331473833264052e-06;
                } else {
                  result[0] += -1.3331473833264052e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -1.3331473833264052e-06;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -1.3331473833264052e-06;
                    } else {
                      result[0] += -1.3331473833264052e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -1.3331473833264052e-06;
                    } else {
                      result[0] += -1.3331473833264052e-06;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -1.3331473833264052e-06;
              } else {
                result[0] += -1.3331473833264052e-06;
              }
            }
          } else {
            result[0] += -1.5565007726637726e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -1.3331473833264052e-06;
              } else {
                result[0] += -1.3331473833264052e-06;
              }
            } else {
              result[0] += -1.3331473833264052e-06;
            }
          } else {
            result[0] += -1.3331473833264052e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1255.500000000000227) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1990485499246814893) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4007915000000000227) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1645630000000000426) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8155157533417086713) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.489742655943457672) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.335710565658207782) ) ) {
                        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7683067979899498301) ) ) {
                          result[0] += 1.3019644311150823e-05;
                        } else {
                          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.786764172562814168) ) ) {
                            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3850000000000000644) ) ) {
                              result[0] += -0.0003873206363184304;
                            } else {
                              result[0] += 0.00040689536516261304;
                            }
                          } else {
                            result[0] += -4.801497607188556e-07;
                          }
                        }
                      } else {
                        result[0] += 0.00030357703686061045;
                      }
                    } else {
                      result[0] += -0.0007433868070254558;
                    }
                  } else {
                    result[0] += 0.0005901588994260092;
                  }
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)95.50000000000001421) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8701049114070352752) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.242456489623170593e-05) ) ) {
                        result[0] += -0.00042910329578325755;
                      } else {
                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03296628516090911037) ) ) {
                          result[0] += 6.374309342335652e-05;
                        } else {
                          result[0] += -0.0009128681604227237;
                        }
                      }
                    } else {
                      result[0] += 3.5185368001887856e-05;
                    }
                  } else {
                    result[0] += 8.164964505121385e-06;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4450000000000000622) ) ) {
                  result[0] += -0.0003032725945804626;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8850000000000001199) ) ) {
                    result[0] += 0.0016432408604731604;
                  } else {
                    result[0] += 0.00017941691370983;
                  }
                }
              }
            } else {
              result[0] += -0.0004943977953391119;
            }
          } else {
            result[0] += 0.00030455128562689585;
          }
        } else {
          result[0] += 0.0006202468090010076;
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 9.913729074495059e-05;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
            if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1185261981962025396) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)201.5000000000000284) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01112050000000000191) ) ) {
                  result[0] += 0.0001207923556740887;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
                    result[0] += -0.00032955396382840636;
                  } else {
                    result[0] += 0.00010479343978344776;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
                  result[0] += 0.00030051999632897203;
                } else {
                  result[0] += 0.00011748300745537007;
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4983996163819096048) ) ) {
                result[0] += -0.0010981511651643955;
              } else {
                result[0] += 9.839111400052258e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
                result[0] += -1.4672319776420272e-06;
              } else {
                result[0] += 0.00011332355743435205;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5932867452288201893) ) ) {
                result[0] += 9.750594011513783e-05;
              } else {
                result[0] += 0.0001066285976955357;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -1.0212535157672576e-06;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -1.2277727374045722e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.2765668828201756e-06;
            } else {
              result[0] += -1.2765668828201756e-06;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6285027855690678011) ) ) {
            result[0] += 8.579185063860284e-06;
          } else {
            result[0] += -3.0384539832450686e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -1.2765668828201756e-06;
                } else {
                  result[0] += -1.2765668828201756e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -1.2765668828201756e-06;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -1.2765668828201756e-06;
                    } else {
                      result[0] += -1.2765668828201756e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -1.2765668828201756e-06;
                    } else {
                      result[0] += -1.2765668828201756e-06;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -1.2765668828201756e-06;
              } else {
                result[0] += -1.2765668828201756e-06;
              }
            }
          } else {
            result[0] += -1.4904408652168219e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -1.2765668828201756e-06;
              } else {
                result[0] += -1.2765668828201756e-06;
              }
            } else {
              result[0] += -1.2765668828201756e-06;
            }
          } else {
            result[0] += -1.2765668828201756e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1255.500000000000227) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1990485499246814893) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
              result[0] += -7.047168437064502e-05;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)3.058716661128509106e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3050000000000000488) ) ) {
                  result[0] += 4.989644437766519e-05;
                } else {
                  result[0] += 0.0015768056384277485;
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)3.928223887174962991e-06) ) ) {
                  result[0] += -0.00023355073554728818;
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3002177033299863185) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)6.500000000000000888) ) ) {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005382500000000000999) ) ) {
                        result[0] += 0.00015000868125957962;
                      } else {
                        result[0] += -0.0011623093195834281;
                      }
                    } else {
                      result[0] += 0.00020909111844451926;
                    }
                  } else {
                    if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1878414568672973628) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8850000000000001199) ) ) {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0009155000000000001895) ) ) {
                          result[0] += 0.00031751708270414823;
                        } else {
                          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3650000000000000466) ) ) {
                            result[0] += -0.0004565662788125739;
                          } else {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.006855418980843201206) ) ) {
                              result[0] += -0.0010266364469352712;
                            } else {
                              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
                                result[0] += 0.000751071248862818;
                              } else {
                                result[0] += -0.00022877203061890365;
                              }
                            }
                          }
                        }
                      } else {
                        result[0] += 0.00041124046681682543;
                      }
                    } else {
                      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1725637113259415323) ) ) {
                        result[0] += 0.0007019237750194525;
                      } else {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.85801459308964273e-06) ) ) {
                          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6152470170603016042) ) ) {
                            result[0] += 0.0007582793143610908;
                          } else {
                            result[0] += 6.161554512484271e-06;
                          }
                        } else {
                          result[0] += -1.037896168501337e-06;
                        }
                      }
                    }
                  }
                }
              }
            }
          } else {
            result[0] += 0.00029162573486926695;
          }
        } else {
          result[0] += 0.0005939227316112263;
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 9.49297758074909e-05;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
            if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1185261981962025396) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)201.5000000000000284) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01112050000000000191) ) ) {
                  result[0] += 0.00011566577175182725;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07184972061993401271) ) ) {
                    result[0] += -7.25738716367639e-06;
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)59.50000000000000711) ) ) {
                      result[0] += 0.00017693001743536015;
                    } else {
                      result[0] += 0.00010034587055976512;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
                  result[0] += 0.0002877655387070424;
                } else {
                  result[0] += 0.00011249687655496078;
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4983996163819096048) ) ) {
                result[0] += -0.0010515442083240578;
              } else {
                result[0] += 9.421526776990795e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
                result[0] += -1.4049607533986714e-06;
              } else {
                result[0] += 0.00010851395897661696;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5932867452288201893) ) ) {
                result[0] += 9.336766180994395e-05;
              } else {
                result[0] += 0.00010210314199472985;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -9.779101946997031e-07;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -1.1756644732628227e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.2223877319903393e-06;
            } else {
              result[0] += -1.2223877319903393e-06;
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)15.50000000000000178) ) ) {
            result[0] += -3.750795350811275e-05;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5494686760804020631) ) ) {
              result[0] += 0.0003437141452790445;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.640890220251256415) ) ) {
                result[0] += -1.9076874711690793e-05;
              } else {
                result[0] += 6.358905221415922e-05;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -1.2223877319903393e-06;
                } else {
                  result[0] += -1.2223877319903393e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -1.2223877319903393e-06;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -1.2223877319903393e-06;
                    } else {
                      result[0] += -1.2223877319903393e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -1.2223877319903393e-06;
                    } else {
                      result[0] += -1.2223877319903393e-06;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -1.2223877319903393e-06;
              } else {
                result[0] += -1.2223877319903393e-06;
              }
            }
          } else {
            result[0] += -1.4271846257464913e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -1.2223877319903393e-06;
              } else {
                result[0] += -1.2223877319903393e-06;
              }
            } else {
              result[0] += -1.2223877319903393e-06;
            }
          } else {
            result[0] += -1.2223877319903393e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1255.500000000000227) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
            result[0] += -6.748077487100725e-05;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)3.058716661128509106e-06) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1850000000000000255) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.115000000000000005) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05500000000000000722) ) ) {
                    result[0] += 7.989733389431492e-07;
                  } else {
                    result[0] += 0.000648443676176833;
                  }
                } else {
                  result[0] += -0.00028999296846989384;
                }
              } else {
                result[0] += 0.001190564189304389;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.004923558837848901124) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.004621314935084650834) ) ) {
                  result[0] += -9.788587424528515e-06;
                } else {
                  result[0] += -0.0004646573799539478;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2669585275879397535) ) ) {
                  result[0] += 0.000563341929401534;
                } else {
                  result[0] += 3.0346451173359825e-05;
                }
              }
            }
          }
        } else {
          result[0] += 0.0005687158821384082;
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 9.090083324996934e-05;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1185261981962025396) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)201.5000000000000284) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01112050000000000191) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03087413318892935285) ) ) {
                    result[0] += 0.00013862995280685192;
                  } else {
                    result[0] += 0.0001046990220960027;
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07184972061993401271) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01962450000000000652) ) ) {
                      result[0] += 0.00020182731978266217;
                    } else {
                      result[0] += -0.00021348638481403178;
                    }
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)59.50000000000000711) ) ) {
                      result[0] += 0.00010939702859325353;
                    } else {
                      result[0] += 9.59605276055016e-05;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
                  result[0] += 0.00027555239677530633;
                } else {
                  result[0] += 0.00010249040597507608;
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02374450000000000519) ) ) {
                result[0] += 0.00010009937768930785;
              } else {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6586934769095478259) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1245513101099625097) ) ) {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5226454670100503241) ) ) {
                      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
                        result[0] += 0.0003278372151788474;
                      } else {
                        result[0] += -0.00026904924372042887;
                      }
                    } else {
                      result[0] += 0.00015614527931923352;
                    }
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)71.50000000000001421) ) ) {
                      result[0] += -1.1515372335524311e-05;
                    } else {
                      result[0] += -0.0004101672999435394;
                    }
                  }
                } else {
                  result[0] += 0.00017307313535428866;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)48.50000000000000711) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3801755927260667134) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1207797749301366269) ) ) {
                  result[0] += 9.838656940666946e-05;
                } else {
                  result[0] += 8.466602741319605e-06;
                }
              } else {
                result[0] += 8.854544804740422e-05;
              }
            } else {
              result[0] += 9.63911352266445e-05;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -9.364064202796408e-07;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -1.1257677512975238e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.1705080144484458e-06;
            } else {
              result[0] += -1.1705080144484458e-06;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6285027855690678011) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.07196201389915944657) ) ) {
              result[0] += -6.648319012280832e-05;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5458973873869347182) ) ) {
                result[0] += 0.0007587339564287518;
              } else {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.640890220251256415) ) ) {
                  result[0] += -1.248786634664632e-05;
                } else {
                  result[0] += 0.00012149802188634414;
                }
              }
            }
          } else {
            result[0] += -3.1793782316154666e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -1.1705080144484458e-06;
                } else {
                  result[0] += -1.1705080144484458e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -1.1705080144484458e-06;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -1.1705080144484458e-06;
                    } else {
                      result[0] += -1.1705080144484458e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -1.1705080144484458e-06;
                    } else {
                      result[0] += -1.1705080144484458e-06;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -1.1705080144484458e-06;
              } else {
                result[0] += -1.1705080144484458e-06;
              }
            }
          } else {
            result[0] += -1.3666130629549294e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -1.1705080144484458e-06;
              } else {
                result[0] += -1.1705080144484458e-06;
              }
            } else {
              result[0] += -1.1705080144484458e-06;
            }
          } else {
            result[0] += -1.1705080144484458e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1255.500000000000227) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
              result[0] += 5.181912791709545e-05;
            } else {
              result[0] += -0.00010026868662827682;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)3.058716661128509106e-06) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1850000000000000255) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.115000000000000005) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05500000000000000722) ) ) {
                    result[0] += 7.650638762881014e-07;
                  } else {
                    result[0] += 0.0006209228872475253;
                  }
                } else {
                  result[0] += -0.00027768529153595023;
                }
              } else {
                result[0] += 0.0011400351041048551;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.004923558837848901124) ) ) {
                result[0] += -1.788896529214196e-05;
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2669585275879397535) ) ) {
                  result[0] += 0.0005394329687567223;
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
                    result[0] += -0.0005844366785210541;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.895681724436047322) ) ) {
                      result[0] += 4.285620244974802e-05;
                    } else {
                      result[0] += -0.0004996027528400861;
                    }
                  }
                }
              }
            }
          }
        } else {
          result[0] += 0.0005445788439836746;
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 8.704288422944873e-05;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
            if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1185261981962025396) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)201.5000000000000284) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01112050000000000191) ) ) {
                  result[0] += 0.00010631320467199707;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
                    result[0] += -0.00030796124949403523;
                  } else {
                    result[0] += 9.201437293265988e-05;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
                  result[0] += 0.0002638575963952173;
                } else {
                  result[0] += 0.00010337253801582898;
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4983996163819096048) ) ) {
                result[0] += -0.0010150298509695494;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9194299814036738239) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6010141514957837439) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3872449054220527542) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3111804673197418603) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2229087561192843736) ) ) {
                          result[0] += 9.987086518892389e-05;
                        } else {
                          result[0] += -0.0002936973189830518;
                        }
                      } else {
                        result[0] += 0.00014883247913971632;
                      }
                    } else {
                      result[0] += -0.0003635049271376525;
                    }
                  } else {
                    result[0] += 0.0002151436312740179;
                  }
                } else {
                  result[0] += -0.000409722197932184;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
                result[0] += -1.704665979595328e-06;
              } else {
                result[0] += 0.0001001505026788918;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5932867452288201893) ) ) {
                result[0] += 8.531405284962218e-05;
              } else {
                result[0] += 9.367878794860283e-05;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -8.966641197663588e-07;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -1.0779887107961998e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.120830139269486e-06;
            } else {
              result[0] += -1.120830139269486e-06;
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)15.50000000000000178) ) ) {
            result[0] += -3.847571230367538e-05;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4992188184422110542) ) ) {
              result[0] += 0.00033907642573066633;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)78.50000000000001421) ) ) {
                result[0] += 1.5244868428450406e-05;
              } else {
                result[0] += -3.0444413042409705e-05;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -1.120830139269486e-06;
                } else {
                  result[0] += -1.120830139269486e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -1.120830139269486e-06;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -1.120830139269486e-06;
                    } else {
                      result[0] += -1.120830139269486e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -1.120830139269486e-06;
                    } else {
                      result[0] += -1.120830139269486e-06;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -1.120830139269486e-06;
              } else {
                result[0] += -1.120830139269486e-06;
              }
            }
          } else {
            result[0] += -1.308612235688976e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -1.120830139269486e-06;
              } else {
                result[0] += -1.120830139269486e-06;
              }
            } else {
              result[0] += -1.120830139269486e-06;
            }
          } else {
            result[0] += -1.120830139269486e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1255.500000000000227) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07802786554345496339) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6571412079648242255) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6551236496733668924) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6915080527790725684) ) ) {
                  result[0] += 6.326658388891591e-06;
                } else {
                  result[0] += -0.0014489789996675986;
                }
              } else {
                result[0] += -0.000954667180132351;
              }
            } else {
              result[0] += 2.0862177793381303e-05;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)27.50000000000000355) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8650000000000001021) ) ) {
                result[0] += 0.00033966940046116875;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005615500000000001567) ) ) {
                  result[0] += 0.0003048553514597527;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.156847194217679814) ) ) {
                    if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3103687546836865763) ) ) {
                      result[0] += -0.0007809006673194106;
                    } else {
                      result[0] += 0.0003930021878263518;
                    }
                  } else {
                    result[0] += -0.0006499822741605491;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)111.5000000000000142) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8650000000000001021) ) ) {
                      result[0] += 0.002469974075062766;
                    } else {
                      result[0] += 0.0003889825380647857;
                    }
                  } else {
                    result[0] += 0.0004885959373778238;
                  }
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)165.5000000000000284) ) ) {
                    result[0] += -0.00035610795714130435;
                  } else {
                    result[0] += 0.0005967275001877462;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7831470153266332224) ) ) {
                  result[0] += -0.0005607941737557654;
                } else {
                  result[0] += 0.0005245112805568479;
                }
              }
            }
          }
        } else {
          result[0] += 0.0005214662129699767;
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 8.334867155888894e-05;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
            if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1185261981962025396) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)201.5000000000000284) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01112050000000000191) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03087413318892935285) ) ) {
                    result[0] += 0.00012823424816153884;
                  } else {
                    result[0] += 9.958781516019945e-05;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
                    result[0] += -0.00029489097545620097;
                  } else {
                    result[0] += 8.810916384669257e-05;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
                  result[0] += 0.0002526591384804119;
                } else {
                  result[0] += 9.898527370230504e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4983996163819096048) ) ) {
                result[0] += -0.0009719506702916236;
              } else {
                result[0] += 8.978719499741626e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
                result[0] += -1.6323177489887253e-06;
              } else {
                result[0] += 9.589998571550725e-05;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5932867452288201893) ) ) {
                result[0] += 8.169321402053349e-05;
              } else {
                result[0] += 8.970293893502599e-05;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -8.586085339272523e-07;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -1.0322374746165005e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.0732606574136245e-06;
            } else {
              result[0] += -1.0732606574136245e-06;
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)15.50000000000000178) ) ) {
            result[0] += -3.6842753272511354e-05;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4992188184422110542) ) ) {
              result[0] += 0.0003246855833394562;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1129321246270776624) ) ) {
                result[0] += -0.00011368270605328004;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003808500000000000687) ) ) {
                  result[0] += -1.2604877083520712e-05;
                } else {
                  result[0] += 1.45978564801682e-05;
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -1.0732606574136245e-06;
                } else {
                  result[0] += -1.0732606574136245e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -1.0732606574136245e-06;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -1.0732606574136245e-06;
                    } else {
                      result[0] += -1.0732606574136245e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -1.0732606574136245e-06;
                    } else {
                      result[0] += -1.0732606574136245e-06;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -1.0732606574136245e-06;
              } else {
                result[0] += -1.0732606574136245e-06;
              }
            }
          } else {
            result[0] += -1.2530730386055006e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -1.0732606574136245e-06;
              } else {
                result[0] += -1.0732606574136245e-06;
              }
            } else {
              result[0] += -1.0732606574136245e-06;
            }
          } else {
            result[0] += -1.0732606574136245e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07802786554345496339) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1255.500000000000227) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)3.500000000000000444) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.002217727144458050623) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.029997717272797003e-05) ) ) {
                  result[0] += 0.00022421921499253712;
                } else {
                  result[0] += -0.00048133890666439975;
                }
              } else {
                result[0] += 0.00047328358503357775;
              }
            } else {
              result[0] += 2.1222042190005204e-07;
            }
          } else {
            result[0] += 0.0004993345119323085;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)27.50000000000000355) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.741363993241206054) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
                result[0] += 0.0003801645106890651;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1405997886577425304) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02231150000000000147) ) ) {
                    result[0] += 0.0005487202160182869;
                  } else {
                    result[0] += -0.0008248766651749866;
                  }
                } else {
                  result[0] += -0.0004455917924910148;
                }
              }
            } else {
              result[0] += -0.0005676976043149309;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8030059940338053481) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)111.5000000000000142) ) ) {
                result[0] += 0.0005012710798829613;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)165.5000000000000284) ) ) {
                  result[0] += -0.00034099427451228433;
                } else {
                  result[0] += 0.000571401612706189;
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7831470153266332224) ) ) {
                result[0] += -0.0005493398429522695;
              } else {
                result[0] += 0.0005022503429094128;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 7.981124605566727e-05;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
            if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1185261981962025396) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)201.5000000000000284) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01112050000000000191) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03087413318892935285) ) ) {
                    result[0] += 0.00012279182068970377;
                  } else {
                    result[0] += 9.53611793834221e-05;
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07184972061993401271) ) ) {
                    result[0] += -3.241765879783937e-06;
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)59.50000000000000711) ) ) {
                      result[0] += 0.0001571332509511858;
                    } else {
                      result[0] += 8.436969688903807e-05;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
                  result[0] += 0.000241935957614225;
                } else {
                  result[0] += 9.478421056489726e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4983996163819096048) ) ) {
                result[0] += -0.000930699825801159;
              } else {
                result[0] += 8.597651022576835e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
                result[0] += -1.5630400709338547e-06;
              } else {
                result[0] += 9.182986619370136e-05;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5932867452288201893) ) ) {
                result[0] += 7.822604827798055e-05;
              } else {
                result[0] += 8.589583009972094e-05;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -8.221680764083517e-07;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -9.884279801183305e-07;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.0277100859392325e-06;
            } else {
              result[0] += -1.0277100859392325e-06;
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)15.50000000000000178) ) ) {
            result[0] += -3.527909913624862e-05;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.568345700351758909) ) ) {
              if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.07196201389915944657) ) ) {
                result[0] += -1.0777391375289184e-05;
              } else {
                result[0] += 0.0005671684200208965;
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.640890220251256415) ) ) {
                result[0] += -3.854010703318939e-05;
              } else {
                result[0] += 6.281941882987516e-05;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -1.0277100859392325e-06;
                } else {
                  result[0] += -1.0277100859392325e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -1.0277100859392325e-06;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -1.0277100859392325e-06;
                    } else {
                      result[0] += -1.0277100859392325e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -1.0277100859392325e-06;
                    } else {
                      result[0] += -1.0277100859392325e-06;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -1.0277100859392325e-06;
              } else {
                result[0] += -1.0277100859392325e-06;
              }
            }
          } else {
            result[0] += -1.1998909969333419e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -1.0277100859392325e-06;
              } else {
                result[0] += -1.0277100859392325e-06;
              }
            } else {
              result[0] += -1.0277100859392325e-06;
            }
          } else {
            result[0] += -1.0277100859392325e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07802786554345496339) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1255.500000000000227) ) ) {
            result[0] += 2.779480422868399e-06;
          } else {
            result[0] += 0.0004781421089328222;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.173295225808050013) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)20.50000000000000355) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05151350000000001067) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01112050000000000191) ) ) {
                  result[0] += -0.00023796557328624668;
                } else {
                  result[0] += 0.0005279898078985021;
                }
              } else {
                result[0] += -0.0004892603345968489;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9350000000000001643) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01962450000000000652) ) ) {
                  result[0] += 0.00023871786836845646;
                } else {
                  result[0] += 0.0024161091203913246;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03588950000000001167) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8850000000000001199) ) ) {
                    result[0] += 8.52829395575463e-05;
                  } else {
                    result[0] += 0.0003511989938065335;
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)111.5000000000000142) ) ) {
                    result[0] += 0.0002197979195475531;
                  } else {
                    result[0] += -0.0004992053058976684;
                  }
                }
              }
            }
          } else {
            result[0] += -0.0004883352081446239;
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 7.642395346946366e-05;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
            if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1000116863636408421) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
                result[0] += -0.00010681060600550353;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)153.5000000000000284) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00799650000000000187) ) ) {
                    result[0] += 9.822744656887196e-05;
                  } else {
                    result[0] += 8.096175813528007e-05;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02803443610476625408) ) ) {
                    result[0] += 0.00024045777243213048;
                  } else {
                    result[0] += 8.552948845600458e-05;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5196530228391961215) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06439350000000000629) ) ) {
                  result[0] += 0.0002137964632897334;
                } else {
                  result[0] += -0.0003609900822534182;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1245513101099625097) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02747750000000000539) ) ) {
                    result[0] += 3.143339842697547e-05;
                  } else {
                    result[0] += 0.00015163136956919493;
                  }
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02278050000000000561) ) ) {
                    result[0] += 0.00011029842987562183;
                  } else {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6067453057537689487) ) ) {
                      result[0] += -0.0007293000566546163;
                    } else {
                      result[0] += 6.464043733331158e-05;
                    }
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
                result[0] += -1.4967026272044315e-06;
              } else {
                result[0] += 8.793248781255323e-05;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5932867452288201893) ) ) {
                result[0] += 7.490603353726192e-05;
              } else {
                result[0] += 8.225029989111301e-05;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -7.87274199073247e-07;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -9.464778172714339e-07;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -9.840927396765462e-07;
            } else {
              result[0] += -9.840927396765462e-07;
            }
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5494686760804020631) ) ) {
            if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.07196201389915944657) ) ) {
              result[0] += -6.446304516685826e-05;
            } else {
              result[0] += 0.0007136060344075171;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01813850000000000531) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4330073079623726895) ) ) {
                result[0] += -5.6157947872976294e-05;
              } else {
                result[0] += 3.971464796441859e-05;
              }
            } else {
              result[0] += 5.418871839304378e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -9.840927396765462e-07;
                } else {
                  result[0] += -9.840927396765462e-07;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -9.840927396765462e-07;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -9.840927396765462e-07;
                    } else {
                      result[0] += -9.840927396765462e-07;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -9.840927396765462e-07;
                    } else {
                      result[0] += -9.840927396765462e-07;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -9.840927396765462e-07;
              } else {
                result[0] += -9.840927396765462e-07;
              }
            }
          } else {
            result[0] += -1.1489660699459139e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -9.840927396765462e-07;
              } else {
                result[0] += -9.840927396765462e-07;
              }
            } else {
              result[0] += -9.840927396765462e-07;
            }
          } else {
            result[0] += -9.840927396765462e-07;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07802786554345496339) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1255.500000000000227) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)3.500000000000000444) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.002217727144458050623) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.029997717272797003e-05) ) ) {
                  result[0] += 0.00021458509654359456;
                } else {
                  result[0] += -0.0004610282251918394;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003250500000000000351) ) ) {
                  result[0] += 0.0007202470490609299;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4450000000000000622) ) ) {
                    result[0] += 0.0005319850794294047;
                  } else {
                    result[0] += -5.908682904015466e-05;
                  }
                }
              }
            } else {
              result[0] += 8.524876574527844e-08;
            }
          } else {
            result[0] += 0.0004578491389469977;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)21.50000000000000355) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05151350000000001067) ) ) {
              result[0] += 5.227495045008046e-05;
            } else {
              result[0] += -0.0005692819073017764;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9350000000000001643) ) ) {
                result[0] += 0.002144616933898406;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02985350000000000156) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01439950000000000084) ) ) {
                    result[0] += 0.0001263061580489276;
                  } else {
                    result[0] += 0.0007349752179454059;
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)111.5000000000000142) ) ) {
                    result[0] += 0.0002192691893824675;
                  } else {
                    result[0] += -0.0003839221330773442;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7550000000000001155) ) ) {
                result[0] += -0.00044309957666277967;
              } else {
                result[0] += 0.000288970662007482;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 7.318042196495676e-05;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
            if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1185261981962025396) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)201.5000000000000284) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01112050000000000191) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03087413318892935285) ) ) {
                    result[0] += 0.0001221086382662645;
                  } else {
                    result[0] += 8.75882996266271e-05;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
                    result[0] += -0.00028567395783414215;
                  } else {
                    result[0] += 7.71993513034971e-05;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
                  result[0] += 0.00022146254332526218;
                } else {
                  result[0] += 8.713146378961423e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4983996163819096048) ) ) {
                result[0] += -0.000890515651947486;
              } else {
                result[0] += 7.764634771960937e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
                result[0] += -1.4331806304519973e-06;
              } else {
                result[0] += 8.420051921446792e-05;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5932867452288201893) ) ) {
                result[0] += 7.172692451939998e-05;
              } else {
                result[0] += 7.875949070315065e-05;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -7.538612630570683e-07;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -9.063080736339069e-07;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -9.423265700453127e-07;
            } else {
              result[0] += -9.423265700453127e-07;
            }
          }
        } else {
          result[0] += -4.098306500931543e-06;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -9.423265700453127e-07;
                } else {
                  result[0] += -9.423265700453127e-07;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -9.423265700453127e-07;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -9.423265700453127e-07;
                    } else {
                      result[0] += -9.423265700453127e-07;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -9.423265700453127e-07;
                    } else {
                      result[0] += -9.423265700453127e-07;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -9.423265700453127e-07;
              } else {
                result[0] += -9.423265700453127e-07;
              }
            }
          } else {
            result[0] += -1.1002024627744432e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -9.423265700453127e-07;
              } else {
                result[0] += -9.423265700453127e-07;
              }
            } else {
              result[0] += -9.423265700453127e-07;
            }
          } else {
            result[0] += -9.423265700453127e-07;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07802786554345496339) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)183.5000000000000284) ) ) {
            result[0] += -5.24760530179627e-06;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)241.5000000000000284) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.08974471890433978472) ) ) {
                result[0] += 0.0007590942624265962;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1650000000000000355) ) ) {
                    result[0] += -0.0004900928396932307;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01154850000000000147) ) ) {
                      result[0] += 0.0003901005111080526;
                    } else {
                      result[0] += -0.00033101442051510144;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3419045205559314016) ) ) {
                    result[0] += 0.0008185141236003558;
                  } else {
                    result[0] += 0.00013226567871866133;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5811189422864322385) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02447420998234165271) ) ) {
                  result[0] += 5.119493722437913e-05;
                } else {
                  result[0] += 0.0006029948487224653;
                }
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)362.5000000000000568) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8645446433232079064) ) ) {
                      result[0] += -0.0003584716484332791;
                    } else {
                      result[0] += 0.0001517893903568792;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9911809338528255742) ) ) {
                      result[0] += -0.0010416189468461887;
                    } else {
                      result[0] += -0.00016555389503414492;
                    }
                  }
                } else {
                  result[0] += 6.493117487615737e-06;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)27.50000000000000355) ) ) {
            result[0] += -9.238437593060013e-05;
          } else {
            result[0] += 0.00030510034507591184;
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 7.007455013576673e-05;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)189.5000000000000284) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004143500000000000481) ) ) {
                result[0] += 0.00012353760212186442;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01321089953182515153) ) ) {
                  result[0] += -0.0013634666018713783;
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4589535259190716254) ) ) {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)82.50000000000001421) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02633100000000000371) ) ) {
                        result[0] += 0.00010134352900921214;
                      } else {
                        result[0] += -0.00012281519158365074;
                      }
                    } else {
                      result[0] += 8.136122602787768e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1177750000000000186) ) ) {
                      result[0] += 7.37960267678956e-05;
                    } else {
                      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5064897371608040322) ) ) {
                        result[0] += -0.0002427010762898557;
                      } else {
                        result[0] += 0.00012881766848059614;
                      }
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03358130704046471265) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02523350000000000246) ) ) {
                  result[0] += 0.00023995331482495102;
                } else {
                  result[0] += -0.0001702224658804034;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4914057384422110819) ) ) {
                  result[0] += 7.92802209729121e-05;
                } else {
                  result[0] += 8.354309163962129e-05;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
                result[0] += -1.372354589457555e-06;
              } else {
                result[0] += 8.062694019415766e-05;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5932867452288201893) ) ) {
                result[0] += 6.868274100313039e-05;
              } else {
                result[0] += 7.541683597544925e-05;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -7.218664152934464e-07;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -8.678431859100205e-07;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -9.023330107132245e-07;
            } else {
              result[0] += -9.023330107132245e-07;
            }
          }
        } else {
          result[0] += -3.924369068393472e-06;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -9.023330107132245e-07;
                } else {
                  result[0] += -9.023330107132245e-07;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -9.023330107132245e-07;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -9.023330107132245e-07;
                    } else {
                      result[0] += -9.023330107132245e-07;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -9.023330107132245e-07;
                    } else {
                      result[0] += -9.023330107132245e-07;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -9.023330107132245e-07;
              } else {
                result[0] += -9.023330107132245e-07;
              }
            }
          } else {
            result[0] += -1.0535084462084443e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -9.023330107132245e-07;
              } else {
                result[0] += -9.023330107132245e-07;
              }
            } else {
              result[0] += -9.023330107132245e-07;
            }
          } else {
            result[0] += -9.023330107132245e-07;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03472639088202265217) ) ) {
          result[0] += -2.923137636276544e-07;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.213351496714494937) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
              result[0] += -0.0007342319288374918;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1165587384072143268) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5308132790452262384) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4983996163819096048) ) ) {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)71.50000000000001421) ) ) {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1167934537543566104) ) ) {
                        result[0] += -0.00014230888835097666;
                      } else {
                        result[0] += 0.000762779411351093;
                      }
                    } else {
                      result[0] += 0.000754254479619182;
                    }
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04324794178047625809) ) ) {
                      result[0] += 0.0006742530738850459;
                    } else {
                      result[0] += -0.0005043145273475801;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02928050000000000444) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0465984882276438625) ) ) {
                      result[0] += -0.0002461859219432457;
                    } else {
                      result[0] += 0.0002809683191167118;
                    }
                  } else {
                    result[0] += 0.0013385229220625587;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6152470170603016042) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2397171522356433271) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1913179023522538491) ) ) {
                      result[0] += -0.00037341391134239826;
                    } else {
                      result[0] += 0.0005469301319365468;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8050000000000001599) ) ) {
                      result[0] += -0.0002640474157279899;
                    } else {
                      result[0] += -0.002672283819658841;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0650000000000000161) ) ) {
                    result[0] += -0.000171687162393691;
                  } else {
                    result[0] += 0.00025496189744411284;
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8371684470603016903) ) ) {
              result[0] += -0.0013891160642562305;
            } else {
              result[0] += 6.801616236375355e-05;
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 6.710049552708837e-05;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4589535259190716254) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
                result[0] += -7.799202931562542e-05;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02633100000000000371) ) ) {
                    result[0] += 0.00012852206866911472;
                  } else {
                    result[0] += -0.00023243398678593987;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
                    result[0] += 0.00020083707633080205;
                  } else {
                    result[0] += 7.168923443852183e-05;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4086612272110553001) ) ) {
                result[0] += -0.00035549304534506095;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1245513101099625097) ) ) {
                  result[0] += 7.584517339356176e-05;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02278050000000000561) ) ) {
                    result[0] += 9.412530385337253e-05;
                  } else {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6586934769095478259) ) ) {
                      result[0] += -0.00017083918176255268;
                    } else {
                      result[0] += 0.00013889214900300066;
                    }
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)48.50000000000000711) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3801755927260667134) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1207797749301366269) ) ) {
                  result[0] += 7.466461978040774e-05;
                } else {
                  result[0] += 8.49782505745719e-06;
                }
              } else {
                result[0] += 6.524116834947444e-05;
              }
            } else {
              result[0] += 7.236816913914622e-05;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -6.912294702813609e-07;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -8.310107978081211e-07;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -8.6403682980481e-07;
            } else {
              result[0] += -8.6403682980481e-07;
            }
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5494686760804020631) ) ) {
            if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.07196201389915944657) ) ) {
              result[0] += -6.138665735700132e-05;
            } else {
              result[0] += 0.0006836601633873757;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01813850000000000531) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4330073079623726895) ) ) {
                result[0] += -5.343403914196529e-05;
              } else {
                result[0] += 3.836959963550103e-05;
              }
            } else {
              result[0] += 5.2229371780638174e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -8.6403682980481e-07;
                } else {
                  result[0] += -8.6403682980481e-07;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -8.6403682980481e-07;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -8.6403682980481e-07;
                    } else {
                      result[0] += -8.6403682980481e-07;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -8.6403682980481e-07;
                    } else {
                      result[0] += -8.6403682980481e-07;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -8.6403682980481e-07;
              } else {
                result[0] += -8.6403682980481e-07;
              }
            }
          } else {
            result[0] += -1.0087961841438776e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -8.6403682980481e-07;
              } else {
                result[0] += -8.6403682980481e-07;
              }
            } else {
              result[0] += -8.6403682980481e-07;
            }
          } else {
            result[0] += -8.6403682980481e-07;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07802786554345496339) ) ) {
          result[0] += 2.814122961283289e-06;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)21.50000000000000355) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05151350000000001067) ) ) {
              result[0] += 5.6669245644402506e-05;
            } else {
              result[0] += -0.0005425250730443605;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9750000000000000888) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5308132790452262384) ) ) {
                  result[0] += 0.0007587170708834444;
                } else {
                  result[0] += 0.0018263122418868787;
                }
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)44.50000000000000711) ) ) {
                  result[0] += 0.0004726364318919138;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02985350000000000156) ) ) {
                    result[0] += 0.00014110390342889458;
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)107.5000000000000142) ) ) {
                      result[0] += -3.8672105010759384e-05;
                    } else {
                      result[0] += -0.0006999056914464869;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7831470153266332224) ) ) {
                result[0] += -0.0005847951800557826;
              } else {
                result[0] += 0.0004934150772500022;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 6.425266364546738e-05;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
            if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1000116863636408421) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)201.5000000000000284) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02007650000000000406) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)19.50000000000000355) ) ) {
                    result[0] += -2.905868257503769e-05;
                  } else {
                    result[0] += 8.271230322761526e-05;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03296628516090911037) ) ) {
                    result[0] += -0.0006769526526713642;
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03588950000000001167) ) ) {
                      result[0] += -2.488767635819589e-05;
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0501585000000000017) ) ) {
                        result[0] += 0.00019440718696032289;
                      } else {
                        result[0] += 6.250273383780914e-05;
                      }
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
                  result[0] += 0.0001965271228838508;
                } else {
                  result[0] += 7.70417619564029e-05;
                }
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9194299814036738239) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6571412079648242255) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3872449054220527542) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2659201053550500626) ) ) {
                      result[0] += 4.9933805461551024e-05;
                    } else {
                      result[0] += 0.00010612596585454911;
                    }
                  } else {
                    result[0] += -0.00045148356787545903;
                  }
                } else {
                  result[0] += 0.00016965437903442913;
                }
              } else {
                result[0] += -0.00040864441991221936;
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
                result[0] += -1.6747687789641506e-06;
              } else {
                result[0] += 7.443610886333771e-05;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5932867452288201893) ) ) {
                result[0] += 6.281919125474656e-05;
              } else {
                result[0] += 6.91446490730265e-05;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -6.618927968704885e-07;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -7.957416239312273e-07;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -8.273659883827686e-07;
            } else {
              result[0] += -8.273659883827686e-07;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6285027855690678011) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1129321246270776624) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5072068278894473758) ) ) {
                result[0] += 6.211880923313635e-06;
              } else {
                result[0] += -0.000158129514377113;
              }
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6242923255276383587) ) ) {
                result[0] += 6.728525425040738e-05;
              } else {
                result[0] += -1.490003982152934e-06;
              }
            }
          } else {
            result[0] += -3.2846298141969795e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -8.273659883827686e-07;
                } else {
                  result[0] += -8.273659883827686e-07;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -8.273659883827686e-07;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -8.273659883827686e-07;
                    } else {
                      result[0] += -8.273659883827686e-07;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -8.273659883827686e-07;
                    } else {
                      result[0] += -8.273659883827686e-07;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -8.273659883827686e-07;
              } else {
                result[0] += -8.273659883827686e-07;
              }
            }
          } else {
            result[0] += -9.659815683546038e-07;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -8.273659883827686e-07;
              } else {
                result[0] += -8.273659883827686e-07;
              }
            } else {
              result[0] += -8.273659883827686e-07;
            }
          } else {
            result[0] += -8.273659883827686e-07;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03472639088202265217) ) ) {
          result[0] += -3.993426100771458e-07;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.213351496714494937) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
              result[0] += -0.0007054752915602599;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1165587384072143268) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5792515097236182742) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5308132790452262384) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4983996163819096048) ) ) {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)84.50000000000001421) ) ) {
                        result[0] += 0.00010525230860505509;
                      } else {
                        result[0] += 0.000698166976960802;
                      }
                    } else {
                      result[0] += -0.00019962358134673796;
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
                      result[0] += 0.002170965128769573;
                    } else {
                      result[0] += 3.0064005288278623e-05;
                    }
                  }
                } else {
                  result[0] += -0.0002443410368818832;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6152470170603016042) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2397171522356433271) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1913179023522538491) ) ) {
                      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)29.50000000000000355) ) ) {
                        result[0] += -0.0005694840922605579;
                      } else {
                        result[0] += 0.0001244252231673522;
                      }
                    } else {
                      result[0] += 0.0005183159944696633;
                    }
                  } else {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5951110425376885393) ) ) {
                      result[0] += -0.0020271963566969677;
                    } else {
                      result[0] += -0.0001249058828498204;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0650000000000000161) ) ) {
                    result[0] += -0.00016451997201954581;
                  } else {
                    result[0] += 0.0002455534230660712;
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8371684470603016903) ) ) {
              result[0] += -0.0013302796155092711;
            } else {
              result[0] += 6.501003337545721e-05;
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 6.152569743498686e-05;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
            if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1000116863636408421) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)201.5000000000000284) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02007650000000000406) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)19.50000000000000355) ) ) {
                    result[0] += -2.782539447447737e-05;
                  } else {
                    result[0] += 7.920188602005461e-05;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03296628516090911037) ) ) {
                    result[0] += -0.0006482219058790682;
                  } else {
                    result[0] += 6.473415859464272e-05;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
                  result[0] += 0.0001881862574139928;
                } else {
                  result[0] += 7.377200986005118e-05;
                }
              }
            } else {
              result[0] += 5.975511355444865e-05;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
                result[0] += -1.6036894242485944e-06;
              } else {
                result[0] += 7.127694405688006e-05;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5932867452288201893) ) ) {
                result[0] += 6.0153063467944514e-05;
              } else {
                result[0] += 6.621006066906587e-05;
              }
            }
          }
        }
      }
    }
  }
}

