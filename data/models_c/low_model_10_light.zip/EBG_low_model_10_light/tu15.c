
#include "header.h"

void predict_unit15(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -3.6066448677413197e-07;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -4.3359853099609807e-07;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -4.508306042689906e-07;
            } else {
              result[0] += -4.508306042689906e-07;
            }
          }
        } else {
          result[0] += 2.0990456567539395e-06;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -4.508306042689906e-07;
                } else {
                  result[0] += -4.508306042689906e-07;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -4.508306042689906e-07;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -4.508306042689906e-07;
                    } else {
                      result[0] += -4.508306042689906e-07;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -4.508306042689906e-07;
                    } else {
                      result[0] += -4.508306042689906e-07;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -4.508306042689906e-07;
              } else {
                result[0] += -4.508306042689906e-07;
              }
            }
          } else {
            result[0] += -5.263620456833265e-07;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -4.508306042689906e-07;
              } else {
                result[0] += -4.508306042689906e-07;
              }
            } else {
              result[0] += -4.508306042689906e-07;
            }
          } else {
            result[0] += -4.508306042689906e-07;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.752860906001682428) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03472639088202265217) ) ) {
            result[0] += 2.63737892717154e-08;
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
              result[0] += -0.0006415264243364317;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1165587384072143268) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5792515097236182742) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5315044381658292627) ) ) {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3966836129899497521) ) ) {
                      result[0] += 0.0007953533727714519;
                    } else {
                      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4213441621608040588) ) ) {
                        result[0] += -0.0004964665178410539;
                      } else {
                        result[0] += 9.859136282914137e-05;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9350000000000001643) ) ) {
                      result[0] += 0.0017316603687181505;
                    } else {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06826496544164491198) ) ) {
                        result[0] += -0.0004353503281524071;
                      } else {
                        result[0] += 0.00016368228887670886;
                      }
                    }
                  }
                } else {
                  result[0] += -0.000250539130946112;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5628434130653267031) ) ) {
                  result[0] += -0.00073797271984506;
                } else {
                  result[0] += 4.18615187432493e-05;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)3.217614006880118073e-05) ) ) {
            result[0] += 0.00012425776174531612;
          } else {
            result[0] += -0.00027396088691137395;
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 3.352526903711482e-05;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4589535259190716254) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
                result[0] += -6.612737546040426e-05;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02633100000000000371) ) ) {
                    result[0] += 8.370832818930896e-05;
                  } else {
                    result[0] += -0.000131719091981114;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
                    result[0] += 0.00010768823155534231;
                  } else {
                    result[0] += 3.7610230560803116e-05;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)189.5000000000000284) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4086612272110553001) ) ) {
                  result[0] += -0.00024919054382348445;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)137.5000000000000284) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3830383354773237436) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2542665105872564113) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
                          result[0] += 5.61781466074827e-05;
                        } else {
                          result[0] += -0.0004651128672807091;
                        }
                      } else {
                        result[0] += 8.412826449266966e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)61.50000000000000711) ) ) {
                        result[0] += 5.088070878888025e-05;
                      } else {
                        result[0] += -0.0007203890192910107;
                      }
                    }
                  } else {
                    result[0] += -7.500002872028787e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)346.5000000000000568) ) ) {
                  result[0] += 5.202571193440023e-05;
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)488.5000000000000568) ) ) {
                    result[0] += -0.0001448911928632564;
                  } else {
                    result[0] += 5.807345360521734e-05;
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)48.50000000000000711) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3801755927260667134) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1207797749301366269) ) ) {
                  result[0] += 4.011704466019554e-05;
                } else {
                  result[0] += 2.0329619940618527e-06;
                }
              } else {
                result[0] += 3.2578389261912565e-05;
              }
            } else {
              result[0] += 3.800889526016224e-05;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -3.4535741912974985e-07;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -4.151960481128395e-07;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -4.316967698917152e-07;
            } else {
              result[0] += -4.316967698917152e-07;
            }
          }
        } else {
          result[0] += 2.00995944218385e-06;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -4.316967698917152e-07;
                } else {
                  result[0] += -4.316967698917152e-07;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -4.316967698917152e-07;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -4.316967698917152e-07;
                    } else {
                      result[0] += -4.316967698917152e-07;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -4.316967698917152e-07;
                    } else {
                      result[0] += -4.316967698917152e-07;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -4.316967698917152e-07;
              } else {
                result[0] += -4.316967698917152e-07;
              }
            }
          } else {
            result[0] += -5.040225591683572e-07;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -4.316967698917152e-07;
              } else {
                result[0] += -4.316967698917152e-07;
              }
            } else {
              result[0] += -4.316967698917152e-07;
            }
          } else {
            result[0] += -4.316967698917152e-07;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1322620000000000184) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)37.50000000000000711) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3665106630729573767) ) ) {
              result[0] += -7.676362761967667e-05;
            } else {
              result[0] += 2.8751795712068802e-05;
            }
          } else {
            result[0] += 1.3395845424989477e-05;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8352912313316583903) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8030059940338053481) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5308132790452262384) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06116598190050365896) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03241729119215525784) ) ) {
                    result[0] += -0.00023904715716324356;
                  } else {
                    result[0] += 0.0012573560937589074;
                  }
                } else {
                  result[0] += -0.0006064039806421953;
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06270917377236372159) ) ) {
                  result[0] += 0.00024471474413955807;
                } else {
                  result[0] += 0.0011587362557593656;
                }
              }
            } else {
              result[0] += -0.0012961102780896271;
            }
          } else {
            result[0] += 0.0008020461125559346;
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 3.21024132257848e-05;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4589535259190716254) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
                result[0] += -9.885482823535739e-05;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)105.5000000000000142) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02633100000000000371) ) ) {
                    result[0] += 4.650512799045218e-05;
                  } else {
                    result[0] += 9.820257005878836e-05;
                  }
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03842800000000001076) ) ) {
                    result[0] += 3.412621556615135e-05;
                  } else {
                    result[0] += 3.9679721753257716e-05;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4086612272110553001) ) ) {
                result[0] += -0.0003456292389616687;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)189.5000000000000284) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)137.5000000000000284) ) ) {
                    if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.02463433988323724885) ) ) {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08260095417535827378) ) ) {
                        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.226146172451905686) ) ) {
                          result[0] += 7.030150261923743e-05;
                        } else {
                          result[0] += 0.00013410003513987328;
                        }
                      } else {
                        result[0] += 7.3613840894476295e-06;
                      }
                    } else {
                      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5451673325125628855) ) ) {
                        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)42.50000000000000711) ) ) {
                          result[0] += -0.0016036654135222175;
                        } else {
                          result[0] += 1.2232690865437674e-05;
                        }
                      } else {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3872449054220527542) ) ) {
                          result[0] += 0.00011665051912052795;
                        } else {
                          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)61.50000000000000711) ) ) {
                            result[0] += 3.646377347659053e-05;
                          } else {
                            result[0] += -0.0008667205207748515;
                          }
                        }
                      }
                    }
                  } else {
                    result[0] += -7.861554581149591e-05;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03358130704046471265) ) ) {
                    result[0] += 2.887919702674816e-05;
                  } else {
                    result[0] += 5.1167424005248724e-05;
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
                result[0] += -1.8670980197660877e-06;
              } else {
                result[0] += 3.8641848652371296e-05;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5932867452288201893) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2394849609754011732) ) ) {
                  result[0] += 3.272250656971196e-05;
                } else {
                  result[0] += 3.119572025383243e-05;
                }
              } else {
                result[0] += 3.4434492177775074e-05;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -3.3070000324889335e-07;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -3.975745904223799e-07;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -4.13375000211269e-07;
            } else {
              result[0] += -4.13375000211269e-07;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6214144784636018715) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1051257686552766607) ) ) {
              result[0] += -6.0987361705581974e-05;
            } else {
              result[0] += 2.3548984568649695e-05;
            }
          } else {
            result[0] += -2.4455434806309103e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -4.13375000211269e-07;
                } else {
                  result[0] += -4.13375000211269e-07;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -4.13375000211269e-07;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -4.13375000211269e-07;
                    } else {
                      result[0] += -4.13375000211269e-07;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -4.13375000211269e-07;
                    } else {
                      result[0] += -4.13375000211269e-07;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -4.13375000211269e-07;
              } else {
                result[0] += -4.13375000211269e-07;
              }
            }
          } else {
            result[0] += -4.826311893762105e-07;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -4.13375000211269e-07;
              } else {
                result[0] += -4.13375000211269e-07;
              }
            } else {
              result[0] += -4.13375000211269e-07;
            }
          } else {
            result[0] += -4.13375000211269e-07;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8050000000000001599) ) ) {
          result[0] += -3.018627225916521e-07;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001872500000000000249) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0007055000000000000724) ) ) {
              result[0] += -7.537664446739432e-05;
            } else {
              result[0] += 0.0004931328436244375;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2669585275879397535) ) ) {
              result[0] += 0.0010556280311147094;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3837516359296482826) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01559164707745600183) ) ) {
                  result[0] += -0.0027078167481792885;
                } else {
                  result[0] += 0.00011992417817245076;
                }
              } else {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2185860198827210554) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.009723928609266600451) ) ) {
                    result[0] += 0.0011631250750390697;
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02116634333934230491) ) ) {
                      result[0] += -0.00017909078091959437;
                    } else {
                      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4213441621608040588) ) ) {
                        result[0] += -3.5105596238654305e-05;
                      } else {
                        result[0] += 0.0005044577844989229;
                      }
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.005088231471697101001) ) ) {
                    result[0] += -0.001187256733105866;
                  } else {
                    result[0] += 3.293020601489657e-05;
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 3.0739945256757536e-05;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4589535259190716254) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
                result[0] += -9.465930137241033e-05;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02633100000000000371) ) ) {
                    result[0] += 0.00010095449625262024;
                  } else {
                    result[0] += -0.00027432595374437006;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
                    result[0] += 0.00010166944286212798;
                  } else {
                    result[0] += 3.531201734975249e-05;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4086612272110553001) ) ) {
                result[0] += -0.00033096028669530935;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)189.5000000000000284) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)137.5000000000000284) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04014591590259960346) ) ) {
                      result[0] += 0.0001723263151058767;
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03759900000000000742) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06270917377236372159) ) ) {
                          result[0] += -0.00020248816849714965;
                        } else {
                          result[0] += 9.710430479682029e-06;
                        }
                      } else {
                        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1536978514979052968) ) ) {
                          result[0] += 0.00013704017054183505;
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.03091333598004935429) ) ) {
                            result[0] += -0.00014497855260095946;
                          } else {
                            result[0] += 0.000155803220996986;
                          }
                        }
                      }
                    }
                  } else {
                    result[0] += -7.527900029131203e-05;
                  }
                } else {
                  result[0] += 4.779186516774816e-05;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
                result[0] += -1.7878559631317154e-06;
              } else {
                result[0] += 3.7001838579532264e-05;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5932867452288201893) ) ) {
                result[0] += 2.9871733508115415e-05;
              } else {
                result[0] += 3.297304775950321e-05;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -3.166646670697936e-07;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -3.80701010204618e-07;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.958308301508235e-07;
            } else {
              result[0] += -3.958308301508235e-07;
            }
          }
        } else {
          result[0] += 1.0086742159581388e-06;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -3.958308301508235e-07;
                } else {
                  result[0] += -3.958308301508235e-07;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -3.958308301508235e-07;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -3.958308301508235e-07;
                    } else {
                      result[0] += -3.958308301508235e-07;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -3.958308301508235e-07;
                    } else {
                      result[0] += -3.958308301508235e-07;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -3.958308301508235e-07;
              } else {
                result[0] += -3.958308301508235e-07;
              }
            }
          } else {
            result[0] += -4.621476970059253e-07;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -3.958308301508235e-07;
              } else {
                result[0] += -3.958308301508235e-07;
              }
            } else {
              result[0] += -3.958308301508235e-07;
            }
          } else {
            result[0] += -3.958308301508235e-07;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8050000000000001599) ) ) {
          result[0] += -2.8905127792909984e-07;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001872500000000000249) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0007055000000000000724) ) ) {
              result[0] += -7.217756211251888e-05;
            } else {
              result[0] += 0.0004722036474550614;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2669585275879397535) ) ) {
              result[0] += 0.0010108258111232145;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3837516359296482826) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01559164707745600183) ) ) {
                  result[0] += -0.0025928935005269126;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9650000000000000799) ) ) {
                    result[0] += 0.0011612413860954964;
                  } else {
                    result[0] += -0.0003601102536460489;
                  }
                }
              } else {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2185860198827210554) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8950000000000001288) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8450000000000000844) ) ) {
                      result[0] += 0.0021910853202014554;
                    } else {
                      result[0] += -0.0006930506280329298;
                    }
                  } else {
                    result[0] += 0.00033533528875178727;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.231660934306704425) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6280024623366835534) ) ) {
                      result[0] += -6.126198699236525e-05;
                    } else {
                      result[0] += 0.0001620119011085046;
                    }
                  } else {
                    result[0] += -0.00045850293926915026;
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 2.943530219184833e-05;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4589535259190716254) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
                result[0] += -9.06418381000015e-05;
              } else {
                result[0] += 3.671011091910677e-05;
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4086612272110553001) ) ) {
                result[0] += -0.00031691390374987473;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1245513101099625097) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09637729146099090205) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06270917377236372159) ) ) {
                      if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.07409325127878772788) ) ) {
                        if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1341510627350609164) ) ) {
                          result[0] += 6.410913866947584e-05;
                        } else {
                          result[0] += 0.00027774342701546644;
                        }
                      } else {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.04446937286580055632) ) ) {
                          result[0] += -9.68865924883521e-05;
                        } else {
                          result[0] += 0.00022138512757798512;
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)61.50000000000000711) ) ) {
                        result[0] += 5.9366575523096154e-05;
                      } else {
                        result[0] += 0.00011534306890339994;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1271566581126106488) ) ) {
                      result[0] += -0.00012649587542834338;
                    } else {
                      result[0] += 1.5325190577665157e-05;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01008250000000000292) ) ) {
                    result[0] += 0.00011611052090200217;
                  } else {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6571412079648242255) ) ) {
                      result[0] += -8.256946920155741e-05;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8440161800932387548) ) ) {
                        result[0] += 0.00022677816914675516;
                      } else {
                        result[0] += -0.0002637530902512521;
                      }
                    }
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
                result[0] += -1.711977041945602e-06;
              } else {
                result[0] += 3.543143265692579e-05;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5932867452288201893) ) ) {
                result[0] += 2.8603938473585973e-05;
              } else {
                result[0] += 3.1573628933961305e-05;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -3.032250087247837e-07;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -3.645435665715979e-07;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.790312573760206e-07;
            } else {
              result[0] += -3.790312573760206e-07;
            }
          }
        } else {
          result[0] += 9.658647766565076e-07;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -3.790312573760206e-07;
                } else {
                  result[0] += -3.790312573760206e-07;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -3.790312573760206e-07;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -3.790312573760206e-07;
                    } else {
                      result[0] += -3.790312573760206e-07;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -3.790312573760206e-07;
                    } else {
                      result[0] += -3.790312573760206e-07;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -3.790312573760206e-07;
              } else {
                result[0] += -3.790312573760206e-07;
              }
            }
          } else {
            result[0] += -4.425335505646522e-07;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -3.790312573760206e-07;
              } else {
                result[0] += -3.790312573760206e-07;
              }
            } else {
              result[0] += -3.790312573760206e-07;
            }
          } else {
            result[0] += -3.790312573760206e-07;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03472639088202265217) ) ) {
          result[0] += -4.828141094061799e-07;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.895681724436047322) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
              result[0] += -0.0006049149445157866;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2397171522356433271) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3510185000000000666) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)165.5000000000000284) ) ) {
                    result[0] += 0.00015748738048422092;
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02812450000000000366) ) ) {
                      result[0] += -4.356310723381293e-05;
                    } else {
                      result[0] += 0.0010068234237767507;
                    }
                  }
                } else {
                  result[0] += -0.0006554162989643521;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5951110425376885393) ) ) {
                  result[0] += -0.0019523118801332937;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2994824114585931674) ) ) {
                    result[0] += -0.001188218367469733;
                  } else {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7210440605025126848) ) ) {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1560895000000000199) ) ) {
                        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7080301875628142172) ) ) {
                          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)109.5000000000000142) ) ) {
                            result[0] += 0.00033349454776594853;
                          } else {
                            result[0] += -0.0005857876292331625;
                          }
                        } else {
                          result[0] += 0.0010921076944449164;
                        }
                      } else {
                        result[0] += 0.0014101352573061435;
                      }
                    } else {
                      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7422817934170855558) ) ) {
                        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)72.50000000000001421) ) ) {
                          result[0] += -1.4117000189459519e-05;
                        } else {
                          result[0] += -0.0012581904469712386;
                        }
                      } else {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003047500000000000295) ) ) {
                          result[0] += -0.0003259473457550296;
                        } else {
                          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8352912313316583903) ) ) {
                            result[0] += 2.4184287203764298e-05;
                          } else {
                            result[0] += 0.0010921960058292936;
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          } else {
            result[0] += -0.0008931293328958194;
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 2.8186029867277418e-05;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004143500000000000481) ) ) {
              result[0] += 7.475123000674378e-05;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.009723928609266600451) ) ) {
                result[0] += -0.0005436914620365646;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)189.5000000000000284) ) ) {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4589535259190716254) ) ) {
                    if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.5724391781153673753) ) ) {
                      result[0] += 2.644808678978439e-05;
                    } else {
                      result[0] += 4.123870045311629e-05;
                    }
                  } else {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4086612272110553001) ) ) {
                      result[0] += -0.00012840394109756364;
                    } else {
                      result[0] += 3.476087045262065e-05;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03358130704046471265) ) ) {
                    result[0] += 2.7656876984087464e-06;
                  } else {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4832433377889447379) ) ) {
                      result[0] += 3.249746968506207e-05;
                    } else {
                      result[0] += 4.788240777934603e-05;
                    }
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
                result[0] += -1.6393185203914503e-06;
              } else {
                result[0] += 3.3927676794329146e-05;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5932867452288201893) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2394849609754011732) ) ) {
                  result[0] += 2.8851937829727477e-05;
                } else {
                  result[0] += 2.7389950301290236e-05;
                }
              } else {
                result[0] += 3.0233603254714015e-05;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -2.903557468755236e-07;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -3.490718657597328e-07;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.62944680214289e-07;
            } else {
              result[0] += -3.62944680214289e-07;
            }
          }
        } else {
          result[0] += 9.248722253691884e-07;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -3.62944680214289e-07;
                } else {
                  result[0] += -3.62944680214289e-07;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -3.62944680214289e-07;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -3.62944680214289e-07;
                    } else {
                      result[0] += -3.62944680214289e-07;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -3.62944680214289e-07;
                    } else {
                      result[0] += -3.62944680214289e-07;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -3.62944680214289e-07;
              } else {
                result[0] += -3.62944680214289e-07;
              }
            }
          } else {
            result[0] += -4.237518538858717e-07;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -3.62944680214289e-07;
              } else {
                result[0] += -3.62944680214289e-07;
              }
            } else {
              result[0] += -3.62944680214289e-07;
            }
          } else {
            result[0] += -3.62944680214289e-07;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03472639088202265217) ) ) {
          result[0] += -4.6232285367319945e-07;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.895681724436047322) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
              result[0] += -0.0005792415712995413;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1165587384072143268) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5792515097236182742) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5315044381658292627) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4983996163819096048) ) ) {
                      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4838161673366834781) ) ) {
                        result[0] += 0.00021281792505538214;
                      } else {
                        result[0] += 0.000760074242164659;
                      }
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01133450000000000256) ) ) {
                        result[0] += 0.00033145957554733265;
                      } else {
                        result[0] += -0.0005658096034211035;
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01154850000000000147) ) ) {
                      result[0] += 0.00013097983992617408;
                    } else {
                      result[0] += 0.0010108551520664393;
                    }
                  }
                } else {
                  result[0] += -0.0002471333501971508;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6152470170603016042) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3872449054220527542) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2659201053550500626) ) ) {
                      result[0] += -0.0002976236108974317;
                    } else {
                      result[0] += 0.000649770078985813;
                    }
                  } else {
                    result[0] += -0.0016830617148111302;
                  }
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7210440605025126848) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7080301875628142172) ) ) {
                      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)33.50000000000000711) ) ) {
                        result[0] += 0.000614678552091946;
                      } else {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007850500000000001574) ) ) {
                          result[0] += 0.000726787100943954;
                        } else {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1377635000000000109) ) ) {
                            result[0] += -0.00029567220092265896;
                          } else {
                            result[0] += 0.0009200161225266224;
                          }
                        }
                      }
                    } else {
                      result[0] += 0.001071253968331052;
                    }
                  } else {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7422817934170855558) ) ) {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)72.50000000000001421) ) ) {
                        result[0] += -1.351785642909406e-05;
                      } else {
                        result[0] += -0.0012047912158643496;
                      }
                    } else {
                      result[0] += 4.407931890410702e-05;
                    }
                  }
                }
              }
            }
          } else {
            result[0] += -0.000855223767986745;
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 2.698977827715159e-05;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4589535259190716254) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
                result[0] += -5.238338802389226e-05;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1177750000000000186) ) ) {
                  result[0] += 3.063390507681117e-05;
                } else {
                  result[0] += 3.1118235008564925e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4086612272110553001) ) ) {
                result[0] += -0.00016336842547525352;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)189.5000000000000284) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)137.5000000000000284) ) ) {
                    result[0] += 3.495138012233663e-05;
                  } else {
                    result[0] += -6.325638788343837e-05;
                  }
                } else {
                  result[0] += 3.6192789632638785e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)48.50000000000000711) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3801755927260667134) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1207797749301366269) ) ) {
                  result[0] += 3.340813618502883e-05;
                } else {
                  result[0] += 1.3779645633914213e-07;
                }
              } else {
                result[0] += 2.6227485358352093e-05;
              }
            } else {
              result[0] += 3.094189074082441e-05;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -2.780326731565189e-07;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -3.342568039561022e-07;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.4754083820894484e-07;
            } else {
              result[0] += -3.4754083820894484e-07;
            }
          }
        } else {
          result[0] += 8.85619451017167e-07;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -3.4754083820894484e-07;
                } else {
                  result[0] += -3.4754083820894484e-07;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -3.4754083820894484e-07;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -3.4754083820894484e-07;
                    } else {
                      result[0] += -3.4754083820894484e-07;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -3.4754083820894484e-07;
                    } else {
                      result[0] += -3.4754083820894484e-07;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -3.4754083820894484e-07;
              } else {
                result[0] += -3.4754083820894484e-07;
              }
            }
          } else {
            result[0] += -4.057672767242083e-07;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -3.4754083820894484e-07;
              } else {
                result[0] += -3.4754083820894484e-07;
              }
            } else {
              result[0] += -3.4754083820894484e-07;
            }
          } else {
            result[0] += -3.4754083820894484e-07;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03472639088202265217) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6690536170100503943) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6650804020351760437) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5423446055643508235) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4868404241646586694) ) ) {
                  result[0] += -1.0835370820794773e-05;
                } else {
                  result[0] += 0.0003982793451332473;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.29500000000000004) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)24.50000000000000355) ) ) {
                    result[0] += 0.0003688831421534307;
                  } else {
                    result[0] += -0.00018231168937257725;
                  }
                } else {
                  result[0] += -0.0018611809911080507;
                }
              }
            } else {
              result[0] += -0.0005718078175046243;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6800105846231156992) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)181.5000000000000284) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5380790363330137938) ) ) {
                  result[0] += 0.0006168140036591522;
                } else {
                  result[0] += -0.00023445274435140336;
                }
              } else {
                result[0] += 0.0018032910967126687;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4868404241646586694) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1950000000000000344) ) ) {
                  result[0] += -0.0002733022045293033;
                } else {
                  result[0] += 0.0006985873992398672;
                }
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)9.500000000000001776) ) ) {
                  result[0] += 0.0001804353890298752;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01413850000000000176) ) ) {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6884145867587940781) ) ) {
                      result[0] += -0.0005539629171405775;
                    } else {
                      result[0] += 2.8131839246560145e-05;
                    }
                  } else {
                    result[0] += -9.097970628056764e-05;
                  }
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.895681724436047322) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
              result[0] += -0.0005546578092728958;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3687216492462311868) ) ) {
                result[0] += 0.000772787728442745;
              } else {
                result[0] += 6.691613502500978e-05;
              }
            }
          } else {
            result[0] += -0.0008189269643154391;
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 2.5844297152877332e-05;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4323286620486300191) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
                result[0] += -5.0160169233775466e-05;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1269590000000000163) ) ) {
                  result[0] += 2.933376249438818e-05;
                } else {
                  result[0] += 3.445790227903754e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4086612272110553001) ) ) {
                result[0] += -0.0007493277773639845;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)189.5000000000000284) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)157.5000000000000284) ) ) {
                    result[0] += 3.200684373753318e-05;
                  } else {
                    result[0] += -0.00017496304367615797;
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)346.5000000000000568) ) ) {
                    result[0] += 4.241893541077915e-05;
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)488.5000000000000568) ) ) {
                      result[0] += -0.00014140469055315055;
                    } else {
                      result[0] += 5.628835264729372e-05;
                    }
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)48.50000000000000711) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3801755927260667134) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1207797749301366269) ) ) {
                  result[0] += 3.1990251643552056e-05;
                } else {
                  result[0] += 1.3194819637468074e-07;
                }
              } else {
                result[0] += 2.511435693222891e-05;
              }
            } else {
              result[0] += 2.962867684818154e-05;
            }
          }
        }
      }
    }
  }
}

