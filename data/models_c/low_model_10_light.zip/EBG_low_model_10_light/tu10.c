
#include "header.h"

void predict_unit10(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -6.044380485905104e-06;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -7.2666830130995725e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -7.555475537015531e-06;
            } else {
              result[0] += -7.555475537015531e-06;
            }
          }
        } else {
          result[0] += -8.805281580828766e-06;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -7.555475537015531e-06;
                } else {
                  result[0] += -7.555475537015531e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -7.555475537015531e-06;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -7.555475537015531e-06;
                    } else {
                      result[0] += -7.555475537015531e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -7.555475537015531e-06;
                    } else {
                      result[0] += -7.555475537015531e-06;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -7.555475537015531e-06;
              } else {
                result[0] += -7.555475537015531e-06;
              }
            }
          } else {
            result[0] += -8.82130787510088e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -7.555475537015531e-06;
              } else {
                result[0] += -7.555475537015531e-06;
              }
            } else {
              result[0] += -7.555475537015531e-06;
            }
          } else {
            result[0] += -7.555475537015531e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6950000000000000622) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3329403679585331566) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.858234205283420677e-05) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)84.50000000000001421) ) ) {
                  result[0] += 0.0003073677406889303;
                } else {
                  result[0] += -0.0009029390808285065;
                }
              } else {
                result[0] += 0.00042740757324018;
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4296173751758793902) ) ) {
                result[0] += -0.0003730355465567606;
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4643511832914573034) ) ) {
                  result[0] += 0.0006492549369113005;
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2450759342279490716) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.00933301618409165118) ) ) {
                      result[0] += -8.652885645178594e-05;
                    } else {
                      result[0] += -0.0016159919916385662;
                    }
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)810.5000000000001137) ) ) {
                      result[0] += -8.588163537861097e-06;
                    } else {
                      result[0] += 0.00019880535413233726;
                    }
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)121.5000000000000142) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.966590843157139501) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9150000000000001465) ) ) {
                  result[0] += 0.0012921617510779039;
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3498337084924623697) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)25.50000000000000355) ) ) {
                      result[0] += -0.0020454586208457325;
                    } else {
                      result[0] += 0.00018259810256136;
                    }
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008973500000000000573) ) ) {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03869870194826590531) ) ) {
                        result[0] += 0.00030715497955160494;
                      } else {
                        result[0] += 0.0006895983145198671;
                      }
                    } else {
                      result[0] += -9.872384797658742e-05;
                    }
                  }
                }
              } else {
                result[0] += -0.000924740999640111;
              }
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.07409325127878772788) ) ) {
                result[0] += 0.0009973224057191366;
              } else {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.07196201389915944657) ) ) {
                  result[0] += -0.0023512350942339407;
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01778816268138619719) ) ) {
                    result[0] += 0.0012789955959294603;
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)141.5000000000000284) ) ) {
                      result[0] += 0.001051691155036634;
                    } else {
                      result[0] += 0.00025416991904514863;
                    }
                  }
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)27.50000000000000355) ) ) {
            result[0] += 0.00037118871067273995;
          } else {
            result[0] += 0.0013662014107791126;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
            result[0] += 0.0005618503883347607;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01013582417766895234) ) ) {
              result[0] += -0.00044594358461802784;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01112050000000000191) ) ) {
                result[0] += 0.0005744656261325356;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)119.5000000000000142) ) ) {
                  result[0] += 0.00022379839418561412;
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2321635079408217728) ) ) {
                    result[0] += 0.0006002535661016767;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07184972061993401271) ) ) {
                      result[0] += 0.00031734067459483815;
                    } else {
                      result[0] += 0.0005062913654557912;
                    }
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
              result[0] += -4.385078312061218e-06;
            } else {
              result[0] += 0.0005791070583639399;
            }
          } else {
            result[0] += 0.0005744639098796736;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -5.787849154546022e-06;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -6.958275580400419e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -7.234811375803097e-06;
            } else {
              result[0] += -7.234811375803097e-06;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6285027855690678011) ) ) {
            result[0] += 1.3200184677103881e-05;
          } else {
            result[0] += -5.8897561247333644e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -7.234811375803097e-06;
                } else {
                  result[0] += -7.234811375803097e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -7.234811375803097e-06;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -7.234811375803097e-06;
                    } else {
                      result[0] += -7.234811375803097e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -7.234811375803097e-06;
                    } else {
                      result[0] += -7.234811375803097e-06;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -7.234811375803097e-06;
              } else {
                result[0] += -7.234811375803097e-06;
              }
            }
          } else {
            result[0] += -8.446920151031385e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -7.234811375803097e-06;
              } else {
                result[0] += -7.234811375803097e-06;
              }
            } else {
              result[0] += -7.234811375803097e-06;
            }
          } else {
            result[0] += -7.234811375803097e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6950000000000000622) ) ) {
            result[0] += 2.5214332811778537e-06;
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)121.5000000000000142) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9150000000000001465) ) ) {
                result[0] += 0.001206448526562643;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9808239647505231362) ) ) {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3837516359296482826) ) ) {
                    if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.9546544174008676498) ) ) {
                      result[0] += 0.0006549000919748034;
                    } else {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01118954037485280113) ) ) {
                        result[0] += -0.0021545657702257354;
                      } else {
                        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)31.50000000000000355) ) ) {
                          result[0] += -0.0013442597826106;
                        } else {
                          result[0] += 0.000901383547037813;
                        }
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)108.5000000000000142) ) ) {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03188050000000000606) ) ) {
                          result[0] += -0.0002718233223736116;
                        } else {
                          result[0] += 0.0010741603866435267;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01439950000000000084) ) ) {
                          result[0] += 0.0006105343025333778;
                        } else {
                          result[0] += -0.00016402417965910538;
                        }
                      }
                    } else {
                      result[0] += -0.0004286198232714806;
                    }
                  }
                } else {
                  result[0] += -0.0009463214115750535;
                }
              }
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2185860198827210554) ) ) {
                result[0] += 0.0011418266571588528;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05530450000000000643) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03739601681999780991) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)141.5000000000000284) ) ) {
                      result[0] += 0.0010753115372650027;
                    } else {
                      result[0] += 0.0002123089417850555;
                    }
                  } else {
                    result[0] += 0.0007298408145049697;
                  }
                } else {
                  result[0] += -0.0002673615296739607;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)27.50000000000000355) ) ) {
            result[0] += 0.00040044642598955753;
          } else {
            result[0] += 0.001130004101239923;
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.9546544174008676498) ) ) {
          result[0] += 0.0005380047306233971;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2162432673096428282) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)14.50000000000000178) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5272802516080402624) ) ) {
                if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3329403679585331566) ) ) {
                  result[0] += 2.3356439923974102e-05;
                } else {
                  result[0] += -0.001195609420111631;
                }
              } else {
                result[0] += 0.00038784708690540163;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0416553728637082607) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
                  result[0] += 0.0006775950312831615;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)155.5000000000000284) ) ) {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4731110269597990081) ) ) {
                      result[0] += -0.0005684942471214293;
                    } else {
                      result[0] += 0.00033927887970095844;
                    }
                  } else {
                    result[0] += 0.0004487624942699353;
                  }
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)117.5000000000000142) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0104785000000000017) ) ) {
                    result[0] += 0.0005500845614005175;
                  } else {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6551236496733668924) ) ) {
                      result[0] += 0.0004505776593950009;
                    } else {
                      result[0] += -0.00047411454828820453;
                    }
                  }
                } else {
                  result[0] += 0.0005500829179876459;
                }
              }
            }
          } else {
            result[0] += 0.0005501233562657068;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -5.5422053449308926e-06;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -6.66295735833184e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -6.927756616643826e-06;
            } else {
              result[0] += -6.927756616643826e-06;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6285027855690678011) ) ) {
            result[0] += 1.2639951753762997e-05;
          } else {
            result[0] += -5.639787251400285e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -6.927756616643826e-06;
                } else {
                  result[0] += -6.927756616643826e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -6.927756616643826e-06;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -6.927756616643826e-06;
                    } else {
                      result[0] += -6.927756616643826e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -6.927756616643826e-06;
                    } else {
                      result[0] += -6.927756616643826e-06;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -6.927756616643826e-06;
              } else {
                result[0] += -6.927756616643826e-06;
              }
            }
          } else {
            result[0] += -8.08842192655972e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -6.927756616643826e-06;
              } else {
                result[0] += -6.927756616643826e-06;
              }
            } else {
              result[0] += -6.927756616643826e-06;
            }
          } else {
            result[0] += -6.927756616643826e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6950000000000000622) ) ) {
            result[0] += 2.4144203891105127e-06;
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)87.50000000000001421) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.966590843157139501) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3837516359296482826) ) ) {
                  result[0] += -0.0008040159235553244;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9150000000000001465) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02844215559246820318) ) ) {
                      result[0] += 0.0001013994618584231;
                    } else {
                      result[0] += 0.0037080527465568236;
                    }
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008973500000000000573) ) ) {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
                        result[0] += -0.00030331510679301873;
                      } else {
                        result[0] += 0.0006907063757930376;
                      }
                    } else {
                      result[0] += -0.00012796751160902803;
                    }
                  }
                }
              } else {
                result[0] += -0.0010734895552035998;
              }
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.80526473097989959) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8412950649051146312) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03472639088202265217) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05530450000000000643) ) ) {
                      result[0] += 0.0004678415193896668;
                    } else {
                      result[0] += -0.0013885127716492189;
                    }
                  } else {
                    result[0] += 0.0008433637194757044;
                  }
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)213.5000000000000284) ) ) {
                    result[0] += 0.0008437667572554087;
                  } else {
                    result[0] += -0.0014960961712456693;
                  }
                }
              } else {
                result[0] += 0.0025232680382610007;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)27.50000000000000355) ) ) {
            result[0] += 0.0003384395167076953;
          } else {
            result[0] += 0.0012602592178881523;
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0005151711134899066;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01112050000000000191) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01035297934913455113) ) ) {
                result[0] += -4.149086237928989e-06;
              } else {
                result[0] += 0.0005267383303618991;
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)119.5000000000000142) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3830383354773237436) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5451673325125628855) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06116598190050365896) ) ) {
                      result[0] += -4.5912401810584795e-05;
                    } else {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)59.50000000000000711) ) ) {
                        result[0] += 0.00015929588714060306;
                      } else {
                        result[0] += 0.0005281524591863409;
                      }
                    }
                  } else {
                    result[0] += 0.00056997871340015;
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)62.50000000000000711) ) ) {
                    result[0] += 0.00015971272656674614;
                  } else {
                    result[0] += -0.0018637076189398668;
                  }
                }
              } else {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2321635079408217728) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03358130704046471265) ) ) {
                    result[0] += 0.0004922647674772142;
                  } else {
                    result[0] += 0.0005530139836631054;
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07184972061993401271) ) ) {
                    result[0] += 0.00024128516192165655;
                  } else {
                    result[0] += 0.00048227353530583993;
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
                result[0] += -4.032316246706308e-05;
              } else {
                result[0] += 0.000531181057948906;
              }
            } else {
              result[0] += 0.0005267366869490275;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -5.306986976544594e-06;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -6.38017282385267e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -6.633733658899265e-06;
            } else {
              result[0] += -6.633733658899265e-06;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6285027855690678011) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.07196201389915944657) ) ) {
              result[0] += -5.8403366550792726e-05;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5458973873869347182) ) ) {
                result[0] += 0.0009667116233325598;
              } else {
                result[0] += 1.1074778244362064e-05;
              }
            }
          } else {
            result[0] += -5.400427380598398e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -6.633733658899265e-06;
                } else {
                  result[0] += -6.633733658899265e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -6.633733658899265e-06;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -6.633733658899265e-06;
                    } else {
                      result[0] += -6.633733658899265e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -6.633733658899265e-06;
                    } else {
                      result[0] += -6.633733658899265e-06;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -6.633733658899265e-06;
              } else {
                result[0] += -6.633733658899265e-06;
              }
            }
          } else {
            result[0] += -7.745138830756464e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -6.633733658899265e-06;
              } else {
                result[0] += -6.633733658899265e-06;
              }
            } else {
              result[0] += -6.633733658899265e-06;
            }
          } else {
            result[0] += -6.633733658899265e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6950000000000000622) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3329403679585331566) ) ) {
              if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3932416254517326903) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4418673924623115479) ) ) {
                  result[0] += 0.00023701502642702247;
                } else {
                  result[0] += -0.0011700925743064476;
                }
              } else {
                result[0] += 0.0008797839834638748;
              }
            } else {
              result[0] += -5.369859682839411e-06;
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)121.5000000000000142) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9150000000000001465) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01008250000000000292) ) ) {
                  result[0] += 0.00015740413967503484;
                } else {
                  result[0] += 0.0027437641658441016;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9808239647505231362) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008973500000000000573) ) ) {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3837516359296482826) ) ) {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01118954037485280113) ) ) {
                        result[0] += -0.0015233796583994416;
                      } else {
                        result[0] += 0.00039585657527261566;
                      }
                    } else {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
                        result[0] += -0.00029044201322190726;
                      } else {
                        result[0] += 0.0005624317509314231;
                      }
                    }
                  } else {
                    result[0] += -0.00011848554755456091;
                  }
                } else {
                  result[0] += -0.0008477014191023602;
                }
              }
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.07409325127878772788) ) ) {
                result[0] += 0.0009086582309834651;
              } else {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.07196201389915944657) ) ) {
                  result[0] += -0.0022758919119990673;
                } else {
                  result[0] += 0.0005029774360984376;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)27.50000000000000355) ) ) {
            result[0] += 0.00032407570555980465;
          } else {
            result[0] += 0.0012067721854658374;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
            result[0] += 0.0004933065846222296;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01112050000000000191) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01035297934913455113) ) ) {
                result[0] += -3.972993647626663e-06;
              } else {
                result[0] += 0.0005043828738381594;
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)119.5000000000000142) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5423446055643508235) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6037488751507539275) ) ) {
                    result[0] += 0.0001705902184868498;
                  } else {
                    result[0] += 0.00043284229878493317;
                  }
                } else {
                  result[0] += -0.00047951294235382304;
                }
              } else {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2321635079408217728) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03358130704046471265) ) ) {
                    result[0] += 0.0004713724135831182;
                  } else {
                    result[0] += 0.0005295433544033969;
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07184972061993401271) ) ) {
                    result[0] += 0.00023104470734251517;
                  } else {
                    result[0] += 0.00046180522223723765;
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
              result[0] += 4.3730360683394165e-06;
            } else {
              result[0] += 0.0005086370463159329;
            }
          } else {
            result[0] += 0.0005043813001738564;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -5.081751580167282e-06;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -6.109390031038648e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -6.3521894160496764e-06;
            } else {
              result[0] += -6.3521894160496764e-06;
            }
          }
        } else {
          result[0] += -7.049548398960806e-06;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -6.3521894160496764e-06;
                } else {
                  result[0] += -6.3521894160496764e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -6.3521894160496764e-06;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -6.3521894160496764e-06;
                    } else {
                      result[0] += -6.3521894160496764e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -6.3521894160496764e-06;
                    } else {
                      result[0] += -6.3521894160496764e-06;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -6.3521894160496764e-06;
              } else {
                result[0] += -6.3521894160496764e-06;
              }
            }
          } else {
            result[0] += -7.416425113867212e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -6.3521894160496764e-06;
              } else {
                result[0] += -6.3521894160496764e-06;
              }
            } else {
              result[0] += -6.3521894160496764e-06;
            }
          } else {
            result[0] += -6.3521894160496764e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03472639088202265217) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2575587311557789305) ) ) {
                result[0] += 0.0018558766736586824;
              } else {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6690536170100503943) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6650804020351760437) ) ) {
                    result[0] += -8.142367134301135e-07;
                  } else {
                    result[0] += -0.0006633959800238832;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)3.217614006880118073e-05) ) ) {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6800105846231156992) ) ) {
                      result[0] += 0.0004929320167762986;
                    } else {
                      result[0] += -0.00012097510514625447;
                    }
                  } else {
                    result[0] += 0.00033666232097062995;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)171.5000000000000284) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
                  result[0] += -0.0014768764773149866;
                } else {
                  result[0] += 0.00032419315812022207;
                }
              } else {
                result[0] += 0.0011202654054536599;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7080301875628142172) ) ) {
              result[0] += -0.0005281144666186119;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8458243956458841861) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7342470301758795559) ) ) {
                  result[0] += 0.0001270352382993372;
                } else {
                  result[0] += -0.0003796169591929608;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7269841738944724518) ) ) {
                  result[0] += 0.0006415149477275782;
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.735388073517588059) ) ) {
                    result[0] += -0.0013071005400350072;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9194299814036738239) ) ) {
                      result[0] += 0.00024375668718036478;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.0144392355375913) ) ) {
                        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7712418641206031378) ) ) {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04125550000000000744) ) ) {
                            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.008982725145665402047) ) ) {
                              result[0] += -0.00015961553398027145;
                            } else {
                              result[0] += 0.0016139543353699693;
                            }
                          } else {
                            result[0] += -0.00047029454585098264;
                          }
                        } else {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01055863010420855265) ) ) {
                            result[0] += 3.214140101217033e-05;
                          } else {
                            result[0] += -0.0007067759925319777;
                          }
                        }
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.051391296366422923) ) ) {
                          result[0] += 0.0005211248970700709;
                        } else {
                          result[0] += -9.906250138370518e-07;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)27.50000000000000355) ) ) {
            result[0] += 0.0003103215131488113;
          } else {
            result[0] += 0.0011555552119304096;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
            result[0] += 0.0004723700146600249;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01344341525633075199) ) ) {
              result[0] += -1.7526869493792763e-05;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01112050000000000191) ) ) {
                result[0] += 0.00048297621182504793;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)119.5000000000000142) ) ) {
                  result[0] += 0.0001818449834706853;
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2321635079408217728) ) ) {
                    result[0] += 0.0005070688490286569;
                  } else {
                    result[0] += 0.000385206145183297;
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
              result[0] += 4.187438757363238e-06;
            } else {
              result[0] += 0.0004870498317164781;
            }
          } else {
            result[0] += 0.0004829747049490951;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -4.86607546554541e-06;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -5.850099610439065e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -6.082594275283107e-06;
            } else {
              result[0] += -6.082594275283107e-06;
            }
          }
        } else {
          result[0] += -6.750356440333677e-06;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -6.082594275283107e-06;
                } else {
                  result[0] += -6.082594275283107e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -6.082594275283107e-06;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -6.082594275283107e-06;
                    } else {
                      result[0] += -6.082594275283107e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -6.082594275283107e-06;
                    } else {
                      result[0] += -6.082594275283107e-06;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -6.082594275283107e-06;
              } else {
                result[0] += -6.082594275283107e-06;
              }
            }
          } else {
            result[0] += -7.101662432592948e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -6.082594275283107e-06;
              } else {
                result[0] += -6.082594275283107e-06;
              }
            } else {
              result[0] += -6.082594275283107e-06;
            }
          } else {
            result[0] += -6.082594275283107e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4450000000000000622) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)3.500000000000000444) ) ) {
              result[0] += 0.00024724174538642596;
            } else {
              result[0] += -1.0731981809768601e-05;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004677500000000000234) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.004923558837848901124) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4592177672613065309) ) ) {
                    result[0] += -0.0008687185642071985;
                  } else {
                    result[0] += 0.0016825076547650583;
                  }
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4638663492462312132) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001972498273255000271) ) ) {
                      result[0] += -0.00020531155128629628;
                    } else {
                      result[0] += 0.001068143641279645;
                    }
                  } else {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5046554252763820747) ) ) {
                      result[0] += -0.0010872811337670734;
                    } else {
                      result[0] += -0.0001641879824732159;
                    }
                  }
                }
              } else {
                result[0] += 0.00043376491303270397;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.966590843157139501) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)15.50000000000000178) ) ) {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4131576219849246168) ) ) {
                    result[0] += -0.001551178461320292;
                  } else {
                    result[0] += -7.60382133010745e-05;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01437243042433420173) ) ) {
                    result[0] += -0.00019035560544605767;
                  } else {
                    result[0] += 0.00044103210293726223;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8155157533417086713) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)100.5000000000000142) ) ) {
                    result[0] += -0.0028817694588061625;
                  } else {
                    result[0] += -0.0002786539643621041;
                  }
                } else {
                  result[0] += 0.000987932023896895;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)27.50000000000000355) ) ) {
            result[0] += 0.00029715106646646504;
          } else {
            result[0] += 0.001106511953044457;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
            result[0] += 0.0004523220198262407;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01344341525633075199) ) ) {
              result[0] += -1.6783006466593884e-05;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01112050000000000191) ) ) {
                result[0] += 0.0004624780762554625;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)119.5000000000000142) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3872449054220527542) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5451673325125628855) ) ) {
                      if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.02463433988323724885) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06116598190050365896) ) ) {
                          result[0] += -3.372610527536309e-05;
                        } else {
                          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)59.50000000000000711) ) ) {
                            result[0] += 0.0002865377709847588;
                          } else {
                            result[0] += 0.0005095987237500632;
                          }
                        }
                      } else {
                        result[0] += -0.000396748659866408;
                      }
                    } else {
                      result[0] += 0.0005192230007119722;
                    }
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)59.50000000000000711) ) ) {
                      result[0] += 0.00023299907232931486;
                    } else {
                      result[0] += -0.0016533255969167122;
                    }
                  }
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2321635079408217728) ) ) {
                    result[0] += 0.00048554819075187207;
                  } else {
                    result[0] += 0.0003688574977905636;
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
              result[0] += 4.009718436492063e-06;
            } else {
              result[0] += 0.00046637880644601575;
            }
          } else {
            result[0] += 0.0004624766333332757;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -4.659552924388174e-06;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -5.6018138109020005e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -5.824441101240846e-06;
            } else {
              result[0] += -5.824441101240846e-06;
            }
          }
        } else {
          result[0] += -6.463862575689444e-06;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -5.824441101240846e-06;
                } else {
                  result[0] += -5.824441101240846e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -5.824441101240846e-06;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -5.824441101240846e-06;
                    } else {
                      result[0] += -5.824441101240846e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -5.824441101240846e-06;
                    } else {
                      result[0] += -5.824441101240846e-06;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -5.824441101240846e-06;
              } else {
                result[0] += -5.824441101240846e-06;
              }
            }
          } else {
            result[0] += -6.800258686924739e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -5.824441101240846e-06;
              } else {
                result[0] += -5.824441101240846e-06;
              }
            } else {
              result[0] += -5.824441101240846e-06;
            }
          } else {
            result[0] += -5.824441101240846e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03536067803908965468) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2575587311557789305) ) ) {
            result[0] += 0.0017344698426350245;
          } else {
            result[0] += 3.5015937024818824e-06;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.213351496714494937) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)171.5000000000000284) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05403737693237045669) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001872500000000000249) ) ) {
                  result[0] += -0.0006300700943611347;
                } else {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6359282793467337935) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2323788471531250399) ) ) {
                      result[0] += 0.0001076170027291704;
                    } else {
                      result[0] += -0.001091836116935652;
                    }
                  } else {
                    result[0] += 0.0002911238320235808;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)3.500000000000000444) ) ) {
                  result[0] += -0.0011545550001584072;
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4589535259190716254) ) ) {
                    result[0] += 0.001186307960204118;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1856729582787713384) ) ) {
                      result[0] += 0.0003571074034415266;
                    } else {
                      result[0] += 0.0010870065235667964;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3450000000000000289) ) ) {
                result[0] += -0.00011397240408160617;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
                  result[0] += 0.001775747954540113;
                } else {
                  result[0] += 6.0171081568870274e-05;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8371684470603016903) ) ) {
              result[0] += -0.0014047501886833096;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005491500000000000721) ) ) {
                result[0] += -0.000315937599584059;
              } else {
                result[0] += 0.0009502059780807875;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
            result[0] += 0.0004331248878423029;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01344341525633075199) ) ) {
              result[0] += -1.6070713949086608e-05;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01112050000000000191) ) ) {
                result[0] += 0.0004428499080911898;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)119.5000000000000142) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3872449054220527542) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5451673325125628855) ) ) {
                      if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.07218104077152019682) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04250871378122500488) ) ) {
                          result[0] += -0.00033479644355378235;
                        } else {
                          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)60.50000000000000711) ) ) {
                            result[0] += 0.00027437673886968;
                          } else {
                            result[0] += 0.0004826319801122688;
                          }
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
                          result[0] += 0.0003593816623381221;
                        } else {
                          result[0] += -0.0008219591371199099;
                        }
                      }
                    } else {
                      result[0] += 0.0004971865045060344;
                    }
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)59.50000000000000711) ) ) {
                      result[0] += 0.00022311029011756414;
                    } else {
                      result[0] += -0.0015831563186033913;
                    }
                  }
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2321635079408217728) ) ) {
                    result[0] += 0.0004649408970675936;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07184972061993401271) ) ) {
                      result[0] += 0.0003146060126460396;
                    } else {
                      result[0] += 0.0004102021738391393;
                    }
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
              result[0] += 3.8395407960721626e-06;
            } else {
              result[0] += 0.00044658508624354686;
            }
          } else {
            result[0] += 0.00044284852640848524;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -4.461795467189941e-06;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -5.3640655820657415e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -5.577244282045217e-06;
            } else {
              result[0] += -5.577244282045217e-06;
            }
          }
        } else {
          result[0] += -6.189527881483722e-06;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -5.577244282045217e-06;
                } else {
                  result[0] += -5.577244282045217e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -5.577244282045217e-06;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -5.577244282045217e-06;
                    } else {
                      result[0] += -5.577244282045217e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -5.577244282045217e-06;
                    } else {
                      result[0] += -5.577244282045217e-06;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -5.577244282045217e-06;
              } else {
                result[0] += -5.577244282045217e-06;
              }
            }
          } else {
            result[0] += -6.511646906344227e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -5.577244282045217e-06;
              } else {
                result[0] += -5.577244282045217e-06;
              }
            } else {
              result[0] += -5.577244282045217e-06;
            }
          } else {
            result[0] += -5.577244282045217e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
            result[0] += -0.0001130640069404461;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.752860906001682428) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3103687546836865763) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001972498273255000271) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)59.50000000000000711) ) ) {
                    if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.6002047193041207818) ) ) {
                      result[0] += -0.0002596944894207396;
                    } else {
                      result[0] += 0.0010961907484321144;
                    }
                  } else {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.435405567110552727) ) ) {
                      result[0] += -0.00022735378998753659;
                    } else {
                      result[0] += -0.0011420250189108682;
                    }
                  }
                } else {
                  if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3763018001168558224) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4465236086683417871) ) ) {
                      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)5.500000000000000888) ) ) {
                        result[0] += -0.0009502832223452567;
                      } else {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002917500000000000388) ) ) {
                          result[0] += 0.0007581449677557118;
                        } else {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.008982725145665402047) ) ) {
                            result[0] += -0.0009250286425392888;
                          } else {
                            result[0] += 0.0006429043088083554;
                          }
                        }
                      }
                    } else {
                      result[0] += -0.0012665739992298408;
                    }
                  } else {
                    if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3750409390474713223) ) ) {
                      result[0] += 0.002781259791760886;
                    } else {
                      result[0] += 0.0006849231115542852;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4274156973366834422) ) ) {
                  result[0] += -0.0003665262342103517;
                } else {
                  result[0] += 2.2341804762608707e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)3.217614006880118073e-05) ) ) {
                result[0] += 0.0001025065780810709;
              } else {
                result[0] += -0.00037996651024485204;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)27.50000000000000355) ) ) {
            result[0] += 0.00027406813095985514;
          } else {
            result[0] += 0.0010180609801018565;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
            result[0] += 0.0004147425069875507;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01344341525633075199) ) ) {
              result[0] += -1.538865204797809e-05;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01112050000000000191) ) ) {
                result[0] += 0.0004240547847895061;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)119.5000000000000142) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3872449054220527542) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5451673325125628855) ) ) {
                      if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.02463433988323724885) ) ) {
                        result[0] += 0.00020713622977745568;
                      } else {
                        result[0] += -0.00037009396560255077;
                      }
                    } else {
                      result[0] += 0.00047608526572199037;
                    }
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)59.50000000000000711) ) ) {
                      result[0] += 0.00021364120062241466;
                    } else {
                      result[0] += -0.0015159651152852143;
                    }
                  }
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2321635079408217728) ) ) {
                    result[0] += 0.00044520820360030274;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07184972061993401271) ) ) {
                      result[0] += 0.0003012537262593955;
                    } else {
                      result[0] += 0.0003927926626366715;
                    }
                  }
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)40.50000000000000711) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3139010709447103697) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
                result[0] += 3.6765857149810955e-06;
              } else {
                result[0] += 0.00043971763595082716;
              }
            } else {
              result[0] += 0.00040954647934310134;
            }
          } else {
            result[0] += 0.00042667789927504054;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -4.272431092442342e-06;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -5.136407695790455e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -5.340538815815184e-06;
            } else {
              result[0] += -5.340538815815184e-06;
            }
          }
        } else {
          result[0] += -5.92683630678492e-06;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -5.340538815815184e-06;
                } else {
                  result[0] += -5.340538815815184e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -5.340538815815184e-06;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -5.340538815815184e-06;
                    } else {
                      result[0] += -5.340538815815184e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -5.340538815815184e-06;
                    } else {
                      result[0] += -5.340538815815184e-06;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -5.340538815815184e-06;
              } else {
                result[0] += -5.340538815815184e-06;
              }
            }
          } else {
            result[0] += -6.235284183295963e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -5.340538815815184e-06;
              } else {
                result[0] += -5.340538815815184e-06;
              }
            } else {
              result[0] += -5.340538815815184e-06;
            }
          } else {
            result[0] += -5.340538815815184e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6950000000000000622) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01265500000000000132) ) ) {
              result[0] += -1.597400870490333e-05;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4725302343969849939) ) ) {
                result[0] += 0.0011732955658216445;
              } else {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2118170036735003703) ) ) {
                  result[0] += -0.0009560177647057415;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01075889670750075112) ) ) {
                    result[0] += -0.0001827313675663764;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.247314011309283543) ) ) {
                      result[0] += 0.0002086294908806143;
                    } else {
                      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8371684470603016903) ) ) {
                        result[0] += -0.0015453278148627855;
                      } else {
                        result[0] += 9.95040189732109e-05;
                      }
                    }
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.231660934306704425) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)121.5000000000000142) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9150000000000001465) ) ) {
                  result[0] += 0.001113063588665462;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01504150000000000105) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.008408953333664601418) ) ) {
                      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.6002047193041207818) ) ) {
                        result[0] += -0.0014144061195277829;
                      } else {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
                          result[0] += -0.0005962185374671135;
                        } else {
                          result[0] += 0.00044860456776922754;
                        }
                      }
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
                        result[0] += 0.0002885768434187647;
                      } else {
                        result[0] += 0.0005511240282235428;
                      }
                    }
                  } else {
                    result[0] += -0.00026679077810190104;
                  }
                }
              } else {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2185860198827210554) ) ) {
                  result[0] += 0.0009946321418557523;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05274650000000000866) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03472639088202265217) ) ) {
                      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)141.5000000000000284) ) ) {
                        result[0] += 0.0009399668262496573;
                      } else {
                        result[0] += 0.0001656816381714298;
                      }
                    } else {
                      result[0] += 0.0006009586386992274;
                    }
                  } else {
                    result[0] += -0.00021699388089964616;
                  }
                }
              }
            } else {
              result[0] += -0.0008419696469636;
            }
          }
        } else {
          result[0] += 0.0006698750440378344;
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.9546544174008676498) ) ) {
          result[0] += 0.00039714029816948735;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1271566581126106488) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)155.5000000000000284) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00799650000000000187) ) ) {
                result[0] += 0.00044156365759008787;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04324794178047625809) ) ) {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4731110269597990081) ) ) {
                    result[0] += -0.0005090559535639475;
                  } else {
                    result[0] += 0.00034588996962364304;
                  }
                } else {
                  if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.07196201389915944657) ) ) {
                    result[0] += 0.0004393545101647616;
                  } else {
                    result[0] += 5.696287697585753e-05;
                  }
                }
              }
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2185860198827210554) ) ) {
                result[0] += 0.0004446649962812948;
              } else {
                result[0] += 0.00033744546223454157;
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)48.50000000000000711) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3801755927260667134) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1498495000000000243) ) ) {
                  result[0] += 0.00040853422440444197;
                } else {
                  result[0] += -0.00016374076403653757;
                }
              } else {
                result[0] += 0.00039216479666374254;
              }
            } else {
              result[0] += 0.000405983421457094;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -4.091103586862568e-06;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -4.9184119048774255e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -5.113879435951415e-06;
            } else {
              result[0] += -5.113879435951415e-06;
            }
          }
        } else {
          result[0] += -5.675293702530914e-06;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -5.113879435951415e-06;
                } else {
                  result[0] += -5.113879435951415e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -5.113879435951415e-06;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -5.113879435951415e-06;
                    } else {
                      result[0] += -5.113879435951415e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -5.113879435951415e-06;
                    } else {
                      result[0] += -5.113879435951415e-06;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -5.113879435951415e-06;
              } else {
                result[0] += -5.113879435951415e-06;
              }
            }
          } else {
            result[0] += -5.970650651923652e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -5.113879435951415e-06;
              } else {
                result[0] += -5.113879435951415e-06;
              }
            } else {
              result[0] += -5.113879435951415e-06;
            }
          } else {
            result[0] += -5.113879435951415e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8050000000000001599) ) ) {
            result[0] += 6.0080281485539154e-06;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01198850000000000089) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.005901718216089950862) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)43.50000000000000711) ) ) {
                  result[0] += -0.0010575547208747599;
                } else {
                  result[0] += 0.00015905467245408574;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001509500000000000208) ) ) {
                  result[0] += 0.0007775990526384975;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08495625534650631805) ) ) {
                    result[0] += 0.00036011706387312274;
                  } else {
                    result[0] += 0.000569855451792065;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04407393373669900999) ) ) {
                  result[0] += 0.00032107471726195244;
                } else {
                  result[0] += 0.0014229557913794956;
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)256.5000000000000568) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5423446055643508235) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6059238433417085679) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.07172822906307056712) ) ) {
                        if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.08689530881909278415) ) ) {
                          if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1828583041203602211) ) ) {
                            result[0] += 1.5555079295022276e-05;
                          } else {
                            result[0] += -0.0024537542451896605;
                          }
                        } else {
                          result[0] += 0.0005817548921458425;
                        }
                      } else {
                        result[0] += -0.0015874354979887185;
                      }
                    } else {
                      result[0] += 0.0007773048377302417;
                    }
                  } else {
                    result[0] += -0.001530665287842719;
                  }
                } else {
                  result[0] += 0.0008955909732655868;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)40.50000000000000711) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.156847194217679814) ) ) {
              result[0] += 0.0010078100569159297;
            } else {
              result[0] += -0.0001341248738191023;
            }
          } else {
            result[0] += 0.000836300562377044;
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.9546544174008676498) ) ) {
          result[0] += 0.000380285149877063;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2162432673096428282) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)14.50000000000000178) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5272802516080402624) ) ) {
                result[0] += -0.0006082564410676004;
              } else {
                result[0] += 0.0003533439032029199;
              }
            } else {
              if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.08110515786938453375) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)201.5000000000000284) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08780304645514057371) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01738250000000000559) ) ) {
                      result[0] += 0.0004281508182981591;
                    } else {
                      result[0] += -2.7699540699720393e-05;
                    }
                  } else {
                    result[0] += 0.00039424531135181194;
                  }
                } else {
                  result[0] += 0.00040744083319092745;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5085295226130653878) ) ) {
                  result[0] += -0.00025698555646835663;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9194299814036738239) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02278050000000000561) ) ) {
                      result[0] += 0.0003887142375410565;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1245513101099625097) ) ) {
                        result[0] += 0.00041080754463701963;
                      } else {
                        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6067453057537689487) ) ) {
                          result[0] += -0.0003885766583196792;
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5423446055643508235) ) ) {
                            result[0] += 0.00041080754463701963;
                          } else {
                            result[0] += 1.4165233340760546e-05;
                          }
                        }
                      }
                    }
                  } else {
                    result[0] += -0.0005320625041944523;
                  }
                }
              }
            }
          } else {
            result[0] += 0.0003887529595662553;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -3.917471855320671e-06;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -4.70966813749336e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -4.896839773545384e-06;
            } else {
              result[0] += -4.896839773545384e-06;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6285027855690678011) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.07196201389915944657) ) ) {
              result[0] += -5.430953057306794e-05;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.568345700351758909) ) ) {
                result[0] += 0.0005342139108648366;
              } else {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.640890220251256415) ) ) {
                  result[0] += -2.1223160138469312e-05;
                } else {
                  result[0] += 0.00012179494520903961;
                }
              }
            }
          } else {
            result[0] += -5.009714101830974e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -4.896839773545384e-06;
                } else {
                  result[0] += -4.896839773545384e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -4.896839773545384e-06;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -4.896839773545384e-06;
                    } else {
                      result[0] += -4.896839773545384e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -4.896839773545384e-06;
                    } else {
                      result[0] += -4.896839773545384e-06;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -4.896839773545384e-06;
              } else {
                result[0] += -4.896839773545384e-06;
              }
            }
          } else {
            result[0] += -5.717248510150862e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -4.896839773545384e-06;
              } else {
                result[0] += -4.896839773545384e-06;
              }
            } else {
              result[0] += -4.896839773545384e-06;
            }
          } else {
            result[0] += -4.896839773545384e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03472639088202265217) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2575587311557789305) ) ) {
            result[0] += 0.0016215391643314607;
          } else {
            result[0] += 2.772899165269055e-06;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.194581012612933923) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)171.5000000000000284) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
                result[0] += -0.00121878398496162;
              } else {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4589535259190716254) ) ) {
                  result[0] += 0.0010701630805097708;
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3763018001168558224) ) ) {
                    result[0] += -0.000775613901188953;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1165587384072143268) ) ) {
                      result[0] += 0.0005425054108855044;
                    } else {
                      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6059238433417085679) ) ) {
                        result[0] += -0.0005732334517132271;
                      } else {
                        result[0] += 0.00017410114838277007;
                      }
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5811189422864322385) ) ) {
                result[0] += 0.0011662466578147078;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.774278571389027559) ) ) {
                    result[0] += 0.000609929955549187;
                  } else {
                    result[0] += -0.0003957072525259249;
                  }
                } else {
                  result[0] += 0.0012621765691284586;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8257879984924624273) ) ) {
              result[0] += -0.001851091219098535;
            } else {
              result[0] += -2.7377207331018794e-05;
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0003641453558946116;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2162432673096428282) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06439350000000000629) ) ) {
                result[0] += 0.00015099836421572933;
              } else {
                result[0] += -0.0009461164177279527;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5423446055643508235) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03296628516090911037) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06439350000000000629) ) ) {
                    result[0] += 0.00036552279371861174;
                  } else {
                    result[0] += -0.0010904894805993796;
                  }
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01775050000000000239) ) ) {
                    result[0] += 0.00037221670216796605;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1466079245622486649) ) ) {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)119.5000000000000142) ) ) {
                        result[0] += 0.0001560061786835533;
                      } else {
                        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2321635079408217728) ) ) {
                          result[0] += 0.00039633825065580616;
                        } else {
                          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05035649857444463723) ) ) {
                            result[0] += 2.258425328379089e-05;
                          } else {
                            result[0] += 0.00041035552366541946;
                          }
                        }
                      }
                    } else {
                      result[0] += 0.0003802772479416319;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6731103726130654996) ) ) {
                  result[0] += -0.0008037139302297594;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9911809338528255742) ) ) {
                    result[0] += 0.0003851719881989584;
                  } else {
                    result[0] += -0.0006852569625139057;
                  }
                }
              }
            }
          } else {
            result[0] += 0.00037225378078029335;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -3.7512092792054255e-06;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -4.50978372578434e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -4.689011555336914e-06;
            } else {
              result[0] += -4.689011555336914e-06;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.07196201389915944657) ) ) {
              result[0] += -6.799974932793053e-05;
            } else {
              result[0] += -1.2834860787576127e-06;
            }
          } else {
            result[0] += 0.0005652594467635048;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -4.689011555336914e-06;
                } else {
                  result[0] += -4.689011555336914e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -4.689011555336914e-06;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -4.689011555336914e-06;
                    } else {
                      result[0] += -4.689011555336914e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -4.689011555336914e-06;
                    } else {
                      result[0] += -4.689011555336914e-06;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -4.689011555336914e-06;
              } else {
                result[0] += -4.689011555336914e-06;
              }
            }
          } else {
            result[0] += -5.474601083265719e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -4.689011555336914e-06;
              } else {
                result[0] += -4.689011555336914e-06;
              }
            } else {
              result[0] += -4.689011555336914e-06;
            }
          } else {
            result[0] += -4.689011555336914e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06413776133552721859) ) ) {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3103687546836865763) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001972498273255000271) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001795500000000000221) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)59.50000000000000711) ) ) {
                  result[0] += 0.00010638817077169684;
                } else {
                  result[0] += -0.0005940736310293599;
                }
              } else {
                result[0] += 0.0018692861075591048;
              }
            } else {
              if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3932416254517326903) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4418673924623115479) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)6.500000000000000888) ) ) {
                    result[0] += -0.0003697189737839029;
                  } else {
                    result[0] += 0.00044978835457891583;
                  }
                } else {
                  result[0] += -0.0011480998510012823;
                }
              } else {
                result[0] += 0.0009085242830535877;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4274156973366834422) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.006369601946274350453) ) ) {
                result[0] += -0.0001088297051190572;
              } else {
                result[0] += -0.0007962472225361087;
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)735.5000000000001137) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06116598190050365896) ) ) {
                  result[0] += -2.2991535264350582e-07;
                } else {
                  result[0] += -0.0008895287949094511;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
                  result[0] += -0.00013890100785733908;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01271386927770580197) ) ) {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2650000000000000688) ) ) {
                      result[0] += 0.0008705388492992922;
                    } else {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.004134701972639751033) ) ) {
                        result[0] += 0.00033873923533733654;
                      } else {
                        result[0] += -0.0011764169510312126;
                      }
                    }
                  } else {
                    result[0] += 0.0015369242506600824;
                  }
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.213351496714494937) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)10.50000000000000178) ) ) {
              result[0] += -0.00032275324265441707;
            } else {
              result[0] += 0.000676107246102967;
            }
          } else {
            result[0] += -0.0005118156631283966;
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0003486905556593029;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2162432673096428282) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06439350000000000629) ) ) {
                result[0] += 0.0001445897981938464;
              } else {
                result[0] += -0.0009059620123548302;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9993516786272610419) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03358130704046471265) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02687100000000000252) ) ) {
                    result[0] += 0.00035340873730361436;
                  } else {
                    result[0] += -0.00012536037019804817;
                  }
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01775050000000000239) ) ) {
                    result[0] += 0.00035641933657492236;
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)117.5000000000000142) ) ) {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.103377615329305908) ) ) {
                        result[0] += 8.280876252515784e-05;
                      } else {
                        result[0] += 0.0003661505435751022;
                      }
                    } else {
                      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2321635079408217728) ) ) {
                        result[0] += 0.00036469782435400876;
                      } else {
                        result[0] += 0.0003504660167369896;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.0007986554608524617;
              }
            }
          } else {
            result[0] += 0.0003564548484977028;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -3.592003102022346e-06;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -4.318382667228422e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -4.490003835711439e-06;
            } else {
              result[0] += -4.490003835711439e-06;
            }
          }
        } else {
          result[0] += -9.055737947339061e-06;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -4.490003835711439e-06;
                } else {
                  result[0] += -4.490003835711439e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -4.490003835711439e-06;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -4.490003835711439e-06;
                    } else {
                      result[0] += -4.490003835711439e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -4.490003835711439e-06;
                    } else {
                      result[0] += -4.490003835711439e-06;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -4.490003835711439e-06;
              } else {
                result[0] += -4.490003835711439e-06;
              }
            }
          } else {
            result[0] += -5.242251927248036e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -4.490003835711439e-06;
              } else {
                result[0] += -4.490003835711439e-06;
              }
            } else {
              result[0] += -4.490003835711439e-06;
            }
          } else {
            result[0] += -4.490003835711439e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2575587311557789305) ) ) {
            result[0] += 0.001339720474251279;
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)31.50000000000000355) ) ) {
                result[0] += -0.001538030191723846;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5650000000000000577) ) ) {
                  result[0] += -0.0007924474334556791;
                } else {
                  result[0] += 0.0005625173338766649;
                }
              }
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3539353041941689093) ) ) {
                if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3763018001168558224) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4465236086683417871) ) ) {
                    if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3998230401234152409) ) ) {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0129473293797221032) ) ) {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005984500000000001103) ) ) {
                          result[0] += 0.0002546019213181205;
                        } else {
                          result[0] += -0.0012461937521910283;
                        }
                      } else {
                        result[0] += 0.0009744895731543234;
                      }
                    } else {
                      result[0] += -0.0008574605144584214;
                    }
                  } else {
                    result[0] += -0.001327531570866125;
                  }
                } else {
                  result[0] += 0.0011143570229283108;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4296173751758793902) ) ) {
                  result[0] += -0.000312567367105297;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08500000000000000611) ) ) {
                    result[0] += -1.9986393549004056e-05;
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
                        result[0] += -0.00017404936280961643;
                      } else {
                        result[0] += 0.000416563084661809;
                      }
                    } else {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.004923558837848901124) ) ) {
                        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4643511832914573034) ) ) {
                          result[0] += 0.0010819086562951484;
                        } else {
                          result[0] += -0.00027054101775385927;
                        }
                      } else {
                        result[0] += 7.542553791961131e-05;
                      }
                    }
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += 0.002228495046871791;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2397171522356433271) ) ) {
              result[0] += 0.0006169199169049099;
            } else {
              result[0] += -0.0003097166520536591;
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0003338916771498814;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2162432673096428282) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01344341525633075199) ) ) {
              result[0] += -7.091280810892005e-05;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01112050000000000191) ) ) {
                result[0] += 0.00034129238280086076;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)105.5000000000000142) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.714286561348693172) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1167934537543566104) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01775050000000000239) ) ) {
                        result[0] += 0.0004338689325208693;
                      } else {
                        result[0] += 1.5411660683523788e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.144071500000000019) ) ) {
                        result[0] += 0.00035338105332731657;
                      } else {
                        result[0] += -1.2419692505029484e-05;
                      }
                    }
                  } else {
                    result[0] += -0.0009573470229428451;
                  }
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2450759342279490716) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03739601681999780991) ) ) {
                      result[0] += 0.00044008159337892904;
                    } else {
                      result[0] += 0.0003492195766421951;
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07184972061993401271) ) ) {
                      result[0] += 0.00015596642153028833;
                    } else {
                      result[0] += 0.0003411515982337342;
                    }
                  }
                }
              }
            }
          } else {
            result[0] += 0.0003413264433505186;
          }
        }
      }
    }
  }
}

