
#include "header.h"

void predict_unit2(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.0005497297704138615;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6249533869346735049) ) ) {
                result[0] += -0.0006871622066176297;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4840806222471906728) ) ) {
                  result[0] += -0.0006871622066176297;
                } else {
                  result[0] += -0.0006871622066176297;
                }
              }
            } else {
              result[0] += -0.0005290252065743783;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6152470170603016042) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.005393752740946750925) ) ) {
                result[0] += -0.0005558211050167304;
              } else {
                result[0] += -0.0002807514385940656;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)52.50000000000000711) ) ) {
                result[0] += -0.0007004153338015288;
              } else {
                result[0] += -0.0006917538090963827;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.85801459308964273e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9993516786272610419) ) ) {
                  result[0] += -0.0006871622066176297;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.256922594654586334) ) ) {
                    result[0] += -0.0006871622066176297;
                  } else {
                    result[0] += -0.0006871622066176297;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.002492780962593150584) ) ) {
                    result[0] += -0.0006871622066176297;
                  } else {
                    result[0] += -0.0006871622066176297;
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)114.5000000000000142) ) ) {
                    result[0] += -0.0006871622066176297;
                  } else {
                    result[0] += -0.0006871622066176297;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)86.50000000000001421) ) ) {
                    result[0] += -0.0006871622066176297;
                  } else {
                    result[0] += -0.0006871622066176297;
                  }
                } else {
                  result[0] += -0.0006871622066176297;
                }
              } else {
                result[0] += -0.0006871622066176297;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.247314011309283543) ) ) {
              result[0] += -0.0005009829113924183;
            } else {
              result[0] += -0.0007049354427514831;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0003825000000000000817) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7392963230402010977) ) ) {
              result[0] += -0.0005524478395215165;
            } else {
              result[0] += -0.0007083737560990327;
            }
          } else {
            result[0] += -0.0004066722683528671;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9567162861906464144) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5494686760804020631) ) ) {
                result[0] += 0.0005462365028915386;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01184520638735680163) ) ) {
                  result[0] += -0.0005892876732546501;
                } else {
                  result[0] += 2.5501721879887443e-06;
                }
              }
            } else {
              result[0] += 0.0017789904121649671;
            }
          } else {
            result[0] += -0.0005555714653765793;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2350000000000000144) ) ) {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05500000000000000722) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
            result[0] += -0.0003141148928078333;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.168079446220334772) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
                result[0] += -0.0005921118755453684;
              } else {
                result[0] += -0.0005296167306403472;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)88.50000000000001421) ) ) {
                result[0] += -0.0005424097048158566;
              } else {
                result[0] += -0.00016297000079916867;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)331.5000000000000568) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7496778360301509236) ) ) {
                result[0] += -0.00033579163238015524;
              } else {
                result[0] += -0.0004574620266566621;
              }
            } else {
              result[0] += 0.00016765670431596535;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.04500000000000000527) ) ) {
              result[0] += -3.800158240706959e-05;
            } else {
              result[0] += 0.0012596176399407098;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5705607401507538645) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.360629054696599941e-06) ) ) {
            result[0] += 0.00028986702312496355;
          } else {
            result[0] += 0.0015328285043300258;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02085144663384500344) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.03500000000000001027) ) ) {
              result[0] += -8.277869927824943e-05;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)43.50000000000000711) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8009873338190955927) ) ) {
                  result[0] += 0.0001445116039822006;
                } else {
                  result[0] += -0.0006825773390636458;
                }
              } else {
                result[0] += 0.000510056332485098;
              }
            }
          } else {
            result[0] += 0.0012215146250532866;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7650000000000001243) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.004923558837848901124) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2750000000000000777) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.130629626450776108e-06) ) ) {
              result[0] += -0.0004856967735036641;
            } else {
              result[0] += 0.0017731626086379935;
            }
          } else {
            result[0] += 0.0027811475273566604;
          }
        } else {
          result[0] += 0.0036803230499419535;
        }
      } else {
        result[0] += 0.011774351430294637;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.0005263985274153704;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6249533869346735049) ) ) {
                result[0] += -0.0006579981531411273;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4840806222471906728) ) ) {
                  result[0] += -0.0006579981531411273;
                } else {
                  result[0] += -0.0006579981531411273;
                }
              }
            } else {
              result[0] += -0.0005065726920641643;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6152470170603016042) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.005393752740946750925) ) ) {
                result[0] += -0.0005322313378933812;
              } else {
                result[0] += -0.00026883598414981604;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)52.50000000000000711) ) ) {
                result[0] += -0.000670688800453171;
              } else {
                result[0] += -0.0006623948820675461;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.85801459308964273e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9993516786272610419) ) ) {
                  result[0] += -0.0006579981531411273;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.256922594654586334) ) ) {
                    result[0] += -0.0006579981531411273;
                  } else {
                    result[0] += -0.0006579981531411273;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.002492780962593150584) ) ) {
                    result[0] += -0.0006579981531411273;
                  } else {
                    result[0] += -0.0006579981531411273;
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)114.5000000000000142) ) ) {
                    result[0] += -0.0006579981531411273;
                  } else {
                    result[0] += -0.0006579981531411273;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)86.50000000000001421) ) ) {
                    result[0] += -0.0006579981531411273;
                  } else {
                    result[0] += -0.0006579981531411273;
                  }
                } else {
                  result[0] += -0.0006579981531411273;
                }
              } else {
                result[0] += -0.0006579981531411273;
              }
            }
          } else {
            result[0] += -0.00048560475810353545;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0003825000000000000817) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -0.0005290012381519668;
            } else {
              result[0] += -0.0006783094570073936;
            }
          } else {
            result[0] += -0.0003894125709081658;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9567162861906464144) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5064897371608040322) ) ) {
              result[0] += 0.001570735630338869;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
                result[0] += -0.000213840037562885;
              } else {
                result[0] += 0.0003377876123636148;
              }
            }
          } else {
            result[0] += -0.000531992293282679;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.25500000000000006) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.04500000000000000527) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04500000000000000527) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5745673188442211865) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.503000764270941431e-05) ) ) {
              result[0] += -0.0004149648326241039;
            } else {
              result[0] += 0.0002801659700994641;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
                result[0] += -0.0005640316819113461;
              } else {
                result[0] += -0.00036099656579805043;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02687100000000000252) ) ) {
                result[0] += -0.000371017936963078;
              } else {
                result[0] += 4.1344698850707375e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04770400000000000335) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.09500000000000001499) ) ) {
                result[0] += -8.709139119886643e-05;
              } else {
                result[0] += 0.00031398053025867757;
              }
            } else {
              result[0] += -0.00043349104417853137;
            }
          } else {
            result[0] += 0.001122100622839945;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004396500000000000234) ) ) {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05740595745564833902) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)3.928223887174962991e-06) ) ) {
              result[0] += 0.00020671333852909972;
            } else {
              result[0] += 0.0017321049196607568;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)43.50000000000000711) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7255694492462312351) ) ) {
                  result[0] += -0.00010878740838719563;
                } else {
                  result[0] += -0.0005867869476924939;
                }
              } else {
                result[0] += 0.0005320083321620968;
              }
            } else {
              result[0] += 0.0005078245096376355;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.213351496714494937) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01461911667849610276) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2542665105872564113) ) ) {
                result[0] += 0.0017140567121217483;
              } else {
                result[0] += 0.00037940345087312686;
              }
            } else {
              result[0] += 0.0025681081635290028;
            }
          } else {
            result[0] += 0.00015523614859925232;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5550000000000001599) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.004923558837848901124) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2750000000000000777) ) ) {
            result[0] += 0.0005619922281329228;
          } else {
            result[0] += 0.002673496789887114;
          }
        } else {
          result[0] += 0.003655037820166659;
        }
      } else {
        result[0] += 0.012544500128603453;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.000504057492568504;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6249533869346735049) ) ) {
                result[0] += -0.0006300718598426283;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4840806222471906728) ) ) {
                  result[0] += -0.0006300718598426283;
                } else {
                  result[0] += -0.0006300718598426283;
                }
              }
            } else {
              result[0] += -0.0004850730913311515;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6152470170603016042) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.06355808660527756393) ) ) {
                result[0] += -0.0005096427510201362;
              } else {
                result[0] += 9.238836093501623e-06;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)52.50000000000000711) ) ) {
                result[0] += -0.0006422238996566233;
              } else {
                result[0] += -0.0006342819859025086;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.85801459308964273e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9993516786272610419) ) ) {
                  result[0] += -0.0006300718598426283;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.256922594654586334) ) ) {
                    result[0] += -0.0006300718598426283;
                  } else {
                    result[0] += -0.0006300718598426283;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.002492780962593150584) ) ) {
                    result[0] += -0.0006300718598426283;
                  } else {
                    result[0] += -0.0006300718598426283;
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)114.5000000000000142) ) ) {
                    result[0] += -0.0006300718598426283;
                  } else {
                    result[0] += -0.0006300718598426283;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)86.50000000000001421) ) ) {
                    result[0] += -0.0006300718598426283;
                  } else {
                    result[0] += -0.0006300718598426283;
                  }
                } else {
                  result[0] += -0.0006300718598426283;
                }
              } else {
                result[0] += -0.0006300718598426283;
              }
            }
          } else {
            result[0] += -0.00046499506362763403;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0003825000000000000817) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -0.0005065497408926233;
            } else {
              result[0] += -0.0006495211256828962;
            }
          } else {
            result[0] += -0.00037288539736308806;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9567162861906464144) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5064897371608040322) ) ) {
              result[0] += 0.0015040715771073429;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01848850000000000146) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
                  result[0] += -0.0003797923650451391;
                } else {
                  result[0] += -2.116545939479788e-05;
                }
              } else {
                result[0] += 0.0004636239325336159;
              }
            }
          } else {
            result[0] += -0.0005094138517721193;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2750000000000000777) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.04500000000000000527) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04500000000000000527) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -0.0005245781906075286;
              } else {
                result[0] += -0.0005400934472772382;
              }
            } else {
              result[0] += -0.0003231222115630319;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05686650000000000732) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5745673188442211865) ) ) {
                result[0] += 1.3320074462050183e-05;
              } else {
                result[0] += -0.000348086836884366;
              }
            } else {
              result[0] += 0.0007956411617053526;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04770400000000000335) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
                result[0] += -2.9185359380606402e-05;
              } else {
                result[0] += 0.0011101917639830751;
              }
            } else {
              result[0] += -0.0004150931231749358;
            }
          } else {
            result[0] += 0.0010744772200169041;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006732000000000001004) ) ) {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05740595745564833902) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.360629054696599941e-06) ) ) {
              result[0] += 4.333580801185283e-06;
            } else {
              result[0] += 0.0016262416533164065;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1050000000000000239) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
                result[0] += 8.141488316053004e-05;
              } else {
                result[0] += -0.000516035036255332;
              }
            } else {
              result[0] += 0.0007232608733461235;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.247314011309283543) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01461911667849610276) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3084325690180824142) ) ) {
                result[0] += 0.0016883744408956731;
              } else {
                result[0] += 0.0004910317927195092;
              }
            } else {
              result[0] += 0.002733092729303943;
            }
          } else {
            result[0] += 9.931534410849046e-05;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5750000000000000666) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2750000000000000777) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0005935000000000001689) ) ) {
            result[0] += -0.0004411529532938693;
          } else {
            result[0] += 0.004744670625208335;
          }
        } else {
          result[0] += 0.003410659117449936;
        }
      } else {
        result[0] += 0.01251739934270123;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.00048266464015763263;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6249533869346735049) ) ) {
                result[0] += -0.0006033307945780847;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4840806222471906728) ) ) {
                  result[0] += -0.0006033307945780847;
                } else {
                  result[0] += -0.0006033307945780847;
                }
              }
            } else {
              result[0] += -0.0004644859614812324;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6152470170603016042) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.03659918966571634041) ) ) {
                  result[0] += -0.00048801285301130446;
                } else {
                  result[0] += -0.0003083136746407824;
                }
              } else {
                result[0] += -0.0006149670860933944;
              }
            } else {
              result[0] += -9.342471630138563e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.85801459308964273e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9993516786272610419) ) ) {
                  result[0] += -0.0006033307945780847;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.256922594654586334) ) ) {
                    result[0] += -0.0006033307945780847;
                  } else {
                    result[0] += -0.0006033307945780847;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.002492780962593150584) ) ) {
                    result[0] += -0.0006033307945780847;
                  } else {
                    result[0] += -0.0006033307945780847;
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)114.5000000000000142) ) ) {
                    result[0] += -0.0006033307945780847;
                  } else {
                    result[0] += -0.0006033307945780847;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)86.50000000000001421) ) ) {
                    result[0] += -0.0006033307945780847;
                  } else {
                    result[0] += -0.0006033307945780847;
                  }
                } else {
                  result[0] += -0.0006033307945780847;
                }
              } else {
                result[0] += -0.0006033307945780847;
              }
            }
          } else {
            result[0] += -0.0004452600712614254;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7403451809045227261) ) ) {
              result[0] += -0.0004850511142370375;
            } else {
              result[0] += -0.0006219546084019557;
            }
          } else {
            result[0] += -0.0003543097287608188;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9567162861906464144) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.03500000000000001027) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005067500000000000823) ) ) {
                result[0] += -0.0005284197852877911;
              } else {
                result[0] += 1.0584550463844615e-05;
              }
            } else {
              result[0] += 0.002781994287188719;
            }
          } else {
            result[0] += -0.00048779366854364897;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2750000000000000777) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
              result[0] += -0.000502314413210938;
            } else {
              result[0] += -0.0005171711823054296;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6210224928643216513) ) ) {
              result[0] += 2.7666519627680978e-05;
            } else {
              result[0] += -0.00033235581910304537;
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)356.5000000000000568) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.09500000000000001499) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1207797749301366269) ) ) {
                result[0] += 0.00043217503556440654;
              } else {
                result[0] += -0.00023414920673941732;
              }
            } else {
              result[0] += 0.0005379989003039083;
            }
          } else {
            result[0] += -0.0005346322900035276;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.007190624686192600631) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08500000000000000611) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8257879984924624273) ) ) {
              result[0] += 1.5183519628058342e-05;
            } else {
              result[0] += -0.0003475923126264702;
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1677498571863928756) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.676837902221867901e-06) ) ) {
                result[0] += 0.00029805113448289403;
              } else {
                result[0] += 0.0019345345903403906;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)37.50000000000000711) ) ) {
                result[0] += 5.077871134428571e-05;
              } else {
                result[0] += 0.0006622581692703245;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.04446937286580055632) ) ) {
            result[0] += 0.0027169779904941058;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02359730123255650638) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
                result[0] += -0.00014513561775095723;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1850000000000000255) ) ) {
                  result[0] += 0.000381999562286253;
                } else {
                  result[0] += 0.0019309243067350318;
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0036495000000000004) ) ) {
                result[0] += 0.0001547997154294859;
              } else {
                result[0] += 0.001874681350450369;
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5850000000000000755) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.004923558837848901124) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2650000000000000688) ) ) {
            result[0] += 0.00018227940206494187;
          } else {
            result[0] += 0.0025566747741578577;
          }
        } else {
          result[0] += 0.0035999040872093614;
        }
      } else {
        result[0] += 0.012410559781150453;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.0004621797280928938;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6249533869346735049) ) ) {
                result[0] += -0.0005777246547356369;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4840806222471906728) ) ) {
                  result[0] += -0.0005777246547356369;
                } else {
                  result[0] += -0.0005777246547356369;
                }
              }
            } else {
              result[0] += -0.0004447725760690729;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6152470170603016042) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.03659918966571634041) ) ) {
                  result[0] += -0.00046730095587060237;
                } else {
                  result[0] += -0.0002952284432235602;
                }
              } else {
                result[0] += -0.0005888670869776156;
              }
            } else {
              result[0] += -8.945965041737553e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.85801459308964273e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9993516786272610419) ) ) {
                  result[0] += -0.0005777246547356369;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.256922594654586334) ) ) {
                    result[0] += -0.0005777246547356369;
                  } else {
                    result[0] += -0.0005777246547356369;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.002492780962593150584) ) ) {
                    result[0] += -0.0005777246547356369;
                  } else {
                    result[0] += -0.0005777246547356369;
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)114.5000000000000142) ) ) {
                    result[0] += -0.0005777246547356369;
                  } else {
                    result[0] += -0.0005777246547356369;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)86.50000000000001421) ) ) {
                    result[0] += -0.0005777246547356369;
                  } else {
                    result[0] += -0.0005777246547356369;
                  }
                } else {
                  result[0] += -0.0005777246547356369;
                }
              } else {
                result[0] += -0.0005777246547356369;
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
              result[0] += -0.0004263626575152044;
            } else {
              result[0] += -0.0006157749695403601;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7403451809045227261) ) ) {
              result[0] += -0.00046446491712343865;
            } else {
              result[0] += -0.0005955580497951097;
            }
          } else {
            result[0] += -0.00033927236527179984;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9567162861906464144) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.04500000000000000527) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5143309380402011355) ) ) {
                result[0] += 0.0006023996136342323;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01344341525633075199) ) ) {
                  result[0] += -0.00047799605186473414;
                } else {
                  result[0] += 1.011236943568804e-05;
                }
              }
            } else {
              result[0] += 0.0044479855906414635;
            }
          } else {
            result[0] += -0.00046709107387545533;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2750000000000000777) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.04500000000000000527) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03500000000000001027) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -0.0004809955393441545;
              } else {
                result[0] += -0.0004952217679284332;
              }
            } else {
              result[0] += -0.00027487471723112777;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02985350000000000156) ) ) {
              result[0] += -0.0003129517446636527;
            } else {
              result[0] += 0.0003947721927340794;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08500000000000000611) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05403750000000000914) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7269841738944724518) ) ) {
                result[0] += -5.491890250875582e-05;
              } else {
                result[0] += -0.0003216546703642708;
              }
            } else {
              result[0] += 0.0007973320432318312;
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)199.5000000000000284) ) ) {
              result[0] += 0.0004500993586721354;
            } else {
              result[0] += -0.00016786747602815557;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006732000000000001004) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.140339474584314505) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05740595745564833902) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.322824821631954977e-06) ) ) {
                result[0] += -0.00025434115930852915;
              } else {
                result[0] += 0.0013730160178257412;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)43.50000000000000711) ) ) {
                result[0] += 0.00012064400569086115;
              } else {
                result[0] += 0.0005868452227209206;
              }
            }
          } else {
            result[0] += -0.00015175432404920507;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.247314011309283543) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02747750000000000539) ) ) {
              result[0] += 0.0013385299874954218;
            } else {
              result[0] += 0.0029415101041547864;
            }
          } else {
            result[0] += 3.4632723713899264e-05;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6150000000000001021) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.004923558837848901124) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2650000000000000688) ) ) {
            result[0] += 0.00018316744014508762;
          } else {
            result[0] += 0.002699222965258931;
          }
        } else {
          result[0] += 0.003539819788640102;
        }
      } else {
        result[0] += 0.012732664637918624;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.0004425642222108059;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6249533869346735049) ) ) {
                result[0] += -0.0005532052726113816;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4840806222471906728) ) ) {
                  result[0] += -0.0005532052726113816;
                } else {
                  result[0] += -0.0005532052726113816;
                }
              }
            } else {
              result[0] += -0.0004258958522498042;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6152470170603016042) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.03659918966571634041) ) ) {
                  result[0] += -0.00044746809845297306;
                } else {
                  result[0] += -0.00028269856596453984;
                }
              } else {
                result[0] += -0.0005638748056068159;
              }
            } else {
              result[0] += -8.566286706166145e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.85801459308964273e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9993516786272610419) ) ) {
                  result[0] += -0.0005532052726113816;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.256922594654586334) ) ) {
                    result[0] += -0.0005532052726113816;
                  } else {
                    result[0] += -0.0005532052726113816;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.002492780962593150584) ) ) {
                    result[0] += -0.0005532052726113816;
                  } else {
                    result[0] += -0.0005532052726113816;
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)114.5000000000000142) ) ) {
                    result[0] += -0.0005532052726113816;
                  } else {
                    result[0] += -0.0005532052726113816;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)86.50000000000001421) ) ) {
                    result[0] += -0.0005532052726113816;
                  } else {
                    result[0] += -0.0005532052726113816;
                  }
                } else {
                  result[0] += -0.0005532052726113816;
                }
              } else {
                result[0] += -0.0005532052726113816;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)7.626034349605784223e-05) ) ) {
              result[0] += -0.0006407500709286177;
            } else {
              result[0] += -0.0003955962979314458;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7403451809045227261) ) ) {
              result[0] += -0.00044475242486106265;
            } else {
              result[0] += -0.0005702817953018952;
            }
          } else {
            result[0] += -0.00032487320695284987;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9567162861906464144) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.04500000000000000527) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5143309380402011355) ) ) {
                result[0] += 0.0005768329943163147;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01344341525633075199) ) ) {
                  result[0] += -0.0004577092807299281;
                } else {
                  result[0] += 9.68318738790319e-06;
                }
              }
            } else {
              result[0] += 0.004259207324929357;
            }
          } else {
            result[0] += -0.00044726712412136065;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2750000000000000777) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.04500000000000000527) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04500000000000000527) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5800027599246232457) ) ) {
            result[0] += 2.129442044281199e-05;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
                result[0] += -0.000474203915107797;
              } else {
                result[0] += -0.0003128639563519944;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02687100000000000252) ) ) {
                result[0] += -0.0003167905187114873;
              } else {
                result[0] += 8.1410375684498e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04770400000000000335) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7269841738944724518) ) ) {
                result[0] += 1.7790812486501e-05;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001071500000000000187) ) ) {
                  result[0] += -0.00014678952951996833;
                } else {
                  result[0] += -0.000443643037587439;
                }
              }
            } else {
              result[0] += 0.0008514074501768479;
            }
          } else {
            result[0] += 0.0008277739464311563;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01896216239618550223) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5811189422864322385) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.750591121697756835e-06) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2150000000000000244) ) ) {
                result[0] += -0.00023728507724635618;
              } else {
                result[0] += 0.0019068382834808073;
              }
            } else {
              result[0] += 0.0011017286669762702;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)24.50000000000000355) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)18.50000000000000355) ) ) {
                result[0] += 2.298518832188821e-05;
              } else {
                result[0] += -0.0004951857956164208;
              }
            } else {
              result[0] += 0.00036778043785887606;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
            result[0] += 0.002444791421990024;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07347650000000001402) ) ) {
              result[0] += 0.0002874489797727374;
            } else {
              result[0] += 0.0030336681526947212;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8050000000000001599) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01413701125100120214) ) ) {
          result[0] += 0.0022029108995588833;
        } else {
          result[0] += 0.004099380067332871;
        }
      } else {
        result[0] += 0.010070208646789864;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.0004237812237876626;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6249533869346735049) ) ) {
                result[0] += -0.0005297265248011152;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4840806222471906728) ) ) {
                  result[0] += -0.0005297265248011152;
                } else {
                  result[0] += -0.0005297265248011152;
                }
              }
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6152470170603016042) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.03659918966571634041) ) ) {
                  result[0] += -0.0004284769731747852;
                } else {
                  result[0] += -0.00027070047291442514;
                }
              } else {
                result[0] += -0.0005399432290061249;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.85801459308964273e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9993516786272610419) ) ) {
                  result[0] += -0.0005297265248011152;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.256922594654586334) ) ) {
                    result[0] += -0.0005297265248011152;
                  } else {
                    result[0] += -0.0005297265248011152;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.002492780962593150584) ) ) {
                    result[0] += -0.0005297265248011152;
                  } else {
                    result[0] += -0.0005297265248011152;
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)114.5000000000000142) ) ) {
                    result[0] += -0.0005297265248011152;
                  } else {
                    result[0] += -0.0005297265248011152;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)86.50000000000001421) ) ) {
                    result[0] += -0.0005297265248011152;
                  } else {
                    result[0] += -0.0005297265248011152;
                  }
                } else {
                  result[0] += -0.0005297265248011152;
                }
              } else {
                result[0] += -0.0005297265248011152;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7562503571356784526) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002252500000000000595) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)8.256973923420418294e-06) ) ) {
                result[0] += -0.00040131846899249714;
              } else {
                result[0] += -0.0004132446978197592;
              }
            } else {
              result[0] += 3.299913093725301e-05;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8068034447989950175) ) ) {
              result[0] += -0.0006203425751837333;
            } else {
              result[0] += -0.00038107301210385606;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7403451809045227261) ) ) {
              result[0] += -0.0004258765562851446;
            } else {
              result[0] += -0.0005460782977656649;
            }
          } else {
            result[0] += -0.0003110851675504909;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.04500000000000000527) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005067500000000000823) ) ) {
                result[0] += -0.0004115549767323978;
              } else {
                result[0] += 1.3797024540511421e-05;
              }
            } else {
              result[0] += 0.00414728252518576;
            }
          } else {
            result[0] += -0.00042995829657729184;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2750000000000000777) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
              result[0] += -0.00044045563813584486;
            } else {
              result[0] += -0.00045407808716530336;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6210224928643216513) ) ) {
              result[0] += 3.887063107082385e-05;
            } else {
              result[0] += -0.0003007669635346967;
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)356.5000000000000568) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1250000000000000278) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1207797749301366269) ) ) {
                result[0] += 0.00025740750923411784;
              } else {
                result[0] += -0.0001844221987124272;
              }
            } else {
              result[0] += 0.0010033682199398217;
            }
          } else {
            result[0] += -0.00048612283503730234;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.007190624686192600631) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08500000000000000611) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8257879984924624273) ) ) {
              result[0] += 1.398601755862653e-06;
            } else {
              result[0] += -0.0003075548711039877;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4795364038944723295) ) ) {
              result[0] += 0.00133162261709155;
            } else {
              result[0] += 0.0004350396397964155;
            }
          }
        } else {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.0194836725655387448) ) ) {
            result[0] += 0.0026642439199273415;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05686650000000000732) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7683067979899498301) ) ) {
                result[0] += 0.0009313053750488709;
              } else {
                result[0] += -0.0002186273705597305;
              }
            } else {
              result[0] += 0.002079407305265916;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8850000000000001199) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01205124510104085139) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2750000000000000777) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0005935000000000001689) ) ) {
              result[0] += -0.0005289641296392932;
            } else {
              result[0] += 0.003644612081970017;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
              result[0] += 0.0026714722750497623;
            } else {
              result[0] += 0.001542997110171696;
            }
          }
        } else {
          result[0] += 0.003970638404276585;
        }
      } else {
        result[0] += 0.011340468642104173;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.00040579540012935074;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6249533869346735049) ) ) {
                result[0] += -0.0005072442454376081;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4840806222471906728) ) ) {
                  result[0] += -0.0005072442454376081;
                } else {
                  result[0] += -0.0005072442454376081;
                }
              }
            } else {
              result[0] += -0.00039061080666342936;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6152470170603016042) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.06355808660527756393) ) ) {
                result[0] += -0.0004102918558345459;
              } else {
                result[0] += 2.6664728830606392e-05;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)52.50000000000000711) ) ) {
                result[0] += -0.0005170273394921772;
              } else {
                result[0] += -0.0005094224908373945;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.85801459308964273e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9993516786272610419) ) ) {
                  result[0] += -0.0005072442454376081;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.256922594654586334) ) ) {
                    result[0] += -0.0005072442454376081;
                  } else {
                    result[0] += -0.0005072442454376081;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.002492780962593150584) ) ) {
                    result[0] += -0.0005072442454376081;
                  } else {
                    result[0] += -0.0005072442454376081;
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)114.5000000000000142) ) ) {
                    result[0] += -0.0005072442454376081;
                  } else {
                    result[0] += -0.0005072442454376081;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)86.50000000000001421) ) ) {
                    result[0] += -0.0005072442454376081;
                  } else {
                    result[0] += -0.0005072442454376081;
                  }
                } else {
                  result[0] += -0.0005072442454376081;
                }
              } else {
                result[0] += -0.0005072442454376081;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.054643202733792936e-05) ) ) {
              result[0] += -0.0005872276667337228;
            } else {
              result[0] += -0.00035551122821265145;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)7.626034349605784223e-05) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7471533970100503463) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4547672002352448062) ) ) {
              result[0] += -0.00040780180400354837;
            } else {
              result[0] += -0.00022681169229178715;
            }
          } else {
            result[0] += -0.0005229020279926428;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.05463331189772155372) ) ) {
              result[0] += 0.00021268976832272037;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01962450000000000652) ) ) {
                result[0] += -0.0004103805571709249;
              } else {
                result[0] += -1.0416966995683066e-05;
              }
            }
          } else {
            result[0] += 0.0013141975715867343;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4050000000000000822) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05500000000000000722) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03500000000000001027) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                result[0] += -0.0004217621307500862;
              } else {
                result[0] += -0.00043480642541053263;
              }
            } else {
              result[0] += -0.00024210320597685783;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7593447680904524821) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0204930000000000008) ) ) {
                result[0] += -0.0002254546457414274;
              } else {
                result[0] += 0.0006844318049483752;
              }
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8155157533417086713) ) ) {
                result[0] += -0.0003364968704407118;
              } else {
                result[0] += -0.00012800010907354506;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6479278833417086991) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.402140754838179745e-06) ) ) {
              result[0] += -0.00011439950107854288;
            } else {
              result[0] += 0.0003245957075574192;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0650000000000000161) ) ) {
              result[0] += -0.00024240840559129268;
            } else {
              result[0] += 9.327892665489725e-06;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5800027599246232457) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.007532052389947900377) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2750000000000000777) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.750591121697756835e-06) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)93.50000000000001421) ) ) {
                  result[0] += -0.0004821322315855024;
                } else {
                  result[0] += 0.0012871674470340286;
                }
              } else {
                result[0] += 0.0005877295864940656;
              }
            } else {
              result[0] += 0.0018963807082842605;
            }
          } else {
            result[0] += 0.0026552334901144173;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0195721650588623515) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1650000000000000355) ) ) {
              result[0] += 9.988730605095227e-05;
            } else {
              result[0] += 0.0009418462193532033;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.489742655943457672) ) ) {
              result[0] += 0.0018086684435368163;
            } else {
              result[0] += -0.00010835359550798545;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8850000000000001199) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01205124510104085139) ) ) {
          result[0] += 0.0027143538872844647;
        } else {
          result[0] += 0.004637032038553078;
        }
      } else {
        result[0] += 0.010859164474410092;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.00038857291810702894;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6249533869346735049) ) ) {
                result[0] += -0.0004857161431102019;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4840806222471906728) ) ) {
                  result[0] += -0.0004857161431102019;
                } else {
                  result[0] += -0.0004857161431102019;
                }
              }
            } else {
              result[0] += -0.0003740327784419631;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6152470170603016042) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.06355808660527756393) ) ) {
                result[0] += -0.00039287853841211306;
              } else {
                result[0] += 2.553304322557288e-05;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)52.50000000000000711) ) ) {
                result[0] += -0.0004950840299903581;
              } else {
                result[0] += -0.00048780194095581186;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.85801459308964273e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9993516786272610419) ) ) {
                  result[0] += -0.0004857161431102019;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.256922594654586334) ) ) {
                    result[0] += -0.0004857161431102019;
                  } else {
                    result[0] += -0.0004857161431102019;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.002492780962593150584) ) ) {
                    result[0] += -0.0004857161431102019;
                  } else {
                    result[0] += -0.0004857161431102019;
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)114.5000000000000142) ) ) {
                    result[0] += -0.0004857161431102019;
                  } else {
                    result[0] += -0.0004857161431102019;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)86.50000000000001421) ) ) {
                    result[0] += -0.0004857161431102019;
                  } else {
                    result[0] += -0.0004857161431102019;
                  }
                } else {
                  result[0] += -0.0004857161431102019;
                }
              } else {
                result[0] += -0.0004857161431102019;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.054643202733792936e-05) ) ) {
              result[0] += -0.0005623049644800555;
            } else {
              result[0] += -0.0003404228715317372;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.650000000000000541e-05) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7471533970100503463) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4547672002352448062) ) ) {
              result[0] += -0.00039049416760381897;
            } else {
              result[0] += -0.00022048314366184527;
            }
          } else {
            result[0] += -0.0005007093891069672;
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5072261056783921029) ) ) {
            result[0] += 0.0010465086506621646;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005067500000000000823) ) ) {
                result[0] += -0.000407300463357248;
              } else {
                result[0] += -0.00018123611417059074;
              }
            } else {
              result[0] += 2.4514053611986855e-05;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4050000000000000822) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05500000000000000722) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04500000000000000527) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5800027599246232457) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.503000764270941431e-05) ) ) {
              result[0] += -0.0004052383798599053;
            } else {
              result[0] += 0.0002999834132646701;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04770400000000000335) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)273.5000000000000568) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)62.50000000000000711) ) ) {
                    result[0] += -0.0004163526779248886;
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
                      result[0] += -0.0004001368833270907;
                    } else {
                      result[0] += 0.00010232702508074594;
                    }
                  }
                } else {
                  result[0] += -0.00048376772645687417;
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)125.5000000000000142) ) ) {
                  result[0] += -0.0003567307161874539;
                } else {
                  result[0] += -9.117949635075363e-06;
                }
              }
            } else {
              result[0] += 0.0001304442376458101;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01359750000000000195) ) ) {
              result[0] += -9.687079181071912e-05;
            } else {
              result[0] += 0.000674115752718718;
            }
          } else {
            result[0] += 0.0006842173653982317;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01461911667849610276) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2323788471531250399) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2750000000000000777) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.750591121697756835e-06) ) ) {
                result[0] += -0.00013900820476788365;
              } else {
                result[0] += 0.000755086160775075;
              }
            } else {
              result[0] += 0.0018016558811151614;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2050000000000000433) ) ) {
              result[0] += 0.00010387571880696008;
            } else {
              result[0] += 0.0011393367003000258;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8458243956458841861) ) ) {
            result[0] += 0.0024683436920470126;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09550850000000001006) ) ) {
              result[0] += 0.00040380262438899985;
            } else {
              result[0] += 0.0040828446853085;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8850000000000001199) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6650000000000001465) ) ) {
          result[0] += 0.003130395309931073;
        } else {
          result[0] += 0.006731017520411759;
        }
      } else {
        result[0] += 0.01039828747856847;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.00037208138051363527;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6249533869346735049) ) ) {
                result[0] += -0.00046510172131044653;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4840806222471906728) ) ) {
                  result[0] += -0.00046510172131044653;
                } else {
                  result[0] += -0.00046510172131044653;
                }
              }
            } else {
              result[0] += -0.00035815834319596863;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6152470170603016042) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.06355808660527756393) ) ) {
                result[0] += -0.0003762042647199966;
              } else {
                result[0] += 2.444938782241297e-05;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)52.50000000000000711) ) ) {
                result[0] += -0.00047407202294609465;
              } else {
                result[0] += -0.00046709899519573864;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.85801459308964273e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9993516786272610419) ) ) {
                  result[0] += -0.00046510172131044653;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.256922594654586334) ) ) {
                    result[0] += -0.00046510172131044653;
                  } else {
                    result[0] += -0.00046510172131044653;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.002492780962593150584) ) ) {
                    result[0] += -0.00046510172131044653;
                  } else {
                    result[0] += -0.00046510172131044653;
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)114.5000000000000142) ) ) {
                    result[0] += -0.00046510172131044653;
                  } else {
                    result[0] += -0.00046510172131044653;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)86.50000000000001421) ) ) {
                    result[0] += -0.00046510172131044653;
                  } else {
                    result[0] += -0.00046510172131044653;
                  }
                } else {
                  result[0] += -0.00046510172131044653;
                }
              } else {
                result[0] += -0.00046510172131044653;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.054643202733792936e-05) ) ) {
              result[0] += -0.0005384400139687065;
            } else {
              result[0] += -0.000325974884237959;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.650000000000000541e-05) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7471533970100503463) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4547672002352448062) ) ) {
              result[0] += -0.0003739210896950143;
            } else {
              result[0] += -0.00021112555366272078;
            }
          } else {
            result[0] += -0.0004794586345406175;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005067500000000000823) ) ) {
              result[0] += -0.0003057377992531314;
            } else {
              result[0] += 0.0002452217865437947;
            }
          } else {
            result[0] += -0.00039743207623183316;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5050000000000001155) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09500000000000001499) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05500000000000000722) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.553675928821614205) ) ) {
              result[0] += -0.00014782582371250267;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)341.5000000000000568) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)59.50000000000000711) ) ) {
                  result[0] += -0.00039868213136812317;
                } else {
                  result[0] += -0.00017332292613347767;
                }
              } else {
                result[0] += -0.0004326521606484827;
              }
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
              result[0] += -0.0002459796283581301;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
                result[0] += 0.0014296609314320943;
              } else {
                result[0] += -4.376600340217033e-05;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4184049418341709292) ) ) {
            result[0] += 0.0016853574096542493;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
              result[0] += -0.0003596240953540842;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
                result[0] += 2.647091149987468e-05;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)151.5000000000000284) ) ) {
                  result[0] += 0.0008530405041415211;
                } else {
                  result[0] += -0.00013900033167158385;
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0195721650588623515) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5800027599246232457) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.130629626450776108e-06) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2750000000000000777) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4578754035427136104) ) ) {
                  result[0] += -0.0006363194019346106;
                } else {
                  result[0] += 0.0008427887544642076;
                }
              } else {
                result[0] += 0.0023262221396474865;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)51.50000000000000711) ) ) {
                result[0] += 0.001001143411327434;
              } else {
                result[0] += 0.002140251604851748;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2050000000000000433) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)92.50000000000001421) ) ) {
                result[0] += -0.00010267015131960766;
              } else {
                result[0] += 0.00046036369556017726;
              }
            } else {
              result[0] += 0.0012085168042781068;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
            result[0] += 0.003041800328471449;
          } else {
            result[0] += 0.001403394278156909;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8950000000000001288) ) ) {
        result[0] += 0.004017425424926971;
      } else {
        result[0] += 0.010381383237703339;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.0003562897651215088;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6249533869346735049) ) ) {
                result[0] += -0.00044536220225412706;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4840806222471906728) ) ) {
                  result[0] += -0.00044536220225412706;
                } else {
                  result[0] += -0.00044536220225412706;
                }
              }
            } else {
              result[0] += -0.00034295763952887204;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6152470170603016042) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.06355808660527756393) ) ) {
                result[0] += -0.0003602376687857015;
              } else {
                result[0] += 2.341172415719141e-05;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)52.50000000000000711) ) ) {
                result[0] += -0.0004539517926776581;
              } else {
                result[0] += -0.0004472747092505581;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.85801459308964273e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9993516786272610419) ) ) {
                  result[0] += -0.00044536220225412706;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.256922594654586334) ) ) {
                    result[0] += -0.00044536220225412706;
                  } else {
                    result[0] += -0.00044536220225412706;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.002492780962593150584) ) ) {
                    result[0] += -0.00044536220225412706;
                  } else {
                    result[0] += -0.00044536220225412706;
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)114.5000000000000142) ) ) {
                    result[0] += -0.00044536220225412706;
                  } else {
                    result[0] += -0.00044536220225412706;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)86.50000000000001421) ) ) {
                    result[0] += -0.00044536220225412706;
                  } else {
                    result[0] += -0.00044536220225412706;
                  }
                } else {
                  result[0] += -0.00044536220225412706;
                }
              } else {
                result[0] += -0.00044536220225412706;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.054643202733792936e-05) ) ) {
              result[0] += -0.0005155879228466315;
            } else {
              result[0] += -0.0003121400882256652;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.650000000000000541e-05) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7471533970100503463) ) ) {
            result[0] += -0.00035805139466400457;
          } else {
            result[0] += -0.00045910978950395464;
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5064897371608040322) ) ) {
            result[0] += 0.001325304347992916;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
              result[0] += -0.0003504296380979934;
            } else {
              result[0] += 7.603992186079309e-05;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6650000000000001465) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09500000000000001499) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05500000000000000722) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.553675928821614205) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005984500000000001103) ) ) {
                result[0] += -0.0002530522547976462;
              } else {
                result[0] += 0.0003931947443236447;
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)341.5000000000000568) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)59.50000000000000711) ) ) {
                  result[0] += -0.00038176154567907955;
                } else {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                    result[0] += -0.0003592819176241623;
                  } else {
                    result[0] += 8.506078637380439e-05;
                  }
                }
              } else {
                result[0] += -0.0004142898429477103;
              }
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)313.5000000000000568) ) ) {
                result[0] += -0.00029613633020498284;
              } else {
                result[0] += 7.70288701253258e-05;
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
                result[0] += 0.0013689842710220535;
              } else {
                result[0] += -4.190851756930369e-05;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
            result[0] += -0.0003061150468486931;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
              result[0] += 5.540610225403637e-05;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)151.5000000000000284) ) ) {
                result[0] += 0.0008939705322231559;
              } else {
                result[0] += -0.00011501137231169908;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.008982725145665402047) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7211604863065327331) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2750000000000000777) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)187.5000000000000284) ) ) {
                result[0] += 0.000263199925943905;
              } else {
                result[0] += 0.0015348185333847377;
              }
            } else {
              result[0] += 0.0015126632288220844;
            }
          } else {
            result[0] += 0.0001810321420393386;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.08693186820944626136) ) ) {
            result[0] += 0.0033058069173881165;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0195721650588623515) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2150000000000000244) ) ) {
                result[0] += 0.00013187810680595708;
              } else {
                result[0] += 0.0012831220575517702;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.335710565658207782) ) ) {
                result[0] += 0.0021453153387271037;
              } else {
                result[0] += -0.0003195917633322434;
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6650000000000001465) ) ) {
        result[0] += 0.003128205875501782;
      } else {
        result[0] += 0.012062849119348122;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.00034116836632648427;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6249533869346735049) ) ) {
                result[0] += -0.00042646045393638266;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4840806222471906728) ) ) {
                  result[0] += -0.00042646045393638266;
                } else {
                  result[0] += -0.00042646045393638266;
                }
              }
            } else {
              result[0] += -0.0003284020734004212;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6152470170603016042) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.06355808660527756393) ) ) {
                result[0] += -0.00034494871584920395;
              } else {
                result[0] += 2.2418100281020715e-05;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)52.50000000000000711) ) ) {
                result[0] += -0.0004346854910244121;
              } else {
                result[0] += -0.00042829179166043385;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.85801459308964273e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9993516786272610419) ) ) {
                  result[0] += -0.00042646045393638266;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.256922594654586334) ) ) {
                    result[0] += -0.00042646045393638266;
                  } else {
                    result[0] += -0.00042646045393638266;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.002492780962593150584) ) ) {
                    result[0] += -0.00042646045393638266;
                  } else {
                    result[0] += -0.00042646045393638266;
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)114.5000000000000142) ) ) {
                    result[0] += -0.00042646045393638266;
                  } else {
                    result[0] += -0.00042646045393638266;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)86.50000000000001421) ) ) {
                    result[0] += -0.00042646045393638266;
                  } else {
                    result[0] += -0.00042646045393638266;
                  }
                } else {
                  result[0] += -0.00042646045393638266;
                }
              } else {
                result[0] += -0.00042646045393638266;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.054643202733792936e-05) ) ) {
              result[0] += -0.0004937057040503566;
            } else {
              result[0] += -0.00029889245886318626;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.650000000000000541e-05) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7471533970100503463) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4547672002352448062) ) ) {
              result[0] += -0.00034285523003103327;
            } else {
              result[0] += -0.00018696894726217422;
            }
          } else {
            result[0] += -0.00043962457578915307;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01154850000000000147) ) ) {
              result[0] += -0.0001303039204842137;
            } else {
              result[0] += 0.0004202306899463402;
            }
          } else {
            result[0] += -0.00036569185708168353;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5050000000000001155) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09500000000000001499) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05500000000000000722) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05530450000000000643) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7383710406281408511) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.00036555909154782043;
              } else {
                result[0] += -7.607964268673856e-05;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                  result[0] += -0.000363823384830837;
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)60.50000000000000711) ) ) {
                    result[0] += -0.00045803559059252543;
                  } else {
                    result[0] += -0.00021783091575228948;
                  }
                }
              } else {
                result[0] += -0.00024157941132596213;
              }
            }
          } else {
            result[0] += 0.0006338225206874217;
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
            result[0] += 0.0010612709702296638;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
              result[0] += -0.00033408573015369713;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
                result[0] += 3.689342608788066e-06;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)151.5000000000000284) ) ) {
                  result[0] += 0.0007534566227615823;
                } else {
                  result[0] += -0.00014926319493623744;
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0195721650588623515) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5792515097236182742) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.750591121697756835e-06) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2750000000000000777) ) ) {
                result[0] += -0.0003573110267122957;
              } else {
                result[0] += 0.0019778788405458866;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)51.50000000000000711) ) ) {
                result[0] += 0.001022608214512573;
              } else {
                result[0] += 0.0018603313111925598;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2050000000000000433) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)92.50000000000001421) ) ) {
                result[0] += -0.0001151344851308373;
              } else {
                result[0] += 0.0004354024740549695;
              }
            } else {
              result[0] += 0.0011033421002930532;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
            result[0] += 0.0028147979133978924;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02747750000000000539) ) ) {
              result[0] += 0.0005666668597828463;
            } else {
              result[0] += 0.0030952936403249843;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9350000000000001643) ) ) {
        result[0] += 0.0038319793536142266;
      } else {
        result[0] += 0.0106226026351836;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.00032668873926868647;
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.363906689523952442) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7573260829648241765) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0001725283487249000298) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
                  result[0] += -0.0004083609202827006;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
                    result[0] += -0.0004083609202827006;
                  } else {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7255694492462312351) ) ) {
                      result[0] += -0.0004083609202827006;
                    } else {
                      result[0] += -0.0004083609202827006;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6852090990703517681) ) ) {
                  result[0] += -0.000314464264338443;
                } else {
                  result[0] += -0.0003141350988392126;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5494686760804020631) ) ) {
                  result[0] += -0.0003303086458645708;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6754021834779359024) ) ) {
                    result[0] += -0.0004162368761506463;
                  } else {
                    result[0] += -0.0004083609202827006;
                  }
                }
              } else {
                result[0] += 1.0682074027310925e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.804290595070191781e-06) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                result[0] += -0.0004083609202827006;
              } else {
                result[0] += -0.0004083609202827006;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)27.50000000000000355) ) ) {
                  result[0] += -0.0004083609202827006;
                } else {
                  result[0] += -0.0004083609202827006;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.051391296366422923) ) ) {
                  result[0] += -0.0004083609202827006;
                } else {
                  result[0] += -0.0004083609202827006;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.650000000000000541e-05) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7293938685427137081) ) ) {
                result[0] += -0.0003283040102942244;
              } else {
                result[0] += -0.0004209663397650727;
              }
            } else {
              result[0] += -0.00020991549333328237;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.04500000000000000527) ) ) {
              result[0] += -3.706038687404014e-05;
            } else {
              result[0] += 0.003662558260939631;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.447980401343111337e-05) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8622145545979901238) ) ) {
                result[0] += -0.0004083609202827006;
              } else {
                result[0] += -0.0004083609202827006;
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)64.50000000000001421) ) ) {
                result[0] += -0.0004083609202827006;
              } else {
                result[0] += -0.0004083609202827006;
              }
            }
          } else {
            result[0] += -0.0004083609202827006;
          }
        } else {
          result[0] += -0.00042566225644769976;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5050000000000001155) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09500000000000001499) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05500000000000000722) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.363906689523952442) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.586499390175879487) ) ) {
                result[0] += 2.3810574652361324e-05;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)351.5000000000000568) ) ) {
                  result[0] += -0.0002692762881582776;
                } else {
                  result[0] += -0.0004102525781696446;
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01627850000000000477) ) ) {
                result[0] += -0.00010943989317252897;
              } else {
                result[0] += 0.0008633998836590988;
              }
            }
          } else {
            result[0] += -0.0003364873549093815;
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4184049418341709292) ) ) {
            result[0] += 0.0015756414893734463;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
              result[0] += -0.00032006134998229863;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7573260829648241765) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.004923558837848901124) ) ) {
                  result[0] += 3.703645704454451e-05;
                } else {
                  result[0] += 0.00048725240776587307;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001071500000000000187) ) ) {
                    result[0] += 5.122972988658876e-05;
                  } else {
                    result[0] += -0.00043325986727020137;
                  }
                } else {
                  result[0] += 0.0001555947887276076;
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0195721650588623515) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5792515097236182742) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.750591121697756835e-06) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2750000000000000777) ) ) {
                result[0] += -0.0003421462842534893;
              } else {
                result[0] += 0.0018939351024878054;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)65.50000000000001421) ) ) {
                result[0] += 0.0009675158701743993;
              } else {
                result[0] += 0.001940428194049717;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1550000000000000266) ) ) {
              result[0] += 6.47450531183046e-05;
            } else {
              result[0] += 0.000803540921831341;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
            result[0] += 0.0026953342466226864;
          } else {
            result[0] += 0.0011429800101918249;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6950000000000000622) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
          result[0] += 0.003116692064596971;
        } else {
          result[0] += 0.0046886387989184975;
        }
      } else {
        result[0] += 0.011948874261470812;
      }
    }
  }
}

