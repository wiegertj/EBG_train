
#include "header.h"

void predict_unit6(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -5.764352432676745e-05;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -6.930027320703808e-05;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -7.205440473740043e-05;
            } else {
              result[0] += -7.205440473740043e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6285027855690678011) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.06355808660527756393) ) ) {
                result[0] += -0.00010181602075968186;
              } else {
                result[0] += -1.1797891535559805e-05;
              }
            } else {
              result[0] += 0.0002571182405275447;
            }
          } else {
            result[0] += -0.0001290741454986356;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -7.205440473740043e-05;
                } else {
                  result[0] += -7.205440473740043e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -7.205440473740043e-05;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -7.205440473740043e-05;
                    } else {
                      result[0] += -7.205440473740043e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -7.205440473740043e-05;
                    } else {
                      result[0] += -7.205440473740043e-05;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -7.205440473740043e-05;
              } else {
                result[0] += -7.205440473740043e-05;
              }
            }
          } else {
            result[0] += -8.41262849481495e-05;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -7.205440473740043e-05;
              } else {
                result[0] += -7.205440473740043e-05;
              }
            } else {
              result[0] += -7.205440473740043e-05;
            }
          } else {
            result[0] += -7.205440473740043e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8850000000000001199) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3150000000000000577) ) ) {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.006053013595436600516) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2150000000000000244) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5226454670100503241) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.641728423423682037e-06) ) ) {
                    result[0] += -0.000266120012122133;
                  } else {
                    result[0] += 6.49483616236062e-05;
                  }
                } else {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5492268452512564236) ) ) {
                    result[0] += -0.0004804452911962431;
                  } else {
                    result[0] += 1.614610441820901e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002855500000000000399) ) ) {
                  result[0] += 0.0008031040436689015;
                } else {
                  result[0] += -0.0005040917688726618;
                }
              }
            } else {
              result[0] += 0.0007532171556398091;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07149150000000001337) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7496778360301509236) ) ) {
                  result[0] += -6.299859174265391e-06;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.002612771187363900714) ) ) {
                    result[0] += 6.350226927189021e-06;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9911809338528255742) ) ) {
                      result[0] += -0.0004784307757409688;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.051391296366422923) ) ) {
                        result[0] += 0.0007559162170065164;
                      } else {
                        result[0] += -0.00011590797742132984;
                      }
                    }
                  }
                }
              } else {
                result[0] += 0.0005296705751916055;
              }
            } else {
              result[0] += -0.0002323022808292058;
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01437243042433420173) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004677500000000000234) ) ) {
              result[0] += 0.0005171176622056166;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1165587384072143268) ) ) {
                result[0] += 0.0001933349854258928;
              } else {
                result[0] += -0.0005667139833068076;
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7650000000000001243) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.966590843157139501) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0660705000000000181) ) ) {
                  result[0] += 0.0006776667625833313;
                } else {
                  result[0] += 0.0028712978999668247;
                }
              } else {
                result[0] += -4.372967999603158e-05;
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)100.5000000000000142) ) ) {
                result[0] += 0.0017427970085163304;
              } else {
                result[0] += 0.0035671063756041797;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01504150000000000105) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.008240561420177351659) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)47.50000000000000711) ) ) {
                result[0] += -5.018813351414451e-05;
              } else {
                result[0] += 0.0029420200816226106;
              }
            } else {
              result[0] += 0.0038248905445273265;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05403737693237045669) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)86.50000000000001421) ) ) {
                result[0] += -0.00019912025628552357;
              } else {
                result[0] += 0.0025904286181247737;
              }
            } else {
              result[0] += 0.003093805213382999;
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01871178646485605404) ) ) {
            result[0] += 0.0031898682617746833;
          } else {
            result[0] += 0.004409070447875538;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -5.51970585435068e-05;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -6.635907991339858e-05;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -6.899632253680521e-05;
            } else {
              result[0] += -6.899632253680521e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01369138287730510203) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6135097231155780539) ) ) {
                result[0] += -3.262452784423815e-05;
              } else {
                result[0] += -0.00011267543724866548;
              }
            } else {
              result[0] += 2.7667384129807266e-05;
            }
          } else {
            result[0] += 0.000794140323508686;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -6.899632253680521e-05;
                } else {
                  result[0] += -6.899632253680521e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -6.899632253680521e-05;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -6.899632253680521e-05;
                    } else {
                      result[0] += -6.899632253680521e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -6.899632253680521e-05;
                    } else {
                      result[0] += -6.899632253680521e-05;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -6.899632253680521e-05;
              } else {
                result[0] += -6.899632253680521e-05;
              }
            }
          } else {
            result[0] += -8.055585652618519e-05;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -6.899632253680521e-05;
              } else {
                result[0] += -6.899632253680521e-05;
              }
            } else {
              result[0] += -6.899632253680521e-05;
            }
          } else {
            result[0] += -6.899632253680521e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8250000000000000666) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2050000000000000433) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.036113539341048927e-06) ) ) {
                result[0] += -5.189048277642071e-05;
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6249533869346735049) ) ) {
                  result[0] += -7.760711456336295e-06;
                } else {
                  result[0] += -0.00036189964897292233;
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3995174958040201285) ) ) {
                result[0] += 0.001115787649441745;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.316725863161028132) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7593447680904524821) ) ) {
                    result[0] += 1.1444442546260387e-05;
                  } else {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                      result[0] += -0.0003639205805652137;
                    } else {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01035297934913455113) ) ) {
                        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)41.50000000000000711) ) ) {
                          result[0] += -0.00026392847454845004;
                        } else {
                          result[0] += 0.00023391031034002626;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06960450000000001358) ) ) {
                          result[0] += -0.0003506531491492637;
                        } else {
                          result[0] += 0.0007072595899567637;
                        }
                      }
                    }
                  }
                } else {
                  result[0] += 0.00014766075726544133;
                }
              }
            }
          } else {
            result[0] += -0.00027039706207430844;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1377635000000000109) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.009516766579768852138) ) ) {
              result[0] += 0.0002072728746779381;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)33.50000000000000711) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3622054098241206943) ) ) {
                  result[0] += -0.0012884958288260709;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001543500000000000384) ) ) {
                    result[0] += 0.0009452502744447332;
                  } else {
                    result[0] += 0.00012028349210887839;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.05368089823796016319) ) ) {
                  result[0] += 0.0015087271605167642;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7750000000000001332) ) ) {
                    result[0] += 0.0003865672329674845;
                  } else {
                    result[0] += 0.002630708926340805;
                  }
                }
              }
            }
          } else {
            result[0] += 0.00322355329368895;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01369138287730510203) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007100500000000000908) ) ) {
              result[0] += 0.002477777882993889;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)210.5000000000000284) ) ) {
                result[0] += -0.0009541459972833595;
              } else {
                result[0] += 0.0017747190688752613;
              }
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01359750000000000195) ) ) {
              result[0] += 0.003543185125200244;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)86.50000000000001421) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09998752698574815689) ) ) {
                  result[0] += 0.0008084239205979761;
                } else {
                  result[0] += 0.0034770501311645998;
                }
              } else {
                result[0] += 0.003318593573428848;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01321089953182515153) ) ) {
            if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1341510627350609164) ) ) {
              result[0] += 0.0035160637322097666;
            } else {
              result[0] += -0.00010067675028312737;
            }
          } else {
            result[0] += 0.0042219437911921905;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -5.2854423934668036e-05;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -6.354271467007146e-05;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -6.606802930302861e-05;
            } else {
              result[0] += -6.606802930302861e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6285027855690678011) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3230417339964383738) ) ) {
                result[0] += -5.8114162104871755e-05;
              } else {
                result[0] += 2.6493144536089903e-05;
              }
            } else {
              result[0] += 0.00024503157000512507;
            }
          } else {
            result[0] += -0.00011881398029853217;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -6.606802930302861e-05;
                } else {
                  result[0] += -6.606802930302861e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -6.606802930302861e-05;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -6.606802930302861e-05;
                    } else {
                      result[0] += -6.606802930302861e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -6.606802930302861e-05;
                    } else {
                      result[0] += -6.606802930302861e-05;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -6.606802930302861e-05;
              } else {
                result[0] += -6.606802930302861e-05;
              }
            }
          } else {
            result[0] += -7.713696170782915e-05;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -6.606802930302861e-05;
              } else {
                result[0] += -6.606802930302861e-05;
              }
            } else {
              result[0] += -6.606802930302861e-05;
            }
          } else {
            result[0] += -6.606802930302861e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8850000000000001199) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4450000000000000622) ) ) {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05740595745564833902) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02116634333934230491) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.20148062912028756e-06) ) ) {
                result[0] += -0.00040451823493630016;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)841.5000000000001137) ) ) {
                  result[0] += 0.0002029013757214419;
                } else {
                  result[0] += 0.0019305273747351208;
                }
              }
            } else {
              result[0] += 0.0015625035011758062;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.32337995336020553) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)410.5000000000000568) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1250000000000000278) ) ) {
                    result[0] += -3.726380117327653e-05;
                  } else {
                    result[0] += 0.0005459167694824221;
                  }
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001872500000000000249) ) ) {
                    result[0] += -6.825989455155533e-05;
                  } else {
                    result[0] += -0.0002411569989746449;
                  }
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1269590000000000163) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)89.50000000000001421) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01244450000000000243) ) ) {
                      result[0] += -0.00011807428223661367;
                    } else {
                      result[0] += 0.0004784536485045888;
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7250000000000000888) ) ) {
                      result[0] += 0.00014293230480003912;
                    } else {
                      result[0] += -0.0012680031111918053;
                    }
                  }
                } else {
                  result[0] += 0.002092660519456183;
                }
              }
            } else {
              result[0] += -0.000466550675023869;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02937690275817125482) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00448250000000000124) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.006855418980843201206) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0005035000000000001497) ) ) {
                  result[0] += 0.0012959469721045523;
                } else {
                  result[0] += 6.009216975017195e-05;
                }
              } else {
                result[0] += 0.0011005093841504109;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.966590843157139501) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)85.50000000000001421) ) ) {
                  result[0] += -0.00025818276937190633;
                } else {
                  result[0] += 0.0007715455722373586;
                }
              } else {
                result[0] += -0.0008838193021531641;
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)27.50000000000000355) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4184049418341709292) ) ) {
                result[0] += -0.0014973505406673403;
              } else {
                result[0] += 0.0005678053506321644;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.247314011309283543) ) ) {
                result[0] += 0.0023510614979710166;
              } else {
                result[0] += -0.000850129487925623;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007249500000000001602) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.00802520011231920051) ) ) {
              result[0] += 0.0024880360607673;
            } else {
              result[0] += 0.0036964799389114095;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05403737693237045669) ) ) {
              result[0] += 0.0016547645620558482;
            } else {
              result[0] += 0.003189167103198515;
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01871178646485605404) ) ) {
            result[0] += 0.0028753013647759454;
          } else {
            result[0] += 0.004042759032025665;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -5.061121377081492e-05;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -6.0845879613030415e-05;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -6.326401662432663e-05;
            } else {
              result[0] += -6.326401662432663e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6285027855690678011) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3230417339964383738) ) ) {
                result[0] += -5.5647721845138856e-05;
              } else {
                result[0] += 2.5368741190605583e-05;
              }
            } else {
              result[0] += 0.00023463211301776303;
            }
          } else {
            result[0] += -0.00011377136118791706;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -6.326401662432663e-05;
                } else {
                  result[0] += -6.326401662432663e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -6.326401662432663e-05;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -6.326401662432663e-05;
                    } else {
                      result[0] += -6.326401662432663e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -6.326401662432663e-05;
                    } else {
                      result[0] += -6.326401662432663e-05;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -6.326401662432663e-05;
              } else {
                result[0] += -6.326401662432663e-05;
              }
            }
          } else {
            result[0] += -7.386316921080686e-05;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -6.326401662432663e-05;
              } else {
                result[0] += -6.326401662432663e-05;
              }
            } else {
              result[0] += -6.326401662432663e-05;
            }
          } else {
            result[0] += -6.326401662432663e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8850000000000001199) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3150000000000000577) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02747750000000000539) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04500000000000000527) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)30.50000000000000355) ) ) {
                  result[0] += -0.00013704652924171975;
                } else {
                  result[0] += -3.618791973418378e-05;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.04500000000000000527) ) ) {
                  result[0] += -7.031051053078726e-05;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2904646427154551902) ) ) {
                    result[0] += 0.000166058372190562;
                  } else {
                    result[0] += 0.0011492675540484643;
                  }
                }
              }
            } else {
              result[0] += 8.124925152887086e-06;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.247314011309283543) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)696.5000000000001137) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02180250462562445188) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5380790363330137938) ) ) {
                    result[0] += 0.00040674531827508356;
                  } else {
                    result[0] += -0.0004760123875656795;
                  }
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03588950000000001167) ) ) {
                    result[0] += 0.0013817433578129775;
                  } else {
                    result[0] += 0.0005673889868862339;
                  }
                }
              } else {
                result[0] += 0.000834276427694808;
              }
            } else {
              result[0] += -0.00026010346147925365;
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0129473293797221032) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002357500000000000654) ) ) {
              result[0] += 0.0004938310976850291;
            } else {
              result[0] += -1.4140575051931681e-05;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7650000000000001243) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3419045205559314016) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)89.50000000000001421) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0660705000000000181) ) ) {
                    result[0] += 0.0003633392956187295;
                  } else {
                    result[0] += 0.002965784491264218;
                  }
                } else {
                  result[0] += 0.0018373851271058176;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6402527760050252814) ) ) {
                  result[0] += -0.0011525065101426583;
                } else {
                  result[0] += 0.00048295352467503535;
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006601500000000000597) ) ) {
                result[0] += 0.0029518402186371365;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02447420998234165271) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)87.50000000000001421) ) ) {
                    result[0] += -0.001298127259301378;
                  } else {
                    result[0] += 0.0013573420993327956;
                  }
                } else {
                  result[0] += 0.002561817605438728;
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007249500000000001602) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.00802520011231920051) ) ) {
              result[0] += 0.002382440589961582;
            } else {
              result[0] += 0.003539596545769244;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05403737693237045669) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)59.50000000000000711) ) ) {
                result[0] += 0.0003240534258553024;
              } else {
                result[0] += 0.002267517396018034;
              }
            } else {
              result[0] += 0.00305381472344382;
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01871178646485605404) ) ) {
            result[0] += 0.002753269853211677;
          } else {
            result[0] += 0.003871179105965766;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -4.846320834981239e-05;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -5.8263501726455705e-05;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -6.0579009873079504e-05;
            } else {
              result[0] += -6.0579009873079504e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01369138287730510203) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6135097231155780539) ) ) {
                result[0] += -2.6411699052598314e-05;
              } else {
                result[0] += -9.802212291123599e-05;
              }
            } else {
              result[0] += 2.4292058978473903e-05;
            }
          } else {
            result[0] += 0.0007400784327246637;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -6.0579009873079504e-05;
                } else {
                  result[0] += -6.0579009873079504e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -6.0579009873079504e-05;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -6.0579009873079504e-05;
                    } else {
                      result[0] += -6.0579009873079504e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -6.0579009873079504e-05;
                    } else {
                      result[0] += -6.0579009873079504e-05;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -6.0579009873079504e-05;
              } else {
                result[0] += -6.0579009873079504e-05;
              }
            }
          } else {
            result[0] += -7.072832070478794e-05;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -6.0579009873079504e-05;
              } else {
                result[0] += -6.0579009873079504e-05;
              }
            } else {
              result[0] += -6.0579009873079504e-05;
            }
          } else {
            result[0] += -6.0579009873079504e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8850000000000001199) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2150000000000000244) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0009875000000000003133) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.008240561420177351659) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)43.50000000000000711) ) ) {
                result[0] += -0.00014894108250582269;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7573260829648241765) ) ) {
                    result[0] += -6.452021062138716e-05;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.179099372612799401) ) ) {
                      result[0] += -0.00015605859788447982;
                    } else {
                      result[0] += -3.7921822606748715e-05;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)615.5000000000001137) ) ) {
                    result[0] += 5.155811029262128e-06;
                  } else {
                    result[0] += 0.0006155642284629294;
                  }
                }
              }
            } else {
              result[0] += -0.0005226884846665036;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.25500000000000006) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4737195465326633492) ) ) {
                result[0] += 0.0007520302037865424;
              } else {
                result[0] += -3.260518043627864e-06;
              }
            } else {
              result[0] += 0.0025733809484526447;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1377635000000000109) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6950000000000000622) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0005035000000000001497) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
                  result[0] += -6.019954084348289e-05;
                } else {
                  result[0] += 0.0009203953779524257;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6690536170100503943) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01265500000000000132) ) ) {
                      result[0] += -1.1641251525356538e-05;
                    } else {
                      result[0] += 0.0007627591419892809;
                    }
                  } else {
                    result[0] += 0.0007938314898544759;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4050000000000000822) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00448250000000000124) ) ) {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002038500000000000381) ) ) {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4650000000000000244) ) ) {
                          result[0] += 0.0004745900101043483;
                        } else {
                          result[0] += -0.0014285162287649758;
                        }
                      } else {
                        result[0] += -0.0011512694491046793;
                      }
                    } else {
                      result[0] += -0.0001190679379953609;
                    }
                  } else {
                    result[0] += 0.00017242619462964982;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3664391713316583199) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
                  result[0] += 0.002122662853970501;
                } else {
                  result[0] += -0.0012178147482925837;
                }
              } else {
                result[0] += 0.001210247608374616;
              }
            }
          } else {
            result[0] += 0.003018807785857841;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05403737693237045669) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)57.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01775050000000000239) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.009516766579768852138) ) ) {
                result[0] += 0.00020879725546635544;
              } else {
                result[0] += 0.0030147919402017396;
              }
            } else {
              result[0] += -0.00010850909028160274;
            }
          } else {
            result[0] += 0.003058131114249735;
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
            result[0] += 0.0030769129356976927;
          } else {
            result[0] += 0.0037068812540521374;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -4.6406367059145675e-05;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -5.579072329988521e-05;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -5.8007958283690866e-05;
            } else {
              result[0] += -5.8007958283690866e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01369138287730510203) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6135097231155780539) ) ) {
                result[0] += -2.52907523588523e-05;
              } else {
                result[0] += -9.386193714005558e-05;
              }
            } else {
              result[0] += 2.3261072553027523e-05;
            }
          } else {
            result[0] += 0.0007086685461201193;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -5.8007958283690866e-05;
                } else {
                  result[0] += -5.8007958283690866e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -5.8007958283690866e-05;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -5.8007958283690866e-05;
                    } else {
                      result[0] += -5.8007958283690866e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -5.8007958283690866e-05;
                    } else {
                      result[0] += -5.8007958283690866e-05;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -5.8007958283690866e-05;
              } else {
                result[0] += -5.8007958283690866e-05;
              }
            }
          } else {
            result[0] += -6.772651922695221e-05;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -5.8007958283690866e-05;
              } else {
                result[0] += -5.8007958283690866e-05;
              }
            } else {
              result[0] += -5.8007958283690866e-05;
            }
          } else {
            result[0] += -5.8007958283690866e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4450000000000000622) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1377635000000000109) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05740595745564833902) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01413701125100120214) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.20148062912028756e-06) ) ) {
                  result[0] += -0.000382503427294326;
                } else {
                  result[0] += 0.00018155955088830616;
                }
              } else {
                result[0] += 0.0011152849392599084;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.32337995336020553) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)410.5000000000000568) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1250000000000000278) ) ) {
                      result[0] += -3.1998859108834705e-05;
                    } else {
                      result[0] += 0.0005164607444417511;
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001570360081376600365) ) ) {
                      result[0] += -5.570850568520484e-05;
                    } else {
                      result[0] += -0.00023396499755196475;
                    }
                  }
                } else {
                  result[0] += 1.3402185735756105e-05;
                }
              } else {
                result[0] += -0.0004207531232150244;
              }
            }
          } else {
            result[0] += 0.0017862976548477692;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08030541277720280868) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00448250000000000124) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.006855418980843201206) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.242456489623170593e-05) ) ) {
                  result[0] += 0.0021158525745859197;
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4543227793467337072) ) ) {
                    result[0] += 0.0009728539234623382;
                  } else {
                    if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1341510627350609164) ) ) {
                      result[0] += -0.0008603478622359231;
                    } else {
                      result[0] += 6.879816298568522e-05;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7750000000000001332) ) ) {
                  result[0] += 0.0007567094666550167;
                } else {
                  result[0] += 0.002842762435108527;
                }
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)40.50000000000000711) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6305648090703518394) ) ) {
                  result[0] += -0.0006615789537097738;
                } else {
                  result[0] += 0.001734163906155665;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3230417339964383738) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01751223853061240412) ) ) {
                    result[0] += 0.00032371148625788017;
                  } else {
                    result[0] += 0.002366496142338818;
                  }
                } else {
                  result[0] += -0.00020183470785543187;
                }
              }
            }
          } else {
            result[0] += 0.0021743806171652517;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09998752698574815689) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)34.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02374450000000000519) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01035297934913455113) ) ) {
                result[0] += -0.00016788229306106338;
              } else {
                result[0] += 0.0031251438768951324;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08188550000000001383) ) ) {
                result[0] += -0.0013063604075390035;
              } else {
                result[0] += 0.002276316269722188;
              }
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01896216239618550223) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03507550000000000251) ) ) {
                result[0] += 0.0027871169771254444;
              } else {
                result[0] += -0.00014206437869011671;
              }
            } else {
              result[0] += 0.0031545170902784916;
            }
          }
        } else {
          result[0] += 0.0036427421207765667;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -4.44368207751251e-05;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -5.342289279037641e-05;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -5.5546025451593686e-05;
            } else {
              result[0] += -5.5546025451593686e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6285027855690678011) ) ) {
            result[0] += -2.4217380093684932e-05;
          } else {
            result[0] += -0.00010079894948576497;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -5.5546025451593686e-05;
                } else {
                  result[0] += -5.5546025451593686e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -5.5546025451593686e-05;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -5.5546025451593686e-05;
                    } else {
                      result[0] += -5.5546025451593686e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -5.5546025451593686e-05;
                    } else {
                      result[0] += -5.5546025451593686e-05;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -5.5546025451593686e-05;
              } else {
                result[0] += -5.5546025451593686e-05;
              }
            }
          } else {
            result[0] += -6.48521180892143e-05;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -5.5546025451593686e-05;
              } else {
                result[0] += -5.5546025451593686e-05;
              }
            } else {
              result[0] += -5.5546025451593686e-05;
            }
          } else {
            result[0] += -5.5546025451593686e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4450000000000000622) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06439350000000000629) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.03500000000000001027) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)439.5000000000000568) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7093311367085428643) ) ) {
                  result[0] += -7.30488067149107e-05;
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7496778360301509236) ) ) {
                    result[0] += 9.416346878741886e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.168079446220334772) ) ) {
                      result[0] += -0.0001036804432110291;
                    } else {
                      result[0] += 4.1011977335656345e-05;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)564.5000000000001137) ) ) {
                  result[0] += -0.00011549051242066324;
                } else {
                  result[0] += -5.90277862199417e-05;
                }
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                result[0] += 0.00011168506816988873;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.316725863161028132) ) ) {
                  result[0] += -0.00033498859019861306;
                } else {
                  result[0] += 1.625006422543126e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)902.5000000000001137) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02937690275817125482) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6915080527790725684) ) ) {
                  result[0] += 0.0004388614012381997;
                } else {
                  result[0] += -0.00018942374718934287;
                }
              } else {
                result[0] += 0.0010903665903186956;
              }
            } else {
              result[0] += 0.0024974738763897946;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02085144663384500344) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00526800000000000098) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.006855418980843201206) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0005035000000000001497) ) ) {
                  result[0] += 0.0011856499242098835;
                } else {
                  result[0] += 5.966655693732337e-05;
                }
              } else {
                result[0] += 0.0009745102158971163;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)115.5000000000000142) ) ) {
                result[0] += -0.0006695563487896488;
              } else {
                result[0] += 0.0004395497276036081;
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7650000000000001243) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)26.50000000000000355) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4184049418341709292) ) ) {
                  result[0] += -0.0014578164958445382;
                } else {
                  result[0] += 0.00019492879787643102;
                }
              } else {
                result[0] += 0.001408606248450383;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008633000000000001783) ) ) {
                result[0] += 0.0027853845507161456;
              } else {
                result[0] += 0.0019649638938096553;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09998752698574815689) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)34.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02374450000000000519) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01035297934913455113) ) ) {
                result[0] += -0.00016075715124528865;
              } else {
                result[0] += 0.002992508725733146;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08188550000000001383) ) ) {
                result[0] += -0.001250916780956886;
              } else {
                result[0] += 0.0021797064608877073;
              }
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01896216239618550223) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03507550000000000251) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)183.5000000000000284) ) ) {
                  result[0] += 0.0023210393585646823;
                } else {
                  result[0] += 0.0032370837339101197;
                }
              } else {
                result[0] += -0.00013603498257763437;
              }
            } else {
              result[0] += 0.0030206353019213285;
            }
          }
        } else {
          result[0] += 0.003488139430191532;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -4.255086458467844e-05;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -5.115555607249e-05;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -5.3188580235490785e-05;
            } else {
              result[0] += -5.3188580235490785e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6285027855690678011) ) ) {
            result[0] += -2.3189563136769483e-05;
          } else {
            result[0] += -9.652091160057914e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -5.3188580235490785e-05;
                } else {
                  result[0] += -5.3188580235490785e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -5.3188580235490785e-05;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -5.3188580235490785e-05;
                    } else {
                      result[0] += -5.3188580235490785e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -5.3188580235490785e-05;
                    } else {
                      result[0] += -5.3188580235490785e-05;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -5.3188580235490785e-05;
              } else {
                result[0] += -5.3188580235490785e-05;
              }
            }
          } else {
            result[0] += -6.209971025623995e-05;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -5.3188580235490785e-05;
              } else {
                result[0] += -5.3188580235490785e-05;
              }
            } else {
              result[0] += -5.3188580235490785e-05;
            }
          } else {
            result[0] += -5.3188580235490785e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4450000000000000622) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1377635000000000109) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05740595745564833902) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02149820807722475566) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.20148062912028756e-06) ) ) {
                  result[0] += -0.00037100954559963833;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)841.5000000000001137) ) ) {
                    result[0] += 0.00016497452867825473;
                  } else {
                    result[0] += 0.0017155102918474873;
                  }
                }
              } else {
                result[0] += 0.001246582095383537;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.32337995336020553) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.0650000000000000161) ) ) {
                  result[0] += -3.6046836096313596e-05;
                } else {
                  result[0] += 3.7125454535903315e-05;
                }
              } else {
                result[0] += -0.0004035854898234143;
              }
            }
          } else {
            result[0] += 0.001683888086750461;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0465984882276438625) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00448250000000000124) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.006855418980843201206) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001872500000000000249) ) ) {
                  result[0] += 0.0005473892066987118;
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4638663492462312132) ) ) {
                    result[0] += 0.0012283797619735656;
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)61.50000000000000711) ) ) {
                      result[0] += -0.001170048229307421;
                    } else {
                      result[0] += -1.989034898685307e-05;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8150000000000000577) ) ) {
                  result[0] += 0.0007863016394980976;
                } else {
                  result[0] += 0.0029031681666375074;
                }
              }
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7293938685427137081) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)45.50000000000000711) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6479278833417086991) ) ) {
                    result[0] += -0.00039920437596130864;
                  } else {
                    result[0] += 0.0019169195688379752;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0129473293797221032) ) ) {
                    result[0] += 5.7778871298440584e-05;
                  } else {
                    result[0] += 0.0014281499041301255;
                  }
                }
              } else {
                result[0] += -0.0008473860781552485;
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)26.50000000000000355) ) ) {
              result[0] += 0.0002509817039008804;
            } else {
              result[0] += 0.0022689172947635006;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09998752698574815689) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)34.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02374450000000000519) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01035297934913455113) ) ) {
                result[0] += -0.00015393440967059505;
              } else {
                result[0] += 0.002865502782062634;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08188550000000001383) ) ) {
                result[0] += -0.0011978262536503084;
              } else {
                result[0] += 0.00208719689738696;
              }
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01871178646485605404) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03507550000000000251) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)183.5000000000000284) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007249500000000001602) ) ) {
                    result[0] += 0.0030806447616795974;
                  } else {
                    result[0] += 0.0007409339928699218;
                  }
                } else {
                  result[0] += 0.0030994532215415653;
                }
              } else {
                result[0] += -0.0001034324791196263;
              }
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2450759342279490716) ) ) {
                result[0] += 0.0037118874940431017;
              } else {
                result[0] += 0.002606735854141847;
              }
            }
          }
        } else {
          result[0] += 0.0033400982779047475;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -4.074495081603965e-05;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -4.89844480596355e-05;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -5.093118804571592e-05;
            } else {
              result[0] += -5.093118804571592e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01369138287730510203) ) ) {
              result[0] += -6.79695360938597e-05;
            } else {
              result[0] += 2.4285854557758837e-05;
            }
          } else {
            result[0] += 0.0006806037477902494;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -5.093118804571592e-05;
                } else {
                  result[0] += -5.093118804571592e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -5.093118804571592e-05;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -5.093118804571592e-05;
                    } else {
                      result[0] += -5.093118804571592e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -5.093118804571592e-05;
                    } else {
                      result[0] += -5.093118804571592e-05;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -5.093118804571592e-05;
              } else {
                result[0] += -5.093118804571592e-05;
              }
            }
          } else {
            result[0] += -5.946411817427308e-05;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -5.093118804571592e-05;
              } else {
                result[0] += -5.093118804571592e-05;
              }
            } else {
              result[0] += -5.093118804571592e-05;
            }
          } else {
            result[0] += -5.093118804571592e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2050000000000000433) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8371684470603016903) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.036113539341048927e-06) ) ) {
                    result[0] += -7.175986575005005e-06;
                  } else {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6249533869346735049) ) ) {
                      result[0] += -1.3935600669225962e-05;
                    } else {
                      result[0] += -0.0003460843647359312;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3995174958040201285) ) ) {
                    result[0] += 0.0008959286614920139;
                  } else {
                    result[0] += -3.76405793045663e-06;
                  }
                }
              } else {
                result[0] += -0.0002836558117540925;
              }
            } else {
              result[0] += 0.0001357848490229665;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8789704397738694608) ) ) {
              result[0] += -0.00031049915193776185;
            } else {
              result[0] += 5.980028931067812e-06;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0465984882276438625) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)57.50000000000000711) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.290165581321393473) ) ) {
                  result[0] += -3.1398050196553206e-05;
                } else {
                  result[0] += 0.0012836303775919484;
                }
              } else {
                result[0] += 0.0009178608813953527;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.05368089823796016319) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.00991443746623210144) ) ) {
                  result[0] += 0.00044327282469866855;
                } else {
                  result[0] += 0.0014884095557445472;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.09900846148772847466) ) ) {
                  result[0] += -0.0005155097751224824;
                } else {
                  result[0] += 0.00031529274948879216;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.213351496714494937) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)26.50000000000000355) ) ) {
                result[0] += 0.0006527817292024093;
              } else {
                result[0] += 0.00218736245622213;
              }
            } else {
              result[0] += -0.0010476061218048468;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01265500000000000132) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3498337084924623697) ) ) {
              result[0] += 0.00048140831515589466;
            } else {
              result[0] += 0.003004099653678738;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01611044660174075147) ) ) {
              result[0] += -0.0003507119904718907;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)84.50000000000001421) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09998752698574815689) ) ) {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4086612272110553001) ) ) {
                    result[0] += -0.0015482173757872955;
                  } else {
                    result[0] += 0.0007789147095095749;
                  }
                } else {
                  result[0] += 0.002673372166511843;
                }
              } else {
                result[0] += 0.002466801850389723;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06116598190050365896) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02424450000000000563) ) ) {
                result[0] += 0.002897102259000302;
              } else {
                result[0] += -0.0008026143016914961;
              }
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6455378428894472664) ) ) {
                result[0] += 0.0031072111170373255;
              } else {
                result[0] += 0.0006578977451502502;
              }
            }
          } else {
            result[0] += 0.0031768417116302856;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -3.901568236522443e-05;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -4.690548468101781e-05;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -4.8769602502328214e-05;
            } else {
              result[0] += -4.8769602502328214e-05;
            }
          }
        } else {
          result[0] += -3.061307144278903e-05;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -4.8769602502328214e-05;
                } else {
                  result[0] += -4.8769602502328214e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -4.8769602502328214e-05;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -4.8769602502328214e-05;
                    } else {
                      result[0] += -4.8769602502328214e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -4.8769602502328214e-05;
                    } else {
                      result[0] += -4.8769602502328214e-05;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -4.8769602502328214e-05;
              } else {
                result[0] += -4.8769602502328214e-05;
              }
            }
          } else {
            result[0] += -5.694038403164064e-05;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -4.8769602502328214e-05;
              } else {
                result[0] += -4.8769602502328214e-05;
              }
            } else {
              result[0] += -4.8769602502328214e-05;
            }
          } else {
            result[0] += -4.8769602502328214e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4350000000000000533) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1377635000000000109) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.036113539341048927e-06) ) ) {
                result[0] += -4.7110864285914695e-05;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)157.5000000000000284) ) ) {
                  result[0] += -0.00017060133940754944;
                } else {
                  result[0] += -0.0004413877668255971;
                }
              }
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3103687546836865763) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.130629626450776108e-06) ) ) {
                  result[0] += -0.0006177923906030826;
                } else {
                  result[0] += 0.0007005317060208228;
                }
              } else {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.226146172451905686) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00279350000000000041) ) ) {
                    result[0] += 0.00015387010624221784;
                  } else {
                    result[0] += -0.0008641670115212531;
                  }
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1296381427427941713) ) ) {
                    if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1536978514979052968) ) ) {
                      result[0] += 0.0004575598405628816;
                    } else {
                      result[0] += 0.0024188356676371494;
                    }
                  } else {
                    if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1185261981962025396) ) ) {
                      result[0] += -0.0007013537701400891;
                    } else {
                      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05740595745564833902) ) ) {
                        result[0] += 0.00039334906540414974;
                      } else {
                        result[0] += -4.623855523242443e-06;
                      }
                    }
                  }
                }
              }
            }
          } else {
            result[0] += 0.0015924827953280934;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08030541277720280868) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)59.50000000000000711) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001543500000000000384) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5350000000000001421) ) ) {
                  result[0] += -0.0012372673330633343;
                } else {
                  result[0] += 0.0011093779174949012;
                }
              } else {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6555524765326633529) ) ) {
                  result[0] += -0.00015437454423660878;
                } else {
                  result[0] += 0.0008872329173758435;
                }
              }
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.564198853668341882) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.00991443746623210144) ) ) {
                  result[0] += 0.00044735918319679545;
                } else {
                  result[0] += 0.001836350403103881;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += 0.0004489218393249535;
                } else {
                  result[0] += -0.0008509198198555203;
                }
              }
            }
          } else {
            result[0] += 0.0019379178914232169;
          }
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01265500000000000132) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3498337084924623697) ) ) {
              result[0] += 0.0004609767231503539;
            } else {
              result[0] += 0.0028766017760235114;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09998752698574815689) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)84.50000000000001421) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4086612272110553001) ) ) {
                  result[0] += -0.0015794033594753237;
                } else {
                  result[0] += 0.0005471850427956707;
                }
              } else {
                result[0] += 0.0019489318210050182;
              }
            } else {
              result[0] += 0.0025690923720792106;
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06116598190050365896) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02424450000000000563) ) ) {
                result[0] += 0.0027741454892671897;
              } else {
                result[0] += -0.0007685503118647662;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3872449054220527542) ) ) {
                result[0] += 0.0030255973796009367;
              } else {
                result[0] += 0.0006299757132968474;
              }
            }
          } else {
            result[0] += 0.0030420124374471043;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -3.73598063057385e-05;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -4.491475519909264e-05;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -4.669975744724777e-05;
            } else {
              result[0] += -4.669975744724777e-05;
            }
          }
        } else {
          result[0] += -2.9313813066761534e-05;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -4.669975744724777e-05;
                } else {
                  result[0] += -4.669975744724777e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -4.669975744724777e-05;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -4.669975744724777e-05;
                    } else {
                      result[0] += -4.669975744724777e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -4.669975744724777e-05;
                    } else {
                      result[0] += -4.669975744724777e-05;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -4.669975744724777e-05;
              } else {
                result[0] += -4.669975744724777e-05;
              }
            }
          } else {
            result[0] += -5.452376043261407e-05;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -4.669975744724777e-05;
              } else {
                result[0] += -4.669975744724777e-05;
              }
            } else {
              result[0] += -4.669975744724777e-05;
            }
          } else {
            result[0] += -4.669975744724777e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3150000000000000577) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1957540000000000113) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.036113539341048927e-06) ) ) {
                result[0] += -5.002606791838561e-05;
              } else {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6169877415829146949) ) ) {
                  result[0] += -6.274031389809903e-05;
                } else {
                  result[0] += -0.00031411131679558895;
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.394516409999999984) ) ) {
                result[0] += 0.0009584318851543179;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
                  result[0] += 7.212811238177457e-06;
                } else {
                  result[0] += -0.00022543572840327667;
                }
              }
            }
          } else {
            result[0] += 0.0021968909651725013;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06563467004728905374) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)58.50000000000000711) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001543500000000000384) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6050000000000000933) ) ) {
                  result[0] += -0.0003282427236383391;
                } else {
                  result[0] += 0.0010246445878244442;
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.008408953333664601418) ) ) {
                  result[0] += -0.0003417237096330045;
                } else {
                  result[0] += 0.0001842986165937649;
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.05368089823796016319) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01611044660174075147) ) ) {
                  result[0] += 0.0005443784680898039;
                } else {
                  result[0] += 0.0020690238862606696;
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00799650000000000187) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001117500000000000221) ) ) {
                      result[0] += -0.0006942803439571926;
                    } else {
                      result[0] += 7.85834395871397e-05;
                    }
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.003859773430623800444) ) ) {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001624500000000000293) ) ) {
                        result[0] += 0.00042971121939014564;
                      } else {
                        result[0] += -0.0008129044836687094;
                      }
                    } else {
                      result[0] += 0.0009492648831118045;
                    }
                  }
                } else {
                  result[0] += -0.00018765306718079316;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8030059940338053481) ) ) {
              result[0] += 0.002027596485019454;
            } else {
              result[0] += 0.00010979779248389537;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01265500000000000132) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3498337084924623697) ) ) {
              result[0] += 0.0004414122743551347;
            } else {
              result[0] += 0.00275451507332271;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01611044660174075147) ) ) {
              result[0] += -0.0003522377433507714;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)44.50000000000000711) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09998752698574815689) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03420850000000000973) ) ) {
                    result[0] += 0.0007834476761508102;
                  } else {
                    result[0] += -0.0016892914078222307;
                  }
                } else {
                  result[0] += 0.0022692160994908514;
                }
              } else {
                result[0] += 0.0020353399692944066;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06413776133552721859) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02424450000000000563) ) ) {
                result[0] += 0.002656407164639827;
              } else {
                result[0] += -0.0003427642528819778;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3872449054220527542) ) ) {
                result[0] += 0.0028861736902692403;
              } else {
                result[0] += 0.0006032387286161553;
              }
            }
          } else {
            result[0] += 0.002912905492176381;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -3.577420776949856e-05;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -4.30085148530789e-05;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -4.471775929540661e-05;
            } else {
              result[0] += -4.471775929540661e-05;
            }
          }
        } else {
          result[0] += -2.8069696897906304e-05;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -4.471775929540661e-05;
                } else {
                  result[0] += -4.471775929540661e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -4.471775929540661e-05;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -4.471775929540661e-05;
                    } else {
                      result[0] += -4.471775929540661e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -4.471775929540661e-05;
                    } else {
                      result[0] += -4.471775929540661e-05;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -4.471775929540661e-05;
              } else {
                result[0] += -4.471775929540661e-05;
              }
            }
          } else {
            result[0] += -5.220970146708429e-05;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -4.471775929540661e-05;
              } else {
                result[0] += -4.471775929540661e-05;
              }
            } else {
              result[0] += -4.471775929540661e-05;
            }
          } else {
            result[0] += -4.471775929540661e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8850000000000001199) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2150000000000000244) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0009875000000000003133) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)43.50000000000000711) ) ) {
              result[0] += -0.0001539827071192811;
            } else {
              result[0] += -1.2714664132335449e-05;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.25500000000000006) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2050000000000000433) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.115000000000000005) ) ) {
                  result[0] += -5.52057499944234e-06;
                } else {
                  result[0] += 0.0006054455629623234;
                }
              } else {
                result[0] += -0.0005712121919680047;
              }
            } else {
              result[0] += 0.002408067266831916;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1645630000000000426) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0005035000000000001497) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
                result[0] += -5.08579465965223e-05;
              } else {
                result[0] += 0.000828274987344529;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.009516766579768852138) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1550000000000000266) ) ) {
                  result[0] += -0.0005733055200437047;
                } else {
                  result[0] += -2.8857927056625905e-05;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.966590843157139501) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)37.50000000000000711) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6359282793467337935) ) ) {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08030541277720280868) ) ) {
                        result[0] += -0.0001395063443373315;
                      } else {
                        result[0] += 0.0010557846470613877;
                      }
                    } else {
                      result[0] += 0.0006631827380153858;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4350000000000000533) ) ) {
                      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4725302343969849939) ) ) {
                        result[0] += 0.001814719299262429;
                      } else {
                        result[0] += 6.640621784608233e-05;
                      }
                    } else {
                      result[0] += 0.0010899042956868394;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8022705390703518402) ) ) {
                    result[0] += -0.0009762621856902014;
                  } else {
                    result[0] += 0.00016524841131777834;
                  }
                }
              }
            }
          } else {
            result[0] += 0.003350198933870251;
          }
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01244450000000000243) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03869870194826590531) ) ) {
              result[0] += 0.0021032491371048095;
            } else {
              result[0] += 0.002877822295839317;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05403737693237045669) ) ) {
                result[0] += 0.001758566286205054;
              } else {
                result[0] += 0.003883970983441427;
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)79.50000000000001421) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09998752698574815689) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03049200000000000174) ) ) {
                    result[0] += 0.0004886186936931837;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05826200000000000823) ) ) {
                      result[0] += -0.0029925810819013;
                    } else {
                      result[0] += 0.00024280270469319802;
                    }
                  }
                } else {
                  result[0] += 0.0021386941448856157;
                }
              } else {
                result[0] += 0.001542006827438817;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06413776133552721859) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02424450000000000563) ) ) {
                result[0] += 0.0025436658062548074;
              } else {
                result[0] += -0.00032821689433313293;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3872449054220527542) ) ) {
                result[0] += 0.0027636807431384563;
              } else {
                result[0] += 0.000577636496172299;
              }
            }
          } else {
            result[0] += 0.0027892780127723787;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -3.425590408745436e-05;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -4.1183177814690085e-05;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -4.281987971052673e-05;
            } else {
              result[0] += -4.281987971052673e-05;
            }
          }
        } else {
          result[0] += -2.6878382629577693e-05;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -4.281987971052673e-05;
                } else {
                  result[0] += -4.281987971052673e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -4.281987971052673e-05;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -4.281987971052673e-05;
                    } else {
                      result[0] += -4.281987971052673e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -4.281987971052673e-05;
                    } else {
                      result[0] += -4.281987971052673e-05;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -4.281987971052673e-05;
              } else {
                result[0] += -4.281987971052673e-05;
              }
            }
          } else {
            result[0] += -4.9993854159251223e-05;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -4.281987971052673e-05;
              } else {
                result[0] += -4.281987971052673e-05;
              }
            } else {
              result[0] += -4.281987971052673e-05;
            }
          } else {
            result[0] += -4.281987971052673e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7750000000000001332) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08500000000000000611) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1350000000000000366) ) ) {
              result[0] += -3.1416421768240625e-05;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6067453057537689487) ) ) {
                result[0] += 0.002729026515708613;
              } else {
                result[0] += -0.00016767249630213242;
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1645630000000000426) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1466079245622486649) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01289050000000000092) ) ) {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)90.50000000000001421) ) ) {
                      result[0] += -2.821858133701308e-05;
                    } else {
                      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3498337084924623697) ) ) {
                        result[0] += -0.000926951668221376;
                      } else {
                        result[0] += 0.0006713965339004383;
                      }
                    }
                  } else {
                    result[0] += 0.0011322579519592972;
                  }
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0005035000000000001497) ) ) {
                    result[0] += 0.000249497033253589;
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.004923558837848901124) ) ) {
                      result[0] += -0.00027959972463496456;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9766759383227824332) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4868404241646586694) ) ) {
                          result[0] += -1.5541514539409446e-06;
                        } else {
                          result[0] += 0.0003777674402679183;
                        }
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9911809338528255742) ) ) {
                          result[0] += -0.0010585861649415097;
                        } else {
                          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05173018288230480516) ) ) {
                            result[0] += 3.739515271018549e-05;
                          } else {
                            result[0] += -0.001100470611673889;
                          }
                        }
                      }
                    }
                  }
                }
              } else {
                result[0] += 0.0017354177819112193;
              }
            } else {
              result[0] += 0.00266662678646098;
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02116634333934230491) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004677500000000000234) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001427453683264650122) ) ) {
                result[0] += -0.0006118800175435162;
              } else {
                result[0] += 0.002076304868626012;
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)149.5000000000000284) ) ) {
                result[0] += -0.0007449553901683967;
              } else {
                result[0] += 0.0009796753325722832;
              }
            }
          } else {
            result[0] += 0.0020430169727538253;
          }
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01265500000000000132) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.00802520011231920051) ) ) {
              result[0] += 0.0009925251531528135;
            } else {
              result[0] += 0.002692145083104554;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01611044660174075147) ) ) {
              result[0] += -0.0003669673833596385;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)44.50000000000000711) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09998752698574815689) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03507550000000000251) ) ) {
                    result[0] += 0.0007465058449209032;
                  } else {
                    result[0] += -0.001708526097562283;
                  }
                } else {
                  result[0] += 0.0020821386833457115;
                }
              } else {
                result[0] += 0.001896819258955072;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06413776133552721859) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02424450000000000563) ) ) {
                result[0] += 0.002435709337046302;
              } else {
                result[0] += -0.00031428694451045573;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3872449054220527542) ) ) {
                result[0] += 0.0026463865552325133;
              } else {
                result[0] += 0.0005531208556115813;
              }
            }
          } else {
            result[0] += 0.002670897443611374;
          }
        }
      }
    }
  }
}

