
#include "header.h"

void predict_unit9(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -1.4645839737933341e-05;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6249533869346735049) ) ) {
            result[0] += -1.1355269334141673e-05;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.8307299501916665e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6503673217403566076) ) ) {
                  result[0] += -1.8465821103151523e-05;
                } else {
                  result[0] += -1.8433605285209833e-05;
                }
              } else {
                result[0] += -1.8307299501916665e-05;
              }
            }
          }
        } else {
          result[0] += -8.464489154404469e-06;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -1.8307299501916665e-05;
                } else {
                  result[0] += -1.8307299501916665e-05;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -1.8013104424715242e-05;
                } else {
                  result[0] += -1.8307299501916665e-05;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -1.8307299501916665e-05;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -1.8307299501916665e-05;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -1.8307299501916665e-05;
                      } else {
                        result[0] += -1.8307299501916665e-05;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -1.8307299501916665e-05;
                      } else {
                        result[0] += -1.8307299501916665e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -1.8307299501916665e-05;
                        } else {
                          result[0] += -1.8307299501916665e-05;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -1.8307299501916665e-05;
                        } else {
                          result[0] += -1.8307299501916665e-05;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -1.8307299501916665e-05;
                    } else {
                      result[0] += -1.8307299501916665e-05;
                    }
                  }
                }
              } else {
                result[0] += -1.8307299501916665e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -1.8307299501916665e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  result[0] += -1.8307299501916665e-05;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -1.8307299501916665e-05;
                  } else {
                    result[0] += -1.8307299501916665e-05;
                  }
                }
              } else {
                result[0] += -1.8307299501916665e-05;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
            result[0] += -5.838229209360017e-05;
          } else {
            result[0] += 3.5933425240453566e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8050000000000001599) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.115000000000000005) ) ) {
            result[0] += -1.5859440343563074e-05;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1604180000000000328) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1550000000000000266) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                  result[0] += -0.00046942291586260217;
                } else {
                  result[0] += 0.0013104190649821641;
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0007535000000000001549) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.29500000000000004) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.552189803348073886e-06) ) ) {
                      result[0] += 0.000225534744483294;
                    } else {
                      result[0] += -0.000593227265402018;
                    }
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.373325504271297691e-06) ) ) {
                      result[0] += -0.00028071960671889644;
                    } else {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7572008430306190752) ) ) {
                        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.9159493641278110276) ) ) {
                          result[0] += 0.0004941756830139967;
                        } else {
                          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002055218118527550337) ) ) {
                            result[0] += -0.0026787833686628764;
                          } else {
                            result[0] += 0.00024912895951554074;
                          }
                        }
                      } else {
                        result[0] += 0.0006946129589972734;
                      }
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.555096866909547848) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01724500000000000338) ) ) {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002895500000000000504) ) ) {
                        result[0] += 0.0005156019968125037;
                      } else {
                        result[0] += -0.00021476143867653254;
                      }
                    } else {
                      result[0] += 0.0008894273917735536;
                    }
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003140007450906850701) ) ) {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002867412157011550635) ) ) {
                        result[0] += -0.0003497354640976469;
                      } else {
                        result[0] += -0.0019746381694693733;
                      }
                    } else {
                      result[0] += -3.052109653320583e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += 0.0022643251828581533;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0526089167981486569) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003882500000000000534) ) ) {
              result[0] += 0.0013139478553412535;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6647073645226131422) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5380790363330137938) ) ) {
                  result[0] += 0.0001360119884125485;
                } else {
                  result[0] += -0.005844480705935548;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7210440605025126848) ) ) {
                  result[0] += 0.001638754541814578;
                } else {
                  result[0] += 4.7689274484586526e-05;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01063150000000000206) ) ) {
              result[0] += 0.001456469443569677;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
                result[0] += 0.0024241013366035815;
              } else {
                result[0] += 0.00025928549666294904;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0013585006579332115;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021562361187840079) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
                result[0] += 0.0012920117426861864;
              } else {
                result[0] += 0.001203581626932769;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.051391296366422923) ) ) {
                result[0] += 0.0007442014670300253;
              } else {
                result[0] += -0.0013834335799695321;
              }
            }
          } else {
            result[0] += 0.0015225900920273667;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -1.4012945737521796e-05;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6249533869346735049) ) ) {
            result[0] += -1.086457150026999e-05;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.7516182008770048e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6503673217403566076) ) ) {
                  result[0] += -1.7667853380031593e-05;
                } else {
                  result[0] += -1.7637029711550668e-05;
                }
              } else {
                result[0] += -1.7516182008770048e-05;
              }
            }
          }
        } else {
          result[0] += -8.098711261280575e-06;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -1.7516182008770048e-05;
                } else {
                  result[0] += -1.7516182008770048e-05;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -1.7234700050286506e-05;
                } else {
                  result[0] += -1.7516182008770048e-05;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -1.7516182008770048e-05;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -1.7516182008770048e-05;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -1.7516182008770048e-05;
                      } else {
                        result[0] += -1.7516182008770048e-05;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -1.7516182008770048e-05;
                      } else {
                        result[0] += -1.7516182008770048e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -1.7516182008770048e-05;
                        } else {
                          result[0] += -1.7516182008770048e-05;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -1.7516182008770048e-05;
                        } else {
                          result[0] += -1.7516182008770048e-05;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -1.7516182008770048e-05;
                    } else {
                      result[0] += -1.7516182008770048e-05;
                    }
                  }
                }
              } else {
                result[0] += -1.7516182008770048e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -1.7516182008770048e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  result[0] += -1.7516182008770048e-05;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -1.7516182008770048e-05;
                  } else {
                    result[0] += -1.7516182008770048e-05;
                  }
                }
              } else {
                result[0] += -1.7516182008770048e-05;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
            result[0] += 5.723808946862588e-05;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
              result[0] += -5.5859404839780624e-05;
            } else {
              result[0] += 2.7659154850578598e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8050000000000001599) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3115605993075549196) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01724500000000000338) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2932818109908455484) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6425364825628142595) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5985432365577890712) ) ) {
                    result[0] += -3.3692688872935316e-06;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1076318469022627677) ) ) {
                      result[0] += -0.0004129694966775671;
                    } else {
                      result[0] += 0.00045610769246028635;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2350000000000000144) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2564454682769619631) ) ) {
                      result[0] += -0.0001406448133949279;
                    } else {
                      result[0] += -0.0012245745628564591;
                    }
                  } else {
                    result[0] += 1.7552423057018176e-05;
                  }
                }
              } else {
                result[0] += 0.0006637910147257902;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1604180000000000328) ) ) {
                result[0] += 0.0005790966038552205;
              } else {
                result[0] += 0.003805831776659259;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3346339054385528144) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.0650000000000000161) ) ) {
                result[0] += -0.0006102638553979993;
              } else {
                result[0] += -0.0009927781324742004;
              }
            } else {
              result[0] += 9.454078789619703e-07;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0526089167981486569) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004657500000000001049) ) ) {
              result[0] += 0.001226475463902284;
            } else {
              result[0] += 0.00015264509613336296;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              result[0] += 0.0021569156677439826;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02031150000000000316) ) ) {
                result[0] += 0.0011993681398117446;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1706267463716274191) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1301603066321575797) ) ) {
                    result[0] += -6.694042781629543e-05;
                  } else {
                    result[0] += -0.0015618494541320507;
                  }
                } else {
                  result[0] += 0.0021383507940045472;
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021562361187840079) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
            result[0] += 0.0012997954603244863;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0170586839503055511) ) ) {
                result[0] += 0.0012027790719728977;
              } else {
                result[0] += 0.0011815416226640726;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1206324332205917643) ) ) {
                result[0] += 0.0008979705712128438;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.55780239615577909) ) ) {
                  result[0] += -0.0030521021827174615;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.051391296366422923) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6077784371608041525) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3251271839107726103) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5859181088693469208) ) ) {
                          result[0] += 0.0015612633118747437;
                        } else {
                          result[0] += -0.0005259704864000826;
                        }
                      } else {
                        result[0] += -0.0021362857867898133;
                      }
                    } else {
                      result[0] += 0.0007120421199383809;
                    }
                  } else {
                    result[0] += -0.0017872300413960536;
                  }
                }
              }
            }
          }
        } else {
          result[0] += 0.0014637172527213916;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -1.3407401129355672e-05;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6249533869346735049) ) ) {
            result[0] += -1.0395078303389375e-05;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.6759251255611873e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6503673217403566076) ) ) {
                  result[0] += -1.6904368417444443e-05;
                } else {
                  result[0] += -1.6874876739153314e-05;
                }
              } else {
                result[0] += -1.6759251255611873e-05;
              }
            }
          }
        } else {
          result[0] += -7.748739811364011e-06;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -1.6759251255611873e-05;
                } else {
                  result[0] += -1.6759251255611873e-05;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -1.6489933040958396e-05;
                } else {
                  result[0] += -1.6759251255611873e-05;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -1.6759251255611873e-05;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -1.6759251255611873e-05;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -1.6759251255611873e-05;
                      } else {
                        result[0] += -1.6759251255611873e-05;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -1.6759251255611873e-05;
                      } else {
                        result[0] += -1.6759251255611873e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -1.6759251255611873e-05;
                        } else {
                          result[0] += -1.6759251255611873e-05;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -1.6759251255611873e-05;
                        } else {
                          result[0] += -1.6759251255611873e-05;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -1.6759251255611873e-05;
                    } else {
                      result[0] += -1.6759251255611873e-05;
                    }
                  }
                }
              } else {
                result[0] += -1.6759251255611873e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -1.6759251255611873e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  result[0] += -1.6759251255611873e-05;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -1.6759251255611873e-05;
                  } else {
                    result[0] += -1.6759251255611873e-05;
                  }
                }
              } else {
                result[0] += -1.6759251255611873e-05;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7519737796733669821) ) ) {
            result[0] += -3.2517819900728576e-05;
          } else {
            result[0] += 5.0447642683188714e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8050000000000001599) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1773295000000000288) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8764371766733816127) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
                    result[0] += 4.96364712843041e-05;
                  } else {
                    result[0] += -0.0006000670585506455;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6650804020351760437) ) ) {
                    result[0] += -0.0005660402596501452;
                  } else {
                    result[0] += 0.00039256244571185246;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7954292854522614364) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9050000000000001377) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002055218118527550337) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.194581012612933923) ) ) {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7519737796733669821) ) ) {
                          result[0] += -0.0003748577864148941;
                        } else {
                          result[0] += 0.0001299394996776936;
                        }
                      } else {
                        result[0] += -0.00033925114454289745;
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7536081807788946874) ) ) {
                        result[0] += 0.00014397499180756105;
                      } else {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09500000000000001499) ) ) {
                          result[0] += -0.00034009009400727574;
                        } else {
                          result[0] += -0.0004464493040015508;
                        }
                      }
                    }
                  } else {
                    result[0] += 0.0007317075143639007;
                  }
                } else {
                  result[0] += 1.003068434093423e-05;
                }
              }
            } else {
              result[0] += 0.0015112940454462265;
            }
          } else {
            result[0] += -0.0007622981887456374;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0526089167981486569) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004657500000000001049) ) ) {
              result[0] += 0.0011734755010018767;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6647073645226131422) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.52031910737473408) ) ) {
                  result[0] += 0.00010072799795703062;
                } else {
                  result[0] += -0.005206684918098278;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7210440605025126848) ) ) {
                  result[0] += 0.0015876740810107674;
                } else {
                  result[0] += -0.00019933349769490357;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1250629713251516228) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3278371989949749321) ) ) {
                result[0] += -0.0006321797699179649;
              } else {
                result[0] += 0.0013789762175845232;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6116569490452262725) ) ) {
                result[0] += -0.001657820619457327;
              } else {
                result[0] += 0.0011698510622527767;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021562361187840079) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
            result[0] += 0.0012436271037589773;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0170586839503055511) ) ) {
                result[0] += 0.0011508031066412134;
              } else {
                result[0] += 0.0011304833960549268;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3251271839107726103) ) ) {
                result[0] += 0.0008229575188611466;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6100010069597990858) ) ) {
                  result[0] += -0.002088960875463638;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.051391296366422923) ) ) {
                    result[0] += 0.0006634885590929336;
                  } else {
                    result[0] += -0.0018234807967098699;
                  }
                }
              }
            }
          }
        } else {
          result[0] += 0.0014004653064948495;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -1.2828024057933625e-05;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6249533869346735049) ) ) {
            result[0] += -9.94587342270343e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.603502992307914e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6503673217403566076) ) ) {
                  result[0] += -1.617387610402403e-05;
                } else {
                  result[0] += -1.614565885632797e-05;
                }
              } else {
                result[0] += -1.603502992307914e-05;
              }
            }
          }
        } else {
          result[0] += -7.4138917572329314e-06;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -1.603502992307914e-05;
                } else {
                  result[0] += -1.603502992307914e-05;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -1.5777349817629757e-05;
                } else {
                  result[0] += -1.603502992307914e-05;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -1.603502992307914e-05;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -1.603502992307914e-05;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -1.603502992307914e-05;
                      } else {
                        result[0] += -1.603502992307914e-05;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -1.603502992307914e-05;
                      } else {
                        result[0] += -1.603502992307914e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -1.603502992307914e-05;
                        } else {
                          result[0] += -1.603502992307914e-05;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -1.603502992307914e-05;
                        } else {
                          result[0] += -1.603502992307914e-05;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -1.603502992307914e-05;
                    } else {
                      result[0] += -1.603502992307914e-05;
                    }
                  }
                }
              } else {
                result[0] += -1.603502992307914e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -1.603502992307914e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  result[0] += -1.603502992307914e-05;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -1.603502992307914e-05;
                  } else {
                    result[0] += -1.603502992307914e-05;
                  }
                }
              } else {
                result[0] += -1.603502992307914e-05;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
            result[0] += 5.510269241486467e-05;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
              result[0] += -5.366354023070311e-05;
            } else {
              result[0] += 2.428390806138639e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.168924500000000033) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5792515097236182742) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006782232836504950395) ) ) {
                result[0] += -9.648280242193175e-06;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.576481470050251299) ) ) {
                  result[0] += 0.00024488414038005546;
                } else {
                  result[0] += 0.0018855382500165274;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1076318469022627677) ) ) {
                result[0] += -0.0006767988344596466;
              } else {
                result[0] += 4.601542369427628e-07;
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.07500000000000002498) ) ) {
              result[0] += -0.000525573281673731;
            } else {
              result[0] += 0.0021783089167398376;
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001798500000000000185) ) ) {
            result[0] += 0.001738674454771984;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05473596564878090848) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4093335132160804135) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4601878067544193374) ) ) {
                  result[0] += 0.00043397881200161814;
                } else {
                  result[0] += -0.003641037756894115;
                }
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4635963316561722558) ) ) {
                  result[0] += 0.0021446244203997423;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
                      result[0] += 0.0005023171702603858;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5628434130653267031) ) ) {
                        result[0] += -0.00482608928250841;
                      } else {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009505000000000001295) ) ) {
                          result[0] += 0.0011263627446188311;
                        } else {
                          result[0] += -0.002023214035273594;
                        }
                      }
                    }
                  } else {
                    result[0] += 0.0008637497047732361;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
                result[0] += 0.002301292446733983;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
                  result[0] += 0.001179399786177531;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1706267463716274191) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1301603066321575797) ) ) {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1711110322396684202) ) ) {
                        result[0] += 0.0009124576525966059;
                      } else {
                        result[0] += -0.0009587269865720661;
                      }
                    } else {
                      result[0] += -0.001587877542351145;
                    }
                  } else {
                    result[0] += 0.0020400850903587293;
                  }
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07316210697219156789) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
            result[0] += 0.0011898859631482594;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0175975000000000055) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02032228342586875347) ) ) {
                result[0] += 0.0010979353690362059;
              } else {
                result[0] += 0.0010398904627126622;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3251271839107726103) ) ) {
                result[0] += 0.0006945413559599334;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0240756843176193544) ) ) {
                  result[0] += -0.0014125922540073094;
                } else {
                  result[0] += 0.0001338072540412842;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
            result[0] += 0.0009164076178689607;
          } else {
            result[0] += 0.0010410067076272774;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -1.2273683739544523e-05;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6249533869346735049) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05721739154190200877) ) ) {
              result[0] += -0.00013860549278645054;
            } else {
              result[0] += 2.947355504264332e-05;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.534210453154615e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6503673217403566076) ) ) {
                  result[0] += -1.5474950720925347e-05;
                } else {
                  result[0] += -1.544795283156548e-05;
                }
              } else {
                result[0] += -1.534210453154615e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
            result[0] += -1.591007902034073e-05;
          } else {
            result[0] += 0.001974278673420858;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -1.534210453154615e-05;
                } else {
                  result[0] += -1.534210453154615e-05;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -1.5095559615043421e-05;
                } else {
                  result[0] += -1.534210453154615e-05;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -1.534210453154615e-05;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -1.534210453154615e-05;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -1.534210453154615e-05;
                      } else {
                        result[0] += -1.534210453154615e-05;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -1.534210453154615e-05;
                      } else {
                        result[0] += -1.534210453154615e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -1.534210453154615e-05;
                        } else {
                          result[0] += -1.534210453154615e-05;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -1.534210453154615e-05;
                        } else {
                          result[0] += -1.534210453154615e-05;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -1.534210453154615e-05;
                    } else {
                      result[0] += -1.534210453154615e-05;
                    }
                  }
                }
              } else {
                result[0] += -1.534210453154615e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -1.534210453154615e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -1.534210453154615e-05;
                  } else {
                    result[0] += -1.534210453154615e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -1.534210453154615e-05;
                  } else {
                    result[0] += -1.534210453154615e-05;
                  }
                }
              } else {
                result[0] += -1.534210453154615e-05;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7519737796733669821) ) ) {
            result[0] += -2.8793645203307695e-05;
          } else {
            result[0] += 4.7218251200418814e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8050000000000001599) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3115605993075549196) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2932818109908455484) ) ) {
              result[0] += 7.574493275250356e-05;
            } else {
              result[0] += 0.0006987012676423815;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3346339054385528144) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.0650000000000000161) ) ) {
                result[0] += -0.0005860572216125749;
              } else {
                result[0] += -0.0009520418223188866;
              }
            } else {
              result[0] += 2.588243683466874e-07;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0526089167981486569) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01172600000000000205) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3837516359296482826) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002399500000000000157) ) ) {
                  result[0] += 0.0016120753356764102;
                } else {
                  if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.7835979262278595092) ) ) {
                    result[0] += 0.0002684230457182976;
                  } else {
                    result[0] += -0.0020520134808188774;
                  }
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                  result[0] += 0.001110303317111817;
                } else {
                  result[0] += -0.0010105129384802044;
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3364660453768844595) ) ) {
                result[0] += 0.003090743936844401;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4093335132160804135) ) ) {
                  result[0] += -0.00189665828266734;
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3103100527046326884) ) ) {
                    result[0] += 0.001765603000628441;
                  } else {
                    result[0] += -0.00022895163887401405;
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1250629713251516228) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3278371989949749321) ) ) {
                result[0] += -0.0006994595290056029;
              } else {
                result[0] += 0.0012338396259211836;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6116569490452262725) ) ) {
                result[0] += -0.0015295207308888123;
              } else {
                result[0] += 0.001097683263388594;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021562361187840079) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
            result[0] += 0.0011384671506577736;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02405800000000000646) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0170586839503055511) ) ) {
                result[0] += 0.0010068909569160977;
              } else {
                result[0] += 0.0010060790965024642;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09956041386891252565) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01940114940222455522) ) ) {
                  result[0] += -0.0005873948175227898;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
                    result[0] += -0.00021242379006396292;
                  } else {
                    result[0] += 0.0009330092379203088;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5499504253266332965) ) ) {
                  result[0] += -0.0038625798683013515;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3251271839107726103) ) ) {
                    result[0] += 0.0008609682826226762;
                  } else {
                    result[0] += -6.228614004795596e-05;
                  }
                }
              }
            }
          }
        } else {
          result[0] += 0.0012949614215992254;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -1.1743298255290763e-05;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6249533869346735049) ) ) {
            result[0] += -7.884476663046171e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.4679122682403439e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6503673217403566076) ) ) {
                  result[0] += -1.4806228159215786e-05;
                } else {
                  result[0] += -1.4780396935783264e-05;
                }
              } else {
                result[0] += -1.4679122682403439e-05;
              }
            }
          }
        } else {
          result[0] += -6.405987708367221e-06;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -1.4679122682403439e-05;
                } else {
                  result[0] += -1.4679122682403439e-05;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -1.4443231767397287e-05;
                } else {
                  result[0] += -1.4679122682403439e-05;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -1.4679122682403439e-05;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -1.4679122682403439e-05;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -1.4679122682403439e-05;
                      } else {
                        result[0] += -1.4679122682403439e-05;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -1.4679122682403439e-05;
                      } else {
                        result[0] += -1.4679122682403439e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -1.4679122682403439e-05;
                        } else {
                          result[0] += -1.4679122682403439e-05;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -1.4679122682403439e-05;
                        } else {
                          result[0] += -1.4679122682403439e-05;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -1.4679122682403439e-05;
                    } else {
                      result[0] += -1.4679122682403439e-05;
                    }
                  }
                }
              } else {
                result[0] += -1.4679122682403439e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -1.4679122682403439e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  result[0] += -1.4679122682403439e-05;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -1.4679122682403439e-05;
                  } else {
                    result[0] += -1.4679122682403439e-05;
                  }
                }
              } else {
                result[0] += -1.4679122682403439e-05;
              }
            }
          }
        } else {
          result[0] += -2.7549378870667586e-05;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4250000000000000444) ) ) {
            result[0] += -5.202727636624431e-06;
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6782348568386622478) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03291917222295825951) ) ) {
                result[0] += -0.00024375825711364202;
              } else {
                result[0] += -0.0026091677187735046;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0005095000000000000787) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.002347679878538096e-06) ) ) {
                  result[0] += -0.0016945083471165095;
                } else {
                  result[0] += 0.0008811341822148513;
                }
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2261393214330764401) ) ) {
                  result[0] += 0.0007121340202486446;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02930104421257910194) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04258450000000000429) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6784611311055277483) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.543101476988260834) ) ) {
                          result[0] += -2.7264753670768445e-05;
                        } else {
                          result[0] += -0.0016755805262749757;
                        }
                      } else {
                        result[0] += 0.0005214579712940484;
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5386386389447237466) ) ) {
                        result[0] += 0.0010570747430419056;
                      } else {
                        result[0] += -0.0017777072156937716;
                      }
                    }
                  } else {
                    result[0] += 0.0005974606970515663;
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002023500000000000559) ) ) {
            result[0] += 0.0015667591873704612;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05473596564878090848) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4093335132160804135) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2669585275879397535) ) ) {
                  result[0] += 0.0028293056474558904;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01822956926157560595) ) ) {
                    result[0] += -0.0016838386596573776;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03409611752714010457) ) ) {
                      result[0] += 0.0012345488557663122;
                    } else {
                      result[0] += -0.0025620949576846195;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00799750000000000287) ) ) {
                  result[0] += 0.0008762781551839792;
                } else {
                  result[0] += 0.00012418133369217798;
                }
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
                result[0] += 0.0021544117370598543;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
                  result[0] += 0.0010696515611066783;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1706267463716274191) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1301603066321575797) ) ) {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1711110322396684202) ) ) {
                        result[0] += 0.000835960736005142;
                      } else {
                        result[0] += -0.0009170118138964735;
                      }
                    } else {
                      result[0] += -0.0014758703486020635;
                    }
                  } else {
                    result[0] += 0.0018986082376955113;
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0010892703109947816;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07316210697219156789) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
                result[0] += 0.0010449822252671106;
              } else {
                result[0] += 0.0009468978326165532;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3251271839107726103) ) ) {
                result[0] += 0.0006497523449809771;
              } else {
                result[0] += -6.314893556757269e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
              result[0] += 0.0008158903331206067;
            } else {
              result[0] += 0.0009557031080379688;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -1.1235832439481858e-05;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6249533869346735049) ) ) {
            result[0] += -7.543762981501341e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.4044790418549951e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6503673217403566076) ) ) {
                  result[0] += -1.4166403257511997e-05;
                } else {
                  result[0] += -1.4141688284607017e-05;
                }
              } else {
                result[0] += -1.4044790418549951e-05;
              }
            }
          }
        } else {
          result[0] += -6.129164305962025e-06;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -1.4044790418549951e-05;
                } else {
                  result[0] += -1.4044790418549951e-05;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -1.381909311125291e-05;
                } else {
                  result[0] += -1.4044790418549951e-05;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -1.4044790418549951e-05;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -1.4044790418549951e-05;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -1.4044790418549951e-05;
                      } else {
                        result[0] += -1.4044790418549951e-05;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -1.4044790418549951e-05;
                      } else {
                        result[0] += -1.4044790418549951e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -1.4044790418549951e-05;
                        } else {
                          result[0] += -1.4044790418549951e-05;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -1.4044790418549951e-05;
                        } else {
                          result[0] += -1.4044790418549951e-05;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -1.4044790418549951e-05;
                    } else {
                      result[0] += -1.4044790418549951e-05;
                    }
                  }
                }
              } else {
                result[0] += -1.4044790418549951e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -1.4044790418549951e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  result[0] += -1.4044790418549951e-05;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -1.4044790418549951e-05;
                  } else {
                    result[0] += -1.4044790418549951e-05;
                  }
                }
              } else {
                result[0] += -1.4044790418549951e-05;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
            result[0] += 5.47217932384481e-05;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
              result[0] += -5.0358113206241325e-05;
            } else {
              result[0] += 3.3099044695406275e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9650000000000000799) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4250000000000000444) ) ) {
            result[0] += -4.977900985103145e-06;
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6782348568386622478) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03291917222295825951) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001237226668511850168) ) ) {
                  result[0] += -0.0015839447868949165;
                } else {
                  result[0] += 0.0001527197936689341;
                }
              } else {
                result[0] += -0.002496417161289094;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0005095000000000000787) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.002347679878538096e-06) ) ) {
                  result[0] += -0.001621283172887702;
                } else {
                  result[0] += 0.0008430575305881814;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.009602467408789250661) ) ) {
                  result[0] += -5.222939870346713e-05;
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1711110322396684202) ) ) {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003795500000000000696) ) ) {
                      result[0] += 0.0013173139441399599;
                    } else {
                      result[0] += 0.0007073904614284146;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4992002680402010117) ) ) {
                      result[0] += -0.0016970516256225308;
                    } else {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1044543990012605922) ) ) {
                        result[0] += -0.0013224112517832762;
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5792515097236182742) ) ) {
                          result[0] += 0.0008092484256697763;
                        } else {
                          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1051257686552766607) ) ) {
                            result[0] += -0.0012479768884483147;
                          } else {
                            result[0] += 0.00015456743054328168;
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001980500000000000489) ) ) {
            result[0] += 0.0015655688352371989;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9250000000000001554) ) ) {
              result[0] += 0.004267991831813581;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0526089167981486569) ) ) {
                result[0] += 0.00011240833161003077;
              } else {
                result[0] += 0.00098779234169694;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07316210697219156789) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
            result[0] += 0.0010421994255426135;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01021941412521685209) ) ) {
                result[0] += 0.0008255254019309329;
              } else {
                result[0] += 0.000950613734793724;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1206324332205917643) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02796916660693585244) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
                    result[0] += -0.0014742865490871713;
                  } else {
                    result[0] += 0.0006815007215114079;
                  }
                } else {
                  result[0] += 0.000724652817497578;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01210357511382575101) ) ) {
                  result[0] += -0.0040401736501292865;
                } else {
                  result[0] += 1.3885757512639453e-05;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.234744531431348824) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 0.0009971140292408108;
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                result[0] += 0.0012009105714116037;
              } else {
                result[0] += 0.0005690083103257108;
              }
            }
          } else {
            result[0] += 0.0012009105714116037;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -1.0750295859277453e-05;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6249533869346735049) ) ) {
            result[0] += -7.217772637693792e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.3437869698946844e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6503673217403566076) ) ) {
                  result[0] += -1.3554227254666051e-05;
                } else {
                  result[0] += -1.353058029550093e-05;
                }
              } else {
                result[0] += -1.3437869698946844e-05;
              }
            }
          }
        } else {
          result[0] += -5.864303336144562e-06;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -1.3437869698946844e-05;
                } else {
                  result[0] += -1.3437869698946844e-05;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -1.3221925500672796e-05;
                } else {
                  result[0] += -1.3437869698946844e-05;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -1.3437869698946844e-05;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -1.3437869698946844e-05;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -1.3437869698946844e-05;
                      } else {
                        result[0] += -1.3437869698946844e-05;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -1.3437869698946844e-05;
                      } else {
                        result[0] += -1.3437869698946844e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -1.3437869698946844e-05;
                        } else {
                          result[0] += -1.3437869698946844e-05;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -1.3437869698946844e-05;
                        } else {
                          result[0] += -1.3437869698946844e-05;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -1.3437869698946844e-05;
                    } else {
                      result[0] += -1.3437869698946844e-05;
                    }
                  }
                }
              } else {
                result[0] += -1.3437869698946844e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -1.3437869698946844e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -1.3437869698946844e-05;
                  } else {
                    result[0] += -1.3437869698946844e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -1.3437869698946844e-05;
                  } else {
                    result[0] += -1.3437869698946844e-05;
                  }
                }
              } else {
                result[0] += -1.3437869698946844e-05;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7519737796733669821) ) ) {
            result[0] += -2.4182744713468637e-05;
          } else {
            result[0] += 5.565245733210433e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9650000000000000799) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8050000000000001599) ) ) {
          result[0] += 1.6196491857279866e-05;
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01085750000000000083) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006782232836504950395) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6334213184170854882) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.03588532983514210878) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4082869870603015872) ) ) {
                    result[0] += -0.0009897401897618144;
                  } else {
                    result[0] += 0.0010678942509401402;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5800027599246232457) ) ) {
                    result[0] += -0.003940010859377897;
                  } else {
                    result[0] += 0.0003018163618940986;
                  }
                }
              } else {
                result[0] += 0.00205127992080591;
              }
            } else {
              result[0] += 0.0011049455669601557;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7642320229909970175) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02616152934301940389) ) ) {
                  result[0] += 0.00016964157754752844;
                } else {
                  result[0] += 0.0030409612514579543;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04853104146385620737) ) ) {
                  result[0] += -0.0019533400234277485;
                } else {
                  result[0] += 0.0013085150449832971;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0956005000000000188) ) ) {
                result[0] += -0.0005299780804424625;
              } else {
                result[0] += 0.0014620150329342167;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1706267463716274191) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
            result[0] += 0.0009971626249589008;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03237403661108240877) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004749500000000001117) ) ) {
                  result[0] += 0.001087878438813324;
                } else {
                  result[0] += 0.0006956440164172755;
                }
              } else {
                result[0] += 0.0009327945123117338;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.07274795227358500649) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01940114940222455522) ) ) {
                  result[0] += -0.0006568648448550281;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4093335132160804135) ) ) {
                    if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4999497468491173047) ) ) {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6782348568386622478) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3044676633919599085) ) ) {
                          result[0] += 0.001149015350019233;
                        } else {
                          result[0] += -0.0012648857320641319;
                        }
                      } else {
                        result[0] += 0.001149015350019233;
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3931761618090452437) ) ) {
                        result[0] += -0.0030133125571292813;
                      } else {
                        result[0] += -0.00031194149742636804;
                      }
                    }
                  } else {
                    result[0] += 0.0008625088710838409;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5424744603768845153) ) ) {
                  result[0] += -0.0027221615433124647;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3830383354773237436) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0409003745630781082) ) ) {
                      result[0] += -4.487032793448751e-05;
                    } else {
                      result[0] += 0.0007868727517100274;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4287309711685468594) ) ) {
                      result[0] += -0.0016932594487664814;
                    } else {
                      result[0] += 0.0003168103126742874;
                    }
                  }
                }
              }
            }
          }
        } else {
          result[0] += 0.001149015350019233;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -1.0285740881636703e-05;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6249533869346735049) ) ) {
            result[0] += -6.90586938868447e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.2857175982303998e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6503673217403566076) ) ) {
                  result[0] += -1.296850535252924e-05;
                } else {
                  result[0] += -1.2945880254783563e-05;
                }
              } else {
                result[0] += -1.2857175982303998e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
            result[0] += -1.4427453315789118e-05;
          } else {
            result[0] += 0.0018897588203570343;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -1.2857175982303998e-05;
                } else {
                  result[0] += -1.2857175982303998e-05;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -1.2650563429736639e-05;
                } else {
                  result[0] += -1.2857175982303998e-05;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -1.2857175982303998e-05;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -1.2857175982303998e-05;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -1.2857175982303998e-05;
                      } else {
                        result[0] += -1.2857175982303998e-05;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -1.2857175982303998e-05;
                      } else {
                        result[0] += -1.2857175982303998e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -1.2857175982303998e-05;
                        } else {
                          result[0] += -1.2857175982303998e-05;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -1.2857175982303998e-05;
                        } else {
                          result[0] += -1.2857175982303998e-05;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -1.2857175982303998e-05;
                    } else {
                      result[0] += -1.2857175982303998e-05;
                    }
                  }
                }
              } else {
                result[0] += -1.2857175982303998e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -1.2857175982303998e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -1.2857175982303998e-05;
                  } else {
                    result[0] += -1.2857175982303998e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -1.2857175982303998e-05;
                  } else {
                    result[0] += -1.2857175982303998e-05;
                  }
                }
              } else {
                result[0] += -1.2857175982303998e-05;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7519737796733669821) ) ) {
            result[0] += -2.3137730271381156e-05;
          } else {
            result[0] += 5.324753504810423e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9650000000000000799) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4250000000000000444) ) ) {
          result[0] += -5.462692501541784e-06;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07316210697219156789) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003965500000000001142) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004867285882244350333) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6802634857286432579) ) ) {
                  result[0] += -4.3763601505654646e-05;
                } else {
                  result[0] += 0.0005153678335967227;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.249304608119721216) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8450000000000000844) ) ) {
                    result[0] += 0.0004675910702125668;
                  } else {
                    result[0] += 0.001115766155433599;
                  }
                } else {
                  result[0] += -0.0006695298249796216;
                }
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9774026691300493619) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03160800000000000415) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8764371766733816127) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8440161800932387548) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4129968667336683663) ) ) {
                        result[0] += -0.0006444510193606729;
                      } else {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002205503205843300455) ) ) {
                          result[0] += 0.001839443202286589;
                        } else {
                          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003549689586176700464) ) ) {
                            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006452000000000001137) ) ) {
                              result[0] += 0.0004967844203586279;
                            } else {
                              result[0] += -0.001970599607828889;
                            }
                          } else {
                            result[0] += 7.322094876142768e-05;
                          }
                        }
                      }
                    } else {
                      result[0] += -0.0031442026297740216;
                    }
                  } else {
                    result[0] += 0.002186022510451451;
                  }
                } else {
                  result[0] += 0.0009322439561796282;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8054659791206031372) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0683765000000000206) ) ) {
                    result[0] += -0.0002011409722238884;
                  } else {
                    result[0] += -0.0024786586570301893;
                  }
                } else {
                  result[0] += 0.000763562159926349;
                }
              }
            }
          } else {
            result[0] += 0.0007882736696682549;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1706267463716274191) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
            result[0] += 0.0009540720098720409;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01021941412521685209) ) ) {
                result[0] += 0.0007428410469987265;
              } else {
                result[0] += 0.0008859010263356769;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03350035677887956004) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1211830000000000129) ) ) {
                  result[0] += 0.00015486557579002383;
                } else {
                  result[0] += -0.0032608410219205257;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3830383354773237436) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4093335132160804135) ) ) {
                      result[0] += -0.003583716040873372;
                    } else {
                      result[0] += 0.0008794840511119073;
                    }
                  } else {
                    result[0] += 0.000781031043385179;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6100010069597990858) ) ) {
                    result[0] += -0.0017719951178994712;
                  } else {
                    result[0] += 0.0004290922117293681;
                  }
                }
              }
            }
          }
        } else {
          result[0] += 0.0010993626886204827;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -9.841260823800555e-06;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6249533869346735049) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05721739154190200877) ) ) {
              result[0] += -0.00013133886995543668;
            } else {
              result[0] += 2.9476939789028567e-05;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.2301575915183213e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6503673217403566076) ) ) {
                  result[0] += -1.2408094384036738e-05;
                } else {
                  result[0] += -1.2386446989780802e-05;
                }
              } else {
                result[0] += -1.2301575915183213e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
            result[0] += -1.3803996497459275e-05;
          } else {
            result[0] += 0.0018080962430634235;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -1.2301575915183213e-05;
                } else {
                  result[0] += -1.2301575915183213e-05;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -1.210389175779629e-05;
                } else {
                  result[0] += -1.2301575915183213e-05;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -1.2301575915183213e-05;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -1.2301575915183213e-05;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -1.2301575915183213e-05;
                      } else {
                        result[0] += -1.2301575915183213e-05;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -1.2301575915183213e-05;
                      } else {
                        result[0] += -1.2301575915183213e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -1.2301575915183213e-05;
                        } else {
                          result[0] += -1.2301575915183213e-05;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -1.2301575915183213e-05;
                        } else {
                          result[0] += -1.2301575915183213e-05;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -1.2301575915183213e-05;
                    } else {
                      result[0] += -1.2301575915183213e-05;
                    }
                  }
                }
              } else {
                result[0] += -1.2301575915183213e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -1.2301575915183213e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -1.2301575915183213e-05;
                  } else {
                    result[0] += -1.2301575915183213e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -1.2301575915183213e-05;
                  } else {
                    result[0] += -1.2301575915183213e-05;
                  }
                }
              } else {
                result[0] += -1.2301575915183213e-05;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
            result[0] += 5.364731197971203e-05;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
              result[0] += -4.8652568629418584e-05;
            } else {
              result[0] += 2.696280804134745e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1773295000000000288) ) ) {
            result[0] += 1.4002683231016558e-05;
          } else {
            result[0] += 0.0013237036326077028;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006585500000000000208) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008506177121675452882) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002023500000000000559) ) ) {
                result[0] += 0.0016792069709784616;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4093335132160804135) ) ) {
                  result[0] += -0.0010800880536256;
                } else {
                  result[0] += 0.00027472245069098646;
                }
              }
            } else {
              result[0] += 0.0010327945347104192;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1706267463716274191) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05473596564878090848) ) ) {
                  result[0] += 0.00030521982560677253;
                } else {
                  result[0] += 0.0019494247433784542;
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02159955403810970287) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5778807480402011754) ) ) {
                      result[0] += -0.0009810960250560205;
                    } else {
                      result[0] += 0.000655088456264588;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3687216492462311868) ) ) {
                      result[0] += -0.0005536747758349979;
                    } else {
                      result[0] += 0.0007712446457418421;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04477003072051350535) ) ) {
                    result[0] += 0.00028764944341223706;
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04562750000000000833) ) ) {
                      result[0] += -0.0015846032164831283;
                    } else {
                      result[0] += -0.00024324378813182158;
                    }
                  }
                }
              }
            } else {
              result[0] += 0.0011525700669946523;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2302999793555680907) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
              result[0] += 0.0009128434793259421;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03603011311338780859) ) ) {
                result[0] += 0.0009349349471524126;
              } else {
                result[0] += 0.0010518556789607966;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
              result[0] += -0.0017231958927874601;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
                result[0] += 0.000777976470043604;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3251271839107726103) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03018900000000000403) ) ) {
                    result[0] += -0.00011968315723651481;
                  } else {
                    result[0] += 0.0006838840837059972;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5834559473869348478) ) ) {
                    result[0] += -0.0029237660420438146;
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07316210697219156789) ) ) {
                      result[0] += -9.325296993118587e-05;
                    } else {
                      result[0] += 0.0005121867696515391;
                    }
                  }
                }
              }
            }
          }
        } else {
          result[0] += 0.0010518556789607966;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -9.415988183698087e-06;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6249533869346735049) ) ) {
            result[0] += -5.1015325472925734e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.1769985120005932e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6503673217403566076) ) ) {
                  result[0] += -1.1871900582061847e-05;
                } else {
                  result[0] += -1.1851188641572595e-05;
                }
              } else {
                result[0] += -1.1769985120005932e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
            result[0] += -1.3207481260281222e-05;
          } else {
            result[0] += 0.0017299625692777083;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -1.1769985120005932e-05;
                } else {
                  result[0] += -1.1769985120005932e-05;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -1.158084353302981e-05;
                } else {
                  result[0] += -1.1769985120005932e-05;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -1.1769985120005932e-05;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -1.1769985120005932e-05;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -1.1769985120005932e-05;
                      } else {
                        result[0] += -1.1769985120005932e-05;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -1.1769985120005932e-05;
                      } else {
                        result[0] += -1.1769985120005932e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -1.1769985120005932e-05;
                        } else {
                          result[0] += -1.1769985120005932e-05;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -1.1769985120005932e-05;
                        } else {
                          result[0] += -1.1769985120005932e-05;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -1.1769985120005932e-05;
                    } else {
                      result[0] += -1.1769985120005932e-05;
                    }
                  }
                }
              } else {
                result[0] += -1.1769985120005932e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -1.1769985120005932e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -1.1769985120005932e-05;
                  } else {
                    result[0] += -1.1769985120005932e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -1.1769985120005932e-05;
                  } else {
                    result[0] += -1.1769985120005932e-05;
                  }
                }
              } else {
                result[0] += -1.1769985120005932e-05;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7519737796733669821) ) ) {
            result[0] += -2.0035439772845263e-05;
          } else {
            result[0] += 4.978138726684824e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2150000000000000244) ) ) {
            result[0] += -1.2591442159062878e-05;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.966590843157139501) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6959555468592965033) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6915080527790725684) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1604180000000000328) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3115605993075549196) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3998546246231156065) ) ) {
                        result[0] += -0.00021419014224013317;
                      } else {
                        result[0] += 0.0002403263630345539;
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6468042868844222637) ) ) {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03795623917694670307) ) ) {
                          result[0] += -0.00033059373848445616;
                        } else {
                          result[0] += -0.0015031327976956427;
                        }
                      } else {
                        result[0] += 0.0002488669950962048;
                      }
                    }
                  } else {
                    result[0] += 0.003539516059240376;
                  }
                } else {
                  result[0] += -0.0016873549346983572;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7210440605025126848) ) ) {
                  result[0] += 0.0014863476668827572;
                } else {
                  result[0] += 0.0002817916898744216;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.039722088301102687) ) ) {
                result[0] += -0.0008278739657589927;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
                  result[0] += 0.0005095879173018627;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7894192122613066243) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
                      result[0] += -0.00024534146533104734;
                    } else {
                      result[0] += -0.0034828009996762774;
                    }
                  } else {
                    result[0] += -0.00012958799664477934;
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002023500000000000559) ) ) {
            result[0] += 0.001283528367759712;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0526089167981486569) ) ) {
              result[0] += 0.00018131395089300217;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
                result[0] += 0.0017822448332777227;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
                  result[0] += 0.0008989323495169221;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1706267463716274191) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06217080128912850362) ) ) {
                      result[0] += 0.0005778895845257176;
                    } else {
                      result[0] += -0.0013160409485330632;
                    }
                  } else {
                    result[0] += 0.001617702083877778;
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.000873396566638247;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021562361187840079) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02577363736079425413) ) ) {
                result[0] += 0.0007759232878443654;
              } else {
                result[0] += 0.0008229627154198567;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9186477097784532253) ) ) {
                result[0] += 0.0004965782980216553;
              } else {
                result[0] += -0.0006974964955312803;
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3057749246864051029) ) ) {
              result[0] += 0.0006987984410089867;
            } else {
              result[0] += 0.001006401600504037;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -9.009092946822442e-06;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6249533869346735049) ) ) {
            result[0] += -4.88107886216017e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.126136607864829e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6503673217403566076) ) ) {
                  result[0] += -1.1358877444685234e-05;
                } else {
                  result[0] += -1.1339060533986494e-05;
                }
              } else {
                result[0] += -1.126136607864829e-05;
              }
            }
          }
        } else {
          result[0] += -3.820177919395343e-06;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -1.126136607864829e-05;
                } else {
                  result[0] += -1.126136607864829e-05;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -1.108039791004677e-05;
                } else {
                  result[0] += -1.126136607864829e-05;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -1.126136607864829e-05;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -1.126136607864829e-05;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -1.126136607864829e-05;
                      } else {
                        result[0] += -1.126136607864829e-05;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -1.126136607864829e-05;
                      } else {
                        result[0] += -1.126136607864829e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -1.126136607864829e-05;
                        } else {
                          result[0] += -1.126136607864829e-05;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -1.126136607864829e-05;
                        } else {
                          result[0] += -1.126136607864829e-05;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -1.126136607864829e-05;
                    } else {
                      result[0] += -1.126136607864829e-05;
                    }
                  }
                }
              } else {
                result[0] += -1.126136607864829e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -1.126136607864829e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -1.126136607864829e-05;
                  } else {
                    result[0] += -1.126136607864829e-05;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -1.126136607864829e-05;
                  } else {
                    result[0] += -1.126136607864829e-05;
                  }
                }
              } else {
                result[0] += -1.126136607864829e-05;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7519737796733669821) ) ) {
            result[0] += -1.9169643761504325e-05;
          } else {
            result[0] += 4.763017286759801e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
          result[0] += 1.87355626680166e-05;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006585500000000000208) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008506177121675452882) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002023500000000000559) ) ) {
                result[0] += 0.001551177615595161;
              } else {
                result[0] += -0.0002962886194568973;
              }
            } else {
              result[0] += 0.0009542273127486111;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1960530738562874242) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
                result[0] += 0.0018949544545070816;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4093335132160804135) ) ) {
                  if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4999497468491173047) ) ) {
                    result[0] += 0.0003062437422449563;
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02563650000000000304) ) ) {
                      result[0] += -0.0017844886357483802;
                    } else {
                      result[0] += -0.004547334071363865;
                    }
                  }
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1828583041203602211) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05585367585607920599) ) ) {
                      result[0] += 0.0006120961934386054;
                    } else {
                      result[0] += 0.0015484662757866933;
                    }
                  } else {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1044543990012605922) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.497782690150753826) ) ) {
                        result[0] += -0.0004603953067094713;
                      } else {
                        result[0] += -0.003926547056034026;
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5139155612311558929) ) ) {
                        if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.02125964230697484705) ) ) {
                          result[0] += -6.66712254720926e-05;
                        } else {
                          result[0] += -0.004371121533194141;
                        }
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.03945373639888280493) ) ) {
                          result[0] += 0.001253678004285649;
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5628434130653267031) ) ) {
                            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.07274795227358500649) ) ) {
                              result[0] += 0.0017007668912843424;
                            } else {
                              result[0] += -0.0044038082079663025;
                            }
                          } else {
                            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
                              result[0] += 0.0007015860087278212;
                            } else {
                              result[0] += 7.059288134867364e-05;
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            } else {
              result[0] += 0.0014049071972807986;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2302999793555680907) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
              result[0] += 0.0008356542823516245;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03603011311338780859) ) ) {
                result[0] += 0.0008589705160315428;
              } else {
                result[0] += 0.0009756940956557128;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
              result[0] += -0.0016728113901179615;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
                result[0] += 0.0007108274467301007;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3251271839107726103) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03018900000000000403) ) ) {
                    result[0] += -0.00013597001259308054;
                  } else {
                    result[0] += 0.0006241339095934464;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5834559473869348478) ) ) {
                    result[0] += -0.002826744166380196;
                  } else {
                    result[0] += 0.0002344137075340298;
                  }
                }
              }
            }
          }
        } else {
          result[0] += 0.0009629117394676709;
        }
      }
    }
  }
}

