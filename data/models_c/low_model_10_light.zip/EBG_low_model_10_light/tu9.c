
#include "header.h"

void predict_unit9(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -2.6369237413480637e-05;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
            result[0] += -1.891132723331333e-05;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.51589832179741e-05;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.652905739716803768) ) ) {
                result[0] += -3.51589832179741e-05;
              } else {
                result[0] += -3.51589832179741e-05;
              }
            }
          }
        } else {
          result[0] += -3.593078382336644e-05;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                  result[0] += -3.51589832179741e-05;
                } else {
                  result[0] += -3.51589832179741e-05;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += 3.6394980685735796e-06;
                } else {
                  result[0] += -3.5340598631203226e-05;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06983950000000001268) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                        result[0] += -3.51589832179741e-05;
                      } else {
                        result[0] += -3.51589832179741e-05;
                      }
                    } else {
                      result[0] += -3.51589832179741e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                          result[0] += -3.51589832179741e-05;
                        } else {
                          result[0] += -3.51589832179741e-05;
                        }
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                          result[0] += -3.51589832179741e-05;
                        } else {
                          result[0] += -3.51589832179741e-05;
                        }
                      }
                    } else {
                      result[0] += -3.51589832179741e-05;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.483243480726212482) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                      result[0] += -3.51589832179741e-05;
                    } else {
                      result[0] += -3.51589832179741e-05;
                    }
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.598708736933611707) ) ) {
                      result[0] += -3.51589832179741e-05;
                    } else {
                      result[0] += -3.51589832179741e-05;
                    }
                  }
                }
              } else {
                result[0] += -3.51589832179741e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
              result[0] += -3.51589832179741e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                  result[0] += -3.51589832179741e-05;
                } else {
                  result[0] += -3.51589832179741e-05;
                }
              } else {
                result[0] += -3.51589832179741e-05;
              }
            }
          }
        } else {
          result[0] += -6.700475385622211e-05;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9650000000000000799) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4450000000000000622) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3477174365476807805) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3050000000000000488) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001600500000000000143) ) ) {
                result[0] += -0.0003595727530480319;
              } else {
                result[0] += 0.0018607379769782885;
              }
            } else {
              result[0] += 0.0020914979185856753;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.07183500000000002383) ) ) {
              result[0] += -6.846445228360365e-05;
            } else {
              result[0] += 0.0008170684072373143;
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4100284358542713448) ) ) {
            if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1701831610694422292) ) ) {
              result[0] += -0.00012829033523933155;
            } else {
              result[0] += -0.006001874227940346;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1001961271985990637) ) ) {
              result[0] += 0.001470190134653656;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5917931336432161737) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7750000000000001332) ) ) {
                  result[0] += 0.000878808842218274;
                } else {
                  result[0] += -0.002434905284245916;
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2273413669989351737) ) ) {
                  result[0] += 0.003374683850815592;
                } else {
                  result[0] += 0.0008532512516692093;
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.003987061616222399;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9850000000000000977) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007045500000000000547) ) ) {
              result[0] += 0.004640509232899178;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6137798012311558304) ) ) {
                result[0] += 0.00042112206129683844;
              } else {
                result[0] += 0.002947478209851367;
              }
            }
          } else {
            result[0] += 0.002666167531408242;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -2.4254894781704292e-05;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
            result[0] += -1.7394976010641078e-05;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.2339859708939045e-05;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.652905739716803768) ) ) {
                result[0] += -3.2339859708939045e-05;
              } else {
                result[0] += -3.2339859708939045e-05;
              }
            }
          }
        } else {
          result[0] += -3.304977566830914e-05;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                  result[0] += -3.2339859708939045e-05;
                } else {
                  result[0] += -3.2339859708939045e-05;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += 3.3476752219743284e-06;
                } else {
                  result[0] += -3.250691280454189e-05;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06983950000000001268) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                        result[0] += -3.2339859708939045e-05;
                      } else {
                        result[0] += -3.2339859708939045e-05;
                      }
                    } else {
                      result[0] += -3.2339859708939045e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                          result[0] += -3.2339859708939045e-05;
                        } else {
                          result[0] += -3.2339859708939045e-05;
                        }
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                          result[0] += -3.2339859708939045e-05;
                        } else {
                          result[0] += -3.2339859708939045e-05;
                        }
                      }
                    } else {
                      result[0] += -3.2339859708939045e-05;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.483243480726212482) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                      result[0] += -3.2339859708939045e-05;
                    } else {
                      result[0] += -3.2339859708939045e-05;
                    }
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.598708736933611707) ) ) {
                      result[0] += -3.2339859708939045e-05;
                    } else {
                      result[0] += -3.2339859708939045e-05;
                    }
                  }
                }
              } else {
                result[0] += -3.2339859708939045e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
              result[0] += -3.2339859708939045e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                  result[0] += -3.2339859708939045e-05;
                } else {
                  result[0] += -3.2339859708939045e-05;
                }
              } else {
                result[0] += -3.2339859708939045e-05;
              }
            }
          }
        } else {
          result[0] += -6.163216740677624e-05;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9550000000000000711) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.7650000000000001243) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.115000000000000005) ) ) {
            result[0] += -5.747725330206625e-05;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08494950000000001111) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.09500000000000001499) ) ) {
                result[0] += 0.001499244420978936;
              } else {
                result[0] += 0.00013364278637258443;
              }
            } else {
              result[0] += 0.0025087892500741684;
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006417500000000000461) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
              result[0] += -0.0022215005397051243;
            } else {
              result[0] += 0.0022053024751219506;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
              result[0] += 0.003643202577732422;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.145614105386054682) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1113440000000000124) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6711668573618091438) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.527988611169282529) ) ) {
                      result[0] += -0.00032710168366608994;
                    } else {
                      result[0] += -0.009583483393025756;
                    }
                  } else {
                    result[0] += 0.002881335403476425;
                  }
                } else {
                  result[0] += 0.004005599477189357;
                }
              } else {
                result[0] += -0.0032367138630908124;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0195175000000000036) ) ) {
            result[0] += 0.0035239223064094513;
          } else {
            result[0] += 0.001212603559219486;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.075834742120705068) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
              result[0] += 0.003667370370756638;
            } else {
              result[0] += 0.002452388437734781;
            }
          } else {
            result[0] += -7.948319654126153e-05;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -2.23100847266365e-05;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
            result[0] += -1.600020911688094e-05;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.9746779635515387e-05;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.652905739716803768) ) ) {
                result[0] += -2.9746779635515387e-05;
              } else {
                result[0] += -2.9746779635515387e-05;
              }
            }
          }
        } else {
          result[0] += -3.0399772993964615e-05;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                  result[0] += -2.9746779635515387e-05;
                } else {
                  result[0] += -2.9746779635515387e-05;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += 3.079251363969868e-06;
                } else {
                  result[0] += -2.9900438051694448e-05;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06983950000000001268) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                        result[0] += -2.9746779635515387e-05;
                      } else {
                        result[0] += -2.9746779635515387e-05;
                      }
                    } else {
                      result[0] += -2.9746779635515387e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                          result[0] += -2.9746779635515387e-05;
                        } else {
                          result[0] += -2.9746779635515387e-05;
                        }
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                          result[0] += -2.9746779635515387e-05;
                        } else {
                          result[0] += -2.9746779635515387e-05;
                        }
                      }
                    } else {
                      result[0] += -2.9746779635515387e-05;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.483243480726212482) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                      result[0] += -2.9746779635515387e-05;
                    } else {
                      result[0] += -2.9746779635515387e-05;
                    }
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.598708736933611707) ) ) {
                      result[0] += -2.9746779635515387e-05;
                    } else {
                      result[0] += -2.9746779635515387e-05;
                    }
                  }
                }
              } else {
                result[0] += -2.9746779635515387e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
              result[0] += -2.9746779635515387e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                  result[0] += -2.9746779635515387e-05;
                } else {
                  result[0] += -2.9746779635515387e-05;
                }
              } else {
                result[0] += -2.9746779635515387e-05;
              }
            }
          }
        } else {
          result[0] += -5.669036658813362e-05;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9550000000000000711) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.7650000000000001243) ) ) {
          result[0] += 3.8023328763637426e-05;
        } else {
          result[0] += 0.0014130522395674717;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09277402050424696234) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
            result[0] += 0.0033733126625333505;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4100284358542713448) ) ) {
              if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4314418144595498217) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1113440000000000124) ) ) {
                  result[0] += 0.0021555679810147904;
                } else {
                  result[0] += 0.0038203728835334927;
                }
              } else {
                result[0] += -0.002743439757169526;
              }
            } else {
              result[0] += 0.0030185519653824345;
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6050666370100503677) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3230417339964383738) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1202115000000000128) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02310400000000000301) ) ) {
                  result[0] += 0.0022841514605984746;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5876205025125629255) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5499504253266332965) ) ) {
                      result[0] += -0.002186706178251081;
                    } else {
                      result[0] += 0.0030680245285097567;
                    }
                  } else {
                    result[0] += -0.0031348483666058394;
                  }
                }
              } else {
                result[0] += 0.0030575715334766455;
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5750608109547740154) ) ) {
                result[0] += -0.008413163487247402;
              } else {
                result[0] += 0.0002511935407182841;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.236061396638114873) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02361250000000000501) ) ) {
                result[0] += 0.0030575715334766455;
              } else {
                result[0] += 0.0022557506153255873;
              }
            } else {
              result[0] += -0.0011136561218250316;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -2.0521213758682242e-05;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
            result[0] += -1.4717277656911534e-05;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.736161834490971e-05;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.652905739716803768) ) ) {
                result[0] += -2.736161834490971e-05;
              } else {
                result[0] += -2.736161834490971e-05;
              }
            }
          }
        } else {
          result[0] += -2.7962253280004243e-05;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                  result[0] += -2.736161834490971e-05;
                } else {
                  result[0] += -2.736161834490971e-05;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += 2.832350312919113e-06;
                } else {
                  result[0] += -2.7502956096104636e-05;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06983950000000001268) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                        result[0] += -2.736161834490971e-05;
                      } else {
                        result[0] += -2.736161834490971e-05;
                      }
                    } else {
                      result[0] += -2.736161834490971e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                          result[0] += -2.736161834490971e-05;
                        } else {
                          result[0] += -2.736161834490971e-05;
                        }
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                          result[0] += -2.736161834490971e-05;
                        } else {
                          result[0] += -2.736161834490971e-05;
                        }
                      }
                    } else {
                      result[0] += -2.736161834490971e-05;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.483243480726212482) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                      result[0] += -2.736161834490971e-05;
                    } else {
                      result[0] += -2.736161834490971e-05;
                    }
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.598708736933611707) ) ) {
                      result[0] += -2.736161834490971e-05;
                    } else {
                      result[0] += -2.736161834490971e-05;
                    }
                  }
                }
              } else {
                result[0] += -2.736161834490971e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
              result[0] += -2.736161834490971e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                  result[0] += -2.736161834490971e-05;
                } else {
                  result[0] += -2.736161834490971e-05;
                }
              } else {
                result[0] += -2.736161834490971e-05;
              }
            }
          }
        } else {
          result[0] += -5.214481007435138e-05;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.7650000000000001243) ) ) {
          result[0] += 3.497453581803995e-05;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006417500000000000461) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
              result[0] += -0.0016459419230515108;
            } else {
              result[0] += 0.0021502121592581443;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08228200000000000791) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
                result[0] += 0.0027999971172232114;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01173150000000000061) ) ) {
                  result[0] += 0.0014123091237793848;
                } else {
                  result[0] += -0.0015946353926288655;
                }
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7593447680904524821) ) ) {
                result[0] += 0.004302029102755958;
              } else {
                result[0] += -0.003294148452923877;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0031028331389556653;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3230417339964383738) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3597967273366834418) ) ) {
              result[0] += 0.0010686850311910775;
            } else {
              result[0] += 0.0027153548575072333;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5750608109547740154) ) ) {
              result[0] += -0.008059301270056309;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.316725863161028132) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6665876335678392328) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5508018452917812224) ) ) {
                    result[0] += 0.002751245752026197;
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08494950000000001111) ) ) {
                      result[0] += -0.010472867319829863;
                    } else {
                      result[0] += 0.002074879639883567;
                    }
                  }
                } else {
                  result[0] += 0.002812408818242783;
                }
              } else {
                result[0] += -0.001334601285126448;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -1.8875778343716723e-05;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
            result[0] += -1.3537214423160623e-05;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.5167704458288952e-05;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.652905739716803768) ) ) {
                result[0] += -2.5167704458288952e-05;
              } else {
                result[0] += -2.5167704458288952e-05;
              }
            }
          }
        } else {
          result[0] += -2.572017918194123e-05;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                  result[0] += -2.5167704458288952e-05;
                } else {
                  result[0] += -2.5167704458288952e-05;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += 2.6052463234928733e-06;
                } else {
                  result[0] += -2.5297709442132853e-05;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06983950000000001268) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                        result[0] += -2.5167704458288952e-05;
                      } else {
                        result[0] += -2.5167704458288952e-05;
                      }
                    } else {
                      result[0] += -2.5167704458288952e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                          result[0] += -2.5167704458288952e-05;
                        } else {
                          result[0] += -2.5167704458288952e-05;
                        }
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                          result[0] += -2.5167704458288952e-05;
                        } else {
                          result[0] += -2.5167704458288952e-05;
                        }
                      }
                    } else {
                      result[0] += -2.5167704458288952e-05;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.483243480726212482) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                      result[0] += -2.5167704458288952e-05;
                    } else {
                      result[0] += -2.5167704458288952e-05;
                    }
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.598708736933611707) ) ) {
                      result[0] += -2.5167704458288952e-05;
                    } else {
                      result[0] += -2.5167704458288952e-05;
                    }
                  }
                }
              } else {
                result[0] += -2.5167704458288952e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
              result[0] += -2.5167704458288952e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                  result[0] += -2.5167704458288952e-05;
                } else {
                  result[0] += -2.5167704458288952e-05;
                }
              } else {
                result[0] += -2.5167704458288952e-05;
              }
            }
          }
        } else {
          result[0] += -4.796372613789612e-05;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9850000000000000977) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8550000000000000933) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03945373639888280493) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0195175000000000036) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5673593061306533292) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5493276582412061071) ) ) {
                  result[0] += 4.658780078595101e-05;
                } else {
                  result[0] += 0.0013430656537393663;
                }
              } else {
                result[0] += -0.0011182727181256044;
              }
            } else {
              result[0] += 0.0018871378596172724;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5917931336432161737) ) ) {
              result[0] += -0.00037086100861610376;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2659201053550500626) ) ) {
                result[0] += 0.0007582087417652419;
              } else {
                result[0] += -7.755485344793692e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006417500000000000461) ) ) {
            result[0] += 0.0025470172074515923;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
              result[0] += 0.003610402004105288;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6690536170100503943) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.527988611169282529) ) ) {
                  result[0] += 0.0001015496404607473;
                } else {
                  result[0] += -0.008422748259510407;
                }
              } else {
                result[0] += 0.0023099744993734833;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.8975410753335467673) ) ) {
          result[0] += 0.0028540412500545355;
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3597967273366834418) ) ) {
            result[0] += 0.00011086277351164392;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09277402050424696234) ) ) {
              result[0] += 0.0025587948835917138;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5613540176884422861) ) ) {
                result[0] += -0.0009043621223814087;
              } else {
                result[0] += 0.0018825139978187915;
              }
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -1.7362277508092312e-05;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.803731059838205808) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6193272217839197458) ) ) {
            result[0] += -1.2451771218202672e-05;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.3149703344123145e-05;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.652905739716803768) ) ) {
                result[0] += -2.3149703344123145e-05;
              } else {
                result[0] += -2.3149703344123145e-05;
              }
            }
          }
        } else {
          result[0] += -2.3657879446511512e-05;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.932576353658176371) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7605905273618090989) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.300000000000000843e-05) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                  result[0] += -2.3149703344123145e-05;
                } else {
                  result[0] += -2.3149703344123145e-05;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
                  result[0] += 2.3963520243645326e-06;
                } else {
                  result[0] += -2.326928424647488e-05;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06983950000000001268) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8274453021105528938) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.045304313006248043) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9494413002849252381) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7640286906783920751) ) ) {
                        result[0] += -2.3149703344123145e-05;
                      } else {
                        result[0] += -2.3149703344123145e-05;
                      }
                    } else {
                      result[0] += -2.3149703344123145e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8011796369346734226) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
                          result[0] += -2.3149703344123145e-05;
                        } else {
                          result[0] += -2.3149703344123145e-05;
                        }
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8145641537437187107) ) ) {
                          result[0] += -2.3149703344123145e-05;
                        } else {
                          result[0] += -2.3149703344123145e-05;
                        }
                      }
                    } else {
                      result[0] += -2.3149703344123145e-05;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.483243480726212482) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                      result[0] += -2.3149703344123145e-05;
                    } else {
                      result[0] += -2.3149703344123145e-05;
                    }
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.598708736933611707) ) ) {
                      result[0] += -2.3149703344123145e-05;
                    } else {
                      result[0] += -2.3149703344123145e-05;
                    }
                  }
                }
              } else {
                result[0] += -2.3149703344123145e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.820923736457286557) ) ) {
              result[0] += -2.3149703344123145e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9189305784170854752) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8987185122361810441) ) ) {
                  result[0] += -2.3149703344123145e-05;
                } else {
                  result[0] += -2.3149703344123145e-05;
                }
              } else {
                result[0] += -2.3149703344123145e-05;
              }
            }
          }
        } else {
          result[0] += -4.411789057723814e-05;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9650000000000000799) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4650000000000000244) ) ) {
          result[0] += -3.47660386922135e-05;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1196770600947829194) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4129968667336683663) ) ) {
              result[0] += -0.0001950633660877999;
            } else {
              result[0] += 0.0011402023865928995;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5917931336432161737) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3316832053466863273) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5903148145979900674) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8950000000000001288) ) ) {
                    result[0] += -9.609699811058786e-05;
                  } else {
                    result[0] += -0.004621380777843924;
                  }
                } else {
                  result[0] += -0.00398095098143768;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5750608109547740154) ) ) {
                  result[0] += -0.006573791887434397;
                } else {
                  result[0] += 0.0008855557927075985;
                }
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2273413669989351737) ) ) {
                result[0] += 0.002161994544952451;
              } else {
                result[0] += 0.00029545981495681414;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0026251980342566683;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.075834742120705068) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01731250000000000497) ) ) {
              result[0] += 0.0022924620954178627;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.107195500000000013) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4100284358542713448) ) ) {
                  if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4188836135812591954) ) ) {
                    result[0] += 0.0005977047816726246;
                  } else {
                    result[0] += -0.0035989379728620235;
                  }
                } else {
                  result[0] += 0.0016502371525246812;
                }
              } else {
                result[0] += 0.0023536251616344487;
              }
            }
          } else {
            result[0] += -0.0004306666757253378;
          }
        }
      }
    }
  }
}

