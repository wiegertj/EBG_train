
#include "header.h"

void predict_unit12(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -1.9572776156610098e-06;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -2.3530808549875267e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.4465969967904864e-06;
            } else {
              result[0] += -2.4465969967904864e-06;
            }
          }
        } else {
          result[0] += -7.2962580344711205e-06;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -2.4465969967904864e-06;
                } else {
                  result[0] += -2.4465969967904864e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -2.4465969967904864e-06;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -2.4465969967904864e-06;
                    } else {
                      result[0] += -2.4465969967904864e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -2.4465969967904864e-06;
                    } else {
                      result[0] += -2.4465969967904864e-06;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -2.4465969967904864e-06;
              } else {
                result[0] += -2.4465969967904864e-06;
              }
            }
          } else {
            result[0] += -2.856495961008911e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -2.4465969967904864e-06;
              } else {
                result[0] += -2.4465969967904864e-06;
              }
            } else {
              result[0] += -2.4465969967904864e-06;
            }
          } else {
            result[0] += -2.4465969967904864e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2655998599748743971) ) ) {
            result[0] += 0.0007266316465036607;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
              result[0] += -9.548869027766647e-05;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)37.50000000000000711) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
                  result[0] += -0.0012117487240452245;
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4629970383791919275) ) ) {
                    result[0] += 0.0006514460756707845;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4218023131278703652) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2397171522356433271) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1913179023522538491) ) ) {
                          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3932416254517326903) ) ) {
                            result[0] += -0.0005789899432699391;
                          } else {
                            result[0] += -7.736654449685184e-05;
                          }
                        } else {
                          result[0] += 0.0007078224001519508;
                        }
                      } else {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6350000000000001199) ) ) {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2994824114585931674) ) ) {
                            result[0] += -0.0008593658791539523;
                          } else {
                            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5971694628894473889) ) ) {
                              result[0] += 0.0004234218602335533;
                            } else {
                              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6249533869346735049) ) ) {
                                result[0] += -0.00047602030865820675;
                              } else {
                                result[0] += -0.00011543868891408648;
                              }
                            }
                          }
                        } else {
                          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02620539606947270075) ) ) {
                            result[0] += 0.0010165697439003445;
                          } else {
                            result[0] += -0.0012045656515706318;
                          }
                        }
                      }
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9808239647505231362) ) ) {
                        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6067453057537689487) ) ) {
                          result[0] += -0.00037472673927143143;
                        } else {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.029997717272797003e-05) ) ) {
                            result[0] += -0.00021518740107126811;
                          } else {
                            result[0] += 0.00019498191051555512;
                          }
                        }
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.06536400211476856) ) ) {
                          result[0] += -0.0006452914436665153;
                        } else {
                          result[0] += -2.3766887051387254e-06;
                        }
                      }
                    }
                  }
                }
              } else {
                result[0] += 4.292927637904767e-05;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)13.50000000000000178) ) ) {
            result[0] += -7.02934570321215e-05;
          } else {
            result[0] += 0.0005174924397013698;
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.00018193712176168265;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1185261981962025396) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)201.5000000000000284) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)14.50000000000000178) ) ) {
                  result[0] += -7.66609158124122e-05;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01439950000000000084) ) ) {
                    result[0] += 0.0002142190147992348;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08780304645514057371) ) ) {
                      result[0] += -8.453920408203113e-06;
                    } else {
                      result[0] += 0.00019247801336934507;
                    }
                  }
                }
              } else {
                result[0] += 0.00020735655262879815;
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4983996163819096048) ) ) {
                result[0] += -0.0011964948803208778;
              } else {
                result[0] += 0.00013232968554469392;
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)48.50000000000000711) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3801755927260667134) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1207797749301366269) ) ) {
                  result[0] += 0.00019426999911844377;
                } else {
                  result[0] += 1.8863381271126848e-05;
                }
              } else {
                result[0] += 0.00017743272673133236;
              }
            } else {
              result[0] += 0.00019090965493019516;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -1.8742082202521862e-06;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -2.2532130577942256e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.3427602534965523e-06;
            } else {
              result[0] += -2.3427602534965523e-06;
            }
          }
        } else {
          result[0] += -6.986595399584571e-06;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -2.3427602534965523e-06;
                } else {
                  result[0] += -2.3427602534965523e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -2.3427602534965523e-06;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -2.3427602534965523e-06;
                    } else {
                      result[0] += -2.3427602534965523e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -2.3427602534965523e-06;
                    } else {
                      result[0] += -2.3427602534965523e-06;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -2.3427602534965523e-06;
              } else {
                result[0] += -2.3427602534965523e-06;
              }
            }
          } else {
            result[0] += -2.7352625751212627e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -2.3427602534965523e-06;
              } else {
                result[0] += -2.3427602534965523e-06;
              }
            } else {
              result[0] += -2.3427602534965523e-06;
            }
          } else {
            result[0] += -2.3427602534965523e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05403737693237045669) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2655998599748743971) ) ) {
            result[0] += 0.0007905999350791668;
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)115.5000000000000142) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4330073079623726895) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4014600540350321545) ) ) {
                  result[0] += -5.045234659697644e-05;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.004621314935084650834) ) ) {
                    result[0] += 3.45665914979015e-06;
                  } else {
                    result[0] += -0.0011833638077458175;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5380790363330137938) ) ) {
                  result[0] += 0.0003427912276179157;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9450000000000000622) ) ) {
                    result[0] += 8.473519656351487e-06;
                  } else {
                    result[0] += -0.0010946086948995647;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.05368089823796016319) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02447420998234165271) ) ) {
                  result[0] += 0.00010551524197554703;
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.08974471890433978472) ) ) {
                    result[0] += 0.0011316642119976494;
                  } else {
                    result[0] += 0.000565572534775606;
                  }
                }
              } else {
                result[0] += -6.9585498901920206e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.213351496714494937) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)3.500000000000000444) ) ) {
              result[0] += -0.0009632921950295954;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7974125133417085953) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.966590843157139501) ) ) {
                  result[0] += 0.0003531091468808006;
                } else {
                  result[0] += -0.0004175548475537211;
                }
              } else {
                result[0] += 0.0011973027755123825;
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006979000000000000828) ) ) {
              result[0] += -1.2821228576106596e-05;
            } else {
              result[0] += -0.0027309888605100744;
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0001742154748240002;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1185261981962025396) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)201.5000000000000284) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01112050000000000191) ) ) {
                  result[0] += 0.00018903143827871078;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
                    result[0] += -0.00035880372901357454;
                  } else {
                    result[0] += 0.00018422250746704465;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
                  result[0] += 0.0004885744202159282;
                } else {
                  result[0] += 0.0001964352832268051;
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4983996163819096048) ) ) {
                result[0] += -0.0011457140889182189;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3830383354773237436) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3111804673197418603) ) ) {
                    result[0] += 0.00018279805303784904;
                  } else {
                    result[0] += 0.00020450130602756402;
                  }
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6586934769095478259) ) ) {
                    result[0] += -0.00025118082219704015;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9079021320180030719) ) ) {
                      result[0] += 0.0002472746538258509;
                    } else {
                      result[0] += -0.0003990494785316184;
                    }
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)48.50000000000000711) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3801755927260667134) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1207797749301366269) ) ) {
                  result[0] += 0.00018602492890269705;
                } else {
                  result[0] += 1.8062794954184204e-05;
                }
              } else {
                result[0] += 0.00016990225214899945;
              }
            } else {
              result[0] += 0.00018280720207125524;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -1.794664397505312e-06;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -2.1575837791775826e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.2433304759889875e-06;
            } else {
              result[0] += -2.2433304759889875e-06;
            }
          }
        } else {
          result[0] += -6.6900752477341025e-06;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -2.2433304759889875e-06;
                } else {
                  result[0] += -2.2433304759889875e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -2.2433304759889875e-06;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -2.2433304759889875e-06;
                    } else {
                      result[0] += -2.2433304759889875e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -2.2433304759889875e-06;
                    } else {
                      result[0] += -2.2433304759889875e-06;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -2.2433304759889875e-06;
              } else {
                result[0] += -2.2433304759889875e-06;
              }
            }
          } else {
            result[0] += -2.6191744910489803e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -2.2433304759889875e-06;
              } else {
                result[0] += -2.2433304759889875e-06;
              }
            } else {
              result[0] += -2.2433304759889875e-06;
            }
          } else {
            result[0] += -2.2433304759889875e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2655998599748743971) ) ) {
          result[0] += 0.0006432181884645389;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05403737693237045669) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)115.5000000000000142) ) ) {
              result[0] += -1.6449332868361646e-05;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.05368089823796016319) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02447420998234165271) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                    result[0] += 0.0006197149748699025;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09500000000000001499) ) ) {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.005252998053033501244) ) ) {
                        result[0] += -0.000347818302429757;
                      } else {
                        result[0] += 8.678839186680803e-05;
                      }
                    } else {
                      result[0] += 0.00020551713680559458;
                    }
                  }
                } else {
                  result[0] += 0.0008126542995275189;
                }
              } else {
                result[0] += -6.663220026060893e-06;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.213351496714494937) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7974125133417085953) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.966590843157139501) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)10.50000000000000178) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4950000000000000511) ) ) {
                      result[0] += 0.000779637234072691;
                    } else {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09069971400431196817) ) ) {
                        result[0] += 0.000452287557585546;
                      } else {
                        result[0] += -0.000434994754916153;
                      }
                    }
                  } else {
                    result[0] += 0.00036062886664346114;
                  }
                } else {
                  result[0] += -0.0003992163042194708;
                }
              } else {
                result[0] += 0.0011600237805939263;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006979000000000000828) ) ) {
                result[0] += -1.2277079040193788e-05;
              } else {
                result[0] += -0.002615082158417584;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0001668215445768608;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1185261981962025396) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)201.5000000000000284) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01112050000000000191) ) ) {
                  result[0] += 0.0001810086993655252;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07184972061993401271) ) ) {
                    result[0] += -1.3059383015072513e-05;
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
                      result[0] += 0.0001899681392060569;
                    } else {
                      result[0] += 0.00017640386580194077;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
                  result[0] += 0.0004678386894361999;
                } else {
                  result[0] += 0.00018809831555086705;
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5196530228391961215) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06439350000000000629) ) ) {
                  result[0] += 1.576191123579906e-05;
                } else {
                  result[0] += -0.0004647337017450431;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1245513101099625097) ) ) {
                  result[0] += 0.00018150232882051126;
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6067453057537689487) ) ) {
                    result[0] += -0.00015039001832710275;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5423446055643508235) ) ) {
                      result[0] += 0.00017879936329966755;
                    } else {
                      result[0] += 9.601316907375682e-06;
                    }
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)48.50000000000000711) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3801755927260667134) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1207797749301366269) ) ) {
                  result[0] += 0.0001781297901389016;
                } else {
                  result[0] += 1.7296186556769116e-05;
                }
              } else {
                result[0] += 0.0001626913806550031;
              }
            } else {
              result[0] += 0.00017504862779905148;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -1.7184965175532933e-06;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -2.0660131309230823e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.1481206269356676e-06;
            } else {
              result[0] += -2.1481206269356676e-06;
            }
          }
        } else {
          result[0] += -6.406139794928712e-06;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -2.1481206269356676e-06;
                } else {
                  result[0] += -2.1481206269356676e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -2.1481206269356676e-06;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -2.1481206269356676e-06;
                    } else {
                      result[0] += -2.1481206269356676e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -2.1481206269356676e-06;
                    } else {
                      result[0] += -2.1481206269356676e-06;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -2.1481206269356676e-06;
              } else {
                result[0] += -2.1481206269356676e-06;
              }
            }
          } else {
            result[0] += -2.508013335523227e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -2.1481206269356676e-06;
              } else {
                result[0] += -2.1481206269356676e-06;
              }
            } else {
              result[0] += -2.1481206269356676e-06;
            }
          } else {
            result[0] += -2.1481206269356676e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2655998599748743971) ) ) {
          result[0] += 0.0006159191759973437;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07802786554345496339) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
              result[0] += -8.85966327959759e-05;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)678.5000000000001137) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)3.058716661128509106e-06) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5326995889949749374) ) ) {
                      result[0] += -0.0003367786591461895;
                    } else {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)113.5000000000000142) ) ) {
                        result[0] += -2.5338564498269882e-06;
                      } else {
                        result[0] += 0.00016791561441849835;
                      }
                    }
                  } else {
                    result[0] += 0.0011298148862776778;
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)513.5000000000001137) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)37.50000000000000711) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4143094250104821241) ) ) {
                          result[0] += -0.00014044719573657558;
                        } else {
                          result[0] += 9.312619576704334e-06;
                        }
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
                          result[0] += 0.0008349798875399882;
                        } else {
                          result[0] += -0.00010078080475271476;
                        }
                      }
                    } else {
                      result[0] += 2.3705574275963146e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7210440605025126848) ) ) {
                      result[0] += -2.8740672517538355e-05;
                    } else {
                      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8155157533417086713) ) ) {
                        result[0] += -0.0007277678684495432;
                      } else {
                        result[0] += -1.8418379645647875e-06;
                      }
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02447420998234165271) ) ) {
                  result[0] += 0.000115231377065302;
                } else {
                  result[0] += 0.0010668516966214035;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)27.50000000000000355) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04896500000000000158) ) ) {
                result[0] += 0.0001088796684963602;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09856400000000001271) ) ) {
                  result[0] += -0.000923947812988327;
                } else {
                  result[0] += -7.744665650821487e-05;
                }
              }
            } else {
              result[0] += 0.00045898137812976834;
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0001597414222997372;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1185261981962025396) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)201.5000000000000284) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01112050000000000191) ) ) {
                  result[0] += 0.00017332645587603935;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07184972061993401271) ) ) {
                    result[0] += -1.2505125896513485e-05;
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
                      result[0] += 0.00018190564549310024;
                    } else {
                      result[0] += 0.00016891705740915415;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
                  result[0] += 0.00044798300991003053;
                } else {
                  result[0] += 0.0001801151795740384;
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4983996163819096048) ) ) {
                result[0] += -0.0010977574559450122;
              } else {
                result[0] += 0.0001301187657270816;
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)48.50000000000000711) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3801755927260667134) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1207797749301366269) ) ) {
                  result[0] += 0.00017056973128330897;
                } else {
                  result[0] += 1.6562114011999648e-05;
                }
              } else {
                result[0] += 0.00015578654788059196;
              }
            } else {
              result[0] += 0.00016761933746126012;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -1.6455613010142135e-06;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -1.978328859504871e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.0569516071109345e-06;
            } else {
              result[0] += -2.0569516071109345e-06;
            }
          }
        } else {
          result[0] += -6.134254930251867e-06;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -2.0569516071109345e-06;
                } else {
                  result[0] += -2.0569516071109345e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -2.0569516071109345e-06;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -2.0569516071109345e-06;
                    } else {
                      result[0] += -2.0569516071109345e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -2.0569516071109345e-06;
                    } else {
                      result[0] += -2.0569516071109345e-06;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -2.0569516071109345e-06;
              } else {
                result[0] += -2.0569516071109345e-06;
              }
            }
          } else {
            result[0] += -2.401570003319285e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -2.0569516071109345e-06;
              } else {
                result[0] += -2.0569516071109345e-06;
              }
            } else {
              result[0] += -2.0569516071109345e-06;
            }
          } else {
            result[0] += -2.0569516071109345e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
          result[0] += -9.330004578408086e-05;
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2655998599748743971) ) ) {
            result[0] += 0.0006941793530618566;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1990485499246814893) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)37.50000000000000711) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
                  result[0] += -0.0012012053740102476;
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4629970383791919275) ) ) {
                    result[0] += 0.000600336913461376;
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)24.50000000000000355) ) ) {
                      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4146383914824121053) ) ) {
                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0224959460313973042) ) ) {
                          result[0] += 9.154927670929744e-05;
                        } else {
                          result[0] += -0.0010370018453646336;
                        }
                      } else {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)3.058716661128509106e-06) ) ) {
                            result[0] += 0.00023916807463607954;
                          } else {
                            result[0] += -0.0001779574688314464;
                          }
                        } else {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9567162861906464144) ) ) {
                            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
                              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6642917660552764003) ) ) {
                                result[0] += 6.965283877291608e-05;
                              } else {
                                result[0] += -0.0009051122400304768;
                              }
                            } else {
                              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0159540000000000029) ) ) {
                                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001831500000000000229) ) ) {
                                  result[0] += 0.0006153429875519865;
                                } else {
                                  result[0] += 3.289942475364281e-05;
                                }
                              } else {
                                result[0] += 0.0010444533735328785;
                              }
                            }
                          } else {
                            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.316725863161028132) ) ) {
                              result[0] += -0.00048067820565573025;
                            } else {
                              result[0] += 0.00019046772426446981;
                            }
                          }
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)25.50000000000000355) ) ) {
                        result[0] += -0.0005801306571754859;
                      } else {
                        result[0] += -0.0001041362235583833;
                      }
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07802786554345496339) ) ) {
                  result[0] += 2.539807794372038e-05;
                } else {
                  result[0] += 0.00039178881613205225;
                }
              }
            } else {
              result[0] += 0.00044611078125850775;
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.00015296178957620334;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1185261981962025396) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)201.5000000000000284) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
                  result[0] += -6.023311724347373e-05;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01112050000000000191) ) ) {
                    result[0] += 0.00018361885565806236;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07184972061993401271) ) ) {
                      result[0] += 3.635044411149564e-05;
                    } else {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
                        result[0] += 0.0001722460434735953;
                      } else {
                        result[0] += 0.00016174799885510015;
                      }
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
                  result[0] += 0.0004289700311231313;
                } else {
                  result[0] += 0.00017247085822102973;
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4983996163819096048) ) ) {
                result[0] += -0.001051167208633545;
              } else {
                result[0] += 0.0001245963568905412;
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)48.50000000000000711) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3801755927260667134) ) ) {
                result[0] += 0.00015996159597504448;
              } else {
                result[0] += 0.0001491747651463906;
              }
            } else {
              result[0] += 0.0001605053558214993;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -1.5757215494687048e-06;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -1.8943660220596896e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.9696519184920845e-06;
            } else {
              result[0] += -1.9696519184920845e-06;
            }
          }
        } else {
          result[0] += -5.873909211145818e-06;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -1.9696519184920845e-06;
                } else {
                  result[0] += -1.9696519184920845e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -1.9696519184920845e-06;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -1.9696519184920845e-06;
                    } else {
                      result[0] += -1.9696519184920845e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -1.9696519184920845e-06;
                    } else {
                      result[0] += -1.9696519184920845e-06;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -1.9696519184920845e-06;
              } else {
                result[0] += -1.9696519184920845e-06;
              }
            }
          } else {
            result[0] += -2.2996442639088915e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -1.9696519184920845e-06;
              } else {
                result[0] += -1.9696519184920845e-06;
              }
            } else {
              result[0] += -1.9696519184920845e-06;
            }
          } else {
            result[0] += -1.9696519184920845e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
          result[0] += -8.934027107819224e-05;
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2655998599748743971) ) ) {
            result[0] += 0.0006647174828076269;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1990485499246814893) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4330073079623726895) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4036106884780860105) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6628367744974875686) ) ) {
                      result[0] += 4.0374415826218405e-05;
                    } else {
                      result[0] += -0.0005030907108921385;
                    }
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)73.50000000000001421) ) ) {
                      result[0] += -0.00021782580632698825;
                    } else {
                      result[0] += -0.001130389719574081;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)262.5000000000000568) ) ) {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5951110425376885393) ) ) {
                      result[0] += -0.0007495534379603455;
                    } else {
                      result[0] += 0.0002062152010544915;
                    }
                  } else {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6720057180904523975) ) ) {
                      result[0] += -0.0010734122889844628;
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001687500000000000198) ) ) {
                        result[0] += -0.000646640493735069;
                      } else {
                        result[0] += 0.0011039429655412274;
                      }
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8523239353217898495) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01926987714285620379) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)9.264969488118538537e-06) ) ) {
                      result[0] += -0.000280591480297764;
                    } else {
                      result[0] += -2.9009381823254546e-05;
                    }
                  } else {
                    result[0] += -0.0005755330249871299;
                  }
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7080301875628142172) ) ) {
                    result[0] += -0.000919717167321776;
                  } else {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7269841738944724518) ) ) {
                      result[0] += 0.0006168958608040923;
                    } else {
                      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7377710019346734871) ) ) {
                        result[0] += -0.0010073449235381115;
                      } else {
                        result[0] += 1.0029330871707394e-05;
                      }
                    }
                  }
                }
              }
            } else {
              result[0] += 0.00042717726227889293;
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.00014646989324066252;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1185261981962025396) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)201.5000000000000284) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
                  result[0] += -5.767674578499198e-05;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01112050000000000191) ) ) {
                    result[0] += 0.00017582583375706784;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07184972061993401271) ) ) {
                      result[0] += 3.480768421324417e-05;
                    } else {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
                        result[0] += 0.00016493569844210014;
                      } else {
                        result[0] += 0.000154883204425342;
                      }
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
                  result[0] += 0.00041076398776537744;
                } else {
                  result[0] += 0.00016515097176066258;
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4983996163819096048) ) ) {
                result[0] += -0.0010065543117220121;
              } else {
                result[0] += 0.00011930832623294805;
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)48.50000000000000711) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3801755927260667134) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1207797749301366269) ) ) {
                  result[0] += 0.0001565415539316026;
                } else {
                  result[0] += 9.070219276875867e-06;
                }
              } else {
                result[0] += 0.00014284359502938246;
              }
            } else {
              result[0] += 0.0001536933007705048;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -1.5088458873758221e-06;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -1.813966676112888e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.8860573416544746e-06;
            } else {
              result[0] += -1.8860573416544746e-06;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.07196201389915944657) ) ) {
              result[0] += -6.933922225270717e-05;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5521365942211056144) ) ) {
                result[0] += 0.00082617256722742;
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.640890220251256415) ) ) {
                  result[0] += -1.454093800329764e-05;
                } else {
                  result[0] += 5.3469384004089654e-05;
                }
              }
            }
          } else {
            result[0] += 0.0005507252295459778;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -1.8860573416544746e-06;
                } else {
                  result[0] += -1.8860573416544746e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -1.8860573416544746e-06;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -1.8860573416544746e-06;
                    } else {
                      result[0] += -1.8860573416544746e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -1.8860573416544746e-06;
                    } else {
                      result[0] += -1.8860573416544746e-06;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -1.8860573416544746e-06;
              } else {
                result[0] += -1.8860573416544746e-06;
              }
            }
          } else {
            result[0] += -2.202044384806574e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -1.8860573416544746e-06;
              } else {
                result[0] += -1.8860573416544746e-06;
              }
            } else {
              result[0] += -1.8860573416544746e-06;
            }
          } else {
            result[0] += -1.8860573416544746e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
          result[0] += -8.554855433615154e-05;
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2575587311557789305) ) ) {
            result[0] += 0.0006701093118074141;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1990485499246814893) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)37.50000000000000711) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
                  result[0] += -0.001164457923164062;
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4629970383791919275) ) ) {
                    result[0] += 0.0006042269558962731;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4218023131278703652) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2397171522356433271) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1913179023522538491) ) ) {
                          result[0] += -8.852407590443405e-05;
                        } else {
                          result[0] += 0.0006785330663436269;
                        }
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3419045205559314016) ) ) {
                          result[0] += -0.0005262704672301844;
                        } else {
                          result[0] += -3.635156290123507e-05;
                        }
                      }
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9808239647505231362) ) ) {
                        result[0] += 9.497640340514426e-05;
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.0144392355375913) ) ) {
                          result[0] += -0.0011168592635884343;
                        } else {
                          result[0] += -4.4717360501863894e-05;
                        }
                      }
                    }
                  }
                }
              } else {
                result[0] += 3.8420353001834227e-05;
              }
            } else {
              result[0] += 0.00040904730635135347;
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0001402535213883841;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1185261981962025396) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)201.5000000000000284) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01112050000000000191) ) ) {
                  result[0] += 0.00016395446315187342;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07184972061993401271) ) ) {
                    result[0] += -8.298694628621622e-06;
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
                      result[0] += 0.00015987490489127875;
                    } else {
                      result[0] += 0.00014830976075662353;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
                  result[0] += 0.00039333063245269547;
                } else {
                  result[0] += 0.00015814175075616228;
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5196530228391961215) ) ) {
                result[0] += -0.00014132033558971293;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3830383354773237436) ) ) {
                  result[0] += 0.0001535721075873724;
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6586934769095478259) ) ) {
                    result[0] += -0.00023269746586781223;
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)117.5000000000000142) ) ) {
                      result[0] += -8.040984163862779e-05;
                    } else {
                      result[0] += 0.00021388747210137837;
                    }
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)48.50000000000000711) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3801755927260667134) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1207797749301366269) ) ) {
                  result[0] += 0.00014989772776335505;
                } else {
                  result[0] += 8.685267430736922e-06;
                }
              } else {
                result[0] += 0.00013678112796688537;
              }
            } else {
              result[0] += 0.0001471703581530478;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -1.4448085149425388e-06;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -1.7369795824728745e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.8060106268584018e-06;
            } else {
              result[0] += -1.8060106268584018e-06;
            }
          }
        } else {
          result[0] += -5.566908100606058e-06;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -1.8060106268584018e-06;
                } else {
                  result[0] += -1.8060106268584018e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -1.8060106268584018e-06;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -1.8060106268584018e-06;
                    } else {
                      result[0] += -1.8060106268584018e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -1.8060106268584018e-06;
                    } else {
                      result[0] += -1.8060106268584018e-06;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -1.8060106268584018e-06;
              } else {
                result[0] += -1.8060106268584018e-06;
              }
            }
          } else {
            result[0] += -2.108586770901652e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -1.8060106268584018e-06;
              } else {
                result[0] += -1.8060106268584018e-06;
              }
            } else {
              result[0] += -1.8060106268584018e-06;
            }
          } else {
            result[0] += -1.8060106268584018e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.006697829966773901147) ) ) {
          result[0] += -9.525130855413132e-06;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6918289147989949983) ) ) {
              if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)102.5000000000000142) ) ) {
                  if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05227730674148379358) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.163639685692610809) ) ) {
                      result[0] += -2.9784830147835546e-05;
                    } else {
                      result[0] += 0.0009695109615364595;
                    }
                  } else {
                    result[0] += 0.0012420681324108735;
                  }
                } else {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5510720942211057016) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004773500000000000833) ) ) {
                      result[0] += 0.00043616276168153054;
                    } else {
                      result[0] += 0.0002454692883237363;
                    }
                  } else {
                    result[0] += 0.001286700314027251;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0006285000000000000439) ) ) {
                  result[0] += -0.000802769042746041;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.144071500000000019) ) ) {
                    result[0] += -3.269382269200966e-05;
                  } else {
                    result[0] += 0.0013475843270088692;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5043717672569237864) ) ) {
                result[0] += -0.0006094032821504393;
              } else {
                result[0] += 0.0006453802474312445;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7080301875628142172) ) ) {
              result[0] += -0.0014343753597126348;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7210440605025126848) ) ) {
                result[0] += 0.0017090061077734598;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8523239353217898495) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)390.5000000000000568) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01413850000000000176) ) ) {
                      result[0] += -0.00015183184383577814;
                    } else {
                      result[0] += -0.0016802245034067296;
                    }
                  } else {
                    result[0] += 0.00018603756168152232;
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
                    result[0] += -0.00011496445902540702;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9567162861906464144) ) ) {
                      result[0] += 0.0004716724062863923;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.0144392355375913) ) ) {
                        result[0] += -0.0005408479465886666;
                      } else {
                        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)367.5000000000000568) ) ) {
                          result[0] += -1.7314003905471765e-05;
                        } else {
                          result[0] += 0.0006044752548787205;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.00013430098040367031;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)189.5000000000000284) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01112050000000000191) ) ) {
                result[0] += 0.00014561942586718572;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06413776133552721859) ) ) {
                  result[0] += -2.4972410376069468e-05;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3830383354773237436) ) ) {
                    result[0] += 0.00014229337343084865;
                  } else {
                    result[0] += -8.921784292177926e-05;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5072068278894473758) ) ) {
                result[0] += 0.00015269695166484322;
              } else {
                result[0] += 0.00012694291648199414;
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)48.50000000000000711) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3801755927260667134) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1207797749301366269) ) ) {
                  result[0] += 0.0001435358741771205;
                } else {
                  result[0] += 8.316653439211746e-06;
                }
              } else {
                result[0] += 0.00013097595985346724;
              }
            } else {
              result[0] += 0.00014092425766324085;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -1.3834889714820692e-06;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -1.6632599207351036e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.7293611982466522e-06;
            } else {
              result[0] += -1.7293611982466522e-06;
            }
          }
        } else {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.07196201389915944657) ) ) {
            result[0] += -5.4192887554644796e-05;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5494686760804020631) ) ) {
              result[0] += 0.0008105900078665302;
            } else {
              result[0] += -1.298792984693361e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -1.7293611982466522e-06;
                } else {
                  result[0] += -1.7293611982466522e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -1.7293611982466522e-06;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -1.7293611982466522e-06;
                    } else {
                      result[0] += -1.7293611982466522e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -1.7293611982466522e-06;
                    } else {
                      result[0] += -1.7293611982466522e-06;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -1.7293611982466522e-06;
              } else {
                result[0] += -1.7293611982466522e-06;
              }
            }
          } else {
            result[0] += -2.0190956190976067e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -1.7293611982466522e-06;
              } else {
                result[0] += -1.7293611982466522e-06;
              }
            } else {
              result[0] += -1.7293611982466522e-06;
            }
          } else {
            result[0] += -1.7293611982466522e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07184972061993401271) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1255.500000000000227) ) ) {
            result[0] += 5.0936044803919865e-06;
          } else {
            result[0] += 0.0007365381992973353;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)21.50000000000000355) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04896500000000000158) ) ) {
              result[0] += 3.7605055874742147e-05;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1016030000000000127) ) ) {
                result[0] += -0.0011489814835235414;
              } else {
                result[0] += 0.00017288708753306737;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8030059940338053481) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5308132790452262384) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
                  result[0] += 0.000552943241870742;
                } else {
                  result[0] += -0.0014149399696364506;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1165587384072143268) ) ) {
                  result[0] += 0.0007169274536032471;
                } else {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6903617355527639221) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1498495000000000243) ) ) {
                      result[0] += -0.00012801447243463967;
                    } else {
                      result[0] += 0.00141739239735182;
                    }
                  } else {
                    result[0] += 0.0007496739434138444;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7831470153266332224) ) ) {
                result[0] += -0.000597481646936064;
              } else {
                result[0] += 0.0006292352058853232;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.00012860107296301112;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1185261981962025396) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)201.5000000000000284) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
                  result[0] += -6.827329538990694e-05;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01112050000000000191) ) ) {
                    result[0] += 0.00015522484124584707;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07184972061993401271) ) ) {
                      result[0] += 2.764349343771119e-05;
                    } else {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
                        result[0] += 0.00014511120107270177;
                      } else {
                        result[0] += 0.00013597618759985744;
                      }
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
                  result[0] += 0.00037015651503253876;
                } else {
                  result[0] += 0.00014494935389168108;
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5196530228391961215) ) ) {
                result[0] += -0.00013426265621009522;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1245513101099625097) ) ) {
                  result[0] += 0.00014528560875526643;
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6067453057537689487) ) ) {
                    result[0] += -0.00014813086590477256;
                  } else {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6541365753517588422) ) ) {
                      result[0] += 0.0001545967693454184;
                    } else {
                      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6918289147989949983) ) ) {
                        result[0] += -0.00010373579323276387;
                      } else {
                        result[0] += 0.00013694062686037809;
                      }
                    }
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)48.50000000000000711) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3801755927260667134) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1207797749301366269) ) ) {
                  result[0] += 0.00013744402589154067;
                } else {
                  result[0] += 7.963683902598468e-06;
                }
              } else {
                result[0] += 0.0001254171705886964;
              }
            } else {
              result[0] += 0.00013494324976285547;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -1.3247719088149367e-06;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -1.592669016860447e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.6559648705962895e-06;
            } else {
              result[0] += -1.6559648705962895e-06;
            }
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4754075198241206057) ) ) {
            result[0] += 0.0003605528411691698;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.06355808660527756393) ) ) {
              result[0] += -0.00017476762893950444;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6285027855690678011) ) ) {
                result[0] += 2.2955382214204686e-05;
              } else {
                result[0] += -3.941488005752987e-05;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -1.6559648705962895e-06;
                } else {
                  result[0] += -1.6559648705962895e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -1.6559648705962895e-06;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -1.6559648705962895e-06;
                    } else {
                      result[0] += -1.6559648705962895e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -1.6559648705962895e-06;
                    } else {
                      result[0] += -1.6559648705962895e-06;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -1.6559648705962895e-06;
              } else {
                result[0] += -1.6559648705962895e-06;
              }
            }
          } else {
            result[0] += -1.9334025876088657e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -1.6559648705962895e-06;
              } else {
                result[0] += -1.6559648705962895e-06;
              }
            } else {
              result[0] += -1.6559648705962895e-06;
            }
          } else {
            result[0] += -1.6559648705962895e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07802786554345496339) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1255.500000000000227) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2575587311557789305) ) ) {
              result[0] += 0.0006222667235616228;
            } else {
              result[0] += 3.1989677365892648e-06;
            }
          } else {
            result[0] += 0.000705278564781744;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)21.50000000000000355) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05151350000000001067) ) ) {
              result[0] += 4.0407016496129625e-05;
            } else {
              result[0] += -0.000624331894715959;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.168079446220334772) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9350000000000001643) ) ) {
                result[0] += 0.0017805334485359258;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5366611211306534512) ) ) {
                    result[0] += -0.00016482235037797247;
                  } else {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6427178366080402716) ) ) {
                      result[0] += 0.0007108156419423886;
                    } else {
                      result[0] += -3.2354653802402e-05;
                    }
                  }
                } else {
                  result[0] += 0.00033549268921520347;
                }
              }
            } else {
              result[0] += -0.00022348809546542545;
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.00012314307697180437;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1185261981962025396) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)201.5000000000000284) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
                  result[0] += -6.53756883640926e-05;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01112050000000000191) ) ) {
                    result[0] += 0.00014863689806826933;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07184972061993401271) ) ) {
                      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4516066347997827468) ) ) {
                        result[0] += 0.00027167771928535026;
                      } else {
                        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)96.50000000000001421) ) ) {
                          result[0] += 2.6470267795887305e-05;
                        } else {
                          result[0] += -0.0005668890023816328;
                        }
                      }
                    } else {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)67.50000000000001421) ) ) {
                        result[0] += 0.00013895249387465013;
                      } else {
                        result[0] += 0.00013020518219748964;
                      }
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
                  result[0] += 0.0003544465934228757;
                } else {
                  result[0] += 0.0001387975156974821;
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4983996163819096048) ) ) {
                result[0] += -0.000955422968724048;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9194299814036738239) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6852090990703517681) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5423446055643508235) ) ) {
                      result[0] += 0.0001315175290818956;
                    } else {
                      result[0] += -0.00034977498435485513;
                    }
                  } else {
                    result[0] += 0.00024008124489291056;
                  }
                } else {
                  result[0] += -0.000402580082390044;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)48.50000000000000711) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3801755927260667134) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1207797749301366269) ) ) {
                  result[0] += 0.0001316107235321786;
                } else {
                  result[0] += 7.625694849988894e-06;
                }
              } else {
                result[0] += 0.00012009430353533567;
              }
            } else {
              result[0] += 0.0001292160835792737;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -1.2685468742877528e-06;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -1.5250740823154904e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.5856835780918646e-06;
            } else {
              result[0] += -1.5856835780918646e-06;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6285027855690678011) ) ) {
            result[0] += 7.2718809003312944e-06;
          } else {
            result[0] += -3.774206153128142e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -1.5856835780918646e-06;
                } else {
                  result[0] += -1.5856835780918646e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -1.5856835780918646e-06;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -1.5856835780918646e-06;
                    } else {
                      result[0] += -1.5856835780918646e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -1.5856835780918646e-06;
                    } else {
                      result[0] += -1.5856835780918646e-06;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -1.5856835780918646e-06;
              } else {
                result[0] += -1.5856835780918646e-06;
              }
            }
          } else {
            result[0] += -1.8513464792932501e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -1.5856835780918646e-06;
              } else {
                result[0] += -1.5856835780918646e-06;
              }
            } else {
              result[0] += -1.5856835780918646e-06;
            }
          } else {
            result[0] += -1.5856835780918646e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.006697829966773901147) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002357500000000000654) ) ) {
            result[0] += 6.227692826138974e-06;
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)678.5000000000001137) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)432.5000000000000568) ) ) {
                result[0] += -0.00012614059287183136;
              } else {
                result[0] += -0.0008634603122256516;
              }
            } else {
              result[0] += 0.0004284664120620944;
            }
          }
        } else {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)102.5000000000000142) ) ) {
              if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1000116863636408421) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00279350000000000041) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7750000000000001332) ) ) {
                    result[0] += 5.171027824856998e-05;
                  } else {
                    result[0] += 0.0008353083601557545;
                  }
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5550000000000001599) ) ) {
                    result[0] += 0.00022668155296107602;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6150000000000001021) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01112050000000000191) ) ) {
                        result[0] += -0.0013409655293362382;
                      } else {
                        result[0] += -3.507250114160757e-06;
                      }
                    } else {
                      result[0] += -9.784536280544418e-05;
                    }
                  }
                }
              } else {
                result[0] += 0.0006066068067731698;
              }
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5510720942211057016) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4814085394974874643) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02447420998234165271) ) ) {
                    result[0] += 0.0003750812476857724;
                  } else {
                    result[0] += 0.0009343734358102884;
                  }
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4892818374874372545) ) ) {
                    result[0] += -0.0006629207839851871;
                  } else {
                    result[0] += 0.00018364268819268578;
                  }
                }
              } else {
                result[0] += 0.0012176033808100851;
              }
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0006285000000000000439) ) ) {
              result[0] += -0.0004942096200315084;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3096860000000000723) ) ) {
                result[0] += 4.859502657888583e-06;
              } else {
                result[0] += 0.0011838552704430448;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.00011791672539501382;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2162432673096428282) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)14.50000000000000178) ) ) {
              result[0] += -0.00014914832054113675;
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1185261981962025396) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08780304645514057371) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01265500000000000132) ) ) {
                    result[0] += 0.00014888072074640917;
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)201.5000000000000284) ) ) {
                      result[0] += -1.1382224756677659e-05;
                    } else {
                      result[0] += 0.00016699323169878016;
                    }
                  }
                } else {
                  result[0] += 0.00011919280651060074;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5085295226130653878) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0660705000000000181) ) ) {
                    result[0] += 0.0002207835341739726;
                  } else {
                    result[0] += -0.0003291917751669834;
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
                    result[0] += 0.0001256868404909356;
                  } else {
                    result[0] += 0.00011955299833290926;
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)48.50000000000000711) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3801755927260667134) ) ) {
                result[0] += 0.00012194412065909527;
              } else {
                result[0] += 0.00011499734584936616;
              }
            } else {
              result[0] += 0.00012629511508947689;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -1.2147081030007272e-06;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -1.4603479642840512e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.5183851146098414e-06;
            } else {
              result[0] += -1.5183851146098414e-06;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6285027855690678011) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)57.50000000000000711) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.05721739154190200877) ) ) {
                result[0] += -7.947105013167707e-05;
              } else {
                result[0] += 2.1672498042998836e-05;
              }
            } else {
              result[0] += 8.84861512541862e-05;
            }
          } else {
            result[0] += -3.614023958849779e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -1.5183851146098414e-06;
                } else {
                  result[0] += -1.5183851146098414e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -1.5183851146098414e-06;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -1.5183851146098414e-06;
                    } else {
                      result[0] += -1.5183851146098414e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -1.5183851146098414e-06;
                    } else {
                      result[0] += -1.5183851146098414e-06;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -1.5183851146098414e-06;
              } else {
                result[0] += -1.5183851146098414e-06;
              }
            }
          } else {
            result[0] += -1.7727729384237317e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -1.5183851146098414e-06;
              } else {
                result[0] += -1.5183851146098414e-06;
              }
            } else {
              result[0] += -1.5183851146098414e-06;
            }
          } else {
            result[0] += -1.5183851146098414e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1990485499246814893) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1255.500000000000227) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
                result[0] += 4.461313204163487e-05;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.036113539341048927e-06) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)94.50000000000001421) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.29500000000000004) ) ) {
                      result[0] += -0.0003189399032220328;
                    } else {
                      result[0] += 0.0010009080458411464;
                    }
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)564.5000000000001137) ) ) {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1650000000000000355) ) ) {
                        result[0] += 0.0003196673162235418;
                      } else {
                        result[0] += 6.509181025385155e-05;
                      }
                    } else {
                      result[0] += -0.00014896933990546547;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6169877415829146949) ) ) {
                    result[0] += -3.110814868153734e-05;
                  } else {
                    result[0] += -0.0002788798259874294;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.752860906001682428) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2575587311557789305) ) ) {
                  result[0] += 0.0005875618923789765;
                } else {
                  result[0] += 1.736149301123011e-05;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8701049114070352752) ) ) {
                  result[0] += -0.0005065561223562628;
                } else {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9127016867587941507) ) ) {
                    result[0] += 0.00016129949309080593;
                  } else {
                    result[0] += -0.0002511981073316046;
                  }
                }
              }
            }
          } else {
            result[0] += 0.0006751335792811511;
          }
        } else {
          result[0] += 0.0003248693713575806;
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.00011291218694386712;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
            if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1000116863636408421) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)201.5000000000000284) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01112050000000000191) ) ) {
                  result[0] += 0.0001360096722120094;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
                    result[0] += -0.00029323590128377437;
                  } else {
                    result[0] += 0.00011962040874870171;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
                  result[0] += 0.0003351738689321841;
                } else {
                  result[0] += 0.00012784807249347993;
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5196530228391961215) ) ) {
                result[0] += -0.00021494379179674814;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1245513101099625097) ) ) {
                  result[0] += 0.00012765219272779254;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02278050000000000561) ) ) {
                    result[0] += 0.0001390460859966147;
                  } else {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6586934769095478259) ) ) {
                      result[0] += -0.0001654544431186123;
                    } else {
                      result[0] += 0.00018845057492632367;
                    }
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)48.50000000000000711) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3801755927260667134) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1207797749301366269) ) ) {
                  result[0] += 0.00012084952775626394;
                } else {
                  result[0] += 9.029886900597496e-06;
                }
              } else {
                result[0] += 0.00011011670964482842;
              }
            } else {
              result[0] += 0.0001186732887560822;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
    result[0] += -1.163154318853262e-06;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            result[0] += -1.398368906480046e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -1.453942885025688e-06;
            } else {
              result[0] += -1.453942885025688e-06;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6285027855690678011) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1129321246270776624) ) ) {
              result[0] += -2.3704278035417933e-05;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6242923255276383587) ) ) {
                result[0] += 7.98384590371326e-05;
              } else {
                result[0] += -7.654319622605362e-06;
              }
            }
          } else {
            result[0] += -3.460640104228237e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0004235000000000000483) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -1.453942885025688e-06;
                } else {
                  result[0] += -1.453942885025688e-06;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                  result[0] += -1.453942885025688e-06;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)28.50000000000000355) ) ) {
                      result[0] += -1.453942885025688e-06;
                    } else {
                      result[0] += -1.453942885025688e-06;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                      result[0] += -1.453942885025688e-06;
                    } else {
                      result[0] += -1.453942885025688e-06;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -1.453942885025688e-06;
              } else {
                result[0] += -1.453942885025688e-06;
              }
            }
          } else {
            result[0] += -1.6975341603303072e-06;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                result[0] += -1.453942885025688e-06;
              } else {
                result[0] += -1.453942885025688e-06;
              }
            } else {
              result[0] += -1.453942885025688e-06;
            }
          } else {
            result[0] += -1.453942885025688e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.004923558837848901124) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002917500000000000388) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002668500000000000299) ) ) {
              result[0] += -2.763271788157437e-06;
            } else {
              result[0] += 0.0006984629884033407;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003732500000000000574) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6150000000000001021) ) ) {
                result[0] += -0.00013995274541950975;
              } else {
                result[0] += -0.0014340285256392825;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005169500000000001351) ) ) {
                result[0] += 0.0003690275020001845;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001972498273255000271) ) ) {
                  result[0] += 0.0009335551815801094;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.004134701972639751033) ) ) {
                    result[0] += -0.0005482064284854174;
                  } else {
                    result[0] += 4.2940406321711715e-05;
                  }
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.895681724436047322) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7573260829648241765) ) ) {
                result[0] += 2.8926418006129512e-06;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.140339474584314505) ) ) {
                  result[0] += -0.0001978008120338409;
                } else {
                  result[0] += -3.261676615744616e-05;
                }
              }
            } else {
              result[0] += 8.2145670185534e-05;
            }
          } else {
            result[0] += -0.0005426223494923861;
          }
        }
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.00010812004758220365;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1185261981962025396) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)201.5000000000000284) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.799706208613007119) ) ) {
                  result[0] += -7.101903800281734e-05;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01112050000000000191) ) ) {
                    result[0] += 0.0001302374393121587;
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
                      result[0] += -0.0002258165747783719;
                    } else {
                      result[0] += 0.00011454356377086218;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
                  result[0] += 0.00031855203032470054;
                } else {
                  result[0] += 0.0001224220348168455;
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5196530228391961215) ) ) {
                result[0] += -0.00013035796891856834;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9194299814036738239) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6852090990703517681) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3830383354773237436) ) ) {
                      result[0] += 0.00011811713088104009;
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03676400000000001195) ) ) {
                        result[0] += 0.00016841739754734603;
                      } else {
                        result[0] += -0.0003796887232014169;
                      }
                    }
                  } else {
                    result[0] += 0.00021865627805385234;
                  }
                } else {
                  result[0] += -0.0004095544795365512;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)48.50000000000000711) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3801755927260667134) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1207797749301366269) ) ) {
                  result[0] += 0.00011572051737683416;
                } else {
                  result[0] += 8.646646812714063e-06;
                }
              } else {
                result[0] += 0.00010544321395806127;
              }
            } else {
              result[0] += 0.00011363664077663471;
            }
          }
        }
      }
    }
  }
}

