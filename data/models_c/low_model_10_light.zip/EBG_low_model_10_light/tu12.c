
#include "header.h"

void predict_unit12(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -2.9857960264495353e-06;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += 3.4519612278177834e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.7322449983025644e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7093978733165829942) ) ) {
                  result[0] += 8.871362687100875e-07;
                } else {
                  result[0] += -3.4403938513771994e-06;
                }
              } else {
                result[0] += -3.7322449983025644e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04500000000000000527) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007384500000000001306) ) ) {
                  result[0] += 1.0623739932996498e-05;
                } else {
                  result[0] += -6.848464050710383e-05;
                }
              } else {
                result[0] += 1.0616372517047653e-05;
              }
            } else {
              result[0] += 0.002157238520618548;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7326471166347855446) ) ) {
              result[0] += -0.00012004138663600457;
            } else {
              result[0] += 6.123591858525648e-06;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -3.7322449983025644e-06;
                } else {
                  result[0] += -3.7322449983025644e-06;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -3.672268478811241e-06;
                } else {
                  result[0] += -3.7322449983025644e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -3.7322449983025644e-06;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -3.7322449983025644e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -3.7322449983025644e-06;
                      } else {
                        result[0] += -3.7322449983025644e-06;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -3.7322449983025644e-06;
                      } else {
                        result[0] += -3.7322449983025644e-06;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.310012234630710122e-06) ) ) {
                            result[0] += -3.7322449983025644e-06;
                          } else {
                            result[0] += -3.7322449983025644e-06;
                          }
                        } else {
                          result[0] += -3.7322449983025644e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -3.7322449983025644e-06;
                        } else {
                          result[0] += -3.7322449983025644e-06;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -3.7322449983025644e-06;
                    } else {
                      result[0] += -3.7322449983025644e-06;
                    }
                  }
                }
              } else {
                result[0] += -3.7322449983025644e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -3.7322449983025644e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -3.7322449983025644e-06;
                  } else {
                    result[0] += -3.7322449983025644e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -3.7322449983025644e-06;
                  } else {
                    result[0] += -3.7322449983025644e-06;
                  }
                }
              } else {
                result[0] += -3.7322449983025644e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
            result[0] += 4.474909547496535e-05;
          } else {
            result[0] += -3.321928842292928e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8850000000000001199) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.168924500000000033) ) ) {
            result[0] += 8.023725445418171e-07;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8327395279648243109) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9808239647505231362) ) ) {
                result[0] += 0.0019692907068564742;
              } else {
                result[0] += -0.0008004570010867763;
              }
            } else {
              result[0] += 0.0018798655278503868;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.051391296366422923) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02207100000000000381) ) ) {
                result[0] += 7.186562625563875e-05;
              } else {
                result[0] += 0.001383389900717653;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03091100000000000445) ) ) {
                result[0] += 0.0002521503943750834;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04160250000000000753) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03625250000000000694) ) ) {
                    result[0] += -5.5118242386315144e-05;
                  } else {
                    result[0] += -0.00384041726275198;
                  }
                } else {
                  result[0] += -3.81747631923215e-06;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
              result[0] += 8.266110546260742e-05;
            } else {
              result[0] += -0.0015154407280864183;
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0002769527687702478;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004295500000000001574) ) ) {
              result[0] += 0.0003645303860760834;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01065347450249755183) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4133512684738382403) ) ) {
                  result[0] += 0.0008092793040768047;
                } else {
                  result[0] += -0.0016270857328684828;
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00984850000000000135) ) ) {
                  result[0] += 0.0003252265593050246;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2929122217587940002) ) ) {
                      result[0] += -0.00023220583402377726;
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09221529126392057074) ) ) {
                        result[0] += 0.0003341126429901461;
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5424744603768845153) ) ) {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5139155612311558929) ) ) {
                            result[0] += 9.750034145599293e-05;
                          } else {
                            result[0] += -0.002217106853401627;
                          }
                        } else {
                          result[0] += 0.00015861850560481067;
                        }
                      }
                    }
                  } else {
                    result[0] += 0.0003193407978080569;
                  }
                }
              }
            }
          } else {
            result[0] += 0.0003191284697021712;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -2.856770144328306e-06;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += 3.302790842928167e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.5709626471531223e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7093978733165829942) ) ) {
                  result[0] += 8.488002475559085e-07;
                } else {
                  result[0] += -3.291723330154033e-06;
                }
              } else {
                result[0] += -3.5709626471531223e-06;
              }
            }
          }
        } else {
          result[0] += 9.194744118662039e-07;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -3.5709626471531223e-06;
                } else {
                  result[0] += -3.5709626471531223e-06;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -3.5135779066263955e-06;
                } else {
                  result[0] += -3.5709626471531223e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -3.5709626471531223e-06;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -3.5709626471531223e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -3.5709626471531223e-06;
                      } else {
                        result[0] += -3.5709626471531223e-06;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -3.5709626471531223e-06;
                      } else {
                        result[0] += -3.5709626471531223e-06;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -3.5709626471531223e-06;
                        } else {
                          result[0] += -3.5709626471531223e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -3.5709626471531223e-06;
                        } else {
                          result[0] += -3.5709626471531223e-06;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -3.5709626471531223e-06;
                    } else {
                      result[0] += -3.5709626471531223e-06;
                    }
                  }
                }
              } else {
                result[0] += -3.5709626471531223e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -3.5709626471531223e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -3.5709626471531223e-06;
                  } else {
                    result[0] += -3.5709626471531223e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -3.5709626471531223e-06;
                  } else {
                    result[0] += -3.5709626471531223e-06;
                  }
                }
              } else {
                result[0] += -3.5709626471531223e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
            result[0] += 4.2815342644351175e-05;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
              result[0] += -3.178377576424847e-05;
            } else {
              result[0] += -2.292339573082234e-08;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6950000000000000622) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01287800000000000229) ) ) {
            result[0] += -1.736678059659672e-05;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01467829982783020078) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02120250000000000259) ) ) {
                result[0] += 0.000315297847210874;
              } else {
                result[0] += -0.00028239664491542756;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.039722088301102687) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7640286906783920751) ) ) {
                    result[0] += 0.0003823529567930986;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04557577292723340862) ) ) {
                      result[0] += -0.0014001904002871695;
                    } else {
                      result[0] += 0.00042295816650283265;
                    }
                  }
                } else {
                  result[0] += 0.0012729845245322126;
                }
              } else {
                result[0] += -0.00020896265816676028;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4093335132160804135) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.469327283602055445) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.09229200000000001292) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2669585275879397535) ) ) {
                    result[0] += 0.000818513170235225;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3725635588693467781) ) ) {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06364359169843836206) ) ) {
                        result[0] += -0.0006845342522594788;
                      } else {
                        result[0] += -0.003957907759762174;
                      }
                    } else {
                      result[0] += 0.0004586794343613968;
                    }
                  }
                } else {
                  result[0] += 0.0014953437507503307;
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04160250000000000753) ) ) {
                  result[0] += -0.0012321119141648592;
                } else {
                  result[0] += -0.004639435733738495;
                }
              }
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2177889902755587859) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5470680148669562204) ) ) {
                  result[0] += -0.0004507000862919237;
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.469327283602055445) ) ) {
                    result[0] += 0.0011162186199912662;
                  } else {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4026472078210281969) ) ) {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02032228342586875347) ) ) {
                        result[0] += -0.0021750139988910566;
                      } else {
                        result[0] += 0.0011407186182101862;
                      }
                    } else {
                      result[0] += 0.0007791028592492853;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
                  result[0] += -0.0015094184490990746;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8158067323869347964) ) ) {
                    result[0] += 0.00019401747078988285;
                  } else {
                    result[0] += 0.0014510288696870696;
                  }
                }
              }
            }
          } else {
            result[0] += -0.0008802208888236515;
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0002649847458443865;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01151200000000000313) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01043419202401875238) ) ) {
                result[0] += 6.956983766781455e-05;
              } else {
                result[0] += 0.0003331334474951896;
              }
            } else {
              result[0] += 0.0001804452726443821;
            }
          } else {
            result[0] += 0.00030533789862880985;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -2.733319886968401e-06;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += 3.1600665917751737e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.4166498268903516e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7093978733165829942) ) ) {
                  result[0] += 8.121208495945459e-07;
                } else {
                  result[0] += -3.1494773419452828e-06;
                }
              } else {
                result[0] += -3.4166498268903516e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
            result[0] += 4.150492311960526e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7326471166347855446) ) ) {
              result[0] += -0.00011489374437627535;
            } else {
              result[0] += 5.819238235463189e-06;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -3.4166498268903516e-06;
                } else {
                  result[0] += -3.4166498268903516e-06;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -3.361744866194922e-06;
                } else {
                  result[0] += -3.4166498268903516e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -3.4166498268903516e-06;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -3.4166498268903516e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -3.4166498268903516e-06;
                      } else {
                        result[0] += -3.4166498268903516e-06;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -3.4166498268903516e-06;
                      } else {
                        result[0] += -3.4166498268903516e-06;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -3.4166498268903516e-06;
                        } else {
                          result[0] += -3.4166498268903516e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -3.4166498268903516e-06;
                        } else {
                          result[0] += -3.4166498268903516e-06;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -3.4166498268903516e-06;
                    } else {
                      result[0] += -3.4166498268903516e-06;
                    }
                  }
                }
              } else {
                result[0] += -3.4166498268903516e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -3.4166498268903516e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -3.4166498268903516e-06;
                  } else {
                    result[0] += -3.4166498268903516e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -3.4166498268903516e-06;
                  } else {
                    result[0] += -3.4166498268903516e-06;
                  }
                }
              } else {
                result[0] += -3.4166498268903516e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
            result[0] += 4.096515351419209e-05;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
              result[0] += -3.0410296240263303e-05;
            } else {
              result[0] += -2.193280182247788e-08;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8050000000000001599) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01287800000000000229) ) ) {
            result[0] += -1.4535375066709206e-05;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.039722088301102687) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8030059940338053481) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6055650374709939943) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01467829982783020078) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01326604349644140181) ) ) {
                          result[0] += 0.0004064637998386718;
                        } else {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5386386389447237466) ) ) {
                            result[0] += -0.00010871177146093619;
                          } else {
                            result[0] += -0.0014002641477907944;
                          }
                        }
                      } else {
                        result[0] += -0.0009890463728268576;
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3569067370100503234) ) ) {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03291917222295825951) ) ) {
                          result[0] += 0.0005655405441554229;
                        } else {
                          result[0] += -0.0018459975418357597;
                        }
                      } else {
                        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4601878067544193374) ) ) {
                          result[0] += 0.0023568162676794293;
                        } else {
                          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.378188349821562797) ) ) {
                            result[0] += -0.0008985222309565004;
                          } else {
                            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3539353041941689093) ) ) {
                              result[0] += 0.005719367500648615;
                            } else {
                              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2177889902755587859) ) ) {
                                result[0] += -0.0002844942874862899;
                              } else {
                                result[0] += 0.0005045153621672094;
                              }
                            }
                          }
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6915080527790725684) ) ) {
                      result[0] += 0.00405810211605781;
                    } else {
                      result[0] += 0.00035038049181817637;
                    }
                  }
                } else {
                  result[0] += -0.0002425513222778614;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.009602467408789250661) ) ) {
                  result[0] += -0.00039583259352210314;
                } else {
                  result[0] += 0.000977979323377549;
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8022705390703518402) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03729562354052295275) ) ) {
                  result[0] += -0.00016148394946164703;
                } else {
                  result[0] += -0.0020417167432815737;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.459978591867425068) ) ) {
                  result[0] += -0.00010001989552337459;
                } else {
                  result[0] += 0.0006217343278026532;
                }
              }
            }
          }
        } else {
          result[0] += 0.00020794874673312017;
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.00025353389981258746;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 0.0003122685183431408;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01127328256994905228) ) ) {
                result[0] += -0.001762261478507402;
              } else {
                result[0] += 0.00015535766631394763;
              }
            }
          } else {
            result[0] += 0.00029214326263672235;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -2.6152043136300043e-06;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += 3.023509916116903e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.2690053615924346e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7093978733165829942) ) ) {
                  result[0] += 7.770264867915519e-07;
                } else {
                  result[0] += -3.01337826194602e-06;
                }
              } else {
                result[0] += -3.2690053615924346e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
            result[0] += 3.971136144612162e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7326471166347855446) ) ) {
              result[0] += -0.00010992881489447659;
            } else {
              result[0] += 5.567770171351352e-06;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -3.2690053615924346e-06;
                } else {
                  result[0] += -3.2690053615924346e-06;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -3.2164730214389984e-06;
                } else {
                  result[0] += -3.2690053615924346e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -3.2690053615924346e-06;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -3.2690053615924346e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -3.2690053615924346e-06;
                      } else {
                        result[0] += -3.2690053615924346e-06;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -3.2690053615924346e-06;
                      } else {
                        result[0] += -3.2690053615924346e-06;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -3.2690053615924346e-06;
                        } else {
                          result[0] += -3.2690053615924346e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -3.2690053615924346e-06;
                        } else {
                          result[0] += -3.2690053615924346e-06;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -3.2690053615924346e-06;
                    } else {
                      result[0] += -3.2690053615924346e-06;
                    }
                  }
                }
              } else {
                result[0] += -3.2690053615924346e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -3.2690053615924346e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -3.2690053615924346e-06;
                  } else {
                    result[0] += -3.2690053615924346e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -3.2690053615924346e-06;
                  } else {
                    result[0] += -3.2690053615924346e-06;
                  }
                }
              } else {
                result[0] += -3.2690053615924346e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
            result[0] += -6.290509730756445e-05;
          } else {
            result[0] += 1.1673405966558099e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8050000000000001599) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01287800000000000229) ) ) {
            result[0] += -1.3907254601235625e-05;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.039722088301102687) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8030059940338053481) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7077536600502513098) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01467829982783020078) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725302343969849939) ) ) {
                        result[0] += 0.0008021699858510916;
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01326604349644140181) ) ) {
                          result[0] += -9.010653814641897e-05;
                        } else {
                          result[0] += -0.001407898547253012;
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3569067370100503234) ) ) {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03291917222295825951) ) ) {
                          result[0] += 0.0005411017121191541;
                        } else {
                          result[0] += -0.0017662260306142905;
                        }
                      } else {
                        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4601878067544193374) ) ) {
                          result[0] += 0.0023356799204135486;
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
                            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4405029099497487777) ) ) {
                              result[0] += 0.0006766001586049135;
                            } else {
                              result[0] += -0.0014011463502333508;
                            }
                          } else {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4693879269597989734) ) ) {
                              result[0] += 0.002686833079974505;
                            } else {
                              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2177889902755587859) ) ) {
                                result[0] += -0.0005829991833787981;
                              } else {
                                result[0] += 0.00048284564932023997;
                              }
                            }
                          }
                        }
                      }
                    }
                  } else {
                    result[0] += 0.001565455732545281;
                  }
                } else {
                  result[0] += -0.0002320698968759465;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0110643527143887508) ) ) {
                  result[0] += -0.00017605403767714125;
                } else {
                  result[0] += 0.0010843838331375474;
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8022705390703518402) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03729562354052295275) ) ) {
                  result[0] += -0.00015450570686130434;
                } else {
                  result[0] += -0.0019534875737368634;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.459978591867425068) ) ) {
                  result[0] += -9.569771305168035e-05;
                } else {
                  result[0] += 0.000594867181025329;
                }
              }
            }
          }
        } else {
          result[0] += 0.0001989626102905895;
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0002425778817922091;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              result[0] += -0.00044042660720359573;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
                result[0] += 0.00028865850075541317;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07316210697219156789) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06949760265420222571) ) ) {
                    result[0] += 9.29450420007121e-05;
                  } else {
                    result[0] += -0.0006756955037986888;
                  }
                } else {
                  result[0] += 0.00024731552567849266;
                }
              }
            }
          } else {
            result[0] += 0.00027951880944783816;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -2.502192895400453e-06;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += 2.8928542951121533e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -3.127741090121096e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7093978733165829942) ) ) {
                  result[0] += 7.434486646624771e-07;
                } else {
                  result[0] += -2.8831604624150916e-06;
                }
              } else {
                result[0] += -3.127741090121096e-06;
              }
            }
          }
        } else {
          result[0] += 5.287791793000231e-07;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -3.127741090121096e-06;
                } else {
                  result[0] += -3.127741090121096e-06;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -3.0774788419190676e-06;
                } else {
                  result[0] += -3.127741090121096e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -3.127741090121096e-06;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -3.127741090121096e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -3.127741090121096e-06;
                      } else {
                        result[0] += -3.127741090121096e-06;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -3.127741090121096e-06;
                      } else {
                        result[0] += -3.127741090121096e-06;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -3.127741090121096e-06;
                        } else {
                          result[0] += -3.127741090121096e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -3.127741090121096e-06;
                        } else {
                          result[0] += -3.127741090121096e-06;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -3.127741090121096e-06;
                    } else {
                      result[0] += -3.127741090121096e-06;
                    }
                  }
                }
              } else {
                result[0] += -3.127741090121096e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -3.127741090121096e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  result[0] += -3.127741090121096e-06;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -3.127741090121096e-06;
                  } else {
                    result[0] += -3.127741090121096e-06;
                  }
                }
              } else {
                result[0] += -3.127741090121096e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
            result[0] += -6.01867650443656e-05;
          } else {
            result[0] += 1.1168960422103038e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03409611752714010457) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3103100527046326884) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00922340305469475201) ) ) {
              result[0] += 2.247692642335364e-05;
            } else {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4026472078210281969) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4405029099497487777) ) ) {
                  result[0] += 0.0006370569535539419;
                } else {
                  result[0] += -0.004727573726955234;
                }
              } else {
                result[0] += 0.0009339765484458188;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4529241356532663354) ) ) {
                result[0] += -0.00017431001684506137;
              } else {
                result[0] += -0.0008877120828138197;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4643511832914573034) ) ) {
                result[0] += 0.001118976240935494;
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2677063317952667609) ) ) {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2795185878002977575) ) ) {
                    result[0] += 0.0006880953873303545;
                  } else {
                    result[0] += -0.001162555803592544;
                  }
                } else {
                  result[0] += -1.1904095578884903e-05;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5190499213819096402) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.04779931491322893938) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2929122217587940002) ) ) {
                  result[0] += -0.0020419968184363225;
                } else {
                  result[0] += 0.00036241204832506584;
                }
              } else {
                result[0] += -0.0014360722786723012;
              }
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1044543990012605922) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5478500007788945636) ) ) {
                  result[0] += 9.17045073956619e-05;
                } else {
                  result[0] += -0.002902617080620708;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5792515097236182742) ) ) {
                  result[0] += 0.0009492345741557766;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08407783631914581002) ) ) {
                    result[0] += -0.0010998254065558621;
                  } else {
                    result[0] += 0.00041476570007281845;
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6116569490452262725) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6077784371608041525) ) ) {
                result[0] += -0.0005809612376137003;
              } else {
                result[0] += -0.0026745050011191393;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7760221401809592745) ) ) {
                result[0] += 0.0004763943095030016;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8158067323869347964) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.166761325528187454) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8577098326317653676) ) ) {
                      result[0] += -0.0009150752926014393;
                    } else {
                      result[0] += 3.4489047590080295e-05;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7875164333668343009) ) ) {
                      result[0] += -0.002227435460806708;
                    } else {
                      result[0] += -0.0008556101804513911;
                    }
                  }
                } else {
                  result[0] += 0.00040104212565144763;
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.00023209530866796766;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3763200711443456803) ) ) {
              result[0] += 0.00026854927911048476;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4364163272837385255) ) ) {
                result[0] += -0.00025780097408648777;
              } else {
                result[0] += 0.00013795685817329252;
              }
            }
          } else {
            result[0] += 0.00026743989962312156;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -2.394065065265185e-06;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += 2.7678447251453444e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.992581303710806e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7093978733165829942) ) ) {
                  result[0] += 7.113218485905928e-07;
                } else {
                  result[0] += -2.75856979424328e-06;
                }
              } else {
                result[0] += -2.992581303710806e-06;
              }
            }
          }
        } else {
          result[0] += 5.059289244761391e-07;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -2.992581303710806e-06;
                } else {
                  result[0] += -2.992581303710806e-06;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -2.9444910494608808e-06;
                } else {
                  result[0] += -2.992581303710806e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -2.992581303710806e-06;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -2.992581303710806e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -2.992581303710806e-06;
                      } else {
                        result[0] += -2.992581303710806e-06;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -2.992581303710806e-06;
                      } else {
                        result[0] += -2.992581303710806e-06;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -2.992581303710806e-06;
                        } else {
                          result[0] += -2.992581303710806e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -2.992581303710806e-06;
                        } else {
                          result[0] += -2.992581303710806e-06;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -2.992581303710806e-06;
                    } else {
                      result[0] += -2.992581303710806e-06;
                    }
                  }
                }
              } else {
                result[0] += -2.992581303710806e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -2.992581303710806e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -2.992581303710806e-06;
                  } else {
                    result[0] += -2.992581303710806e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -2.992581303710806e-06;
                  } else {
                    result[0] += -2.992581303710806e-06;
                  }
                }
              } else {
                result[0] += -2.992581303710806e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
            result[0] += -5.7585900690913696e-05;
          } else {
            result[0] += 1.0686313597580237e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05473596564878090848) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3103100527046326884) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4931942899748744114) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4636504894974874946) ) ) {
                result[0] += 0.0001940746375989814;
              } else {
                result[0] += 0.0012057688057882496;
              }
            } else {
              result[0] += -0.0009650747539704973;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003965500000000001142) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1189475733471909297) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4529241356532663354) ) ) {
                    result[0] += 0.001032256151005058;
                  } else {
                    result[0] += -0.00038694304102018074;
                  }
                } else {
                  result[0] += -0.0011590722206924707;
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005707500000000000767) ) ) {
                  result[0] += -0.002010979846842969;
                } else {
                  result[0] += -0.0010156652042180902;
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4643511832914573034) ) ) {
                result[0] += 0.001145314812418584;
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2677063317952667609) ) ) {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2795185878002977575) ) ) {
                    result[0] += 0.00065836056500915;
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4050000000000000822) ) ) {
                      result[0] += -0.0016755338606396469;
                    } else {
                      result[0] += -0.0005641398715003954;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4751828078391960308) ) ) {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2302999793555680907) ) ) {
                      result[0] += 0.0003270446427417417;
                    } else {
                      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1750000000000000167) ) ) {
                        result[0] += 0.00047000629300923555;
                      } else {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004848500000000001246) ) ) {
                          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001134500000000000309) ) ) {
                            result[0] += -0.0017725708677396312;
                          } else {
                            result[0] += -0.0021661673743606845;
                          }
                        } else {
                          result[0] += -0.0005858990603622368;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4797597438944724013) ) ) {
                      result[0] += 0.0010148244878190663;
                    } else {
                      result[0] += -2.1003810606979286e-06;
                    }
                  }
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2929122217587940002) ) ) {
              result[0] += -0.002501772623672752;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1250629713251516228) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5309997332914574431) ) ) {
                  result[0] += 0.00027609540269948055;
                } else {
                  result[0] += 0.0006976146055460447;
                }
              } else {
                result[0] += 0.0001578916518842095;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7894192122613066243) ) ) {
              result[0] += -0.0018136196919645339;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003024500000000000712) ) ) {
                result[0] += -0.0005123109171039692;
              } else {
                result[0] += 0.00013247151879807278;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.00022206572135798403;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              result[0] += -0.00042961320675134583;
            } else {
              result[0] += 0.00023066666261381576;
            }
          } else {
            result[0] += 0.00025588295847322443;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -2.2906097876222954e-06;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += 2.6482372221301483e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.8632622078615646e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7093978733165829942) ) ) {
                  result[0] += 6.805833359214527e-07;
                } else {
                  result[0] += -2.6393630909245723e-06;
                }
              } else {
                result[0] += -2.8632622078615646e-06;
              }
            }
          }
        } else {
          result[0] += 4.840661029059768e-07;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -2.8632622078615646e-06;
                } else {
                  result[0] += -2.8632622078615646e-06;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -2.817250088695572e-06;
                } else {
                  result[0] += -2.8632622078615646e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -2.8632622078615646e-06;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -2.8632622078615646e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -2.8632622078615646e-06;
                      } else {
                        result[0] += -2.8632622078615646e-06;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -2.8632622078615646e-06;
                      } else {
                        result[0] += -2.8632622078615646e-06;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -2.8632622078615646e-06;
                        } else {
                          result[0] += -2.8632622078615646e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -2.8632622078615646e-06;
                        } else {
                          result[0] += -2.8632622078615646e-06;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -2.8632622078615646e-06;
                    } else {
                      result[0] += -2.8632622078615646e-06;
                    }
                  }
                }
              } else {
                result[0] += -2.8632622078615646e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -2.8632622078615646e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  result[0] += -2.8632622078615646e-06;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -2.8632622078615646e-06;
                  } else {
                    result[0] += -2.8632622078615646e-06;
                  }
                }
              } else {
                result[0] += -2.8632622078615646e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
            result[0] += -5.509742807973387e-05;
          } else {
            result[0] += 1.0224523499952175e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03603011311338780859) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3103100527046326884) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.009602467408789250661) ) ) {
              result[0] += 3.137606444266359e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4636504894974874946) ) ) {
                result[0] += 0.0006373391728981147;
              } else {
                result[0] += 0.001282143391352998;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4529241356532663354) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4295075599497487628) ) ) {
                  result[0] += -0.0006554983877657881;
                } else {
                  if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1189475733471909297) ) ) {
                    result[0] += 0.001437684790947908;
                  } else {
                    result[0] += -0.0003493641560942204;
                  }
                }
              } else {
                result[0] += -0.0008643127848361361;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4643511832914573034) ) ) {
                result[0] += 0.0010351481303953515;
              } else {
                result[0] += -1.5409461118422516e-05;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2929122217587940002) ) ) {
            result[0] += -0.0023936629548351597;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2323027026914575854) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5190499213819096402) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.04779931491322893938) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4992002680402010117) ) ) {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01724500000000000338) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01387300000000000165) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4443392717336683839) ) ) {
                          result[0] += -0.00023816126786013243;
                        } else {
                          result[0] += 0.0010877994333405815;
                        }
                      } else {
                        result[0] += -0.002018781298405732;
                      }
                    } else {
                      result[0] += 0.001202681977576083;
                    }
                  } else {
                    result[0] += -0.0006468759792168735;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
                    result[0] += -0.0025832446932498873;
                  } else {
                    result[0] += -0.0001473934647930563;
                  }
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5792515097236182742) ) ) {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1044543990012605922) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01262450000000000204) ) ) {
                      result[0] += 6.882108752812373e-05;
                    } else {
                      result[0] += -0.0026470422764742632;
                    }
                  } else {
                    result[0] += 0.0011894584698142546;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5829435000502513065) ) ) {
                    result[0] += -0.001635142970427669;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1908722399174398732) ) ) {
                      result[0] += -4.1516918496608896e-05;
                    } else {
                      result[0] += 0.001750329635645632;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6116569490452262725) ) ) {
                result[0] += -0.0010682292494184002;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8030059940338053481) ) ) {
                  result[0] += 0.0005434789984069563;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9112103514676580529) ) ) {
                      result[0] += -0.0015596163974006367;
                    } else {
                      result[0] += -1.5603896315922914e-05;
                    }
                  } else {
                    result[0] += 7.778591726525553e-05;
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.00021246954488334248;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
            result[0] += 0.00019604551726052697;
          } else {
            result[0] += 0.00024482543004719474;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -2.1916251463992315e-06;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += 2.5337983453198507e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.739531407485041e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7093978733165829942) ) ) {
                  result[0] += 6.511731335846651e-07;
                } else {
                  result[0] += -2.525307693962429e-06;
                }
              } else {
                result[0] += -2.739531407485041e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
            result[0] += 3.733899401188528e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7326471166347855446) ) ) {
              result[0] += -0.00010524406717339031;
            } else {
              result[0] += 5.261537718944314e-06;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -2.739531407485041e-06;
                } else {
                  result[0] += -2.739531407485041e-06;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -2.695507620479406e-06;
                } else {
                  result[0] += -2.739531407485041e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -2.739531407485041e-06;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -2.739531407485041e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -2.739531407485041e-06;
                      } else {
                        result[0] += -2.739531407485041e-06;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -2.739531407485041e-06;
                      } else {
                        result[0] += -2.739531407485041e-06;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -2.739531407485041e-06;
                        } else {
                          result[0] += -2.739531407485041e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -2.739531407485041e-06;
                        } else {
                          result[0] += -2.739531407485041e-06;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -2.739531407485041e-06;
                    } else {
                      result[0] += -2.739531407485041e-06;
                    }
                  }
                }
              } else {
                result[0] += -2.739531407485041e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -2.739531407485041e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -2.739531407485041e-06;
                  } else {
                    result[0] += -2.739531407485041e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -2.739531407485041e-06;
                  } else {
                    result[0] += -2.739531407485041e-06;
                  }
                }
              } else {
                result[0] += -2.739531407485041e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
            result[0] += -5.2716490400929766e-05;
          } else {
            result[0] += 9.7826888427405e-07;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05473596564878090848) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3103100527046326884) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4052145559547739029) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.578971790991679312e-05) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3644118032412060892) ) ) {
                  result[0] += -0.00028184385984866535;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                    result[0] += -0.00045293454436167444;
                  } else {
                    result[0] += -0.0021365213614895507;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002194500000000000704) ) ) {
                  if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6782348568386622478) ) ) {
                    result[0] += 0.00023589461564691515;
                  } else {
                    result[0] += 0.0018814805746458175;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01657900000000000346) ) ) {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.9159493641278110276) ) ) {
                      result[0] += 0.000757151803593786;
                    } else {
                      result[0] += -0.0008059158086277386;
                    }
                  } else {
                    result[0] += 0.0008764015668309927;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4931942899748744114) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4636504894974874946) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4251092621105527214) ) ) {
                    result[0] += 0.0007783663735840947;
                  } else {
                    result[0] += -7.20494917748074e-06;
                  }
                } else {
                  result[0] += 0.0011399255474902647;
                }
              } else {
                result[0] += -0.0009247266203456477;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4295075599497487628) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003882500000000000534) ) ) {
                result[0] += -2.5029109362457245e-05;
              } else {
                result[0] += -0.0013996619897151661;
              }
            } else {
              result[0] += -2.567313187304636e-06;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2929122217587940002) ) ) {
              result[0] += -0.002290225053681642;
            } else {
              result[0] += 0.0003233618303880256;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7894192122613066243) ) ) {
              result[0] += -0.00172711100190175;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003024500000000000712) ) ) {
                result[0] += -0.0004935336895535065;
              } else {
                result[0] += 0.0001187863065613144;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0002032880501631365;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6269304705026225166) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6458133101595427972) ) ) {
                result[0] += 0.00023899016876117971;
              } else {
                result[0] += 0.00033564655330188786;
              }
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5724391781153673753) ) ) {
                result[0] += -0.0004709270567766735;
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4601878067544193374) ) ) {
                  result[0] += 0.00027460546261980605;
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.378188349821562797) ) ) {
                    result[0] += -0.0003936342419416697;
                  } else {
                    result[0] += 0.0001829058212656522;
                  }
                }
              }
            }
          } else {
            result[0] += 0.00023424573310952112;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -2.096917950968558e-06;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += 2.4243047416958824e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.6211474142992034e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                result[0] += 1.8917311825626064e-10;
              } else {
                result[0] += -2.6211474142992034e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
            result[0] += 3.5725455579512736e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7326471166347855446) ) ) {
              result[0] += -0.00010069613138515167;
            } else {
              result[0] += 5.034169693973083e-06;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -2.6211474142992034e-06;
                } else {
                  result[0] += -2.6211474142992034e-06;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -2.5790260372044933e-06;
                } else {
                  result[0] += -2.6211474142992034e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -2.6211474142992034e-06;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -2.6211474142992034e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -2.6211474142992034e-06;
                      } else {
                        result[0] += -2.6211474142992034e-06;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -2.6211474142992034e-06;
                      } else {
                        result[0] += -2.6211474142992034e-06;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -2.6211474142992034e-06;
                        } else {
                          result[0] += -2.6211474142992034e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -2.6211474142992034e-06;
                        } else {
                          result[0] += -2.6211474142992034e-06;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -2.6211474142992034e-06;
                    } else {
                      result[0] += -2.6211474142992034e-06;
                    }
                  }
                }
              } else {
                result[0] += -2.6211474142992034e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -2.6211474142992034e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -2.6211474142992034e-06;
                  } else {
                    result[0] += -2.6211474142992034e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -2.6211474142992034e-06;
                  } else {
                    result[0] += -2.6211474142992034e-06;
                  }
                }
              } else {
                result[0] += -2.6211474142992034e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
            result[0] += -5.0438440723034626e-05;
          } else {
            result[0] += 9.359947286964237e-07;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05473596564878090848) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3103100527046326884) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4931942899748744114) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4636504894974874946) ) ) {
                result[0] += 0.0001891863997055244;
              } else {
                result[0] += 0.0010906656857935756;
              }
            } else {
              result[0] += -0.0008847661987849932;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004054500000000000812) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1189475733471909297) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4529241356532663354) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4295075599497487628) ) ) {
                      result[0] += 0.0005002287770979621;
                    } else {
                      result[0] += 0.0016721739142928;
                    }
                  } else {
                    result[0] += -0.0003127149704632834;
                  }
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.125515493975159704e-06) ) ) {
                    result[0] += -0.0017604690741037572;
                  } else {
                    result[0] += -9.965435585102878e-05;
                  }
                }
              } else {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1587324468652908105) ) ) {
                  result[0] += -0.0015394939556773533;
                } else {
                  result[0] += -0.0003632931763379143;
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4643511832914573034) ) ) {
                result[0] += 0.001050063297357004;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4674830972361809223) ) ) {
                  result[0] += -0.0006067330292819316;
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2677063317952667609) ) ) {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2795185878002977575) ) ) {
                      result[0] += 0.0006306875147539787;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4814085394974874643) ) ) {
                        result[0] += -0.00013612689436983934;
                      } else {
                        result[0] += -0.002332240167840783;
                      }
                    }
                  } else {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2177889902755587859) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01195250000000000305) ) ) {
                        result[0] += 0.0005539620918253589;
                      } else {
                        result[0] += -0.0016450788450607507;
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4751828078391960308) ) ) {
                        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1750000000000000167) ) ) {
                          result[0] += 0.0007395287214799081;
                        } else {
                          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003292500000000000288) ) ) {
                            result[0] += -0.0018180128182046207;
                          } else {
                            result[0] += -0.0006924663257195157;
                          }
                        }
                      } else {
                        result[0] += -1.56693373284013e-06;
                      }
                    }
                  }
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2929122217587940002) ) ) {
              result[0] += -0.0021912570380537505;
            } else {
              result[0] += 0.0003093883221374439;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7894192122613066243) ) ) {
              result[0] += -0.0016524769617437564;
            } else {
              result[0] += -7.538743905534765e-05;
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0001945033174604857;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2302999793555680907) ) ) {
              result[0] += 0.0002614502963967727;
            } else {
              result[0] += 6.0403978704081277e-05;
            }
          } else {
            result[0] += 0.0002241232190195285;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -2.0063033590932865e-06;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += 2.319542710044331e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.507879175510024e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                result[0] += 1.8099833731328472e-10;
              } else {
                result[0] += -2.507879175510024e-06;
              }
            }
          }
        } else {
          result[0] += 1.4741297822795488e-07;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -2.507879175510024e-06;
                } else {
                  result[0] += -2.507879175510024e-06;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -2.467577999054494e-06;
                } else {
                  result[0] += -2.507879175510024e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -2.507879175510024e-06;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -2.507879175510024e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -2.507879175510024e-06;
                      } else {
                        result[0] += -2.507879175510024e-06;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -2.507879175510024e-06;
                      } else {
                        result[0] += -2.507879175510024e-06;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -2.507879175510024e-06;
                        } else {
                          result[0] += -2.507879175510024e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -2.507879175510024e-06;
                        } else {
                          result[0] += -2.507879175510024e-06;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -2.507879175510024e-06;
                    } else {
                      result[0] += -2.507879175510024e-06;
                    }
                  }
                }
              } else {
                result[0] += -2.507879175510024e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -2.507879175510024e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -2.507879175510024e-06;
                  } else {
                    result[0] += -2.507879175510024e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -2.507879175510024e-06;
                  } else {
                    result[0] += -2.507879175510024e-06;
                  }
                }
              } else {
                result[0] += -2.507879175510024e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
            result[0] += -4.825883292348703e-05;
          } else {
            result[0] += 8.955473758092741e-07;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.03945373639888280493) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006782232836504950395) ) ) {
            if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.05580247069824354617) ) ) {
              result[0] += 1.8643154288334646e-05;
            } else {
              result[0] += -0.00022698762059206062;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5748180127889448432) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003024500000000000712) ) ) {
                result[0] += 0.0004096486265799293;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02733191529475900369) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00342950000000000069) ) ) {
                    result[0] += -0.0006801798109179756;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.564198853668341882) ) ) {
                      result[0] += 0.00017619341023699295;
                    } else {
                      result[0] += 0.00204663756178094;
                    }
                  }
                } else {
                  result[0] += 0.0015376179582241086;
                }
              }
            } else {
              result[0] += -0.001206279906151418;
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1076318469022627677) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0816878293504414571) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
                result[0] += 0.0006738050598057291;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.0442771331626926e-05) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5701775282412061552) ) ) {
                    result[0] += 0.0005436002341106902;
                  } else {
                    result[0] += -0.0003954680835294351;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09341808925382111273) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.08500000000000000611) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006626010166593451593) ) ) {
                        result[0] += -8.835344316238861e-05;
                      } else {
                        result[0] += -0.000724795300966326;
                      }
                    } else {
                      result[0] += -0.00019827182065959754;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5424744603768845153) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01278116174711865262) ) ) {
                        result[0] += -0.0007033394519733462;
                      } else {
                        result[0] += -0.0036518237341878015;
                      }
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01940114940222455522) ) ) {
                        result[0] += -0.0013877601034023143;
                      } else {
                        result[0] += 0.000255236152451497;
                      }
                    }
                  }
                }
              }
            } else {
              result[0] += 0.0007985932279821361;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1206324332205917643) ) ) {
              result[0] += 0.0005698200280427283;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5687531224874372571) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5408295445477387942) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5336217185678392427) ) ) {
                    result[0] += -0.0001316745801210494;
                  } else {
                    result[0] += 0.0011806994432385378;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3212986210119083141) ) ) {
                    result[0] += -0.0003959010820185316;
                  } else {
                    result[0] += -0.0016572954613861583;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5800027599246232457) ) ) {
                  result[0] += 0.0005464575479537137;
                } else {
                  result[0] += 1.130530618595442e-06;
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0001860982014081726;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2302999793555680907) ) ) {
              result[0] += 0.0002214011303585138;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1251234928765115051) ) ) {
                result[0] += 9.506012125169502e-06;
              } else {
                result[0] += 0.00022091574930394321;
              }
            }
          } else {
            result[0] += 0.00021443813143093415;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -1.9196045161660914e-06;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += 2.2193077838705085e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -2.399505622860362e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                result[0] += 1.7317681503666493e-10;
              } else {
                result[0] += -2.399505622860362e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
            result[0] += 3.4117941444813197e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7326471166347855446) ) ) {
              result[0] += -9.635109677003206e-05;
            } else {
              result[0] += 4.810256784604092e-06;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -2.399505622860362e-06;
                } else {
                  result[0] += -2.399505622860362e-06;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -2.360945990300207e-06;
                } else {
                  result[0] += -2.399505622860362e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -2.399505622860362e-06;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -2.399505622860362e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -2.399505622860362e-06;
                      } else {
                        result[0] += -2.399505622860362e-06;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -2.399505622860362e-06;
                      } else {
                        result[0] += -2.399505622860362e-06;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.310012234630710122e-06) ) ) {
                            result[0] += -2.399505622860362e-06;
                          } else {
                            result[0] += -2.399505622860362e-06;
                          }
                        } else {
                          result[0] += -2.399505622860362e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -2.399505622860362e-06;
                        } else {
                          result[0] += -2.399505622860362e-06;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -2.399505622860362e-06;
                    } else {
                      result[0] += -2.399505622860362e-06;
                    }
                  }
                }
              } else {
                result[0] += -2.399505622860362e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -2.399505622860362e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -2.399505622860362e-06;
                  } else {
                    result[0] += -2.399505622860362e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -2.399505622860362e-06;
                  } else {
                    result[0] += -2.399505622860362e-06;
                  }
                }
              } else {
                result[0] += -2.399505622860362e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
            result[0] += -4.617341301103007e-05;
          } else {
            result[0] += 8.568478835728528e-07;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07316210697219156789) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5361772370603016258) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5336217185678392427) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.07196201389915944657) ) ) {
                result[0] += 0.00014327980480127001;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5309997332914574431) ) ) {
                  result[0] += -8.829290157332125e-05;
                } else {
                  result[0] += -0.0008733629787904036;
                }
              }
            } else {
              result[0] += 0.0008391166857352975;
            }
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1044543990012605922) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01590200000000000294) ) ) {
                result[0] += -0.0001866052238151902;
              } else {
                result[0] += -0.005049899904153941;
              }
            } else {
              result[0] += -9.21289372440549e-06;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3569067370100503234) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0480970000000000078) ) ) {
              result[0] += -0.0021860597273904137;
            } else {
              result[0] += 0.0002854579137840287;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5309997332914574431) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.01537695356895864805) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5041457217085428821) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4838161673366834781) ) ) {
                      result[0] += 0.0003773099954943166;
                    } else {
                      result[0] += 0.0014344123181932935;
                    }
                  } else {
                    result[0] += -0.0006556610244379077;
                  }
                } else {
                  result[0] += -0.001654071499537465;
                }
              } else {
                result[0] += 0.0007398006209150566;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5628434130653267031) ) ) {
                result[0] += -0.0016252332640435494;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0846450000000000119) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2739990068871500095) ) ) {
                    result[0] += -0.0006486224981349046;
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03468100000000001043) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8025985781909549255) ) ) {
                        result[0] += 0.000370081005122396;
                      } else {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003024500000000000712) ) ) {
                          result[0] += -0.0007187095239944276;
                        } else {
                          result[0] += 0.0005360012400457431;
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                        result[0] += -0.00309335771426103;
                      } else {
                        result[0] += 0.00027669528711041864;
                      }
                    }
                  }
                } else {
                  result[0] += 0.0008499348757495469;
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0001780562975456349;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2302999793555680907) ) ) {
              result[0] += 0.00021183367300573957;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1251234928765115051) ) ) {
                result[0] += 9.095226663257753e-06;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09956041386891252565) ) ) {
                  result[0] += 0.00021136926683296806;
                } else {
                  result[0] += 9.227843368330014e-05;
                }
              }
            }
          } else {
            result[0] += 0.00020517156773294334;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -1.836652210037979e-06;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6299505656030152112) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.244955337349149066) ) ) {
            result[0] += -5.2894909968553395e-05;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4781247323869347032) ) ) {
              result[0] += 0.001343630272791823;
            } else {
              result[0] += 1.033031054082711e-07;
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4677590045467516222) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.485713013107980879e-05) ) ) {
              result[0] += -2.2958152411659043e-06;
            } else {
              result[0] += -6.841863359883335e-05;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7211604863065327331) ) ) {
              result[0] += -5.577021205263687e-07;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.016289495364576286e-06) ) ) {
                result[0] += -2.2958152411659043e-06;
              } else {
                result[0] += -5.4374394592036236e-05;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -2.2958152411659043e-06;
                } else {
                  result[0] += -2.2958152411659043e-06;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -2.2589218947690607e-06;
                } else {
                  result[0] += -2.2958152411659043e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -2.2958152411659043e-06;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -2.2958152411659043e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -2.2958152411659043e-06;
                      } else {
                        result[0] += -2.2958152411659043e-06;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -2.2958152411659043e-06;
                      } else {
                        result[0] += -2.2958152411659043e-06;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -2.2958152411659043e-06;
                        } else {
                          result[0] += -2.2958152411659043e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -2.2958152411659043e-06;
                        } else {
                          result[0] += -2.2958152411659043e-06;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -2.2958152411659043e-06;
                    } else {
                      result[0] += -2.2958152411659043e-06;
                    }
                  }
                }
              } else {
                result[0] += -2.2958152411659043e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -2.2958152411659043e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -2.2958152411659043e-06;
                  } else {
                    result[0] += -2.2958152411659043e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -2.2958152411659043e-06;
                  } else {
                    result[0] += -2.2958152411659043e-06;
                  }
                }
              } else {
                result[0] += -2.2958152411659043e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
            result[0] += -4.4178110823097596e-05;
          } else {
            result[0] += 8.198207212877123e-07;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.576152860085799078e-06) ) ) {
          result[0] += -6.760268053994836e-05;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1450000000000000455) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1250000000000000278) ) ) {
                result[0] += 3.115467990718049e-05;
              } else {
                result[0] += -0.0009054962164387374;
              }
            } else {
              result[0] += 0.0009285588076614607;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.03945373639888280493) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5687531224874372571) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02733191529475900369) ) ) {
                  result[0] += 0.00012751968529379565;
                } else {
                  result[0] += 0.001044368954493567;
                }
              } else {
                result[0] += -0.0005072835482161741;
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1076318469022627677) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03409611752714010457) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
                    result[0] += 0.0007435230357799235;
                  } else {
                    result[0] += -0.0005136051383391959;
                  }
                } else {
                  result[0] += 0.00024648748822732645;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1206324332205917643) ) ) {
                  result[0] += 0.000611376646664005;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4287309711685468594) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4036106884780860105) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6577150591959800563) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3561404984221285264) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3115605993075549196) ) ) {
                            result[0] += 3.931472445905777e-05;
                          } else {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.576481470050251299) ) ) {
                              result[0] += -0.004428674453545796;
                            } else {
                              result[0] += -0.0004791570370685377;
                            }
                          }
                        } else {
                          result[0] += 0.0007017840985812935;
                        }
                      } else {
                        result[0] += -0.0004052763630441447;
                      }
                    } else {
                      result[0] += -0.0005949155995757645;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6915080527790725684) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6722423356281408413) ) ) {
                        result[0] += -1.2945216723155878e-05;
                      } else {
                        result[0] += 0.00037868976818748203;
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                        result[0] += -0.00025015911873235236;
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7210440605025126848) ) ) {
                          result[0] += 0.0007967652008352252;
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.717118227269369246) ) ) {
                            result[0] += -2.6092448160406457e-05;
                          } else {
                            result[0] += 0.00042857020998756095;
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.00017036191030198245;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2302999793555680907) ) ) {
              result[0] += 0.00020267965636146248;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1251234928765115051) ) ) {
                result[0] += 8.702192566848078e-06;
              } else {
                result[0] += 0.0002022353186781556;
              }
            }
          } else {
            result[0] += 0.00019630544215757731;
          }
        }
      }
    }
  }
}

