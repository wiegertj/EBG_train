
#include "header.h"

void predict_unit5(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.00012206368214911459;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002295101748406000225) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1523979577405769892) ) ) {
                  result[0] += -0.00022261709277063093;
                } else {
                  result[0] += -5.310637766846487e-05;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
                  result[0] += -0.0001525796012653851;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                      result[0] += 0.00014793087127710214;
                    } else {
                      result[0] += -0.00015404022373209783;
                    }
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.016289495364576286e-06) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9808239647505231362) ) ) {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                          result[0] += -0.0001525796012653851;
                        } else {
                          result[0] += -0.0001525796012653851;
                        }
                      } else {
                        result[0] += -0.0001525796012653851;
                      }
                    } else {
                      result[0] += -0.0001525796012653851;
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.701692321267631473e-05) ) ) {
                result[0] += -5.854205980130922e-05;
              } else {
                result[0] += -0.00017634081739563204;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7463838234422112139) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03500000000000001027) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5494686760804020631) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01704648841990550126) ) ) {
                    result[0] += -0.0001292230318923579;
                  } else {
                    result[0] += 0.0008100638985668047;
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08693186820944626136) ) ) {
                    result[0] += -0.0004592482028576273;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6100010069597990858) ) ) {
                      result[0] += 6.061121977487145e-05;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6208328749497488142) ) ) {
                        result[0] += -0.0002726937707748191;
                      } else {
                        result[0] += -9.845197366015827e-05;
                      }
                    }
                  }
                }
              } else {
                result[0] += 0.0022875288918306684;
              }
            } else {
              result[0] += -0.00015341460911412255;
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -0.0001525796012653851;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.310012234630710122e-06) ) ) {
                      result[0] += -0.0001525796012653851;
                    } else {
                      result[0] += -0.0001525796012653851;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8254037945979900703) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                        result[0] += -0.0001525796012653851;
                      } else {
                        result[0] += -0.0001525796012653851;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7894192122613066243) ) ) {
                          result[0] += -0.0001525796012653851;
                        } else {
                          result[0] += -0.0001525796012653851;
                        }
                      } else {
                        result[0] += -0.0001525796012653851;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005013289129500051074) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8419399877135679278) ) ) {
                        result[0] += -0.0001525796012653851;
                      } else {
                        result[0] += -0.0001525796012653851;
                      }
                    } else {
                      result[0] += -0.0001525796012653851;
                    }
                  }
                }
              } else {
                result[0] += -0.0001525796012653851;
              }
            } else {
              result[0] += -0.00019995257648154573;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
              result[0] += -0.0001750808518217315;
            } else {
              result[0] += -2.3632792511186887e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -0.0001525796012653851;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                    result[0] += -0.0001525796012653851;
                  } else {
                    result[0] += -0.0001525796012653851;
                  }
                } else {
                  result[0] += -0.0001525796012653851;
                }
              } else {
                result[0] += -0.0001525796012653851;
              }
            } else {
              result[0] += -0.0001525796012653851;
            }
          }
        } else {
          result[0] += -0.00024696183675741175;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8050000000000001599) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3850000000000000644) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.05580247069824354617) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02129391514754680123) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
              result[0] += -0.0005028811839348758;
            } else {
              result[0] += 0.0004874636362027561;
            }
          } else {
            result[0] += 0.0024510553072200096;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
            result[0] += -9.604395395149197e-05;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02577363736079425413) ) ) {
              result[0] += 4.702329794185303e-05;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02722700000000000467) ) ) {
                result[0] += 0.00020762081117621438;
              } else {
                result[0] += 0.0016201666776749523;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0119121105025029022) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006452000000000001137) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2850000000000000866) ) ) {
                result[0] += -0.0013874450962789962;
              } else {
                result[0] += 0.0010794324628778916;
              }
            } else {
              result[0] += -0.0002747664284023404;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3115605993075549196) ) ) {
              result[0] += 0.002119532909153986;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4050000000000000822) ) ) {
                result[0] += -0.0009893941570639734;
              } else {
                result[0] += 0.0012703038847951937;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00984850000000000135) ) ) {
            result[0] += 0.0016780763648038366;
          } else {
            result[0] += -0.0002124930241865044;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9750000000000000888) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03469629566125685682) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006585500000000000208) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006782232836504950395) ) ) {
              result[0] += 0.004211404403292205;
            } else {
              result[0] += 0.006324156996343357;
            }
          } else {
            result[0] += 0.002987910872905065;
          }
        } else {
          result[0] += 0.006645576667610421;
        }
      } else {
        result[0] += 0.008428747616276447;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.00011678891651719037;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002295101748406000225) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5687531224874372571) ) ) {
                  result[0] += -4.3845628506867744e-05;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4677590045467516222) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6249533869346735049) ) ) {
                      result[0] += -0.00018385375264353692;
                    } else {
                      result[0] += -0.0001459861442868862;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.584873521522560625e-06) ) ) {
                        result[0] += 0.00011429992845689188;
                      } else {
                        result[0] += -0.00014718189807320724;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9567162861906464144) ) ) {
                          result[0] += -0.0001459861442868862;
                        } else {
                          result[0] += -0.0001459861442868862;
                        }
                      } else {
                        result[0] += -0.0001459861442868862;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.00017748385341825721;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.701692321267631473e-05) ) ) {
                result[0] += -5.6012268469234126e-05;
              } else {
                result[0] += -0.00016872056158549178;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7463838234422112139) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7326471166347855446) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6100010069597990858) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08693186820944626136) ) ) {
                      result[0] += -0.00013043909679775014;
                    } else {
                      result[0] += 8.940470544100509e-05;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6402694681155779444) ) ) {
                      result[0] += -0.00021341913379052;
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.606193063154585432) ) ) {
                        result[0] += 1.9584680880718676e-05;
                      } else {
                        result[0] += -0.00025607899191454163;
                      }
                    }
                  }
                } else {
                  result[0] += 3.7461250303080636e-05;
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01332150000000000174) ) ) {
                  result[0] += -7.969517112656519e-05;
                } else {
                  result[0] += 0.0007270243146013766;
                }
              }
            } else {
              result[0] += -0.00014678506875172632;
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -0.0001459861442868862;
                  } else {
                    result[0] += -0.0001459861442868862;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8254037945979900703) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                        result[0] += -0.0001459861442868862;
                      } else {
                        result[0] += -0.0001459861442868862;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7894192122613066243) ) ) {
                          result[0] += -0.0001459861442868862;
                        } else {
                          result[0] += -0.0001459861442868862;
                        }
                      } else {
                        result[0] += -0.0001459861442868862;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005013289129500051074) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8419399877135679278) ) ) {
                        result[0] += -0.0001459861442868862;
                      } else {
                        result[0] += -0.0001459861442868862;
                      }
                    } else {
                      result[0] += -0.0001459861442868862;
                    }
                  }
                }
              } else {
                result[0] += -0.0001459861442868862;
              }
            } else {
              result[0] += -0.00019131198036098044;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.883880929790755059e-06) ) ) {
              result[0] += -0.00016751504319022464;
            } else {
              result[0] += -2.2611543278576278e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -0.0001459861442868862;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                    result[0] += -0.0001459861442868862;
                  } else {
                    result[0] += -0.0001459861442868862;
                  }
                } else {
                  result[0] += -0.0001459861442868862;
                }
              } else {
                result[0] += -0.0001459861442868862;
              }
            } else {
              result[0] += -0.0001459861442868862;
            }
          }
        } else {
          result[0] += -0.0002362898187911381;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8050000000000001599) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3850000000000000644) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0650000000000000161) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.07500000000000002498) ) ) {
            result[0] += -0.00011635078148115696;
          } else {
            result[0] += 0.000108245053431364;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02616152934301940389) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.05580247069824354617) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.373325504271297691e-06) ) ) {
                result[0] += -0.0006430796754305148;
              } else {
                result[0] += 0.0007180470926544745;
              }
            } else {
              result[0] += 5.202734853377629e-05;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01868100000000000316) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3450000000000000289) ) ) {
                result[0] += 0.0004675303665943297;
              } else {
                result[0] += -0.00015377815334665705;
              }
            } else {
              result[0] += 0.0019217544370796944;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0119121105025029022) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006186000000000001393) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.002347679878538096e-06) ) ) {
              result[0] += -0.0011765869611287054;
            } else {
              result[0] += 0.0010813362561704963;
            }
          } else {
            result[0] += -0.0002538640097271174;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3644118032412060892) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9250000000000001554) ) ) {
              result[0] += 0.001902913381219737;
            } else {
              result[0] += -0.0022215610207175587;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5650000000000000577) ) ) {
              result[0] += 0.0012578112669664329;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
                result[0] += 0.0023161562209619143;
              } else {
                result[0] += -6.234944576785277e-05;
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9750000000000000888) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03469629566125685682) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006585500000000000208) ) ) {
            result[0] += 0.005415936840619956;
          } else {
            result[0] += 0.002858793601443444;
          }
        } else {
          result[0] += 0.0063583998530702315;
        }
      } else {
        result[0] += 0.008064514230360845;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.00011174209053104666;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002295101748406000225) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5687531224874372571) ) ) {
                  result[0] += -4.195091739963104e-05;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4677590045467516222) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6249533869346735049) ) ) {
                      result[0] += -0.00017590883865544575;
                    } else {
                      result[0] += -0.00013967761186295933;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.584873521522560625e-06) ) ) {
                        result[0] += 0.00010936065967734374;
                      } else {
                        result[0] += -0.00014082169326921383;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9567162861906464144) ) ) {
                          result[0] += -0.00013967761186295933;
                        } else {
                          result[0] += -0.00013967761186295933;
                        }
                      } else {
                        result[0] += -0.00013967761186295933;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.00016981420333275155;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.701692321267631473e-05) ) ) {
                result[0] += -5.359179758480923e-05;
              } else {
                result[0] += -0.0001614296016211437;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7463838234422112139) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4295075599497487628) ) ) {
                  result[0] += 0.0008036490263745611;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                      result[0] += -0.00013355639111493816;
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01238050000000000088) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.03588532983514210878) ) ) {
                          result[0] += 0.0002737389976939822;
                        } else {
                          result[0] += -0.0002493273281959161;
                        }
                      } else {
                        result[0] += 0.0004613735102806995;
                      }
                    }
                  } else {
                    result[0] += 4.942155982709054e-05;
                  }
                }
              } else {
                result[0] += 0.0003732490097279377;
              }
            } else {
              result[0] += -0.0001404420122233693;
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -0.00013967761186295933;
                  } else {
                    result[0] += -0.00013967761186295933;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8254037945979900703) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                        result[0] += -0.00013967761186295933;
                      } else {
                        result[0] += -0.00013967761186295933;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7894192122613066243) ) ) {
                          result[0] += -0.00013967761186295933;
                        } else {
                          result[0] += -0.00013967761186295933;
                        }
                      } else {
                        result[0] += -0.00013967761186295933;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005013289129500051074) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8419399877135679278) ) ) {
                        result[0] += -0.00013967761186295933;
                      } else {
                        result[0] += -0.00013967761186295933;
                      }
                    } else {
                      result[0] += -0.00013967761186295933;
                    }
                  }
                }
              } else {
                result[0] += -0.00013967761186295933;
              }
            } else {
              result[0] += -0.00018304477228388264;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.883880929790755059e-06) ) ) {
              result[0] += -0.0001602761775662082;
            } else {
              result[0] += -2.1634425521101922e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -0.00013967761186295933;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                    result[0] += -0.00013967761186295933;
                  } else {
                    result[0] += -0.00013967761186295933;
                  }
                } else {
                  result[0] += -0.00013967761186295933;
                }
              } else {
                result[0] += -0.00013967761186295933;
              }
            } else {
              result[0] += -0.00013967761186295933;
            }
          }
        } else {
          result[0] += -0.0002260789731621286;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8350000000000000755) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3850000000000000644) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0650000000000000161) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.07500000000000002498) ) ) {
            result[0] += -0.000111322888723878;
          } else {
            result[0] += 0.00010356743534207803;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02616152934301940389) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6915080527790725684) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.564374608675820677) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.05580247069824354617) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.373325504271297691e-06) ) ) {
                    result[0] += -0.0006152901272960747;
                  } else {
                    result[0] += 0.0006870179604854975;
                  }
                } else {
                  result[0] += 4.2735334581132687e-05;
                }
              } else {
                result[0] += 0.0007835870635080359;
              }
            } else {
              result[0] += -0.00011790245667489592;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01868100000000000316) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3450000000000000289) ) ) {
                result[0] += 0.0004473268706308049;
              } else {
                result[0] += -0.00014713290306473588;
              }
            } else {
              result[0] += 0.0018387092259306273;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0119121105025029022) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00583050000000000148) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2850000000000000866) ) ) {
              result[0] += -0.0014474706268546142;
            } else {
              result[0] += 0.00104987152011412;
            }
          } else {
            result[0] += -0.00017556813504198944;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3569067370100503234) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03291917222295825951) ) ) {
              result[0] += 0.0022384998727741374;
            } else {
              result[0] += -0.0019071609084491893;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6950000000000000622) ) ) {
              result[0] += 0.0013536008761681614;
            } else {
              result[0] += 0.0032473653913914565;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03350035677887956004) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007090500000000000448) ) ) {
            result[0] += 0.0056090495960761655;
          } else {
            result[0] += 0.0026896290240994007;
          }
        } else {
          result[0] += 0.006389835779031158;
        }
      } else {
        result[0] += 0.008148152404590379;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.00010691335418297806;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002295101748406000225) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5687531224874372571) ) ) {
                  result[0] += -4.013808287398611e-05;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4677590045467516222) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6249533869346735049) ) ) {
                      result[0] += -0.00016830725004075904;
                    } else {
                      result[0] += -0.00013364169148408743;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.584873521522560625e-06) ) ) {
                        result[0] += 0.00010463483264186305;
                      } else {
                        result[0] += -0.00013473633344057617;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9567162861906464144) ) ) {
                          result[0] += -0.00013364169148408743;
                        } else {
                          result[0] += -0.00013364169148408743;
                        }
                      } else {
                        result[0] += -0.00013364169148408743;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.0001624759835790828;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.701692321267631473e-05) ) ) {
                result[0] += -5.1275923058690484e-05;
              } else {
                result[0] += -0.00015445370756638128;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7463838234422112139) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03500000000000001027) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4295075599497487628) ) ) {
                  result[0] += 0.0007689207583933334;
                } else {
                  result[0] += -9.607668517497564e-05;
                }
              } else {
                result[0] += 0.0021759919773289074;
              }
            } else {
              result[0] += -0.00013437305963803656;
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -0.00013364169148408743;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.310012234630710122e-06) ) ) {
                      result[0] += -0.00013364169148408743;
                    } else {
                      result[0] += -0.00013364169148408743;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8254037945979900703) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                        result[0] += -0.00013364169148408743;
                      } else {
                        result[0] += -0.00013364169148408743;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7894192122613066243) ) ) {
                          result[0] += -0.00013364169148408743;
                        } else {
                          result[0] += -0.00013364169148408743;
                        }
                      } else {
                        result[0] += -0.00013364169148408743;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005013289129500051074) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8419399877135679278) ) ) {
                        result[0] += -0.00013364169148408743;
                      } else {
                        result[0] += -0.00013364169148408743;
                      }
                    } else {
                      result[0] += -0.00013364169148408743;
                    }
                  }
                }
              } else {
                result[0] += -0.00013364169148408743;
              }
            } else {
              result[0] += -0.00017513481694788902;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.883880929790755059e-06) ) ) {
              result[0] += -0.0001533501266872118;
            } else {
              result[0] += -2.0699532175301263e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -0.00013364169148408743;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                    result[0] += -0.00013364169148408743;
                  } else {
                    result[0] += -0.00013364169148408743;
                  }
                } else {
                  result[0] += -0.00013364169148408743;
                }
              } else {
                result[0] += -0.00013364169148408743;
              }
            } else {
              result[0] += -0.00013364169148408743;
            }
          }
        } else {
          result[0] += -0.00021630937112538588;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7750000000000001332) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3150000000000000577) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01724500000000000338) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
            result[0] += -0.0001173751297822166;
          } else {
            result[0] += 5.510798013198667e-05;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.459978591867425068) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01467829982783020078) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01326604349644140181) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6025283427889448484) ) ) {
                  result[0] += 0.0011691231666999511;
                } else {
                  result[0] += -0.00014166616782865913;
                }
              } else {
                result[0] += -0.000977397065909757;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4693879269597989734) ) ) {
                result[0] += 0.003188936357260898;
              } else {
                result[0] += 0.0006144914181449102;
              }
            }
          } else {
            result[0] += -0.0012081721751962787;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08951570884523896154) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7789937396482412568) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01043419202401875238) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004657500000000001049) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2750000000000000777) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    result[0] += -0.0014383283160714713;
                  } else {
                    result[0] += 0.0026384081305337696;
                  }
                } else {
                  result[0] += 0.0009541060123856865;
                }
              } else {
                result[0] += -0.00014899091623179507;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004295500000000001574) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4550000000000000711) ) ) {
                  result[0] += 0.0004424709912452476;
                } else {
                  result[0] += 0.0018030802045663147;
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1050145000000000106) ) ) {
                  result[0] += 0.0011836970334555186;
                } else {
                  result[0] += 0.003956601363241709;
                }
              }
            }
          } else {
            result[0] += 4.5296761273134356e-05;
          }
        } else {
          result[0] += 0.0027061902418111946;
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9750000000000000888) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03350035677887956004) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007090500000000000448) ) ) {
            result[0] += 0.004423654295591422;
          } else {
            result[0] += 0.002448932399204481;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
            result[0] += 0.005710439581152221;
          } else {
            result[0] += 0.001490871600740297;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01881166515770610337) ) ) {
          result[0] += 0.006067514427289979;
        } else {
          result[0] += 0.0077960444433139925;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.00010229328311590021;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002295101748406000225) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5687531224874372571) ) ) {
                  result[0] += -3.8403586778608726e-05;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4677590045467516222) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6249533869346735049) ) ) {
                      result[0] += -0.00016103415060210585;
                    } else {
                      result[0] += -0.00012786660270402482;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.584873521522560625e-06) ) ) {
                        result[0] += 0.0001001132238438653;
                      } else {
                        result[0] += -0.00012891394164892412;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9567162861906464144) ) ) {
                          result[0] += -0.00012786660270402482;
                        } else {
                          result[0] += -0.00012786660270402482;
                        }
                      } else {
                        result[0] += -0.00012786660270402482;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.0001554548719830138;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.701692321267631473e-05) ) ) {
                result[0] += -4.906012494468012e-05;
              } else {
                result[0] += -0.00014777926440646448;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7463838234422112139) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03500000000000001027) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4295075599497487628) ) ) {
                  result[0] += 0.0007356932109473085;
                } else {
                  result[0] += -9.192490154804005e-05;
                }
              } else {
                result[0] += 0.0020819603415853957;
              }
            } else {
              result[0] += -0.00012856636607975645;
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -0.00012786660270402482;
                  } else {
                    result[0] += -0.00012786660270402482;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8254037945979900703) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                        result[0] += -0.00012786660270402482;
                      } else {
                        result[0] += -0.00012786660270402482;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7894192122613066243) ) ) {
                          result[0] += -0.00012786660270402482;
                        } else {
                          result[0] += -0.00012786660270402482;
                        }
                      } else {
                        result[0] += -0.00012786660270402482;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005013289129500051074) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8419399877135679278) ) ) {
                        result[0] += -0.00012786660270402482;
                      } else {
                        result[0] += -0.00012786660270402482;
                      }
                    } else {
                      result[0] += -0.00012786660270402482;
                    }
                  }
                }
              } else {
                result[0] += -0.00012786660270402482;
              }
            } else {
              result[0] += -0.00016756667630912365;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.883880929790755059e-06) ) ) {
              result[0] += -0.0001467233728185813;
            } else {
              result[0] += -1.9805038588078446e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -0.00012786660270402482;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                    result[0] += -0.00012786660270402482;
                  } else {
                    result[0] += -0.00012786660270402482;
                  }
                } else {
                  result[0] += -0.00012786660270402482;
                }
              } else {
                result[0] += -0.00012786660270402482;
              }
            } else {
              result[0] += -0.00012786660270402482;
            }
          }
        } else {
          result[0] += -0.00020696194512129825;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.875000000000000111) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3650000000000000466) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.05580247069824354617) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.125515493975159704e-06) ) ) {
            result[0] += -0.00011148518830905789;
          } else {
            result[0] += 0.0007441364267020789;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.717118227269369246) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02500000000000000486) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1350000000000000366) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006124087708088651362) ) ) {
                  result[0] += -0.00010126699496023546;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006064500000000001313) ) ) {
                    result[0] += -0.00026519413746976843;
                  } else {
                    result[0] += -7.673481933218703e-05;
                  }
                }
              } else {
                result[0] += 0.0006927889668081308;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00799750000000000287) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.02125964230697484705) ) ) {
                  result[0] += -0.000633852641186172;
                } else {
                  result[0] += 1.689414049439244e-05;
                }
              } else {
                result[0] += 0.00044430444404274134;
              }
            }
          } else {
            result[0] += -0.0007960432362082423;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02446805795595660346) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004552500000000000123) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2750000000000000777) ) ) {
              result[0] += -0.002378903517491789;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004867285882244350333) ) ) {
                result[0] += 0.00084129230230206;
              } else {
                result[0] += 0.0015290885164613492;
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9774026691300493619) ) ) {
              result[0] += 0.0005902935032975577;
            } else {
              result[0] += -0.001153612858267833;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3569067370100503234) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03291917222295825951) ) ) {
                result[0] += 0.006663299695398409;
              } else {
                result[0] += -0.001633019825426009;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5550000000000001599) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002399500000000000157) ) ) {
                  result[0] += -0.00042913478910392713;
                } else {
                  result[0] += 0.0019559108395303597;
                }
              } else {
                result[0] += 0.003089178415402475;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8025985781909549255) ) ) {
              result[0] += -0.0015461435779237833;
            } else {
              result[0] += 0.0004034642813190257;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0526089167981486569) ) ) {
          result[0] += 0.00438184128620092;
        } else {
          result[0] += 0.006299075690555175;
        }
      } else {
        result[0] += 0.007459152203373939;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -9.787286022961293e-05;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002295101748406000225) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5687531224874372571) ) ) {
                  result[0] += -3.6744043857111694e-05;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4677590045467516222) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6249533869346735049) ) ) {
                      result[0] += -0.00015407534526208316;
                    } else {
                      result[0] += -0.0001223410741476262;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.584873521522560625e-06) ) ) {
                        result[0] += 9.578700835425184e-05;
                      } else {
                        result[0] += -0.00012334315419672403;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9567162861906464144) ) ) {
                          result[0] += -0.0001223410741476262;
                        } else {
                          result[0] += -0.0001223410741476262;
                        }
                      } else {
                        result[0] += -0.0001223410741476262;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.00014873716527767723;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.701692321267631473e-05) ) ) {
                result[0] += -4.6940078618042416e-05;
              } else {
                result[0] += -0.00014139324547537892;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7463838234422112139) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0650000000000000161) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4295075599497487628) ) ) {
                  result[0] += 0.0009445446754151042;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008506177121675452882) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.543101476988260834) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6161319161557790025) ) ) {
                        result[0] += -0.00010498152457054494;
                      } else {
                        result[0] += -0.0003843825681382513;
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6858832018090453841) ) ) {
                        result[0] += 0.0001727156190748389;
                      } else {
                        result[0] += -0.00021884183173025417;
                      }
                    }
                  } else {
                    result[0] += -1.6903674096435197e-05;
                  }
                }
              } else {
                result[0] += 0.003997436971616641;
              }
            } else {
              result[0] += -0.00012301059848960266;
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -0.0001223410741476262;
                  } else {
                    result[0] += -0.0001223410741476262;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8254037945979900703) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                        result[0] += -0.0001223410741476262;
                      } else {
                        result[0] += -0.0001223410741476262;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7894192122613066243) ) ) {
                          result[0] += -0.0001223410741476262;
                        } else {
                          result[0] += -0.0001223410741476262;
                        }
                      } else {
                        result[0] += -0.0001223410741476262;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005013289129500051074) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8419399877135679278) ) ) {
                        result[0] += -0.0001223410741476262;
                      } else {
                        result[0] += -0.0001223410741476262;
                      }
                    } else {
                      result[0] += -0.0001223410741476262;
                    }
                  }
                }
              } else {
                result[0] += -0.0001223410741476262;
              }
            } else {
              result[0] += -0.00016032557945140817;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.883880929790755059e-06) ) ) {
              result[0] += -0.0001403829823706018;
            } else {
              result[0] += -1.894919895548642e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -0.0001223410741476262;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                    result[0] += -0.0001223410741476262;
                  } else {
                    result[0] += -0.0001223410741476262;
                  }
                } else {
                  result[0] += -0.0001223410741476262;
                }
              } else {
                result[0] += -0.0001223410741476262;
              }
            } else {
              result[0] += -0.0001223410741476262;
            }
          }
        } else {
          result[0] += -0.00019801845156104008;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.875000000000000111) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3650000000000000466) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.05580247069824354617) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02032228342586875347) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
              result[0] += -0.0004714386135888412;
            } else {
              result[0] += 0.0003819942992492337;
            }
          } else {
            result[0] += 0.0019655767344539388;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
            result[0] += -0.00011308491895889149;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04397260539440395882) ) ) {
                result[0] += 3.343732104623705e-05;
              } else {
                result[0] += 0.0005995209969698134;
              }
            } else {
              result[0] += -0.0009518989529142534;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02446805795595660346) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004657500000000001049) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2750000000000000777) ) ) {
              result[0] += -0.0022761034192578175;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004867285882244350333) ) ) {
                result[0] += 0.0008020526349024211;
              } else {
                result[0] += 0.0014591637977511434;
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9774026691300493619) ) ) {
              result[0] += 0.0005930153830328792;
            } else {
              result[0] += -0.001144905733110029;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3569067370100503234) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03291917222295825951) ) ) {
                result[0] += 0.006375357011631408;
              } else {
                result[0] += -0.0015624517686563864;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5550000000000001599) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01949300000000000338) ) ) {
                  result[0] += 0.00041264810002319236;
                } else {
                  result[0] += 0.0028921503571377968;
                }
              } else {
                result[0] += 0.0029556850466169824;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8025985781909549255) ) ) {
              result[0] += -0.0014793297241774252;
            } else {
              result[0] += 0.00038602928765554785;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        result[0] += 0.0049861505800432365;
      } else {
        result[0] += 0.007568950024425545;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -9.364345808191585e-05;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002295101748406000225) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5687531224874372571) ) ) {
                  result[0] += -3.5156215140961355e-05;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4677590045467516222) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6249533869346735049) ) ) {
                      result[0] += -0.00014741725235839316;
                    } else {
                      result[0] += -0.00011705432151224155;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.584873521522560625e-06) ) ) {
                        result[0] += 9.164774259759037e-05;
                      } else {
                        result[0] += -0.00011801309844848585;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9567162861906464144) ) ) {
                          result[0] += -0.00011705432151224155;
                        } else {
                          result[0] += -0.00011705432151224155;
                        }
                      } else {
                        result[0] += -0.00011705432151224155;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.0001423097523585905;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.701692321267631473e-05) ) ) {
                result[0] += -4.491164633503292e-05;
              } else {
                result[0] += -0.00013528318703138854;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7463838234422112139) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07500000000000002498) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4295075599497487628) ) ) {
                  result[0] += 0.0009194291032944869;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01238050000000000088) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4868404241646586694) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6100010069597990858) ) ) {
                        result[0] += -0.00017365921942977876;
                      } else {
                        result[0] += -0.00022739060008691717;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                        result[0] += 0.00017754682632201892;
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7003595884880823297) ) ) {
                          result[0] += -0.00023038697198083714;
                        } else {
                          result[0] += 8.209560934133335e-07;
                        }
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02796916660693585244) ) ) {
                      result[0] += -5.484402039132655e-05;
                    } else {
                      result[0] += 0.00039142140221939395;
                    }
                  }
                }
              } else {
                result[0] += 0.00405079068853591;
              }
            } else {
              result[0] += -0.00011769491354669936;
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -0.00011705432151224155;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.310012234630710122e-06) ) ) {
                      result[0] += -0.00011705432151224155;
                    } else {
                      result[0] += -0.00011705432151224155;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8254037945979900703) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                        result[0] += -0.00011705432151224155;
                      } else {
                        result[0] += -0.00011705432151224155;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7894192122613066243) ) ) {
                          result[0] += -0.00011705432151224155;
                        } else {
                          result[0] += -0.00011705432151224155;
                        }
                      } else {
                        result[0] += -0.00011705432151224155;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005013289129500051074) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8419399877135679278) ) ) {
                        result[0] += -0.00011705432151224155;
                      } else {
                        result[0] += -0.00011705432151224155;
                      }
                    } else {
                      result[0] += -0.00011705432151224155;
                    }
                  }
                }
              } else {
                result[0] += -0.00011705432151224155;
              }
            } else {
              result[0] += -0.00015339739375752154;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.883880929790755059e-06) ) ) {
              result[0] += -0.0001343165806557094;
            } else {
              result[0] += -1.8130342915400795e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -0.00011705432151224155;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                    result[0] += -0.00011705432151224155;
                  } else {
                    result[0] += -0.00011705432151224155;
                  }
                } else {
                  result[0] += -0.00011705432151224155;
                }
              } else {
                result[0] += -0.00011705432151224155;
              }
            } else {
              result[0] += -0.00011705432151224155;
            }
          }
        } else {
          result[0] += -0.000189461435220135;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.875000000000000111) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3150000000000000577) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01724500000000000338) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
            result[0] += -0.00013582083295593072;
          } else {
            result[0] += 2.059259669917775e-05;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.459978591867425068) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01467829982783020078) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01326604349644140181) ) ) {
                result[0] += 0.0001324134373912016;
              } else {
                result[0] += -0.0009670127686466921;
              }
            } else {
              result[0] += 0.0008432630812140872;
            }
          } else {
            result[0] += -0.001098552864206966;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01444878842564100048) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004657500000000001049) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005479696504671500816) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.29500000000000004) ) ) {
                result[0] += -0.0007982482512708349;
              } else {
                result[0] += 0.0007923596320926959;
              }
            } else {
              result[0] += 0.0014016174344352694;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1206324332205917643) ) ) {
              result[0] += 0.0003875108708292028;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5612777274623116375) ) ) {
                result[0] += -0.0026483238839756923;
              } else {
                result[0] += -0.00040707046554334887;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7250000000000000888) ) ) {
              result[0] += 0.0012073476834989633;
            } else {
              result[0] += 0.003550866829382417;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7894192122613066243) ) ) {
              result[0] += -0.003575865664870549;
            } else {
              result[0] += 6.432872431909274e-05;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        result[0] += 0.004770682922078587;
      } else {
        result[0] += 0.00724187126720913;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -8.959682205022866e-05;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002295101748406000225) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5687531224874372571) ) ) {
                  result[0] += -3.363700162790722e-05;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4677590045467516222) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6249533869346735049) ) ) {
                      result[0] += -0.00014104687713619699;
                    } else {
                      result[0] += -0.00011199602651974157;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.584873521522560625e-06) ) ) {
                        result[0] += 8.768734787259225e-05;
                      } else {
                        result[0] += -0.00011291337161038738;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9567162861906464144) ) ) {
                          result[0] += -0.00011199602651974157;
                        } else {
                          result[0] += -0.00011199602651974157;
                        }
                      } else {
                        result[0] += -0.00011199602651974157;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.00013616008869440796;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.701692321267631473e-05) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7149244603266332598) ) ) {
                  result[0] += -8.551791431831868e-05;
                } else {
                  result[0] += 2.8729394328648407e-05;
                }
              } else {
                result[0] += -0.00012943716393126108;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7463838234422112139) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0650000000000000161) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01262450000000000204) ) ) {
                  result[0] += -0.00010646008517553443;
                } else {
                  result[0] += 3.428633132143419e-05;
                }
              } else {
                result[0] += 0.0036496470810264666;
              }
            } else {
              result[0] += -0.00011260893650505953;
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -0.00011199602651974157;
                  } else {
                    result[0] += -0.00011199602651974157;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8254037945979900703) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                        result[0] += -0.00011199602651974157;
                      } else {
                        result[0] += -0.00011199602651974157;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7894192122613066243) ) ) {
                          result[0] += -0.00011199602651974157;
                        } else {
                          result[0] += -0.00011199602651974157;
                        }
                      } else {
                        result[0] += -0.00011199602651974157;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005013289129500051074) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8419399877135679278) ) ) {
                        result[0] += -0.00011199602651974157;
                      } else {
                        result[0] += -0.00011199602651974157;
                      }
                    } else {
                      result[0] += -0.00011199602651974157;
                    }
                  }
                }
              } else {
                result[0] += -0.00011199602651974157;
              }
            } else {
              result[0] += -0.00014676859732624183;
            }
          } else {
            result[0] += -8.737763926713388e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -0.00011199602651974157;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                    result[0] += -0.00011199602651974157;
                  } else {
                    result[0] += -0.00011199602651974157;
                  }
                } else {
                  result[0] += -0.00011199602651974157;
                }
              } else {
                result[0] += -0.00011199602651974157;
              }
            } else {
              result[0] += -0.00011199602651974157;
            }
          }
        } else {
          result[0] += -0.00018127419517068803;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8350000000000000755) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3150000000000000577) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0650000000000000161) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.07500000000000002498) ) ) {
            result[0] += -0.00011195870313615297;
          } else {
            result[0] += 8.21507288213506e-05;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02906350000000000253) ) ) {
            result[0] += 0.0001066634699394087;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.363906689523952442) ) ) {
              result[0] += 0.0012266504673129487;
            } else {
              result[0] += -0.0005793216633110658;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01444878842564100048) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004848500000000001246) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9650000000000000799) ) ) {
              result[0] += 0.0007320481360588481;
            } else {
              result[0] += 0.0010340701457533673;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1206324332205917643) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3998546246231156065) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.317357466959798995) ) ) {
                  result[0] += 0.0014235441431611061;
                } else {
                  result[0] += -0.001989287894509412;
                }
              } else {
                result[0] += 0.0007562256662640661;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5612777274623116375) ) ) {
                result[0] += -0.001864420367324901;
              } else {
                result[0] += -0.0005144486148614943;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3644118032412060892) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9250000000000001554) ) ) {
                result[0] += 0.0013475326130457672;
              } else {
                result[0] += -0.002250378554990725;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5550000000000001599) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7650000000000001243) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3966559369710560001) ) ) {
                    result[0] += 0.0019004434323824895;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6402694681155779444) ) ) {
                      result[0] += -0.001994705058621641;
                    } else {
                      result[0] += 0.0007227629489879421;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0526089167981486569) ) ) {
                    result[0] += -0.0005055879407356327;
                  } else {
                    result[0] += 0.0016203400659933736;
                  }
                }
              } else {
                result[0] += 0.0020820239303686876;
              }
            }
          } else {
            result[0] += -0.00013733286834443582;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03350035677887956004) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007090500000000000448) ) ) {
            result[0] += 0.00464232995343097;
          } else {
            result[0] += 0.001976901121540727;
          }
        } else {
          result[0] += 0.005173116178322138;
        }
      } else {
        result[0] += 0.006496794778568152;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -8.57250542208522e-05;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002295101748406000225) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5687531224874372571) ) ) {
                  result[0] += -3.218343823358722e-05;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4677590045467516222) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6249533869346735049) ) ) {
                      result[0] += -0.00013495178638594927;
                    } else {
                      result[0] += -0.0001071563167780943;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.584873521522560625e-06) ) ) {
                        result[0] += 8.389809458472321e-05;
                      } else {
                        result[0] += -0.00010803402042689962;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9567162861906464144) ) ) {
                          result[0] += -0.0001071563167780943;
                        } else {
                          result[0] += -0.0001071563167780943;
                        }
                      } else {
                        result[0] += -0.0001071563167780943;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.00013027617184346754;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.701692321267631473e-05) ) ) {
                result[0] += -3.927536409441676e-05;
              } else {
                result[0] += -0.00012384376635568825;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7463838234422112139) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0650000000000000161) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4295075599497487628) ) ) {
                  result[0] += 0.0008625147299591542;
                } else {
                  result[0] += -7.5310935103925e-05;
                }
              } else {
                result[0] += 0.003491934052444111;
              }
            } else {
              result[0] += -0.00010774274094495181;
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -0.0001071563167780943;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.310012234630710122e-06) ) ) {
                      result[0] += -0.0001071563167780943;
                    } else {
                      result[0] += -0.0001071563167780943;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8254037945979900703) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                        result[0] += -0.0001071563167780943;
                      } else {
                        result[0] += -0.0001071563167780943;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7894192122613066243) ) ) {
                          result[0] += -0.0001071563167780943;
                        } else {
                          result[0] += -0.0001071563167780943;
                        }
                      } else {
                        result[0] += -0.0001071563167780943;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005013289129500051074) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8419399877135679278) ) ) {
                        result[0] += -0.0001071563167780943;
                      } else {
                        result[0] += -0.0001071563167780943;
                      }
                    } else {
                      result[0] += -0.0001071563167780943;
                    }
                  }
                }
              } else {
                result[0] += -0.0001071563167780943;
              }
            } else {
              result[0] += -0.00014042625258133687;
            }
          } else {
            result[0] += -8.36017694876043e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
            result[0] += -0.0001071563167780943;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                    result[0] += -0.0001071563167780943;
                  } else {
                    result[0] += -0.0001071563167780943;
                  }
                } else {
                  result[0] += -0.0001071563167780943;
                }
              } else {
                result[0] += -0.0001071563167780943;
              }
            } else {
              result[0] += -0.0001071563167780943;
            }
          }
        } else {
          result[0] += -0.00017344075218579606;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8850000000000001199) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4050000000000000822) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.05580247069824354617) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02129391514754680123) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
              result[0] += -0.0004305326686462365;
            } else {
              result[0] += 0.00035458150339963944;
            }
          } else {
            result[0] += 0.0021005792501699134;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
            result[0] += -8.574752800992192e-05;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00799750000000000287) ) ) {
                result[0] += -7.400517238666405e-06;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04247438584267165113) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
                    result[0] += 0.000636241443194863;
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1014535000000000159) ) ) {
                      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1250000000000000278) ) ) {
                        result[0] += 0.0012170623172863928;
                      } else {
                        result[0] += -0.0005917517817296932;
                      }
                    } else {
                      result[0] += 0.001714482982004274;
                    }
                  }
                } else {
                  result[0] += 0.0015953217313933;
                }
              }
            } else {
              result[0] += -0.0012373695914234513;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02930104421257910194) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004552500000000000123) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004867285882244350333) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
                result[0] += 0.0004310504235817983;
              } else {
                result[0] += 0.0009661809285652007;
              }
            } else {
              result[0] += 0.001402583867602783;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01000276686157755036) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4129968667336683663) ) ) {
                result[0] += -0.0016960901724310936;
              } else {
                result[0] += -2.7171231836584006e-05;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5361772370603016258) ) ) {
                result[0] += 0.0018313370069812625;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05311250000000000693) ) ) {
                  result[0] += 0.0008186985023003628;
                } else {
                  result[0] += -0.0013366637771325468;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3569067370100503234) ) ) {
            result[0] += -0.0009405824194478029;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
              result[0] += 0.0023605359795172203;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8282572652763819931) ) ) {
                result[0] += -0.001059696353149782;
              } else {
                result[0] += 0.0011180989235520184;
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        result[0] += 0.004484266580367152;
      } else {
        result[0] += 0.006648179169683992;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -8.202059797442667e-05;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002295101748406000225) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5687531224874372571) ) ) {
                  result[0] += -3.0792688004503554e-05;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4677590045467516222) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6249533869346735049) ) ) {
                      result[0] += -0.00012912008417721377;
                    } else {
                      result[0] += -0.00010252574651318793;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.584873521522560625e-06) ) ) {
                        result[0] += 8.027258716017407e-05;
                      } else {
                        result[0] += -0.00010336552175478628;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9567162861906464144) ) ) {
                          result[0] += -0.00010252574651318793;
                        } else {
                          result[0] += -0.00010252574651318793;
                        }
                      } else {
                        result[0] += -0.00010252574651318793;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.0001347930463924453;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.701692321267631473e-05) ) ) {
                result[0] += -3.757814886168721e-05;
              } else {
                result[0] += -0.00012277472080119187;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7463838234422112139) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0650000000000000161) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01262450000000000204) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01568578759365070463) ) ) {
                    result[0] += -7.794399754467217e-05;
                  } else {
                    result[0] += -0.0003139608428388217;
                  }
                } else {
                  result[0] += 3.6059136846265366e-05;
                }
              } else {
                result[0] += 0.0033410363128013165;
              }
            } else {
              result[0] += -0.00010308682939927618;
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -0.00010252574651318793;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.175366324986798601e-07) ) ) {
                      result[0] += -0.00010252574651318793;
                    } else {
                      result[0] += -0.00010252574651318793;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.767254320477387064) ) ) {
                    result[0] += -0.00010252574651318793;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9774026691300493619) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7712418641206031378) ) ) {
                          result[0] += -0.00010252574651318793;
                        } else {
                          result[0] += -0.00010252574651318793;
                        }
                      } else {
                        result[0] += -0.00010252574651318793;
                      }
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8254037945979900703) ) ) {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.384300133116745416e-05) ) ) {
                          result[0] += -0.00010252574651318793;
                        } else {
                          result[0] += -0.00010252574651318793;
                        }
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8327395279648243109) ) ) {
                          result[0] += -0.00010252574651318793;
                        } else {
                          result[0] += -0.00010252574651318793;
                        }
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.00010252574651318793;
              }
            } else {
              result[0] += -0.00013552910725231804;
            }
          } else {
            result[0] += -9.916756350965938e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                result[0] += -0.00010252574651318793;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006064500000000001313) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.485713013107980879e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8254037945979900703) ) ) {
                      result[0] += -0.00010252574651318793;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9007328855527639844) ) ) {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.120890988778383868e-05) ) ) {
                          result[0] += -0.00010252574651318793;
                        } else {
                          result[0] += -0.00010252574651318793;
                        }
                      } else {
                        result[0] += -0.00010252574651318793;
                      }
                    }
                  } else {
                    result[0] += -0.00010252574651318793;
                  }
                } else {
                  result[0] += -0.00010252574651318793;
                }
              }
            } else {
              result[0] += -0.00010252574651318793;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.052300094327177008e-06) ) ) {
              result[0] += -0.00010252574651318793;
            } else {
              result[0] += -0.00010252574651318793;
            }
          }
        } else {
          result[0] += -2.1572643236585435e-05;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8850000000000001199) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4050000000000000822) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.05580247069824354617) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02129391514754680123) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.310012234630710122e-06) ) ) {
              result[0] += -0.0003252825928614857;
            } else {
              result[0] += 0.00035818265380405746;
            }
          } else {
            result[0] += 0.0020098064417403442;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
            result[0] += -8.204210059854284e-05;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.96280210579579717) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04397260539440395882) ) ) {
                result[0] += 6.906141648811623e-05;
              } else {
                result[0] += 0.0009572721407596417;
              }
            } else {
              result[0] += -0.0007475185017567497;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02930104421257910194) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004552500000000000123) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004867285882244350333) ) ) {
              result[0] += 0.0006336797505715999;
            } else {
              result[0] += 0.001341973692238051;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01444878842564100048) ) ) {
              result[0] += -9.572826961377136e-05;
            } else {
              result[0] += 0.0010738035713312847;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3569067370100503234) ) ) {
            result[0] += -0.0008999368176378012;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
              result[0] += 0.0022585296018752007;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8168185667587940513) ) ) {
                result[0] += -0.0010139034538577452;
              } else {
                result[0] += 0.0010320118276420376;
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05473596564878090848) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00583050000000000148) ) ) {
            result[0] += 0.004786899632659453;
          } else {
            result[0] += 0.002622016407619742;
          }
        } else {
          result[0] += 0.00521678245051924;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01881166515770610337) ) ) {
          result[0] += 0.004707055236944029;
        } else {
          result[0] += 0.006240666801667673;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -7.847622323750155e-05;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002295101748406000225) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5687531224874372571) ) ) {
                  result[0] += -2.946203658107441e-05;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4677590045467516222) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6249533869346735049) ) ) {
                      result[0] += -0.00012354038864109917;
                    } else {
                      result[0] += -9.80952781332935e-05;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.584873521522560625e-06) ) ) {
                        result[0] += 7.680374961174693e-05;
                      } else {
                        result[0] += -9.889876397656358e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9567162861906464144) ) ) {
                          result[0] += -9.80952781332935e-05;
                        } else {
                          result[0] += -9.80952781332935e-05;
                        }
                      } else {
                        result[0] += -9.80952781332935e-05;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.0001289682038511179;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.714147492562814179) ) ) {
                result[0] += -0.00010459252998500965;
              } else {
                result[0] += 6.267200490838895e-06;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7463838234422112139) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07500000000000002498) ) ) {
                result[0] += -5.679604318551757e-05;
              } else {
                result[0] += 0.0034227552205368175;
              }
            } else {
              result[0] += -9.86321148171364e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -9.80952781332935e-05;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.175366324986798601e-07) ) ) {
                      result[0] += -9.80952781332935e-05;
                    } else {
                      result[0] += -9.80952781332935e-05;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.767254320477387064) ) ) {
                    result[0] += -9.80952781332935e-05;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9774026691300493619) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7712418641206031378) ) ) {
                          result[0] += -9.80952781332935e-05;
                        } else {
                          result[0] += -9.80952781332935e-05;
                        }
                      } else {
                        result[0] += -9.80952781332935e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8254037945979900703) ) ) {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.384300133116745416e-05) ) ) {
                          result[0] += -9.80952781332935e-05;
                        } else {
                          result[0] += -9.80952781332935e-05;
                        }
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8327395279648243109) ) ) {
                          result[0] += -9.80952781332935e-05;
                        } else {
                          result[0] += -9.80952781332935e-05;
                        }
                      }
                    }
                  }
                }
              } else {
                result[0] += -9.80952781332935e-05;
              }
            } else {
              result[0] += -0.00012967245714580572;
            }
          } else {
            result[0] += -9.488221305494016e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                result[0] += -9.80952781332935e-05;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006064500000000001313) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.485713013107980879e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8254037945979900703) ) ) {
                      result[0] += -9.80952781332935e-05;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9007328855527639844) ) ) {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.120890988778383868e-05) ) ) {
                          result[0] += -9.80952781332935e-05;
                        } else {
                          result[0] += -9.80952781332935e-05;
                        }
                      } else {
                        result[0] += -9.80952781332935e-05;
                      }
                    }
                  } else {
                    result[0] += -9.80952781332935e-05;
                  }
                } else {
                  result[0] += -9.80952781332935e-05;
                }
              }
            } else {
              result[0] += -9.80952781332935e-05;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.052300094327177008e-06) ) ) {
              result[0] += -9.80952781332935e-05;
            } else {
              result[0] += -9.80952781332935e-05;
            }
          }
        } else {
          result[0] += -2.0640419702683722e-05;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8850000000000001199) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3150000000000000577) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.05500000000000000722) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08500000000000000611) ) ) {
            result[0] += -0.0001101295000512422;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              result[0] += -0.0007087996778450262;
            } else {
              result[0] += 0.0021790612956089674;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01590200000000000294) ) ) {
            result[0] += 3.464542772853134e-05;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04247438584267165113) ) ) {
                result[0] += 0.0006068695141232837;
              } else {
                result[0] += 0.0017171226110622015;
              }
            } else {
              result[0] += -0.00021567326054222548;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01444878842564100048) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004657500000000001049) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005479696504671500816) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.29500000000000004) ) ) {
                result[0] += -0.0008275545590104982;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002837500000000000178) ) ) {
                  result[0] += 0.0008295118926856317;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003795500000000000696) ) ) {
                    result[0] += -0.0007960675368171025;
                  } else {
                    result[0] += 0.0010447035474345397;
                  }
                }
              }
            } else {
              result[0] += 0.0012674370410063133;
            }
          } else {
            result[0] += -0.00014031186353870938;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7350000000000000977) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1469960000000000155) ) ) {
                result[0] += 0.0008812912922242652;
              } else {
                result[0] += 0.004595154710946505;
              }
            } else {
              result[0] += 0.0032006845829825226;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7894192122613066243) ) ) {
              result[0] += -0.0034489138816135374;
            } else {
              result[0] += 0.0001422135361356496;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00583050000000000148) ) ) {
          result[0] += 0.004991948399449911;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01467829982783020078) ) ) {
            result[0] += 0.0014692801454385036;
          } else {
            result[0] += 0.004044447434402781;
          }
        }
      } else {
        result[0] += 0.006091210540130461;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -7.508501237143321e-05;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002295101748406000225) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5687531224874372571) ) ) {
                  result[0] += -2.8188886899955514e-05;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4677590045467516222) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6249533869346735049) ) ) {
                      result[0] += -0.00011820180975600075;
                    } else {
                      result[0] += -9.385626459018702e-05;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.584873521522560625e-06) ) ) {
                        result[0] += 7.348481172848655e-05;
                      } else {
                        result[0] += -9.462502921714446e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9567162861906464144) ) ) {
                          result[0] += -9.385626459018702e-05;
                        } else {
                          result[0] += -9.385626459018702e-05;
                        }
                      } else {
                        result[0] += -9.385626459018702e-05;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.00012339507155404496;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.714147492562814179) ) ) {
                result[0] += -0.00010007274922133447;
              } else {
                result[0] += 5.996374531999903e-06;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7463838234422112139) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07500000000000002498) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01262450000000000204) ) ) {
                  result[0] += -9.278262077872844e-05;
                } else {
                  result[0] += 3.817039315875635e-05;
                }
              } else {
                result[0] += 0.003274846921475993;
              }
            } else {
              result[0] += -9.436990282843142e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -9.385626459018702e-05;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.175366324986798601e-07) ) ) {
                      result[0] += -9.385626459018702e-05;
                    } else {
                      result[0] += -9.385626459018702e-05;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.767254320477387064) ) ) {
                    result[0] += -9.385626459018702e-05;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9774026691300493619) ) ) {
                        result[0] += -9.385626459018702e-05;
                      } else {
                        result[0] += -9.385626459018702e-05;
                      }
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8254037945979900703) ) ) {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.384300133116745416e-05) ) ) {
                          result[0] += -9.385626459018702e-05;
                        } else {
                          result[0] += -9.385626459018702e-05;
                        }
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8327395279648243109) ) ) {
                          result[0] += -9.385626459018702e-05;
                        } else {
                          result[0] += -9.385626459018702e-05;
                        }
                      }
                    }
                  }
                }
              } else {
                result[0] += -9.385626459018702e-05;
              }
            } else {
              result[0] += -0.00012406889179108956;
            }
          } else {
            result[0] += -9.07820464231347e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                result[0] += -9.385626459018702e-05;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006064500000000001313) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.485713013107980879e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8254037945979900703) ) ) {
                      result[0] += -9.385626459018702e-05;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9007328855527639844) ) ) {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.120890988778383868e-05) ) ) {
                          result[0] += -9.385626459018702e-05;
                        } else {
                          result[0] += -9.385626459018702e-05;
                        }
                      } else {
                        result[0] += -9.385626459018702e-05;
                      }
                    }
                  } else {
                    result[0] += -9.385626459018702e-05;
                  }
                } else {
                  result[0] += -9.385626459018702e-05;
                }
              }
            } else {
              result[0] += -9.385626459018702e-05;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.052300094327177008e-06) ) ) {
              result[0] += -9.385626459018702e-05;
            } else {
              result[0] += -9.385626459018702e-05;
            }
          }
        } else {
          result[0] += -1.974848055617161e-05;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8850000000000001199) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4250000000000000444) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.05580247069824354617) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02129391514754680123) ) ) {
            result[0] += 0.00029493554179141693;
          } else {
            result[0] += 0.001947438694526065;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00583050000000000148) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.02125964230697484705) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1750000000000000167) ) ) {
                result[0] += -0.000977554996579234;
              } else {
                result[0] += -0.00045349347351186277;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005259500000000001153) ) ) {
                result[0] += -2.786687282760199e-05;
              } else {
                result[0] += -0.0006237272132251669;
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04756785543737290789) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7322719660050253099) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6735883055778896233) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3550000000000000377) ) ) {
                      result[0] += 1.2003958025233976e-05;
                    } else {
                      result[0] += 0.0009218980530319069;
                    }
                  } else {
                    result[0] += 0.0010844911076324766;
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9808239647505231362) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2050000000000000433) ) ) {
                      result[0] += -0.0006992195696408974;
                    } else {
                      result[0] += 0.0004549270749549618;
                    }
                  } else {
                    result[0] += 8.539307978704557e-05;
                  }
                }
              } else {
                result[0] += 0.0013004076721813867;
              }
            } else {
              result[0] += -0.0012042648210908102;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0816878293504414571) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
            result[0] += 0.0008175005381145956;
          } else {
            result[0] += 0.0013256352096628148;
          }
        } else {
          result[0] += 0.0025350640214257592;
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00583050000000000148) ) ) {
          result[0] += 0.004628218700873223;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05473596564878090848) ) ) {
            result[0] += 0.002381420420849724;
          } else {
            result[0] += 0.004727374624297218;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01881166515770610337) ) ) {
          result[0] += 0.004240427324345792;
        } else {
          result[0] += 0.005796213823208738;
        }
      }
    }
  }
}

