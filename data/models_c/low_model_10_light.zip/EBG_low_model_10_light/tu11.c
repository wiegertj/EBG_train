
#include "header.h"

void predict_unit11(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -5.073155601591603e-06;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6249533869346735049) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1643367459977091716) ) ) {
            result[0] += -1.0029063879503402e-05;
          } else {
            result[0] += 4.304492108462391e-05;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -6.341444442930198e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.381175493840676405e-06) ) ) {
                  result[0] += 0.00014637127429159;
                } else {
                  result[0] += -2.7710800782119465e-05;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.794554612313755398e-06) ) ) {
                  result[0] += -6.341444442930198e-06;
                } else {
                  result[0] += -2.132691994589403e-05;
                }
              }
            }
          } else {
            result[0] += -5.3202301432000674e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -6.341444442930198e-06;
                } else {
                  result[0] += -6.341444442930198e-06;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -6.239538548111523e-06;
                } else {
                  result[0] += -6.341444442930198e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -6.341444442930198e-06;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -6.341444442930198e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -6.341444442930198e-06;
                      } else {
                        result[0] += -6.341444442930198e-06;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -6.341444442930198e-06;
                      } else {
                        result[0] += -6.341444442930198e-06;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -6.341444442930198e-06;
                        } else {
                          result[0] += -6.341444442930198e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -6.341444442930198e-06;
                        } else {
                          result[0] += -6.341444442930198e-06;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -6.341444442930198e-06;
                    } else {
                      result[0] += -6.341444442930198e-06;
                    }
                  }
                }
              } else {
                result[0] += -6.341444442930198e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -6.341444442930198e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -6.341444442930198e-06;
                  } else {
                    result[0] += -6.341444442930198e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -6.341444442930198e-06;
                  } else {
                    result[0] += -6.341444442930198e-06;
                  }
                }
              } else {
                result[0] += -6.341444442930198e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7519737796733669821) ) ) {
            result[0] += -7.5503552092097095e-06;
          } else {
            result[0] += 2.096027700158658e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8850000000000001199) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1773295000000000288) ) ) {
            result[0] += 5.630002457804836e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8327395279648243109) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9808239647505231362) ) ) {
                result[0] += 0.0025660977414208503;
              } else {
                result[0] += -0.0012536392875869963;
              }
            } else {
              result[0] += 0.002559664500783369;
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006585500000000000208) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04477003072051350535) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1494199460089949139) ) ) {
                result[0] += 0.0006611260625100753;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0240756843176193544) ) ) {
                  result[0] += 0.00037525082110781356;
                } else {
                  result[0] += -0.0010353814585518924;
                }
              }
            } else {
              result[0] += 0.0005841221000910927;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05473596564878090848) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8030059940338053481) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01129950000000000225) ) ) {
                    result[0] += -0.0004691555168136675;
                  } else {
                    result[0] += 0.0018781958376364284;
                  }
                } else {
                  result[0] += -0.0021906288544793684;
                }
              } else {
                result[0] += 0.0013132566629202253;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.51994285276381913) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.01537695356895864805) ) ) {
                  result[0] += -2.9849708473599304e-05;
                } else {
                  result[0] += -0.003589257173646233;
                }
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.09893965937729458371) ) ) {
                  result[0] += -0.003239556576962059;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1165587384072143268) ) ) {
                    result[0] += 0.0008055831404100848;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6059258460552764403) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3466557816143853721) ) ) {
                        result[0] += -0.00010163719916320777;
                      } else {
                        result[0] += -0.0035388579806528665;
                      }
                    } else {
                      result[0] += 0.0004136768608564615;
                    }
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0004705694822475382;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2646734959245704566) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02884459794480960168) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004132000000000001123) ) ) {
                  result[0] += 0.0006312455371226013;
                } else {
                  result[0] += 0.0004238956319777939;
                }
              } else {
                result[0] += 0.0005466084347913609;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06217080128912850362) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01127328256994905228) ) ) {
                  result[0] += -0.001963986368702307;
                } else {
                  result[0] += 0.00017096182858216807;
                }
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                  result[0] += 0.0005814581719409753;
                } else {
                  result[0] += 0.0002949086975941119;
                }
              }
            }
          } else {
            result[0] += 0.0005422300684156735;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -4.853928175861558e-06;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += 9.115350421309467e-07;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -6.067410163319803e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.381175493840676405e-06) ) ) {
                  result[0] += 0.00014004609915726091;
                } else {
                  result[0] += -2.6513327651495232e-05;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.794554612313755398e-06) ) ) {
                  result[0] += -6.067410163319803e-06;
                } else {
                  result[0] += -2.040531490838602e-05;
                }
              }
            }
          }
        } else {
          result[0] += 1.7712367267860331e-06;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -6.067410163319803e-06;
                } else {
                  result[0] += -6.067410163319803e-06;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -5.9699079510889045e-06;
                } else {
                  result[0] += -6.067410163319803e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -6.067410163319803e-06;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -6.067410163319803e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -6.067410163319803e-06;
                      } else {
                        result[0] += -6.067410163319803e-06;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -6.067410163319803e-06;
                      } else {
                        result[0] += -6.067410163319803e-06;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -6.067410163319803e-06;
                        } else {
                          result[0] += -6.067410163319803e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -6.067410163319803e-06;
                        } else {
                          result[0] += -6.067410163319803e-06;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -6.067410163319803e-06;
                    } else {
                      result[0] += -6.067410163319803e-06;
                    }
                  }
                }
              } else {
                result[0] += -6.067410163319803e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -6.067410163319803e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -6.067410163319803e-06;
                  } else {
                    result[0] += -6.067410163319803e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -6.067410163319803e-06;
                  } else {
                    result[0] += -6.067410163319803e-06;
                  }
                }
              } else {
                result[0] += -6.067410163319803e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7519737796733669821) ) ) {
            result[0] += -7.2240799939683185e-06;
          } else {
            result[0] += 2.0054515788939255e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9650000000000000799) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2150000000000000244) ) ) {
          result[0] += -1.5510712348793016e-05;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1604180000000000328) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6959555468592965033) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2323027026914575854) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07316210697219156789) ) ) {
                    result[0] += 0.00016107913385374938;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5309997332914574431) ) ) {
                      result[0] += 0.00010220849215822289;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5792515097236182742) ) ) {
                        result[0] += 0.002039118552429622;
                      } else {
                        result[0] += -6.392227660978296e-05;
                      }
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6116569490452262725) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02229191548174745338) ) ) {
                      result[0] += -0.00015806737325755788;
                    } else {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004295500000000001574) ) ) {
                        result[0] += 0.0001927189414240998;
                      } else {
                        result[0] += -0.0023888524214009037;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6915080527790725684) ) ) {
                      result[0] += 5.14104693342111e-05;
                    } else {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007543500000000000726) ) ) {
                        result[0] += -0.0024906833141579063;
                      } else {
                        result[0] += 2.5496155973331047e-05;
                      }
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7210440605025126848) ) ) {
                  result[0] += 0.0014317781011924753;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4950000000000000511) ) ) {
                    result[0] += -0.00017170323289685777;
                  } else {
                    result[0] += 0.0005396712349925489;
                  }
                }
              }
            } else {
              result[0] += 0.0013785808197372418;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.224356303145077041) ) ) {
              result[0] += -0.002669953502921588;
            } else {
              result[0] += -0.0001904655873844131;
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0004502346562887446;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3057749246864051029) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0175975000000000055) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03127843326018551334) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004132000000000001123) ) ) {
                  result[0] += 0.0006061712979189999;
                } else {
                  result[0] += 0.0002571445685608663;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3251271839107726103) ) ) {
                  result[0] += 0.0005321544745862023;
                } else {
                  result[0] += 0.00020305951620620382;
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021562361187840079) ) ) {
                result[0] += 0.00021693886423714234;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6503673217403566076) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6077784371608041525) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1643367459977091716) ) ) {
                      result[0] += 0.0005525922607361038;
                    } else {
                      result[0] += -6.733038479763502e-05;
                    }
                  } else {
                    result[0] += 0.0005851364384691733;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7519737796733669821) ) ) {
                    result[0] += -0.000800384805800523;
                  } else {
                    result[0] += 0.0003578602366528328;
                  }
                }
              }
            }
          } else {
            result[0] += 0.0005187985572641336;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -4.64417427469228e-06;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += 8.721446712370423e-07;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -5.805217789300067e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.381175493840676405e-06) ) ) {
                  result[0] += 0.00013399425525321295;
                } else {
                  result[0] += -2.5367601199353568e-05;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.794554612313755398e-06) ) ) {
                  result[0] += -5.805217789300067e-06;
                } else {
                  result[0] += -1.9523535398770223e-05;
                }
              }
            }
          }
        } else {
          result[0] += 1.6946958716524426e-06;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -5.805217789300067e-06;
                } else {
                  result[0] += -5.805217789300067e-06;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -5.711928962320678e-06;
                } else {
                  result[0] += -5.805217789300067e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -5.805217789300067e-06;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -5.805217789300067e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -5.805217789300067e-06;
                      } else {
                        result[0] += -5.805217789300067e-06;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -5.805217789300067e-06;
                      } else {
                        result[0] += -5.805217789300067e-06;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -5.805217789300067e-06;
                        } else {
                          result[0] += -5.805217789300067e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -5.805217789300067e-06;
                        } else {
                          result[0] += -5.805217789300067e-06;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -5.805217789300067e-06;
                    } else {
                      result[0] += -5.805217789300067e-06;
                    }
                  }
                }
              } else {
                result[0] += -5.805217789300067e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -5.805217789300067e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  result[0] += -5.805217789300067e-06;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -5.805217789300067e-06;
                  } else {
                    result[0] += -5.805217789300067e-06;
                  }
                }
              } else {
                result[0] += -5.805217789300067e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7519737796733669821) ) ) {
            result[0] += -6.911904183739152e-06;
          } else {
            result[0] += 1.9187895441380413e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9650000000000000799) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1350000000000000366) ) ) {
          result[0] += -1.723131706445546e-05;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.002347679878538096e-06) ) ) {
            result[0] += -0.0003991993349169323;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.115000000000000005) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6735883055778896233) ) ) {
                  result[0] += 0.00022450588415624603;
                } else {
                  result[0] += -0.0013661927633679821;
                }
              } else {
                result[0] += 0.002372509637947966;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.038494786985569569e-06) ) ) {
                result[0] += 0.0007703590139889452;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1604180000000000328) ) ) {
                  result[0] += 5.194487527020885e-05;
                } else {
                  result[0] += 0.0011073969924507592;
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.00043077856378457;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3057749246864051029) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03237403661108240877) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004132000000000001123) ) ) {
                  result[0] += 0.000581292752733061;
                } else {
                  result[0] += 0.00030851746152997435;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3251271839107726103) ) ) {
                  result[0] += 0.00047279054388402306;
                } else {
                  result[0] += 0.00021949132135423558;
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021562361187840079) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8440161800932387548) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4129968667336683663) ) ) {
                    if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6269304705026225166) ) ) {
                      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6782348568386622478) ) ) {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03468100000000001043) ) ) {
                          result[0] += 0.0006509697446186254;
                        } else {
                          result[0] += -0.0012104549543690037;
                        }
                      } else {
                        result[0] += 0.0007419346128616849;
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06315050000000001218) ) ) {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3725635588693467781) ) ) {
                          result[0] += -0.001944295961055008;
                        } else {
                          result[0] += 0.0003440150663950438;
                        }
                      } else {
                        result[0] += -0.0034884156490033033;
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4405029099497487777) ) ) {
                      result[0] += 0.0007600973774083104;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6959555468592965033) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3830383354773237436) ) ) {
                          result[0] += 0.0003364747010669979;
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6059258460552764403) ) ) {
                            result[0] += -0.0025082791296183126;
                          } else {
                            result[0] += 1.9052689268131306e-05;
                          }
                        }
                      } else {
                        result[0] += 0.0011019933741148403;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                    result[0] += -0.0030496560097416766;
                  } else {
                    result[0] += 0.0004633249468785492;
                  }
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6754021834779359024) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04928050000000000486) ) ) {
                    result[0] += 0.0005285424131280728;
                  } else {
                    result[0] += 0.00029805318406855337;
                  }
                } else {
                  result[0] += -0.0002219181659799105;
                }
              }
            }
          } else {
            result[0] += 0.0004963795973280767;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -4.443484516514376e-06;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += 1.693214287972321e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -5.554355593913992e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7104391779899498216) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.381175493840676405e-06) ) ) {
                    result[0] += 0.00011987754210137277;
                  } else {
                    result[0] += -2.214468335756316e-05;
                  }
                } else {
                  result[0] += -4.781400331511521e-06;
                }
              } else {
                result[0] += -5.554355593913992e-06;
              }
            }
          }
        } else {
          result[0] += 1.352871393447855e-07;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -5.554355593913992e-06;
                } else {
                  result[0] += -5.554355593913992e-06;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -5.465098078211878e-06;
                } else {
                  result[0] += -5.554355593913992e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -5.554355593913992e-06;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -5.554355593913992e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -5.554355593913992e-06;
                      } else {
                        result[0] += -5.554355593913992e-06;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -5.554355593913992e-06;
                      } else {
                        result[0] += -5.554355593913992e-06;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -5.554355593913992e-06;
                        } else {
                          result[0] += -5.554355593913992e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -5.554355593913992e-06;
                        } else {
                          result[0] += -5.554355593913992e-06;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -5.554355593913992e-06;
                    } else {
                      result[0] += -5.554355593913992e-06;
                    }
                  }
                }
              } else {
                result[0] += -5.554355593913992e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -5.554355593913992e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  result[0] += -5.554355593913992e-06;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -5.554355593913992e-06;
                  } else {
                    result[0] += -5.554355593913992e-06;
                  }
                }
              } else {
                result[0] += -5.554355593913992e-06;
              }
            }
          }
        } else {
          result[0] += -6.613218497729763e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9650000000000000799) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.03945373639888280493) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001939744889791500219) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2750000000000000777) ) ) {
              result[0] += -0.00018729959626129236;
            } else {
              result[0] += 0.0001827498287289296;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5687531224874372571) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003024500000000000712) ) ) {
                result[0] += 0.0004184138117106774;
              } else {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1044543990012605922) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4814085394974874643) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.009038634387355000757) ) ) {
                        result[0] += -0.0006220585514721756;
                      } else {
                        result[0] += 0.00010148431054212482;
                      }
                    } else {
                      result[0] += 0.0012290866526987344;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4832433377889447379) ) ) {
                      result[0] += -0.0018427670543356433;
                    } else {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6050000000000000933) ) ) {
                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.545000000000000151) ) ) {
                          result[0] += -0.0007780715623295655;
                        } else {
                          result[0] += -0.0030748590415535845;
                        }
                      } else {
                        result[0] += 8.976620041321285e-06;
                      }
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4814085394974874643) ) ) {
                    result[0] += -0.0014545115032903572;
                  } else {
                    result[0] += 0.0007659459742008491;
                  }
                }
              }
            } else {
              result[0] += -0.001134290572168176;
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1076318469022627677) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5745673188442211865) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09341808925382111273) ) ) {
                result[0] += 0.0001830928478892232;
              } else {
                result[0] += -0.0007938559653872384;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1250000000000000278) ) ) {
                result[0] += -0.0005425185946193436;
              } else {
                result[0] += -0.0005487844861109504;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1206324332205917643) ) ) {
              result[0] += 0.0006334886734212738;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5687531224874372571) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5408295445477387942) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5336217185678392427) ) ) {
                    result[0] += -0.0001412135281406859;
                  } else {
                    result[0] += 0.0013458594111441585;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2533229942273665936) ) ) {
                    result[0] += -0.00034753439402574507;
                  } else {
                    result[0] += -0.0019315063773744027;
                  }
                }
              } else {
                result[0] += 5.2975587840287e-06;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0004121632318265775;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.234744531431348824) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01195250000000000305) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03127843326018551334) ) ) {
                result[0] += 0.0003985993904584473;
              } else {
                result[0] += 0.00043025278980832253;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
                result[0] += 9.263487309924924e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08407783631914581002) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01989400000000000543) ) ) {
                    result[0] += 0.0004965573884455026;
                  } else {
                    result[0] += 0.00042393087868448096;
                  }
                } else {
                  result[0] += 0.00017705027841910412;
                }
              }
            }
          } else {
            result[0] += 0.00047492943300175453;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -4.251467210457196e-06;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += 1.6200450342153738e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -5.314333963577847e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7104391779899498216) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.381175493840676405e-06) ) ) {
                    result[0] += 0.0001146972466360647;
                  } else {
                    result[0] += -2.1187740123935133e-05;
                  }
                } else {
                  result[0] += -4.574780592559865e-06;
                }
              } else {
                result[0] += -5.314333963577847e-06;
              }
            }
          }
        } else {
          result[0] += 1.2944094545244118e-07;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -5.314333963577847e-06;
                } else {
                  result[0] += -5.314333963577847e-06;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -5.2289335531827915e-06;
                } else {
                  result[0] += -5.314333963577847e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -5.314333963577847e-06;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -5.314333963577847e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -5.314333963577847e-06;
                      } else {
                        result[0] += -5.314333963577847e-06;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -5.314333963577847e-06;
                      } else {
                        result[0] += -5.314333963577847e-06;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -5.314333963577847e-06;
                        } else {
                          result[0] += -5.314333963577847e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -5.314333963577847e-06;
                        } else {
                          result[0] += -5.314333963577847e-06;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -5.314333963577847e-06;
                    } else {
                      result[0] += -5.314333963577847e-06;
                    }
                  }
                }
              } else {
                result[0] += -5.314333963577847e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -5.314333963577847e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -5.314333963577847e-06;
                  } else {
                    result[0] += -5.314333963577847e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -5.314333963577847e-06;
                  } else {
                    result[0] += -5.314333963577847e-06;
                  }
                }
              } else {
                result[0] += -5.314333963577847e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7519737796733669821) ) ) {
            result[0] += -6.327439984137025e-06;
          } else {
            result[0] += 2.12165096917408e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
          result[0] += 6.699961143466966e-06;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006585500000000000208) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004570381822539301524) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
                result[0] += -0.00199781071690445;
              } else {
                result[0] += 0.000572952089794005;
              }
            } else {
              result[0] += 0.0005204434678001339;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1960530738562874242) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
                result[0] += 0.001946545753530738;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4093335132160804135) ) ) {
                  if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4601878067544193374) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3044676633919599085) ) ) {
                      result[0] += -0.001236116762246438;
                    } else {
                      result[0] += 0.0004706118534203626;
                    }
                  } else {
                    result[0] += -0.0035855189347545465;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.234671350732867934) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6717423563567840317) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5681735652491761712) ) ) {
                        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1828583041203602211) ) ) {
                          result[0] += 0.0009129687028970553;
                        } else {
                          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1044543990012605922) ) ) {
                            result[0] += -0.001941404337887069;
                          } else {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5224889643718594323) ) ) {
                              result[0] += -0.0012885614969841946;
                            } else {
                              result[0] += 0.00043325972002417534;
                            }
                          }
                        }
                      } else {
                        result[0] += -0.003843564344619425;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8030059940338053481) ) ) {
                        result[0] += 0.001035674564972738;
                      } else {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.767254320477387064) ) ) {
                          result[0] += -0.0004970416819360941;
                        } else {
                          result[0] += 0.0010200190821356141;
                        }
                      }
                    }
                  } else {
                    result[0] += -0.0013151133326507012;
                  }
                }
              }
            } else {
              result[0] += 0.0008363452508319995;
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4601878067544193374) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
            result[0] += 0.000394352328438248;
          } else {
            result[0] += 0.0004544061995003548;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2646734959245704566) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4138030768592965147) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06364359169843836206) ) ) {
                result[0] += -0.001173168011081998;
              } else {
                result[0] += 0.00011060441723046101;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01129950000000000225) ) ) {
                result[0] += 0.0004545792591609027;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09221529126392057074) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.51994285276381913) ) ) {
                    if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.03659918966571634041) ) ) {
                      result[0] += 0.0003671611763478371;
                    } else {
                      result[0] += -0.00041716534152096656;
                    }
                  } else {
                    result[0] += 0.0005425010899123074;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5424744603768845153) ) ) {
                    result[0] += -0.001556943302061852;
                  } else {
                    result[0] += 0.00023196279021144207;
                  }
                }
              }
            }
          } else {
            result[0] += 0.0004544061995003548;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -4.067747591876688e-06;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += 1.550037660046472e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -5.084684442490946e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7093978733165829942) ) ) {
                  result[0] += 8.844053757945523e-07;
                } else {
                  result[0] += -4.704258234800181e-06;
                }
              } else {
                result[0] += -5.084684442490946e-06;
              }
            }
          }
        } else {
          result[0] += 1.2384738446513433e-07;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -5.084684442490946e-06;
                } else {
                  result[0] += -5.084684442490946e-06;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -5.0029744594349065e-06;
                } else {
                  result[0] += -5.084684442490946e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -5.084684442490946e-06;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -5.084684442490946e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -5.084684442490946e-06;
                      } else {
                        result[0] += -5.084684442490946e-06;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -5.084684442490946e-06;
                      } else {
                        result[0] += -5.084684442490946e-06;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -5.084684442490946e-06;
                        } else {
                          result[0] += -5.084684442490946e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -5.084684442490946e-06;
                        } else {
                          result[0] += -5.084684442490946e-06;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -5.084684442490946e-06;
                    } else {
                      result[0] += -5.084684442490946e-06;
                    }
                  }
                }
              } else {
                result[0] += -5.084684442490946e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -5.084684442490946e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  result[0] += -5.084684442490946e-06;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -5.084684442490946e-06;
                  } else {
                    result[0] += -5.084684442490946e-06;
                  }
                }
              } else {
                result[0] += -5.084684442490946e-06;
              }
            }
          }
        } else {
          result[0] += -6.054010882386542e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9650000000000000799) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2150000000000000244) ) ) {
          result[0] += -1.5009682639977014e-05;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.966590843157139501) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6959555468592965033) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2273413669989351737) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02162700000000000386) ) ) {
                  result[0] += 8.720460004771335e-05;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5876205025125629255) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02733191529475900369) ) ) {
                      result[0] += 0.0007442581379578456;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.52572947701005035) ) ) {
                        result[0] += -0.002615835685956288;
                      } else {
                        result[0] += 0.002451716921500148;
                      }
                    }
                  } else {
                    result[0] += -0.0010983306145270631;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6116569490452262725) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02229191548174745338) ) ) {
                    result[0] += -0.00013700984568423976;
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00421750000000000163) ) ) {
                      result[0] += 0.00024151007079373387;
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0956005000000000188) ) ) {
                        result[0] += -0.0025650003789901865;
                      } else {
                        result[0] += -0.00030937240854312157;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6915080527790725684) ) ) {
                    result[0] += 0.00011515392391578096;
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007543500000000000726) ) ) {
                      result[0] += -0.002083365860693555;
                    } else {
                      result[0] += -0.0002251543606667889;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7210440605025126848) ) ) {
                result[0] += 0.0013700727371217586;
              } else {
                result[0] += 0.0002598387129542955;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7894192122613066243) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005046500000000001505) ) ) {
                result[0] += 0.00043882544999206363;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -0.0008300646046775492;
                } else {
                  result[0] += -0.002432326215532971;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1469960000000000155) ) ) {
                result[0] += -0.00013051863557973323;
              } else {
                result[0] += 0.0023872472189070395;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0003773110916650197;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3057749246864051029) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01195250000000000305) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03127843326018551334) ) ) {
                result[0] += 0.00036875582162602705;
              } else {
                result[0] += 0.0003864445732997908;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021562361187840079) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1165587384072143268) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5400528323115579843) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5353359946984925788) ) ) {
                      result[0] += 0.0002663785647570651;
                    } else {
                      result[0] += -0.0029513696265564527;
                    }
                  } else {
                    result[0] += 0.0006009819213999016;
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1507499186893259402) ) ) {
                    result[0] += -0.0017264984734485138;
                  } else {
                    result[0] += 6.374097721156623e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6503673217403566076) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04928050000000000486) ) ) {
                    result[0] += 0.00045388080367964994;
                  } else {
                    result[0] += 0.0002759980077846751;
                  }
                } else {
                  result[0] += -9.370503973220431e-05;
                }
              }
            }
          } else {
            result[0] += 0.00043476984115152565;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -3.891967090918466e-06;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += 1.4830555304445395e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -4.864958818339557e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7093978733165829942) ) ) {
                  result[0] += 8.461873653364438e-07;
                } else {
                  result[0] += -4.5009720548018796e-06;
                }
              } else {
                result[0] += -4.864958818339557e-06;
              }
            }
          }
        } else {
          result[0] += 1.1849553929973652e-07;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -4.864958818339557e-06;
                } else {
                  result[0] += -4.864958818339557e-06;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -4.786779787347397e-06;
                } else {
                  result[0] += -4.864958818339557e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -4.864958818339557e-06;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -4.864958818339557e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -4.864958818339557e-06;
                      } else {
                        result[0] += -4.864958818339557e-06;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -4.864958818339557e-06;
                      } else {
                        result[0] += -4.864958818339557e-06;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -4.864958818339557e-06;
                        } else {
                          result[0] += -4.864958818339557e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -4.864958818339557e-06;
                        } else {
                          result[0] += -4.864958818339557e-06;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -4.864958818339557e-06;
                    } else {
                      result[0] += -4.864958818339557e-06;
                    }
                  }
                }
              } else {
                result[0] += -4.864958818339557e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -4.864958818339557e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -4.864958818339557e-06;
                  } else {
                    result[0] += -4.864958818339557e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -4.864958818339557e-06;
                  } else {
                    result[0] += -4.864958818339557e-06;
                  }
                }
              } else {
                result[0] += -4.864958818339557e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7519737796733669821) ) ) {
            result[0] += -5.792397534538349e-06;
          } else {
            result[0] += 2.2915809316114775e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9650000000000000799) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3150000000000000577) ) ) {
          result[0] += -9.830348776374158e-06;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6959555468592965033) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6915080527790725684) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0683765000000000206) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3115605993075549196) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3998546246231156065) ) ) {
                      result[0] += -0.00016789076847060054;
                    } else {
                      result[0] += 0.00018205942975924375;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3212986210119083141) ) ) {
                      result[0] += -0.0019603171957238864;
                    } else {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0008935000000000000884) ) ) {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)5.354107497039817852e-06) ) ) {
                          result[0] += -0.00018719791848009887;
                        } else {
                          result[0] += 0.0014568483274150072;
                        }
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5745673188442211865) ) ) {
                          result[0] += -0.003090377823048346;
                        } else {
                          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001390500000000000243) ) ) {
                            result[0] += -0.0011297230895679071;
                          } else {
                            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007851000000000002074) ) ) {
                              result[0] += 0.0002536205404574532;
                            } else {
                              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01326604349644140181) ) ) {
                                result[0] += -0.0017901305207539383;
                              } else {
                                result[0] += -0.00013363023036628343;
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                } else {
                  result[0] += 0.001174331046950062;
                }
              } else {
                result[0] += -0.0021303008179478127;
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8030059940338053481) ) ) {
                result[0] += 0.000916004282303236;
              } else {
                result[0] += 0.00012196622633485532;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7894192122613066243) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006585500000000000208) ) ) {
                result[0] += 0.0004742867047452558;
              } else {
                result[0] += -0.0029630832858135695;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1469960000000000155) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0846450000000000119) ) ) {
                  result[0] += -7.153850080833961e-05;
                } else {
                  result[0] += -0.0015199803428571864;
                }
              } else {
                result[0] += 0.002080945615445001;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0003610062617285662;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021562361187840079) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01195250000000000305) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03127843326018551334) ) ) {
                result[0] += 0.0003528206925176935;
              } else {
                result[0] += 0.0003689685988483374;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1206324332205917643) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5400528323115579843) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5353359946984925788) ) ) {
                    result[0] += 0.00025486748731188777;
                  } else {
                    result[0] += -0.00282383142027617;
                  }
                } else {
                  result[0] += 0.0005736054020338606;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1507499186893259402) ) ) {
                  result[0] += -0.002573619258579188;
                } else {
                  result[0] += 6.098652388015008e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
              result[0] += 0.0004149811098626352;
            } else {
              result[0] += 0.00041598203321778054;
            }
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -3.7237826326888863e-06;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += 1.4189679148287078e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -4.654728247510508e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7093978733165829942) ) ) {
                  result[0] += 8.096208784481279e-07;
                } else {
                  result[0] += -4.306470526690372e-06;
                }
              } else {
                result[0] += -4.654728247510508e-06;
              }
            }
          }
        } else {
          result[0] += 1.1337496463551313e-07;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -4.654728247510508e-06;
                } else {
                  result[0] += -4.654728247510508e-06;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -4.57992758474839e-06;
                } else {
                  result[0] += -4.654728247510508e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -4.654728247510508e-06;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -4.654728247510508e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -4.654728247510508e-06;
                      } else {
                        result[0] += -4.654728247510508e-06;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -4.654728247510508e-06;
                      } else {
                        result[0] += -4.654728247510508e-06;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -4.654728247510508e-06;
                        } else {
                          result[0] += -4.654728247510508e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -4.654728247510508e-06;
                        } else {
                          result[0] += -4.654728247510508e-06;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -4.654728247510508e-06;
                    } else {
                      result[0] += -4.654728247510508e-06;
                    }
                  }
                }
              } else {
                result[0] += -4.654728247510508e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -4.654728247510508e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -4.654728247510508e-06;
                  } else {
                    result[0] += -4.654728247510508e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -4.654728247510508e-06;
                  } else {
                    result[0] += -4.654728247510508e-06;
                  }
                }
              } else {
                result[0] += -4.654728247510508e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
            result[0] += 4.6774121184941344e-05;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
              result[0] += -3.954486146425238e-05;
            } else {
              result[0] += 2.1778463483703238e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
          result[0] += 4.978091922453682e-06;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006585500000000000208) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06949760265420222571) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3245708964283948172) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3569067370100503234) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005656257031049250449) ) ) {
                    result[0] += -0.0014342068808159425;
                  } else {
                    result[0] += 0.0005054783038474794;
                  }
                } else {
                  result[0] += 0.0008465449249436735;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5041457217085428821) ) ) {
                  result[0] += -0.0010826258234453556;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5284121414321608645) ) ) {
                    result[0] += 0.0009310570871018563;
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01254618095428180168) ) ) {
                      result[0] += 0.0008051960581216194;
                    } else {
                      result[0] += -4.942902772855809e-05;
                    }
                  }
                }
              }
            } else {
              result[0] += 0.0005159503855886298;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9350000000000001643) ) ) {
              result[0] += 0.0027085971214715235;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2669585275879397535) ) ) {
                result[0] += 0.001625994647818877;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4093335132160804135) ) ) {
                  if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4601878067544193374) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3044676633919599085) ) ) {
                      result[0] += -0.0016071378783659982;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3687216492462311868) ) ) {
                        result[0] += 0.001090996163464342;
                      } else {
                        result[0] += -0.00029296572076722066;
                      }
                    }
                  } else {
                    result[0] += -0.0033832386343711587;
                  }
                } else {
                  result[0] += 0.00021843861301858335;
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0003454060161129307;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1251234928765115051) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01151200000000000313) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01043419202401875238) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004460500000000000922) ) ) {
                  result[0] += 0.0010243716608686955;
                } else {
                  result[0] += -0.002558612133728533;
                }
              } else {
                result[0] += 0.00037879546428077433;
              }
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2302999793555680907) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.8537219630417757221) ) ) {
                  result[0] += -0.00038187410297811983;
                } else {
                  result[0] += 0.0004462365373887158;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
                  result[0] += -0.003717499244651188;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3251271839107726103) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5400528323115579843) ) ) {
                      result[0] += 5.254593568738889e-05;
                    } else {
                      result[0] += 0.0004959195781059169;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6100010069597990858) ) ) {
                      result[0] += -0.0008918167343501106;
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9186477097784532253) ) ) {
                        result[0] += 0.0003291206653833937;
                      } else {
                        result[0] += -0.00044237605239541355;
                      }
                    }
                  }
                }
              }
            }
          } else {
            result[0] += 0.00039800610709722715;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -3.56286596766754e-06;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
            result[0] += 1.3576497319084054e-06;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -4.45358241810712e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7093978733165829942) ) ) {
                  result[0] += 7.746345474663254e-07;
                } else {
                  result[0] += -4.120374037307632e-06;
                }
              } else {
                result[0] += -4.45358241810712e-06;
              }
            }
          }
        } else {
          result[0] += 1.0847566652774781e-07;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -4.45358241810712e-06;
                } else {
                  result[0] += -4.45358241810712e-06;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -4.38201413338109e-06;
                } else {
                  result[0] += -4.45358241810712e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -4.45358241810712e-06;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -4.45358241810712e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -4.45358241810712e-06;
                      } else {
                        result[0] += -4.45358241810712e-06;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -4.45358241810712e-06;
                      } else {
                        result[0] += -4.45358241810712e-06;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -4.45358241810712e-06;
                        } else {
                          result[0] += -4.45358241810712e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -4.45358241810712e-06;
                        } else {
                          result[0] += -4.45358241810712e-06;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -4.45358241810712e-06;
                    } else {
                      result[0] += -4.45358241810712e-06;
                    }
                  }
                }
              } else {
                result[0] += -4.45358241810712e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -4.45358241810712e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -4.45358241810712e-06;
                  } else {
                    result[0] += -4.45358241810712e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -4.45358241810712e-06;
                  } else {
                    result[0] += -4.45358241810712e-06;
                  }
                }
              } else {
                result[0] += -4.45358241810712e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7519737796733669821) ) ) {
            result[0] += -5.4174290000769014e-06;
          } else {
            result[0] += 2.0984425550218488e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
          result[0] += 4.762972505090326e-06;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006585500000000000208) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004570381822539301524) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3457619648241206378) ) ) {
                result[0] += -0.002691233199867952;
              } else {
                result[0] += 0.0002606908667626796;
              }
            } else {
              result[0] += 0.0004556839763442501;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9350000000000001643) ) ) {
              result[0] += 0.002591549898616052;
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
                result[0] += 0.0016374382989748084;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4093335132160804135) ) ) {
                  if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4601878067544193374) ) ) {
                    result[0] += -2.791490059659002e-05;
                  } else {
                    result[0] += -0.0032370379745272375;
                  }
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1828583041203602211) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05701962466675345592) ) ) {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04653956279752540642) ) ) {
                        result[0] += 0.0008737399636741311;
                      } else {
                        result[0] += -0.0003685038817567902;
                      }
                    } else {
                      result[0] += 0.0010400867966836418;
                    }
                  } else {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1044543990012605922) ) ) {
                      result[0] += -0.0018113000172959466;
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.07274795227358500649) ) ) {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5224889643718594323) ) ) {
                          result[0] += -0.0002671996153229661;
                        } else {
                          result[0] += 0.0008317543018816347;
                        }
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5628434130653267031) ) ) {
                          result[0] += -0.0029931850944632395;
                        } else {
                          result[0] += 0.00020955193359856175;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0003304799074557596;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01151200000000000313) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01043419202401875238) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004460500000000000922) ) ) {
                  result[0] += 0.0009801052555306494;
                } else {
                  result[0] += -0.0024480462462278716;
                }
              } else {
                result[0] += 0.000411437840022758;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03603011311338780859) ) ) {
                result[0] += 2.7073116231466156e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08407783631914581002) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5386386389447237466) ) ) {
                    if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                      result[0] += 0.00040526173934240655;
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.0286104669690836512) ) ) {
                        if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.02125964230697484705) ) ) {
                          result[0] += 0.00015497039559342278;
                        } else {
                          result[0] += -0.0009005146201023285;
                        }
                      } else {
                        result[0] += 0.0005228336960612765;
                      }
                    }
                  } else {
                    result[0] += 0.0004998489594278551;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5424744603768845153) ) ) {
                    result[0] += -0.0010283229342841777;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3763200711443456803) ) ) {
                      result[0] += 0.0003135722396816837;
                    } else {
                      result[0] += 3.2739128879298084e-06;
                    }
                  }
                }
              }
            }
          } else {
            result[0] += 0.0003808069787565956;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -3.4089030310550925e-06;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6249533869346735049) ) ) {
            result[0] += 1.4529851693576627e-07;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -4.261128749133939e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7093978733165829942) ) ) {
                  result[0] += 7.411600887548064e-07;
                } else {
                  result[0] += -3.942319377805288e-06;
                }
              } else {
                result[0] += -4.261128749133939e-06;
              }
            }
          }
        } else {
          result[0] += 1.0378808290232803e-07;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -4.261128749133939e-06;
                } else {
                  result[0] += -4.261128749133939e-06;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -4.192653160957465e-06;
                } else {
                  result[0] += -4.261128749133939e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -4.261128749133939e-06;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -4.261128749133939e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -4.261128749133939e-06;
                      } else {
                        result[0] += -4.261128749133939e-06;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -4.261128749133939e-06;
                      } else {
                        result[0] += -4.261128749133939e-06;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -4.261128749133939e-06;
                        } else {
                          result[0] += -4.261128749133939e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -4.261128749133939e-06;
                        } else {
                          result[0] += -4.261128749133939e-06;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -4.261128749133939e-06;
                    } else {
                      result[0] += -4.261128749133939e-06;
                    }
                  }
                }
              } else {
                result[0] += -4.261128749133939e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -4.261128749133939e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -4.261128749133939e-06;
                  } else {
                    result[0] += -4.261128749133939e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -4.261128749133939e-06;
                  } else {
                    result[0] += -4.261128749133939e-06;
                  }
                }
              } else {
                result[0] += -4.261128749133939e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7519737796733669821) ) ) {
            result[0] += -5.183324409752571e-06;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0064655058205014505) ) ) {
              result[0] += -3.792668085538175e-05;
            } else {
              result[0] += 8.616011400125557e-05;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.168924500000000033) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5361772370603016258) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5336217185678392427) ) ) {
                result[0] += 6.245427459414765e-05;
              } else {
                result[0] += 0.0007288803959973938;
              }
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.07196201389915944657) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5408295445477387942) ) ) {
                  result[0] += -0.001299744218813357;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7250000000000000888) ) ) {
                    result[0] += 0.00033108165451028836;
                  } else {
                    result[0] += -0.0015825654998118759;
                  }
                }
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.01051018765715429869) ) ) {
                  if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.02125964230697484705) ) ) {
                    result[0] += 0.00023177634451889234;
                  } else {
                    result[0] += 0.002163250500431637;
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1076318469022627677) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03409611752714010457) ) ) {
                      result[0] += -0.00036080965065664637;
                    } else {
                      result[0] += 0.0009908514989005856;
                    }
                  } else {
                    result[0] += -4.849903923390448e-06;
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8327395279648243109) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9808239647505231362) ) ) {
                result[0] += 0.0020604673828482694;
              } else {
                result[0] += -0.0007355310251842951;
              }
            } else {
              result[0] += 0.0021084410294209726;
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006585500000000000208) ) ) {
            result[0] += 0.0004005185056614056;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9350000000000001643) ) ) {
              result[0] += 0.0024795606639972114;
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
                result[0] += 0.0015666793057037601;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1960530738562874242) ) ) {
                  result[0] += 6.363513352014269e-05;
                } else {
                  result[0] += 0.0007075765357009768;
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0003161988041234893;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01129950000000000225) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01043419202401875238) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004460500000000000922) ) ) {
                  result[0] += 0.0009377517444246549;
                } else {
                  result[0] += -0.0023422582675464714;
                }
              } else {
                result[0] += 0.0003713133094067611;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05701962466675345592) ) ) {
                result[0] += 0.00015911411232744435;
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1828583041203602211) ) ) {
                  result[0] += 0.00036439433338529776;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.51994285276381913) ) ) {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                      result[0] += 0.0003618282215757346;
                    } else {
                      result[0] += -0.0002713218195441938;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08407783631914581002) ) ) {
                      result[0] += 0.0003756265667963635;
                    } else {
                      result[0] += 0.00020067936365300527;
                    }
                  }
                }
              }
            }
          } else {
            result[0] += 0.00036435108025692053;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -3.261593329805858e-06;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6249533869346735049) ) ) {
            result[0] += 1.390196991088055e-07;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
              result[0] += -4.076991624287268e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7093978733165829942) ) ) {
                  result[0] += 7.091321694336286e-07;
                } else {
                  result[0] += -3.7719590347614584e-06;
                }
              } else {
                result[0] += -4.076991624287268e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06646350000000002256) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03705350000000001004) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1643367459977091716) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006452000000000001137) ) ) {
                    result[0] += 3.470155320381566e-05;
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01151200000000000313) ) ) {
                      result[0] += -0.00042185032962527763;
                    } else {
                      result[0] += -2.848049603962707e-07;
                    }
                  }
                } else {
                  result[0] += 1.699995988108422e-05;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7326471166347855446) ) ) {
                  result[0] += -0.00014538341554355463;
                } else {
                  result[0] += 6.182092016690355e-06;
                }
              }
            } else {
              result[0] += 0.00015970432573319268;
            }
          } else {
            result[0] += -0.00031175467047293013;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -4.076991624287268e-06;
                } else {
                  result[0] += -4.076991624287268e-06;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -4.011475087261634e-06;
                } else {
                  result[0] += -4.076991624287268e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -4.076991624287268e-06;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -4.076991624287268e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -4.076991624287268e-06;
                      } else {
                        result[0] += -4.076991624287268e-06;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -4.076991624287268e-06;
                      } else {
                        result[0] += -4.076991624287268e-06;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.310012234630710122e-06) ) ) {
                            result[0] += -4.076991624287268e-06;
                          } else {
                            result[0] += -4.076991624287268e-06;
                          }
                        } else {
                          result[0] += -4.076991624287268e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -4.076991624287268e-06;
                        } else {
                          result[0] += -4.076991624287268e-06;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -4.076991624287268e-06;
                    } else {
                      result[0] += -4.076991624287268e-06;
                    }
                  }
                }
              } else {
                result[0] += -4.076991624287268e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -4.076991624287268e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -4.076991624287268e-06;
                  } else {
                    result[0] += -4.076991624287268e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -4.076991624287268e-06;
                  } else {
                    result[0] += -4.076991624287268e-06;
                  }
                }
              } else {
                result[0] += -4.076991624287268e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7519737796733669821) ) ) {
            result[0] += -4.959336234282985e-06;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0064655058205014505) ) ) {
              result[0] += -3.6287746577907345e-05;
            } else {
              result[0] += 8.243685741768554e-05;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8850000000000001199) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.168924500000000033) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7536081807788946874) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.540399458636966701) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8697742174477757215) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
                    result[0] += 2.622555393524332e-05;
                  } else {
                    result[0] += -0.0006607946561739006;
                  }
                } else {
                  result[0] += 0.00021919438189261383;
                }
              } else {
                result[0] += -0.0005845028758321726;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.717118227269369246) ) ) {
                result[0] += -5.3254410860579576e-05;
              } else {
                result[0] += 0.0005327761460928016;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8327395279648243109) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9808239647505231362) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021562361187840079) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03536062175606080604) ) ) {
                    result[0] += -0.0014108123771221586;
                  } else {
                    result[0] += 0.0026893789298447243;
                  }
                } else {
                  result[0] += -0.0002892507499396002;
                }
              } else {
                result[0] += -0.0008743950331548767;
              }
            } else {
              result[0] += 0.00205350828129399;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.363906689523952442) ) ) {
            result[0] += 0.00027305833865883943;
          } else {
            result[0] += -0.0019801291256538846;
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0003025348333544561;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01129950000000000225) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01043419202401875238) ) ) {
                result[0] += 0.00011184338608512855;
              } else {
                result[0] += 0.00035526766299784655;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03603011311338780859) ) ) {
                result[0] += 2.1320144019730436e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3346339054385528144) ) ) {
                  result[0] += 0.000348162297204752;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6077784371608041525) ) ) {
                    result[0] += -0.000778324407158021;
                  } else {
                    result[0] += 0.00019277013047992408;
                  }
                }
              }
            }
          } else {
            result[0] += 0.00034860629423821144;
          }
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
    result[0] += -3.1206493561482474e-06;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6249533869346735049) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.244955337349149066) ) ) {
            result[0] += -5.705206849493139e-05;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4781247323869347032) ) ) {
              result[0] += 0.001405744855765932;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3212986210119083141) ) ) {
                result[0] += -1.5083909326178665e-06;
              } else {
                result[0] += 4.3362027538187214e-05;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4677590045467516222) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.485713013107980879e-05) ) ) {
              result[0] += -3.900811658856091e-06;
            } else {
              result[0] += -7.006158689509492e-05;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6647073645226131422) ) ) {
                result[0] += 0.00016356672240456577;
              } else {
                result[0] += -4.828336189384555e-06;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.016289495364576286e-06) ) ) {
                result[0] += -3.900811658856091e-06;
              } else {
                result[0] += -5.113663943064625e-05;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7608008567839197323) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.115699180057906622e-06) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                  result[0] += -3.900811658856091e-06;
                } else {
                  result[0] += -3.900811658856091e-06;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -3.8381263028315615e-06;
                } else {
                  result[0] += -3.900811658856091e-06;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0617095000000000074) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                    result[0] += -3.900811658856091e-06;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -3.900811658856091e-06;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                        result[0] += -3.900811658856091e-06;
                      } else {
                        result[0] += -3.900811658856091e-06;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8010032165075378074) ) ) {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                        result[0] += -3.900811658856091e-06;
                      } else {
                        result[0] += -3.900811658856091e-06;
                      }
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                          result[0] += -3.900811658856091e-06;
                        } else {
                          result[0] += -3.900811658856091e-06;
                        }
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                          result[0] += -3.900811658856091e-06;
                        } else {
                          result[0] += -3.900811658856091e-06;
                        }
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += -3.900811658856091e-06;
                    } else {
                      result[0] += -3.900811658856091e-06;
                    }
                  }
                }
              } else {
                result[0] += -3.900811658856091e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              result[0] += -3.900811658856091e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.717136164243549924e-06) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.086617471325609268e-06) ) ) {
                    result[0] += -3.900811658856091e-06;
                  } else {
                    result[0] += -3.900811658856091e-06;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                    result[0] += -3.900811658856091e-06;
                  } else {
                    result[0] += -3.900811658856091e-06;
                  }
                }
              } else {
                result[0] += -3.900811658856091e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7519737796733669821) ) ) {
            result[0] += -4.745027310734439e-06;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0064655058205014505) ) ) {
              result[0] += -3.47196359397628e-05;
            } else {
              result[0] += 7.887449476685671e-05;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8850000000000001199) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.168924500000000033) ) ) {
            result[0] += 8.386116607881149e-07;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8327395279648243109) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9808239647505231362) ) ) {
                result[0] += 0.002058233624126069;
              } else {
                result[0] += -0.0008366096019077978;
              }
            } else {
              result[0] += 0.0019647695613378862;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.051391296366422923) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02207100000000000381) ) ) {
                result[0] += 7.511143370718919e-05;
              } else {
                result[0] += 0.0014458706370877195;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03091100000000000445) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3837516359296482826) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002399500000000000157) ) ) {
                    result[0] += 0.0007837399307136984;
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007851000000000002074) ) ) {
                      result[0] += -0.0012760418967978798;
                    } else {
                      result[0] += 2.4622544221268764e-05;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4183012963065327328) ) ) {
                    result[0] += 0.0008437665118654691;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5829435000502513065) ) ) {
                      result[0] += 0.0001333735513506698;
                    } else {
                      result[0] += 0.0003388039445422351;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04160250000000000753) ) ) {
                  result[0] += -0.0017531223198777967;
                } else {
                  result[0] += -3.989892448176828e-06;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
              result[0] += 8.639449019802143e-05;
            } else {
              result[0] += -0.0015838855335363598;
            }
          }
        }
      } else {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.00028946132685898364;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3716644664679621957) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004295500000000001574) ) ) {
              result[0] += 0.00038099438291419943;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01065347450249755183) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4133512684738382403) ) ) {
                  result[0] += 0.00084583036377555;
                } else {
                  result[0] += -0.0017005729794315196;
                }
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
                  result[0] += -0.0005924739512192111;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01085750000000000083) ) ) {
                    result[0] += 0.00033991540075307866;
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06217080128912850362) ) ) {
                      result[0] += 0.00017604228832152847;
                    } else {
                      result[0] += 0.00033003006048678185;
                    }
                  }
                }
              }
            }
          } else {
            result[0] += 0.00033354189123524784;
          }
        }
      }
    }
  }
}

