
#include "header.h"

void predict_unit3(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.0003128236463249112;
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.363906689523952442) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7573260829648241765) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0001725283487249000298) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
                  result[0] += -0.0003910295542643924;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
                    result[0] += -0.0003910295542643924;
                  } else {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7255694492462312351) ) ) {
                      result[0] += -0.0003910295542643924;
                    } else {
                      result[0] += -0.0003910295542643924;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6852090990703517681) ) ) {
                  result[0] += -0.0003011179939334429;
                } else {
                  result[0] += -0.000300802798644055;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
                  result[0] += -0.0003162899193994439;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6754021834779359024) ) ) {
                    result[0] += -0.00039857124437106767;
                  } else {
                    result[0] += -0.0003910295542643924;
                  }
                }
              } else {
                result[0] += 1.0228712979261057e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.599834298791339877e-06) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                result[0] += -0.0003910295542643924;
              } else {
                result[0] += -0.0003910295542643924;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0133385000000000014) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -0.0003910295542643924;
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)79.50000000000001421) ) ) {
                      result[0] += -0.0003910295542643924;
                    } else {
                      result[0] += -0.0003910295542643924;
                    }
                  }
                } else {
                  result[0] += -0.0003910295542643924;
                }
              } else {
                result[0] += -0.000275324298957278;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0007055000000000000724) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
              result[0] += -0.0003143703631574009;
            } else {
              result[0] += -0.00021031549367069187;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.04500000000000000527) ) ) {
              result[0] += -1.8123909965549793e-05;
            } else {
              result[0] += 0.0033074442342132357;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.828053558455352334) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
              result[0] += -0.0003910295542643924;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)81.50000000000001421) ) ) {
                  result[0] += -0.0003910295542643924;
                } else {
                  result[0] += -0.0003910295542643924;
                }
              } else {
                result[0] += -0.0003910295542643924;
              }
            }
          } else {
            result[0] += -0.0003910295542643924;
          }
        } else {
          result[0] += -0.0004075965993285835;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5050000000000001155) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09500000000000001499) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05500000000000000722) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05530450000000000643) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7536081807788946874) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.00031820440584465345;
              } else {
                result[0] += -9.2845815578821e-05;
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                result[0] += -0.0003928409277421492;
              } else {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
                    result[0] += -0.00034399532862732613;
                  } else {
                    result[0] += -5.5316273975448486e-05;
                  }
                } else {
                  result[0] += -0.00032354702973140715;
                }
              }
            }
          } else {
            result[0] += 0.0005702784639187744;
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4184049418341709292) ) ) {
            result[0] += 0.0015087692251345994;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
              result[0] += -0.0003064775320179915;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7573260829648241765) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1350000000000000366) ) ) {
                  result[0] += 6.90469389683137e-05;
                } else {
                  result[0] += 0.0006080169913234732;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9993516786272610419) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0006285000000000000439) ) ) {
                    result[0] += 0.00030837267338139135;
                  } else {
                    result[0] += -0.0004937504733689849;
                  }
                } else {
                  result[0] += 8.353683896832921e-05;
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.008982725145665402047) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2650000000000000688) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)91.50000000000001421) ) ) {
              result[0] += -2.6849120074003505e-05;
            } else {
              result[0] += 0.0008794774879192386;
            }
          } else {
            result[0] += 0.0010875238662287074;
          }
        } else {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05227730674148379358) ) ) {
            result[0] += 0.003194910416220777;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1132595000000000129) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9567162861906464144) ) ) {
                result[0] += 0.0013954158406344294;
              } else {
                result[0] += 0.0004898806611077143;
              }
            } else {
              result[0] += 0.005169361368961194;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9750000000000000888) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7450000000000001066) ) ) {
          result[0] += 0.0031658279819053816;
        } else {
          result[0] += 0.008226626619887545;
        }
      } else {
        result[0] += 0.011017336033064326;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.00029954700587193764;
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.363906689523952442) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7573260829648241765) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0001725283487249000298) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
                  result[0] += -0.0003744337538527358;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
                    result[0] += -0.0003744337538527358;
                  } else {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7255694492462312351) ) ) {
                      result[0] += -0.0003744337538527358;
                    } else {
                      result[0] += -0.0003744337538527358;
                    }
                  }
                }
              } else {
                result[0] += -0.00028833815651916163;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
                  result[0] += -0.00030286616583062045;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6754021834779359024) ) ) {
                    result[0] += -0.00038165536486970547;
                  } else {
                    result[0] += -0.0003744337538527358;
                  }
                }
              } else {
                result[0] += 9.79459316089781e-06;
              }
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.599834298791339877e-06) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                result[0] += -0.0003744337538527358;
              } else {
                result[0] += -0.0003744337538527358;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0133385000000000014) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -0.0003744337538527358;
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)79.50000000000001421) ) ) {
                      result[0] += -0.0003744337538527358;
                    } else {
                      result[0] += -0.0003744337538527358;
                    }
                  }
                } else {
                  result[0] += -0.0003744337538527358;
                }
              } else {
                result[0] += -0.00026363917934382595;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0007055000000000000724) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
              result[0] += -0.00030102807804006525;
            } else {
              result[0] += -0.00020138943189767857;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.04500000000000000527) ) ) {
              result[0] += -1.7354707767948616e-05;
            } else {
              result[0] += 0.0031670720199264;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.828053558455352334) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
              result[0] += -0.0003744337538527358;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)81.50000000000001421) ) ) {
                  result[0] += -0.0003744337538527358;
                } else {
                  result[0] += -0.0003744337538527358;
                }
              } else {
                result[0] += -0.0003744337538527358;
              }
            }
          } else {
            result[0] += -0.0003744337538527358;
          }
        } else {
          result[0] += -0.000390297672080866;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5650000000000000577) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09500000000000001499) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05500000000000000722) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05530450000000000643) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7536081807788946874) ) ) {
              result[0] += -0.00012289246484060577;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)52.50000000000000711) ) ) {
                result[0] += -0.0003438714035848879;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.003859773430623800444) ) ) {
                  result[0] += -0.00014298046618460114;
                } else {
                  result[0] += -0.0003322858222562771;
                }
              }
            }
          } else {
            result[0] += 0.0005460751077707559;
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
            result[0] += 0.0009151059287625137;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09212750000000001493) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7573260829648241765) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.004134701972639751033) ) ) {
                  result[0] += -2.927181342396116e-05;
                } else {
                  result[0] += 0.00034279270291886447;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.00802520011231920051) ) ) {
                  result[0] += 2.2549326550091875e-05;
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8342136590201005841) ) ) {
                    result[0] += -0.0005889214755465429;
                  } else {
                    result[0] += -0.00012796609689928173;
                  }
                }
              }
            } else {
              result[0] += 0.0018334999418257035;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.008982725145665402047) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2650000000000000688) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)91.50000000000001421) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7269841738944724518) ) ) {
                result[0] += 7.252648803264932e-05;
              } else {
                result[0] += -0.0006116647324492475;
              }
            } else {
              result[0] += 0.0008421513249812218;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2323788471531250399) ) ) {
              result[0] += 0.0015075289587269595;
            } else {
              result[0] += 0.0008049953547073055;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.06355808660527756393) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)48.50000000000000711) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
                result[0] += 0.00131279500773819;
              } else {
                result[0] += 0.004134337174001084;
              }
            } else {
              result[0] += 0.0034355617355498087;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.144071500000000019) ) ) {
              result[0] += 0.0011988829396199184;
            } else {
              result[0] += 0.005470779200357587;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9750000000000000888) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02620539606947270075) ) ) {
          result[0] += 0.00303011012238614;
        } else {
          result[0] += 0.007024231477356896;
        }
      } else {
        result[0] += 0.010549746031544236;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.0002868338432243932;
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.363906689523952442) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7573260829648241765) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1507499186893259402) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.0141436144428988015) ) ) {
                  result[0] += -0.0002900121337382786;
                } else {
                  result[0] += -0.00035854230069130605;
                }
              } else {
                result[0] += 1.1770234263696144e-06;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0001725283487249000298) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4677590045467516222) ) ) {
                  result[0] += -0.00035854230069130605;
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                    result[0] += -0.00035854230069130605;
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)44.50000000000000711) ) ) {
                      result[0] += -0.00035854230069130605;
                    } else {
                      result[0] += -0.00035854230069130605;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6754021834779359024) ) ) {
                  result[0] += -0.0003654574171894312;
                } else {
                  result[0] += -0.00035854230069130605;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.599834298791339877e-06) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                result[0] += -0.00035854230069130605;
              } else {
                result[0] += -0.00035854230069130605;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0133385000000000014) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                    result[0] += -0.00035854230069130605;
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)79.50000000000001421) ) ) {
                      result[0] += -0.00035854230069130605;
                    } else {
                      result[0] += -0.00035854230069130605;
                    }
                  }
                } else {
                  result[0] += -0.00035854230069130605;
                }
              } else {
                result[0] += -0.00025244999133139053;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0007055000000000000724) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
              result[0] += -0.00028825205677268135;
            } else {
              result[0] += -0.00019284220373975023;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.04500000000000000527) ) ) {
              result[0] += -1.6618151507229755e-05;
            } else {
              result[0] += 0.00303265738410452;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.828053558455352334) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
              result[0] += -0.00035854230069130605;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)81.50000000000001421) ) ) {
                  result[0] += -0.00035854230069130605;
                } else {
                  result[0] += -0.00035854230069130605;
                }
              } else {
                result[0] += -0.00035854230069130605;
              }
            }
          } else {
            result[0] += -0.00035854230069130605;
          }
        } else {
          result[0] += -0.0003737329336963892;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5650000000000000577) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09500000000000001499) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0650000000000000161) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5881074671461999914) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01627850000000000477) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4330073079623726895) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5800027599246232457) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)6.243504382093530685e-06) ) ) {
                    result[0] += -0.00039921815262155587;
                  } else {
                    result[0] += 5.172431580414193e-05;
                  }
                } else {
                  result[0] += -0.0003020704531709177;
                }
              } else {
                result[0] += 0.00013933813626756345;
              }
            } else {
              result[0] += 0.0012725190736509956;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.168079446220334772) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)173.5000000000000284) ) ) {
                  result[0] += -0.00024421634617994735;
                } else {
                  result[0] += -0.0004127826299891263;
                }
              } else {
                result[0] += -0.00012907672389006104;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)123.5000000000000142) ) ) {
                result[0] += -0.0003286329958255189;
              } else {
                result[0] += 5.657632560760811e-05;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4184049418341709292) ) ) {
            result[0] += 0.0018137006356545437;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02664459509800340062) ) ) {
              result[0] += 4.0822384873616724e-05;
            } else {
              result[0] += 0.0003980772740407131;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.008982725145665402047) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2750000000000000777) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8324892801256282837) ) ) {
              result[0] += 0.00041772672639077364;
            } else {
              result[0] += -0.00043783216701632214;
            }
          } else {
            result[0] += 0.0014469032006474126;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.06355808660527756393) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0159540000000000029) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)48.50000000000000711) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03415342701090800376) ) ) {
                  result[0] += 0.0005438050685439995;
                } else {
                  result[0] += 0.0032435368748954157;
                }
              } else {
                result[0] += 0.0024184168364654104;
              }
            } else {
              result[0] += 0.0041444855686381225;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.144071500000000019) ) ) {
              result[0] += 0.0011480007958896287;
            } else {
              result[0] += 0.005238592249997338;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02620539606947270075) ) ) {
          result[0] += 0.002769620784983908;
        } else {
          result[0] += 0.0066303642207370065;
        }
      } else {
        result[0] += 0.009917626013433212;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.0002746602436548788;
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.363906689523952442) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7573260829648241765) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1507499186893259402) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5377715594472363136) ) ) {
                  result[0] += -0.000277703643405538;
                } else {
                  result[0] += -0.0003433253013711324;
                }
              } else {
                result[0] += 1.1270690286754877e-06;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0001725283487249000298) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4677590045467516222) ) ) {
                  result[0] += -0.0003433253013711324;
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                    result[0] += -0.0003433253013711324;
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)44.50000000000000711) ) ) {
                      result[0] += -0.0003433253013711324;
                    } else {
                      result[0] += -0.0003433253013711324;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6754021834779359024) ) ) {
                  result[0] += -0.00034994693137450363;
                } else {
                  result[0] += -0.0003433253013711324;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.402140754838179745e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -0.0003433253013711324;
                } else {
                  result[0] += -0.0003433253013711324;
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0133385000000000014) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    result[0] += -0.0003433253013711324;
                  } else {
                    result[0] += -0.0003433253013711324;
                  }
                } else {
                  result[0] += -0.0003433253013711324;
                }
              }
            } else {
              result[0] += -0.0004077165622247081;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0007055000000000000724) ) ) {
            result[0] += -0.0002760182663845144;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.04500000000000000527) ) ) {
              result[0] += -1.5912855647576612e-05;
            } else {
              result[0] += 0.002903947479406357;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.828053558455352334) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
              result[0] += -0.0003433253013711324;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)81.50000000000001421) ) ) {
                  result[0] += -0.0003433253013711324;
                } else {
                  result[0] += -0.0003433253013711324;
                }
              } else {
                result[0] += -0.0003433253013711324;
              }
            }
          } else {
            result[0] += -0.0003433253013711324;
          }
        } else {
          result[0] += -0.0003578712242495006;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5850000000000000755) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09500000000000001499) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03500000000000001027) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
              result[0] += -0.0003236818421424871;
            } else {
              result[0] += -0.00015065838813226696;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7392963230402010977) ) ) {
              result[0] += 4.04734994860382e-06;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
                result[0] += -0.0004500403722293663;
              } else {
                result[0] += -0.00014383158205329022;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3995174958040201285) ) ) {
            result[0] += 0.0015304797970366827;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.573103097775156778) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04770400000000000335) ) ) {
                  result[0] += -3.572579468709882e-05;
                } else {
                  result[0] += 0.0005895851881643824;
                }
              } else {
                result[0] += -0.0003541858084211901;
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)151.5000000000000284) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2150000000000000244) ) ) {
                  result[0] += 0.00029135209094615586;
                } else {
                  result[0] += 0.001325233983732842;
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1950000000000000344) ) ) {
                  result[0] += 0.0007001179204008949;
                } else {
                  result[0] += -0.0006798510480779756;
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02403426826619565679) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2850000000000000866) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.01704648841990550126) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.130629626450776108e-06) ) ) {
                result[0] += -9.767510497874971e-05;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)179.5000000000000284) ) ) {
                  result[0] += 0.0008671335644468369;
                } else {
                  result[0] += 0.0022369911022259116;
                }
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)47.50000000000000711) ) ) {
                result[0] += -6.991031424909562e-05;
              } else {
                result[0] += 0.00041869966260666227;
              }
            }
          } else {
            result[0] += 0.0015954222472109399;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.335710565658207782) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01962450000000000652) ) ) {
              result[0] += 0.0015411222705541097;
            } else {
              result[0] += 0.003884014275336335;
            }
          } else {
            result[0] += -0.0002781682296175934;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8250000000000000666) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9750000000000000888) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01391911106985315068) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004064500000000001272) ) ) {
              result[0] += 0.0025772671705441156;
            } else {
              result[0] += 0.0013865281085358497;
            }
          } else {
            result[0] += 0.004908903401198949;
          }
        } else {
          result[0] += 0.0037393036683155386;
        }
      } else {
        result[0] += 0.013500799648369075;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.0002630033074079798;
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.363906689523952442) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7573260829648241765) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0001725283487249000298) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
                result[0] += -0.0003287541311982133;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4677590045467516222) ) ) {
                  result[0] += -0.0003287541311982133;
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                    result[0] += -0.0003287541311982133;
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)44.50000000000000711) ) ) {
                      result[0] += -0.0003287541311982133;
                    } else {
                      result[0] += -0.0003287541311982133;
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5494686760804020631) ) ) {
                  result[0] += -0.00026591754133399993;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01096925634721525149) ) ) {
                    result[0] += -0.00033509473065354193;
                  } else {
                    result[0] += -0.0003287541311982133;
                  }
                }
              } else {
                result[0] += 1.8224344529671157e-05;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.402140754838179745e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -0.0003287541311982133;
                } else {
                  result[0] += -0.0003287541311982133;
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0133385000000000014) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    result[0] += -0.0003287541311982133;
                  } else {
                    result[0] += -0.0003287541311982133;
                  }
                } else {
                  result[0] += -0.0003287541311982133;
                }
              }
            } else {
              result[0] += -0.0003904125435964052;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0007055000000000000724) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
              result[0] += -0.0002643036938952145;
            } else {
              result[0] += -0.00017294315851863995;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.04500000000000000527) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5143309380402011355) ) ) {
                result[0] += 0.0005211089362090257;
              } else {
                result[0] += -0.00010596920223216693;
              }
            } else {
              result[0] += 0.002780700189659108;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.828053558455352334) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8324892801256282837) ) ) {
                result[0] += -0.0003287541311982133;
              } else {
                result[0] += -0.0003287541311982133;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)81.50000000000001421) ) ) {
                  result[0] += -0.0003287541311982133;
                } else {
                  result[0] += -0.0003287541311982133;
                }
              } else {
                result[0] += -0.0003287541311982133;
              }
            }
          } else {
            result[0] += -0.0003287541311982133;
          }
        } else {
          result[0] += -0.0003426827062821243;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5850000000000000755) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09500000000000001499) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03500000000000001027) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
              result[0] += -0.00030994436580472173;
            } else {
              result[0] += -0.00014426425113541367;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02985350000000000156) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7392963230402010977) ) ) {
                result[0] += -5.1276282065315795e-05;
              } else {
                result[0] += -0.0002868960681449165;
              }
            } else {
              result[0] += 0.00037257874970229594;
            }
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3995174958040201285) ) ) {
            result[0] += 0.0014655242534755948;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02180250462562445188) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.573103097775156778) ) ) {
                result[0] += -8.512419784141564e-06;
              } else {
                result[0] += -0.0002860589138510004;
              }
            } else {
              result[0] += 0.00028737966692742565;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02085144663384500344) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2850000000000000866) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.01704648841990550126) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.322824821631954977e-06) ) ) {
                result[0] += -0.0004804032398669917;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)189.5000000000000284) ) ) {
                  result[0] += 0.0008064468253870733;
                } else {
                  result[0] += 0.002150896597117784;
                }
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)24.50000000000000355) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)18.50000000000000355) ) ) {
                  result[0] += 2.6090106476885112e-05;
                } else {
                  result[0] += -0.000608543232660043;
                }
              } else {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
                  result[0] += 0.00043667918542101354;
                } else {
                  result[0] += -0.00030253406155752755;
                }
              }
            }
          } else {
            result[0] += 0.001474981141493558;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.335710565658207782) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02182250000000000509) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)48.50000000000000711) ) ) {
                result[0] += 0.0011143564203378;
              } else {
                result[0] += 0.0021625690007689383;
              }
            } else {
              result[0] += 0.003503427307777581;
            }
          } else {
            result[0] += -0.00010160889368280428;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0129473293797221032) ) ) {
          result[0] += 0.002315460289213603;
        } else {
          result[0] += 0.005418107437128875;
        }
      } else {
        result[0] += 0.009956917935687417;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.00025184110662354196;
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.363906689523952442) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7573260829648241765) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0001725283487249000298) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
                result[0] += -0.0003148013803476111;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4677590045467516222) ) ) {
                  result[0] += -0.0003148013803476111;
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                    result[0] += -0.0003148013803476111;
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)44.50000000000000711) ) ) {
                      result[0] += -0.0003148013803476111;
                    } else {
                      result[0] += -0.0003148013803476111;
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.000314532277099779;
              } else {
                result[0] += 1.7450879759171438e-05;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.402140754838179745e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -0.0003148013803476111;
                } else {
                  result[0] += -0.0003148013803476111;
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0133385000000000014) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    result[0] += -0.0003148013803476111;
                  } else {
                    result[0] += -0.0003148013803476111;
                  }
                } else {
                  result[0] += -0.0003148013803476111;
                }
              }
            } else {
              result[0] += -0.00037384292991612516;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0007055000000000000724) ) ) {
            result[0] += -0.0002530863030251045;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.04500000000000000527) ) ) {
              result[0] += -1.5253688384475817e-05;
            } else {
              result[0] += 0.002662683674413727;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.828053558455352334) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
              result[0] += -0.0003148013803476111;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)81.50000000000001421) ) ) {
                  result[0] += -0.0003148013803476111;
                } else {
                  result[0] += -0.0003148013803476111;
                }
              } else {
                result[0] += -0.0003148013803476111;
              }
            }
          } else {
            result[0] += -0.0003148013803476111;
          }
        } else {
          result[0] += -0.00032813880867652495;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5850000000000000755) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09500000000000001499) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03500000000000001027) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -0.0002797499946124619;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02985350000000000156) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7392963230402010977) ) ) {
                result[0] += -4.910005028506422e-05;
              } else {
                result[0] += -0.0002747198276692344;
              }
            } else {
              result[0] += 0.0003567660253180334;
            }
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.029997717272797003e-05) ) ) {
              result[0] += -2.914061336514355e-05;
            } else {
              result[0] += 0.001166872519032152;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02180250462562445188) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.09500000000000001499) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5326995889949749374) ) ) {
                  result[0] += -0.000470733956381398;
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)49.50000000000000711) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8030059940338053481) ) ) {
                      result[0] += -6.671535698310425e-05;
                    } else {
                      result[0] += -0.0003497475993049236;
                    }
                  } else {
                    result[0] += -7.624354861884471e-06;
                  }
                }
              } else {
                result[0] += 9.166889271237413e-05;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02321150000000000296) ) ) {
                result[0] += -3.882054605554226e-06;
              } else {
                result[0] += 0.0008499599218340313;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.29500000000000004) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.140339474584314505) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
                result[0] += -0.00012912246995851084;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)78.50000000000001421) ) ) {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4573392949246231631) ) ) {
                    result[0] += 0.0012543359691958979;
                  } else {
                    result[0] += 0.00018953617227594202;
                  }
                } else {
                  result[0] += 0.000962830645649261;
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8106783849246231854) ) ) {
                  result[0] += -0.0001878994987620819;
                } else {
                  result[0] += -0.0008025978303158049;
                }
              } else {
                result[0] += 0.00014424286556575838;
              }
            }
          } else {
            result[0] += 0.0022196858017648926;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01184520638735680163) ) ) {
            result[0] += 0.0013403795248808335;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)48.50000000000000711) ) ) {
              result[0] += 0.0018765674757709678;
            } else {
              result[0] += 0.003026672110098782;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8250000000000000666) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9750000000000000888) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01391911106985315068) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003047500000000000295) ) ) {
              result[0] += 0.00268187752058885;
            } else {
              result[0] += 0.001237104659131194;
            }
          } else {
            result[0] += 0.004470611694465136;
          }
        } else {
          result[0] += 0.003384615818893757;
        }
      } else {
        result[0] += 0.012505223751630629;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.000241152644088178;
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.363906689523952442) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7573260829648241765) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0001725283487249000298) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
                result[0] += -0.00030144080230283624;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4677590045467516222) ) ) {
                  result[0] += -0.00030144080230283624;
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                    result[0] += -0.00030144080230283624;
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)44.50000000000000711) ) ) {
                      result[0] += -0.00030144080230283624;
                    } else {
                      result[0] += -0.00030144080230283624;
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5494686760804020631) ) ) {
                  result[0] += -0.00024128249973508293;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01096925634721525149) ) ) {
                    result[0] += -0.0003075237196004842;
                  } else {
                    result[0] += -0.0003014522233929877;
                  }
                }
              } else {
                result[0] += 1.6710241834665118e-05;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.402140754838179745e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -0.00030144080230283624;
                } else {
                  result[0] += -0.00030144080230283624;
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0133385000000000014) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    result[0] += -0.00030144080230283624;
                  } else {
                    result[0] += -0.00030144080230283624;
                  }
                } else {
                  result[0] += -0.00030144080230283624;
                }
              }
            } else {
              result[0] += -0.0003579765520872974;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004773500000000000833) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)159.5000000000000284) ) ) {
                result[0] += -0.0003184682801236996;
              } else {
                result[0] += -8.409264570648255e-05;
              }
            } else {
              result[0] += 9.897776935710024e-05;
            }
          } else {
            result[0] += 7.899297603316772e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.828053558455352334) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
              result[0] += -0.00030144080230283624;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)81.50000000000001421) ) ) {
                  result[0] += -0.00030144080230283624;
                } else {
                  result[0] += -0.00030144080230283624;
                }
              } else {
                result[0] += -0.00030144080230283624;
              }
            }
          } else {
            result[0] += -0.00030144080230283624;
          }
        } else {
          result[0] += -0.00031421217291018527;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6150000000000001021) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09500000000000001499) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05500000000000000722) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05530450000000000643) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.402140754838179745e-06) ) ) {
                result[0] += -0.00020788513581749873;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)107.5000000000000142) ) ) {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
                    result[0] += 0.0003280377448376246;
                  } else {
                    result[0] += -0.00022989935740455277;
                  }
                } else {
                  result[0] += 0.0003137829747800565;
                }
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.168079446220334772) ) ) {
                  result[0] += -0.0003031458882719279;
                } else {
                  result[0] += -0.00021013730629426054;
                }
              } else {
                result[0] += -0.00013989947689531707;
              }
            }
          } else {
            result[0] += 0.0005015037688176293;
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
            result[0] += 0.000813863983227346;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
              result[0] += -0.00030367274814873014;
            } else {
              result[0] += 6.38757106283636e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01896216239618550223) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2850000000000000866) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.140339474584314505) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4519613501507538378) ) ) {
                  result[0] += 0.001004201704349266;
                } else {
                  result[0] += 2.7963949622021605e-05;
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.676837902221867901e-06) ) ) {
                  result[0] += 0.00012752136474633366;
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05740595745564833902) ) ) {
                    result[0] += 0.0016776656843731955;
                  } else {
                    result[0] += 0.0007295938477540728;
                  }
                }
              }
            } else {
              result[0] += -0.00023761219635149645;
            }
          } else {
            result[0] += 0.0013412854488582889;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
            result[0] += 0.0022869387871419264;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7392963230402010977) ) ) {
              result[0] += -0.000756262411376043;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02359730123255650638) ) ) {
                result[0] += -9.008268460310786e-05;
              } else {
                result[0] += 0.00155524764030196;
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8450000000000000844) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02620539606947270075) ) ) {
            result[0] += 0.0025746117373436728;
          } else {
            result[0] += 0.005624719612446178;
          }
        } else {
          result[0] += 0.003438783358261909;
        }
      } else {
        result[0] += 0.012398898408226078;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.0002309178137374147;
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.363906689523952442) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7573260829648241765) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0001725283487249000298) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
                result[0] += -0.0002886472644835312;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4677590045467516222) ) ) {
                  result[0] += -0.0002886472644835312;
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                    result[0] += -0.0002886472644835312;
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)44.50000000000000711) ) ) {
                      result[0] += -0.0002886472644835312;
                    } else {
                      result[0] += -0.0002886472644835312;
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01096925634721525149) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3230417339964383738) ) ) {
                  result[0] += -0.0002944720148976497;
                } else {
                  result[0] += -0.00028813141544232107;
                }
              } else {
                result[0] += -4.145811680949986e-05;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.402140754838179745e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -0.0002886472644835312;
                } else {
                  result[0] += -0.0002886472644835312;
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0133385000000000014) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    result[0] += -0.0002886472644835312;
                  } else {
                    result[0] += -0.0002886472644835312;
                  }
                } else {
                  result[0] += -0.0002886472644835312;
                }
              }
            } else {
              result[0] += -0.000342783563870154;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004773500000000000833) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
              result[0] += -0.00029523851510215084;
            } else {
              result[0] += 9.477702471381749e-05;
            }
          } else {
            result[0] += 7.5640411885848e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.828053558455352334) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
              result[0] += -0.0002886472644835312;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)81.50000000000001421) ) ) {
                  result[0] += -0.0002886472644835312;
                } else {
                  result[0] += -0.0002886472644835312;
                }
              } else {
                result[0] += -0.0002886472644835312;
              }
            }
          } else {
            result[0] += -0.0002886472644835312;
          }
        } else {
          result[0] += -0.00030087660159169475;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6150000000000001021) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1050000000000000239) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04500000000000000527) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)56.50000000000000711) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
                result[0] += -0.000367779717993887;
              } else {
                result[0] += -0.00022559081072605916;
              }
            } else {
              result[0] += -0.0001738752817617711;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6413622072216433878) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01848850000000000146) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.008982725145665402047) ) ) {
                  result[0] += 0.00022030643196035393;
                } else {
                  result[0] += -0.0002109082975982419;
                }
              } else {
                result[0] += 0.0010469027859899074;
              }
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7948036090201006099) ) ) {
                result[0] += -0.0003616316269439743;
              } else {
                result[0] += 2.132353623865285e-05;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3995174958040201285) ) ) {
            result[0] += 0.0016756751600698258;
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7573260829648241765) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.004134701972639751033) ) ) {
                result[0] += -1.5745347698139705e-05;
              } else {
                result[0] += 0.000424207541656835;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.007692735115326951138) ) ) {
                  result[0] += -2.8473018469384323e-05;
                } else {
                  result[0] += -0.0006608699023914973;
                }
              } else {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
                  result[0] += 0.0005432481652587222;
                } else {
                  result[0] += -0.00026229669579575264;
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01840935775314125541) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2850000000000000866) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)91.50000000000001421) ) ) {
              result[0] += 0.00010439260978224216;
            } else {
              result[0] += 0.000687629194694106;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00526800000000000098) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.29500000000000004) ) ) {
                result[0] += 0.0001703606235059067;
              } else {
                result[0] += 0.0015686133563075797;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006229000000000001029) ) ) {
                result[0] += -0.0007430149098800553;
              } else {
                result[0] += 0.0010558062122674261;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
            result[0] += 0.0022201730789680155;
          } else {
            result[0] += 0.0008333425887201608;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02664459509800340062) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)81.50000000000001421) ) ) {
              result[0] += 0.002032772808013346;
            } else {
              result[0] += 0.0031767536347348134;
            }
          } else {
            result[0] += 0.005810411770481623;
          }
        } else {
          result[0] += 0.004404581094412224;
        }
      } else {
        result[0] += 0.013145913257190655;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.00022111736283417924;
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.363906689523952442) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7573260829648241765) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0001725283487249000298) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
                result[0] += -0.0002763967009685792;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4677590045467516222) ) ) {
                  result[0] += -0.0002763967009685792;
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                    result[0] += -0.0002763967009685792;
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)44.50000000000000711) ) ) {
                      result[0] += -0.0002763967009685792;
                    } else {
                      result[0] += -0.0002763967009685792;
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01096925634721525149) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3230417339964383738) ) ) {
                  result[0] += -0.0002819742414358631;
                } else {
                  result[0] += -0.00027590274522836666;
                }
              } else {
                result[0] += -3.9698580670836526e-05;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.402140754838179745e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -0.0002763967009685792;
                } else {
                  result[0] += -0.0002763967009685792;
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0133385000000000014) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    result[0] += -0.0002763967009685792;
                  } else {
                    result[0] += -0.0002763967009685792;
                  }
                } else {
                  result[0] += -0.0002763967009685792;
                }
              }
            } else {
              result[0] += -0.0003282353857379738;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004773500000000000833) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
              result[0] += -0.00028270821037956653;
            } else {
              result[0] += 9.075456511042478e-05;
            }
          } else {
            result[0] += 7.243013490032829e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.828053558455352334) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
              result[0] += -0.0002763967009685792;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)81.50000000000001421) ) ) {
                  result[0] += -0.0002763967009685792;
                } else {
                  result[0] += -0.0002763967009685792;
                }
              } else {
                result[0] += -0.0002763967009685792;
              }
            }
          } else {
            result[0] += -0.0002763967009685792;
          }
        } else {
          result[0] += -0.0002881070091808431;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6150000000000001021) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2050000000000000433) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)397.5000000000000568) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1250000000000000278) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06439350000000000629) ) ) {
                result[0] += -0.00015756526130044176;
              } else {
                result[0] += 0.0009428414521601741;
              }
            } else {
              result[0] += 0.0007872842480826718;
            }
          } else {
            result[0] += -0.00028939954780256847;
          }
        } else {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)6.243504382093530685e-06) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1550000000000000266) ) ) {
                result[0] += -0.0002987135033792995;
              } else {
                result[0] += 0.001342517976129521;
              }
            } else {
              result[0] += 0.0008949090179511668;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02620539606947270075) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)125.5000000000000142) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7269841738944724518) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.09900846148772847466) ) ) {
                      result[0] += -0.0004376330759490263;
                    } else {
                      result[0] += 2.5596489372708677e-05;
                    }
                  } else {
                    result[0] += -0.00039619193591119284;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1350000000000000366) ) ) {
                    result[0] += 0.0005094580336184832;
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
                      result[0] += 0.0006868928080424956;
                    } else {
                      result[0] += -0.0005799099344736995;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1850000000000000255) ) ) {
                  result[0] += 0.0003896485603443844;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.115000000000000005) ) ) {
                    result[0] += -0.00065353603951302;
                  } else {
                    result[0] += 3.6598130901002485e-05;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.194581012612933923) ) ) {
                result[0] += 0.0007265466143813907;
              } else {
                result[0] += -0.0004551129379529176;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0129473293797221032) ) ) {
          result[0] += 0.0009607929510130732;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0159540000000000029) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3050000000000000488) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7218051716834171794) ) ) {
                result[0] += 0.0007428134162389325;
              } else {
                result[0] += -0.0005795398814636283;
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4131576219849246168) ) ) {
                result[0] += -0.00028626287616717746;
              } else {
                result[0] += 0.0019776021407539304;
              }
            }
          } else {
            result[0] += 0.003086579942814682;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02620539606947270075) ) ) {
            result[0] += 0.0024342748351819533;
          } else {
            result[0] += 0.005445549600076049;
          }
        } else {
          result[0] += 0.004006836482940732;
        }
      } else {
        result[0] += 0.012587983683157044;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.00021173285575247998;
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.363906689523952442) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7573260829648241765) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001009954059381500341) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
                result[0] += -0.0002646660672257052;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4677590045467516222) ) ) {
                  result[0] += -0.0002646660672257052;
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                    result[0] += -0.0002646660672257052;
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)44.50000000000000711) ) ) {
                      result[0] += -0.0002646660672257052;
                    } else {
                      result[0] += -0.0002646660672257052;
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01096925634721525149) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5494686760804020631) ) ) {
                  result[0] += 4.563948110398925e-05;
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6488668789195980446) ) ) {
                    result[0] += -0.00027053367506178695;
                  } else {
                    result[0] += -0.00026419307560645835;
                  }
                }
              } else {
                result[0] += -3.801372152335179e-05;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.402140754838179745e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -0.0002646660672257052;
                } else {
                  result[0] += -0.0002646660672257052;
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0133385000000000014) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    result[0] += -0.0002646660672257052;
                  } else {
                    result[0] += -0.0002646660672257052;
                  }
                } else {
                  result[0] += -0.0002646660672257052;
                }
              }
            } else {
              result[0] += -0.00031430465111614175;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008633000000000001783) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5927985607788945899) ) ) {
              result[0] += 3.839169426174904e-05;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4868404241646586694) ) ) {
                result[0] += -0.00036194899698744227;
              } else {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7496778360301509236) ) ) {
                  result[0] += -3.309335328671148e-05;
                } else {
                  result[0] += -0.00030297680519029757;
                }
              }
            }
          } else {
            result[0] += 0.0002181700930105084;
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.828053558455352334) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
              result[0] += -0.0002646660672257052;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)81.50000000000001421) ) ) {
                  result[0] += -0.0002646660672257052;
                } else {
                  result[0] += -0.0002646660672257052;
                }
              } else {
                result[0] += -0.0002646660672257052;
              }
            }
          } else {
            result[0] += -0.0002646660672257052;
          }
        } else {
          result[0] += -0.000275879374800216;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6350000000000001199) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2050000000000000433) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)384.5000000000000568) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.09500000000000001499) ) ) {
              result[0] += -0.0001719556916335066;
            } else {
              result[0] += 0.00038774041326826723;
            }
          } else {
            result[0] += -0.0003076627684101512;
          }
        } else {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.360629054696599941e-06) ) ) {
              result[0] += -0.00022943275702024037;
            } else {
              result[0] += 0.0008058704127719708;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05686650000000000732) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.0650000000000000161) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)125.5000000000000142) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08500000000000000611) ) ) {
                    result[0] += -0.00020013015635282042;
                  } else {
                    result[0] += -1.700759979385058e-05;
                  }
                } else {
                  result[0] += 4.2171834943259645e-05;
                }
              } else {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8352912313316583903) ) ) {
                  result[0] += 0.00020525728169916048;
                } else {
                  result[0] += -0.00029697437985227147;
                }
              }
            } else {
              result[0] += 0.0008473443970854208;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01344341525633075199) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4550000000000000711) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8106783849246231854) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)51.50000000000000711) ) ) {
                result[0] += 0.00025694186117198106;
              } else {
                result[0] += 0.0010438772982086697;
              }
            } else {
              result[0] += -0.00035262588905405706;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001919500000000000199) ) ) {
              result[0] += 0.0022656048322041104;
            } else {
              result[0] += 0.0006670433661114521;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.144071500000000019) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
              result[0] += 0.002105798860147765;
            } else {
              result[0] += 0.0008822121675835416;
            }
          } else {
            result[0] += 0.005622100623394741;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02708729125130565282) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)80.50000000000001421) ) ) {
              result[0] += 0.0019506645772029033;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3460056117438527479) ) ) {
                result[0] += 0.003788309428058688;
              } else {
                result[0] += 0.0020207908438567438;
              }
            }
          } else {
            result[0] += 0.005773310131105493;
          }
        } else {
          result[0] += 0.004209083108471805;
        }
      } else {
        result[0] += 0.01205373336240095;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.00020274663929815455;
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.363906689523952442) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7573260829648241765) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001009954059381500341) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
                result[0] += -0.0002534332967624117;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4677590045467516222) ) ) {
                  result[0] += -0.0002534332967624117;
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                    result[0] += -0.0002534332967624117;
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)44.50000000000000711) ) ) {
                      result[0] += -0.0002534332967624117;
                    } else {
                      result[0] += -0.0002534332967624117;
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01096925634721525149) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5494686760804020631) ) ) {
                  result[0] += 4.370248245252348e-05;
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6488668789195980446) ) ) {
                    result[0] += -0.0002590518757271984;
                  } else {
                    result[0] += -0.0002529803795197019;
                  }
                }
              } else {
                result[0] += -3.640036997888189e-05;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.402140754838179745e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -0.0002534332967624117;
                } else {
                  result[0] += -0.0002534332967624117;
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0133385000000000014) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    result[0] += -0.0002534332967624117;
                  } else {
                    result[0] += -0.0002534332967624117;
                  }
                } else {
                  result[0] += -0.0002534332967624117;
                }
              }
            } else {
              result[0] += -0.0003009651549028914;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004773500000000000833) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.03500000000000001027) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)159.5000000000000284) ) ) {
                result[0] += -0.00028017087213181235;
              } else {
                result[0] += -3.178646585763698e-05;
              }
            } else {
              result[0] += 0.00017437365701460935;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
              result[0] += -2.371632347770841e-05;
            } else {
              result[0] += 0.0008616993599906698;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.828053558455352334) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
              result[0] += -0.0002534332967624117;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)81.50000000000001421) ) ) {
                  result[0] += -0.0002534332967624117;
                } else {
                  result[0] += -0.0002534332967624117;
                }
              } else {
                result[0] += -0.0002534332967624117;
              }
            }
          } else {
            result[0] += -0.0002534332967624117;
          }
        } else {
          result[0] += -0.0002641706970495279;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6350000000000001199) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2350000000000000144) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05500000000000000722) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)55.50000000000000711) ) ) {
                result[0] += -0.00039854373477650354;
              } else {
                result[0] += -0.00022950240247332913;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.05721739154190200877) ) ) {
                result[0] += -0.0004555528429944701;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.720904137215244607e-05) ) ) {
                  result[0] += 3.33713180908579e-05;
                } else {
                  result[0] += -0.000252807309995912;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4992188184422110542) ) ) {
              result[0] += 0.0011466464027641585;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05500000000000000722) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02318580028060065329) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.002336892070558550458) ) ) {
                    result[0] += 7.880818605793366e-05;
                  } else {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7536081807788946874) ) ) {
                      result[0] += -0.0001876286975812032;
                    } else {
                      result[0] += -0.0003450469539072699;
                    }
                  }
                } else {
                  result[0] += 0.00015015790239919735;
                }
              } else {
                result[0] += 0.0009942181438366005;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04528350000000001124) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.027057242659878707e-06) ) ) {
                result[0] += -4.899109518990749e-05;
              } else {
                result[0] += 0.0006749943989571148;
              }
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
                result[0] += 8.366202648774361e-05;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.264417267085903962) ) ) {
                  result[0] += -0.0006690362324470755;
                } else {
                  result[0] += 2.5313396735817067e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.247314011309283543) ) ) {
              result[0] += 0.0016718726722650546;
            } else {
              result[0] += -0.00011545472692931698;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0129473293797221032) ) ) {
          result[0] += 0.000960057571957369;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)31.50000000000000355) ) ) {
            result[0] += 0.001130288416436384;
          } else {
            result[0] += 0.0023126996759664513;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02620539606947270075) ) ) {
            result[0] += 0.002367619617967704;
          } else {
            result[0] += 0.005216429435884909;
          }
        } else {
          result[0] += 0.004030444173326146;
        }
      } else {
        result[0] += 0.011542157316764065;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.0001941418095014501;
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.363906689523952442) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7573260829648241765) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001009954059381500341) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
                result[0] += -0.00024267725961670458;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4677590045467516222) ) ) {
                  result[0] += -0.00024267725961670458;
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                    result[0] += -0.00024267725961670458;
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)44.50000000000000711) ) ) {
                      result[0] += -0.00024267725961670458;
                    } else {
                      result[0] += -0.00024267725961670458;
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01096925634721525149) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5494686760804020631) ) ) {
                  result[0] += 4.1847692530978094e-05;
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6488668789195980446) ) ) {
                    result[0] += -0.00024805737881782416;
                  } else {
                    result[0] += -0.0002422435647680083;
                  }
                }
              } else {
                result[0] += -3.4855491162199044e-05;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.402140754838179745e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -0.00024267725961670458;
                } else {
                  result[0] += -0.00024267725961670458;
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0133385000000000014) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    result[0] += -0.00024267725961670458;
                  } else {
                    result[0] += -0.00024267725961670458;
                  }
                } else {
                  result[0] += -0.00024267725961670458;
                }
              }
            } else {
              result[0] += -0.00028819180417489376;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.04500000000000000527) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01154850000000000147) ) ) {
              result[0] += -0.000211864275020707;
            } else {
              result[0] += 6.110323655529662e-05;
            }
          } else {
            result[0] += 0.0006609732982405347;
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.828053558455352334) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
              result[0] += -0.00024267725961670458;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)81.50000000000001421) ) ) {
                  result[0] += -0.00024267725961670458;
                } else {
                  result[0] += -0.00024267725961670458;
                }
              } else {
                result[0] += -0.00024267725961670458;
              }
            }
          } else {
            result[0] += -0.00024267725961670458;
          }
        } else {
          result[0] += -0.00025295895073769323;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6150000000000001021) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1050000000000000239) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7269841738944724518) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0009875000000000003133) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1350000000000000366) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)49.50000000000000711) ) ) {
                result[0] += -0.0002183954769571844;
              } else {
                result[0] += -1.1373843932781467e-05;
              }
            } else {
              result[0] += 0.0004790962580057418;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
              result[0] += 0.001009312407050089;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5143309380402011355) ) ) {
                result[0] += -0.0006292946716288562;
              } else {
                result[0] += 0.00020587013331285843;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06439350000000000629) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)304.5000000000000568) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.173295225808050013) ) ) {
                  result[0] += -0.00022216499705963666;
                } else {
                  result[0] += 4.576439796912448e-05;
                }
              } else {
                result[0] += -0.0003657445631081571;
              }
            } else {
              result[0] += -0.00011181556784765311;
            }
          } else {
            result[0] += 0.0004806111147485294;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01840935775314125541) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2850000000000000866) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)82.50000000000001421) ) ) {
              result[0] += 2.643395403301054e-05;
            } else {
              result[0] += 0.0005942750447442977;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005169500000000001351) ) ) {
              result[0] += 0.0012854295055707654;
            } else {
              result[0] += 0.0005542177728020637;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1737935000000000174) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3916739053167483386) ) ) {
              result[0] += 0.002112084486067005;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.439120857165606282) ) ) {
                result[0] += -0.0007230936892662091;
              } else {
                result[0] += 0.0009589013315766893;
              }
            }
          } else {
            result[0] += 0.0067123381139900466;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8250000000000000666) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00448250000000000124) ) ) {
          result[0] += 0.0023582495701306703;
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01369138287730510203) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7050000000000000711) ) ) {
              result[0] += -9.944504412948469e-05;
            } else {
              result[0] += 0.0021686806890339333;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)29.50000000000000355) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3103687546836865763) ) ) {
                result[0] += -0.00040276155922795584;
              } else {
                result[0] += 0.002572390448340924;
              }
            } else {
              result[0] += 0.004612119841709843;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
          result[0] += 0.007849623373428172;
        } else {
          result[0] += 0.012749945905309517;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.00018590217981896982;
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.363906689523952442) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7573260829648241765) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001009954059381500341) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
                  result[0] += -0.00026226368076871066;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
                    result[0] += -0.00023237772260952617;
                  } else {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7255694492462312351) ) ) {
                      result[0] += -0.00023237772260952617;
                    } else {
                      result[0] += -0.00023237772260952617;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)6.243504382093530685e-06) ) ) {
                  result[0] += -0.00014993613386453112;
                } else {
                  result[0] += -0.00015510687782874794;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5458973873869347182) ) ) {
                  result[0] += -0.00021214489171075197;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01096925634721525149) ) ) {
                    result[0] += -0.00023700271718248605;
                  } else {
                    result[0] += -0.0002805762630404425;
                  }
                }
              } else {
                result[0] += 0.0001105503579042359;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.402140754838179745e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -0.00023237772260952617;
                } else {
                  result[0] += -0.00023237772260952617;
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0133385000000000014) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)68.50000000000001421) ) ) {
                    result[0] += -0.00023237772260952617;
                  } else {
                    result[0] += -0.00023237772260952617;
                  }
                } else {
                  result[0] += -0.00023237772260952617;
                }
              }
            } else {
              result[0] += -0.00027596057098496483;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.04500000000000000527) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5046554252763820747) ) ) {
              result[0] += 0.0006136806725070087;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01154850000000000147) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
                  result[0] += -0.0003049733045054848;
                } else {
                  result[0] += -0.00019418256604567894;
                }
              } else {
                result[0] += 2.385651611586727e-05;
              }
            }
          } else {
            result[0] += 0.000632920735933141;
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.828053558455352334) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
              result[0] += -0.00023237772260952617;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)81.50000000000001421) ) ) {
                  result[0] += -0.00023237772260952617;
                } else {
                  result[0] += -0.00023237772260952617;
                }
              } else {
                result[0] += -0.00023237772260952617;
              }
            }
          } else {
            result[0] += -0.00023237772260952617;
          }
        } else {
          result[0] += -0.0002422230454512444;
        }
      }
    }
  } else {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6350000000000001199) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2050000000000000433) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05500000000000000722) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)55.50000000000000711) ) ) {
                result[0] += -0.00037236003609593204;
              } else {
                result[0] += -0.00021033305342194565;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.05721739154190200877) ) ) {
                result[0] += -0.00042870685969797817;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.720904137215244607e-05) ) ) {
                  result[0] += 3.7357922719028804e-05;
                } else {
                  result[0] += -0.00022815442888338204;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4992188184422110542) ) ) {
              result[0] += 0.0010551447203127153;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05500000000000000722) ) ) {
                result[0] += -0.00013210084936196646;
              } else {
                result[0] += 0.000906298579663902;
              }
            }
          }
        } else {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
            result[0] += 0.0005876407291715462;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1377635000000000109) ) ) {
              result[0] += 4.8966080353631076e-05;
            } else {
              result[0] += 0.002147101733792473;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0129473293797221032) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004968500000000001561) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4550000000000000711) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)49.50000000000000711) ) ) {
                result[0] += 0.0002031988362603212;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7050000000000000711) ) ) {
                  result[0] += 0.0010942075038339947;
                } else {
                  result[0] += -0.0005657707084823822;
                }
              }
            } else {
              result[0] += 0.0016477182049348896;
            }
          } else {
            result[0] += 0.0002819880149256964;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01921000000000000138) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3050000000000000488) ) ) {
              result[0] += 7.387620940984009e-05;
            } else {
              result[0] += 0.0017084220467427668;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1405997886577425304) ) ) {
              result[0] += 0.004019354450869373;
            } else {
              result[0] += 0.001769061123750283;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9350000000000001643) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02620539606947270075) ) ) {
            result[0] += 0.0023044094496031055;
          } else {
            result[0] += 0.0052297593967398715;
          }
        } else {
          result[0] += 0.004073620179021914;
        }
      } else {
        result[0] += 0.011359994091036702;
      }
    }
  }
}

