
#include "header.h"

void predict_unit3(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.0003523891768699356;
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5814822343216081713) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001504690974371400121) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.0004722091812143193;
              } else {
                result[0] += -0.000322874583065727;
              }
            } else {
              result[0] += -0.00032122962162707737;
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6249533869346735049) ) ) {
                    result[0] += -0.0004404864669850698;
                  } else {
                    result[0] += -0.0004404864669850698;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7002105688944724182) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.564374608675820677) ) ) {
                      result[0] += -0.00047700373493051037;
                    } else {
                      result[0] += -0.0004404864669850698;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7492319095182128352) ) ) {
                      result[0] += -0.0004404864669850698;
                    } else {
                      result[0] += -0.0004404864669850698;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3346339054385528144) ) ) {
                  result[0] += -0.00043832259626919656;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6802634857286432579) ) ) {
                    result[0] += -0.0003021952491992577;
                  } else {
                    result[0] += -0.0004820723857526485;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.794554612313755398e-06) ) ) {
                  result[0] += -0.0003355156052894042;
                } else {
                  result[0] += -0.0005184129471120167;
                }
              } else {
                result[0] += -0.0003222109511027855;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8932219825431284566) ) ) {
                    result[0] += -0.0004404864669850698;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.051391296366422923) ) ) {
                      result[0] += -0.0004404864669850698;
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.234671350732867934) ) ) {
                        result[0] += -0.0004404864669850698;
                      } else {
                        result[0] += -0.0004404864669850698;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                      result[0] += -0.0004404864669850698;
                    } else {
                      result[0] += -0.0004404864669850698;
                    }
                  } else {
                    result[0] += -0.0004404864669850698;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02511600000000000291) ) ) {
                    result[0] += -0.0004404864669850698;
                  } else {
                    result[0] += -0.0004404864669850698;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.272781830548367354) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06473550000000001525) ) ) {
                      result[0] += -0.0004404864669850698;
                    } else {
                      result[0] += -0.0004404864669850698;
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009152500000000002647) ) ) {
                      result[0] += -0.0004404864669850698;
                    } else {
                      result[0] += -0.0004404864669850698;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.0004404864669850698;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.883880929790755059e-06) ) ) {
              result[0] += -0.00045294660577798916;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.039722088301102687) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7601236426381910993) ) ) {
                    result[0] += -0.00031510918938942336;
                  } else {
                    result[0] += -0.000564898628705748;
                  }
                } else {
                  result[0] += -0.00026370441436394303;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.578971790991679312e-05) ) ) {
                  result[0] += -0.0005377175726450441;
                } else {
                  result[0] += -0.0002946584023673382;
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.891911223721401525) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0003845000000000000219) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7463838234422112139) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6635233717587941671) ) ) {
                  result[0] += -0.0003517020128028233;
                } else {
                  result[0] += -0.0002885775076469665;
                }
              } else {
                result[0] += -0.0004985277865154147;
              }
            } else {
              result[0] += -0.0003236919627384405;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005150500000000001431) ) ) {
                result[0] += -0.00034454783511771674;
              } else {
                result[0] += 3.0470138696707946e-05;
              }
            } else {
              result[0] += 0.005372672873593261;
            }
          }
        } else {
          result[0] += -0.000510823794803994;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4050000000000000822) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.115000000000000005) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.05580247069824354617) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.16917529420057901e-06) ) ) {
            result[0] += -0.0005876185122238666;
          } else {
            result[0] += 0.0007234187073444196;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.723113719091885043) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00847950000000000266) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  result[0] += -0.0003837964471782857;
                } else {
                  result[0] += -0.00023034870882131733;
                }
              } else {
                result[0] += 5.8089624715280475e-05;
              }
            } else {
              result[0] += -0.0005356037877331675;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04562750000000000833) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8327395279648243109) ) ) {
                result[0] += 1.4015068771807143e-05;
              } else {
                result[0] += -0.0004468461469707591;
              }
            } else {
              result[0] += 0.0007426624245941211;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01000276686157755036) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6532207681155780543) ) ) {
            result[0] += 0.0010043017646889575;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02615650000000000266) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4218023131278703652) ) ) {
                result[0] += -0.0008305514883354342;
              } else {
                result[0] += 0.0004406574562010175;
              }
            } else {
              result[0] += -0.0022469280571114866;
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05463331189772155372) ) ) {
            result[0] += 0.0032409137467671245;
          } else {
            result[0] += 0.0012471062387125326;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8950000000000001288) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02577363736079425413) ) ) {
          result[0] += 0.0027164504850863062;
        } else {
          result[0] += 0.005130365007629811;
        }
      } else {
        result[0] += 0.010274562355272805;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.0003371613033002616;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1523979577405769892) ) ) {
                  result[0] += -0.00045180349857150366;
                } else {
                  result[0] += -0.0002150704187017207;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4677590045467516222) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                    result[0] += -0.0004214516252002531;
                  } else {
                    result[0] += -0.0004214516252002531;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6968016071608041928) ) ) {
                    result[0] += -0.0004214516252002531;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7114754460552764614) ) ) {
                      result[0] += -0.0004214516252002531;
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.966590843157139501) ) ) {
                          result[0] += -0.0004214516252002531;
                        } else {
                          result[0] += -0.0004214516252002531;
                        }
                      } else {
                        result[0] += -0.0004214516252002531;
                      }
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5494686760804020631) ) ) {
                result[0] += -0.00027222405384989254;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7326471166347855446) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6802634857286432579) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5508018452917812224) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01622350000000000528) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                          result[0] += -0.00041938126232129785;
                        } else {
                          result[0] += -0.0006038729546726824;
                        }
                      } else {
                        result[0] += -0.00013696647244297114;
                      }
                    } else {
                      result[0] += -0.00020646955794546048;
                    }
                  } else {
                    result[0] += -0.00047662895909316507;
                  }
                } else {
                  result[0] += -0.0004214516252002531;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.07000300000000002354) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -0.0004214516252002531;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.186721136015642994e-07) ) ) {
                    result[0] += -0.0004214516252002531;
                  } else {
                    result[0] += -0.0004214516252002531;
                  }
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8254037945979900703) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -0.0004214516252002531;
                    } else {
                      result[0] += -0.0004214516252002531;
                    }
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)5.045799003287211847e-06) ) ) {
                        result[0] += -0.0004214516252002531;
                      } else {
                        result[0] += -0.0004214516252002531;
                      }
                    } else {
                      result[0] += -0.0004214516252002531;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005656257031049250449) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.249304608119721216) ) ) {
                      result[0] += -0.0004214516252002531;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8419399877135679278) ) ) {
                        result[0] += -0.0004214516252002531;
                      } else {
                        result[0] += -0.0004214516252002531;
                      }
                    }
                  } else {
                    result[0] += -0.0004214516252002531;
                  }
                }
              }
            } else {
              result[0] += -0.0004214516252002531;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002295101748406000225) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7463838234422112139) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6635233717587941671) ) ) {
                  result[0] += -0.0003365038338101183;
                } else {
                  result[0] += -0.0002594137066617264;
                }
              } else {
                result[0] += -0.0004769847920016299;
              }
            } else {
              result[0] += -0.0003120627878367569;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7342470301758795559) ) ) {
                result[0] += -7.572227378598723e-05;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
                  result[0] += -0.000448061621618265;
                } else {
                  result[0] += -0.00010776444562902985;
                }
              }
            } else {
              result[0] += 0.00043515148680062444;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
          result[0] += -0.0004214516252002531;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.578971790991679312e-05) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                result[0] += -0.0004214516252002531;
              } else {
                result[0] += -0.0004214516252002531;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.717118227269369246) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                  result[0] += -0.0004214516252002531;
                } else {
                  result[0] += -0.0004214516252002531;
                }
              } else {
                result[0] += -0.0004214516252002531;
              }
            }
          } else {
            result[0] += -0.0003963677953349106;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4050000000000000822) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.115000000000000005) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.009014249010710599294) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.287816516911927658e-06) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.294841568336650095) ) ) {
              result[0] += 0.0006952877924999636;
            } else {
              result[0] += -0.0005621098000182981;
            }
          } else {
            result[0] += 0.0007105545294571343;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
              result[0] += -0.00031409566771791223;
            } else {
              result[0] += -6.673509781946072e-05;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04562750000000000833) ) ) {
              result[0] += -4.204049576970998e-05;
            } else {
              result[0] += 0.0006959575512979727;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01000276686157755036) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6532207681155780543) ) ) {
            result[0] += 0.0009609026443347908;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02615650000000000266) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4218023131278703652) ) ) {
                result[0] += -0.0007946606781527344;
              } else {
                result[0] += 0.0004216152254203595;
              }
            } else {
              result[0] += -0.002149831044434291;
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05463331189772155372) ) ) {
            result[0] += 0.0031008634046301876;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
              result[0] += 0.0013805248668276617;
            } else {
              result[0] += -0.00031350774567659375;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9150000000000001465) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006290243127013950622) ) ) {
          result[0] += 0.00198022809086723;
        } else {
          result[0] += 0.0037462889867855573;
        }
      } else {
        result[0] += 0.01026269721771511;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.00032259147529121936;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002295101748406000225) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1523979577405769892) ) ) {
                  result[0] += -0.0004322796113292952;
                } else {
                  result[0] += -0.00020577653183023072;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4677590045467516222) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                    result[0] += -0.0004032393403585655;
                  } else {
                    result[0] += -0.0004032393403585655;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6968016071608041928) ) ) {
                    result[0] += -0.0004032393403585655;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7463838234422112139) ) ) {
                      result[0] += -0.0004032393403585655;
                    } else {
                      result[0] += -0.0004032393403585655;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.0003170993603921932;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5494686760804020631) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.07196201389915944657) ) ) {
                  result[0] += -0.00038892345691010627;
                } else {
                  result[0] += 0.00025805553405853913;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7326471166347855446) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6802634857286432579) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5508018452917812224) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01622350000000000528) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                          result[0] += -0.00040125844454112476;
                        } else {
                          result[0] += -0.0005777776554708706;
                        }
                      } else {
                        result[0] += -0.00013104770914787814;
                      }
                    } else {
                      result[0] += -0.00019754734202411157;
                    }
                  } else {
                    result[0] += -0.00046163775240952833;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9186477097784532253) ) ) {
                    result[0] += -1.660702152362169e-05;
                  } else {
                    result[0] += -0.0004032393403585655;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003965500000000001142) ) ) {
                result[0] += -0.00030421122872898235;
              } else {
                result[0] += 0.00030144732540749353;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.07000300000000002354) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -0.0004032393403585655;
                } else {
                  result[0] += -0.0004032393403585655;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8254037945979900703) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -0.0004032393403585655;
                    } else {
                      result[0] += -0.0004032393403585655;
                    }
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)5.045799003287211847e-06) ) ) {
                        result[0] += -0.0004032393403585655;
                      } else {
                        result[0] += -0.0004032393403585655;
                      }
                    } else {
                      result[0] += -0.0004032393403585655;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005656257031049250449) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.249304608119721216) ) ) {
                      result[0] += -0.0004032393403585655;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8419399877135679278) ) ) {
                        result[0] += -0.0004032393403585655;
                      } else {
                        result[0] += -0.0004032393403585655;
                      }
                    }
                  } else {
                    result[0] += -0.0004032393403585655;
                  }
                }
              }
            } else {
              result[0] += -0.0004032393403585655;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.008624500000000001956) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8054659791206031372) ) ) {
                  result[0] += -0.000464520125451902;
                } else {
                  result[0] += -0.00015447343475687766;
                }
              } else {
                result[0] += -0.00012009912228147277;
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.068802141605957212) ) ) {
                result[0] += -0.00034428055574577246;
              } else {
                result[0] += 0.00022168816386590378;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
          result[0] += -0.0004032393403585655;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.578971790991679312e-05) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                result[0] += -0.0004032393403585655;
              } else {
                result[0] += -0.0004032393403585655;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.717118227269369246) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                  result[0] += -0.0004032393403585655;
                } else {
                  result[0] += -0.0004032393403585655;
                }
              } else {
                result[0] += -0.0004032393403585655;
              }
            }
          } else {
            result[0] += -0.00037923946373272227;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5050000000000001155) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.115000000000000005) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6413622072216433878) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01622350000000000528) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.08500000000000000611) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                result[0] += -0.0002510536705538509;
              } else {
                result[0] += 4.8950621776148164e-05;
              }
            } else {
              result[0] += 0.00029423974633700306;
            }
          } else {
            result[0] += 0.0012614726028026253;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9808239647505231362) ) ) {
              result[0] += -0.0003834773204322541;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
                result[0] += 8.962934662439814e-06;
              } else {
                result[0] += -0.00029502821530231056;
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.96280210579579717) ) ) {
              result[0] += -4.28564126643319e-05;
            } else {
              result[0] += -0.0009912307693902978;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0119121105025029022) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.05751864358971629093) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
              result[0] += 0.00014737681548679236;
            } else {
              result[0] += 0.001754299997681142;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8327395279648243109) ) ) {
              result[0] += 0.0005663226925375237;
            } else {
              result[0] += -0.0006225182663362242;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
            result[0] += 0.0022247304377812755;
          } else {
            result[0] += -0.00020455285687532673;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7450000000000001066) ) ) {
          result[0] += 0.0034678121521030344;
        } else {
          result[0] += 0.009387081090885202;
        }
      } else {
        result[0] += 0.011979874827066694;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.00030865125657047684;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002295101748406000225) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1523979577405769892) ) ) {
                  result[0] += -0.0004135994142626868;
                } else {
                  result[0] += -0.00019688426380386816;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4677590045467516222) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                    result[0] += -0.0003858140671199229;
                  } else {
                    result[0] += -0.0003858140671199229;
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6558660377084782889) ) ) {
                    result[0] += -0.0003858140671199229;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.966590843157139501) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                          result[0] += -0.0003858140671199229;
                        } else {
                          result[0] += -0.0003858140671199229;
                        }
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7210440605025126848) ) ) {
                          result[0] += -0.0003858140671199229;
                        } else {
                          result[0] += -0.0003858140671199229;
                        }
                      }
                    } else {
                      result[0] += -0.0003858140671199229;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.0003033964736804964;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5494686760804020631) ) ) {
                result[0] += -0.00024365373624199985;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7326471166347855446) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6802634857286432579) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5508018452917812224) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01622350000000000528) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                          result[0] += -0.00038391877220353887;
                        } else {
                          result[0] += -0.0005528100183628204;
                        }
                      } else {
                        result[0] += -0.0001253847147159128;
                      }
                    } else {
                      result[0] += -0.00018901068384667087;
                    }
                  } else {
                    result[0] += -0.0004416888953216859;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9186477097784532253) ) ) {
                    result[0] += -1.5889378529086974e-05;
                  } else {
                    result[0] += -0.0003858140671199229;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
                result[0] += -3.236257379359294e-05;
              } else {
                result[0] += 0.005575303123357831;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.07000300000000002354) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -0.0003858140671199229;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.186721136015642994e-07) ) ) {
                    result[0] += -0.0003858140671199229;
                  } else {
                    result[0] += -0.0003858140671199229;
                  }
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8254037945979900703) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -0.0003858140671199229;
                    } else {
                      result[0] += -0.0003858140671199229;
                    }
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)5.045799003287211847e-06) ) ) {
                        result[0] += -0.0003858140671199229;
                      } else {
                        result[0] += -0.0003858140671199229;
                      }
                    } else {
                      result[0] += -0.0003858140671199229;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005656257031049250449) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.249304608119721216) ) ) {
                      result[0] += -0.0003858140671199229;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8419399877135679278) ) ) {
                        result[0] += -0.0003858140671199229;
                      } else {
                        result[0] += -0.0003858140671199229;
                      }
                    }
                  } else {
                    result[0] += -0.0003858140671199229;
                  }
                }
              }
            } else {
              result[0] += -0.0003858140671199229;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)5.354107497039817852e-06) ) ) {
                result[0] += -0.00044444671172284893;
              } else {
                result[0] += -0.0002213777194477683;
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.068802141605957212) ) ) {
                result[0] += -0.0003294030818631715;
              } else {
                result[0] += 0.00021210830286895504;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
          result[0] += -0.0003858140671199229;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.578971790991679312e-05) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8731831355778895132) ) ) {
                result[0] += -0.0003858140671199229;
              } else {
                result[0] += -0.0003858140671199229;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.717118227269369246) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                  result[0] += -0.0003858140671199229;
                } else {
                  result[0] += -0.0003858140671199229;
                }
              } else {
                result[0] += -0.0003858140671199229;
              }
            }
          } else {
            result[0] += -0.00036285130261594546;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5050000000000001155) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1350000000000000366) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5800027599246232457) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002579500000000000629) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1750000000000000167) ) ) {
              result[0] += -9.311818530404182e-05;
            } else {
              result[0] += 0.001392135700774042;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1405997886577425304) ) ) {
              result[0] += 0.0013392201008200822;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5628434130653267031) ) ) {
                result[0] += -0.000831913696221924;
              } else {
                result[0] += 0.0008985046861926658;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.08500000000000000611) ) ) {
              result[0] += -0.000294547833355796;
            } else {
              result[0] += 0.0003908886878818198;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02063185379234615258) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8371684470603016903) ) ) {
                result[0] += -4.330385093067259e-05;
              } else {
                result[0] += -0.00045551415752139747;
              }
            } else {
              result[0] += 0.000385288754946358;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005013289129500051074) ) ) {
          result[0] += 0.0006627167165738237;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7760221401809592745) ) ) {
            result[0] += 0.0020435533036382747;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6914593314070353047) ) ) {
              result[0] += -0.0017902522643649184;
            } else {
              result[0] += 0.0007393327256149669;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7250000000000000888) ) ) {
        result[0] += 0.00367026465359416;
      } else {
        result[0] += 0.012870624339197258;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.00029531343968879943;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002295101748406000225) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1523979577405769892) ) ) {
                  result[0] += -0.0003957264487964175;
                } else {
                  result[0] += -0.00018837625937622295;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4677590045467516222) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                    result[0] += -0.00036914179617309877;
                  } else {
                    result[0] += -0.00036914179617309877;
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6558660377084782889) ) ) {
                    result[0] += -0.00036914179617309877;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.966590843157139501) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.714147492562814179) ) ) {
                          result[0] += -0.00036914179617309877;
                        } else {
                          result[0] += -0.00036914179617309877;
                        }
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8697742174477757215) ) ) {
                          result[0] += -0.00036914179617309877;
                        } else {
                          result[0] += -0.00036914179617309877;
                        }
                      }
                    } else {
                      result[0] += -0.00036914179617309877;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.0002902857329258314;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5494686760804020631) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.07196201389915944657) ) ) {
                  result[0] += -0.0003615877549287286;
                } else {
                  result[0] += 0.00025743318589712777;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7326471166347855446) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01622350000000000528) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006308000000000001106) ) ) {
                      result[0] += -0.00036781590464432333;
                    } else {
                      result[0] += -0.00047339310224607734;
                    }
                  } else {
                    result[0] += -0.00018058968163518326;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9186477097784532253) ) ) {
                    result[0] += -1.520274720433739e-05;
                  } else {
                    result[0] += -0.00036914179617309877;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003965500000000001142) ) ) {
                  result[0] += -0.00041285263950707133;
                } else {
                  result[0] += 0.0001079739898056878;
                }
              } else {
                result[0] += 0.00533437628267215;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.07000300000000002354) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -0.00036914179617309877;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.186721136015642994e-07) ) ) {
                    result[0] += -0.00036914179617309877;
                  } else {
                    result[0] += -0.00036914179617309877;
                  }
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8254037945979900703) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -0.00036914179617309877;
                    } else {
                      result[0] += -0.00036914179617309877;
                    }
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)5.045799003287211847e-06) ) ) {
                        result[0] += -0.00036914179617309877;
                      } else {
                        result[0] += -0.00036914179617309877;
                      }
                    } else {
                      result[0] += -0.00036914179617309877;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005656257031049250449) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.249304608119721216) ) ) {
                      result[0] += -0.00036914179617309877;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8419399877135679278) ) ) {
                        result[0] += -0.00036914179617309877;
                      } else {
                        result[0] += -0.00036914179617309877;
                      }
                    }
                  } else {
                    result[0] += -0.00036914179617309877;
                  }
                }
              }
            } else {
              result[0] += -0.00036914179617309877;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0003845000000000000219) ) ) {
                result[0] += -0.0004448413726349529;
              } else {
                result[0] += -0.0002757955327965909;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                result[0] += -0.00031579388631833717;
              } else {
                result[0] += 0.00023948226903929817;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
          result[0] += -0.00036914179617309877;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.768269948548106596) ) ) {
                  result[0] += -0.00036914179617309877;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.052300094327177008e-06) ) ) {
                    result[0] += -0.00036914179617309877;
                  } else {
                    result[0] += -0.00036914179617309877;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.906142995150753916) ) ) {
                  result[0] += -0.00036914179617309877;
                } else {
                  result[0] += -0.00036914179617309877;
                }
              }
            } else {
              result[0] += -0.00036914179617309877;
            }
          } else {
            result[0] += -0.0003471713268292131;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5050000000000001155) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1350000000000000366) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5800027599246232457) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007851000000000002074) ) ) {
            result[0] += 0.00012255839310222413;
          } else {
            result[0] += 0.0013991048017966998;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04562750000000000833) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.08500000000000000611) ) ) {
                result[0] += -0.0002972572775087812;
              } else {
                result[0] += 0.0002727252628089567;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8327395279648243109) ) ) {
                result[0] += -1.8516744084418792e-05;
              } else {
                result[0] += -0.00042698677541963873;
              }
            }
          } else {
            result[0] += 0.00044450610242497996;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005013289129500051074) ) ) {
          result[0] += 0.0006340785885185438;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7760221401809592745) ) ) {
            result[0] += 0.0019552447703935693;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6914593314070353047) ) ) {
              result[0] += -0.0017128896864851964;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02483316262871755262) ) ) {
                result[0] += 0.00020734272271223636;
              } else {
                result[0] += 0.0018104436334579511;
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02366047096071570086) ) ) {
          result[0] += 0.0029387139781143503;
        } else {
          result[0] += 0.005880138341694026;
        }
      } else {
        result[0] += 0.010906004560083919;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.00028255199291863834;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002295101748406000225) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1523979577405769892) ) ) {
                  result[0] += -0.00037862583184792334;
                } else {
                  result[0] += -0.00018023591327709175;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4677590045467516222) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                    result[0] += -0.00035318998785896006;
                  } else {
                    result[0] += -0.00035318998785896006;
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6558660377084782889) ) ) {
                    result[0] += -0.00035318998785896006;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.966590843157139501) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.714147492562814179) ) ) {
                          result[0] += -0.00035318998785896006;
                        } else {
                          result[0] += -0.00035318998785896006;
                        }
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8697742174477757215) ) ) {
                          result[0] += -0.00035318998785896006;
                        } else {
                          result[0] += -0.00035318998785896006;
                        }
                      }
                    } else {
                      result[0] += -0.00035318998785896006;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.00027774154959040993;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5494686760804020631) ) ) {
                result[0] += -0.00021749929816154034;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7326471166347855446) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01622350000000000528) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006308000000000001106) ) ) {
                      result[0] += -0.00035192139238208564;
                    } else {
                      result[0] += -0.00045293625855470675;
                    }
                  } else {
                    result[0] += -0.00017278581868923566;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7463838234422112139) ) ) {
                    result[0] += 3.2590880973117142e-06;
                  } else {
                    result[0] += -0.00035318998785896006;
                  }
                }
              }
            } else {
              result[0] += 5.017965599345557e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.07000300000000002354) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -0.00035318998785896006;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.186721136015642994e-07) ) ) {
                    result[0] += -0.00035318998785896006;
                  } else {
                    result[0] += -0.00035318998785896006;
                  }
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8254037945979900703) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -0.00035318998785896006;
                    } else {
                      result[0] += -0.00035318998785896006;
                    }
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)5.045799003287211847e-06) ) ) {
                        result[0] += -0.00035318998785896006;
                      } else {
                        result[0] += -0.00035318998785896006;
                      }
                    } else {
                      result[0] += -0.00035318998785896006;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005656257031049250449) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.249304608119721216) ) ) {
                      result[0] += -0.00035318998785896006;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8419399877135679278) ) ) {
                        result[0] += -0.00035318998785896006;
                      } else {
                        result[0] += -0.00035318998785896006;
                      }
                    }
                  } else {
                    result[0] += -0.00035318998785896006;
                  }
                }
              }
            } else {
              result[0] += -0.00035318998785896006;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02500000000000000486) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8022705390703518402) ) ) {
                result[0] += -0.0004061311786058698;
              } else {
                result[0] += -0.00016323871190669563;
              }
            } else {
              result[0] += 0.00012750326518261334;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
          result[0] += -0.00035318998785896006;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.768269948548106596) ) ) {
                  result[0] += -0.00035318998785896006;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.052300094327177008e-06) ) ) {
                    result[0] += -0.00035318998785896006;
                  } else {
                    result[0] += -0.00035318998785896006;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.906142995150753916) ) ) {
                  result[0] += -0.00035318998785896006;
                } else {
                  result[0] += -0.00035318998785896006;
                }
              }
            } else {
              result[0] += -0.00035318998785896006;
            }
          } else {
            result[0] += -0.00033216893339894465;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5650000000000000577) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.115000000000000005) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.05580247069824354617) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.16917529420057901e-06) ) ) {
            result[0] += -0.000530714941160764;
          } else {
            result[0] += 0.0006039054989599922;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.723113719091885043) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05439750000000000835) ) ) {
                result[0] += -0.00023814545672269858;
              } else {
                result[0] += 0.00037123610849022423;
              }
            } else {
              result[0] += -0.0004605626020674882;
            }
          } else {
            result[0] += 9.95391197648595e-06;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005013289129500051074) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2650000000000000688) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001306500000000000153) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3550000000000000377) ) ) {
                result[0] += -7.226856491522292e-05;
              } else {
                result[0] += -0.0023378398838284054;
              }
            } else {
              result[0] += 0.0011922242765542853;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2323027026914575854) ) ) {
              result[0] += 0.0014173067244915522;
            } else {
              result[0] += 0.0005719547118051635;
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.06355808660527756393) ) ) {
            result[0] += 0.0025135667741634504;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.96280210579579717) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02577363736079425413) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
                  result[0] += 0.0010301501213227648;
                } else {
                  result[0] += 9.573525605565688e-05;
                }
              } else {
                result[0] += 0.0020441440587184484;
              }
            } else {
              result[0] += -0.0012507571606249694;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02616152934301940389) ) ) {
          result[0] += 0.003183374278119708;
        } else {
          result[0] += 0.006884709638482693;
        }
      } else {
        result[0] += 0.01083229814056768;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.00027034200944740214;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002295101748406000225) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1523979577405769892) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.001151299667459350319) ) ) {
                    result[0] += -0.00024157089058108284;
                  } else {
                    result[0] += -0.0003622641877452133;
                  }
                } else {
                  result[0] += -0.00017244733780358537;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4677590045467516222) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                    result[0] += -0.0003379275086620577;
                  } else {
                    result[0] += -0.0003379275086620577;
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6915080527790725684) ) ) {
                    result[0] += -0.0003379275086620577;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.966590843157139501) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                        result[0] += -0.0003379275086620577;
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7210440605025126848) ) ) {
                          result[0] += -0.0003379275086620577;
                        } else {
                          result[0] += -0.0003379275086620577;
                        }
                      }
                    } else {
                      result[0] += -0.0003379275086620577;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.00026573944089974165;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5494686760804020631) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.07196201389915944657) ) ) {
                  result[0] += -0.000336563534523831;
                } else {
                  result[0] += 0.0002557075137326631;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7326471166347855446) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01622350000000000528) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006308000000000001106) ) ) {
                      result[0] += -0.00033671373328977465;
                    } else {
                      result[0] += -0.0004333634210979594;
                    }
                  } else {
                    result[0] += -0.00016531918584595896;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7463838234422112139) ) ) {
                    result[0] += 3.1182523828351577e-06;
                  } else {
                    result[0] += -0.0003379275086620577;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
                result[0] += -3.442224759771032e-05;
              } else {
                result[0] += 0.005101692243419998;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.07000300000000002354) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -0.0003379275086620577;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.186721136015642994e-07) ) ) {
                    result[0] += -0.0003379275086620577;
                  } else {
                    result[0] += -0.0003379275086620577;
                  }
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8254037945979900703) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                      result[0] += -0.0003379275086620577;
                    } else {
                      result[0] += -0.0003379275086620577;
                    }
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)5.045799003287211847e-06) ) ) {
                        result[0] += -0.0003379275086620577;
                      } else {
                        result[0] += -0.0003379275086620577;
                      }
                    } else {
                      result[0] += -0.0003379275086620577;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005656257031049250449) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.249304608119721216) ) ) {
                      result[0] += -0.0003379275086620577;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8419399877135679278) ) ) {
                        result[0] += -0.0003379275086620577;
                      } else {
                        result[0] += -0.0003379275086620577;
                      }
                    }
                  } else {
                    result[0] += -0.0003379275086620577;
                  }
                }
              }
            } else {
              result[0] += -0.0003379275086620577;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
              result[0] += -0.00038960277459410925;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                result[0] += -0.00029216548155191926;
              } else {
                result[0] += 0.00022613638124444787;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
          result[0] += -0.0003379275086620577;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.768269948548106596) ) ) {
                  result[0] += -0.0003379275086620577;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.052300094327177008e-06) ) ) {
                    result[0] += -0.0003379275086620577;
                  } else {
                    result[0] += -0.0003379275086620577;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.906142995150753916) ) ) {
                  result[0] += -0.0003379275086620577;
                } else {
                  result[0] += -0.0003379275086620577;
                }
              }
            } else {
              result[0] += -0.0003379275086620577;
            }
          } else {
            result[0] += -0.00031781484180481046;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5650000000000000577) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.115000000000000005) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.05580247069824354617) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.16917529420057901e-06) ) ) {
            result[0] += -0.0005077810358197496;
          } else {
            result[0] += 0.0005778087934144986;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02500000000000000486) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1350000000000000366) ) ) {
              result[0] += -0.000206432666939202;
            } else {
              result[0] += 0.0009708641507630819;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.96280210579579717) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03291917222295825951) ) ) {
                result[0] += -3.344275884363131e-06;
              } else {
                result[0] += 0.0009734150718131841;
              }
            } else {
              result[0] += -0.0009486182659929131;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0119121105025029022) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5792515097236182742) ) ) {
            result[0] += 0.0011275982268973926;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02251500000000000376) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2050000000000000433) ) ) {
                result[0] += -0.0001364944037397888;
              } else {
                result[0] += 0.0008980298422180728;
              }
            } else {
              result[0] += -0.0008370893164209478;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.96280210579579717) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01704648841990550126) ) ) {
              result[0] += 0.003343077936069248;
            } else {
              result[0] += 0.0015294892253472753;
            }
          } else {
            result[0] += -0.001340122392184925;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4950000000000000511) ) ) {
          result[0] += -0.0016712983027414707;
        } else {
          result[0] += 0.0040931259236578225;
        }
      } else {
        result[0] += 0.01036419957971301;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.0002586596587662514;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002295101748406000225) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.576481470050251299) ) ) {
                result[0] += -0.0002937900974679227;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4677590045467516222) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                    result[0] += -0.0003162577097155431;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4218023131278703652) ) ) {
                      result[0] += -0.0003233245704466196;
                    } else {
                      result[0] += -0.0003233245704466196;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6915080527790725684) ) ) {
                    result[0] += -0.0003233245704466196;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.966590843157139501) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.714147492562814179) ) ) {
                          result[0] += -0.0003902309536527785;
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                            result[0] += -0.000322891642904525;
                          } else {
                            result[0] += -0.0003233245704466196;
                          }
                        }
                      } else {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)5.354107497039817852e-06) ) ) {
                          result[0] += -0.0003233245704466196;
                        } else {
                          result[0] += -0.0003233245704466196;
                        }
                      }
                    } else {
                      result[0] += -0.0003233245704466196;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.00025677515269552283;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5494686760804020631) ) ) {
                result[0] += -0.00019355645507898337;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7326471166347855446) ) ) {
                  result[0] += -0.00030759215742436774;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7463838234422112139) ) ) {
                    result[0] += 2.9835026340888312e-06;
                  } else {
                    result[0] += -0.0003233245704466196;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07500000000000002498) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005046500000000001505) ) ) {
                  result[0] += -0.00038876145531418127;
                } else {
                  result[0] += 0.00016633567153010888;
                }
              } else {
                result[0] += 0.006730858152606795;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.07000300000000002354) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -0.0003233245704466196;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.186721136015642994e-07) ) ) {
                    result[0] += -0.0003233245704466196;
                  } else {
                    result[0] += -0.0003233245704466196;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001660081062325250096) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.063944343817919913) ) ) {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)9.125515493975159704e-06) ) ) {
                        result[0] += -0.0003233245704466196;
                      } else {
                        result[0] += -0.0003233245704466196;
                      }
                    } else {
                      result[0] += -0.0003233245704466196;
                    }
                  } else {
                    result[0] += -0.0003233245704466196;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7983409114572864729) ) ) {
                    result[0] += -0.0003233245704466196;
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8168185667587940513) ) ) {
                        result[0] += -0.0003233245704466196;
                      } else {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.324477022761784649e-05) ) ) {
                          result[0] += -0.0003233245704466196;
                        } else {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
                            result[0] += -0.0003233245704466196;
                          } else {
                            result[0] += -0.0003233245704466196;
                          }
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                        result[0] += -0.0003233245704466196;
                      } else {
                        result[0] += -0.0003233245704466196;
                      }
                    }
                  }
                }
              }
            } else {
              result[0] += -0.0003233245704466196;
            }
          } else {
            result[0] += -0.00020536936564202846;
          }
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
          result[0] += -0.0003233245704466196;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.768269948548106596) ) ) {
                  result[0] += -0.0003233245704466196;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.052300094327177008e-06) ) ) {
                    result[0] += -0.0003233245704466196;
                  } else {
                    result[0] += -0.0003233245704466196;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.906142995150753916) ) ) {
                  result[0] += -0.0003233245704466196;
                } else {
                  result[0] += -0.0003233245704466196;
                }
              }
            } else {
              result[0] += -0.0003233245704466196;
            }
          } else {
            result[0] += -0.00030408103683225913;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5650000000000000577) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.115000000000000005) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4347441410050251753) ) ) {
          result[0] += 0.0015180440758877822;
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01590200000000000294) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
              result[0] += -0.000304321229168798;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8327395279648243109) ) ) {
                result[0] += -2.2685817568626413e-05;
              } else {
                result[0] += -0.00024991342234232126;
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.363906689523952442) ) ) {
              result[0] += 0.00046353618634605015;
            } else {
              result[0] += -0.00043489467676627823;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0119121105025029022) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2323027026914575854) ) ) {
            result[0] += 0.0010300911087249025;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02300100000000000408) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3550000000000000377) ) ) {
                result[0] += 0.0001711227396889431;
              } else {
                result[0] += 0.0015139557561453748;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3750000000000000555) ) ) {
                result[0] += -0.0004078127483675165;
              } else {
                result[0] += -0.0021673898897239907;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.96280210579579717) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01989400000000000543) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3050000000000000488) ) ) {
                result[0] += 0.00043041208857197725;
              } else {
                result[0] += 0.0020230964514509715;
              }
            } else {
              result[0] += 0.003023535437991157;
            }
          } else {
            result[0] += -0.0012822113787498738;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.795000000000000151) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4950000000000000511) ) ) {
          result[0] += -0.0016059544249451799;
        } else {
          result[0] += 0.003434343440021282;
        }
      } else {
        result[0] += 0.012975809291076001;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.0002474821401595398;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002295101748406000225) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.576481470050251299) ) ) {
              result[0] += -0.000272686453362409;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4677590045467516222) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6299505656030152112) ) ) {
                  result[0] += -0.00030935267231835354;
                } else {
                  result[0] += -0.00030935267231835354;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6915080527790725684) ) ) {
                  result[0] += -0.00030935267231835354;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                        result[0] += -0.00030733440293860553;
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.966590843157139501) ) ) {
                          result[0] += -0.00030935267231835354;
                        } else {
                          result[0] += -0.00030935267231835354;
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7190147863316583843) ) ) {
                        result[0] += -0.00030935267231835354;
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
                          result[0] += 3.676794350719344e-06;
                        } else {
                          result[0] += -0.00030935267231835354;
                        }
                      }
                    }
                  } else {
                    result[0] += -0.00024525352488674357;
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5494686760804020631) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.07196201389915944657) ) ) {
                  result[0] += -0.0003136553389596748;
                } else {
                  result[0] += 0.00025302176591314685;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5681735652491761712) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6100010069597990858) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1523979577405769892) ) ) {
                      result[0] += -0.0004102716339115389;
                    } else {
                      result[0] += 0.00017283998644719519;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6413621769095478875) ) ) {
                      result[0] += -0.0004001638052059853;
                    } else {
                      result[0] += -0.00019511256933449944;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7463838234422112139) ) ) {
                    result[0] += -0.00015080378039032173;
                  } else {
                    result[0] += -0.00030935267231835354;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07500000000000002498) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003965500000000001142) ) ) {
                  result[0] += -0.0004272729439381074;
                } else {
                  result[0] += 0.00013774292823739642;
                }
              } else {
                result[0] += 0.0064399960498778665;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.07000300000000002354) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -0.00030935267231835354;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.186721136015642994e-07) ) ) {
                    result[0] += -0.00030935267231835354;
                  } else {
                    result[0] += -0.00030935267231835354;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                    result[0] += -0.00030935267231835354;
                  } else {
                    result[0] += -0.00030935267231835354;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8254037945979900703) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)5.045799003287211847e-06) ) ) {
                        result[0] += -0.00030935267231835354;
                      } else {
                        result[0] += -0.00030935267231835354;
                      }
                    } else {
                      result[0] += -0.00030935267231835354;
                    }
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                      result[0] += -0.00030935267231835354;
                    } else {
                      result[0] += -0.00030935267231835354;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.00030935267231835354;
            }
          } else {
            result[0] += -0.00021880004697366143;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007696500000000001084) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8025985781909549255) ) ) {
                    result[0] += -0.00030935267231835354;
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                      result[0] += -0.00030935267231835354;
                    } else {
                      result[0] += -0.00030935267231835354;
                    }
                  }
                } else {
                  result[0] += -0.00030935267231835354;
                }
              } else {
                result[0] += -0.00030935267231835354;
              }
            } else {
              result[0] += -0.00030935267231835354;
            }
          } else {
            result[0] += -0.00029094071389457107;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.052300094327177008e-06) ) ) {
            result[0] += -0.00030935267231835354;
          } else {
            result[0] += -0.00030935267231835354;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5850000000000000755) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2050000000000000433) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005959500000000000387) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.03500000000000001027) ) ) {
            result[0] += -0.00023307404874424247;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5072068278894473758) ) ) {
              result[0] += 0.0006637256020315943;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8327395279648243109) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.314196657149456993) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.762281072713567931) ) ) {
                    result[0] += 1.8592686188562566e-05;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001939744889791500219) ) ) {
                      result[0] += 3.960559217859802e-05;
                    } else {
                      result[0] += -0.0007396873459925493;
                    }
                  }
                } else {
                  result[0] += 0.0006467290517497744;
                }
              } else {
                result[0] += -0.0003712403857134532;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.768269948548106596) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05463331189772155372) ) ) {
              result[0] += 0.0019443277522438209;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02192319026750580435) ) ) {
                result[0] += -3.161140939987297e-05;
              } else {
                result[0] += 0.0006510395557335639;
              }
            }
          } else {
            result[0] += -0.0014453892962445784;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0119121105025029022) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02455150000000000388) ) ) {
            result[0] += 0.0010097677439363769;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1405997886577425304) ) ) {
              result[0] += 0.0016070516269131173;
            } else {
              result[0] += -0.001681110012206793;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7760221401809592745) ) ) {
            result[0] += 0.002360626032613011;
          } else {
            result[0] += 0.0009354275672909531;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8350000000000000755) ) ) {
        result[0] += 0.003628012227049045;
      } else {
        result[0] += 0.013279346415984963;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.000236787638204127;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002295101748406000225) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.576481470050251299) ) ) {
              result[0] += -0.00026090279169365636;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4677590045467516222) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6299505656030152112) ) ) {
                  result[0] += -0.000295984544998588;
                } else {
                  result[0] += -0.000295984544998588;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6915080527790725684) ) ) {
                  result[0] += -0.000295984544998588;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                        result[0] += -0.0002940534915521366;
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.966590843157139501) ) ) {
                          result[0] += -0.000295984544998588;
                        } else {
                          result[0] += -0.000295984544998588;
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7190147863316583843) ) ) {
                        result[0] += -0.000295984544998588;
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
                          result[0] += 3.517908201003343e-06;
                        } else {
                          result[0] += -0.000295984544998588;
                        }
                      }
                    }
                  } else {
                    result[0] += -0.00023465532858949834;
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5494686760804020631) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.07196201389915944657) ) ) {
                  result[0] += -0.00030010127952868925;
                } else {
                  result[0] += 0.00024208787885133414;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5681735652491761712) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6100010069597990858) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1523979577405769892) ) ) {
                      result[0] += -0.0003925424725737194;
                    } else {
                      result[0] += 0.00016537101284028581;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6413621769095478875) ) ) {
                      result[0] += -0.0003828714357667119;
                    } else {
                      result[0] += -0.00018668112554252216;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7463838234422112139) ) ) {
                    result[0] += -0.0001442870623627976;
                  } else {
                    result[0] += -0.000295984544998588;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03500000000000001027) ) ) {
                result[0] += -4.753668170504219e-05;
              } else {
                result[0] += 0.0025311419955707285;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.07000300000000002354) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -0.000295984544998588;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.186721136015642994e-07) ) ) {
                    result[0] += -0.000295984544998588;
                  } else {
                    result[0] += -0.000295984544998588;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                    result[0] += -0.000295984544998588;
                  } else {
                    result[0] += -0.000295984544998588;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8254037945979900703) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)5.045799003287211847e-06) ) ) {
                        result[0] += -0.000295984544998588;
                      } else {
                        result[0] += -0.000295984544998588;
                      }
                    } else {
                      result[0] += -0.000295984544998588;
                    }
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                      result[0] += -0.000295984544998588;
                    } else {
                      result[0] += -0.000295984544998588;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.000295984544998588;
            }
          } else {
            result[0] += -0.00020934499082821286;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006064500000000001313) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.384300133116745416e-05) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8025985781909549255) ) ) {
                    result[0] += -0.000295984544998588;
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                      result[0] += -0.000295984544998588;
                    } else {
                      result[0] += -0.000295984544998588;
                    }
                  }
                } else {
                  result[0] += -0.000295984544998588;
                }
              } else {
                result[0] += -0.000295984544998588;
              }
            } else {
              result[0] += -0.000295984544998588;
            }
          } else {
            result[0] += -0.00027836822671772324;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.052300094327177008e-06) ) ) {
            result[0] += -0.000295984544998588;
          } else {
            result[0] += -0.000295984544998588;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5850000000000000755) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2050000000000000433) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0229305563329877532) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5041457217085428821) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.72638075848137134e-06) ) ) {
              result[0] += -0.000330542768285526;
            } else {
              result[0] += 0.0009042785701443841;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.723113719091885043) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  result[0] += -0.0002912255273116888;
                } else {
                  result[0] += -0.00011906945898898069;
                }
              } else {
                result[0] += -0.0003078718598188961;
              }
            } else {
              result[0] += -9.878290455956417e-07;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8377933889099087317) ) ) {
            result[0] += 0.001148834820642441;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7954292854522614364) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02722700000000000467) ) ) {
                  result[0] += -0.0007364101576238982;
                } else {
                  result[0] += 0.0006054136389480012;
                }
              } else {
                result[0] += -0.0016432108780232652;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002837500000000000178) ) ) {
                result[0] += -0.0003531877035047645;
              } else {
                result[0] += 0.0009084691311531808;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.009602467408789250661) ) ) {
          result[0] += 0.0008691387772879691;
        } else {
          result[0] += 0.001882227968042273;
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8450000000000000844) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02616152934301940389) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5850000000000000755) ) ) {
              result[0] += -0.001891326891087801;
            } else {
              result[0] += 0.0025433026799203677;
            }
          } else {
            result[0] += 0.005452153382884776;
          }
        } else {
          result[0] += 0.003595845322151267;
        }
      } else {
        result[0] += 0.012705503001988286;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.00022655528019170987;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002295101748406000225) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.576481470050251299) ) ) {
              result[0] += -0.0002496283400740699;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4677590045467516222) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6299505656030152112) ) ) {
                  result[0] += -0.0002831940976021869;
                } else {
                  result[0] += -0.0002831940976021869;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6915080527790725684) ) ) {
                  result[0] += -0.0002831940976021869;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                        result[0] += -0.0002813464912070895;
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.966590843157139501) ) ) {
                          result[0] += -0.0002831940976021869;
                        } else {
                          result[0] += -0.0002831940976021869;
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7190147863316583843) ) ) {
                        result[0] += -0.0002831940976021869;
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
                          result[0] += 3.3658880345770148e-06;
                        } else {
                          result[0] += -0.0002831940976021869;
                        }
                      }
                    }
                  } else {
                    result[0] += -0.00022451511455695992;
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4781247323869347032) ) ) {
                result[0] += 0.0001269595609315589;
              } else {
                result[0] += -0.00027454621506911483;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07500000000000002498) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003965500000000001142) ) ) {
                  result[0] += -0.00042851409703965746;
                } else {
                  result[0] += 0.00013384482520940102;
                }
              } else {
                result[0] += 0.006052324223104919;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.07000300000000002354) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -0.0002831940976021869;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.186721136015642994e-07) ) ) {
                    result[0] += -0.0002831940976021869;
                  } else {
                    result[0] += -0.0002831940976021869;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                    result[0] += -0.0002831940976021869;
                  } else {
                    result[0] += -0.0002831940976021869;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8254037945979900703) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)5.045799003287211847e-06) ) ) {
                        result[0] += -0.0002831940976021869;
                      } else {
                        result[0] += -0.0002831940976021869;
                      }
                    } else {
                      result[0] += -0.0002831940976021869;
                    }
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                      result[0] += -0.0002831940976021869;
                    } else {
                      result[0] += -0.0002831940976021869;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.0002831940976021869;
            }
          } else {
            result[0] += -0.000200298518172348;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006064500000000001313) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.384300133116745416e-05) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8025985781909549255) ) ) {
                    result[0] += -0.0002831940976021869;
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                      result[0] += -0.0002831940976021869;
                    } else {
                      result[0] += -0.0002831940976021869;
                    }
                  }
                } else {
                  result[0] += -0.0002831940976021869;
                }
              } else {
                result[0] += -0.0002831940976021869;
              }
            } else {
              result[0] += -0.0002831940976021869;
            }
          } else {
            result[0] += -0.00026633903728595924;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.052300094327177008e-06) ) ) {
            result[0] += -0.0002831940976021869;
          } else {
            result[0] += -0.0002831940976021869;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5850000000000000755) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2050000000000000433) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0229305563329877532) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5800027599246232457) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.384724495646039899e-06) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.03588532983514210878) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.294841568336650095) ) ) {
                  result[0] += 0.0005692263529825653;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1350000000000000366) ) ) {
                    result[0] += -0.0005809748975756854;
                  } else {
                    result[0] += -1.8516549247417825e-05;
                  }
                }
              } else {
                result[0] += 0.0005946159890193312;
              }
            } else {
              result[0] += 0.0004408991301602651;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8025985781909549255) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
                    result[0] += -0.00027967423462753403;
                  } else {
                    result[0] += -7.47223938625142e-05;
                  }
                } else {
                  result[0] += -0.0006601071768375446;
                }
              } else {
                result[0] += 0.0005012586965243666;
              }
            } else {
              result[0] += -0.00033370100354250087;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8377933889099087317) ) ) {
            result[0] += 0.0010991899605006688;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7954292854522614364) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.213351496714494937) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02722700000000000467) ) ) {
                  result[0] += -0.0007045874981559558;
                } else {
                  result[0] += 0.0005792517618065271;
                }
              } else {
                result[0] += -0.0015722024329821536;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002837500000000000178) ) ) {
                result[0] += -0.000337925323022179;
              } else {
                result[0] += 0.0008692112481670115;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0119121105025029022) ) ) {
          result[0] += 0.0008597857013927464;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7760221401809592745) ) ) {
            result[0] += 0.002177278618624723;
          } else {
            result[0] += 0.0008136675784171076;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9050000000000001377) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0270604707267506038) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5850000000000000755) ) ) {
              result[0] += -0.0017104735382694669;
            } else {
              result[0] += 0.002586474968281181;
            }
          } else {
            result[0] += 0.0056486800999948844;
          }
        } else {
          result[0] += 0.004270166334871223;
        }
      } else {
        result[0] += 0.013884987229852914;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.00021676509539107173;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002295101748406000225) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.576481470050251299) ) ) {
              result[0] += -0.00023884109389409272;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4677590045467516222) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4218023131278703652) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6553322322110554099) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1643367459977091716) ) ) {
                      result[0] += -0.000270956366715362;
                    } else {
                      result[0] += -0.000270956366715362;
                    }
                  } else {
                    result[0] += -0.000270956366715362;
                  }
                } else {
                  result[0] += -0.000270956366715362;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6915080527790725684) ) ) {
                  result[0] += -0.000270956366715362;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                        result[0] += -0.00026918860135522756;
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.966590843157139501) ) ) {
                          result[0] += -0.000270956366715362;
                        } else {
                          result[0] += -0.000270956366715362;
                        }
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7190147863316583843) ) ) {
                        result[0] += -0.000270956366715362;
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
                          result[0] += 3.2204371501444153e-06;
                        } else {
                          result[0] += -0.000270956366715362;
                        }
                      }
                    }
                  } else {
                    result[0] += -0.00021481309189746108;
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5494686760804020631) ) ) {
                result[0] += -0.00016415618414805942;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5681735652491761712) ) ) {
                  result[0] += -0.00025341266888714614;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7463838234422112139) ) ) {
                    result[0] += -0.0001261879247781623;
                  } else {
                    result[0] += -0.00027133006962822877;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07500000000000002498) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003965500000000001142) ) ) {
                  result[0] += -0.0004099966199976443;
                } else {
                  result[0] += 0.0001280609583655105;
                }
              } else {
                result[0] += 0.005790783761247503;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                result[0] += -0.000270956366715362;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.186721136015642994e-07) ) ) {
                  result[0] += -0.000270956366715362;
                } else {
                  result[0] += -0.000270956366715362;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.07000300000000002354) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9481906544603079245) ) ) {
                    result[0] += -0.000270956366715362;
                  } else {
                    result[0] += -0.000270956366715362;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8254037945979900703) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0001106331572290500067) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)5.045799003287211847e-06) ) ) {
                        result[0] += -0.000270956366715362;
                      } else {
                        result[0] += -0.000270956366715362;
                      }
                    } else {
                      result[0] += -0.000270956366715362;
                    }
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                      result[0] += -0.000270956366715362;
                    } else {
                      result[0] += -0.000270956366715362;
                    }
                  }
                }
              } else {
                result[0] += -0.000270956366715362;
              }
            }
          } else {
            result[0] += -0.0001916429727948935;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006064500000000001313) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.384300133116745416e-05) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8025985781909549255) ) ) {
                    result[0] += -0.000270956366715362;
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                      result[0] += -0.000270956366715362;
                    } else {
                      result[0] += -0.000270956366715362;
                    }
                  }
                } else {
                  result[0] += -0.000270956366715362;
                }
              } else {
                result[0] += -0.000270956366715362;
              }
            } else {
              result[0] += -0.000270956366715362;
            }
          } else {
            result[0] += -0.0002548296679503731;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.052300094327177008e-06) ) ) {
            result[0] += -0.000270956366715362;
          } else {
            result[0] += -0.000270956366715362;
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5850000000000000755) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.115000000000000005) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01590200000000000294) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.03500000000000001027) ) ) {
            result[0] += -0.00021397672773095622;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.421180086331658321) ) ) {
              result[0] += 0.001378175962794769;
            } else {
              result[0] += -3.866657432590876e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.363906689523952442) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02192319026750580435) ) ) {
              result[0] += 0.00012903795867315145;
            } else {
              result[0] += 0.0008764634388505446;
            }
          } else {
            result[0] += -0.00040748895757627783;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02577363736079425413) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.05751864358971629093) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.333167009208742572e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2750000000000000777) ) ) {
                result[0] += -0.0006692932885020417;
              } else {
                result[0] += 0.0019241072574067326;
              }
            } else {
              result[0] += 0.0017951399376868254;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2850000000000000866) ) ) {
              result[0] += 0.00016078615284365085;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7789937396482412568) ) ) {
                result[0] += 0.0011432338876747649;
              } else {
                result[0] += -9.709984078893504e-05;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01905700000000000102) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3050000000000000488) ) ) {
              result[0] += 3.8541889981567876e-05;
            } else {
              result[0] += 0.001707262093235387;
            }
          } else {
            result[0] += 0.0035068115855024953;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01302823237808665123) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04258450000000000429) ) ) {
              result[0] += 0.0020604767647634096;
            } else {
              result[0] += -0.0017577342890826072;
            }
          } else {
            result[0] += 0.004412689026875428;
          }
        } else {
          result[0] += 0.0036535068066998358;
        }
      } else {
        result[0] += 0.01240406398152405;
      }
    }
  }
}

