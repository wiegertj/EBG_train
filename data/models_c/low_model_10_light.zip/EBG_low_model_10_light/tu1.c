
#include "header.h"

void predict_unit1(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -0.0010173225138610281;
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7584510713567840234) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
              result[0] += -0.001271653130483093;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3966559369710560001) ) ) {
                  result[0] += -0.001271653130483093;
                } else {
                  result[0] += -0.001271653130483093;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6732382808793971884) ) ) {
                  result[0] += -0.0010108879402430605;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.966590843157139501) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5928702589437735426) ) ) {
                      result[0] += -0.001271653130483093;
                    } else {
                      result[0] += -0.001271653130483093;
                    }
                  } else {
                    result[0] += -0.001271653130483093;
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6914593314070353047) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5687531224874372571) ) ) {
                  result[0] += -0.000825158759884593;
                } else {
                  result[0] += -0.0010649741119629374;
                }
              } else {
                result[0] += -0.0007194691296932317;
              }
            } else {
              result[0] += -0.0010173225138610281;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.906142995150753916) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9351570282820221847) ) ) {
                    result[0] += -0.001271653130483093;
                  } else {
                    result[0] += -0.001271653130483093;
                  }
                } else {
                  result[0] += -0.001271653130483093;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.723113719091885043) ) ) {
                    result[0] += -0.001271653130483093;
                  } else {
                    result[0] += -0.001271653130483093;
                  }
                } else {
                  result[0] += -0.001271653130483093;
                }
              }
            } else {
              result[0] += -0.001271653130483093;
            }
          } else {
            result[0] += -0.001271653130483093;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5671541132663318052) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0184998371148766029) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.07196201389915944657) ) ) {
                result[0] += -0.001061272638112674;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5347873053015076428) ) ) {
                  result[0] += -9.597588926536859e-06;
                } else {
                  result[0] += -0.0010173225138610281;
                }
              }
            } else {
              result[0] += 0.00015055037589868466;
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5986852915639623296) ) ) {
                result[0] += -0.001271653130483093;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7149244603266332598) ) ) {
                  result[0] += -0.0009951532335060243;
                } else {
                  result[0] += -0.0012767390602487837;
                }
              }
            } else {
              result[0] += -0.0009639541975978875;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.272781830548367354) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7601236426381910993) ) ) {
                  result[0] += -0.001271653130483093;
                } else {
                  result[0] += -0.001271653130483093;
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007696500000000001084) ) ) {
                  result[0] += -0.001271653130483093;
                } else {
                  result[0] += -0.001271653130483093;
                }
              }
            } else {
              result[0] += -0.0010179088706198285;
            }
          } else {
            result[0] += -0.001271653130483093;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.321871344966293327) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
              result[0] += 2.8679676098366875e-05;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01444878842564100048) ) ) {
                result[0] += -0.0006954389350353158;
              } else {
                result[0] += -0.0005880540636866981;
              }
            }
          } else {
            result[0] += 0.0008310830751308735;
          }
        } else {
          result[0] += -0.0013647745476835838;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0650000000000000161) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.05500000000000000722) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5859181088693469208) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001499500000000000182) ) ) {
              result[0] += -0.0007328671720673745;
            } else {
              result[0] += 0.0003258420474029564;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.384724495646039899e-06) ) ) {
                result[0] += -0.0010943974189207705;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  result[0] += -0.0010525362088760648;
                } else {
                  result[0] += -0.0006183371777635285;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03790150000000000463) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
                  result[0] += -0.0007632057930787546;
                } else {
                  result[0] += -0.0007631249862434294;
                }
              } else {
                result[0] += 0.00019325545550274303;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.115000000000000005) ) ) {
            result[0] += -0.00022232974630680176;
          } else {
            result[0] += 0.0017208648949946419;
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002710500000000000669) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.0650000000000000161) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8327395279648243109) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007631825330566300962) ) ) {
                result[0] += -0.00036312316790358435;
              } else {
                result[0] += -0.0010018515406096265;
              }
            } else {
              result[0] += -0.0007954429880513134;
            }
          } else {
            result[0] += 4.622390435590293e-05;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8030059940338053481) ) ) {
            result[0] += 0.0012230822085620061;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05574000000000000482) ) ) {
              result[0] += -0.000225404097455936;
            } else {
              result[0] += 0.0009644526754277343;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2650000000000000688) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002726474613321750156) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1950000000000000344) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6836184685175880071) ) ) {
              result[0] += 0.0007871325690008874;
            } else {
              result[0] += -0.00013031436513011698;
            }
          } else {
            result[0] += 0.0017988557948806225;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.891911223721401525) ) ) {
            result[0] += 0.0029960657567188343;
          } else {
            result[0] += -0.0008956194540524004;
          }
        }
      } else {
        result[0] += 0.012938430873409885;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -0.0009733607249143246;
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7584510713567840234) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
              result[0] += -0.0012167008948114962;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3966559369710560001) ) ) {
                  result[0] += -0.0012167008948114962;
                } else {
                  result[0] += -0.0012167008948114962;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6732382808793971884) ) ) {
                  result[0] += -0.0009672042099881693;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.729199597233659459e-06) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7077536600502513098) ) ) {
                      result[0] += -0.0012167008948114962;
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.966590843157139501) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
                          result[0] += -0.0012167008948114962;
                        } else {
                          result[0] += -0.0012167008948114962;
                        }
                      } else {
                        result[0] += -0.0012167008948114962;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.735388073517588059) ) ) {
                      result[0] += -0.0012500952330756101;
                    } else {
                      result[0] += -0.0012167008948114962;
                    }
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6914593314070353047) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5687531224874372571) ) ) {
                  result[0] += -0.0007895009869017713;
                } else {
                  result[0] += -0.0010189531436800973;
                }
              } else {
                result[0] += -0.0006883785467145845;
              }
            } else {
              result[0] += -0.0009733607249143246;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.906142995150753916) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9351570282820221847) ) ) {
                    result[0] += -0.0012167008948114962;
                  } else {
                    result[0] += -0.0012167008948114962;
                  }
                } else {
                  result[0] += -0.0012167008948114962;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                  result[0] += -0.0012167008948114962;
                } else {
                  result[0] += -0.0012167008948114962;
                }
              }
            } else {
              result[0] += -0.0012167008948114962;
            }
          } else {
            result[0] += -0.0012167008948114962;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5671541132663318052) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0184998371148766029) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.07196201389915944657) ) ) {
                result[0] += -0.0010154116224603711;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5347873053015076428) ) ) {
                  result[0] += -9.182846135497647e-06;
                } else {
                  result[0] += -0.0009733607249143246;
                }
              }
            } else {
              result[0] += 0.00014404460829703592;
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5986852915639623296) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6100010069597990858) ) ) {
                  result[0] += -0.0008759866128712422;
                } else {
                  result[0] += -0.0012167008948114962;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7149244603266332598) ) ) {
                  result[0] += -0.0009521494507085882;
                } else {
                  result[0] += -0.001221567045138601;
                }
              }
            } else {
              result[0] += -0.0009222986258281704;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02511600000000000291) ) ) {
                result[0] += -0.0012167008948114962;
              } else {
                result[0] += -0.0012167008948114962;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.394135022639764854) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  result[0] += -0.0012167008948114962;
                } else {
                  result[0] += -0.0009748432750088308;
                }
              } else {
                result[0] += -0.0012167008948114962;
              }
            }
          } else {
            result[0] += -0.0012167008948114962;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.321871344966293327) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
              result[0] += 2.744033473855448e-05;
            } else {
              result[0] += -0.0006518123671484879;
            }
          } else {
            result[0] += 0.0007951692933671961;
          }
        } else {
          result[0] += -0.0013057982350515266;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0650000000000000161) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.05500000000000000722) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5859181088693469208) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)5.354107497039817852e-06) ) ) {
              result[0] += -0.0007346572747993176;
            } else {
              result[0] += 4.644523499437568e-05;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6968016071608041928) ) ) {
                result[0] += -0.0006511702347617002;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8440161800932387548) ) ) {
                  result[0] += -0.0010357092136210901;
                } else {
                  result[0] += -0.0009822479283666432;
                }
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.394135022639764854) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03790150000000000463) ) ) {
                  result[0] += -0.0007302252077274183;
                } else {
                  result[0] += 0.0002536270019420881;
                }
              } else {
                result[0] += -0.0007306915368480007;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.115000000000000005) ) ) {
            result[0] += -0.00021272216046205468;
          } else {
            result[0] += 0.0016465007692736612;
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002710500000000000669) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.0650000000000000161) ) ) {
            result[0] += -0.00038382517110597706;
          } else {
            result[0] += 4.422642027401177e-05;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8030059940338053481) ) ) {
            result[0] += 0.0011702288791756322;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05574000000000000482) ) ) {
              result[0] += -0.00021566365897642963;
            } else {
              result[0] += 0.0009227755628222923;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3650000000000000466) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2050000000000000433) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
              result[0] += -0.0007278873281440241;
            } else {
              result[0] += 0.00036652335027692064;
            }
          } else {
            result[0] += 0.0023346027316284474;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.891911223721401525) ) ) {
            result[0] += 0.0027766008871904094;
          } else {
            result[0] += -0.001301716601377341;
          }
        }
      } else {
        result[0] += 0.011947187660138331;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.0009312986667423384;
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5671541132663318052) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00135663295830650032) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5392784256532664466) ) ) {
                result[0] += -0.0010253921437952957;
              } else {
                result[0] += -0.0007996329788437252;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.06355808660527756393) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0184998371148766029) ) ) {
                  result[0] += -0.0009610048313204916;
                } else {
                  result[0] += -0.0002943122866242864;
                }
              } else {
                result[0] += 0.0012253701133761862;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4677590045467516222) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                    result[0] += -0.00116412332258618;
                  } else {
                    result[0] += -0.00116412332258618;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6735883055778896233) ) ) {
                    result[0] += -0.0011997853173872713;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6269974968039345731) ) ) {
                      result[0] += -0.00116412332258618;
                    } else {
                      result[0] += -0.00116412332258618;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.794554612313755398e-06) ) ) {
                  result[0] += -0.0008831335617480766;
                } else {
                  result[0] += -0.0012742781769743761;
                }
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5986852915639623296) ) ) {
                  result[0] += -0.00116412332258618;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7149244603266332598) ) ) {
                    result[0] += -0.0009110040001484636;
                  } else {
                    result[0] += -0.001168779190853517;
                  }
                }
              } else {
                result[0] += -0.0008824431257462845;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7601236426381910993) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.729199597233659459e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9808239647505231362) ) ) {
                    result[0] += -0.00116412332258618;
                  } else {
                    result[0] += -0.00116412332258618;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7269841738944724518) ) ) {
                    result[0] += -0.00116412332258618;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.051391296366422923) ) ) {
                      result[0] += -0.00116412332258618;
                    } else {
                      result[0] += -0.00116412332258618;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9127147582663316383) ) ) {
                    result[0] += -0.00116412332258618;
                  } else {
                    result[0] += -0.00116412332258618;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.272781830548367354) ) ) {
                    result[0] += -0.00116412332258618;
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009152500000000002647) ) ) {
                      result[0] += -0.00116412332258618;
                    } else {
                      result[0] += -0.00116412332258618;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.00116412332258618;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
              result[0] += -0.0008958244599140151;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                  result[0] += -0.0012753000033827004;
                } else {
                  result[0] += -0.0008954325323363154;
                }
              } else {
                result[0] += -0.0009427946197860374;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6914593314070353047) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5687531224874372571) ) ) {
                result[0] += -0.0007553841013649874;
              } else {
                result[0] += -0.0009749208899565119;
              }
            } else {
              result[0] += -0.0006586314881625715;
            }
          } else {
            result[0] += -0.00116412332258618;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.321871344966293327) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02500000000000000486) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
                result[0] += 0.00019813043815352236;
              } else {
                result[0] += -0.0005462760403134735;
              }
            } else {
              result[0] += 0.001962448038202899;
            }
          } else {
            result[0] += -0.0012493704792177899;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08500000000000000611) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.05500000000000000722) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6732382808793971884) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005959500000000000387) ) ) {
              result[0] += -0.0005914877914816864;
            } else {
              result[0] += 0.00020587346507142793;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01210357511382575101) ) ) {
                result[0] += -0.0009625398510320764;
              } else {
                result[0] += -0.0005146722765563442;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.394135022639764854) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                  result[0] += -0.0007659623218256177;
                } else {
                  result[0] += 0.00015176158051314278;
                }
              } else {
                result[0] += -0.0006991159974390278;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.115000000000000005) ) ) {
            result[0] += -0.0002035297494074449;
          } else {
            result[0] += 0.00157535015741442;
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003637500000000000542) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.0650000000000000161) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8254037945979900703) ) ) {
              result[0] += -0.00032585355768056424;
            } else {
              result[0] += -0.0007526593195292115;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08693186820944626136) ) ) {
              result[0] += 0.0008744625073955523;
            } else {
              result[0] += -1.6952985637934754e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7293493725076146683) ) ) {
            result[0] += 0.0015040231579220185;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05574000000000000482) ) ) {
              result[0] += -9.491090816954752e-05;
            } else {
              result[0] += 0.0008896195591062957;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3350000000000000755) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1950000000000000344) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7211604863065327331) ) ) {
              result[0] += 0.0005940101630060112;
            } else {
              result[0] += -0.00042177326485336246;
            }
          } else {
            result[0] += 0.002010746211389079;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.96280210579579717) ) ) {
            result[0] += 0.0031951436839756145;
          } else {
            result[0] += -0.0011639712158925675;
          }
        }
      } else {
        result[0] += 0.014023704861331615;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.0008910542458474462;
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5814822343216081713) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00135663295830650032) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5515127872864322711) ) ) {
                result[0] += -0.0009580973041225058;
              } else {
                result[0] += -0.0009584812647544511;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01940114940222455522) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4781247323869347032) ) ) {
                  result[0] += -0.0005224360182742342;
                } else {
                  result[0] += -0.0009194767111858721;
                }
              } else {
                result[0] += -0.00013391375592020508;
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                    result[0] += -0.0011138177969360714;
                  } else {
                    result[0] += -0.0011138177969360714;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6735883055778896233) ) ) {
                    result[0] += -0.0011479387218527326;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6269974968039345731) ) ) {
                      result[0] += -0.0011138177969360714;
                    } else {
                      result[0] += -0.0011138177969360714;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3346339054385528144) ) ) {
                  result[0] += -0.0011138177969360714;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003812769089456950235) ) ) {
                    result[0] += -0.0008304831181570109;
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01798150000000000096) ) ) {
                      result[0] += -0.0011138177969360714;
                    } else {
                      result[0] += -0.0008280251689881462;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.794554612313755398e-06) ) ) {
                result[0] += -0.0008745626245299397;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                  result[0] += -0.0012205112871985745;
                } else {
                  result[0] += -0.0008439824737898964;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7601236426381910993) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.729199597233659459e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9808239647505231362) ) ) {
                    result[0] += -0.0011138177969360714;
                  } else {
                    result[0] += -0.0011138177969360714;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7269841738944724518) ) ) {
                    result[0] += -0.0011138177969360714;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.051391296366422923) ) ) {
                      result[0] += -0.0011138177969360714;
                    } else {
                      result[0] += -0.0011138177969360714;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9127147582663316383) ) ) {
                    result[0] += -0.0011138177969360714;
                  } else {
                    result[0] += -0.0011138177969360714;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.272781830548367354) ) ) {
                    result[0] += -0.0011138177969360714;
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009152500000000002647) ) ) {
                      result[0] += -0.0011138177969360714;
                    } else {
                      result[0] += -0.0011138177969360714;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.0011138177969360714;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
              result[0] += -0.0008571129939792168;
            } else {
              result[0] += -0.0011205003234743855;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5392784256532664466) ) ) {
            result[0] += -0.00042732386206168204;
          } else {
            result[0] += -0.0009295146742786253;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.459978591867425068) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02500000000000000486) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
                result[0] += 0.00018956858251055077;
              } else {
                result[0] += -0.00058047844417226;
              }
            } else {
              result[0] += 0.0018854523694668546;
            }
          } else {
            result[0] += -0.0012729709629459547;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08500000000000000611) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.05500000000000000722) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6732382808793971884) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004749500000000001117) ) ) {
              result[0] += -0.0005895042420005296;
            } else {
              result[0] += 9.726925205131812e-05;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01210357511382575101) ) ) {
                result[0] += -0.0009209453977418742;
              } else {
                result[0] += -0.0004924316265260825;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.394135022639764854) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                  result[0] += -0.0007328626179712069;
                } else {
                  result[0] += 0.00014520347285128048;
                }
              } else {
                result[0] += -0.0006689049389891044;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.115000000000000005) ) ) {
            result[0] += -0.00019473457210043024;
          } else {
            result[0] += 0.0015072741931122385;
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006452000000000001137) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.0650000000000000161) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8254037945979900703) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04500000000000000527) ) ) {
                result[0] += -0.00033543776543031067;
              } else {
                result[0] += 6.4649006377048e-05;
              }
            } else {
              result[0] += -0.0007232038689858159;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08693186820944626136) ) ) {
              result[0] += 0.0009392617991382647;
            } else {
              result[0] += -5.665336073220112e-06;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3966559369710560001) ) ) {
            result[0] += 0.0019474269716117849;
          } else {
            result[0] += 0.0004335550648871646;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2750000000000000777) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0003305000000000000646) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1950000000000000344) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7211604863065327331) ) ) {
              result[0] += 0.0005790298142285508;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7642320229909970175) ) ) {
                result[0] += -0.0006765246746313803;
              } else {
                result[0] += -0.00011993799136779545;
              }
            }
          } else {
            result[0] += 0.0017513803291620085;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7760221401809592745) ) ) {
            result[0] += 0.003095690631255569;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.96280210579579717) ) ) {
              result[0] += 0.0013339779572691603;
            } else {
              result[0] += -0.0012137210004583183;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4450000000000000622) ) ) {
          result[0] += 0.00436882253186767;
        } else {
          result[0] += 0.013417695316703629;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.0008525489162569908;
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5814822343216081713) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00135663295830650032) ) ) {
              result[0] += -0.0009751296797053633;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01940114940222455522) ) ) {
                result[0] += -0.0008589484773138304;
              } else {
                result[0] += -0.00012812691035784613;
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
                  result[0] += -0.0010656861353962634;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6735883055778896233) ) ) {
                    result[0] += -0.0010983325850315708;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6269974968039345731) ) ) {
                      result[0] += -0.0010656861353962634;
                    } else {
                      result[0] += -0.0010656861353962634;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3346339054385528144) ) ) {
                  result[0] += -0.0010656861353962634;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003812769089456950235) ) ) {
                    result[0] += -0.0007945952624703667;
                  } else {
                    result[0] += -0.0010656861353962634;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001504690974371400121) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.794554612313755398e-06) ) ) {
                  result[0] += -0.000836769951118691;
                } else {
                  result[0] += -0.0011663259784939985;
                }
              } else {
                result[0] += -0.0008370099915460092;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7601236426381910993) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.729199597233659459e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9808239647505231362) ) ) {
                    result[0] += -0.0010656861353962634;
                  } else {
                    result[0] += -0.0010656861353962634;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7269841738944724518) ) ) {
                    result[0] += -0.0010656861353962634;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.051391296366422923) ) ) {
                      result[0] += -0.0010656861353962634;
                    } else {
                      result[0] += -0.0010656861353962634;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9127147582663316383) ) ) {
                    result[0] += -0.0010656861353962634;
                  } else {
                    result[0] += -0.0010656861353962634;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.272781830548367354) ) ) {
                    result[0] += -0.0010656861353962634;
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009152500000000002647) ) ) {
                      result[0] += -0.0010656861353962634;
                    } else {
                      result[0] += -0.0010656861353962634;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.0010656861353962634;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.883880929790755059e-06) ) ) {
              result[0] += -0.0010720798883968787;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7983409114572864729) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7601236426381910993) ) ) {
                    result[0] += -0.0008039608350783452;
                  } else {
                    result[0] += -0.0011717697394863463;
                  }
                } else {
                  result[0] += -0.0008083175677794788;
                }
              } else {
                result[0] += -0.0008463002730114693;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7463838234422112139) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5392784256532664466) ) ) {
              result[0] += -0.0004088578189142164;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.482877277201360311) ) ) {
                result[0] += -0.0008925154341987209;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6914593314070353047) ) ) {
                  result[0] += -0.0006175878084067399;
                } else {
                  result[0] += -0.0008479608236484049;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7753767533919598831) ) ) {
              result[0] += -0.0009106721432354883;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.72638075848137134e-06) ) ) {
                result[0] += -0.0010736504681128712;
              } else {
                result[0] += -0.0009464851598018386;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.459978591867425068) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6858832018090453841) ) ) {
                result[0] += -0.00021877749549107216;
              } else {
                result[0] += -0.0007326110937488009;
              }
            } else {
              result[0] += 0.000703033172572825;
            }
          } else {
            result[0] += -0.0012179617794807033;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08500000000000000611) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.05500000000000000722) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5859181088693469208) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001499500000000000182) ) ) {
              result[0] += -0.0006217918296497569;
            } else {
              result[0] += 0.0003287216634639337;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6968016071608041928) ) ) {
                result[0] += -0.0005719965903615964;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8440161800932387548) ) ) {
                  result[0] += -0.000909561400020528;
                } else {
                  result[0] += -0.0008590492659379138;
                }
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.394135022639764854) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03790150000000000463) ) ) {
                  result[0] += -0.0006339007572194199;
                } else {
                  result[0] += 0.00022970066395719497;
                }
              } else {
                result[0] += -0.0006399993978725104;
              }
            }
          }
        } else {
          result[0] += 1.4980283389137175e-05;
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006452000000000001137) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.03500000000000001027) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
              result[0] += -0.0006775326697418545;
            } else {
              result[0] += 7.030800600351223e-05;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6503673217403566076) ) ) {
              result[0] += 0.0002740926375948661;
            } else {
              result[0] += -0.00022954573903238637;
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3115605993075549196) ) ) {
            result[0] += 0.002093754384449876;
          } else {
            result[0] += 0.00041662342632932376;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3350000000000000755) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1950000000000000344) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7211604863065327331) ) ) {
              result[0] += 0.0004819563425889745;
            } else {
              result[0] += -0.0004042146999807401;
            }
          } else {
            result[0] += 0.0017974159412504152;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7760221401809592745) ) ) {
            result[0] += 0.003286462672628837;
          } else {
            result[0] += 0.0014899364534269133;
          }
        }
      } else {
        result[0] += 0.012837873400224667;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.0008157075262232786;
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5814822343216081713) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00135663295830650032) ) ) {
              result[0] += -0.0009329911792880514;
            } else {
              result[0] += -0.0008129190548446991;
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
                  result[0] += -0.0010196343982830133;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6735883055778896233) ) ) {
                    result[0] += -0.0010508700894723295;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6269974968039345731) ) ) {
                      result[0] += -0.0010196343982830133;
                    } else {
                      result[0] += -0.0010196343982830133;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3346339054385528144) ) ) {
                  result[0] += -0.0010196343982830133;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6802634857286432579) ) ) {
                    result[0] += -0.0007607444483236143;
                  } else {
                    result[0] += -0.0010364390932261025;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001504690974371400121) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.794554612313755398e-06) ) ) {
                  result[0] += -0.0008006104210907843;
                } else {
                  result[0] += -0.0011159252689736598;
                }
              } else {
                result[0] += -0.0008008400885965751;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7601236426381910993) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.729199597233659459e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9808239647505231362) ) ) {
                    result[0] += -0.0010196343982830133;
                  } else {
                    result[0] += -0.0010196343982830133;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7269841738944724518) ) ) {
                    result[0] += -0.0010196343982830133;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.051391296366422923) ) ) {
                      result[0] += -0.0010196343982830133;
                    } else {
                      result[0] += -0.0010196343982830133;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9127147582663316383) ) ) {
                    result[0] += -0.0010196343982830133;
                  } else {
                    result[0] += -0.0010196343982830133;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.272781830548367354) ) ) {
                    result[0] += -0.0010196343982830133;
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009152500000000002647) ) ) {
                      result[0] += -0.0010196343982830133;
                    } else {
                      result[0] += -0.0010196343982830133;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.0010196343982830133;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.883880929790755059e-06) ) ) {
              result[0] += -0.0010257518565824296;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7983409114572864729) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7601236426381910993) ) ) {
                    result[0] += -0.0007692190928367518;
                  } else {
                    result[0] += -0.0011211337874853181;
                  }
                } else {
                  result[0] += -0.0007733875570577379;
                }
              } else {
                result[0] += -0.0008097289070181377;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7463838234422112139) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5478500007788945636) ) ) {
              result[0] += -0.0003577471153416203;
            } else {
              result[0] += -0.000804182688523715;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7753767533919598831) ) ) {
              result[0] += -0.0008713190609876402;
            } else {
              result[0] += -0.001027254566480289;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.459978591867425068) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02500000000000000486) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01332150000000000174) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.512360309673366987) ) ) {
                    result[0] += 0.0011188602916798857;
                  } else {
                    result[0] += -0.000558294866998727;
                  }
                } else {
                  result[0] += 0.0005316911096770485;
                }
              } else {
                result[0] += 0.002188850202247758;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                result[0] += -0.0007196264337409192;
              } else {
                result[0] += -8.994161238237104e-06;
              }
            }
          } else {
            result[0] += -0.0011653297203596798;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.115000000000000005) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.0650000000000000161) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5800027599246232457) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001499500000000000182) ) ) {
              result[0] += -0.0005004317730838547;
            } else {
              result[0] += 0.00032404892480905893;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0435660000000000075) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8764371766733816127) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005959500000000000387) ) ) {
                    result[0] += -0.0006303021403131383;
                  } else {
                    result[0] += -4.5032605325170114e-05;
                  }
                } else {
                  result[0] += 0.0002461363437074663;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.767254320477387064) ) ) {
                  result[0] += -0.0008816520775393406;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
                    result[0] += -0.0006921505591846195;
                  } else {
                    result[0] += -0.000706834732656505;
                  }
                }
              }
            } else {
              result[0] += -1.8975131043240834e-06;
            }
          }
        } else {
          result[0] += 0.00010827118065985365;
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003637500000000000542) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.03500000000000001027) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
              result[0] += -0.0006533156066369564;
            } else {
              result[0] += 0.0001894531249270795;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6503673217403566076) ) ) {
              result[0] += 0.0003282631003321199;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001886500000000000373) ) ) {
                result[0] += -7.070034289868854e-05;
              } else {
                result[0] += -0.0006249973826574569;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7293493725076146683) ) ) {
            result[0] += 0.0015584315621801194;
          } else {
            result[0] += 0.00020774131072640354;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3550000000000000377) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.08500000000000000611) ) ) {
            result[0] += -0.0005639689091936919;
          } else {
            result[0] += 0.0011633382424149903;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
            result[0] += 0.003240301223179672;
          } else {
            result[0] += 0.0016515071330679024;
          }
        }
      } else {
        result[0] += 0.01271523932004793;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.0007804581715481653;
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5671541132663318052) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00135663295830650032) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5392784256532664466) ) ) {
                result[0] += -0.0008572231033540875;
              } else {
                result[0] += -0.0006412047875088443;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.06355808660527756393) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  result[0] += -0.0008074963635950157;
                } else {
                  result[0] += 4.586876868356659e-05;
                }
              } else {
                result[0] += 0.0012188703949196067;
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4677590045467516222) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                    result[0] += -0.0009755727053494781;
                  } else {
                    result[0] += -0.0009755727053494781;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6735883055778896233) ) ) {
                    result[0] += -0.0010054586015180809;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6269974968039345731) ) ) {
                      result[0] += -0.0009755727053494781;
                    } else {
                      result[0] += -0.0009755727053494781;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3346339054385528144) ) ) {
                  result[0] += -0.0009755727053494781;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6802634857286432579) ) ) {
                    result[0] += -0.0007278702256224465;
                  } else {
                    result[0] += -0.000991651215191642;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001504690974371400121) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.794554612313755398e-06) ) ) {
                  result[0] += -0.0007364213469995131;
                } else {
                  result[0] += -0.0010677025367658332;
                }
              } else {
                result[0] += -0.0007370619163722342;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7601236426381910993) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.729199597233659459e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9808239647505231362) ) ) {
                    result[0] += -0.0009755727053494781;
                  } else {
                    result[0] += -0.0009755727053494781;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7269841738944724518) ) ) {
                    result[0] += -0.0009755727053494781;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.051391296366422923) ) ) {
                      result[0] += -0.0009755727053494781;
                    } else {
                      result[0] += -0.0009755727053494781;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9127147582663316383) ) ) {
                    result[0] += -0.0009755727053494781;
                  } else {
                    result[0] += -0.0009755727053494781;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.272781830548367354) ) ) {
                    result[0] += -0.0009755727053494781;
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009152500000000002647) ) ) {
                      result[0] += -0.0009755727053494781;
                    } else {
                      result[0] += -0.0009755727053494781;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.0009755727053494781;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.883880929790755059e-06) ) ) {
              result[0] += -0.0009814258085333975;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7983409114572864729) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7601236426381910993) ) ) {
                    result[0] += -0.0007359786533966359;
                  } else {
                    result[0] += -0.0010726859783835715;
                  }
                } else {
                  result[0] += -0.0007399669848260853;
                }
              } else {
                result[0] += -0.0007747379077731933;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5478500007788945636) ) ) {
            result[0] += -0.00034228770795934277;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7463838234422112139) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4455657651192640456) ) ) {
                result[0] += -0.0008193042816952312;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6914593314070353047) ) ) {
                  result[0] += -0.0005423558962597673;
                } else {
                  result[0] += -0.000776566370658153;
                }
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.0009878092489730165;
              } else {
                result[0] += -0.0007423142606800629;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.459978591867425068) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02500000000000000486) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
                result[0] += 0.0001700348358048516;
              } else {
                result[0] += -0.0005171989916326044;
              }
            } else {
              result[0] += 0.0017739842223182655;
            }
          } else {
            result[0] += -0.0011149720623684681;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.115000000000000005) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6968016071608041928) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001237226668511850168) ) ) {
              result[0] += -0.0005796231322080472;
            } else {
              result[0] += -3.5781528599976812e-06;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0435660000000000075) ) ) {
              result[0] += -0.0007911979132962021;
            } else {
              result[0] += -1.8155154393955015e-06;
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.115000000000000005) ) ) {
            result[0] += -0.0002173283247823617;
          } else {
            result[0] += 0.001436813917402564;
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003637500000000000542) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.03500000000000001027) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002825000000000000362) ) ) {
              result[0] += -0.0006250837308814917;
            } else {
              result[0] += 0.00018126624399221456;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6503673217403566076) ) ) {
              result[0] += 0.0003140777923897825;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001886500000000000373) ) ) {
                result[0] += -6.764515291653083e-05;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004718492901569751492) ) ) {
                  result[0] += -0.0010284813371114721;
                } else {
                  result[0] += -0.0003890978025195906;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7293493725076146683) ) ) {
            result[0] += 0.0014910867049780282;
          } else {
            result[0] += 0.00019876413826316525;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5350000000000001421) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.25500000000000006) ) ) {
            result[0] += 0.00021098199752500298;
          } else {
            result[0] += 0.00243653152437143;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8377933889099087317) ) ) {
            result[0] += 0.003425424363956847;
          } else {
            result[0] += 0.0014523228126870954;
          }
        }
      } else {
        result[0] += 0.012597904654242693;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.0007467320552459583;
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5814822343216081713) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00135663295830650032) ) ) {
              result[0] += -0.0008618651949951678;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.0007726018397562913;
              } else {
                result[0] += 8.786167112695332e-06;
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
                  result[0] += -0.0009334150603643431;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6735883055778896233) ) ) {
                    result[0] += -0.0009620094905111621;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6269974968039345731) ) ) {
                      result[0] += -0.0009334150603643431;
                    } else {
                      result[0] += -0.0009334150603643431;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3346339054385528144) ) ) {
                  result[0] += -0.0009334150603643431;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6802634857286432579) ) ) {
                    result[0] += -0.0006964166041765197;
                  } else {
                    result[0] += -0.0009487987659073509;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001504690974371400121) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.794554612313755398e-06) ) ) {
                  result[0] += -0.0007341903180531407;
                } else {
                  result[0] += -0.0010215636644420349;
                }
              } else {
                result[0] += -0.0007343823798149657;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7601236426381910993) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.729199597233659459e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9808239647505231362) ) ) {
                    result[0] += -0.0009334150603643431;
                  } else {
                    result[0] += -0.0009334150603643431;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7269841738944724518) ) ) {
                    result[0] += -0.0009334150603643431;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.051391296366422923) ) ) {
                      result[0] += -0.0009334150603643431;
                    } else {
                      result[0] += -0.0009334150603643431;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9127147582663316383) ) ) {
                    result[0] += -0.0009334150603643431;
                  } else {
                    result[0] += -0.0009334150603643431;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.272781830548367354) ) ) {
                    result[0] += -0.0009334150603643431;
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009152500000000002647) ) ) {
                      result[0] += -0.0009334150603643431;
                    } else {
                      result[0] += -0.0009334150603643431;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.0009334150603643431;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.883880929790755059e-06) ) ) {
              result[0] += -0.0009390152320704382;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7983409114572864729) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7601236426381910993) ) ) {
                    result[0] += -0.0007041746406189123;
                  } else {
                    result[0] += -0.0010263317554648121;
                  }
                } else {
                  result[0] += -0.0007079906233760754;
                }
              } else {
                result[0] += -0.000741258982529248;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5478500007788945636) ) ) {
            result[0] += -0.00032749635146095006;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7463838234422112139) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4455657651192640456) ) ) {
                result[0] += -0.0007838994996086562;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6914593314070353047) ) ) {
                  result[0] += -0.0005189189476810109;
                } else {
                  result[0] += -0.0007430084316320981;
                }
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.0009451228234478997;
              } else {
                result[0] += -0.0007102364658652289;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.459978591867425068) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7342470301758795559) ) ) {
                result[0] += -0.00026862112967739347;
              } else {
                result[0] += -0.0006521458327996347;
              }
            } else {
              result[0] += 0.0006213872701736613;
            }
          } else {
            result[0] += -0.0010667905212942586;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1350000000000000366) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02500000000000000486) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.03500000000000001027) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006308000000000001106) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8764371766733816127) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5800027599246232457) ) ) {
                  result[0] += -0.00035982984461006834;
                } else {
                  result[0] += -0.000590863098915641;
                }
              } else {
                result[0] += 0.00027244047424991277;
              }
            } else {
              result[0] += 4.9884653314757984e-05;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.767254320477387064) ) ) {
              result[0] += -0.0007819453036695046;
            } else {
              result[0] += -0.000599327533433384;
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1350000000000000366) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.762281072713567931) ) ) {
              result[0] += -0.0001355923399955118;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.009662942724727452) ) ) {
                result[0] += -0.0008929796659974582;
              } else {
                result[0] += -0.00026435861476319013;
              }
            }
          } else {
            result[0] += 0.0013747245511181111;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002726474613321750156) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6299505656030152112) ) ) {
            result[0] += 0.0004668913077377308;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002055218118527550337) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8327395279648243109) ) ) {
                result[0] += -5.2785205602655056e-05;
              } else {
                result[0] += -0.0006187753998847254;
              }
            } else {
              result[0] += -0.0010352407479203164;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7642320229909970175) ) ) {
            result[0] += 0.00132288181796428;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04562750000000000833) ) ) {
              result[0] += -4.6906021541131984e-05;
            } else {
              result[0] += 0.0012620044500983075;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3850000000000000644) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002339521674937150662) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2650000000000000688) ) ) {
            result[0] += 0.0003573958615456878;
          } else {
            result[0] += 0.0020951370179082373;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8377933889099087317) ) ) {
            result[0] += 0.0034091414196301363;
          } else {
            result[0] += 0.0018691647320416985;
          }
        }
      } else {
        result[0] += 0.012569755618252767;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.0007144633532707405;
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5814822343216081713) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0008535000000000002003) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5392784256532664466) ) ) {
                result[0] += -0.0009729249322846479;
              } else {
                result[0] += -0.0007638600467395042;
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.0007392152209049163;
              } else {
                result[0] += 3.716834262380836e-05;
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
                  result[0] += -0.0008930791832709779;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6735883055778896233) ) ) {
                    result[0] += -0.0009204379558106583;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6269974968039345731) ) ) {
                      result[0] += -0.0008930791832709779;
                    } else {
                      result[0] += -0.0008930791832709779;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3346339054385528144) ) ) {
                  result[0] += -0.0008930791832709779;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6802634857286432579) ) ) {
                    result[0] += -0.000666322195221003;
                  } else {
                    result[0] += -0.0009077981092508821;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001504690974371400121) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.794554612313755398e-06) ) ) {
                  result[0] += -0.0007024635850169597;
                } else {
                  result[0] += -0.0009774186016916033;
                }
              } else {
                result[0] += -0.000702647347170231;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7601236426381910993) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.729199597233659459e-06) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9808239647505231362) ) ) {
                    result[0] += -0.0008930791832709779;
                  } else {
                    result[0] += -0.0008930791832709779;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7269841738944724518) ) ) {
                    result[0] += -0.0008930791832709779;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.051391296366422923) ) ) {
                      result[0] += -0.0008930791832709779;
                    } else {
                      result[0] += -0.0008930791832709779;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9127147582663316383) ) ) {
                    result[0] += -0.0008930791832709779;
                  } else {
                    result[0] += -0.0008930791832709779;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.272781830548367354) ) ) {
                    result[0] += -0.0008930791832709779;
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009152500000000002647) ) ) {
                      result[0] += -0.0008930791832709779;
                    } else {
                      result[0] += -0.0008930791832709779;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.0008930791832709779;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.883880929790755059e-06) ) ) {
              result[0] += -0.000898437353484671;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7983409114572864729) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7601236426381910993) ) ) {
                    result[0] += -0.0006737449818718353;
                  } else {
                    result[0] += -0.0009819806481136115;
                  }
                } else {
                  result[0] += -0.0006773960636990487;
                }
              } else {
                result[0] += -0.0007092267896889247;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5478500007788945636) ) ) {
            result[0] += -0.00031334417721180286;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7463838234422112139) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4455657651192640456) ) ) {
                result[0] += -0.0007500246724150354;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6914593314070353047) ) ) {
                  result[0] += -0.0004964947852865134;
                } else {
                  result[0] += -0.0007109006394501847;
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7753767533919598831) ) ) {
                result[0] += -0.0007646695943821171;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.72638075848137134e-06) ) ) {
                  result[0] += -0.0008993353486421556;
                } else {
                  result[0] += -0.0007880446778191686;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.321871344966293327) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7210440605025126848) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04500000000000000527) ) ) {
                result[0] += -3.053282380434022e-05;
              } else {
                result[0] += 0.00576789849294067;
              }
            } else {
              result[0] += -0.0003954559076682431;
            }
          } else {
            result[0] += -0.0009431012459746735;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1350000000000000366) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02500000000000000486) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.03500000000000001027) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006308000000000001106) ) ) {
              result[0] += -0.000541582777081398;
            } else {
              result[0] += 4.772897645631545e-05;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.767254320477387064) ) ) {
              result[0] += -0.0007481549235890333;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02906350000000000253) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0044229535828532009) ) ) {
                  result[0] += -0.0005759738623561553;
                } else {
                  result[0] += -0.0007565458920129043;
                }
              } else {
                result[0] += 2.416181572279787e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1350000000000000366) ) ) {
            result[0] += -0.0002322195565841483;
          } else {
            result[0] += 0.0013153182667268054;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002726474613321750156) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5834559473869348478) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.0650000000000000161) ) ) {
              result[0] += -0.00022731498840163782;
            } else {
              result[0] += 0.0009290402059691736;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001939500000000000252) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
                result[0] += -0.0003863687600912342;
              } else {
                result[0] += 2.8057681074712235e-05;
              }
            } else {
              result[0] += -0.0007867947900434017;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7642320229909970175) ) ) {
            result[0] += 0.0012657158253804163;
          } else {
            result[0] += 0.00019106978464194995;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6150000000000001021) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.25500000000000006) ) ) {
            result[0] += 0.0001677792953824945;
          } else {
            result[0] += 0.002235527532038592;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.96280210579579717) ) ) {
            result[0] += 0.003155657647638961;
          } else {
            result[0] += -0.001610986500668061;
          }
        }
      } else {
        result[0] += 0.012806726988256516;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.000683589086046047;
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5671541132663318052) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0008535000000000002003) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5392784256532664466) ) ) {
                result[0] += -0.0009308817061185882;
              } else {
                result[0] += -0.0005432417658725883;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.06355808660527756393) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  result[0] += -0.0007072713456000472;
                } else {
                  result[0] += 5.841602137708575e-05;
                }
              } else {
                result[0] += 0.0005516163447654683;
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4677590045467516222) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6249533869346735049) ) ) {
                    result[0] += -0.0008544863495995349;
                  } else {
                    result[0] += -0.0008544863495995349;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6732382808793971884) ) ) {
                    result[0] += -0.0008644751881235405;
                  } else {
                    result[0] += -0.0008544863495995349;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4455657651192640456) ) ) {
                  result[0] += -0.0008544863495995349;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004570381822539301524) ) ) {
                    result[0] += -0.000587649543729998;
                  } else {
                    result[0] += -0.0008623942124021008;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001504690974371400121) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.794554612313755398e-06) ) ) {
                  result[0] += -0.0006425157524537941;
                } else {
                  result[0] += -0.0009351811895684129;
                }
              } else {
                result[0] += -0.0006431124001924246;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8932219825431284566) ) ) {
                    result[0] += -0.0008544863495995349;
                  } else {
                    result[0] += -0.0008544863495995349;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                      result[0] += -0.0008544863495995349;
                    } else {
                      result[0] += -0.0008544863495995349;
                    }
                  } else {
                    result[0] += -0.0008544863495995349;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02511600000000000291) ) ) {
                    result[0] += -0.0008544863495995349;
                  } else {
                    result[0] += -0.0008544863495995349;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.272781830548367354) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06473550000000001525) ) ) {
                      result[0] += -0.0008544863495995349;
                    } else {
                      result[0] += -0.0008544863495995349;
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009152500000000002647) ) ) {
                      result[0] += -0.0008544863495995349;
                    } else {
                      result[0] += -0.0008544863495995349;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.0008544863495995349;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8066186623115578769) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7536081807788946874) ) ) {
                  result[0] += -0.0006607438272219021;
                } else {
                  result[0] += -0.0009155659155286318;
                }
              } else {
                result[0] += -0.0006481235936810172;
              }
            } else {
              result[0] += -0.0006859115248473303;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6914593314070353047) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5478500007788945636) ) ) {
              result[0] += -0.00029980356408412995;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4455657651192640456) ) ) {
                result[0] += -0.0007176136858259443;
              } else {
                result[0] += -0.00047503964331677;
              }
            }
          } else {
            result[0] += -0.0008604721658750069;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.321871344966293327) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7149244603266332598) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005150500000000001431) ) ) {
                  result[0] += -0.00041894850767321704;
                } else {
                  result[0] += 0.0004017548702505058;
                }
              } else {
                result[0] += 0.0072471783568845835;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                result[0] += -0.000602235133908053;
              } else {
                result[0] += -1.1667098577934182e-05;
              }
            }
          } else {
            result[0] += -0.0009023467975416415;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2050000000000000433) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03500000000000001027) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.03500000000000001027) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006308000000000001106) ) ) {
            result[0] += -0.0005260653200576703;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5928702589437735426) ) ) {
              result[0] += 0.0003125171702987793;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06315050000000001218) ) ) {
                result[0] += -0.0006876647066498886;
              } else {
                result[0] += 2.3117705689939768e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6717423563567840317) ) ) {
            result[0] += 0.0001011819097440557;
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.09500000000000001499) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05720850000000000934) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8393503195226131863) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.272781830548367354) ) ) {
                    result[0] += -0.0005964784178146071;
                  } else {
                    result[0] += 0.00013014366496914495;
                  }
                } else {
                  result[0] += -0.0006607954127863145;
                }
              } else {
                result[0] += 0.00036837471458410915;
              }
            } else {
              result[0] += 0.00016205689579868485;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2273413669989351737) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002579500000000000629) ) ) {
            result[0] += 0.0007897145669514806;
          } else {
            result[0] += 0.002610969870228119;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01940114940222455522) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
                result[0] += 0.00019474596556399786;
              } else {
                result[0] += -0.00047623292297829085;
              }
            } else {
              result[0] += 0.0013786348264872904;
            }
          } else {
            result[0] += -0.0014720282241948161;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4350000000000000533) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0003680466634131000282) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.25500000000000006) ) ) {
            result[0] += -3.247099842166573e-05;
          } else {
            result[0] += 0.0023906519798756803;
          }
        } else {
          result[0] += 0.0033199355003482416;
        }
      } else {
        result[0] += 0.013117570705135962;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.000654048995546161;
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5814822343216081713) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0008535000000000002003) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5392784256532664466) ) ) {
                result[0] += -0.0008906553034378716;
              } else {
                result[0] += -0.0007048115859207652;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08693186820944626136) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  result[0] += -0.0006767078682369896;
                } else {
                  result[0] += 3.937644368417576e-05;
                }
              } else {
                result[0] += 1.5564134709876855e-05;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6249533869346735049) ) ) {
                  result[0] += -0.0008175612368185694;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3966559369710560001) ) ) {
                    result[0] += -0.0008175612368185694;
                  } else {
                    result[0] += -0.0008175612368185694;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6732382808793971884) ) ) {
                  result[0] += -0.0006570252061975698;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5681735652491761712) ) ) {
                    result[0] += -0.0005685399412904994;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7326471166347855446) ) ) {
                      result[0] += -0.0008175612368185694;
                    } else {
                      result[0] += -0.0008175612368185694;
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3346339054385528144) ) ) {
                  result[0] += -0.0008175612368185694;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6802634857286432579) ) ) {
                    result[0] += -0.0006013619674939454;
                  } else {
                    result[0] += -0.0008313023862335753;
                  }
                }
              } else {
                result[0] += -0.0006156114624736391;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8932219825431284566) ) ) {
                    result[0] += -0.0008175612368185694;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.051391296366422923) ) ) {
                      result[0] += -0.0008175612368185694;
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.234671350732867934) ) ) {
                        result[0] += -0.0008175612368185694;
                      } else {
                        result[0] += -0.0008175612368185694;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                      result[0] += -0.0008175612368185694;
                    } else {
                      result[0] += -0.0008175612368185694;
                    }
                  } else {
                    result[0] += -0.0008175612368185694;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02511600000000000291) ) ) {
                    result[0] += -0.0008175612368185694;
                  } else {
                    result[0] += -0.0008175612368185694;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.272781830548367354) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06473550000000001525) ) ) {
                      result[0] += -0.0008175612368185694;
                    } else {
                      result[0] += -0.0008175612368185694;
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009152500000000002647) ) ) {
                      result[0] += -0.0008175612368185694;
                    } else {
                      result[0] += -0.0008175612368185694;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.0008175612368185694;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7536081807788946874) ) ) {
              result[0] += -0.0006321909540824658;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7983409114572864729) ) ) {
                  result[0] += -0.0008999815372998914;
                } else {
                  result[0] += -0.0006222715585293564;
                }
              } else {
                result[0] += -0.0006562710742718217;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5478500007788945636) ) ) {
            result[0] += -0.00028684808454823075;
          } else {
            result[0] += -0.000686331661110538;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.321871344966293327) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7149244603266332598) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03500000000000001027) ) ) {
                result[0] += -5.4483579760242086e-05;
              } else {
                result[0] += 0.00400047855748257;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                result[0] += -0.0005762106102270876;
              } else {
                result[0] += -1.1162925596096748e-05;
              }
            }
          } else {
            result[0] += -0.0008633534803489401;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2150000000000000244) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03500000000000001027) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006308000000000001106) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
              result[0] += -0.0004712975829499952;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7983409114572864729) ) ) {
                result[0] += -0.0006758631371030253;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
                  result[0] += -0.0003133193123764628;
                } else {
                  result[0] += -0.0006254763407210114;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3763200711443456803) ) ) {
              result[0] += 0.0004769784204052935;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06315050000000001218) ) ) {
                result[0] += -0.0004895294000896171;
              } else {
                result[0] += 0.00021807460782967108;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.762281072713567931) ) ) {
            result[0] += 7.269449892667244e-05;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.009662942724727452) ) ) {
              result[0] += -0.0008366546703495238;
            } else {
              result[0] += -7.171647227082213e-05;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004460500000000000922) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7211604863065327331) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.05580247069824354617) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.72638075848137134e-06) ) ) {
                result[0] += -0.00016688587645119404;
              } else {
                result[0] += 0.0017786647224136754;
              }
            } else {
              result[0] += 0.0003498228145034387;
            }
          } else {
            result[0] += -0.00014182054811672553;
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1507499186893259402) ) ) {
            result[0] += 0.0030001029214022385;
          } else {
            result[0] += 0.0009151230972202695;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.625000000000000111) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2650000000000000688) ) ) {
            result[0] += -7.746878074396131e-05;
          } else {
            result[0] += 0.002593915784597026;
          }
        } else {
          result[0] += 0.0034141219988367616;
        }
      } else {
        result[0] += 0.012118586281612014;
      }
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.000625785427689123;
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5814822343216081713) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001237226668511850168) ) ) {
              result[0] += -0.0008101498927731274;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08693186820944626136) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  result[0] += -0.0006474651373658313;
                } else {
                  result[0] += 2.071395593135273e-05;
                }
              } else {
                result[0] += 2.6273440315949585e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4677590045467516222) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0044229535828532009) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6191090779145730361) ) ) {
                    result[0] += -0.0007822317773263029;
                  } else {
                    result[0] += -0.0007822317773263029;
                  }
                } else {
                  result[0] += -0.0009002479585381933;
                }
              } else {
                result[0] += -0.0007822317773263029;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6858832018090453841) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6055650374709939943) ) ) {
                  result[0] += -0.0006286330266734;
                } else {
                  result[0] += -0.000366593983336332;
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007631825330566300962) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                      result[0] += -0.0007822317773263029;
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7326471166347855446) ) ) {
                        result[0] += -0.0007822317773263029;
                      } else {
                        result[0] += -0.0007822317773263029;
                      }
                    }
                  } else {
                    result[0] += -0.0007160331558281147;
                  }
                } else {
                  result[0] += -0.0005962651474570816;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8932219825431284566) ) ) {
                    result[0] += -0.0007822317773263029;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.051391296366422923) ) ) {
                      result[0] += -0.0007822317773263029;
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.234671350732867934) ) ) {
                        result[0] += -0.0007822317773263029;
                      } else {
                        result[0] += -0.0007822317773263029;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.028975360347832879) ) ) {
                      result[0] += -0.0007822317773263029;
                    } else {
                      result[0] += -0.0007822317773263029;
                    }
                  } else {
                    result[0] += -0.0007822317773263029;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02511600000000000291) ) ) {
                    result[0] += -0.0007822317773263029;
                  } else {
                    result[0] += -0.0007822317773263029;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.272781830548367354) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06473550000000001525) ) ) {
                      result[0] += -0.0007822317773263029;
                    } else {
                      result[0] += -0.0007822317773263029;
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009152500000000002647) ) ) {
                      result[0] += -0.0007822317773263029;
                    } else {
                      result[0] += -0.0007822317773263029;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.0007822317773263029;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
              result[0] += -0.0006908375190165716;
            } else {
              result[0] += -0.0006279114832219127;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5478500007788945636) ) ) {
            result[0] += -0.0002744524530932503;
          } else {
            result[0] += -0.0006566730550912244;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.321871344966293327) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7159035085929649211) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01332150000000000174) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.512360309673366987) ) ) {
                  result[0] += 0.0013386454642859281;
                } else {
                  result[0] += -0.0003546377339304709;
                }
              } else {
                result[0] += 0.0013966872495578062;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                result[0] += -0.0005513106902012197;
              } else {
                result[0] += -1.4538808132951203e-05;
              }
            }
          } else {
            result[0] += -0.0008260451902321181;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2050000000000000433) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02500000000000000486) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6047319804020101497) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001499500000000000182) ) ) {
              result[0] += -0.00043894268007082973;
            } else {
              result[0] += 0.00016510861275124963;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06315050000000001218) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6968016071608041928) ) ) {
                  result[0] += -0.00046239876196353625;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8764371766733816127) ) ) {
                    result[0] += -0.0006902030785458563;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
                      result[0] += 0.00023534408593053958;
                    } else {
                      result[0] += -0.000639136768333315;
                    }
                  }
                }
              } else {
                result[0] += -0.00032092845580116504;
              }
            } else {
              result[0] += 7.575718160444225e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1450000000000000455) ) ) {
            result[0] += -0.0001533499492778799;
          } else {
            result[0] += 0.0014070348347299498;
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003637500000000000542) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8327395279648243109) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6299505656030152112) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)6.716605685555453681e-07) ) ) {
                result[0] += -0.000254284088734341;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.08500000000000000611) ) ) {
                  result[0] += 7.648990618199575e-05;
                } else {
                  result[0] += 0.00110736744637498;
                }
              }
            } else {
              result[0] += 1.307438576493691e-05;
            }
          } else {
            result[0] += -0.0005179070556562029;
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1507499186893259402) ) ) {
            result[0] += 0.002755716846455196;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00260107659603655032) ) ) {
              result[0] += -0.0006948753319109669;
            } else {
              result[0] += 0.000781522987833391;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4450000000000000622) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0003680466634131000282) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.25500000000000006) ) ) {
            result[0] += -7.622889803199495e-05;
          } else {
            result[0] += 0.0021905876098288193;
          }
        } else {
          result[0] += 0.003009989057217185;
        }
      } else {
        result[0] += 0.012459166779206485;
      }
    }
  }
}

