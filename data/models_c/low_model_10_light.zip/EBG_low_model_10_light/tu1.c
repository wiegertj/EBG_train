
#include "header.h"

void predict_unit1(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.000966048519763742;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.568345700351758909) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.005393752740946750925) ) ) {
              result[0] += -0.0009767529150742909;
            } else {
              result[0] += -0.0005523399810716003;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4677590045467516222) ) ) {
                  result[0] += -0.0012075606384583922;
                } else {
                  result[0] += -0.0012075606384583922;
                }
              } else {
                result[0] += -0.0012295587587480184;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.341544232904992332e-05) ) ) {
                result[0] += -0.0009442355111676041;
              } else {
                result[0] += -0.0009414583634846125;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.3779290767430908e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -0.0012075606384583922;
                } else {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8068034447989950175) ) ) {
                    result[0] += -0.0012075606384583922;
                  } else {
                    result[0] += -0.0012075606384583922;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7593447680904524821) ) ) {
                  result[0] += -0.0012075606384583922;
                } else {
                  result[0] += -0.0012075606384583922;
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                    result[0] += -0.0012075606384583922;
                  } else {
                    result[0] += -0.0012075606384583922;
                  }
                } else {
                  result[0] += -0.0012075606384583922;
                }
              } else {
                result[0] += -0.0012075606384583922;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.247314011309283543) ) ) {
              result[0] += -0.0008803849200548447;
            } else {
              result[0] += -0.0012075606384583922;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0003825000000000000817) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7471533970100503463) ) ) {
              result[0] += -0.000966048519763742;
            } else {
              result[0] += -0.0012075606384583922;
            }
          } else {
            result[0] += -0.0008317049247582158;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6551236496733668924) ) ) {
              result[0] += -0.00020991810062049993;
            } else {
              result[0] += -0.000955344124453192;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.03500000000000001027) ) ) {
              result[0] += -2.7446866981922866e-05;
            } else {
              result[0] += 0.0029708904589657637;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.0650000000000000161) ) ) {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04500000000000000527) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
              result[0] += -0.0008703631703096165;
            } else {
              result[0] += -0.0010274591693989492;
            }
          } else {
            result[0] += -0.0006896140655496555;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7536081807788946874) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001281074579984450108) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
                result[0] += -0.0006806479143546047;
              } else {
                result[0] += -0.00034864323817512767;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2659201053550500626) ) ) {
                result[0] += 0.0005318913860872152;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01391911106985315068) ) ) {
                  result[0] += -0.000389873651936966;
                } else {
                  result[0] += 0.00019716807571866014;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002265000000000000032) ) ) {
              result[0] += -0.000733883832199797;
            } else {
              result[0] += -0.0006292217760970259;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01504150000000000105) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7573260829648241765) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.09500000000000001499) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5800027599246232457) ) ) {
                result[0] += 0.0002653239160322962;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
                  result[0] += -0.00040009524724865444;
                } else {
                  result[0] += -2.5177501193189984e-05;
                }
              }
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05227730674148379358) ) ) {
                result[0] += 0.0015434817544627676;
              } else {
                result[0] += 0.0005497811959482521;
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0650000000000000161) ) ) {
              result[0] += -0.00043188441338116816;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0008742997306644500989) ) ) {
                result[0] += -2.958769018677847e-07;
              } else {
                result[0] += -0.0003792080723174956;
              }
            }
          }
        } else {
          result[0] += 0.0012900319447435786;
        }
      }
    } else {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3650000000000000466) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0001725283487249000298) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04500000000000000527) ) ) {
            result[0] += -0.0005171122095052052;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.25500000000000006) ) ) {
              result[0] += 0.0007570314314081089;
            } else {
              result[0] += 0.0033472535290686354;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6915080527790725684) ) ) {
            result[0] += 0.003138727672103577;
          } else {
            result[0] += 0.0017203372428751774;
          }
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3550000000000000377) ) ) {
          result[0] += 0.0039302722562893485;
        } else {
          result[0] += 0.014851560645654531;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.0009250481701811241;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5811189422864322385) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.005393752740946750925) ) ) {
              result[0] += -0.000935298257099471;
            } else {
              result[0] += -0.0005288979573542714;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
                  result[0] += -0.0011563102019574267;
                } else {
                  result[0] += -0.0011563102019574267;
                }
              } else {
                result[0] += -0.0009015016519627227;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4330073079623726895) ) ) {
                result[0] += -0.0011773746935487182;
              } else {
                result[0] += -0.0009286531986999351;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.3779290767430908e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -0.0011563102019574267;
                } else {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8068034447989950175) ) ) {
                    result[0] += -0.0011563102019574267;
                  } else {
                    result[0] += -0.0011563102019574267;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7593447680904524821) ) ) {
                  result[0] += -0.0011563102019574267;
                } else {
                  result[0] += -0.0011563102019574267;
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                    result[0] += -0.0011563102019574267;
                  } else {
                    result[0] += -0.0011563102019574267;
                  }
                } else {
                  result[0] += -0.0011563102019574267;
                }
              } else {
                result[0] += -0.0011563102019574267;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
              result[0] += -0.0008430202445224589;
            } else {
              result[0] += -0.0008943034166755947;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0003825000000000000817) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
              result[0] += -0.0009250481701811241;
            } else {
              result[0] += -0.0011563102019574267;
            }
          } else {
            result[0] += -0.0007964062912351177;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6551236496733668924) ) ) {
              result[0] += -0.00020100890472290198;
            } else {
              result[0] += -0.0009147980832627762;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.03500000000000001027) ) ) {
              result[0] += -2.6281986421387936e-05;
            } else {
              result[0] += 0.002844802022518442;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.0650000000000000161) ) ) {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04500000000000000527) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
              result[0] += -0.000833423830808059;
            } else {
              result[0] += -0.0009838524723590062;
            }
          } else {
            result[0] += -0.0006603459520065169;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7392963230402010977) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003897500000000000357) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.03500000000000001027) ) ) {
                result[0] += -0.00035752779314926085;
              } else {
                result[0] += 2.335815696801571e-05;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.05463331189772155372) ) ) {
                result[0] += 0.001137475380036102;
              } else {
                result[0] += -0.000146450232962691;
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002265000000000000032) ) ) {
              result[0] += -0.000741074229033224;
            } else {
              result[0] += -0.0005771536137460908;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01504150000000000105) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7573260829648241765) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.09500000000000001499) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5800027599246232457) ) ) {
                result[0] += 0.00025406322561416544;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
                  result[0] += -0.00038311468709257597;
                } else {
                  result[0] += -2.410893545407978e-05;
                }
              }
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05227730674148379358) ) ) {
                result[0] += 0.0014779743909994474;
              } else {
                result[0] += 0.0005264477703835188;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0008742997306644500989) ) ) {
              result[0] += -5.194075395576922e-05;
            } else {
              result[0] += -0.0004529858751383352;
            }
          }
        } else {
          result[0] += 0.001235281319257225;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.25500000000000006) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001281074579984450108) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.25500000000000006) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04500000000000000527) ) ) {
              result[0] += -0.00047353011133965603;
            } else {
              result[0] += 0.000735913228884851;
            }
          } else {
            result[0] += 0.0025402615649622717;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7593447680904524821) ) ) {
            result[0] += 0.0027356265030058875;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001509500000000000208) ) ) {
                result[0] += 0.001460204687408329;
              } else {
                result[0] += -0.00014948257866933038;
              }
            } else {
              result[0] += 0.0014369525801962827;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4550000000000000711) ) ) {
          result[0] += 0.004884156482586342;
        } else {
          result[0] += 0.013403626477458646;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.0008857879285035502;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
              result[0] += -0.0011072349003175088;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
                  result[0] += -0.0011072349003175088;
                } else {
                  result[0] += -0.0011072349003175088;
                }
              } else {
                result[0] += -0.0008632407549957479;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5492268452512564236) ) ) {
              result[0] += -0.0008956029884658937;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.439120857165606282) ) ) {
                result[0] += -0.0011274053876208642;
              } else {
                result[0] += -0.0008892399549458581;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.3779290767430908e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -0.0011072349003175088;
                } else {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8068034447989950175) ) ) {
                    result[0] += -0.0011072349003175088;
                  } else {
                    result[0] += -0.0011072349003175088;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7593447680904524821) ) ) {
                  result[0] += -0.0011072349003175088;
                } else {
                  result[0] += -0.0011072349003175088;
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                    result[0] += -0.0011072349003175088;
                  } else {
                    result[0] += -0.0011072349003175088;
                  }
                } else {
                  result[0] += -0.0011072349003175088;
                }
              } else {
                result[0] += -0.0011072349003175088;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7673948280402010935) ) ) {
              result[0] += -0.0008072413741825946;
            } else {
              result[0] += -0.0008563480221312335;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0003825000000000000817) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7471533970100503463) ) ) {
              result[0] += -0.0008857879285035502;
            } else {
              result[0] += -0.0011072349003175088;
            }
          } else {
            result[0] += -0.0007626057774074875;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6551236496733668924) ) ) {
              result[0] += -0.00019247782663080605;
            } else {
              result[0] += -0.0008759728685412058;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.03500000000000001027) ) ) {
              result[0] += -2.5166544899603804e-05;
            } else {
              result[0] += 0.002724064942516374;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.0650000000000000161) ) ) {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03500000000000001027) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
            result[0] += -0.0007662136144362137;
          } else {
            result[0] += -0.0009214892120733297;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7593447680904524821) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001281074579984450108) ) ) {
              result[0] += -0.0005345746099724163;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.05463331189772155372) ) ) {
                result[0] += 0.0010032716018841268;
              } else {
                result[0] += -0.00016052736701530938;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.168079446220334772) ) ) {
              result[0] += -0.0007127017765515993;
            } else {
              result[0] += -0.0005518738677275194;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7269841738944724518) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01896216239618550223) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05227730674148379358) ) ) {
              result[0] += 0.0007847659033185661;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05500000000000000722) ) ) {
                result[0] += -0.0002494942316537407;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)3.928223887174962991e-06) ) ) {
                  result[0] += -0.00016480830641776628;
                } else {
                  result[0] += 0.0003591628944348535;
                }
              }
            }
          } else {
            result[0] += 0.0018648429401721149;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04770400000000000335) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0650000000000000161) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)49.50000000000000711) ) ) {
                result[0] += -0.0006401803628259167;
              } else {
                result[0] += -0.00040383699656307455;
              }
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
                result[0] += 6.266385536727552e-06;
              } else {
                result[0] += -0.0004417979329752949;
              }
            }
          } else {
            result[0] += 0.0011018664352565586;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2750000000000000777) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.650000000000000541e-05) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04500000000000000527) ) ) {
            result[0] += -0.0005794114191853704;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.25500000000000006) ) ) {
              result[0] += 0.0006554064208591943;
            } else {
              result[0] += 0.0024754918995564226;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
            result[0] += 0.0027327130692126815;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00448250000000000124) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001509500000000000208) ) ) {
                result[0] += 0.0019233965596606253;
              } else {
                result[0] += -1.9744110260335085e-05;
              }
            } else {
              result[0] += 0.0017134559389547922;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6050000000000000933) ) ) {
          result[0] += 0.005564792713602451;
        } else {
          result[0] += 0.015342135906443318;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.0008481939422992234;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5811189422864322385) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.005393752740946750925) ) ) {
              result[0] += -0.0008575924384126529;
            } else {
              result[0] += -0.00046844029341242287;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
                  result[0] += -0.0010602424179997519;
                } else {
                  result[0] += -0.0010602424179997519;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6010141514957837439) ) ) {
                  result[0] += -0.0010795568437143048;
                } else {
                  result[0] += -0.00117147418288313;
                }
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)9.765598692199240846e-06) ) ) {
                result[0] += -0.0008264858342767375;
              } else {
                result[0] += -0.0008266037000190016;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.3779290767430908e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -0.0010602424179997519;
                } else {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8068034447989950175) ) ) {
                    result[0] += -0.0010602424179997519;
                  } else {
                    result[0] += -0.0010602424179997519;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7593447680904524821) ) ) {
                  result[0] += -0.0010602424179997519;
                } else {
                  result[0] += -0.0010602424179997519;
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                    result[0] += -0.0010602424179997519;
                  } else {
                    result[0] += -0.0010602424179997519;
                  }
                } else {
                  result[0] += -0.0010602424179997519;
                }
              } else {
                result[0] += -0.0010602424179997519;
              }
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)8.256973923420418294e-06) ) ) {
              result[0] += -0.0010958960499092701;
            } else {
              result[0] += -0.0007729810054102959;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
            result[0] += -0.0008481939422992234;
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)131.5000000000000284) ) ) {
              result[0] += -0.0008516848743534463;
            } else {
              result[0] += -0.0010602424179997519;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5451673325125628855) ) ) {
              result[0] += 0.0008004868286328962;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)48.50000000000000711) ) ) {
                result[0] += -0.0008478017583489689;
              } else {
                result[0] += -0.0008387954461857929;
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05500000000000000722) ) ) {
              result[0] += 3.3484228221481427e-06;
            } else {
              result[0] += 0.0056573366942632855;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.0650000000000000161) ) ) {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04500000000000000527) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001149464901271750371) ) ) {
              result[0] += -0.0006080735374539356;
            } else {
              result[0] += -0.0001892888237033168;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.168079446220334772) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7593447680904524821) ) ) {
                result[0] += -0.0008939901266122278;
              } else {
                result[0] += -0.0009074955589280371;
              }
            } else {
              result[0] += -0.0006523024172976344;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002835000000000000605) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7392963230402010977) ) ) {
              result[0] += -0.0002959843872007281;
            } else {
              result[0] += -0.0006226467015421855;
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.03659918966571634041) ) ) {
              result[0] += 0.0010907993007321863;
            } else {
              result[0] += -3.342885754186594e-06;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01504150000000000105) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7573260829648241765) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05227730674148379358) ) ) {
                result[0] += 0.0005232890508993383;
              } else {
                result[0] += -5.032533050147859e-05;
              }
            } else {
              result[0] += 0.0012545577747007574;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0650000000000000161) ) ) {
              result[0] += -0.00039421088220070114;
            } else {
              result[0] += -8.523661874541665e-05;
            }
          }
        } else {
          result[0] += 0.0011634862077301137;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3350000000000000755) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.650000000000000541e-05) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04500000000000000527) ) ) {
            result[0] += -0.0006636756908607616;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.25500000000000006) ) ) {
              result[0] += 0.0006056568525733045;
            } else {
              result[0] += 0.002646262891848129;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.714286561348693172) ) ) {
            result[0] += 0.0030029435061601976;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2150000000000000244) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002982500000000000342) ) ) {
                  result[0] += 0.00118749810344491;
                } else {
                  result[0] += -0.00036771357044991857;
                }
              } else {
                result[0] += 0.002354387656761054;
              }
            } else {
              result[0] += 0.001992698332132958;
            }
          }
        }
      } else {
        result[0] += 0.012568930577112086;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.0008121954935291432;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5811189422864322385) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.005393752740946750925) ) ) {
              result[0] += -0.0008211951053025855;
            } else {
              result[0] += -0.00044855908103481835;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
                  result[0] += -0.0010152443574562285;
                } else {
                  result[0] += -0.0010152443574562285;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6010141514957837439) ) ) {
                  result[0] += -0.0010337390539438501;
                } else {
                  result[0] += -0.0011217553022652429;
                }
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)9.765598692199240846e-06) ) ) {
                result[0] += -0.0007914087057089974;
              } else {
                result[0] += -0.0007915215690766004;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.3779290767430908e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -0.0010152443574562285;
                } else {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8068034447989950175) ) ) {
                    result[0] += -0.0010152443574562285;
                  } else {
                    result[0] += -0.0010152443574562285;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7593447680904524821) ) ) {
                  result[0] += -0.0010152443574562285;
                } else {
                  result[0] += -0.0010152443574562285;
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                    result[0] += -0.0010152443574562285;
                  } else {
                    result[0] += -0.0010152443574562285;
                  }
                } else {
                  result[0] += -0.0010152443574562285;
                }
              } else {
                result[0] += -0.0010152443574562285;
              }
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)8.256973923420418294e-06) ) ) {
              result[0] += -0.0010493848030792676;
            } else {
              result[0] += -0.0007401746910335643;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0003825000000000000817) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
            result[0] += -0.0008121954935291432;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)103.5000000000000142) ) ) {
              result[0] += -0.0010240958095548063;
            } else {
              result[0] += -0.0007746044356893228;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9567162861906464144) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
              result[0] += 0.001624705582042234;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005067500000000000823) ) ) {
                  result[0] += -0.0008212085160131909;
                } else {
                  result[0] += -1.9651921966355615e-05;
                }
              } else {
                result[0] += 0.001302839501777084;
              }
            }
          } else {
            result[0] += -0.0008208262764676754;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.0650000000000000161) ) ) {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03500000000000001027) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
            result[0] += -0.0007202120901869086;
          } else {
            result[0] += -0.0008546954582873523;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7593447680904524821) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001281074579984450108) ) ) {
              result[0] += -0.00049424860278975;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.04446937286580055632) ) ) {
                result[0] += 0.0009745798933893803;
              } else {
                result[0] += -0.00014568071509700724;
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.168079446220334772) ) ) {
              result[0] += -0.0006439385045331951;
            } else {
              result[0] += -0.0005167148336570791;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7269841738944724518) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01896216239618550223) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05227730674148379358) ) ) {
              result[0] += 0.0007065650222597446;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05500000000000000722) ) ) {
                result[0] += -0.0002385640959176486;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.750591121697756835e-06) ) ) {
                  result[0] += -0.00024618340374229407;
                } else {
                  result[0] += 0.0002646221896425639;
                }
              }
            }
          } else {
            result[0] += 0.001736316731420625;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0650000000000000161) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003732500000000000574) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)61.50000000000000711) ) ) {
                result[0] += -0.000618810612010116;
              } else {
                result[0] += -0.000430944790925849;
              }
            } else {
              result[0] += 0.0001470584452333475;
            }
          } else {
            result[0] += 6.346265786680089e-06;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3350000000000000755) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.650000000000000541e-05) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.25500000000000006) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04500000000000000527) ) ) {
              result[0] += -0.0006355084355127266;
            } else {
              result[0] += 0.0005799519918188091;
            }
          } else {
            result[0] += 0.0025339520695306155;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7593447680904524821) ) ) {
            result[0] += 0.002705786451189709;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04528350000000001124) ) ) {
              result[0] += 0.0006812990894043349;
            } else {
              result[0] += 0.0031769235477602828;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5750000000000000666) ) ) {
          result[0] += 0.0056598450511924905;
        } else {
          result[0] += 0.014157554118222858;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.0007777248655194179;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5811189422864322385) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.005393752740946750925) ) ) {
              result[0] += -0.0007863425221205576;
            } else {
              result[0] += -0.0004295216530437448;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
                  result[0] += -0.0009721560728453628;
                } else {
                  result[0] += -0.0009721560728453628;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6010141514957837439) ) ) {
                  result[0] += -0.0009898658304754596;
                } else {
                  result[0] += -0.0010741465552943578;
                }
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)9.765598692199240846e-06) ) ) {
                result[0] += -0.0007578202958797151;
              } else {
                result[0] += -0.0007579283691799124;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.3779290767430908e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -0.0009721560728453628;
                } else {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8068034447989950175) ) ) {
                    result[0] += -0.0009721560728453628;
                  } else {
                    result[0] += -0.0009721560728453628;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7593447680904524821) ) ) {
                  result[0] += -0.0009721560728453628;
                } else {
                  result[0] += -0.0009721560728453628;
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                    result[0] += -0.0009721560728453628;
                  } else {
                    result[0] += -0.0009721560728453628;
                  }
                } else {
                  result[0] += -0.0009721560728453628;
                }
              } else {
                result[0] += -0.0009721560728453628;
              }
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)8.256973923420418294e-06) ) ) {
              result[0] += -0.0010048475537665117;
            } else {
              result[0] += -0.0007087607191017983;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0003825000000000000817) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
            result[0] += -0.0007777248655194179;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)103.5000000000000142) ) ) {
              result[0] += -0.0009806318578600096;
            } else {
              result[0] += -0.000741729220830264;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9567162861906464144) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
              result[0] += 0.001555750974204469;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01437243042433420173) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
                  result[0] += -0.0007683426525793848;
                } else {
                  result[0] += -2.824824868638793e-05;
                }
              } else {
                result[0] += 0.00042845321937786426;
              }
            }
          } else {
            result[0] += -0.0007859893468587944;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08500000000000000611) ) ) {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03500000000000001027) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6468042868844222637) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001149464901271750371) ) ) {
              result[0] += -0.0005652458798136941;
            } else {
              result[0] += -5.974136722621062e-05;
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)244.5000000000000284) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)53.50000000000000711) ) ) {
                result[0] += -0.0008266618838456085;
              } else {
                result[0] += -0.0005807912152712531;
              }
            } else {
              result[0] += -0.0008422220694655718;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002835000000000000605) ) ) {
            result[0] += -0.0005742907232569722;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
              result[0] += -0.0001340849085174399;
            } else {
              result[0] += 0.000690020989989457;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007698000000000000849) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05500000000000000722) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7269841738944724518) ) ) {
              result[0] += -0.00010120003880307942;
            } else {
              result[0] += -0.00047720930570188436;
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05227730674148379358) ) ) {
              result[0] += 0.0010411040903485008;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.115000000000000005) ) ) {
                result[0] += -4.913163270458676e-05;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)151.5000000000000284) ) ) {
                  result[0] += 0.0006660369454427937;
                } else {
                  result[0] += -9.839311018458455e-05;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05530450000000000643) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7293938685427137081) ) ) {
              result[0] += 0.0012726733875304207;
            } else {
              result[0] += -0.00013803925524816303;
            }
          } else {
            result[0] += 0.0015907856590743562;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3550000000000000377) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.650000000000000541e-05) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2450000000000000233) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7211604863065327331) ) ) {
              result[0] += 0.0007556934272752063;
            } else {
              result[0] += -5.0082519293047696e-05;
            }
          } else {
            result[0] += 0.0025257441770006875;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7573260829648241765) ) ) {
            result[0] += 0.00292540831971637;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02085144663384500344) ) ) {
              result[0] += 0.0007210692651779797;
            } else {
              result[0] += 0.00291703396928227;
            }
          }
        }
      } else {
        result[0] += 0.011859036511983181;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.000744717215579445;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.568345700351758909) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.005393752740946750925) ) ) {
              result[0] += -0.0007529691276801779;
            } else {
              result[0] += -0.00041129219813768655;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4677590045467516222) ) ) {
                  result[0] += -0.0009308965108046563;
                } else {
                  result[0] += -0.0009308965108046563;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6010141514957837439) ) ) {
                  result[0] += -0.0009478546433983264;
                } else {
                  result[0] += -0.0010285583851672466;
                }
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.341544232904992332e-05) ) ) {
                result[0] += -0.0007263634872174106;
              } else {
                result[0] += -0.0007257609081681614;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.3779290767430908e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -0.0009308965108046563;
                } else {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8068034447989950175) ) ) {
                    result[0] += -0.0009308965108046563;
                  } else {
                    result[0] += -0.0009308965108046563;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7593447680904524821) ) ) {
                  result[0] += -0.0009308965108046563;
                } else {
                  result[0] += -0.0009308965108046563;
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                    result[0] += -0.0009308965108046563;
                  } else {
                    result[0] += -0.0009308965108046563;
                  }
                } else {
                  result[0] += -0.0009308965108046563;
                }
              } else {
                result[0] += -0.0009308965108046563;
              }
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)8.256973923420418294e-06) ) ) {
              result[0] += -0.000962200522961329;
            } else {
              result[0] += -0.0006786799967994566;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
            result[0] += -0.000744717215579445;
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)131.5000000000000284) ) ) {
              result[0] += -0.0007428918669701448;
            } else {
              result[0] += -0.000950889194408728;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9567162861906464144) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
              result[0] += 0.0012951542446689869;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01344341525633075199) ) ) {
                  result[0] += -0.0007533636674387905;
                } else {
                  result[0] += 8.461765180311949e-06;
                }
              } else {
                result[0] += 0.0012107199368622877;
              }
            }
          } else {
            result[0] += -0.0007526309416336559;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08500000000000000611) ) ) {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03500000000000001027) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6468042868844222637) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001149464901271750371) ) ) {
              result[0] += -0.0005412561130490149;
            } else {
              result[0] += -5.7205866274956965e-05;
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)244.5000000000000284) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)53.50000000000000711) ) ) {
                result[0] += -0.000791577283506296;
              } else {
                result[0] += -0.0005561416843486668;
              }
            } else {
              result[0] += -0.0008064770747082387;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002835000000000000605) ) ) {
            result[0] += -0.0005499170816293769;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
              result[0] += -0.00012839417144730505;
            } else {
              result[0] += 0.0006607356060463911;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007698000000000000849) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0650000000000000161) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7211604863065327331) ) ) {
              result[0] += -7.304054391471214e-05;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)51.50000000000000711) ) ) {
                result[0] += -0.0005291021148560351;
              } else {
                result[0] += -0.0003437534468272905;
              }
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05227730674148379358) ) ) {
              result[0] += 0.0010964697253401628;
            } else {
              result[0] += 6.61029026938378e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05530450000000000643) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7293938685427137081) ) ) {
              result[0] += 0.0012186594816802228;
            } else {
              result[0] += -0.000132180690584472;
            }
          } else {
            result[0] += 0.001523270656671563;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3850000000000000644) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.650000000000000541e-05) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2450000000000000233) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7211604863065327331) ) ) {
              result[0] += 0.0007073375703133446;
            } else {
              result[0] += -3.587978506944612e-05;
            }
          } else {
            result[0] += 0.0024413896194306482;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7573260829648241765) ) ) {
            result[0] += 0.002858510419518707;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02085144663384500344) ) ) {
              result[0] += 0.000785356558495505;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00357950000000000065) ) ) {
                result[0] += 0.0013190282187357904;
              } else {
                result[0] += 0.0036637433469317924;
              }
            }
          }
        }
      } else {
        result[0] += 0.012204548730158353;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.0007131104530263402;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.568345700351758909) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.005393752740946750925) ) ) {
              result[0] += -0.0007210121432966646;
            } else {
              result[0] += -0.0003938364248931164;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4677590045467516222) ) ) {
                  result[0] += -0.0008913880579812265;
                } else {
                  result[0] += -0.0008913880579812265;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6010141514957837439) ) ) {
                  result[0] += -0.0009076264654778808;
                } else {
                  result[0] += -0.000984905035987328;
                }
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.341544232904992332e-05) ) ) {
                result[0] += -0.0006955356806521187;
              } else {
                result[0] += -0.0006949586758376673;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.3779290767430908e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -0.0008913880579812265;
                } else {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8068034447989950175) ) ) {
                    result[0] += -0.0008913880579812265;
                  } else {
                    result[0] += -0.0008913880579812265;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7593447680904524821) ) ) {
                  result[0] += -0.0008913880579812265;
                } else {
                  result[0] += -0.0008913880579812265;
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                    result[0] += -0.0008913880579812265;
                  } else {
                    result[0] += -0.0008913880579812265;
                  }
                } else {
                  result[0] += -0.0008913880579812265;
                }
              } else {
                result[0] += -0.0008913880579812265;
              }
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)8.256973923420418294e-06) ) ) {
              result[0] += -0.000921363487343656;
            } else {
              result[0] += -0.0006498759392865763;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
            result[0] += -0.0007131104530263402;
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)131.5000000000000284) ) ) {
              result[0] += -0.0007113625745746567;
            } else {
              result[0] += -0.0009105322262156331;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9567162861906464144) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
              result[0] += 0.0012401862221437555;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01344341525633075199) ) ) {
                  result[0] += -0.0007213899382772495;
                } else {
                  result[0] += 8.102636913583046e-06;
                }
              } else {
                result[0] += 0.0011593354156478263;
              }
            }
          } else {
            result[0] += -0.0007206883103036876;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08500000000000000611) ) ) {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03500000000000001027) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7573260829648241765) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004873500000000000228) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
                result[0] += -0.0007566465353401149;
              } else {
                result[0] += -0.00040566239485406643;
              }
            } else {
              result[0] += -1.7741402717285136e-05;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.168079446220334772) ) ) {
              result[0] += -0.0007667881692724275;
            } else {
              result[0] += -0.000668879835255912;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002835000000000000605) ) ) {
            result[0] += -0.0005265778889004533;
          } else {
            result[0] += 0.00025066998464393883;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007698000000000000849) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0650000000000000161) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7211604863065327331) ) ) {
              result[0] += -6.994060869102353e-05;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)51.50000000000000711) ) ) {
                result[0] += -0.0005066463362588013;
              } else {
                result[0] += -0.0003291641056070423;
              }
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05227730674148379358) ) ) {
              result[0] += 0.0010499341309823367;
            } else {
              result[0] += 6.329740994329166e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04770400000000000335) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
              result[0] += 0.000955677348934582;
            } else {
              result[0] += -0.00020789469688233133;
            }
          } else {
            result[0] += 0.0014544095594721115;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3850000000000000644) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.007190624686192600631) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3150000000000000577) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7211604863065327331) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
                result[0] += 0.0009153455741894079;
              } else {
                result[0] += 0.0014406377049809755;
              }
            } else {
              result[0] += 0.0003491030693662874;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7593447680904524821) ) ) {
              result[0] += 0.0027680113604442716;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001570360081376600365) ) ) {
                result[0] += 0.002391794933773685;
              } else {
                result[0] += -0.00023611888986944504;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9194299814036738239) ) ) {
            result[0] += 0.0033771281711693904;
          } else {
            result[0] += 0.0018246426816317832;
          }
        }
      } else {
        result[0] += 0.011686571885106136;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.0006828451223861676;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.568345700351758909) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.005393752740946750925) ) ) {
              result[0] += -0.0006904114546938753;
            } else {
              result[0] += -0.00037712149725890697;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4677590045467516222) ) ) {
                  result[0] += -0.0008535563950333456;
                } else {
                  result[0] += -0.0008535563950333456;
                }
              } else {
                result[0] += -0.000869105623497677;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.341544232904992332e-05) ) ) {
                result[0] += -0.0006660162460993955;
              } else {
                result[0] += -0.000665463730116115;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.3779290767430908e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                  result[0] += -0.0008535563950333456;
                } else {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8068034447989950175) ) ) {
                    result[0] += -0.0008535563950333456;
                  } else {
                    result[0] += -0.0008535563950333456;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7593447680904524821) ) ) {
                  result[0] += -0.0008535563950333456;
                } else {
                  result[0] += -0.0008535563950333456;
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
                    result[0] += -0.0008535563950333456;
                  } else {
                    result[0] += -0.0008535563950333456;
                  }
                } else {
                  result[0] += -0.0008535563950333456;
                }
              } else {
                result[0] += -0.0008535563950333456;
              }
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)8.256973923420418294e-06) ) ) {
              result[0] += -0.0008822596283749695;
            } else {
              result[0] += -0.0006222943632570431;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
            result[0] += -0.0006828451223861676;
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)131.5000000000000284) ) ) {
              result[0] += -0.0006811714261583383;
            } else {
              result[0] += -0.0008718880599886509;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9567162861906464144) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
              result[0] += 0.0011875511136422948;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01344341525633075199) ) ) {
                  result[0] += -0.0006907732155664857;
                } else {
                  result[0] += 7.758750515331399e-06;
                }
              } else {
                result[0] += 0.0011101317200232059;
              }
            }
          } else {
            result[0] += -0.0006901013655922733;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09500000000000001499) ) ) {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03500000000000001027) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7573260829648241765) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004873500000000000228) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
                result[0] += -0.0007245334770156652;
              } else {
                result[0] += -0.00038844555774778287;
              }
            } else {
              result[0] += -1.698843462239837e-05;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.168079446220334772) ) ) {
              result[0] += -0.0007342446868770777;
            } else {
              result[0] += -0.000640491709283768;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002835000000000000605) ) ) {
            result[0] += -0.0004995823191539897;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.04500000000000000527) ) ) {
              result[0] += -3.3308021024530546e-05;
            } else {
              result[0] += 0.0015561943611622929;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007698000000000000849) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0650000000000000161) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7211604863065327331) ) ) {
              result[0] += -6.696203335759262e-05;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)49.50000000000000711) ) ) {
                result[0] += -0.0004858267788477797;
              } else {
                result[0] += -0.00031037733193429177;
              }
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05227730674148379358) ) ) {
              result[0] += 0.0010239501799794457;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
                result[0] += -0.00025520673906613296;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.115000000000000005) ) ) {
                  result[0] += -6.541460084531176e-06;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)191.5000000000000284) ) ) {
                    result[0] += 0.0007523056878607539;
                  } else {
                    result[0] += -0.0001129750721700185;
                  }
                }
              }
            }
          }
        } else {
          result[0] += 0.0008108774733663766;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3850000000000000644) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.007190624686192600631) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3150000000000000577) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)93.50000000000001421) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.640890220251256415) ) ) {
                result[0] += 0.0009184609531080856;
              } else {
                result[0] += -0.00010741689819573617;
              }
            } else {
              result[0] += 0.0014567039078923474;
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)372.5000000000000568) ) ) {
              result[0] += 0.002627314657318827;
            } else {
              result[0] += 0.0006490529671292727;
            }
          }
        } else {
          result[0] += 0.0029859308683554218;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6650000000000001465) ) ) {
          result[0] += 0.004814936069004418;
        } else {
          result[0] += 0.013312643871185649;
        }
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.0006538642915522615;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6249533869346735049) ) ) {
                result[0] += -0.0008173303568283443;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4840806222471906728) ) ) {
                  result[0] += -0.0008173303568283443;
                } else {
                  result[0] += -0.0008173303568283443;
                }
              }
            } else {
              result[0] += -0.0006372205880677361;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6152470170603016042) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.005393752740946750925) ) ) {
                result[0] += -0.0006611094989233562;
              } else {
                result[0] += -0.0003611159727884416;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)53.50000000000000711) ) ) {
                result[0] += -0.0008322196559105228;
              } else {
                result[0] += -0.0008124926313815207;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.85801459308964273e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9993516786272610419) ) ) {
                  result[0] += -0.0008173303568283443;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.256922594654586334) ) ) {
                    result[0] += -0.0008173303568283443;
                  } else {
                    result[0] += -0.0008173303568283443;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.002492780962593150584) ) ) {
                    result[0] += -0.0008173303568283443;
                  } else {
                    result[0] += -0.0008173303568283443;
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)114.5000000000000142) ) ) {
                    result[0] += -0.0008173303568283443;
                  } else {
                    result[0] += -0.0008173303568283443;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)86.50000000000001421) ) ) {
                    result[0] += -0.0008173303568283443;
                  } else {
                    result[0] += -0.0008173303568283443;
                  }
                } else {
                  result[0] += -0.0008173303568283443;
                }
              } else {
                result[0] += -0.0008173303568283443;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.247314011309283543) ) ) {
              result[0] += -0.0005958833850143859;
            } else {
              result[0] += -0.0008309296268263713;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0003825000000000000817) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
            result[0] += -0.0006538642915522615;
          } else {
            result[0] += -0.0007501688501765465;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9567162861906464144) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5494686760804020631) ) ) {
              result[0] += 0.0009166722437592108;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01154850000000000147) ) ) {
                result[0] += -0.00033931726939431784;
              } else {
                result[0] += 1.1036259345153301e-05;
              }
            }
          } else {
            result[0] += -0.0006608125704045897;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09500000000000001499) ) ) {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04500000000000000527) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)351.5000000000000568) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004873500000000000228) ) ) {
                result[0] += -0.00042626044070467455;
              } else {
                result[0] += -3.821432374196274e-05;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)52.50000000000000711) ) ) {
                result[0] += -0.0006989604808437603;
              } else {
                result[0] += -0.0003990689094929454;
              }
            }
          } else {
            result[0] += -0.0007069581828653186;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002835000000000000605) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.741363993241206054) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.439120857165606282) ) ) {
                result[0] += -0.00035281013396045916;
              } else {
                result[0] += 0.0001276296350658612;
              }
            } else {
              result[0] += -0.0004882225076254781;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.03588532983514210878) ) ) {
              result[0] += 0.0010569970711453405;
            } else {
              result[0] += 9.44026601850823e-06;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0159540000000000029) ) ) {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05227730674148379358) ) ) {
            result[0] += 0.0008231086362297253;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.115000000000000005) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.0650000000000000161) ) ) {
                result[0] += -0.0001160993360356019;
              } else {
                result[0] += 0.0002877324346348081;
              }
            } else {
              result[0] += 0.000433000423766892;
            }
          }
        } else {
          result[0] += 0.0010902129213791506;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4650000000000000244) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.002492780962593150584) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3150000000000000577) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)93.50000000000001421) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6511828695477387408) ) ) {
                result[0] += 0.0008163491675889936;
              } else {
                result[0] += -0.00031416655268086245;
              }
            } else {
              result[0] += 0.0013524533669119446;
            }
          } else {
            result[0] += 0.0026289210486510756;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
            result[0] += 0.0031050649978932327;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2250000000000000333) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.007190624686192600631) ) ) {
                result[0] += -0.00035804564418422596;
              } else {
                result[0] += 0.0012341059080525863;
              }
            } else {
              result[0] += 0.0026324005785908545;
            }
          }
        }
      } else {
        result[0] += 0.012747638034086501;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.000626113444690253;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
              result[0] += -0.0007826417985738964;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
                result[0] += -0.0007826417985738964;
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                  result[0] += -0.0007826417985738964;
                } else {
                  result[0] += -0.0007826417985738964;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6152470170603016042) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.005393752740946750925) ) ) {
                result[0] += -0.0006330511560826923;
              } else {
                result[0] += -0.00034578974349323583;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)53.50000000000000711) ) ) {
                result[0] += -0.000796899176531079;
              } else {
                result[0] += -0.0007780093924567405;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.85801459308964273e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9993516786272610419) ) ) {
                  result[0] += -0.0007826417985738964;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.256922594654586334) ) ) {
                    result[0] += -0.0007826417985738964;
                  } else {
                    result[0] += -0.0007826417985738964;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.002492780962593150584) ) ) {
                    result[0] += -0.0007826417985738964;
                  } else {
                    result[0] += -0.0007826417985738964;
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)114.5000000000000142) ) ) {
                    result[0] += -0.0007826417985738964;
                  } else {
                    result[0] += -0.0007826417985738964;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)86.50000000000001421) ) ) {
                    result[0] += -0.0007826417985738964;
                  } else {
                    result[0] += -0.0007826417985738964;
                  }
                } else {
                  result[0] += -0.0007826417985738964;
                }
              } else {
                result[0] += -0.0007826417985738964;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.247314011309283543) ) ) {
              result[0] += -0.0005705933228733679;
            } else {
              result[0] += -0.0007956638979510068;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0003825000000000000817) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
            result[0] += -0.000626113444690253;
          } else {
            result[0] += -0.0007183307131948234;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9567162861906464144) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5143309380402011355) ) ) {
              result[0] += 0.0013187907896761504;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01154850000000000147) ) ) {
                  result[0] += -0.0006294244473762813;
                } else {
                  result[0] += 3.715380313326793e-06;
                }
              } else {
                result[0] += 0.0011418360120737056;
              }
            }
          } else {
            result[0] += -0.0006327668295945914;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2050000000000000433) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03500000000000001027) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7573260829648241765) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005862500000000000523) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
                result[0] += -0.0006006826160980417;
              } else {
                result[0] += -0.00035792927933768015;
              }
            } else {
              result[0] += 2.2714674926362526e-06;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7948036090201006099) ) ) {
              result[0] += -0.0006699775401573211;
            } else {
              result[0] += -0.0005038847838515556;
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)356.5000000000000568) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1250000000000000278) ) ) {
              result[0] += -0.00011840967791019033;
            } else {
              result[0] += 0.0013545902253552823;
            }
          } else {
            result[0] += -0.0007349225471522723;
          }
        }
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5811189422864322385) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01289050000000000092) ) ) {
            result[0] += 0.0009020445930412065;
          } else {
            result[0] += 0.0031754302260706296;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01639055436850350364) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04500000000000000527) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)149.5000000000000284) ) ) {
                  result[0] += -0.0005775054322983846;
                } else {
                  result[0] += -0.00013852023201678425;
                }
              } else {
                result[0] += 0.0002833610393967304;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)43.50000000000000711) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9194299814036738239) ) ) {
                  result[0] += 0.00011253947094132735;
                } else {
                  result[0] += -0.0004633605033042519;
                }
              } else {
                result[0] += 0.0003909181055751953;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.213351496714494937) ) ) {
              result[0] += 0.0016086061686104867;
            } else {
              result[0] += 0.00012812698621117793;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4950000000000000511) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0003617856423802000786) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.25500000000000006) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.08390973343508316418) ) ) {
              result[0] += -0.0004358736050989265;
            } else {
              result[0] += 0.00048423824681880244;
            }
          } else {
            result[0] += 0.002833585960665502;
          }
        } else {
          result[0] += 0.0034091915955952023;
        }
      } else {
        result[0] += 0.01305543938320147;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.0005995403796883466;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6249533869346735049) ) ) {
                result[0] += -0.0007494254676308645;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4840806222471906728) ) ) {
                  result[0] += -0.0007494254676308645;
                } else {
                  result[0] += -0.0007494254676308645;
                }
              }
            } else {
              result[0] += -0.0005769597905813385;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5492268452512564236) ) ) {
              result[0] += -0.0006061836456294716;
            } else {
              result[0] += -0.0007449896668252704;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.85801459308964273e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9993516786272610419) ) ) {
                  result[0] += -0.0007494254676308645;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.256922594654586334) ) ) {
                    result[0] += -0.0007494254676308645;
                  } else {
                    result[0] += -0.0007494254676308645;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.002492780962593150584) ) ) {
                    result[0] += -0.0007494254676308645;
                  } else {
                    result[0] += -0.0007494254676308645;
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)114.5000000000000142) ) ) {
                    result[0] += -0.0007494254676308645;
                  } else {
                    result[0] += -0.0007494254676308645;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)86.50000000000001421) ) ) {
                    result[0] += -0.0007494254676308645;
                  } else {
                    result[0] += -0.0007494254676308645;
                  }
                } else {
                  result[0] += -0.0007494254676308645;
                }
              } else {
                result[0] += -0.0007494254676308645;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7683067979899498301) ) ) {
              result[0] += -0.000546376603703779;
            } else {
              result[0] += -0.0006058962944591886;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0003825000000000000817) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7471533970100503463) ) ) {
            result[0] += -0.000532658808769089;
          } else {
            result[0] += -0.000772558979975092;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9567162861906464144) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
              result[0] += 0.001236842607171376;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0148413130503959028) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
                  result[0] += -0.0005665016863105254;
                } else {
                  result[0] += -2.1393124672220396e-05;
                }
              } else {
                result[0] += 0.0003730893518186189;
              }
            }
          } else {
            result[0] += -0.0006059113863255434;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2650000000000000688) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03500000000000001027) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3872449054220527542) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
              result[0] += -0.0005106219828420606;
            } else {
              result[0] += 3.0459966467314586e-05;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += -0.000635860321956916;
            } else {
              result[0] += -0.00041036671745959315;
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)356.5000000000000568) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1250000000000000278) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.08110515786938453375) ) ) {
                result[0] += 0.00026381022026989516;
              } else {
                result[0] += -0.0002044346404643025;
              }
            } else {
              result[0] += 0.0012648761484022415;
            }
          } else {
            result[0] += -0.000703731483004935;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0009875000000000003133) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05500000000000000722) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7403451809045227261) ) ) {
              result[0] += -0.00010198056680287693;
            } else {
              result[0] += -0.00040942758488797217;
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)91.50000000000001421) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.322824821631954977e-06) ) ) {
                result[0] += -0.00047293465571389637;
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5826692266582915725) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1550000000000000266) ) ) {
                    result[0] += 0.0008279372460557934;
                  } else {
                    result[0] += 2.623231493909915e-05;
                  }
                } else {
                  result[0] += -5.288162240667595e-05;
                }
              }
            } else {
              result[0] += 0.0006162675838488829;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.714286561348693172) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04125550000000000744) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
                result[0] += 0.002550618693594976;
              } else {
                result[0] += 0.0010316871809316445;
              }
            } else {
              result[0] += 0.004159484057995988;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05686650000000000732) ) ) {
              result[0] += 0.00019526829760389394;
            } else {
              result[0] += 0.0014676591654989182;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5250000000000001332) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2750000000000000777) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004773500000000000833) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5826692266582915725) ) ) {
              result[0] += 0.0022794587364845784;
            } else {
              result[0] += 0.0008142275993444003;
            }
          } else {
            result[0] += 0.002410118551829279;
          }
        } else {
          result[0] += 0.0038459378979614866;
        }
      } else {
        result[0] += 0.012925762176222053;
      }
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.0005740951099599387;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6249533869346735049) ) ) {
                result[0] += -0.0007176188807665765;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4840806222471906728) ) ) {
                  result[0] += -0.0007176188807665765;
                } else {
                  result[0] += -0.0007176188807665765;
                }
              }
            } else {
              result[0] += -0.0005524728702817927;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5492268452512564236) ) ) {
              result[0] += -0.0005804564270958183;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01439950000000000084) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.439120857165606282) ) ) {
                  result[0] += -0.0007314594182768982;
                } else {
                  result[0] += -0.0004977212767984518;
                }
              } else {
                result[0] += -0.0005093513834556379;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.85801459308964273e-06) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9993516786272610419) ) ) {
                  result[0] += -0.0007176188807665765;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.256922594654586334) ) ) {
                    result[0] += -0.0007176188807665765;
                  } else {
                    result[0] += -0.0007176188807665765;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.002492780962593150584) ) ) {
                    result[0] += -0.0007176188807665765;
                  } else {
                    result[0] += -0.0007176188807665765;
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)114.5000000000000142) ) ) {
                    result[0] += -0.0007176188807665765;
                  } else {
                    result[0] += -0.0007176188807665765;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)86.50000000000001421) ) ) {
                    result[0] += -0.0007176188807665765;
                  } else {
                    result[0] += -0.0007176188807665765;
                  }
                } else {
                  result[0] += -0.0007176188807665765;
                }
              } else {
                result[0] += -0.0007176188807665765;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.247314011309283543) ) ) {
              result[0] += -0.0005231876734406313;
            } else {
              result[0] += -0.0007361798692772165;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0003825000000000000817) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7471533970100503463) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
              result[0] += -0.00057693365039784;
            } else {
              result[0] += -0.00042381967181383105;
            }
          } else {
            result[0] += -0.0007397705769040786;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9567162861906464144) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5494686760804020631) ) ) {
                result[0] += 0.0005704470124577103;
              } else {
                result[0] += -0.0002502651996028944;
              }
            } else {
              result[0] += 0.0018578395263560774;
            }
          } else {
            result[0] += -0.0005801957228291474;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2050000000000000433) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05500000000000000722) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05530450000000000643) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5927985607788945899) ) ) {
                result[0] += -0.00010904254239955722;
              } else {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6571412079648242255) ) ) {
                  result[0] += -0.0004216881900431322;
                } else {
                  result[0] += -9.2049534357178e-05;
                }
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
                  result[0] += -0.0006168152099428138;
                } else {
                  result[0] += -0.0004892369898793248;
                }
              } else {
                result[0] += -0.0003757218299471702;
              }
            }
          } else {
            result[0] += 0.0005282114748836838;
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)189.5000000000000284) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1250000000000000278) ) ) {
              result[0] += 4.0304542345124254e-05;
            } else {
              result[0] += 0.001243416681949578;
            }
          } else {
            result[0] += -0.0006797090548046157;
          }
        }
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5811189422864322385) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01289050000000000092) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.750591121697756835e-06) ) ) {
              result[0] += 8.525140462758667e-05;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4795364038944723295) ) ) {
                result[0] += 0.0018975931737082543;
              } else {
                result[0] += 0.00068273090664832;
              }
            }
          } else {
            result[0] += 0.002943953941179722;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01461911667849610276) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04500000000000000527) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)51.50000000000000711) ) ) {
                result[0] += -0.0005393681188495898;
              } else {
                result[0] += -4.650742673705238e-05;
              }
            } else {
              result[0] += 0.0001789976609492314;
            }
          } else {
            result[0] += 0.001113849209689912;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5250000000000001332) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002835000000000000605) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.25500000000000006) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5458973873869347182) ) ) {
              result[0] += -0.00047145203380914025;
            } else {
              result[0] += 0.0004434528884580871;
            }
          } else {
            result[0] += 0.0028079190611056694;
          }
        } else {
          result[0] += 0.00328351334513594;
        }
      } else {
        result[0] += 0.012377176099017059;
      }
    }
  }
}

