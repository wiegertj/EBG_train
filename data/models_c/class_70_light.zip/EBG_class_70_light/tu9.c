
#include "header.h"

void predict_unit9(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7291204255332855988) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3959052786231780918) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2252442705517153365) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1076279909068390134) ) ) {
          result[0] += -0.06751369238964831;
        } else {
          result[0] += -0.05791158460767774;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)2.800000000000000297e-05) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03500000000000001027) ) ) {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.07624899563451974227) ) ) {
              result[0] += -0.02114101324703754;
            } else {
              result[0] += 0.0515083064494882;
            }
          } else {
            result[0] += -0.03457001579870824;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9808239647505231362) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01151050000000000163) ) ) {
                result[0] += -0.05146349954497035;
              } else {
                result[0] += -0.03393407640376172;
              }
            } else {
              result[0] += 0.009242295667757361;
            }
          } else {
            result[0] += -0.059715149795335834;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5629295393739166542) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4747086856097625374) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2198326728482087045) ) ) {
            result[0] += -0.012045342656279524;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002721500000000000394) ) ) {
              result[0] += -0.0458257383046818;
            } else {
              result[0] += -0.027870009061698054;
            }
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2783343642141558605) ) ) {
            result[0] += -0.009553688379016765;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004411500000000001358) ) ) {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.7531933740031299118) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3950000000000000733) ) ) {
                  result[0] += -0.04732379390393586;
                } else {
                  result[0] += 0.037486297718610485;
                }
              } else {
                result[0] += -0.032114920592093726;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005176500000000001413) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.545000000000000151) ) ) {
                  result[0] += 0.048095238037385434;
                } else {
                  result[0] += -0.021590849704329125;
                }
              } else {
                result[0] += -0.019677591799456714;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6741462157421617141) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3050000000000000488) ) ) {
            result[0] += 0.010330965146269681;
          } else {
            result[0] += -0.007539925505924718;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6050000000000000933) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9150000000000001465) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4350000000000000533) ) ) {
                result[0] += 0.019128702130923585;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009910500000000000906) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.545000000000000151) ) ) {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006832500000000000899) ) ) {
                      result[0] += 0.08713582924952613;
                    } else {
                      result[0] += 0.01807787491521929;
                    }
                  } else {
                    result[0] += 0.003757054487659369;
                  }
                } else {
                  result[0] += -0.008795310937770702;
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5950000000000000844) ) ) {
                result[0] += 0.03346792878992966;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1577417356873818399) ) ) {
                  result[0] += 0.04151319942106211;
                } else {
                  result[0] += -0.03856932725999453;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8290814278894472755) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.786764172562814168) ) ) {
                result[0] += -0.004393299308982101;
              } else {
                result[0] += -0.05143886316457469;
              }
            } else {
              result[0] += 0.04087892241500845;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6800585241488680266) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8319474009675894566) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)2.800000000000000297e-05) ) ) {
          result[0] += 0.040024913492339526;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001376500000000000336) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.104347816094000123) ) ) {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5357646220388291303) ) ) {
                result[0] += -0.03725615073842916;
              } else {
                result[0] += 0.009868395523495214;
              }
            } else {
              result[0] += -0.05119429481005175;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8054659791206031372) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6153161284426161837) ) ) {
                result[0] += 0.01159509200527265;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01683850000000000277) ) ) {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1043955180426469898) ) ) {
                    result[0] += 0.04192001182104021;
                  } else {
                    result[0] += 0.020381862524793553;
                  }
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6850000000000001643) ) ) {
                    result[0] += 0.015743120305877358;
                  } else {
                    result[0] += -0.0707700287170679;
                  }
                }
              }
            } else {
              result[0] += 0.042560721776467116;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5519124520502908249) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5750000000000000666) ) ) {
            result[0] += 0.053654565781145275;
          } else {
            result[0] += 0.010322762220129147;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9350000000000001643) ) ) {
            result[0] += 0.04362676998230612;
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6260154606475681893) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8350000000000000755) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1218810000000000032) ) ) {
                  result[0] += 0.024776610453491946;
                } else {
                  result[0] += -0.06990237464623868;
                }
              } else {
                result[0] += -0.04875672424423667;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8450000000000000844) ) ) {
                result[0] += 0.0406669472603275;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9088377208529384577) ) ) {
                  result[0] += -0.03647451137075527;
                } else {
                  result[0] += 0.027589882341848115;
                }
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8373354933349520524) ) ) {
        result[0] += 0.05499906075303368;
      } else {
        result[0] += 0.06908484601053892;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7291204255332855988) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3959052786231780918) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2252442705517153365) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1076279909068390134) ) ) {
          result[0] += -0.06710004063183957;
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3321712357788945136) ) ) {
            result[0] += 0.024038290641964576;
          } else {
            result[0] += -0.05751290184626099;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)2.800000000000000297e-05) ) ) {
          result[0] += -0.03149269999521363;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01151050000000000163) ) ) {
              result[0] += -0.0495398519954011;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6784611311055277483) ) ) {
                result[0] += -0.03617894046817832;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6800105846231156992) ) ) {
                  result[0] += 0.10669760767379;
                } else {
                  result[0] += -0.015780532906727925;
                }
              }
            }
          } else {
            result[0] += -0.05878158868536142;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5395439842637465011) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4850000000000000422) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4976396106036372058) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2108884567369299912) ) ) {
              result[0] += -0.015216461908723108;
            } else {
              result[0] += -0.03117234352840286;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1800900000000000278) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1119750000000000051) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6425364825628142595) ) ) {
                  result[0] += -0.015820971614960704;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4143094250104821241) ) ) {
                    result[0] += 0.07400538146105037;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5265509790734695938) ) ) {
                      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.254805794918683326) ) ) {
                        result[0] += 0.05038244548878989;
                      } else {
                        result[0] += -0.02775439280493838;
                      }
                    } else {
                      result[0] += 0.04284236321851129;
                    }
                  }
                }
              } else {
                result[0] += -0.06928660183112335;
              }
            } else {
              result[0] += 0.06937273737503151;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004677500000000000234) ) ) {
            result[0] += -0.042564517495467746;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7002474625125628682) ) ) {
                result[0] += -0.016843954763428433;
              } else {
                result[0] += 0.030509723754201436;
              }
            } else {
              result[0] += -0.04509663983918924;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.625707420288709959) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2669585275879397535) ) ) {
              result[0] += 0.05991504265855999;
            } else {
              result[0] += -0.001016864449475259;
            }
          } else {
            result[0] += -0.013042972963418465;
          }
        } else {
          result[0] += 0.0005430027277369766;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6800585241488680266) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8319474009675894566) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)2.800000000000000297e-05) ) ) {
          result[0] += 0.038048196566298716;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001376500000000000336) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.104347816094000123) ) ) {
              result[0] += 0.00703285010494461;
            } else {
              result[0] += -0.04755154133713491;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8054659791206031372) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5894867046835161606) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002122500000000000688) ) ) {
                  result[0] += -0.035055921459199516;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.966590843157139501) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.70902182859296492) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6828811456281408399) ) ) {
                        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.427277195418813982) ) ) {
                          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03588532983514210878) ) ) {
                            result[0] += 0.017189773823129143;
                          } else {
                            result[0] += 0.06400836579156008;
                          }
                        } else {
                          result[0] += 0.007647788993951794;
                        }
                      } else {
                        result[0] += -0.06448060291347776;
                      }
                    } else {
                      result[0] += 0.04503696541514966;
                    }
                  } else {
                    result[0] += -0.022101318842272163;
                  }
                }
              } else {
                result[0] += 0.02035973934037408;
              }
            } else {
              result[0] += 0.04049319318086324;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3746200112814070393) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.0255377885186947;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009356500000000001968) ) ) {
              result[0] += -0.03178041170301789;
            } else {
              result[0] += 0.02639833949258085;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9088377208529384577) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8450000000000000844) ) ) {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6173059481599049159) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8150000000000000577) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8898401904750864455) ) ) {
                    result[0] += 0.019166410716530635;
                  } else {
                    result[0] += 0.0540221033925221;
                  }
                } else {
                  result[0] += -0.06373820797472565;
                }
              } else {
                result[0] += 0.03982228324266141;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01195850000000000211) ) ) {
                result[0] += 0.017702060517793175;
              } else {
                result[0] += -0.07413183077895516;
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8650000000000001021) ) ) {
              result[0] += 0.04670261266829041;
            } else {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6480386193895394387) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5392445599497488473) ) ) {
                  result[0] += -0.08017611141611693;
                } else {
                  result[0] += 0.010656970724141412;
                }
              } else {
                result[0] += 0.0377949643334442;
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7994052243814134817) ) ) {
        result[0] += 0.05170849886895063;
      } else {
        result[0] += 0.06747548836865615;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7074300481310827893) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3768882457614676773) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1887226699691260667) ) ) {
        result[0] += -0.06379953504096637;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)2.800000000000000297e-05) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3288621490399925573) ) ) {
            result[0] += -0.03786667793478459;
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1248769030900628435) ) ) {
              result[0] += 0.0070728511351692315;
            } else {
              result[0] += -0.032848749859934995;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
            result[0] += -0.00530694915507642;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2656063113060950776) ) ) {
              result[0] += -0.059812224156216856;
            } else {
              result[0] += -0.044824566666169095;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5395439842637465011) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4850000000000000422) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4747086856097625374) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1764963302915136534) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3457619648241206378) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1996047352047869705) ) ) {
                  result[0] += 0.0012023221883280114;
                } else {
                  result[0] += 0.1435882082128779;
                }
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.08500000000000000611) ) ) {
                  result[0] += -0.0455583702729275;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09500000000000001499) ) ) {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1803537653079417269) ) ) {
                      result[0] += 0.10872777584100857;
                    } else {
                      result[0] += -0.0038150831449341917;
                    }
                  } else {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1693967519290585366) ) ) {
                      result[0] += -0.052429372725487346;
                    } else {
                      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1923733477048955032) ) ) {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4005412190101058645) ) ) {
                          result[0] += -0.01642063471904789;
                        } else {
                          result[0] += 0.030783100648676422;
                        }
                      } else {
                        result[0] += -0.01906722357813586;
                      }
                    }
                  }
                }
              }
            } else {
              result[0] += -0.030668141961753225;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2055020000000000457) ) ) {
              result[0] += -0.012966169801729635;
            } else {
              result[0] += 0.05500792473412531;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004677500000000000234) ) ) {
            result[0] += -0.041907166994916284;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -0.005119674741299105;
            } else {
              result[0] += -0.04273688669336792;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6095226520848766594) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4250000000000000444) ) ) {
            result[0] += -0.005591524669111824;
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4668057837619645212) ) ) {
              result[0] += -0.021713226305475102;
            } else {
              result[0] += 0.014064034399598661;
            }
          }
        } else {
          result[0] += -0.0012518468882548473;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6800585241488680266) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8207002514789815129) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6445926074073893286) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)2.800000000000000297e-05) ) ) {
            result[0] += 0.03127524438879849;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0006475000000000001804) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6750000000000001554) ) ) {
                result[0] += 0.006631216937055985;
              } else {
                result[0] += -0.03440843784563429;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0007245000000000001005) ) ) {
                result[0] += 0.05347871347853525;
              } else {
                if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5627530554421374953) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4950000000000000511) ) ) {
                    result[0] += 0.020189341718668274;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8507017292462312197) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.138279000000000013) ) ) {
                        result[0] += 0.005447256118624803;
                      } else {
                        result[0] += -0.04077286295884604;
                      }
                    } else {
                      result[0] += 0.056103030037920186;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0009705000000000001169) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6628367744974875686) ) ) {
                      result[0] += 0.0108278048896654;
                    } else {
                      result[0] += -0.05894071184750825;
                    }
                  } else {
                    result[0] += 0.019442960028773805;
                  }
                }
              }
            }
          }
        } else {
          result[0] += 0.03939455184979759;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9155428772725314746) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6173059481599049159) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8150000000000000577) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8898401904750864455) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5550000000000001599) ) ) {
                  result[0] += -0.053622931560062974;
                } else {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.038794232605861678) ) ) {
                    result[0] += 0.06226908509314652;
                  } else {
                    result[0] += 0.018000609528679455;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3623115618844221508) ) ) {
                  result[0] += -0.01185825862125094;
                } else {
                  result[0] += 0.04609586032979942;
                }
              }
            } else {
              result[0] += -0.07063433055826353;
            }
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.5412335719706470316) ) ) {
              result[0] += 0.0012496597897610619;
            } else {
              result[0] += 0.03548733621234325;
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9550000000000000711) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.5496867966949329221) ) ) {
              result[0] += 0.015562052908423949;
            } else {
              result[0] += 0.05562493228573457;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8950000000000001288) ) ) {
              result[0] += 0.028420747899945607;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02431850000000000331) ) ) {
                result[0] += -0.062385378947575;
              } else {
                result[0] += 0.029451775451930822;
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8373354933349520524) ) ) {
        result[0] += 0.05250655698052204;
      } else {
        result[0] += 0.06791253080987565;
      }
    }
  }
}

