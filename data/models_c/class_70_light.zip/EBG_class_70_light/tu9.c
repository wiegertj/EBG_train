
#include "header.h"

void predict_unit9(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.607134570361309911) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4243526687260518182) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2002749652849908635) ) ) {
        result[0] += -0.026509638570176387;
      } else {
        result[0] += -0.016484004176021208;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5561432885305349627) ) ) {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.2413536536667375276) ) ) {
          result[0] += -0.0024558769862354428;
        } else {
          result[0] += -0.011646311205413389;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1295212041281339765) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02065050000000000566) ) ) {
            result[0] += 0.00011476557467950195;
          } else {
            result[0] += 0.00811342900346199;
          }
        } else {
          result[0] += -0.003117265368023764;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7141856296356029477) ) ) {
      result[0] += 0.010534458769541398;
    } else {
      result[0] += 0.026952983221623338;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.637063197009426152) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4697693723122448595) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2721741080702284044) ) ) {
        result[0] += -0.02489312677343849;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += -0.006527912334692034;
        } else {
          result[0] += -0.016089048300497504;
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.655609054534752711) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4450000000000000622) ) ) {
          result[0] += -0.001074125478137566;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003370500000000000666) ) ) {
            result[0] += -0.00997879629802021;
          } else {
            result[0] += -0.0032182572461006507;
          }
        }
      } else {
        result[0] += 0.0025895245556554047;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.733482828522406094) ) ) {
      result[0] += 0.012400568880754775;
    } else {
      result[0] += 0.02727325825716316;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7877973938526349196) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4243526687260518182) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2002749652849908635) ) ) {
        result[0] += -0.02630218006952646;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.300000000000000843e-05) ) ) {
          result[0] += -0.009998058586901361;
        } else {
          result[0] += -0.018955472488300467;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5754236634526536109) ) ) {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.2367007440475680791) ) ) {
          result[0] += -0.0013805727513065357;
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4833496887444805323) ) ) {
            result[0] += -0.01801248375271414;
          } else {
            result[0] += -0.007397863379016154;
          }
        }
      } else {
        result[0] += 0.000360971725437443;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7141856296356029477) ) ) {
      result[0] += 0.010334297354687364;
    } else {
      result[0] += 0.02669623810434312;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.637063197009426152) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4243526687260518182) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2002749652849908635) ) ) {
        result[0] += -0.02619569259826148;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.300000000000000843e-05) ) ) {
          result[0] += -0.009808471816281103;
        } else {
          result[0] += -0.018733895716138236;
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.655609054534752711) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5201676432420939689) ) ) {
          result[0] += -0.009500234569307733;
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3650000000000000466) ) ) {
            result[0] += 0.0024592993204097173;
          } else {
            result[0] += -0.0062083131507523;
          }
        }
      } else {
        result[0] += 0.002454682850463321;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.733482828522406094) ) ) {
      result[0] += 0.01196532088610785;
    } else {
      result[0] += 0.027037066322776183;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.637063197009426152) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4243526687260518182) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2002749652849908635) ) ) {
        result[0] += -0.026089319833476017;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.300000000000000843e-05) ) ) {
          result[0] += -0.009621162837915722;
        } else {
          result[0] += -0.018512670559595715;
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6513175839869357331) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5201676432420939689) ) ) {
          result[0] += -0.009305758445638494;
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3650000000000000466) ) ) {
            result[0] += 0.002468006150309405;
          } else {
            result[0] += -0.006320025766114213;
          }
        }
      } else {
        result[0] += 0.002277590475470804;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.733482828522406094) ) ) {
      result[0] += 0.01173066358742317;
    } else {
      result[0] += 0.026919248326185204;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.637063197009426152) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4243526687260518182) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2002749652849908635) ) ) {
        result[0] += -0.025982989305250694;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.300000000000000843e-05) ) ) {
          result[0] += -0.00943614482702961;
        } else {
          result[0] += -0.01829179434593329;
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6373581005240800401) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004487000000000000537) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0004268439528877000528) ) ) {
            result[0] += 0;
          } else {
            result[0] += -0.012686200518039524;
          }
        } else {
          result[0] += -0.0023515236677535863;
        }
      } else {
        result[0] += 0.0019073978910602806;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.733482828522406094) ) ) {
      result[0] += 0.011499378726316144;
    } else {
      result[0] += 0.026802168028313342;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.637063197009426152) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4243526687260518182) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2002749652849908635) ) ) {
        result[0] += -0.025876632977980717;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.300000000000000843e-05) ) ) {
          result[0] += -0.009253431199685837;
        } else {
          result[0] += -0.018071270128728754;
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.655609054534752711) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5365113871239524101) ) ) {
          result[0] += -0.008423807111734502;
        } else {
          if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.3399990879818117206) ) ) {
            result[0] += 0.0021210263564706722;
          } else {
            result[0] += -0.005944081347616125;
          }
        }
      } else {
        result[0] += 0.0022775558162814215;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.733482828522406094) ) ) {
      result[0] += 0.011271443022914605;
    } else {
      result[0] += 0.026685735612136295;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8177305660097224926) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3423866036000239865) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1353015872182791457) ) ) {
        result[0] += -0.02736318626475512;
      } else {
        result[0] += -0.018159614168854282;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5524193294893345874) ) ) {
        result[0] += -0.008682793503296145;
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6746411929901378057) ) ) {
          if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.3399990879818117206) ) ) {
            result[0] += 0.004012882154289738;
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1928404077803808903) ) ) {
              result[0] += 0.003620777790713514;
            } else {
              result[0] += -0.006727157719590002;
            }
          }
        } else {
          result[0] += 0.002600164336034014;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.733482828522406094) ) ) {
      result[0] += 0.011157615392863505;
    } else {
      result[0] += 0.026569859102662585;
    }
  }
}

