
#include "header.h"

void predict_unit9(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6415213458272231994) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.258569720040409734) ) ) {
      result[0] += -0.034798049955436894;
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5010423588193532174) ) ) {
        result[0] += -0.01178032344798265;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004746500000000001586) ) ) {
          result[0] += -0.004350805439610166;
        } else {
          result[0] += 0.005363232326463901;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.841376214053286442) ) ) {
      result[0] += 0.02114380289301915;
    } else {
      result[0] += 0.042504989357741274;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7051974671744832834) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2025449053348033213) ) ) {
      result[0] += -0.038505087388830475;
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4744068267591841637) ) ) {
        result[0] += -0.013359505880350928;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003591500000000000508) ) ) {
          result[0] += -0.00431137984250953;
        } else {
          result[0] += 0.004298175973665588;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.841376214053286442) ) ) {
      result[0] += 0.021170556497077126;
    } else {
      result[0] += 0.042299149050786;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6606907916086263155) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2025449053348033213) ) ) {
      result[0] += -0.038204577266446625;
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.492025658416472611) ) ) {
        result[0] += -0.012218735744188613;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003591500000000000508) ) ) {
          result[0] += -0.004098575238930659;
        } else {
          result[0] += 0.004742939159213997;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.841376214053286442) ) ) {
      result[0] += 0.022259404445738595;
    } else {
      result[0] += 0.042092504486437;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6415213458272231994) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2025449053348033213) ) ) {
      result[0] += -0.0378991970115087;
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4744068267591841637) ) ) {
        result[0] += -0.01252170426396869;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004746500000000001586) ) ) {
          result[0] += -0.004056381238423978;
        } else {
          result[0] += 0.004442694225368298;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.841376214053286442) ) ) {
      result[0] += 0.019659537397504874;
    } else {
      result[0] += 0.04188470865385334;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6659690958451348619) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2025449053348033213) ) ) {
      result[0] += -0.03758872410690588;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6526844655663904815) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.650000000000000541e-05) ) ) {
          result[0] += 0.005445261587107291;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004471500000000000648) ) ) {
            result[0] += -0.019761017257629725;
          } else {
            result[0] += -0.001836741796299238;
          }
        }
      } else {
        result[0] += 0.003701615987341235;
      }
    }
  } else {
    result[0] += 0.03174888600121513;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6828286013470772353) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1596646965685780961) ) ) {
      result[0] += -0.041122378703792636;
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4744068267591841637) ) ) {
        result[0] += -0.012579138336234015;
      } else {
        if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5797375516240159676) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += 0.011886179332837336;
          } else {
            result[0] += -0.002732757661270352;
          }
        } else {
          result[0] += 0.009918633160125019;
        }
      }
    }
  } else {
    result[0] += 0.033126103004482016;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6953050394685441615) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1596646965685780961) ) ) {
      result[0] += -0.04092283885996716;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5966361188013137307) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.650000000000000541e-05) ) ) {
          result[0] += 0.002764099260108937;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003591500000000000508) ) ) {
            result[0] += -0.022255921433002188;
          } else {
            result[0] += -0.004950647717252438;
          }
        }
      } else {
        result[0] += 0.002861926933202855;
      }
    }
  } else {
    result[0] += 0.0339447681035043;
  }
}

