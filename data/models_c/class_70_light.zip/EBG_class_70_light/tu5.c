
#include "header.h"

void predict_unit5(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6976830617481789565) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4591620551040981879) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2570930305089630941) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1247736973015392964) ) ) {
          result[0] += -0.07482039799504722;
        } else {
          result[0] += -0.06834728605542774;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)2.800000000000000297e-05) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883661844891582726) ) ) {
            result[0] += -0.048291792088882325;
          } else {
            result[0] += 0.000918507022946314;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4094140003309167386) ) ) {
            result[0] += -0.061659362589854154;
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1917993845848007251) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3750110022441224822) ) ) {
                result[0] += -0.029040350359701348;
              } else {
                result[0] += 0.032940546748862085;
              }
            } else {
              result[0] += -0.05355364741839379;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5825139232263935041) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5356561403784442232) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2700291939076160941) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1650000000000000355) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1607310000000000405) ) ) {
                result[0] += -0.010156567872449082;
              } else {
                result[0] += 0.05865870560634383;
              }
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.038794232605861678) ) ) {
                result[0] += 0.043345762508307475;
              } else {
                result[0] += -0.032312165771471134;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003291500000000000589) ) ) {
              result[0] += -0.05274952725427436;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5017812602789092358) ) ) {
                result[0] += -0.050629860393893535;
              } else {
                result[0] += -0.029160288027171622;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3865950184387632049) ) ) {
            result[0] += -0.014577535439303835;
          } else {
            result[0] += -0.03895390639200435;
          }
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.625707420288709959) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3792130763724597675) ) ) {
            result[0] += -0.004209015896499928;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001627500000000000257) ) ) {
              result[0] += -0.045083675054134714;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08425129245607926309) ) ) {
                if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.117869827723712392) ) ) {
                  result[0] += -0.023546211754198354;
                } else {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4562124858515706483) ) ) {
                    result[0] += 0.0038820149437105047;
                  } else {
                    result[0] += 0.08366414535441834;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00192350000000000008) ) ) {
                  result[0] += 0.020558680997357803;
                } else {
                  result[0] += -0.03441679313027827;
                }
              }
            }
          }
        } else {
          result[0] += -0.0034113827104878475;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8898401904750864455) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7811682765315622889) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7291204255332855988) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4350000000000000533) ) ) {
            result[0] += 0.038663039484815295;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009714500000000002647) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6150000000000001021) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7074300481310827893) ) ) {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4970969558157761203) ) ) {
                    result[0] += 0.0625396397829236;
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0006475000000000001804) ) ) {
                      result[0] += 0.05460522770650877;
                    } else {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002122500000000000688) ) ) {
                        result[0] += -0.04456241502258222;
                      } else {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003697500000000000699) ) ) {
                          result[0] += 0.05076365551994443;
                        } else {
                          result[0] += -0.029271305099157874;
                        }
                      }
                    }
                  }
                } else {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4537022967526785355) ) ) {
                    result[0] += -0.003905906434137934;
                  } else {
                    result[0] += 0.0493602475392705;
                  }
                }
              } else {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2450759342279490716) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7750000000000001332) ) ) {
                    result[0] += -0.07185463748300941;
                  } else {
                    result[0] += -7.599431656049648e-05;
                  }
                } else {
                  result[0] += 0.009742652799982331;
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5150000000000001243) ) ) {
                result[0] += 0.010447620036182619;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8388933876381911015) ) ) {
                  result[0] += -0.02113368912425317;
                } else {
                  result[0] += 0.043855158477811254;
                }
              }
            }
          }
        } else {
          result[0] += 0.024600917331364644;
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6445926074073893286) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001376500000000000336) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)2.800000000000000297e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9450000000000000622) ) ) {
                result[0] += 0.017481265684199287;
              } else {
                result[0] += 0.08613080207902099;
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6048664256207149093) ) ) {
                result[0] += -0.06155710333382796;
              } else {
                result[0] += 0.0186542519519551;
              }
            }
          } else {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6260154606475681893) ) ) {
              result[0] += 0.0386725491803485;
            } else {
              result[0] += 0.05522579096937825;
            }
          }
        } else {
          result[0] += 0.06046062066564889;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7409427245099348136) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6675308230823290279) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9550000000000000711) ) ) {
            result[0] += 0.06548513830479005;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8450000000000000844) ) ) {
              result[0] += 0.053310825469636544;
            } else {
              result[0] += 0.012739912453760752;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9150000000000001465) ) ) {
            result[0] += 0.07062351203895045;
          } else {
            result[0] += 0.04403575926148707;
          }
        }
      } else {
        result[0] += 0.07923813107622914;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7024961766447593847) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4591620551040981879) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2570930305089630941) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1206121103143473067) ) ) {
          result[0] += -0.07396399255864793;
        } else {
          result[0] += -0.06723286688938294;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3768882457614676773) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)2.800000000000000297e-05) ) ) {
            result[0] += -0.048060450088235264;
          } else {
            result[0] += -0.06161012438235584;
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2198326728482087045) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4251092621105527214) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2650000000000000688) ) ) {
                result[0] += -0.02054167068762714;
              } else {
                result[0] += 0.05202427786431199;
              }
            } else {
              result[0] += -0.04005670177041636;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002721500000000000394) ) ) {
              result[0] += -0.063017823588064;
            } else {
              result[0] += -0.047690677613703346;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5825139232263935041) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5395439842637465011) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2700291939076160941) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.038794232605861678) ) ) {
              result[0] += 0.035580892564750825;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1650000000000000355) ) ) {
                result[0] += 0.0017136207376238406;
              } else {
                result[0] += -0.029836312977681547;
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002242500000000000569) ) ) {
              result[0] += -0.05275981211774878;
            } else {
              result[0] += -0.03701571870127238;
            }
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3865950184387632049) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4250000000000000444) ) ) {
              result[0] += -0.010244800716342097;
            } else {
              result[0] += -0.04607844192417656;
            }
          } else {
            result[0] += -0.036628969166187075;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6592877443879057164) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002786500000000000348) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2944793848334646413) ) ) {
                result[0] += -0.01989260551554173;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6450000000000001288) ) ) {
                  result[0] += 0.03182115735167342;
                } else {
                  result[0] += -0.00935834810030243;
                }
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5850000000000000755) ) ) {
                result[0] += -0.0576102147921552;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0005375000000000001088) ) ) {
                  result[0] += -0.04907120311216887;
                } else {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.08110515786938453375) ) ) {
                    if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2795185878002977575) ) ) {
                      result[0] += -0.024972152138560813;
                    } else {
                      result[0] += 0.02948254480162428;
                    }
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8950000000000001288) ) ) {
                      result[0] += -0.018376863239162773;
                    } else {
                      result[0] += -0.048558127773906015;
                    }
                  }
                }
              }
            }
          } else {
            result[0] += -0.005053493116124546;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5550000000000001599) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002843500000000000541) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.875000000000000111) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8150000000000000577) ) ) {
                  result[0] += 0.037862412383680995;
                } else {
                  result[0] += -0.03541708451916094;
                }
              } else {
                result[0] += 0.06545903883790714;
              }
            } else {
              result[0] += 0.0031762469394575484;
            }
          } else {
            result[0] += -0.005890621686048449;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6602742250004863811) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7952348873182119027) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6380671833187036013) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7638123743065539095) ) ) {
            result[0] += 0.016026780567990544;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6750000000000001554) ) ) {
              result[0] += 0.032225337418330884;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.505061141934673441) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.464974115402010113) ) ) {
                  result[0] += 0.007223442166838827;
                } else {
                  result[0] += -0.07128521059258551;
                }
              } else {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.01482164789371524967) ) ) {
                  result[0] += 0.07600288651422601;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1228644831992905667) ) ) {
                    result[0] += -0.037369833135106195;
                  } else {
                    result[0] += 0.028853636341941047;
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.0255903056102470966) ) ) {
              result[0] += -0.055576952270481796;
            } else {
              result[0] += 0.039172214448711856;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.7250000000000000888) ) ) {
              result[0] += 0.04280987242019519;
            } else {
              result[0] += -0.019687786407969213;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8898401904750864455) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5572865423445595434) ) ) {
            result[0] += 0.032362331131214325;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00101050000000000033) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)2.800000000000000297e-05) ) ) {
                result[0] += 0.08375078660849332;
              } else {
                result[0] += 0.010297302848527257;
              }
            } else {
              result[0] += 0.0473433768035044;
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9550000000000000711) ) ) {
            result[0] += 0.062759033286476;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8650000000000001021) ) ) {
              result[0] += 0.04727319695054064;
            } else {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6480386193895394387) ) ) {
                result[0] += -0.041735937475668956;
              } else {
                result[0] += 0.03505395157662625;
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7994052243814134817) ) ) {
        result[0] += 0.06769243944414455;
      } else {
        result[0] += 0.07867163492018099;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7074300481310827893) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4591620551040981879) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2570930305089630941) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1247736973015392964) ) ) {
          result[0] += -0.073030425245822;
        } else {
          result[0] += -0.06595325077989223;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7440463348994975634) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.02448774902434403) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3768882457614676773) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                result[0] += -0.045474101394592216;
              } else {
                result[0] += -0.05856400080944374;
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2198326728482087045) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4251092621105527214) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1650000000000000355) ) ) {
                    result[0] += -0.035228353360740344;
                  } else {
                    result[0] += 0.02846752692540684;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6729764489447237485) ) ) {
                    result[0] += -0.04473025648169847;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6858832018090453841) ) ) {
                      result[0] += 0.04619452473597137;
                    } else {
                      result[0] += -0.027215804206861306;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002661500000000000237) ) ) {
                  result[0] += -0.061881297440049624;
                } else {
                  result[0] += -0.04260340555369165;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01716750000000000567) ) ) {
              result[0] += -0.03165769672600171;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.051391296366422923) ) ) {
                result[0] += 0.10621201102510298;
              } else {
                result[0] += -0.003113553520109295;
              }
            }
          }
        } else {
          result[0] += -0.06087740015961831;
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5825139232263935041) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2783343642141558605) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5265509790734695938) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2497186162150318578) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.516125598846385758) ) ) {
                result[0] += -0.024011475824302145;
              } else {
                result[0] += 0.014134239621259837;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7201893438693468541) ) ) {
                result[0] += -0.028423726692670636;
              } else {
                result[0] += -0.05559938887117342;
              }
            }
          } else {
            result[0] += -0.009127338474305052;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.515143529846740944) ) ) {
            result[0] += -0.04836065280186856;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.544739387236181094) ) ) {
                result[0] += -0.009441379125723773;
              } else {
                result[0] += 0.05032341699647492;
              }
            } else {
              result[0] += -0.03190389246504888;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6741462157421617141) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003160500000000000548) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3037124426228626772) ) ) {
                result[0] += -0.019182069748264065;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6350000000000001199) ) ) {
                  result[0] += 0.036249239888004915;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6732382808793971884) ) ) {
                    result[0] += 0.02646371669185935;
                  } else {
                    result[0] += -0.03130504967545737;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.625707420288709959) ) ) {
                result[0] += -0.03364951852669172;
              } else {
                result[0] += -0.013436452933861542;
              }
            }
          } else {
            result[0] += -0.003987017021735317;
          }
        } else {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3746863702111971617) ) ) {
            result[0] += 0.024853504342610924;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.55780239615577909) ) ) {
              result[0] += -0.012211785509208345;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.470659863332140993) ) ) {
                result[0] += 0.029817499600499234;
              } else {
                if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4153271040333154085) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9370184648924336779) ) ) {
                    result[0] += -0.07349734653743853;
                  } else {
                    result[0] += 0.017614185844691013;
                  }
                } else {
                  result[0] += 0.005942036354631239;
                }
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6602742250004863811) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7952348873182119027) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4250000000000000444) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4549440021356783714) ) ) {
              result[0] += 0.007904849600174612;
            } else {
              result[0] += 0.06269547218612291;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.138279000000000013) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7590881258441545265) ) ) {
                result[0] += 0.012656320239342453;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6650000000000001465) ) ) {
                  result[0] += 0.032610302841948755;
                } else {
                  result[0] += 0.012009301710166823;
                }
              }
            } else {
              result[0] += -0.027681835096730202;
            }
          }
        } else {
          result[0] += 0.030903333684692634;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8898401904750864455) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4731422897738694067) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5357646220388291303) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5841461392757277826) ) ) {
                result[0] += 0.021689286688338905;
              } else {
                result[0] += -0.04800746844098506;
              }
            } else {
              result[0] += 0.03624894423570695;
            }
          } else {
            result[0] += 0.04244580405815376;
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9550000000000000711) ) ) {
            result[0] += 0.06064572867751233;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8450000000000000844) ) ) {
              result[0] += 0.048062912833578594;
            } else {
              result[0] += 0.0034366302378463307;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7994052243814134817) ) ) {
        result[0] += 0.06585003514408162;
      } else {
        result[0] += 0.07731433246257811;
      }
    }
  }
}

