
#include "header.h"

void predict_unit5(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5878164698418921752) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4236855092944680212) ) ) {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1596646965685780961) ) ) {
        result[0] += -0.04725719827800124;
      } else {
        result[0] += -0.03261002692999976;
      }
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5582897067648240341) ) ) {
        result[0] += -0.01766799482570654;
      } else {
        result[0] += -0.0012033883680062547;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6953050394685441615) ) ) {
      result[0] += 0.021030232385247895;
    } else {
      result[0] += 0.046678128714390525;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.765966927815004861) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4236855092944680212) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2025449053348033213) ) ) {
        result[0] += -0.045678711196154305;
      } else {
        result[0] += -0.030730443189321572;
      }
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5966361188013137307) ) ) {
        result[0] += -0.014758644564648898;
      } else {
        result[0] += 0.0003846341559119931;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7221143281151479743) ) ) {
      result[0] += 0.021617023631327132;
    } else {
      result[0] += 0.0471289496481711;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5991490417989203676) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4236855092944680212) ) ) {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1596646965685780961) ) ) {
        result[0] += -0.04673732300986936;
      } else {
        result[0] += -0.031373126648121676;
      }
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6438205396169394135) ) ) {
        result[0] += -0.01236652429575283;
      } else {
        result[0] += 0.002757077306476679;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7221143281151479743) ) ) {
      result[0] += 0.021709947170880876;
    } else {
      result[0] += 0.04672403565622913;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.765966927815004861) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4045448672742624763) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1596646965685780961) ) ) {
        result[0] += -0.046487177214329815;
      } else {
        result[0] += -0.03148830875228753;
      }
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5506872176393086127) ) ) {
        result[0] += -0.017278615183026445;
      } else {
        result[0] += -0.0012703405746067474;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7221143281151479743) ) ) {
      result[0] += 0.020321970454825214;
    } else {
      result[0] += 0.04633098323676096;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5991490417989203676) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4236855092944680212) ) ) {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1596646965685780961) ) ) {
        result[0] += -0.046245139312217805;
      } else {
        result[0] += -0.030173405601597893;
      }
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6438205396169394135) ) ) {
        result[0] += -0.01155971873328425;
      } else {
        result[0] += 0.0025050027120783244;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7221143281151479743) ) ) {
      result[0] += 0.020444373383338255;
    } else {
      result[0] += 0.04594862689371616;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.765966927815004861) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4045448672742624763) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1596646965685780961) ) ) {
        result[0] += -0.04601054992037798;
      } else {
        result[0] += -0.03031001166592741;
      }
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5506872176393086127) ) ) {
        result[0] += -0.016287991333089405;
      } else {
        result[0] += -0.0011534232853492277;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6953050394685441615) ) ) {
      result[0] += 0.01806463845721773;
    } else {
      result[0] += 0.04460329166986845;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5991490417989203676) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4045448672742624763) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1596646965685780961) ) ) {
        result[0] += -0.045782767991952376;
      } else {
        result[0] += -0.029717213403760195;
      }
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5506872176393086127) ) ) {
        result[0] += -0.01574926317892299;
      } else {
        result[0] += -0.0009063437588433544;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7286792202408863828) ) ) {
      result[0] += 0.01941589964336972;
    } else {
      result[0] += 0.04543833779552268;
    }
  }
}

