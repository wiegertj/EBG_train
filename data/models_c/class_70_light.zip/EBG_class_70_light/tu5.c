
#include "header.h"

void predict_unit5(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6658449540838127234) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4471985607798013018) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2268996455050684702) ) ) {
        result[0] += -0.030266604268533157;
      } else {
        result[0] += -0.023479381293253186;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5524193294893345874) ) ) {
        result[0] += -0.014853122958638545;
      } else {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.3399990879818117206) ) ) {
          result[0] += -7.867603397780442e-05;
        } else {
          result[0] += -0.008917930585306015;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6967761054388647013) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7693651808594642594) ) ) {
        result[0] += 0.004167327793628284;
      } else {
        result[0] += 0.01522958334315055;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.733482828522406094) ) ) {
        result[0] += 0.024918523730504676;
      } else {
        result[0] += 0.0325683334617624;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.655609054534752711) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4471985607798013018) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2268996455050684702) ) ) {
        result[0] += -0.030092168928833807;
      } else {
        result[0] += -0.023200746717608;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5524193294893345874) ) ) {
        result[0] += -0.014569492188930269;
      } else {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.3399990879818117206) ) ) {
          result[0] += -0.0004208124383475773;
        } else {
          result[0] += -0.009767181688375415;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6967761054388647013) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7640407544788561101) ) ) {
        result[0] += 0.0035149787178602003;
      } else {
        result[0] += 0.014633024439595974;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.733482828522406094) ) ) {
        result[0] += 0.024565991973030575;
      } else {
        result[0] += 0.03233145683674431;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7352869986369691135) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4519258424761351534) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2721741080702284044) ) ) {
        result[0] += -0.02938953479253985;
      } else {
        result[0] += -0.022025530293938014;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6038797007738568867) ) ) {
        result[0] += -0.012034955358709845;
      } else {
        result[0] += -0.0006242562109903364;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6549621339660968156) ) ) {
      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6179594490196074208) ) ) {
        result[0] += 0.00854920837892791;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9350000000000001643) ) ) {
          result[0] += 0.023447786725410858;
        } else {
          result[0] += 0.013874732145225537;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.746072903742064919) ) ) {
        result[0] += 0.025531369906621842;
      } else {
        result[0] += 0.03223098662225553;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7352869986369691135) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4519258424761351534) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2721741080702284044) ) ) {
        result[0] += -0.029212676666951064;
      } else {
        result[0] += -0.021744829858420255;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5991184370131029668) ) ) {
        result[0] += -0.011970394297625371;
      } else {
        result[0] += -0.0007893554920877187;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6549621339660968156) ) ) {
      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6179594490196074208) ) ) {
        result[0] += 0.008334274679574042;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9350000000000001643) ) ) {
          result[0] += 0.023049731736409524;
        } else {
          result[0] += 0.013571423489338265;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.746072903742064919) ) ) {
        result[0] += 0.025200320592075887;
      } else {
        result[0] += 0.032011088728149194;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.655609054534752711) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4471985607798013018) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2268996455050684702) ) ) {
        result[0] += -0.029598905099972664;
      } else {
        result[0] += -0.022370595095664234;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5524193294893345874) ) ) {
        result[0] += -0.013814084560138919;
      } else {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.3399990879818117206) ) ) {
          result[0] += 0;
        } else {
          result[0] += -0.009327010406826387;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6967761054388647013) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.607134570361309911) ) ) {
        result[0] += 0.004075540012865671;
      } else {
        result[0] += 0.014835332511275067;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.733482828522406094) ) ) {
        result[0] += 0.023565206370495344;
      } else {
        result[0] += 0.031666881978905166;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7352869986369691135) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4519258424761351534) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2721741080702284044) ) ) {
        result[0] += -0.02887210950903892;
      } else {
        result[0] += -0.021182708750763543;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6038797007738568867) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4450000000000000622) ) ) {
          result[0] += -0.007682637471224869;
        } else {
          result[0] += -0.014831210855356687;
        }
      } else {
        result[0] += -0.000583345142695294;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6549621339660968156) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.637063197009426152) ) ) {
        result[0] += 0.008928829848174218;
      } else {
        result[0] += 0.017026584699122636;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.746072903742064919) ) ) {
        result[0] += 0.024567030800739433;
      } else {
        result[0] += 0.031592774495462314;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7352869986369691135) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4519258424761351534) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2268996455050684702) ) ) {
        result[0] += -0.029286925526618515;
      } else {
        result[0] += -0.02169297624427857;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5991184370131029668) ) ) {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.2793434790857622363) ) ) {
          result[0] += -0.006845360540977498;
        } else {
          result[0] += -0.014154471808900757;
        }
      } else {
        result[0] += -0.0007338816434003284;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6549621339660968156) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.637063197009426152) ) ) {
        result[0] += 0.008707742938697001;
      } else {
        result[0] += 0.01669060190040978;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.746072903742064919) ) ) {
        result[0] += 0.024250535031907227;
      } else {
        result[0] += 0.03139277146862646;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7352869986369691135) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4471985607798013018) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2178518179945141686) ) ) {
        result[0] += -0.029253426317122442;
      } else {
        result[0] += -0.02169861123824113;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5843380316172624989) ) ) {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.2459704571246580096) ) ) {
          result[0] += -0.005133840080340512;
        } else {
          result[0] += -0.013844927543773856;
        }
      } else {
        result[0] += -0.0011660728289433916;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6549621339660968156) ) ) {
      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.607134570361309911) ) ) {
        result[0] += 0.006970202445688157;
      } else {
        result[0] += 0.015096918894802214;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.746072903742064919) ) ) {
        result[0] += 0.023938421914025138;
      } else {
        result[0] += 0.03119871850915105;
      }
    }
  }
}

