
#include "header.h"

void predict_unit15(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.733482828522406094) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2919078020022707887) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.09772417524126585098) ) ) {
        result[0] += -0.02601919132753728;
      } else {
        result[0] += -0.012579147975735496;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7195042938813859257) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4697693723122448595) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3850000000000000644) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05500000000000000722) ) ) {
              result[0] += 0.019803390008944693;
            } else {
              result[0] += -0.00459453544514614;
            }
          } else {
            result[0] += -0.015504199070400876;
          }
        } else {
          result[0] += -0.0009439761215149146;
        }
      } else {
        result[0] += 0.003016690759107083;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8825415847515221124) ) ) {
      result[0] += 0.015393812655276116;
    } else {
      result[0] += 0.02612635838753666;
    }
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.733482828522406094) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2721741080702284044) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.09772417524126585098) ) ) {
        result[0] += -0.025967124928756198;
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3750409390474713223) ) ) {
          result[0] += 0.016526378387053342;
        } else {
          result[0] += -0.01457331435654397;
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6746411929901378057) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0004268439528877000528) ) ) {
          result[0] += 0.0023181351414042627;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001184500000000000223) ) ) {
            result[0] += -0.013107385834855287;
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4243526687260518182) ) ) {
              result[0] += -0.00963987650229301;
            } else {
              result[0] += -0.0009792662538428765;
            }
          }
        }
      } else {
        result[0] += 0.0023123292419465705;
      }
    }
  } else {
    result[0] += 0.021517366831446446;
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.746072903742064919) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2721741080702284044) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.09772417524126585098) ) ) {
        result[0] += -0.025914542192727753;
      } else {
        result[0] += -0.012764493422714494;
      }
    } else {
      if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5617014566079165938) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4697693723122448595) ) ) {
          result[0] += -0.005854058970492026;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.966590843157139501) ) ) {
            result[0] += 0.00023222189578256044;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.042293675472235615) ) ) {
              result[0] += -0.01886648544163524;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
                result[0] += 0.01634309223159931;
              } else {
                result[0] += -0.006291376468380144;
              }
            }
          }
        }
      } else {
        result[0] += 0.004324701797007605;
      }
    }
  } else {
    result[0] += 0.021985332495498406;
  }
}

