
#include "header.h"

void predict_unit15(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8744374956483617067) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.09235793191041487271) ) ) {
      result[0] += -0.04166144440855066;
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3474450840415687081) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          result[0] += 0.02975996137103251;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.451010911537604565e-06) ) ) {
            result[0] += 0.006788463747082836;
          } else {
            result[0] += -0.015570298493893025;
          }
        }
      } else {
        result[0] += 0.0006315160544066055;
      }
    }
  } else {
    result[0] += 0.0346744308147323;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8744374956483617067) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.09235793191041487271) ) ) {
      result[0] += -0.04155745220673166;
    } else {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5797375516240159676) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.023110450188021527;
        } else {
          result[0] += -0.0018143270335785017;
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9650000000000000799) ) ) {
          result[0] += 0.0169547505993917;
        } else {
          result[0] += 0.0013234213705497707;
        }
      }
    }
  } else {
    result[0] += 0.034337370677798164;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9307660166838862548) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.09235793191041487271) ) ) {
      result[0] += -0.04145032841960919;
    } else {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6251195235379441995) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 0.005068956436379647;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002108500000000000565) ) ) {
            result[0] += -0.010435354529261308;
          } else {
            result[0] += 0.0004536385772045261;
          }
        }
      } else {
        result[0] += 0.0075878860043874065;
      }
    }
  } else {
    result[0] += 0.04051089139190561;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9307660166838862548) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.09235793191041487271) ) ) {
      result[0] += -0.04133992140933678;
    } else {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6415213458272231994) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8450000000000000844) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005038500000000000444) ) ) {
            result[0] += -0.0032238276158305383;
          } else {
            result[0] += 0.002035704506115019;
          }
        } else {
          result[0] += -0.03814701800798423;
        }
      } else {
        result[0] += 0.008620210705411597;
      }
    }
  } else {
    result[0] += 0.040354378720753634;
  }
}

