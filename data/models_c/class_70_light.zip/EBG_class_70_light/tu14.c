
#include "header.h"

void predict_unit14(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8744374956483617067) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.09235793191041487271) ) ) {
      result[0] += -0.04231361529975218;
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3474450840415687081) ) ) {
        result[0] += -0.010411215371841222;
      } else {
        if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6251195235379441995) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += 0.007676365752667463;
          } else {
            result[0] += -0.0014243547918186446;
          }
        } else {
          result[0] += 0.008052553253182616;
        }
      }
    }
  } else {
    result[0] += 0.036831153205999674;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8744374956483617067) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.09235793191041487271) ) ) {
      result[0] += -0.042227581081430876;
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5582897067648240341) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7392963230402010977) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.164043705886945172e-06) ) ) {
            result[0] += 0.018735984054753255;
          } else {
            result[0] += -0.0035295804639219443;
          }
        } else {
          result[0] += -0.016117165997430835;
        }
      } else {
        result[0] += 0.0017360457839954966;
      }
    }
  } else {
    result[0] += 0.03654422959252774;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8744374956483617067) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.09235793191041487271) ) ) {
      result[0] += -0.042139406176225816;
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3474450840415687081) ) ) {
        result[0] += -0.009883431049177924;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003591500000000000508) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += 0.007286060508442125;
          } else {
            result[0] += -0.005977825596863666;
          }
        } else {
          result[0] += 0.0030491771245151557;
        }
      }
    }
  } else {
    result[0] += 0.03625040545295259;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8744374956483617067) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.09235793191041487271) ) ) {
      result[0] += -0.04204893973882303;
    } else {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5447856234025308941) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 0.004327239766622679;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002757500000000000402) ) ) {
            result[0] += -0.011533236605836342;
          } else {
            result[0] += -0.00013568798735678471;
          }
        }
      } else {
        result[0] += 0.0047978620537281556;
      }
    }
  } else {
    result[0] += 0.035949578355236385;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8744374956483617067) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.09235793191041487271) ) ) {
      result[0] += -0.04195605174944165;
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4236855092944680212) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.650000000000000541e-05) ) ) {
          result[0] += 0.0012016459044964752;
        } else {
          result[0] += -0.013531470609174508;
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1850000000000000255) ) ) {
          result[0] += 0.019280469398805126;
        } else {
          result[0] += 0.00041752170130128594;
        }
      }
    }
  } else {
    result[0] += 0.03564164873485309;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8744374956483617067) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.09235793191041487271) ) ) {
      result[0] += -0.04186059782322287;
    } else {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5447856234025308941) ) ) {
        result[0] += -0.001821915595555199;
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9150000000000001465) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6577004887322178694) ) ) {
            result[0] += 0.006279789561598333;
          } else {
            result[0] += 0.03261254034225356;
          }
        } else {
          result[0] += 0.0021301827736440316;
        }
      }
    }
  } else {
    result[0] += 0.0353265244005786;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8744374956483617067) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.09235793191041487271) ) ) {
      result[0] += -0.041762447026645354;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5966361188013137307) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7392963230402010977) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
            result[0] += 0.04588041187103454;
          } else {
            result[0] += -0.001970281949502966;
          }
        } else {
          result[0] += -0.013722458473835056;
        }
      } else {
        result[0] += 0.001927620905039638;
      }
    }
  } else {
    result[0] += 0.03500413609117965;
  }
}

