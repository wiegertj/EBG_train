
#include "header.h"

void predict_unit14(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7141856296356029477) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2965188918505100024) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.09772417524126585098) ) ) {
        result[0] += -0.026417746791916455;
      } else {
        result[0] += -0.013969338990431797;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5024430027690397482) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3850000000000000644) ) ) {
          result[0] += -0.004034230829819963;
        } else {
          result[0] += -0.012927115189541866;
        }
      } else {
        if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.637063197009426152) ) ) {
          result[0] += -0.00013369164763017834;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9150000000000001465) ) ) {
            result[0] += 0.014617911727678998;
          } else {
            result[0] += 0.003588961566763525;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8825415847515221124) ) ) {
      result[0] += 0.016204746847526846;
    } else {
      result[0] += 0.026546756570664565;
    }
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7141856296356029477) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2919078020022707887) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.09772417524126585098) ) ) {
        result[0] += -0.026368729964245267;
      } else {
        result[0] += -0.013920720347937919;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5024430027690397482) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05500000000000000722) ) ) {
          result[0] += 0.01887977475703293;
        } else {
          result[0] += -0.006648642464966984;
        }
      } else {
        if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.637063197009426152) ) ) {
          result[0] += -0.00013008958743154168;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9150000000000001465) ) ) {
            result[0] += 0.014375106282990525;
          } else {
            result[0] += 0.003500651094273036;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8825415847515221124) ) ) {
      result[0] += 0.016006578214498874;
    } else {
      result[0] += 0.026489354215795766;
    }
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7141856296356029477) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2919078020022707887) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.09772417524126585098) ) ) {
        result[0] += -0.026319437281029763;
      } else {
        result[0] += -0.013722817616555786;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.622330635648172481) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 0.001484896797455125;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004487000000000000537) ) ) {
            result[0] += -0.010177340178111645;
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7461908037688443907) ) ) {
              result[0] += 0.0006120983154740414;
            } else {
              result[0] += -0.011543850946146012;
            }
          }
        }
      } else {
        result[0] += 0.001898205792799764;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8825415847515221124) ) ) {
      result[0] += 0.01580828194694143;
    } else {
      result[0] += 0.02643181076362045;
    }
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7141856296356029477) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3423866036000239865) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1353015872182791457) ) ) {
        result[0] += -0.0247228238241951;
      } else {
        result[0] += -0.011153925942480335;
      }
    } else {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5739188701925997949) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7118857137873003671) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005387500000000000795) ) ) {
            result[0] += -0.0035593144257541494;
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6796249047236181395) ) ) {
              result[0] += 0.0014280633957853511;
            } else {
              result[0] += 0.023672392689732275;
            }
          }
        } else {
          result[0] += -0.005929217849103236;
        }
      } else {
        result[0] += 0.003752096797373726;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8825415847515221124) ) ) {
      result[0] += 0.015609904839593519;
    } else {
      result[0] += 0.02637407841796674;
    }
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7141856296356029477) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2721741080702284044) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.09772417524126585098) ) ) {
        result[0] += -0.02622284872231511;
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3750409390474713223) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4633793989949749337) ) ) {
            result[0] += -0.0024423658600008307;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001520500000000000367) ) ) {
              result[0] += -0.0035800425681826106;
            } else {
              result[0] += 0.16611283570621738;
            }
          }
        } else {
          result[0] += -0.015524718223339859;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5024430027690397482) ) ) {
        result[0] += -0.005966951757275448;
      } else {
        if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.637063197009426152) ) ) {
          result[0] += -0.00011647620101093614;
        } else {
          result[0] += 0.005254081212097113;
        }
      }
    }
  } else {
    result[0] += 0.0212426193479412;
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7141856296356029477) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2721741080702284044) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.09772417524126585098) ) ) {
        result[0] += -0.026172563052147577;
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3750409390474713223) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4633793989949749337) ) ) {
            result[0] += -0.0023849528154113457;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03500000000000001027) ) ) {
              result[0] += 0.15377478556855767;
            } else {
              result[0] += 0;
            }
          }
        } else {
          result[0] += -0.015328666180849375;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5024430027690397482) ) ) {
        result[0] += -0.005834631743444898;
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8177305660097224926) ) ) {
          result[0] += -0.00010254319143678594;
        } else {
          result[0] += 0.005187933325368246;
        }
      }
    }
  } else {
    result[0] += 0.021088379435416915;
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7141856296356029477) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2721741080702284044) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.09772417524126585098) ) ) {
        result[0] += -0.02612187693106479;
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3750409390474713223) ) ) {
          if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4577025284881549028) ) ) {
            result[0] += -0.008623199946752536;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
              result[0] += 0.13968148206178163;
            } else {
              result[0] += 0;
            }
          }
        } else {
          result[0] += -0.015132557281856824;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5024430027690397482) ) ) {
        result[0] += -0.005704659749379857;
      } else {
        if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.637063197009426152) ) ) {
          result[0] += -0.00011933010848567682;
        } else {
          result[0] += 0.005043999337058731;
        }
      }
    }
  } else {
    result[0] += 0.02093284437381537;
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.733482828522406094) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2721741080702284044) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.09772417524126585098) ) ) {
        result[0] += -0.02607076347933961;
      } else {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3750409390474713223) ) ) {
          if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4577025284881549028) ) ) {
            result[0] += -0.008468182526767553;
          } else {
            result[0] += 0.06490213600128511;
          }
        } else {
          result[0] += -0.014936445166570942;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5024430027690397482) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 0.0011967036631028289;
        } else {
          result[0] += -0.008050509997371804;
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.844661369991607125) ) ) {
          result[0] += 4.623514652658075e-05;
        } else {
          result[0] += 0.006040376262672656;
        }
      }
    }
  } else {
    result[0] += 0.021802857332963436;
  }
}

