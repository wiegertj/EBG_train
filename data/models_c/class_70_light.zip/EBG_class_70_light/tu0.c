
#include "header.h"

void predict_unit0(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6988115259217656527) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5365113871239524101) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4243526687260518182) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2721741080702284044) ) ) {
          result[0] += -0.34478435994557877;
        } else {
          result[0] += -0.33995430779891156;
        }
      } else {
        result[0] += -0.3330988631500117;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6320766827776574948) ) ) {
        result[0] += -0.3198639422172906;
      } else {
        result[0] += -0.3032519121297876;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.650477501151463966) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7693651808594642594) ) ) {
        result[0] += -0.28101748380937863;
      } else {
        result[0] += -0.2625903682239196;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6904018820383829302) ) ) {
        result[0] += -0.24916581680282618;
      } else {
        result[0] += -0.23681018303161822;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6988115259217656527) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5365113871239524101) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4243526687260518182) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2721741080702284044) ) ) {
          result[0] += -0.04498775787641985;
        } else {
          result[0] += -0.04021972387205764;
        }
      } else {
        result[0] += -0.03346631037038819;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6320766827776574948) ) ) {
        result[0] += -0.020473605830180364;
      } else {
        result[0] += -0.00424554540533842;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.650477501151463966) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7693651808594642594) ) ) {
        result[0] += 0.017347212870800727;
      } else {
        result[0] += 0.03514232034368717;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7141856296356029477) ) ) {
        result[0] += 0.04917171356835869;
      } else {
        result[0] += 0.06025974209451471;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6988115259217656527) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5365113871239524101) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4243526687260518182) ) ) {
        result[0] += -0.04273686108417134;
      } else {
        result[0] += -0.03275589717000979;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6320766827776574948) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3750000000000000555) ) ) {
          result[0] += -0.01379781915547755;
        } else {
          result[0] += -0.023398952422219718;
        }
      } else {
        result[0] += -0.004133825838647192;
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8341961608046256638) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7640407544788561101) ) ) {
        result[0] += 0.01646464203334106;
      } else {
        result[0] += 0.033833366438918794;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6549621339660968156) ) ) {
        result[0] += 0.04424392245324462;
      } else {
        result[0] += 0.057469365693133455;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6988115259217656527) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5365113871239524101) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3423866036000239865) ) ) {
        result[0] += -0.04272880977629158;
      } else {
        result[0] += -0.03438965213644899;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6320766827776574948) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3750000000000000555) ) ) {
          result[0] += -0.013458474162602155;
        } else {
          result[0] += -0.022862587417422617;
        }
      } else {
        result[0] += -0.004025011515040697;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.650477501151463966) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7693651808594642594) ) ) {
        result[0] += 0.016329361764504217;
      } else {
        result[0] += 0.03292070675997076;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7141856296356029477) ) ) {
        result[0] += 0.04610057931409351;
      } else {
        result[0] += 0.05647395963961468;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6988115259217656527) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5365113871239524101) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4243526687260518182) ) ) {
        result[0] += -0.04121355119506344;
      } else {
        result[0] += -0.03137038999274451;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6373581005240800401) ) ) {
        result[0] += -0.018728190915558503;
      } else {
        result[0] += -0.0033416567654489526;
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.844661369991607125) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7640407544788561101) ) ) {
        result[0] += 0.015498000677681516;
      } else {
        if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6226783190417196634) ) ) {
          result[0] += 0.02650987537550716;
        } else {
          result[0] += 0.038515676868544624;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7141856296356029477) ) ) {
        result[0] += 0.045494343673129434;
      } else {
        result[0] += 0.05480837181620297;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6988115259217656527) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5201676432420939689) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2965188918505100024) ) ) {
        result[0] += -0.04176253762794911;
      } else {
        result[0] += -0.034515503579086365;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6038797007738568867) ) ) {
        result[0] += -0.021866877233682247;
      } else {
        result[0] += -0.006467103679812484;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6840531608062441205) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7640407544788561101) ) ) {
        result[0] += 0.01505432507304855;
      } else {
        if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.607134570361309911) ) ) {
          result[0] += 0.02541149994007254;
        } else {
          result[0] += 0.037103465849522316;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7141856296356029477) ) ) {
        result[0] += 0.04604757141230413;
      } else {
        result[0] += 0.05327818821979921;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6988115259217656527) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5365113871239524101) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2965188918505100024) ) ) {
        result[0] += -0.04108973099407966;
      } else {
        result[0] += -0.033240321726905345;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.655609054534752711) ) ) {
        result[0] += -0.016661662265359502;
      } else {
        result[0] += -0.00013801123022841964;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6840531608062441205) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7640407544788561101) ) ) {
        result[0] += 0.014625759754611252;
      } else {
        if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.607134570361309911) ) ) {
          result[0] += 0.024688241021953834;
        } else {
          result[0] += 0.03605099908309707;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7141856296356029477) ) ) {
        result[0] += 0.04477467982622479;
      } else {
        result[0] += 0.051867783423182275;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.704198211736497548) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5365113871239524101) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4243526687260518182) ) ) {
        result[0] += -0.039224998107799766;
      } else {
        result[0] += -0.029450237188475857;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.655609054534752711) ) ) {
        result[0] += -0.016267660471012392;
      } else {
        result[0] += 0.0003316694272608919;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6840531608062441205) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7640407544788561101) ) ) {
        result[0] += 0.014956893737296395;
      } else {
        if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.607134570361309911) ) ) {
          result[0] += 0.023994129095509624;
        } else {
          result[0] += 0.035053204730980204;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7141856296356029477) ) ) {
        result[0] += 0.04358269211474823;
      } else {
        result[0] += 0.05056383836799622;
      }
    }
  }
}

