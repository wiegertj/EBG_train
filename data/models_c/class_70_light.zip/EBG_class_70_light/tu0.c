
#include "header.h"

void predict_unit0(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6988988994204462513) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5506872176393086127) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4236855092944680212) ) ) {
        result[0] += -0.4039221242543623;
      } else {
        result[0] += -0.38565734611212;
      }
    } else {
      result[0] += -0.3517508273901994;
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6577004887322178694) ) ) {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.765966927815004861) ) ) {
        result[0] += -0.3020634857277806;
      } else {
        result[0] += -0.26865908485653595;
      }
    } else {
      result[0] += -0.2342329693000587;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6988988994204462513) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5506872176393086127) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4236855092944680212) ) ) {
        result[0] += -0.06875445697513045;
      } else {
        result[0] += -0.050868124500147646;
      }
    } else {
      result[0] += -0.018012860680004447;
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.677986157280416446) ) ) {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.765966927815004861) ) ) {
        result[0] += 0.029416846659728664;
      } else {
        result[0] += 0.06291890513466711;
      }
    } else {
      result[0] += 0.09430513918665553;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6988988994204462513) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5506872176393086127) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4236855092944680212) ) ) {
        result[0] += -0.06676307344528021;
      } else {
        result[0] += -0.049167382021009884;
      }
    } else {
      result[0] += -0.017284801095505283;
    }
  } else {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8219148688594737351) ) ) {
      result[0] += 0.040130862531137505;
    } else {
      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6828286013470772353) ) ) {
        result[0] += 0.07163093076442816;
      } else {
        result[0] += 0.0916135235680528;
      }
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6891637390098862559) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5055241589195451635) ) ) {
      result[0] += -0.06290696192834293;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6222134205033998944) ) ) {
        result[0] += -0.03403752057313233;
      } else {
        result[0] += -0.005797709271767814;
      }
    }
  } else {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8111300451949871038) ) ) {
      result[0] += 0.03418146455950099;
    } else {
      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6828286013470772353) ) ) {
        result[0] += 0.0674093181696522;
      } else {
        result[0] += 0.08723538082965085;
      }
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6988988994204462513) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5506872176393086127) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4236855092944680212) ) ) {
        result[0] += -0.06332284021441956;
      } else {
        result[0] += -0.04589942727003373;
      }
    } else {
      result[0] += -0.015885627727053243;
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6577004887322178694) ) ) {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7560013597309228617) ) ) {
        result[0] += 0.021982748355385804;
      } else {
        result[0] += 0.05118876219564566;
      }
    } else {
      result[0] += 0.08046281856921192;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6891637390098862559) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5055241589195451635) ) ) {
      result[0] += -0.05970541743754904;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6222134205033998944) ) ) {
        result[0] += -0.0318085819532554;
      } else {
        result[0] += -0.004875838783458436;
      }
    }
  } else {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8219148688594737351) ) ) {
      result[0] += 0.03276362528403213;
    } else {
      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6953050394685441615) ) ) {
        result[0] += 0.06285661926587252;
      } else {
        result[0] += 0.08046302754067984;
      }
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6891637390098862559) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5055241589195451635) ) ) {
      result[0] += -0.05826415150126985;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5966361188013137307) ) ) {
        result[0] += -0.033320425610364995;
      } else {
        result[0] += -0.008453573501096249;
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6577004887322178694) ) ) {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7560013597309228617) ) ) {
        result[0] += 0.01778740765218498;
      } else {
        result[0] += 0.04688724579277869;
      }
    } else {
      result[0] += 0.07429304663476156;
    }
  }
}

