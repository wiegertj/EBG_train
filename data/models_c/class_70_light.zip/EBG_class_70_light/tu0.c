
#include "header.h"

void predict_unit0(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7024961766447593847) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5356561403784442232) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4094140003309167386) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2398531877347642449) ) ) {
          result[0] += -0.4388374371456135;
        } else {
          result[0] += -0.4279416352307528;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1850000000000000255) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5017812602789092358) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.232676602354129819) ) ) {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1685957639392979546) ) ) {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4960812931966640527) ) ) {
                  result[0] += -0.31397051762486655;
                } else {
                  result[0] += -0.3891729312719747;
                }
              } else {
                result[0] += -0.40956253633271034;
              }
            } else {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1917993845848007251) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2097832671075833544) ) ) {
                  result[0] += -0.3642680596869995;
                } else {
                  result[0] += -0.27763627696584137;
                }
              } else {
                result[0] += -0.3949737161769924;
              }
            }
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2465526098716071257) ) ) {
              result[0] += -0.2800168265479364;
            } else {
              result[0] += -0.3597099648789943;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4591620551040981879) ) ) {
            result[0] += -0.4229492164934267;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2646878576133683825) ) ) {
              result[0] += -0.3881594916773631;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003224500000000000369) ) ) {
                result[0] += -0.41908088568571644;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.515143529846740944) ) ) {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4601878067544193374) ) ) {
                    result[0] += -0.3679067222981403;
                  } else {
                    result[0] += -0.4134680827336622;
                  }
                } else {
                  result[0] += -0.3914498773756471;
                }
              }
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6207300888023185026) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3308375782921226249) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6095226520848766594) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.038794232605861678) ) ) {
              result[0] += -0.3123224766413972;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
                result[0] += -0.35214365124341845;
              } else {
                result[0] += -0.373435346487503;
              }
            }
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2944793848334646413) ) ) {
              result[0] += -0.3648602803598459;
            } else {
              result[0] += -0.29192276684042046;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003493500000000000511) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)2.800000000000000297e-05) ) ) {
              result[0] += -0.36527796641698573;
            } else {
              result[0] += -0.4038234690626208;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.578266620629892647) ) ) {
              result[0] += -0.3997301507419313;
            } else {
              result[0] += -0.3573029223289915;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4350000000000000533) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6875734944390267112) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2850000000000000866) ) ) {
              result[0] += -0.2928213214147849;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6650000000000001465) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1275030000000000052) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1001961271985990637) ) ) {
                    result[0] += -0.34205316977709993;
                  } else {
                    result[0] += -0.30745440242635275;
                  }
                } else {
                  result[0] += -0.3990205722574356;
                }
              } else {
                result[0] += -0.3046618499230528;
              }
            }
          } else {
            result[0] += -0.2826184124857837;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6493078852189956285) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5271332674874372737) ) ) {
              result[0] += -0.33959275489518354;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1765680711448399387) ) ) {
                result[0] += -0.3836615712180769;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2667536841802468084) ) ) {
                  result[0] += -0.31885216561055824;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6388211610437092292) ) ) {
                    result[0] += -0.3746658402134692;
                  } else {
                    result[0] += -0.3417751383999047;
                  }
                }
              }
            }
          } else {
            result[0] += -0.33900211115453605;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8509775102983480055) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7811682765315622889) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7341196086063838111) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4250000000000000444) ) ) {
            result[0] += -0.2528392274756157;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4019627342713568141) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3321712357788945136) ) ) {
                result[0] += -0.28149658930659144;
              } else {
                result[0] += -0.3537569612741645;
              }
            } else {
              result[0] += -0.29122373840384913;
            }
          }
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5676048066399036474) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4970969558157761203) ) ) {
              result[0] += -0.2555676582966353;
            } else {
              result[0] += -0.27723103629394874;
            }
          } else {
            result[0] += -0.25304090287220443;
          }
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6410891170561271446) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.8085344187842374852) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
              result[0] += -0.24600797303073424;
            } else {
              result[0] += -0.3093483507049102;
            }
          } else {
            result[0] += -0.24135048611868862;
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3797425373115578262) ) ) {
            result[0] += -0.2576275978485195;
          } else {
            result[0] += -0.22047156506919904;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6800585241488680266) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4924412467785411196) ) ) {
          result[0] += -0.28386865345581463;
        } else {
          result[0] += -0.20878161324855055;
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7994052243814134817) ) ) {
          result[0] += -0.18931642180741362;
        } else {
          result[0] += -0.18106636054565503;
        }
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7024961766447593847) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5356561403784442232) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4094140003309167386) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2570930305089630941) ) ) {
          result[0] += -0.10219563966666081;
        } else {
          result[0] += -0.09122422202485124;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1850000000000000255) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5017812602789092358) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.232676602354129819) ) ) {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1685957639392979546) ) ) {
                result[0] += -0.044553507670021385;
              } else {
                result[0] += -0.07403499442034576;
              }
            } else {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1917993845848007251) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2097832671075833544) ) ) {
                  result[0] += -0.03079960117376302;
                } else {
                  result[0] += 0.05056440896577853;
                }
              } else {
                result[0] += -0.060063762177029204;
              }
            }
          } else {
            result[0] += 0.009671347961020945;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4591620551040981879) ) ) {
            result[0] += -0.0869913133023238;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2646878576133683825) ) ) {
              result[0] += -0.05345048706100768;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003224500000000000369) ) ) {
                result[0] += -0.08323620371232952;
              } else {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4601878067544193374) ) ) {
                  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2543089898133915061) ) ) {
                    result[0] += 0.017240584684255572;
                  } else {
                    result[0] += -0.05865027447311641;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.515143529846740944) ) ) {
                    result[0] += -0.07780066965516333;
                  } else {
                    result[0] += -0.058110903366745244;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6207300888023185026) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3308375782921226249) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6095226520848766594) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.038794232605861678) ) ) {
              result[0] += 0.018159012448483877;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
                result[0] += -0.019235347884667724;
              } else {
                result[0] += -0.03939666260716716;
              }
            }
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2944793848334646413) ) ) {
              result[0] += -0.03139859180168021;
            } else {
              result[0] += 0.03712164708622882;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003615500000000000224) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)2.800000000000000297e-05) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4750000000000000333) ) ) {
                result[0] += -0.05114708564442973;
              } else {
                result[0] += 0.03140602116352729;
              }
            } else {
              result[0] += -0.06823970730533399;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.578266620629892647) ) ) {
              result[0] += -0.0649674561476596;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7250000000000000888) ) ) {
                result[0] += -0.015713209825684398;
              } else {
                result[0] += -0.04396862806066253;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4550000000000000711) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6875734944390267112) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2850000000000000866) ) ) {
              result[0] += 0.03626228021125977;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1275030000000000052) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1001961271985990637) ) ) {
                  result[0] += -0.008508215056364624;
                } else {
                  result[0] += 0.023114732187744735;
                }
              } else {
                if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3498324932584343516) ) ) {
                  result[0] += -0.07761775612308272;
                } else {
                  result[0] += 0;
                }
              }
            }
          } else {
            result[0] += 0.039304134653879046;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6493078852189956285) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5271332674874372737) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001205500000000000191) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7250000000000000888) ) ) {
                  result[0] += -0.0006011028847314518;
                } else {
                  result[0] += -0.056160084091129006;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4750000000000000333) ) ) {
                  result[0] += 0.053725551538202396;
                } else {
                  result[0] += -0.0020757170545380476;
                }
              }
            } else {
              result[0] += -0.03248461305619569;
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
              result[0] += -0.009229367625486687;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001250500000000000092) ) ) {
                result[0] += 0.06047891282093066;
              } else {
                result[0] += -0.0027373114130587574;
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8509775102983480055) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7811682765315622889) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7341196086063838111) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450205000000000244) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4019627342713568141) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3321712357788945136) ) ) {
                result[0] += 0.04976580811512355;
              } else {
                result[0] += -0.01829575581878863;
              }
            } else {
              result[0] += 0.039075418801693344;
            }
          } else {
            result[0] += 0.10240565431867787;
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5841461392757277826) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.529830452742650726) ) ) {
              result[0] += 0.06414114737731572;
            } else {
              result[0] += 0.040388430538752365;
            }
          } else {
            result[0] += 0.07026718084302361;
          }
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6410891170561271446) ) ) {
          result[0] += 0.08183536876130441;
        } else {
          result[0] += 0.09999374459536406;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6800585241488680266) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4924412467785411196) ) ) {
          result[0] += 0.044710105333165384;
        } else {
          result[0] += 0.11316942508274946;
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7994052243814134817) ) ) {
          result[0] += 0.1308278715974643;
        } else {
          result[0] += 0.13829426401126904;
        }
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7024961766447593847) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5356561403784442232) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3768882457614676773) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2398531877347642449) ) ) {
          result[0] += -0.09847000411531993;
        } else {
          result[0] += -0.08887760420776968;
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4591620551040981879) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2198326728482087045) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4251092621105527214) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2650000000000000688) ) ) {
                result[0] += -0.05897958303960552;
              } else {
                result[0] += 0.009873295064633605;
              }
            } else {
              result[0] += -0.07362221007959466;
            }
          } else {
            result[0] += -0.0851752865944427;
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2384269498305124635) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.9211598665314141288) ) ) {
              result[0] += 0.007451629603671526;
            } else {
              result[0] += -0.05342570176163424;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003224500000000000369) ) ) {
              result[0] += -0.08181262376666797;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5065008974286485666) ) ) {
                result[0] += -0.0735988673106142;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1850000000000000255) ) ) {
                  result[0] += 0.011186671007155282;
                } else {
                  result[0] += -0.05681773512634124;
                }
              }
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6207300888023185026) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3308375782921226249) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6095226520848766594) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.038794232605861678) ) ) {
              result[0] += 0.017030861222248637;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3750000000000000555) ) ) {
                result[0] += -0.029065766235642408;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.457260671080300662) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01553850000000000196) ) ) {
                    result[0] += -0.042354140304954435;
                  } else {
                    result[0] += -0.08509650212285728;
                  }
                } else {
                  result[0] += 0.012111470699052468;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2944793848334646413) ) ) {
              result[0] += -0.029728322779866482;
            } else {
              result[0] += 0.03468880290475117;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003493500000000000511) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)2.800000000000000297e-05) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4750000000000000333) ) ) {
                result[0] += -0.04849057900237135;
              } else {
                result[0] += 0.029482210848109803;
              }
            } else {
              result[0] += -0.06514628965382367;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.578266620629892647) ) ) {
              result[0] += -0.06132197458182357;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7250000000000000888) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4613143568254923776) ) ) {
                  result[0] += -0.01846154505817528;
                } else {
                  result[0] += 0.04375511808089892;
                }
              } else {
                result[0] += -0.04188548269128413;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4350000000000000533) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6875734944390267112) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2850000000000000866) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5150000000000001243) ) ) {
                result[0] += 0.010417374708685312;
              } else {
                result[0] += 0.07969259698891665;
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6650000000000001465) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1275030000000000052) ) ) {
                  result[0] += -0.0004373233579490517;
                } else {
                  result[0] += -0.06177047183876938;
                }
              } else {
                result[0] += 0.024786025838536133;
              }
            }
          } else {
            result[0] += 0.04302670992892966;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6493078852189956285) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5271332674874372737) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3837516359296482826) ) ) {
                result[0] += -0.04381267118868897;
              } else {
                if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3699790940065486589) ) ) {
                  result[0] += 0.06097172857935133;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001205500000000000191) ) ) {
                    result[0] += -0.039674982778109505;
                  } else {
                    result[0] += 0.009651663441511702;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1765680711448399387) ) ) {
                result[0] += -0.04761046388564374;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6208328749497488142) ) ) {
                  result[0] += 0.006154967822824277;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6343929365935514486) ) ) {
                    result[0] += -0.0425800389220786;
                  } else {
                    result[0] += -0.0160881780684352;
                  }
                }
              }
            }
          } else {
            result[0] += -0.006429535153687051;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8509775102983480055) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7811682765315622889) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7341196086063838111) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4250000000000000444) ) ) {
            result[0] += 0.06991323279312504;
          } else {
            result[0] += 0.03273233370368769;
          }
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5676048066399036474) ) ) {
            result[0] += 0.05073842043497826;
          } else {
            result[0] += 0.06783620806390028;
          }
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6410891170561271446) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.8085344187842374852) ) ) {
            result[0] += 0.045778189468188;
          } else {
            result[0] += 0.07766183514578373;
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3797425373115578262) ) ) {
            result[0] += 0.06186542435285308;
          } else {
            result[0] += 0.09538162239383341;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6800585241488680266) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4924412467785411196) ) ) {
          result[0] += 0.041858398974757086;
        } else {
          result[0] += 0.10505711742756442;
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7994052243814134817) ) ) {
          result[0] += 0.12151044457973258;
        } else {
          result[0] += 0.128488962246526;
        }
      }
    }
  }
}

