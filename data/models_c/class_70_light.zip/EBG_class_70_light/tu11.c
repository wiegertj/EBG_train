
#include "header.h"

void predict_unit11(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7357947538897144923) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1596646965685780961) ) ) {
      result[0] += -0.0391930387269672;
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4447155022895915022) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
          result[0] += 0.037772091659395775;
        } else {
          result[0] += -0.012672330559846762;
        }
      } else {
        if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5797375516240159676) ) ) {
          result[0] += -0.0008518439411548241;
        } else {
          result[0] += 0.008212119234325055;
        }
      }
    }
  } else {
    result[0] += 0.03402561119266;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7497367709113804679) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1596646965685780961) ) ) {
      result[0] += -0.03895649899826868;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6222134205033998944) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 0.004362298386251437;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003591500000000000508) ) ) {
            result[0] += -0.01985341320785967;
          } else {
            result[0] += -0.001933535748637287;
          }
        }
      } else {
        result[0] += 0.0029880971021210103;
      }
    }
  } else {
    result[0] += 0.03442065630070541;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7497367709113804679) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1596646965685780961) ) ) {
      result[0] += -0.03871470232193966;
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4447155022895915022) ) ) {
        result[0] += -0.010639600912164511;
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.795922241633022054) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2150000000000000244) ) ) {
            result[0] += 0.018136869008028314;
          } else {
            result[0] += -0.0017677175879054737;
          }
        } else {
          result[0] += 0.007652065212682701;
        }
      }
    }
  } else {
    result[0] += 0.03403618897747283;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7497367709113804679) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1596646965685780961) ) ) {
      result[0] += -0.038467440224263495;
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4236855092944680212) ) ) {
        result[0] += -0.011109519287608335;
      } else {
        if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5797375516240159676) ) ) {
          result[0] += -0.0008870373744645067;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += 0.01831531604834057;
          } else {
            result[0] += 0.0018559558149584716;
          }
        }
      }
    }
  } else {
    result[0] += 0.033645561933339736;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7497367709113804679) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1596646965685780961) ) ) {
      result[0] += -0.038214504704250966;
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5055241589195451635) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3286632852763819446) ) ) {
          result[0] += 0.04287055882382823;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.000286500000000000025) ) ) {
            result[0] += 0.000646438364270163;
          } else {
            result[0] += -0.013431710008172573;
          }
        }
      } else {
        result[0] += 0.0014123348913375698;
      }
    }
  } else {
    result[0] += 0.03324876348317697;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7497367709113804679) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1596646965685780961) ) ) {
      result[0] += -0.03795571003015749;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6526844655663904815) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.650000000000000541e-05) ) ) {
          result[0] += 0.005006077757714859;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003591500000000000508) ) ) {
            result[0] += -0.016710401737061984;
          } else {
            result[0] += -0.0011689510960604305;
          }
        }
      } else {
        result[0] += 0.0031136347971736198;
      }
    }
  } else {
    result[0] += 0.03284579018463998;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.841376214053286442) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1596646965685780961) ) ) {
      result[0] += -0.03769087483323283;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.795922241633022054) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 0.00612483219703497;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001705500000000000202) ) ) {
            result[0] += -0.01343050043422471;
          } else {
            result[0] += -0.0011899527364401645;
          }
        }
      } else {
        result[0] += 0.007706574240404327;
      }
    }
  } else {
    result[0] += 0.03855572639804711;
  }
}

