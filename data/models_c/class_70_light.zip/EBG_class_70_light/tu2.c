
#include "header.h"

void predict_unit2(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.66684070898398351) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4447155022895915022) ) ) {
      result[0] += -0.05146902003093361;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5582897067648240341) ) ) {
        result[0] += -0.031367757076884134;
      } else {
        result[0] += -0.013597697115860842;
      }
    }
  } else {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8111300451949871038) ) ) {
      result[0] += 0.0171091331858085;
    } else {
      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6953050394685441615) ) ) {
        result[0] += 0.04483606521941855;
      } else {
        result[0] += 0.06218347131430109;
      }
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7221129311411039753) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5010423588193532174) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2925224498079027069) ) ) {
        result[0] += -0.053641694398409864;
      } else {
        result[0] += -0.03990022601428615;
      }
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6222134205033998944) ) ) {
        result[0] += -0.022584876515408726;
      } else {
        result[0] += -0.000541483803934448;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6415213458272231994) ) ) {
      result[0] += 0.030717924259912145;
    } else {
      result[0] += 0.05917990716323638;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7221129311411039753) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.492025658416472611) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.258569720040409734) ) ) {
        result[0] += -0.053497811166382275;
      } else {
        result[0] += -0.040375864610875695;
      }
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5966361188013137307) ) ) {
        result[0] += -0.024481514180013784;
      } else {
        result[0] += -0.002675977824163391;
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7051974671744832834) ) ) {
      result[0] += 0.029939636559714156;
    } else {
      result[0] += 0.0581701747485885;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.66684070898398351) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4447155022895915022) ) ) {
      result[0] += -0.04906902011183122;
    } else {
      result[0] += -0.020386939589756105;
    }
  } else {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8219148688594737351) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7560013597309228617) ) ) {
        result[0] += 0.007183481250663584;
      } else {
        result[0] += 0.028411219736551897;
      }
    } else {
      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7017935939707627968) ) ) {
        result[0] += 0.04188549649840557;
      } else {
        result[0] += 0.05878360861286179;
      }
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7221129311411039753) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4744068267591841637) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.258569720040409734) ) ) {
        result[0] += -0.052180242398416246;
      } else {
        result[0] += -0.03944056111158895;
      }
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5966361188013137307) ) ) {
        result[0] += -0.023764590545987316;
      } else {
        result[0] += -0.0022250936837676597;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6606907916086263155) ) ) {
      result[0] += 0.028809813409468765;
    } else {
      result[0] += 0.05660483474469827;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.66684070898398351) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4447155022895915022) ) ) {
      result[0] += -0.04761550336336742;
    } else {
      result[0] += -0.01899888793362624;
    }
  } else {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8588694953294175871) ) ) {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7560013597309228617) ) ) {
        result[0] += 0.006443500659356003;
      } else {
        result[0] += 0.028589913494600768;
      }
    } else {
      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7221143281151479743) ) ) {
        result[0] += 0.042451757108061976;
      } else {
        result[0] += 0.05721023669963811;
      }
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7322337689842495223) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5010423588193532174) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2925224498079027069) ) ) {
        result[0] += -0.05033477090237731;
      } else {
        result[0] += -0.03545446178395016;
      }
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6438205396169394135) ) ) {
        result[0] += -0.0175537117268287;
      } else {
        result[0] += 0.0024686298985601334;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6606907916086263155) ) ) {
      result[0] += 0.02807139153159841;
    } else {
      result[0] += 0.054687800559720785;
    }
  }
}

