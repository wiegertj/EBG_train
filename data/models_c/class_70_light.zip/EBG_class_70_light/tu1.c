
#include "header.h"

void predict_unit1(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6846866204190324989) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5010423588193532174) ) ) {
      result[0] += -0.057067648767832775;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5966361188013137307) ) ) {
        result[0] += -0.03242052529299664;
      } else {
        result[0] += -0.008924743887547503;
      }
    }
  } else {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8111300451949871038) ) ) {
      result[0] += 0.027242593339535194;
    } else {
      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6953050394685441615) ) ) {
        result[0] += 0.057064685633023145;
      } else {
        result[0] += 0.07489200217588587;
      }
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6988988994204462513) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5055241589195451635) ) ) {
      result[0] += -0.055658206733728746;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6438205396169394135) ) ) {
        result[0] += -0.026755576945640593;
      } else {
        result[0] += 0.001024802833786388;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6415213458272231994) ) ) {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.765966927815004861) ) ) {
        result[0] += 0.019347720841578597;
      } else {
        result[0] += 0.04698610476744859;
      }
    } else {
      result[0] += 0.07098605424458979;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6988988994204462513) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5010423588193532174) ) ) {
      result[0] += -0.054624680878374764;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6222134205033998944) ) ) {
        result[0] += -0.02797828637450866;
      } else {
        result[0] += -0.0024870943401450636;
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.677986157280416446) ) ) {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.765966927815004861) ) ) {
        result[0] += 0.01876022897318377;
      } else {
        result[0] += 0.04398111078449847;
      }
    } else {
      result[0] += 0.0681436383180071;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6752061090890135731) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4744068267591841637) ) ) {
      result[0] += -0.054339421783014714;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5966361188013137307) ) ) {
        result[0] += -0.030904642966471246;
      } else {
        result[0] += -0.00920208298505136;
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6276205892133321917) ) ) {
      result[0] += 0.0218315243859731;
    } else {
      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6953050394685441615) ) ) {
        result[0] += 0.05075262991615953;
      } else {
        result[0] += 0.06843616052760201;
      }
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7221129311411039753) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5506872176393086127) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2925224498079027069) ) ) {
        result[0] += -0.05707591700581824;
      } else {
        result[0] += -0.041272534040734034;
      }
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6438205396169394135) ) ) {
        result[0] += -0.01968170015773153;
      } else {
        result[0] += 0.0022948095494831787;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6415213458272231994) ) ) {
      result[0] += 0.036025967244095826;
    } else {
      result[0] += 0.0650699481162348;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7221129311411039753) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5010423588193532174) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2925224498079027069) ) ) {
        result[0] += -0.05612433890258628;
      } else {
        result[0] += -0.04291099650891805;
      }
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6438205396169394135) ) ) {
        result[0] += -0.023331949207448452;
      } else {
        result[0] += 0.0021940617435612054;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6415213458272231994) ) ) {
      result[0] += 0.03458662818245042;
    } else {
      result[0] += 0.0634022394371579;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7221129311411039753) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5055241589195451635) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2925224498079027069) ) ) {
        result[0] += -0.05523157233672161;
      } else {
        result[0] += -0.04167469914743397;
      }
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6222134205033998944) ) ) {
        result[0] += -0.023959372796689662;
      } else {
        result[0] += -0.00040326595601702334;
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7051974671744832834) ) ) {
      result[0] += 0.03362572173872301;
    } else {
      result[0] += 0.062088632568484604;
    }
  }
}

