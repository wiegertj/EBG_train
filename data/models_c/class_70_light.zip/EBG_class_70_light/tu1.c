
#include "header.h"

void predict_unit1(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7024961766447593847) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5356561403784442232) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4094140003309167386) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2398531877347642449) ) ) {
          result[0] += -0.09495560839791943;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)2.800000000000000297e-05) ) ) {
            result[0] += -0.07703808743266853;
          } else {
            result[0] += -0.08783649231860709;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1850000000000000255) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5017812602789092358) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.232676602354129819) ) ) {
              result[0] += -0.06068331779933392;
            } else {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1917993845848007251) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2097832671075833544) ) ) {
                  result[0] += -0.025131748452850468;
                } else {
                  result[0] += 0.05203478822386312;
                }
              } else {
                result[0] += -0.053353674780868506;
              }
            }
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2465526098716071257) ) ) {
              result[0] += 0.049703514042502325;
            } else {
              result[0] += -0.026965363672635564;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4591620551040981879) ) ) {
            result[0] += -0.07973578224397702;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2646878576133683825) ) ) {
              result[0] += -0.04789477103900977;
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
                result[0] += 0.005029971925378916;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003224500000000000369) ) ) {
                  result[0] += -0.07653437447043956;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.515143529846740944) ) ) {
                    result[0] += -0.06929066569858039;
                  } else {
                    result[0] += -0.05186712353301317;
                  }
                }
              }
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6207300888023185026) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3308375782921226249) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6095226520848766594) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.038794232605861678) ) ) {
              result[0] += 0.01597754904541017;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.311511335870277295) ) ) {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2328444889043961574) ) ) {
                  result[0] += -0.05248176303436352;
                } else {
                  result[0] += -0.005872107105803472;
                }
              } else {
                result[0] += -0.03616409282923496;
              }
            }
          } else {
            result[0] += 0.011882035485885704;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002458000000000000549) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)2.800000000000000297e-05) ) ) {
              result[0] += -0.028216706695779498;
            } else {
              result[0] += -0.06543303187321754;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5825139232263935041) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4150000000000000355) ) ) {
                result[0] += 0.007349644676873564;
              } else {
                result[0] += -0.057475816649203086;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2009713325329971767) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5720812349497489402) ) ) {
                  result[0] += -0.01864130491980498;
                } else {
                  result[0] += 0.03176973779494558;
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004677500000000000234) ) ) {
                  result[0] += -0.06633219122137181;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6430839056532664522) ) ) {
                    result[0] += -0.059035224937502996;
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5285027443659499058) ) ) {
                      result[0] += 0.042801768815072465;
                    } else {
                      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4461679595852909852) ) ) {
                        result[0] += -0.03877027703302164;
                      } else {
                        result[0] += 0.02017171648695307;
                      }
                    }
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4550000000000000711) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6875734944390267112) ) ) {
            result[0] += 0.0028933464538728098;
          } else {
            result[0] += 0.03442882003973807;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6493078852189956285) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5271332674874372737) ) ) {
              result[0] += -0.004206154586276455;
            } else {
              result[0] += -0.02895109187036234;
            }
          } else {
            result[0] += -0.006855593997284635;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8509775102983480055) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7811682765315622889) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7341196086063838111) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450205000000000244) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4019627342713568141) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3321712357788945136) ) ) {
                result[0] += 0.04415179788242711;
              } else {
                result[0] += -0.019506853411343797;
              }
            } else {
              result[0] += 0.03408085051459144;
            }
          } else {
            result[0] += 0.09161669799216104;
          }
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5676048066399036474) ) ) {
            result[0] += 0.047289092136556576;
          } else {
            result[0] += 0.06321604130562737;
          }
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6410891170561271446) ) ) {
          result[0] += 0.0708519728481721;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001338500000000000063) ) ) {
            result[0] += 0.07235520192376402;
          } else {
            result[0] += 0.09214444656330335;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6800585241488680266) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8898401904750864455) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6260154606475681893) ) ) {
            result[0] += 0.08290576030933615;
          } else {
            result[0] += 0.1023793684729828;
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += 0.10736639256203903;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8950000000000001288) ) ) {
              result[0] += 0.09324610450442673;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02431850000000000331) ) ) {
                result[0] += 0.0027363454452304517;
              } else {
                result[0] += 0.08493389166920225;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7994052243814134817) ) ) {
          result[0] += 0.11382111733608775;
        } else {
          result[0] += 0.12050887008849999;
        }
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7024961766447593847) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5265509790734695938) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3768882457614676773) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2398531877347642449) ) ) {
          result[0] += -0.09186482934280177;
        } else {
          result[0] += -0.08225293044610714;
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4546668074497933199) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2198326728482087045) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4251092621105527214) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2650000000000000688) ) ) {
                result[0] += -0.05173236810962479;
              } else {
                result[0] += 0.013477219273053015;
              }
            } else {
              result[0] += -0.06726648478766656;
            }
          } else {
            result[0] += -0.07940731241516753;
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2384269498305124635) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.9211598665314141288) ) ) {
              result[0] += 0.010331273466315433;
            } else {
              result[0] += -0.04935316399888089;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003224500000000000369) ) ) {
              result[0] += -0.07727992169401715;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1850000000000000255) ) ) {
                result[0] += -0.020417323750008067;
              } else {
                result[0] += -0.06309898658884307;
              }
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6207300888023185026) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4850000000000000422) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6697462251507538822) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.60363466147634115) ) ) {
                result[0] += -0.025290121028487923;
              } else {
                result[0] += 0.03824575037713481;
              }
            } else {
              result[0] += -0.040435722668328136;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7385208534170855099) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5777799923753693667) ) ) {
                result[0] += -0.04466096822062834;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4050000000000000822) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.338334957420099669) ) ) {
                    result[0] += 0.03830379662480494;
                  } else {
                    result[0] += -0.03586728962262819;
                  }
                } else {
                  result[0] += 0.08621691331717746;
                }
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8015857614321609814) ) ) {
                result[0] += -0.05411881208598409;
              } else {
                result[0] += 0.01044287540720003;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003493500000000000511) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5629295393739166542) ) ) {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.6652304509807559496) ) ) {
                result[0] += -0.004358849867997007;
              } else {
                result[0] += -0.0712714308374747;
              }
            } else {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3699790940065486589) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4797881463065327146) ) ) {
                  result[0] += 0.013387351547555182;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.60363466147634115) ) ) {
                    result[0] += -0.04557923973500979;
                  } else {
                    result[0] += 0.01759811815689822;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5950000000000000844) ) ) {
                  result[0] += -0.08225615836161111;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0009065000000000000792) ) ) {
                    result[0] += -0.06943210718178248;
                  } else {
                    result[0] += -0.04321200517128714;
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.578266620629892647) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05458764581207740246) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004095500000000001049) ) ) {
                  result[0] += 0.021456269495105634;
                } else {
                  result[0] += -0.03948977656847744;
                }
              } else {
                result[0] += -0.0578002990373157;
              }
            } else {
              result[0] += -0.02257822737073808;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4350000000000000533) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6875734944390267112) ) ) {
            result[0] += 0.004019911656257241;
          } else {
            result[0] += 0.03791248320541343;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6493078852189956285) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5271332674874372737) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3837516359296482826) ) ) {
                result[0] += -0.04131189725831991;
              } else {
                if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3699790940065486589) ) ) {
                  result[0] += 0.05726636489477019;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001205500000000000191) ) ) {
                    result[0] += -0.037317990111762955;
                  } else {
                    result[0] += 0.0092437035160094;
                  }
                }
              }
            } else {
              result[0] += -0.026417501546379566;
            }
          } else {
            result[0] += -0.0056501666057947415;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8509775102983480055) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7811682765315622889) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7341196086063838111) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4250000000000000444) ) ) {
            result[0] += 0.06259104458796874;
          } else {
            result[0] += 0.028399496623868065;
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5841461392757277826) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5379784667691398514) ) ) {
              result[0] += 0.051925826903878175;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001999500000000000409) ) ) {
                result[0] += 0.0003683780158225712;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00657450000000000135) ) ) {
                  result[0] += 0.06017467855110643;
                } else {
                  result[0] += 0.021875721114079483;
                }
              }
            }
          } else {
            result[0] += 0.05704938178622158;
          }
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6410891170561271446) ) ) {
          result[0] += 0.06624256552119757;
        } else {
          result[0] += 0.08122215073606284;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6800585241488680266) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4924412467785411196) ) ) {
          result[0] += 0.03400168976649421;
        } else {
          result[0] += 0.09225708874903378;
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8373354933349520524) ) ) {
          result[0] += 0.10828976681903857;
        } else {
          result[0] += 0.11428922640686162;
        }
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7024961766447593847) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.515143529846740944) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3332847007720058374) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2252442705517153365) ) ) {
          result[0] += -0.08932059946796131;
        } else {
          result[0] += -0.0811187978095646;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4321942852785685685) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1208111730155778524) ) ) {
            result[0] += -0.054317237705152524;
          } else {
            result[0] += -0.07592960891875931;
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2792435502835992067) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6732382808793971884) ) ) {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.038794232605861678) ) ) {
                result[0] += 0.010501450468918769;
              } else {
                result[0] += -0.05688302400081945;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2850000000000000866) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1077145000000000047) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4150000000000000355) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2150000000000000244) ) ) {
                      result[0] += 0.07117445029616826;
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7704717287437187201) ) ) {
                        result[0] += -0.027268864914945908;
                      } else {
                        result[0] += 0.02402624760651617;
                      }
                    }
                  } else {
                    result[0] += -0.06525728695636601;
                  }
                } else {
                  result[0] += -0.07348405993044271;
                }
              } else {
                result[0] += -0.069447355321637;
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003224500000000000369) ) ) {
              result[0] += -0.07716409434329266;
            } else {
              result[0] += -0.06376827782731313;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6207300888023185026) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4850000000000000422) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5356561403784442232) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6066922323869347045) ) ) {
              result[0] += -0.05404770050378578;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3956994328239594738) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3108711457841912273) ) ) {
                  result[0] += -0.019514049240999243;
                } else {
                  result[0] += 0.08811413772908532;
                }
              } else {
                result[0] += -0.03621187715881118;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6095226520848766594) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3750000000000000555) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6796249047236181395) ) ) {
                  result[0] += -0.022865009862891045;
                } else {
                  result[0] += 0.01214150123365281;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8015857614321609814) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8458243956458841861) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6487317068090453498) ) ) {
                      result[0] += -0.04035940525126668;
                    } else {
                      result[0] += -0.002623420026229501;
                    }
                  } else {
                    result[0] += -0.07938586817202273;
                  }
                } else {
                  result[0] += 0.0322782421106058;
                }
              }
            } else {
              result[0] += 0.010317896199553311;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003493500000000000511) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5629295393739166542) ) ) {
              result[0] += -0.06735096266006786;
            } else {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3699790940065486589) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4850000000000000422) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4797881463065327146) ) ) {
                    result[0] += 0.01741191778769877;
                  } else {
                    result[0] += -0.04549868939822356;
                  }
                } else {
                  result[0] += 0.03462354522747288;
                }
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5950000000000000844) ) ) {
                  result[0] += -0.07914809837285293;
                } else {
                  result[0] += -0.047960724243288705;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.578266620629892647) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
                result[0] += 0.0004502906683062562;
              } else {
                result[0] += -0.05240291376550143;
              }
            } else {
              result[0] += -0.021258820238820447;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4750000000000000333) ) ) {
          result[0] += 0.005272296663932276;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6343929365935514486) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6950000000000000622) ) ) {
              result[0] += -0.008954910280637328;
            } else {
              result[0] += -0.03978555765255882;
            }
          } else {
            result[0] += -0.007890670538795868;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8572185734818382752) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7811682765315622889) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7341196086063838111) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450205000000000244) ) ) {
            result[0] += 0.0275182911372158;
          } else {
            result[0] += 0.0829904604751429;
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9350000000000001643) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5245354220245331822) ) ) {
              result[0] += 0.05038237275249895;
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.469327283602055445) ) ) {
                result[0] += 0.07657113729960324;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5612777274623116375) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6550000000000001377) ) ) {
                    result[0] += 0.0008826622282279152;
                  } else {
                    result[0] += 0.036864257544397;
                  }
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002395500000000000494) ) ) {
                    result[0] += 0.010716836633331558;
                  } else {
                    result[0] += 0.049445099605667134;
                  }
                }
              }
            }
          } else {
            result[0] += 0.05448085157138732;
          }
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6410891170561271446) ) ) {
          result[0] += 0.06239273912404362;
        } else {
          result[0] += 0.07727610272789626;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6800585241488680266) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4924412467785411196) ) ) {
          result[0] += 0.022594687148918567;
        } else {
          result[0] += 0.08765839707029832;
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7994052243814134817) ) ) {
          result[0] += 0.10182559075497627;
        } else {
          result[0] += 0.10833769368218493;
        }
      }
    }
  }
}

