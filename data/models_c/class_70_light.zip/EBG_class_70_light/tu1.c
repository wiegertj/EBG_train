
#include "header.h"

void predict_unit1(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6988115259217656527) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5201676432420939689) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2965188918505100024) ) ) {
        result[0] += -0.03986708974138531;
      } else {
        result[0] += -0.03265112884963274;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6038797007738568867) ) ) {
        result[0] += -0.020514205389819653;
      } else {
        result[0] += -0.005837440149807405;
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.844661369991607125) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7449878528029710845) ) ) {
        result[0] += 0.01084852017025226;
      } else {
        if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6226783190417196634) ) ) {
          result[0] += 0.022237857833486578;
        } else {
          result[0] += 0.03301919718748105;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7141856296356029477) ) ) {
        result[0] += 0.04080623062462217;
      } else {
        result[0] += 0.04935493095680192;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6988115259217656527) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5201676432420939689) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2965188918505100024) ) ) {
        result[0] += -0.03929303610625196;
      } else {
        result[0] += -0.03208066169205792;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6038797007738568867) ) ) {
        result[0] += -0.020059463169537325;
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.655609054534752711) ) ) {
          result[0] += -0.010378239100157866;
        } else {
          result[0] += 0;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6840531608062441205) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7640407544788561101) ) ) {
        result[0] += 0.013390815520641378;
      } else {
        result[0] += 0.029688401404210484;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.733482828522406094) ) ) {
        result[0] += 0.04203595649066198;
      } else {
        result[0] += 0.048394154683724086;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.704198211736497548) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5201676432420939689) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2965188918505100024) ) ) {
        result[0] += -0.03874737308373188;
      } else {
        result[0] += -0.031529900671682744;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6320766827776574948) ) ) {
        result[0] += -0.017707123010010612;
      } else {
        result[0] += -0.0025525164299044713;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6840531608062441205) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7693651808594642594) ) ) {
        result[0] += 0.014299651024321734;
      } else {
        if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.607134570361309911) ) ) {
          result[0] += 0.022251678201179844;
        } else {
          result[0] += 0.03257214743105215;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.733482828522406094) ) ) {
        result[0] += 0.04103764264937785;
      } else {
        result[0] += 0.04734454768507399;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6988115259217656527) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5201676432420939689) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2965188918505100024) ) ) {
        result[0] += -0.03822802657209063;
      } else {
        result[0] += -0.030997446955833608;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6038797007738568867) ) ) {
        result[0] += -0.019226662997292858;
      } else {
        result[0] += -0.00535888979492975;
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.844661369991607125) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7352869986369691135) ) ) {
        result[0] += 0.007832338249952036;
      } else {
        if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6226783190417196634) ) ) {
          result[0] += 0.01974951944905287;
        } else {
          result[0] += 0.030267350493753484;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7141856296356029477) ) ) {
        result[0] += 0.037929785413906;
      } else {
        result[0] += 0.04621197168865225;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6988115259217656527) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5201676432420939689) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2965188918505100024) ) ) {
        result[0] += -0.03773311409594113;
      } else {
        result[0] += -0.030482026218746083;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6038797007738568867) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3650000000000000466) ) ) {
          result[0] += -0.012546442043278342;
        } else {
          result[0] += -0.023306245012788888;
        }
      } else {
        result[0] += -0.00521988929726428;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6840531608062441205) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7580984751822718026) ) ) {
        result[0] += 0.011628395121173588;
      } else {
        result[0] += 0.02708469410727759;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.733482828522406094) ) ) {
        result[0] += 0.039230292816171124;
      } else {
        result[0] += 0.04545101989218969;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.704198211736497548) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5365113871239524101) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4243526687260518182) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2268996455050684702) ) ) {
          result[0] += -0.03779935314132429;
        } else {
          result[0] += -0.03329457787807661;
        }
      } else {
        result[0] += -0.02615454564014138;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.655609054534752711) ) ) {
        result[0] += -0.014192052875240441;
      } else {
        result[0] += 0.0006699341597603981;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6840531608062441205) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7693651808594642594) ) ) {
        result[0] += 0.01308118787322659;
      } else {
        result[0] += 0.02710991718799512;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7141856296356029477) ) ) {
        result[0] += 0.03778911650480611;
      } else {
        result[0] += 0.04444081898775959;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6988115259217656527) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5201676432420939689) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2965188918505100024) ) ) {
        result[0] += -0.03681355439184119;
      } else {
        result[0] += -0.02949630641682481;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6038797007738568867) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3650000000000000466) ) ) {
          result[0] += -0.011840746804338526;
        } else {
          result[0] += -0.02250019146970306;
        }
      } else {
        result[0] += -0.004892506223155892;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6840531608062441205) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7580984751822718026) ) ) {
        result[0] += 0.010976735410732325;
      } else {
        result[0] += 0.0257462524531916;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7141856296356029477) ) ) {
        result[0] += 0.03698066875303297;
      } else {
        result[0] += 0.043634254240567744;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.704198211736497548) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5201676432420939689) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2965188918505100024) ) ) {
        result[0] += -0.036382056844028295;
      } else {
        result[0] += -0.02902537389083191;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6320766827776574948) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3650000000000000466) ) ) {
          result[0] += -0.01020166348701725;
        } else {
          result[0] += -0.019104382649118345;
        }
      } else {
        result[0] += -0.0020454216852585838;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6840531608062441205) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7693651808594642594) ) ) {
        result[0] += 0.012360458730778168;
      } else {
        result[0] += 0.02579899741513633;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7141856296356029477) ) ) {
        result[0] += 0.03620982657972177;
      } else {
        result[0] += 0.042875195343326324;
      }
    }
  }
}

