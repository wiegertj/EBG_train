
#include "header.h"

void predict_unit6(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7074300481310827893) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4591620551040981879) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2656063113060950776) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1247736973015392964) ) ) {
          result[0] += -0.07223315740999484;
        } else {
          result[0] += -0.06446159913642367;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)2.800000000000000297e-05) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883661844891582726) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03500000000000001027) ) ) {
              result[0] += 0.0005987296019855104;
            } else {
              result[0] += -0.044181119244822285;
            }
          } else {
            result[0] += 0.012207701357533936;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004872500000000000962) ) ) {
            result[0] += -0.05969453299873937;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.038112519465065331) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7385208534170855099) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4094140003309167386) ) ) {
                    result[0] += -0.050380730124771365;
                  } else {
                    result[0] += -0.03176615880131625;
                  }
                } else {
                  result[0] += 0.053610948038178195;
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.051391296366422923) ) ) {
                  result[0] += 0.09055925295473165;
                } else {
                  result[0] += -0.007119781711358301;
                }
              }
            } else {
              result[0] += -0.06457328864985393;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5825139232263935041) ) ) {
        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 0.019382479836117506;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5356561403784442232) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2384269498305124635) ) ) {
              result[0] += -0.021311687350641123;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003224500000000000369) ) ) {
                result[0] += -0.048047441767630074;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5065008974286485666) ) ) {
                  result[0] += -0.03994811688056861;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.25500000000000006) ) ) {
                      result[0] += 0.04820054978140398;
                    } else {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.545000000000000151) ) ) {
                        result[0] += -0.02107692578065834;
                      } else {
                        result[0] += 0.053707747824639995;
                      }
                    }
                  } else {
                    result[0] += -0.0320294165550599;
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3865950184387632049) ) ) {
              result[0] += -0.012818142650036562;
            } else {
              result[0] += -0.03369096701655686;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6592877443879057164) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002786500000000000348) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              result[0] += 0.0029310313600890343;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5850000000000000755) ) ) {
                result[0] += -0.054396097373044426;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0005375000000000001088) ) ) {
                  result[0] += -0.04596721545656945;
                } else {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.08110515786938453375) ) ) {
                    if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2795185878002977575) ) ) {
                      result[0] += -0.022467953808400415;
                    } else {
                      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7150000000000000799) ) ) {
                        result[0] += 0.06618299541215465;
                      } else {
                        result[0] += 0.009024994304566077;
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8950000000000001288) ) ) {
                      result[0] += -0.01604848027112795;
                    } else {
                      result[0] += -0.045491090760393225;
                    }
                  }
                }
              }
            }
          } else {
            result[0] += -0.004432502019638377;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4250000000000000444) ) ) {
            result[0] += -0.028197161479912233;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3850000000000000644) ) ) {
              result[0] += 0.026377418186242816;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0003885000000000000649) ) ) {
                result[0] += 0.02282480667859532;
              } else {
                result[0] += -0.0012164828637216789;
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6602742250004863811) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8207002514789815129) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6380671833187036013) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7638123743065539095) ) ) {
            result[0] += 0.014849940427857132;
          } else {
            result[0] += 0.025182798292184658;
          }
        } else {
          result[0] += 0.034138996241641975;
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5468583209944909429) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.875000000000000111) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.7550000000000001155) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4549440021356783714) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3061180769095477872) ) ) {
                  result[0] += 0.06288920688968726;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.625000000000000111) ) ) {
                    result[0] += 0.03448167207473611;
                  } else {
                    if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.469327283602055445) ) ) {
                      result[0] += -0.07340069086136508;
                    } else {
                      result[0] += 0.009422053510002918;
                    }
                  }
                }
              } else {
                result[0] += 0.0531085642696307;
              }
            } else {
              result[0] += -0.01053077441493066;
            }
          } else {
            result[0] += -0.005545274888713252;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9350000000000001643) ) ) {
            result[0] += 0.05561058255295321;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8650000000000001021) ) ) {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6173059481599049159) ) ) {
                result[0] += 0.033027124467333885;
              } else {
                result[0] += 0.04928043525677638;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04236850000000001032) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01437650000000000212) ) ) {
                  result[0] += 0.024583213465118724;
                } else {
                  result[0] += -0.05082342700253703;
                }
              } else {
                result[0] += 0.05972893171107727;
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7994052243814134817) ) ) {
        result[0] += 0.06409223843088958;
      } else {
        result[0] += 0.07606767887701285;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6976830617481789565) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4411376887452597706) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2398531877347642449) ) ) {
        result[0] += -0.06894576908470468;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883661844891582726) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03500000000000001027) ) ) {
              result[0] += -0.005226790462686253;
            } else {
              result[0] += -0.04504744627206464;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3332847007720058374) ) ) {
              result[0] += -0.04693226579461603;
            } else {
              result[0] += 0.06583252613352837;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005384500000000001264) ) ) {
            result[0] += -0.06019283361399951;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9993516786272610419) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4094140003309167386) ) ) {
                  result[0] += -0.048533264482042336;
                } else {
                  result[0] += -0.026661211808243643;
                }
              } else {
                result[0] += 0.01737852759558477;
              }
            } else {
              result[0] += -0.06601686301724294;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5629295393739166542) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4850000000000000422) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5265509790734695938) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2108884567369299912) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6732382808793971884) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2050000000000000433) ) ) {
                  result[0] += -0.05053133543217125;
                } else {
                  result[0] += -0.017142275098735484;
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2850000000000000866) ) ) {
                  result[0] += 0.03673689838589127;
                } else {
                  result[0] += -0.03915037116383605;
                }
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4976396106036372058) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
                  result[0] += -0.03075832725573658;
                } else {
                  result[0] += -0.0513344672097355;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1950000000000000344) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4395917154773869573) ) ) {
                    result[0] += -0.04115024621474748;
                  } else {
                    if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.01051018765715429869) ) ) {
                      result[0] += 0.06807322881134531;
                    } else {
                      result[0] += -0.015221276791397571;
                    }
                  }
                } else {
                  result[0] += -0.029976974478150006;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04288995536428370087) ) ) {
              result[0] += -0.02337904839411149;
            } else {
              result[0] += 0;
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002242500000000000569) ) ) {
            result[0] += -0.04787857792088992;
          } else {
            result[0] += -0.02998484321481579;
          }
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.625707420288709959) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4250000000000000444) ) ) {
            result[0] += -0.005179569753814143;
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3743550388432587694) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5934571403915865906) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8308152110804021273) ) ) {
                  result[0] += -0.031389475847070004;
                } else {
                  result[0] += 0.03449247347947317;
                }
              } else {
                result[0] += 0.006521099554561712;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001376500000000000336) ) ) {
                result[0] += -0.045827254157467426;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08425129245607926309) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4513182083490158703) ) ) {
                    result[0] += -0.0206003873886226;
                  } else {
                    if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.316132418552224348) ) ) {
                      result[0] += -0.0492250612219182;
                    } else {
                      result[0] += 0.039319396729256315;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7379591540954774098) ) ) {
                    result[0] += -0.0434767028389921;
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9567162861906464144) ) ) {
                      result[0] += 0.031948378738430414;
                    } else {
                      result[0] += -0.030007645417077067;
                    }
                  }
                }
              }
            }
          }
        } else {
          result[0] += -0.0024048562153247658;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6602742250004863811) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7952348873182119027) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7341196086063838111) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += 0.04850027244953931;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1705550000000000399) ) ) {
              result[0] += 0.007544018011047917;
            } else {
              result[0] += 0.07182792003375894;
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9350000000000001643) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6650000000000001465) ) ) {
              result[0] += 0.019766248071855175;
            } else {
              result[0] += 0.000534494953210833;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.323165429195979903) ) ) {
              result[0] += -0.03297516521628761;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5288010847236181977) ) ) {
                result[0] += 0.04228677752768814;
              } else {
                result[0] += 0.023346943658698764;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8898401904750864455) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00101050000000000033) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)2.800000000000000297e-05) ) ) {
              result[0] += 0.04887716611716473;
            } else {
              result[0] += 0.003755555561908066;
            }
          } else {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6260154606475681893) ) ) {
              result[0] += 0.0326108393496638;
            } else {
              result[0] += 0.05021421441237904;
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9550000000000000711) ) ) {
            result[0] += 0.05700270080032027;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8450000000000000844) ) ) {
              result[0] += 0.044326542490311156;
            } else {
              result[0] += 0.002367920850551675;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7994052243814134817) ) ) {
        result[0] += 0.06240673883725612;
      } else {
        result[0] += 0.07491824351238212;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7074300481310827893) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4411376887452597706) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2398531877347642449) ) ) {
        result[0] += -0.0681177142216976;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883661844891582726) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03500000000000001027) ) ) {
              result[0] += -0.00492413337934725;
            } else {
              result[0] += -0.043515386898283395;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8789704397738694608) ) ) {
              result[0] += 0.06872818985672882;
            } else {
              result[0] += -0.037842330726110256;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005384500000000001264) ) ) {
            result[0] += -0.058884222336405764;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9993516786272610419) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4240924208358586855) ) ) {
                  result[0] += -0.04550186125573379;
                } else {
                  result[0] += -0.01832380481602065;
                }
              } else {
                result[0] += 0.016172813128498373;
              }
            } else {
              result[0] += -0.06484880999005159;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5629295393739166542) ) ) {
        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 0.023157604594941913;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1650000000000000355) ) ) {
            result[0] += -0.0015128028038079017;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.515143529846740944) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2792435502835992067) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6732382808793971884) ) ) {
                  result[0] += -0.03130881390714806;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2850000000000000866) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1000410000000000188) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7753767533919598831) ) ) {
                        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2131467803247103221) ) ) {
                          result[0] += 0.05916157736063837;
                        } else {
                          result[0] += -0.016468221870166146;
                        }
                      } else {
                        result[0] += 0.08937591596752724;
                      }
                    } else {
                      result[0] += -0.05973028900532301;
                    }
                  } else {
                    result[0] += -0.04639277896606746;
                  }
                }
              } else {
                result[0] += -0.042478434215138916;
              }
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3865950184387632049) ) ) {
                result[0] += -0.01732785199922356;
              } else {
                result[0] += -0.03932617796239892;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.625707420288709959) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4250000000000000444) ) ) {
            result[0] += -0.004860990385351605;
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3743550388432587694) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5934571403915865906) ) ) {
                result[0] += -0.024606214526606236;
              } else {
                result[0] += 0.006100395423825138;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001376500000000000336) ) ) {
                result[0] += -0.0440187019666588;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08425129245607926309) ) ) {
                  result[0] += -0.003746351823378382;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7379591540954774098) ) ) {
                    result[0] += -0.0415488124659361;
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9567162861906464144) ) ) {
                      result[0] += 0.029621320262910044;
                    } else {
                      result[0] += -0.028562174587316583;
                    }
                  }
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8517455601758795458) ) ) {
            result[0] += -0.0019631742270051046;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.679442381639573378) ) ) {
              result[0] += 0.08481359200705116;
            } else {
              result[0] += -0.00037258196624756826;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6675308230823290279) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8207002514789815129) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6380671833187036013) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7638123743065539095) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6550000000000001377) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6750000000000001554) ) ) {
                result[0] += 0.0017160953707647097;
              } else {
                result[0] += 0.017704971128697802;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4748963933302909335) ) ) {
                result[0] += 0.012865427073388577;
              } else {
                result[0] += -0.02516189322334703;
              }
            }
          } else {
            result[0] += 0.022460867107000973;
          }
        } else {
          result[0] += 0.030823637754874098;
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5468583209944909429) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.875000000000000111) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.7550000000000001155) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4573392949246231631) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3061180769095477872) ) ) {
                  result[0] += 0.059107622231565064;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.625000000000000111) ) ) {
                    result[0] += 0.03392686062715946;
                  } else {
                    if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.469327283602055445) ) ) {
                      result[0] += -0.07054808876952602;
                    } else {
                      result[0] += 0.0037168211280071816;
                    }
                  }
                }
              } else {
                result[0] += 0.0495918335616237;
              }
            } else {
              result[0] += -0.012631441180046476;
            }
          } else {
            result[0] += -0.007419803392809389;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9350000000000001643) ) ) {
            result[0] += 0.05205374540754998;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8450000000000000844) ) ) {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6173059481599049159) ) ) {
                result[0] += 0.029856573691778056;
              } else {
                result[0] += 0.046975451561327625;
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3895344436180904757) ) ) {
                result[0] += 0.05326186548297041;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4523612661809045532) ) ) {
                  result[0] += -0.07283424568371966;
                } else {
                  result[0] += 0.011909713018739904;
                }
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7994052243814134817) ) ) {
        result[0] += 0.061520028532015575;
      } else {
        result[0] += 0.07385442770568228;
      }
    }
  }
}

