
#include "header.h"

void predict_unit6(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.655609054534752711) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4243526687260518182) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2002749652849908635) ) ) {
        result[0] += -0.029339676913475395;
      } else {
        result[0] += -0.02223406325168724;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5524193294893345874) ) ) {
        result[0] += -0.01351986783817098;
      } else {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.3399990879818117206) ) ) {
          result[0] += 0.0006066526952211271;
        } else {
          result[0] += -0.008777075244452448;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6967761054388647013) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7693651808594642594) ) ) {
        result[0] += 0.0031725626473473683;
      } else {
        result[0] += 0.012873814505643524;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.733482828522406094) ) ) {
        result[0] += 0.0223018134329215;
      } else {
        result[0] += 0.030870990781111718;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7352869986369691135) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4471985607798013018) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2268996455050684702) ) ) {
        result[0] += -0.02883957140802929;
      } else {
        result[0] += -0.021044702247202115;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5991184370131029668) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4450000000000000622) ) ) {
          result[0] += -0.007287440676296259;
        } else {
          result[0] += -0.014183100530266527;
        }
      } else {
        result[0] += -0.0006559859569151398;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6602317995497481995) ) ) {
      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.637063197009426152) ) ) {
        result[0] += 0.008029720357029093;
      } else {
        result[0] += 0.016034430518069045;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.746072903742064919) ) ) {
        result[0] += 0.023581871505563855;
      } else {
        result[0] += 0.03082803566275223;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.655609054534752711) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4243526687260518182) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2002749652849908635) ) ) {
        result[0] += -0.029062690376560004;
      } else {
        result[0] += -0.02173232776869421;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5409223905044490133) ) ) {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.2209082565809930565) ) ) {
          result[0] += -0.00525370390757158;
        } else {
          result[0] += -0.016310910745968292;
        }
      } else {
        result[0] += -0.0057432307609716115;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6967761054388647013) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.607134570361309911) ) ) {
        result[0] += 0.0035174440088841423;
      } else {
        result[0] += 0.013113799727164954;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.733482828522406094) ) ) {
        result[0] += 0.02168859659622901;
      } else {
        result[0] += 0.030505256383652306;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7352869986369691135) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4471985607798013018) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2178518179945141686) ) ) {
        result[0] += -0.02868179047635791;
      } else {
        result[0] += -0.020671165015431953;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5754236634526536109) ) ) {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.2459704571246580096) ) ) {
          result[0] += -0.004547591572435099;
        } else {
          result[0] += -0.013541480948328083;
        }
      } else {
        result[0] += -0.001300212540812931;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6602317995497481995) ) ) {
      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.637063197009426152) ) ) {
        result[0] += 0.00766958104696628;
      } else {
        result[0] += 0.01542146677923761;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.746072903742064919) ) ) {
        result[0] += 0.02300110541102773;
      } else {
        result[0] += 0.030477551338859862;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7352869986369691135) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4471985607798013018) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2721741080702284044) ) ) {
        result[0] += -0.0277764598852053;
      } else {
        result[0] += -0.019411084605095944;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5754236634526536109) ) ) {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.2459704571246580096) ) ) {
          result[0] += -0.004436684285988113;
        } else {
          result[0] += -0.01327558434060317;
        }
      } else {
        result[0] += -0.0012655255755268755;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6602317995497481995) ) ) {
      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.637063197009426152) ) ) {
        result[0] += 0.007478607326174529;
      } else {
        result[0] += 0.0151164802493987;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.746072903742064919) ) ) {
        result[0] += 0.022709603726620717;
      } else {
        result[0] += 0.030308819298528824;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.655609054534752711) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4243526687260518182) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2002749652849908635) ) ) {
        result[0] += -0.02867002122522494;
      } else {
        result[0] += -0.02098531117371256;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5365113871239524101) ) ) {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.2209082565809930565) ) ) {
          result[0] += -0.004522808735480843;
        } else {
          result[0] += -0.015999582207040473;
        }
      } else {
        result[0] += -0.00549111236885251;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6549621339660968156) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7877973938526349196) ) ) {
        result[0] += 0.003389308173605288;
      } else {
        result[0] += 0.01322530216390292;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.746072903742064919) ) ) {
        result[0] += 0.022184887403704463;
      } else {
        result[0] += 0.03014438714912704;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7352869986369691135) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4471985607798013018) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2268996455050684702) ) ) {
        result[0] += -0.028147573315055074;
      } else {
        result[0] += -0.0197641826448945;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.622330635648172481) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += -0.0017177295124269926;
        } else {
          result[0] += -0.010608391111359874;
        }
      } else {
        result[0] += 0.0002268171757816081;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6602317995497481995) ) ) {
      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.637063197009426152) ) ) {
        result[0] += 0.007096151946553078;
      } else {
        result[0] += 0.014579869130514414;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.746072903742064919) ) ) {
        result[0] += 0.022138775969590088;
      } else {
        result[0] += 0.029984027346129666;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7352869986369691135) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4471985607798013018) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2178518179945141686) ) ) {
        result[0] += -0.028150709304361383;
      } else {
        result[0] += -0.01965707825776454;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5754236634526536109) ) ) {
        result[0] += -0.01026776485426193;
      } else {
        result[0] += -0.0011459047082849763;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6602317995497481995) ) ) {
      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6179594490196074208) ) ) {
        result[0] += 0.006040923610119187;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9350000000000001643) ) ) {
          result[0] += 0.02010135218498875;
        } else {
          result[0] += 0.010268496937319498;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.746072903742064919) ) ) {
        result[0] += 0.021856097808164138;
      } else {
        result[0] += 0.02982752283390901;
      }
    }
  }
}

