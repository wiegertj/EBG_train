
#include "header.h"

void predict_unit6(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.795922241633022054) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4045448672742624763) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1596646965685780961) ) ) {
        result[0] += -0.0455612003706816;
      } else {
        result[0] += -0.029126601421902223;
      }
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6438205396169394135) ) ) {
        result[0] += -0.010905336242412814;
      } else {
        result[0] += 0.0029093703206278464;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7286792202408863828) ) ) {
      result[0] += 0.020715601663248474;
    } else {
      result[0] += 0.04508799966644244;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5797375516240159676) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4045448672742624763) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1596646965685780961) ) ) {
        result[0] += -0.04534528657769839;
      } else {
        result[0] += -0.028538183059784752;
      }
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6222134205033998944) ) ) {
        result[0] += -0.011234762373584988;
      } else {
        result[0] += 0.002243427568646737;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7286792202408863828) ) ) {
      result[0] += 0.020994544933391934;
    } else {
      result[0] += 0.044744734824134755;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.795922241633022054) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4045448672742624763) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1596646965685780961) ) ) {
        result[0] += -0.04513448473129243;
      } else {
        result[0] += -0.027952007153601195;
      }
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5506872176393086127) ) ) {
        result[0] += -0.014477921025472117;
      } else {
        result[0] += -0.000176828205514483;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7286792202408863828) ) ) {
      result[0] += 0.019580335894339062;
    } else {
      result[0] += 0.04440770657042455;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5797375516240159676) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3474450840415687081) ) ) {
      result[0] += -0.03727913974515199;
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5506872176393086127) ) ) {
        result[0] += -0.015037685553244069;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004746500000000001586) ) ) {
          result[0] += -0.007272986426569272;
        } else {
          result[0] += 0.005508267072781498;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7286792202408863828) ) ) {
      result[0] += 0.019871626976586704;
    } else {
      result[0] += 0.04407610924364458;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5797375516240159676) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3474450840415687081) ) ) {
      result[0] += -0.03682965177637182;
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5506872176393086127) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002245000000000000088) ) ) {
          result[0] += 0.0027768155515201323;
        } else {
          result[0] += -0.0192382380913222;
        }
      } else {
        result[0] += 0;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7286792202408863828) ) ) {
      result[0] += 0.019221676287361725;
    } else {
      result[0] += 0.04374919613921857;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8111300451949871038) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2925224498079027069) ) ) {
      result[0] += -0.039053455385076756;
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5431651591220142405) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.650000000000000541e-05) ) ) {
          result[0] += -9.595387980389831e-05;
        } else {
          result[0] += -0.01989447286625039;
        }
      } else {
        result[0] += -7.414383266102124e-05;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7357947538897144923) ) ) {
      result[0] += 0.01951970613986564;
    } else {
      result[0] += 0.043629494220270106;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8111300451949871038) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2925224498079027069) ) ) {
      result[0] += -0.038667809489817455;
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5431651591220142405) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.650000000000000541e-05) ) ) {
          result[0] += -9.178208122253527e-05;
        } else {
          result[0] += -0.019310651733673783;
        }
      } else {
        result[0] += -7.091372238129839e-05;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7286792202408863828) ) ) {
      result[0] += 0.01868154074966471;
    } else {
      result[0] += 0.043108146815024166;
    }
  }
}

