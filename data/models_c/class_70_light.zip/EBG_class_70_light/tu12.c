
#include "header.h"

void predict_unit12(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.841376214053286442) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2025449053348033213) ) ) {
      result[0] += -0.03197586001555467;
    } else {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5797375516240159676) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 0.006990407480761002;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004471500000000000648) ) ) {
            result[0] += -0.01124707448997897;
          } else {
            result[0] += 0.0011577064491520629;
          }
        }
      } else {
        result[0] += 0.007911925224354821;
      }
    }
  } else {
    result[0] += 0.038292993890376235;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.841376214053286442) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1596646965685780961) ) ) {
      result[0] += -0.037183282610576615;
    } else {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5447856234025308941) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4045448672742624763) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
            result[0] += 0.03857069938044096;
          } else {
            result[0] += -0.012878615590162457;
          }
        } else {
          result[0] += -0.0010358319336864806;
        }
      } else {
        result[0] += 0.006268080318686024;
      }
    }
  } else {
    result[0] += 0.03802468744069191;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.841376214053286442) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1596646965685780961) ) ) {
      result[0] += -0.036900282945325026;
    } else {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5797375516240159676) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.02630441138307944;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += 0.005438127420708948;
          } else {
            result[0] += -0.004017945701685743;
          }
        }
      } else {
        result[0] += 0.007365911588877914;
      }
    }
  } else {
    result[0] += 0.03775061343797771;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.841376214053286442) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1221034598319439696) ) ) {
      result[0] += -0.040772588683718705;
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4045448672742624763) ) ) {
        result[0] += -0.010936487152911295;
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8588694953294175871) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1850000000000000255) ) ) {
            result[0] += 0.020192888389800556;
          } else {
            result[0] += -0.0009136842173190507;
          }
        } else {
          result[0] += 0.009106758254601574;
        }
      }
    }
  } else {
    result[0] += 0.03747058504354173;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.841376214053286442) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1221034598319439696) ) ) {
      result[0] += -0.04061011149536677;
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4236855092944680212) ) ) {
        result[0] += -0.010018177033047734;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003591500000000000508) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += 0.008995584290871566;
          } else {
            result[0] += -0.006307797245175918;
          }
        } else {
          result[0] += 0.003814366222274287;
        }
      }
    }
  } else {
    result[0] += 0.0371844298419423;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.841376214053286442) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1221034598319439696) ) ) {
      result[0] += -0.04044356805423984;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5966361188013137307) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.650000000000000541e-05) ) ) {
          result[0] += 0.0030704047532785932;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003591500000000000508) ) ) {
            result[0] += -0.017387292011826726;
          } else {
            result[0] += -0.0025509606934457905;
          }
        }
      } else {
        result[0] += 0.002481143776778005;
      }
    }
  } else {
    result[0] += 0.036891981989792696;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.841376214053286442) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1221034598319439696) ) ) {
      result[0] += -0.0402727537542005;
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4045448672742624763) ) ) {
        result[0] += -0.01009499086766529;
      } else {
        if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6251195235379441995) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1850000000000000255) ) ) {
            result[0] += 0.01903008483888308;
          } else {
            result[0] += -0.0008353243293566797;
          }
        } else {
          result[0] += 0.00913827851540935;
        }
      }
    }
  } else {
    result[0] += 0.03659308435225932;
  }
}

