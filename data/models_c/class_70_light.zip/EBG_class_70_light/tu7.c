
#include "header.h"

void predict_unit7(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7074300481310827893) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4411376887452597706) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2398531877347642449) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1206121103143473067) ) ) {
          result[0] += -0.07029780805629349;
        } else {
          result[0] += -0.06251604819501996;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7440463348994975634) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01151050000000000163) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03500000000000001027) ) ) {
                result[0] += 0;
              } else {
                result[0] += -0.039665679515619716;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3626061583264781896) ) ) {
                result[0] += -0.060246457273456754;
              } else {
                result[0] += -0.04583876198010461;
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6465860195728644344) ) ) {
              result[0] += -0.04112996795475373;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.45553739944690258) ) ) {
                result[0] += 0.07233137384213582;
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1693967519290585366) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.319318361087794933) ) ) {
                    result[0] += -0.026722421452676465;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1050000000000000239) ) ) {
                      result[0] += 0.14417850558726109;
                    } else {
                      result[0] += -0.02779637249091279;
                    }
                  }
                } else {
                  result[0] += -0.0369942402198623;
                }
              }
            }
          }
        } else {
          result[0] += -0.057509531915359596;
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5825139232263935041) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5265509790734695938) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2108884567369299912) ) ) {
            result[0] += -0.014952787583618413;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003224500000000000369) ) ) {
              result[0] += -0.04472648290678369;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.966590843157139501) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003357500000000000675) ) ) {
                  result[0] += 0.04057092474400176;
                } else {
                  result[0] += -0.0255248884033667;
                }
              } else {
                result[0] += -0.05270382761386569;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3865950184387632049) ) ) {
            result[0] += -0.010788277033361904;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5478695791629558665) ) ) {
              result[0] += -0.04855891906127208;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7379591540954774098) ) ) {
                result[0] += -0.03196844901711962;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7359531922351972844) ) ) {
                  result[0] += 0.06521859241530803;
                } else {
                  result[0] += -0.011149349362431539;
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6741462157421617141) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003160500000000000548) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3037124426228626772) ) ) {
                result[0] += -0.017963315486153448;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4250000000000000444) ) ) {
                  result[0] += 0.06822720283769206;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4850000000000000422) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7201893438693468541) ) ) {
                      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5550000000000001599) ) ) {
                        result[0] += -0.04101893512158842;
                      } else {
                        result[0] += 0.04242282732708319;
                      }
                    } else {
                      result[0] += -0.0785431713419755;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.625707420288709959) ) ) {
                      result[0] += 0.07857267722896301;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6388211610437092292) ) ) {
                        result[0] += -0.038991224847382974;
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5392445599497488473) ) ) {
                          result[0] += 0.07808992672087833;
                        } else {
                          result[0] += 0.005237527828670829;
                        }
                      }
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.625707420288709959) ) ) {
                result[0] += -0.02837263888851859;
              } else {
                result[0] += -0.011555721926807448;
              }
            }
          } else {
            result[0] += -0.002813494646364638;
          }
        } else {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3746863702111971617) ) ) {
            result[0] += 0.02318134880834758;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.55780239615577909) ) ) {
              result[0] += -0.011481010036463917;
            } else {
              result[0] += 0.006972623820381012;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6675308230823290279) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8207002514789815129) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6380671833187036013) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4250000000000000444) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4549440021356783714) ) ) {
              result[0] += 0.006216923262574197;
            } else {
              result[0] += 0.05803265175374275;
            }
          } else {
            result[0] += 0.014813139164966878;
          }
        } else {
          result[0] += 0.02922207834048965;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9155428772725314746) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8450000000000000844) ) ) {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6173059481599049159) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8150000000000000577) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8898401904750864455) ) ) {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.038794232605861678) ) ) {
                    result[0] += 0.07048546604348777;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3797425373115578262) ) ) {
                      result[0] += 0.0010860932566624398;
                    } else {
                      result[0] += 0.031354572681524764;
                    }
                  }
                } else {
                  result[0] += 0.05118241495851526;
                }
              } else {
                result[0] += -0.0579413390080629;
              }
            } else {
              result[0] += 0.04586303330866766;
            }
          } else {
            result[0] += -0.0048785963644467426;
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9550000000000000711) ) ) {
            result[0] += 0.05915892348176836;
          } else {
            result[0] += 0.029747609707308994;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7994052243814134817) ) ) {
        result[0] += 0.05997303220404902;
      } else {
        result[0] += 0.0728661607157485;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7074300481310827893) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4321942852785685685) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2398531877347642449) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1206121103143473067) ) ) {
          result[0] += -0.06969465737393041;
        } else {
          result[0] += -0.061539810447252485;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883661844891582726) ) ) {
            result[0] += -0.03813100268407116;
          } else {
            result[0] += 0.01906956359109509;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004872500000000000962) ) ) {
            result[0] += -0.05726798898334056;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.038112519465065331) ) ) {
                result[0] += -0.04138017120220983;
              } else {
                result[0] += 0.008884361260875152;
              }
            } else {
              result[0] += -0.062426064411126525;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5629295393739166542) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4850000000000000422) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4976396106036372058) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2792435502835992067) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6732382808793971884) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05738700000000000745) ) ) {
                  result[0] += -0.028854103306507006;
                } else {
                  result[0] += 0.01052620220773381;
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2850000000000000866) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1077145000000000047) ) ) {
                    result[0] += 0.03059404478567421;
                  } else {
                    result[0] += -0.050194088388649534;
                  }
                } else {
                  result[0] += -0.04314621372456895;
                }
              }
            } else {
              result[0] += -0.041454021557808945;
            }
          } else {
            result[0] += -0.014451344307417154;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002242500000000000569) ) ) {
            result[0] += -0.04451564813831762;
          } else {
            result[0] += -0.02659559346660708;
          }
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6207300888023185026) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4250000000000000444) ) ) {
            result[0] += -0.004062588797741154;
          } else {
            result[0] += -0.021505160781407004;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8517455601758795458) ) ) {
            result[0] += -0.001991196245827332;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.679442381639573378) ) ) {
              result[0] += 0.08342842954384218;
            } else {
              result[0] += -0.003126211020359279;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6675308230823290279) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8207002514789815129) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7638123743065539095) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6750000000000001554) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5073376920831885739) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.545000000000000151) ) ) {
                result[0] += 0.029542773956304395;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5950000000000000844) ) ) {
                  result[0] += -0.040771042488325956;
                } else {
                  result[0] += 0.012222498968505087;
                }
              }
            } else {
              result[0] += -0.04333604917944294;
            }
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4308864010763797103) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5350000000000001421) ) ) {
                result[0] += 0.052074604326054166;
              } else {
                if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.423624169093450742) ) ) {
                  result[0] += -0.06376333191704882;
                } else {
                  result[0] += 0.03803259392765249;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01029450000000000157) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5650000000000000577) ) ) {
                  result[0] += 0.07032240330613483;
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7450000000000001066) ) ) {
                    result[0] += -0.018423386351041748;
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005839500000000000073) ) ) {
                      result[0] += 0.013340480288002877;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7497602064570687563) ) ) {
                        result[0] += 0.021221194738404416;
                      } else {
                        result[0] += 0.0743664055969926;
                      }
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6345459868090453925) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4832433377889447379) ) ) {
                    result[0] += 0.024571987892910506;
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7450000000000001066) ) ) {
                      result[0] += 0.012506492010176517;
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5989105927135679464) ) ) {
                        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5205064676009829583) ) ) {
                          result[0] += 0.00871232872163258;
                        } else {
                          result[0] += -0.053231228432295406;
                        }
                      } else {
                        result[0] += -0.07924909274158302;
                      }
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6670371533417086551) ) ) {
                    result[0] += 0.06944024884995069;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.234671350732867934) ) ) {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.992027305872230758) ) ) {
                        result[0] += 0.013134706420052492;
                      } else {
                        result[0] += -0.05526026208156074;
                      }
                    } else {
                      result[0] += 0.0504443708249645;
                    }
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3041513359296483254) ) ) {
            if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
              result[0] += 0.0257295807311149;
            } else {
              result[0] += -0.058384048193078936;
            }
          } else {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6445926074073893286) ) ) {
              result[0] += 0.022172819038289528;
            } else {
              result[0] += 0.0485618262810346;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9155428772725314746) ) ) {
          result[0] += 0.03410278782527427;
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9550000000000000711) ) ) {
            result[0] += 0.05741613670856985;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8650000000000001021) ) ) {
              result[0] += 0.03893879108605711;
            } else {
              result[0] += -0.002468294618847486;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7994052243814134817) ) ) {
        result[0] += 0.058471128532284804;
      } else {
        result[0] += 0.07194464295421174;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7074300481310827893) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4094140003309167386) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2398531877347642449) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1206121103143473067) ) ) {
          result[0] += -0.0691284309133806;
        } else {
          result[0] += -0.060579233976447704;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)2.800000000000000297e-05) ) ) {
          result[0] += -0.0363268304282398;
        } else {
          result[0] += -0.05183459068473831;
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5395439842637465011) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1850000000000000255) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5017812602789092358) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1764963302915136534) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04288995536428370087) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3670076269095477461) ) ) {
                  result[0] += 0.05237566310693104;
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1250000000000000278) ) ) {
                    result[0] += -0.05673558157327759;
                  } else {
                    result[0] += 0.0013978822924088125;
                  }
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3450000000000000289) ) ) {
                  result[0] += 0.07959157862042408;
                } else {
                  result[0] += -0.016244327385109565;
                }
              }
            } else {
              result[0] += -0.02421570178794215;
            }
          } else {
            result[0] += 0.033588704172096785;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4627525279249136148) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1966996977063275309) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6387151202261307503) ) ) {
                result[0] += -0.042200041130551265;
              } else {
                result[0] += 0.05729479236099589;
              }
            } else {
              result[0] += -0.04363227849408833;
            }
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2384269498305124635) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2150000000000000244) ) ) {
                result[0] += 0.015373892392576275;
              } else {
                result[0] += -0.017895124975667233;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002242500000000000569) ) ) {
                result[0] += -0.041274972597420245;
              } else {
                result[0] += -0.026149261091792098;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6207300888023185026) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.038794232605861678) ) ) {
              result[0] += 0.07101893007791109;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5477977269597991139) ) ) {
                result[0] += -0.011844190435947902;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6152470170603016042) ) ) {
                  result[0] += 0.040038138688169564;
                } else {
                  result[0] += -0.012150014503120364;
                }
              }
            }
          } else {
            result[0] += -0.017171288514596043;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8517455601758795458) ) ) {
            result[0] += -0.0018657826406946205;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.679442381639573378) ) ) {
              result[0] += 0.07790023684077152;
            } else {
              result[0] += -0.0029502959573605766;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6800585241488680266) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8207002514789815129) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6380671833187036013) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3750000000000000555) ) ) {
            result[0] += 0.04836384905577334;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)2.800000000000000297e-05) ) ) {
              result[0] += 0.03513891157870713;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002835000000000000605) ) ) {
                result[0] += -0.04419955754561019;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7638123743065539095) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6750000000000001554) ) ) {
                    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4308864010763797103) ) ) {
                      result[0] += 0.003989930084356962;
                    } else {
                      result[0] += -0.030113775497680066;
                    }
                  } else {
                    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4308864010763797103) ) ) {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5350000000000001421) ) ) {
                        result[0] += 0.04855563392636018;
                      } else {
                        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.423624169093450742) ) ) {
                          result[0] += -0.05987187226299711;
                        } else {
                          result[0] += 0.03298596757017409;
                        }
                      }
                    } else {
                      result[0] += 0.0094746283440711;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.505061141934673441) ) ) {
                    result[0] += 0.00876544783471886;
                  } else {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.529830452742650726) ) ) {
                      result[0] += 0.04749568473436788;
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.52572947701005035) ) ) {
                        result[0] += 0.05604902787001644;
                      } else {
                        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5056897969566794826) ) ) {
                          result[0] += -0.007897898882318257;
                        } else {
                          result[0] += 0.02151735381838591;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        } else {
          result[0] += 0.026455824076996728;
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3797425373115578262) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.323165429195979903) ) ) {
            result[0] += 0.0365702024828925;
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5357646220388291303) ) ) {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5056897969566794826) ) ) {
                result[0] += -0.0014104172494823937;
              } else {
                result[0] += -0.08690847384441812;
              }
            } else {
              result[0] += 0.011614812176827397;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8898401904750864455) ) ) {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6260154606475681893) ) ) {
              result[0] += 0.028614017389660473;
            } else {
              result[0] += 0.04509919327517938;
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
              result[0] += 0.053588005566663474;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8450000000000000844) ) ) {
                result[0] += 0.04232392723734701;
              } else {
                if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6371946970980452152) ) ) {
                  result[0] += -0.05437194789546828;
                } else {
                  result[0] += 0.021754271770721766;
                }
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8373354933349520524) ) ) {
        result[0] += 0.060120249558949096;
      } else {
        result[0] += 0.07190182624273377;
      }
    }
  }
}

