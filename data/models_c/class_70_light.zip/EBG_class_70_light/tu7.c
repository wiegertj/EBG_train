
#include "header.h"

void predict_unit7(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5797375516240159676) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2925224498079027069) ) ) {
      result[0] += -0.038280039973010195;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5506872176393086127) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 0.0009518770388119505;
        } else {
          result[0] += -0.018612411446951395;
        }
      } else {
        result[0] += -0.00015235878718702312;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7357947538897144923) ) ) {
      result[0] += 0.01797807861354488;
    } else {
      result[0] += 0.0430067180832886;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8219148688594737351) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2925224498079027069) ) ) {
      result[0] += -0.03788977989982848;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5582897067648240341) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 0.0019403449865395637;
        } else {
          result[0] += -0.01789948865608685;
        }
      } else {
        result[0] += 0.0004950778625647787;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7357947538897144923) ) ) {
      result[0] += 0.01866940330662587;
    } else {
      result[0] += 0.04269831130689273;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5797375516240159676) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2925224498079027069) ) ) {
      result[0] += -0.0374966831678609;
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5055241589195451635) ) ) {
        result[0] += -0.015485731328766137;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004655500000000000783) ) ) {
          result[0] += -0.007985149679716976;
        } else {
          result[0] += 0.004542624339747596;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7286792202408863828) ) ) {
      result[0] += 0.016782641348750644;
    } else {
      result[0] += 0.04216603433629536;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8219148688594737351) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2925224498079027069) ) ) {
      result[0] += -0.037100439972149846;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6438205396169394135) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 0.00409647017232431;
        } else {
          result[0] += -0.013093257097450071;
        }
      } else {
        result[0] += 0.0027723216494691645;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7357947538897144923) ) ) {
      result[0] += 0.017644569903956048;
    } else {
      result[0] += 0.042087691283186554;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8588694953294175871) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3474450840415687081) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1596646965685780961) ) ) {
        result[0] += -0.04360823302474937;
      } else {
        result[0] += -0.024322550276558663;
      }
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6526844655663904815) ) ) {
        result[0] += -0.008065338059504294;
      } else {
        result[0] += 0.003768056629924118;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7357947538897144923) ) ) {
      result[0] += 0.019407223059229286;
    } else {
      result[0] += 0.0417827614742139;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5797375516240159676) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2925224498079027069) ) ) {
      result[0] += -0.0363143221659317;
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5055241589195451635) ) ) {
        result[0] += -0.014344266334649408;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004746500000000001586) ) ) {
          result[0] += -0.007396557346362205;
        } else {
          result[0] += 0.004411826472425156;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7357947538897144923) ) ) {
      result[0] += 0.015616930799882155;
    } else {
      result[0] += 0.04147795796745539;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8707605184368226725) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2925224498079027069) ) ) {
      result[0] += -0.03590696079097441;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6438205396169394135) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 0.004898976393557949;
        } else {
          result[0] += -0.012069793211163532;
        }
      } else {
        result[0] += 0.003432333834265935;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7497367709113804679) ) ) {
      result[0] += 0.01976588731557256;
    } else {
      result[0] += 0.04158346363958687;
    }
  }
}

