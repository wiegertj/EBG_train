
#include "header.h"

void predict_unit7(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.655609054534752711) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4243526687260518182) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2002749652849908635) ) ) {
        result[0] += -0.028294440732565374;
      } else {
        result[0] += -0.020257620471909543;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5365113871239524101) ) ) {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.2209082565809930565) ) ) {
          result[0] += -0.003886514810900716;
        } else {
          result[0] += -0.01533090356089536;
        }
      } else {
        result[0] += -0.005096791993333097;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6549621339660968156) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7877973938526349196) ) ) {
        result[0] += 0.0031470139011094333;
      } else {
        result[0] += 0.012455772930385375;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.746072903742064919) ) ) {
        result[0] += 0.021341764062612026;
      } else {
        result[0] += 0.029674662202133793;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7352869986369691135) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4471985607798013018) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2721741080702284044) ) ) {
        result[0] += -0.027052945328679828;
      } else {
        result[0] += -0.018098760939372183;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6038797007738568867) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5050000000000001155) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5201676432420939689) ) ) {
            result[0] += -0.010618988432706327;
          } else {
            result[0] += -0.0016857936507442429;
          }
        } else {
          result[0] += -0.013391242010870396;
        }
      } else {
        result[0] += -0.0003546363104064682;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6843233464651609088) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8341961608046256638) ) ) {
        result[0] += 0.007186585019799605;
      } else {
        result[0] += 0.015552933101920532;
      }
    } else {
      result[0] += 0.028307740454296907;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7352869986369691135) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4471985607798013018) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2178518179945141686) ) ) {
        result[0] += -0.027772871199471565;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.300000000000000843e-05) ) ) {
          result[0] += -0.013520623163115444;
        } else {
          result[0] += -0.02113091811400782;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5754236634526536109) ) ) {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.2459704571246580096) ) ) {
          result[0] += -0.003379207590119821;
        } else {
          result[0] += -0.011991934855241417;
        }
      } else {
        result[0] += -0.0010494847030726566;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6843233464651609088) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8341961608046256638) ) ) {
        result[0] += 0.007008929636163626;
      } else {
        result[0] += 0.015262905988391636;
      }
    } else {
      result[0] += 0.028131707090317527;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.655609054534752711) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4243526687260518182) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2002749652849908635) ) ) {
        result[0] += -0.02793845160238106;
      } else {
        result[0] += -0.019532806662954566;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5365113871239524101) ) ) {
        result[0] += -0.011677400845266184;
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3750000000000000555) ) ) {
          result[0] += 0.0012158013963421187;
        } else {
          result[0] += -0.007547027268489994;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6549621339660968156) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.607134570361309911) ) ) {
        result[0] += 0.0027724849957817144;
      } else {
        result[0] += 0.011509262077067862;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.746072903742064919) ) ) {
        result[0] += 0.020452591085995;
      } else {
        result[0] += 0.029247951134349623;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7352869986369691135) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4471985607798013018) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2268996455050684702) ) ) {
        result[0] += -0.027377777011234398;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.300000000000000843e-05) ) ) {
          result[0] += -0.012697287882725465;
        } else {
          result[0] += -0.020521932667390046;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.57063705883429372) ) ) {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.2459704571246580096) ) ) {
          result[0] += -0.0032367387943884334;
        } else {
          result[0] += -0.011845688576564251;
        }
      } else {
        result[0] += -0.0010978318897848156;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6904018820383829302) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8341961608046256638) ) ) {
        result[0] += 0.006646230032913207;
      } else {
        result[0] += 0.01496307392614163;
      }
    } else {
      result[0] += 0.027958880111753265;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5854397126054067257) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4519258424761351534) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2721741080702284044) ) ) {
        result[0] += -0.026497821367216203;
      } else {
        result[0] += -0.016937662642847833;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6373581005240800401) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += -0.0006289756799643046;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003370500000000000666) ) ) {
            result[0] += -0.015398744715899707;
          } else {
            result[0] += -0.004429044614255785;
          }
        }
      } else {
        result[0] += 0.0014020476590720192;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7141856296356029477) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8341961608046256638) ) ) {
        result[0] += 0.007667582870500265;
      } else {
        result[0] += 0.0156611629809081;
      }
    } else {
      result[0] += 0.028471910924990972;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5854397126054067257) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4471985607798013018) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2178518179945141686) ) ) {
        result[0] += -0.0272881063950093;
      } else {
        result[0] += -0.017927781270480142;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6373581005240800401) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += -0.0005352555328584906;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003370500000000000666) ) ) {
            result[0] += -0.015275048631561528;
          } else {
            result[0] += -0.004437483444852833;
          }
        }
      } else {
        result[0] += 0.0013642003192480216;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7141856296356029477) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.844661369991607125) ) ) {
        result[0] += 0.007880404773823724;
      } else {
        result[0] += 0.01577371522078906;
      }
    } else {
      result[0] += 0.028324910601991844;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7449878528029710845) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4243526687260518182) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2002749652849908635) ) ) {
        result[0] += -0.027484190199519695;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.300000000000000843e-05) ) ) {
          result[0] += -0.012911709338783958;
        } else {
          result[0] += -0.021245008551209102;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5561432885305349627) ) ) {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.2367007440475680791) ) ) {
          result[0] += -0.003587830764943504;
        } else {
          result[0] += -0.013051653301033498;
        }
      } else {
        result[0] += -0.0011215266437020982;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7141856296356029477) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.844661369991607125) ) ) {
        result[0] += 0.006954303855692238;
      } else {
        result[0] += 0.015357824356346588;
      }
    } else {
      result[0] += 0.028180107426753472;
    }
  }
}

