
#include "header.h"

void predict_unit3(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7024961766447593847) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.515143529846740944) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2656063113060950776) ) ) {
        result[0] += -0.08024261111188892;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4094140003309167386) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)2.800000000000000297e-05) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03500000000000001027) ) ) {
              result[0] += -0.019339472244313174;
            } else {
              result[0] += -0.05991368933333496;
            }
          } else {
            result[0] += -0.07187959150900759;
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2108884567369299912) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4591620551040981879) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1923733477048955032) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6387151202261307503) ) ) {
                  result[0] += -0.03485403987997462;
                } else {
                  result[0] += 0.02320480883014029;
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2250000000000000333) ) ) {
                  result[0] += -0.044766940624765446;
                } else {
                  result[0] += -0.06814296980331057;
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1650000000000000355) ) ) {
                result[0] += 0.018989423157229762;
              } else {
                result[0] += -0.034206476611429316;
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003224500000000000369) ) ) {
              result[0] += -0.06736429687447619;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9567162861906464144) ) ) {
                result[0] += -0.05019289291075539;
              } else {
                result[0] += -0.07192152165154134;
              }
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6095226520848766594) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2944793848334646413) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5739389314180569635) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2328444889043961574) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01385800000000000226) ) ) {
                result[0] += -0.04996017333477148;
              } else {
                result[0] += -0.0063277300800192865;
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4464275526633166291) ) ) {
                result[0] += 0.054399912242128534;
              } else {
                result[0] += -0.02159298586485301;
              }
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1000410000000000188) ) ) {
                result[0] += 0.057763577277062744;
              } else {
                result[0] += -0.014340475472113562;
              }
            } else {
              result[0] += -0.015566755791501899;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003697500000000000699) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5629295393739166542) ) ) {
              result[0] += -0.0554822480444247;
            } else {
              result[0] += -0.038217491069796834;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.578266620629892647) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3865950184387632049) ) ) {
                result[0] += -0.028193928888099316;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00401850000000000037) ) ) {
                  result[0] += -0.005950739388363464;
                } else {
                  result[0] += -0.05696660847006367;
                }
              }
            } else {
              result[0] += -0.02094861420303551;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4350000000000000533) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6875734944390267112) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3359742075444987486) ) ) {
              result[0] += -0.0035904367003208224;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7294912264551259851) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4330073079623726895) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3750110022441224822) ) ) {
                    result[0] += 0.05998311528488366;
                  } else {
                    result[0] += -0.01859074280403472;
                  }
                } else {
                  result[0] += 0.082950445197029;
                }
              } else {
                result[0] += -0.015893676912302906;
              }
            }
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1890520899528410625) ) ) {
              result[0] += 0.06712160475039289;
            } else {
              result[0] += 0.011570928819442501;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6343929365935514486) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7050000000000000711) ) ) {
              result[0] += -0.00783524946229572;
            } else {
              result[0] += -0.03475284016647736;
            }
          } else {
            result[0] += -0.005371827909417949;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8572185734818382752) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7638123743065539095) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6380671833187036013) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3350000000000000755) ) ) {
            result[0] += 0.08397160777332333;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6750000000000001554) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5073376920831885739) ) ) {
                result[0] += 0.020332940692584307;
              } else {
                result[0] += -0.030982840309466367;
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4613143568254923776) ) ) {
                result[0] += 0.06807105262052479;
              } else {
                if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4153271040333154085) ) ) {
                  result[0] += -0.021049797521083283;
                } else {
                  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4308864010763797103) ) ) {
                    result[0] += 0.05200214972016186;
                  } else {
                    result[0] += 0.026144531690540023;
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08425129245607926309) ) ) {
            result[0] += 6.626406241255985e-06;
          } else {
            result[0] += 0.07957595477111853;
          }
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7952348873182119027) ) ) {
          result[0] += 0.042958421825328615;
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3837516359296482826) ) ) {
            result[0] += 0.03800836115062887;
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6410891170561271446) ) ) {
              result[0] += 0.053567951108736106;
            } else {
              result[0] += 0.06607454637675793;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6800585241488680266) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4924412467785411196) ) ) {
          result[0] += 0.011299404660917568;
        } else {
          result[0] += 0.07168228531515998;
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8373354933349520524) ) ) {
          result[0] += 0.08681320867999079;
        } else {
          result[0] += 0.09324839443259711;
        }
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7024961766447593847) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.515143529846740944) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2656063113060950776) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1247736973015392964) ) ) {
          result[0] += -0.08088442493085828;
        } else {
          result[0] += -0.07525457050895192;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4094140003309167386) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)2.800000000000000297e-05) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03500000000000001027) ) ) {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.07624899563451974227) ) ) {
                result[0] += -0.051204118879206534;
              } else {
                result[0] += 0.020698764287606784;
              }
            } else {
              result[0] += -0.0578563036009359;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0650000000000000161) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6796249047236181395) ) ) {
                result[0] += -0.060793566042655574;
              } else {
                result[0] += -0.00105566839786144;
              }
            } else {
              result[0] += -0.07151675530381424;
            }
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2108884567369299912) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4591620551040981879) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1923733477048955032) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6387151202261307503) ) ) {
                  result[0] += -0.03317906067897351;
                } else {
                  result[0] += 0.02164235789191786;
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2250000000000000333) ) ) {
                  result[0] += -0.0428002371884447;
                } else {
                  result[0] += -0.06595308930531543;
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1650000000000000355) ) ) {
                result[0] += 0.017751065128634374;
              } else {
                result[0] += -0.03247526622929481;
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003224500000000000369) ) ) {
              result[0] += -0.06524557000076597;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.639033920871866834) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6055650374709939943) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05738700000000000745) ) ) {
                    result[0] += -0.050771194177066534;
                  } else {
                    result[0] += -0.024431189529820152;
                  }
                } else {
                  result[0] += 0.03396197767776823;
                }
              } else {
                result[0] += -0.06384416518534224;
              }
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6095226520848766594) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2944793848334646413) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5739389314180569635) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2328444889043961574) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01385800000000000226) ) ) {
                result[0] += -0.04761969402152441;
              } else {
                result[0] += -0.005949913186179036;
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4464275526633166291) ) ) {
                result[0] += 0.050593199481450114;
              } else {
                result[0] += -0.020371569171369622;
              }
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1000410000000000188) ) ) {
                result[0] += 0.05361524391744014;
              } else {
                result[0] += -0.013559619999164246;
              }
            } else {
              result[0] += -0.01466674953876197;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003697500000000000699) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5629295393739166542) ) ) {
              result[0] += -0.05328789499800724;
            } else {
              result[0] += -0.03634246064998629;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.578266620629892647) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3865950184387632049) ) ) {
                result[0] += -0.02668088876632273;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00401850000000000037) ) ) {
                  result[0] += -0.005608908406122087;
                } else {
                  result[0] += -0.05463243669672528;
                }
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4050000000000000822) ) ) {
                result[0] += -0.04731256356959953;
              } else {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3517401684960584363) ) ) {
                  result[0] += 0.027238678328663342;
                } else {
                  result[0] += -0.018356360308980843;
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4350000000000000533) ) ) {
          result[0] += 0.006237239558776694;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6343929365935514486) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7050000000000000711) ) ) {
              result[0] += -0.007357509362154163;
            } else {
              result[0] += -0.032919610747182665;
            }
          } else {
            result[0] += -0.005037105477081053;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8898401904750864455) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.79000980692407341) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7341196086063838111) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450205000000000244) ) ) {
            result[0] += 0.019190712310203428;
          } else {
            result[0] += 0.06952397597856122;
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5894867046835161606) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5245354220245331822) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3623115618844221508) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6550000000000001377) ) ) {
                  result[0] += 0.03763801668074046;
                } else {
                  result[0] += -0.04798799274186117;
                }
              } else {
                result[0] += 0.042944975471013516;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.138279000000000013) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.70902182859296492) ) ) {
                  result[0] += 0.01791685194355796;
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7850000000000001421) ) ) {
                    result[0] += 0.09234560957612471;
                  } else {
                    result[0] += 0.028729029049083442;
                  }
                }
              } else {
                result[0] += -0.03935433420211547;
              }
            }
          } else {
            result[0] += 0.04205057425338687;
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6260154606475681893) ) ) {
          result[0] += 0.05073316227412162;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00101050000000000033) ) ) {
            result[0] += 0.046154090254476296;
          } else {
            result[0] += 0.07209905750917216;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7277785409960092489) ) ) {
        result[0] += 0.07516435395106454;
      } else {
        result[0] += 0.08921311855792345;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7024961766447593847) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4976396106036372058) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2656063113060950776) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1247736973015392964) ) ) {
          result[0] += -0.07944172060662327;
        } else {
          result[0] += -0.0736245865693662;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4094140003309167386) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)2.800000000000000297e-05) ) ) {
            result[0] += -0.05469231530772712;
          } else {
            result[0] += -0.0680025470511771;
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1917993845848007251) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5043975837804381968) ) ) {
              result[0] += -0.04002549663399555;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00401850000000000037) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4591620551040981879) ) ) {
                  result[0] += -0.05081017893052458;
                } else {
                  result[0] += 0.00824851168494475;
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04047250000000000153) ) ) {
                  result[0] += 0.08337312910760315;
                } else {
                  result[0] += -0.023337751720866898;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003224500000000000369) ) ) {
              result[0] += -0.06278612265988838;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4546668074497933199) ) ) {
                result[0] += -0.058645062479204375;
              } else {
                if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2145533287705388148) ) ) {
                  result[0] += -0.00970902863335648;
                } else {
                  result[0] += -0.047246012216652485;
                }
              }
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6095226520848766594) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2944793848334646413) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5265509790734695938) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1950000000000000344) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4395917154773869573) ) ) {
                result[0] += -0.04833535911655214;
              } else {
                if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.01051018765715429869) ) ) {
                  result[0] += 0.06535667607307365;
                } else {
                  result[0] += -0.01303452908530336;
                }
              }
            } else {
              result[0] += -0.039735370538470524;
            }
          } else {
            result[0] += -0.01564228661952534;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5395439842637465011) ) ) {
            result[0] += -0.052126206795826475;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003615500000000000224) ) ) {
              result[0] += -0.03969080830564659;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5435253867705854836) ) ) {
                result[0] += 0.010835477369604326;
              } else {
                result[0] += -0.025788344193585302;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6741462157421617141) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.436852567100262823) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.09025796823538302649) ) ) {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3545101226909838643) ) ) {
                result[0] += 0.00018388289727644792;
              } else {
                result[0] += -0.035502171359082055;
              }
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.01051018765715429869) ) ) {
                result[0] += 0.05442720117170002;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4330073079623726895) ) ) {
                  result[0] += -0.008078088479210889;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7346206940954774778) ) ) {
                    result[0] += 0.05451964500484723;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6388211610437092292) ) ) {
                      result[0] += -0.03714175327755418;
                    } else {
                      result[0] += 0.026653503909284972;
                    }
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.625707420288709959) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003357500000000000675) ) ) {
                result[0] += -0.04305101781411758;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5530932080904523707) ) ) {
                  result[0] += 0.027905955091064277;
                } else {
                  result[0] += -0.026215145824277947;
                }
              }
            } else {
              result[0] += -0.011111379036446708;
            }
          }
        } else {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3746863702111971617) ) ) {
            result[0] += 0.0293613369408467;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6050000000000000933) ) ) {
              result[0] += 0.0018979667420439782;
            } else {
              result[0] += -0.01968402595431855;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8898401904750864455) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.79000980692407341) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6380671833187036013) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7291204255332855988) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4250000000000000444) ) ) {
              result[0] += 0.04690848852971822;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01826050000000000242) ) ) {
                result[0] += 0.019712463009710027;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5150000000000001243) ) ) {
                  result[0] += 0.01315926236246503;
                } else {
                  result[0] += -0.029326688565987337;
                }
              }
            }
          } else {
            result[0] += 0.029668644253134396;
          }
        } else {
          result[0] += 0.04583263658528442;
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6863640520055726002) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001376500000000000336) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)2.800000000000000297e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9450000000000000622) ) ) {
                result[0] += 0.02491447748994278;
              } else {
                result[0] += 0.09735372611030801;
              }
            } else {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6445926074073893286) ) ) {
                result[0] += 0.013587391892681044;
              } else {
                result[0] += 0.05088616829664958;
              }
            }
          } else {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6091439259582375199) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6693797357368335144) ) ) {
                result[0] += 0.04868645426109908;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01130450000000000205) ) ) {
                  result[0] += -0.014248346965539206;
                } else {
                  result[0] += 0.06153182484717802;
                }
              }
            } else {
              result[0] += 0.06350463956024392;
            }
          }
        } else {
          result[0] += 0.06964159572059517;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7126859971266824578) ) ) {
        result[0] += 0.07123652688104655;
      } else {
        result[0] += 0.08647269723931747;
      }
    }
  }
}

