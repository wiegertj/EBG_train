
#include "header.h"

void predict_unit3(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7322337689842495223) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4744068267591841637) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.258569720040409734) ) ) {
        result[0] += -0.05042574670787846;
      } else {
        result[0] += -0.0369175083096549;
      }
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5966361188013137307) ) ) {
        result[0] += -0.02163460747042181;
      } else {
        result[0] += -0.0011096558017221158;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6606907916086263155) ) ) {
      result[0] += 0.027049313824568773;
    } else {
      result[0] += 0.05380334299123037;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.66684070898398351) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4447155022895915022) ) ) {
      result[0] += -0.045624325976974266;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5582897067648240341) ) ) {
        result[0] += -0.025048601016777278;
      } else {
        result[0] += -0.009233357905242445;
      }
    }
  } else {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8707605184368226725) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.765966927815004861) ) ) {
        result[0] += 0.006372928744379422;
      } else {
        result[0] += 0.027422611009705018;
      }
    } else {
      result[0] += 0.051040954638397425;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7365946179753046774) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4744068267591841637) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.258569720040409734) ) ) {
        result[0] += -0.049395665664509;
      } else {
        result[0] += -0.03524608161005288;
      }
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5966361188013137307) ) ) {
        result[0] += -0.020235840951623653;
      } else {
        result[0] += -0.0007627909404983093;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6606907916086263155) ) ) {
      result[0] += 0.025693292983589987;
    } else {
      result[0] += 0.052210070961252984;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7413080085623182658) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4447155022895915022) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.258569720040409734) ) ) {
        result[0] += -0.04889013175033874;
      } else {
        result[0] += -0.03607934930290543;
      }
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5966361188013137307) ) ) {
        result[0] += -0.02075645087687899;
      } else {
        result[0] += -0.0005001981288071502;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6828286013470772353) ) ) {
      result[0] += 0.026678221222915393;
    } else {
      result[0] += 0.05229654359175923;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.66684070898398351) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4236855092944680212) ) ) {
      result[0] += -0.04452837220643907;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5582897067648240341) ) ) {
        result[0] += -0.0237548753011238;
      } else {
        result[0] += -0.00822045061312047;
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.677986157280416446) ) ) {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.765966927815004861) ) ) {
        result[0] += 0.005526748784685421;
      } else {
        result[0] += 0.024905925866003514;
      }
    } else {
      result[0] += 0.04903668307064623;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7413080085623182658) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4447155022895915022) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2025449053348033213) ) ) {
        result[0] += -0.04922800144552026;
      } else {
        result[0] += -0.03627373734890743;
      }
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5966361188013137307) ) ) {
        result[0] += -0.019420124497288537;
      } else {
        result[0] += -0.00044232632028634215;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6828286013470772353) ) ) {
      result[0] += 0.02479479640720653;
    } else {
      result[0] += 0.05097005223303393;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6526844655663904815) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4236855092944680212) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2025449053348033213) ) ) {
        result[0] += -0.04880855809331821;
      } else {
        result[0] += -0.03651893359070078;
      }
    } else {
      result[0] += -0.016402580932005594;
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6415213458272231994) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5991490417989203676) ) ) {
        result[0] += 0.005022680359006569;
      } else {
        result[0] += 0.025048849407511075;
      }
    } else {
      result[0] += 0.048450412902953;
    }
  }
}

