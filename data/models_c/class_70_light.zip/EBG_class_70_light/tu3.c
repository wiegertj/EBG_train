
#include "header.h"

void predict_unit3(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6746411929901378057) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4519258424761351534) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2721741080702284044) ) ) {
        result[0] += -0.0334357749325836;
      } else {
        result[0] += -0.027765617214786095;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5754236634526536109) ) ) {
        result[0] += -0.01829451109241955;
      } else {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.3399990879818117206) ) ) {
          result[0] += 0.0012544672356205747;
        } else {
          result[0] += -0.009378315197911272;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.650477501151463966) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7352869986369691135) ) ) {
        result[0] += 0.0037879614681351984;
      } else {
        result[0] += 0.016712184357407008;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7141856296356029477) ) ) {
        result[0] += 0.028616143434599176;
      } else {
        result[0] += 0.037663128380479687;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6704987506121643515) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4519258424761351534) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2268996455050684702) ) ) {
        result[0] += -0.03355037966395922;
      } else {
        result[0] += -0.02802021240417761;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5524193294893345874) ) ) {
        result[0] += -0.019315089565841645;
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3450000000000000289) ) ) {
          result[0] += 0.0008418011254957367;
        } else {
          result[0] += -0.010800903203407142;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8341961608046256638) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7352869986369691135) ) ) {
        result[0] += 0.0035266093158328893;
      } else {
        result[0] += 0.016368683124693424;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7141856296356029477) ) ) {
        result[0] += 0.028204714331602532;
      } else {
        result[0] += 0.03721429040388328;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.704198211736497548) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5024430027690397482) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2965188918505100024) ) ) {
        result[0] += -0.03263742168358653;
      } else {
        result[0] += -0.025125732000700958;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.622330635648172481) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4850000000000000422) ) ) {
          result[0] += -0.009331317208246528;
        } else {
          result[0] += -0.017443535978670918;
        }
      } else {
        result[0] += -0.001789127565782566;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6840531608062441205) ) ) {
      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.607134570361309911) ) ) {
        result[0] += 0.009865993537238951;
      } else {
        result[0] += 0.021054149144325393;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.733482828522406094) ) ) {
        result[0] += 0.030146963811547613;
      } else {
        result[0] += 0.03696204947859056;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6704987506121643515) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4519258424761351534) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2721741080702284044) ) ) {
        result[0] += -0.03260133403631553;
      } else {
        result[0] += -0.026699430919929084;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5524193294893345874) ) ) {
        result[0] += -0.01862013418186382;
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3450000000000000289) ) ) {
          result[0] += 0.0010776193731124788;
        } else {
          result[0] += -0.010323523390854366;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.844661369991607125) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7352869986369691135) ) ) {
        result[0] += 0.0033108188277117447;
      } else {
        result[0] += 0.01617714132839385;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7141856296356029477) ) ) {
        result[0] += 0.027697437911033455;
      } else {
        result[0] += 0.036377785017476225;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6658449540838127234) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4519258424761351534) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2268996455050684702) ) ) {
        result[0] += -0.03276365326780181;
      } else {
        result[0] += -0.026993245271882717;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5524193294893345874) ) ) {
        result[0] += -0.018274569056689515;
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3450000000000000289) ) ) {
          result[0] += 0.0006118286074285738;
        } else {
          result[0] += -0.010534541522143328;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.650477501151463966) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7352869986369691135) ) ) {
        result[0] += 0.0030833626142426646;
      } else {
        result[0] += 0.015044727460723231;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7141856296356029477) ) ) {
        result[0] += 0.026679308498061716;
      } else {
        result[0] += 0.03598565608962354;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6658449540838127234) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4519258424761351534) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2721741080702284044) ) ) {
        result[0] += -0.03208938523206207;
      } else {
        result[0] += -0.026010096145960566;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5524193294893345874) ) ) {
        result[0] += -0.017934955950581345;
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3450000000000000289) ) ) {
          result[0] += 0.0005952565214404249;
        } else {
          result[0] += -0.010284650555406824;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.844661369991607125) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7352869986369691135) ) ) {
        result[0] += 0.0029994343773642254;
      } else {
        result[0] += 0.015359351144825575;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7141856296356029477) ) ) {
        result[0] += 0.026773443409128284;
      } else {
        result[0] += 0.035610061809719276;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6658449540838127234) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4471985607798013018) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2268996455050684702) ) ) {
        result[0] += -0.032280437097951836;
      } else {
        result[0] += -0.026453789767725517;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5524193294893345874) ) ) {
        result[0] += -0.017732566299459764;
      } else {
        result[0] += -0.008039889353229534;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6840531608062441205) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7449878528029710845) ) ) {
        result[0] += 0.0037235709762595353;
      } else {
        if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.607134570361309911) ) ) {
          result[0] += 0.011477845573370582;
        } else {
          result[0] += 0.02027977575743407;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.733482828522406094) ) ) {
        result[0] += 0.028340303150787807;
      } else {
        result[0] += 0.03543885919338072;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.704198211736497548) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4697693723122448595) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2721741080702284044) ) ) {
        result[0] += -0.03160846455599638;
      } else {
        result[0] += -0.02474448720497822;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5991184370131029668) ) ) {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.2793434790857622363) ) ) {
          result[0] += -0.009142797980822627;
        } else {
          result[0] += -0.017573346538890568;
        }
      } else {
        result[0] += -0.002694358982719867;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6967761054388647013) ) ) {
      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.607134570361309911) ) ) {
        result[0] += 0.008474001802776661;
      } else {
        result[0] += 0.019376988739491657;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.746072903742064919) ) ) {
        result[0] += 0.028838920837876716;
      } else {
        result[0] += 0.035204133392592714;
      }
    }
  }
}

