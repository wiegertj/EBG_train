
#include "header.h"

void predict_unit8(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5854397126054067257) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4243526687260518182) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2002749652849908635) ) ) {
        result[0] += -0.027371509794239145;
      } else {
        result[0] += -0.01834770830519539;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5843380316172624989) ) ) {
        result[0] += -0.008746195141470953;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1295212041281339765) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02065050000000000566) ) ) {
            result[0] += 5.163332319129279e-05;
          } else {
            result[0] += 0.008673545389899083;
          }
        } else {
          result[0] += -0.003380996545722359;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7141856296356029477) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8341961608046256638) ) ) {
        result[0] += 0.0071602311645680905;
      } else {
        result[0] += 0.014852210444263318;
      }
    } else {
      result[0] += 0.028037352445755094;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5854397126054067257) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4243526687260518182) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2002749652849908635) ) ) {
        result[0] += -0.027259826131555125;
      } else {
        result[0] += -0.018112952729825944;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.622330635648172481) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1850000000000000255) ) ) {
          result[0] += 0.003331237445061746;
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5201676432420939689) ) ) {
            result[0] += -0.013255449689884569;
          } else {
            result[0] += -0.005590251715242986;
          }
        }
      } else {
        result[0] += 0.0008931732758336156;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7141856296356029477) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8341961608046256638) ) ) {
        result[0] += 0.0069841949067082605;
      } else {
        result[0] += 0.014583261602000049;
      }
    } else {
      result[0] += 0.027896500804748616;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7580984751822718026) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4243526687260518182) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2002749652849908635) ) ) {
        result[0] += -0.02714904030032779;
      } else {
        result[0] += -0.017879068765029177;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.57063705883429372) ) ) {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.2367007440475680791) ) ) {
          result[0] += -0.0027069588263009597;
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4833496887444805323) ) ) {
            result[0] += -0.019295424393866795;
          } else {
            result[0] += -0.00873821297686026;
          }
        }
      } else {
        result[0] += -0.0003398054940946981;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7141856296356029477) ) ) {
      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.650477501151463966) ) ) {
        result[0] += 0.006484882850018657;
      } else {
        result[0] += 0.01427596392241221;
      }
    } else {
      result[0] += 0.027757414705943666;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5854397126054067257) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4243526687260518182) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2002749652849908635) ) ) {
        result[0] += -0.027039066006524115;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.300000000000000843e-05) ) ) {
          result[0] += -0.011747637427927803;
        } else {
          result[0] += -0.020432298582489312;
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.622330635648172481) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004487000000000000537) ) ) {
          result[0] += -0.009935568092692113;
        } else {
          result[0] += -0.0037635388191936273;
        }
      } else {
        result[0] += 0.0008480289136964349;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7141856296356029477) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.844661369991607125) ) ) {
        result[0] += 0.007024124195619023;
      } else {
        result[0] += 0.014472617466324023;
      }
    } else {
      result[0] += 0.02761996682121753;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7693651808594642594) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4243526687260518182) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2002749652849908635) ) ) {
        result[0] += -0.026929813871269057;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.300000000000000843e-05) ) ) {
          result[0] += -0.011539030798219588;
        } else {
          result[0] += -0.02020822953573715;
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6373581005240800401) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004487000000000000537) ) ) {
          result[0] += -0.009376710200301373;
        } else {
          result[0] += -0.0034042494438528835;
        }
      } else {
        result[0] += 0.001377981523614707;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7141856296356029477) ) ) {
      if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6453796957695748793) ) ) {
        result[0] += 0.008391537953195081;
      } else {
        result[0] += 0.016449205223521616;
      }
    } else {
      result[0] += 0.02748403197978947;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.607134570361309911) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4471985607798013018) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2721741080702284044) ) ) {
        result[0] += -0.025430122429118577;
      } else {
        result[0] += -0.015083201907959658;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6513175839869357331) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 0.00041762066839227155;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003296500000000000385) ) ) {
            result[0] += -0.013171987303277332;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6277403467108452206) ) ) {
              result[0] += -0.0010093454165404638;
            } else {
              result[0] += -0.011078722727237374;
            }
          }
        }
      } else {
        result[0] += 0.002043607349071247;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7141856296356029477) ) ) {
      result[0] += 0.011158704584969452;
    } else {
      result[0] += 0.027349479491904777;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7877973938526349196) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4697693723122448595) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2721741080702284044) ) ) {
        result[0] += -0.02529233291128583;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += -0.007206515717040566;
        } else {
          result[0] += -0.01675353947195528;
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.655609054534752711) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 0.0010374670048846684;
        } else {
          result[0] += -0.006289007425223779;
        }
      } else {
        result[0] += 0.002207920373779178;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7141856296356029477) ) ) {
      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.637063197009426152) ) ) {
        result[0] += 0.006116513042711184;
      } else {
        result[0] += 0.013461475650784082;
      }
    } else {
      result[0] += 0.02721619677938282;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7877973938526349196) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4243526687260518182) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2002749652849908635) ) ) {
        result[0] += -0.026616872080939297;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.300000000000000843e-05) ) ) {
          result[0] += -0.010746164833666668;
        } else {
          result[0] += -0.019577365058385848;
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6038797007738568867) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1850000000000000255) ) ) {
          result[0] += 0.0039165133485233065;
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5201676432420939689) ) ) {
            result[0] += -0.012248528395410907;
          } else {
            result[0] += -0.005196673196322378;
          }
        }
      } else {
        result[0] += 0.0009043551615259082;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7141856296356029477) ) ) {
      result[0] += 0.010940101424215509;
    } else {
      result[0] += 0.027084069292174766;
    }
  }
}

