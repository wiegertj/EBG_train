
#include "header.h"

void predict_unit8(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6415213458272231994) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3474450840415687081) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1596646965685780961) ) ) {
        result[0] += -0.04311541650141098;
      } else {
        result[0] += -0.02248410854555779;
      }
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6526844655663904815) ) ) {
        result[0] += -0.007176702084466591;
      } else {
        result[0] += 0.004119749487394679;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7497367709113804679) ) ) {
      result[0] += 0.021808071917599377;
    } else {
      result[0] += 0.04128973078514943;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6415213458272231994) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.258569720040409734) ) ) {
      result[0] += -0.037099593903082914;
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5431651591220142405) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.650000000000000541e-05) ) ) {
          result[0] += 0.0014493546759966173;
        } else {
          result[0] += -0.016434959121965968;
        }
      } else {
        result[0] += 0.0015540082614300503;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7497367709113804679) ) ) {
      result[0] += 0.021208252005200084;
    } else {
      result[0] += 0.04099511169042958;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8707605184368226725) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.258569720040409734) ) ) {
      result[0] += -0.036727931896211;
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5055241589195451635) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0002245000000000000088) ) ) {
          result[0] += 0;
        } else {
          result[0] += -0.018182720732443213;
        }
      } else {
        result[0] += 0.0004030765230678003;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7497367709113804679) ) ) {
      result[0] += 0.018397044217485725;
    } else {
      result[0] += 0.04069917692959648;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6415213458272231994) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.258569720040409734) ) ) {
      result[0] += -0.03635174068905161;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5966361188013137307) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 0.0037726145616994557;
        } else {
          result[0] += -0.013352077436238487;
        }
      } else {
        result[0] += 0.0025287791077860267;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.841376214053286442) ) ) {
      result[0] += 0.02339627843257699;
    } else {
      result[0] += 0.04331201489138743;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6415213458272231994) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.258569720040409734) ) ) {
      result[0] += -0.03597082502832078;
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5055241589195451635) ) ) {
        result[0] += -0.012634873270087258;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004746500000000001586) ) ) {
          result[0] += -0.004484505838676204;
        } else {
          result[0] += 0.0056697928833794;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.841376214053286442) ) ) {
      result[0] += 0.022807914059455217;
    } else {
      result[0] += 0.043105923405450206;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6415213458272231994) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.258569720040409734) ) ) {
      result[0] += -0.03558500057286024;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6438205396169394135) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 0.005042822370691147;
        } else {
          result[0] += -0.010897102624567718;
        }
      } else {
        result[0] += 0.003348449484482803;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.841376214053286442) ) ) {
      result[0] += 0.02222571223585551;
    } else {
      result[0] += 0.04290043871464143;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8707605184368226725) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.258569720040409734) ) ) {
      result[0] += -0.03519412014082158;
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.492025658416472611) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.650000000000000541e-05) ) ) {
          result[0] += 0.0004375529588208371;
        } else {
          result[0] += -0.017446666092128017;
        }
      } else {
        result[0] += 0.00020124265587948795;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7497367709113804679) ) ) {
      result[0] += 0.016545233861201995;
    } else {
      result[0] += 0.039544241078808884;
    }
  }
}

