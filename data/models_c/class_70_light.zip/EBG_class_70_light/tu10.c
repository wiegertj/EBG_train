
#include "header.h"

void predict_unit10(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8341961608046256638) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3423866036000239865) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1353015872182791457) ) ) {
        result[0] += -0.02728913771186859;
      } else {
        result[0] += -0.01794714477328462;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5524193294893345874) ) ) {
        result[0] += -0.008501179461503658;
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.704198211736497548) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4150000000000000355) ) ) {
            result[0] += 0.003268410203004479;
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6085980263006282032) ) ) {
              result[0] += -0.010879572191819762;
            } else {
              result[0] += -0.0016061573972776155;
            }
          }
        } else {
          result[0] += 0.0033910157740502573;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.746072903742064919) ) ) {
      result[0] += 0.012028817688302136;
    } else {
      result[0] += 0.026740747387451132;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.637063197009426152) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3423866036000239865) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1353015872182791457) ) ) {
        result[0] += -0.027215629636504136;
      } else {
        result[0] += -0.017734755156112468;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5524193294893345874) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3650000000000000466) ) ) {
          result[0] += -0.005162164986320956;
        } else {
          result[0] += -0.012204792773960754;
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6746411929901378057) ) ) {
          if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.3399990879818117206) ) ) {
            result[0] += 0.0038741836218861955;
          } else {
            result[0] += -0.004357143725189405;
          }
        } else {
          result[0] += 0.002398479223310547;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.733482828522406094) ) ) {
      result[0] += 0.010678096742418056;
    } else {
      result[0] += 0.026340753536412485;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.844661369991607125) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4243526687260518182) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2002749652849908635) ) ) {
        result[0] += -0.025459481151253936;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.300000000000000843e-05) ) ) {
          result[0] += -0.008177018763968586;
        } else {
          result[0] += -0.01735243503313207;
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.655609054534752711) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0004268439528877000528) ) ) {
          result[0] += 0.0007509873369543601;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003370500000000000666) ) ) {
            result[0] += -0.011553914745278343;
          } else {
            result[0] += -0.002180479622880082;
          }
        }
      } else {
        result[0] += 0.0025128830767925854;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.746072903742064919) ) ) {
      result[0] += 0.012121550581854212;
    } else {
      result[0] += 0.026523965559919375;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.844661369991607125) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3423866036000239865) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1353015872182791457) ) ) {
        result[0] += -0.027074499919001252;
      } else {
        result[0] += -0.017323295324991956;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5843380316172624989) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0004268439528877000528) ) ) {
          result[0] += -0.0011063681877073695;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002072500000000000557) ) ) {
            result[0] += -0.016579848833698403;
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
              result[0] += -0.0041137011659957015;
            } else {
              result[0] += -0.01673816454061715;
            }
          }
        }
      } else {
        result[0] += 0.0013200926185392174;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.746072903742064919) ) ) {
      result[0] += 0.011894633085197457;
    } else {
      result[0] += 0.026415549272362327;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.844661369991607125) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3423866036000239865) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1353015872182791457) ) ) {
        result[0] += -0.027002248963427084;
      } else {
        result[0] += -0.017111182280197024;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5561432885305349627) ) ) {
        result[0] += -0.007703598921917798;
      } else {
        if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5508449206424210765) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1295212041281339765) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02065050000000000566) ) ) {
              result[0] += -0.00017137439735812106;
            } else {
              result[0] += 0.007493278867770803;
            }
          } else {
            result[0] += -0.0032819173559536;
          }
        } else {
          result[0] += 0.005218579423388029;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.746072903742064919) ) ) {
      result[0] += 0.011670550149024957;
    } else {
      result[0] += 0.026307407224268827;
    }
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6453796957695748793) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4471985607798013018) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2178518179945141686) ) ) {
        result[0] += -0.024683922200207552;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.300000000000000843e-05) ) ) {
          result[0] += -0.006678394500208133;
        } else {
          result[0] += -0.01549715199763698;
        }
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.655609054534752711) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0004268439528877000528) ) ) {
          result[0] += 0.0015251823917470392;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001184500000000000223) ) ) {
            result[0] += -0.016043073268913414;
          } else {
            result[0] += -0.00338296555186329;
          }
        }
      } else {
        result[0] += 0.0030134303620251634;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7525782865880930039) ) ) {
      result[0] += 0.014210555925873832;
    } else {
      result[0] += 0.026304243213363967;
    }
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6453796957695748793) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3423866036000239865) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1353015872182791457) ) ) {
        result[0] += -0.026864622482789317;
      } else {
        result[0] += -0.016699575107546397;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5991184370131029668) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += -0.0006580561253083452;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00344350000000000038) ) ) {
            result[0] += -0.013926703130127588;
          } else {
            result[0] += -0.004060293446834726;
          }
        }
      } else {
        if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5854397126054067257) ) ) {
          result[0] += 0.00013485113860857418;
        } else {
          result[0] += 0.005286232978530518;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7525782865880930039) ) ) {
      result[0] += 0.013976792832749203;
    } else {
      result[0] += 0.026198442437897693;
    }
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6453796957695748793) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3423866036000239865) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1353015872182791457) ) ) {
        result[0] += -0.026793147611192822;
      } else {
        result[0] += -0.01648795643899972;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.622330635648172481) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 0.00034927526606657694;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003370500000000000666) ) ) {
            result[0] += -0.013190673908011688;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6277403467108452206) ) ) {
              result[0] += -0.0008587018365776314;
            } else {
              result[0] += -0.011721181588218105;
            }
          }
        }
      } else {
        result[0] += 0.0023178811682800136;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.746072903742064919) ) ) {
      result[0] += 0.013545696360971013;
    } else {
      result[0] += 0.02598478343870494;
    }
  }
}

