
#include "header.h"

void predict_unit10(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7291204255332855988) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3768882457614676773) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1887226699691260667) ) ) {
        result[0] += -0.0632541211784146;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)2.800000000000000297e-05) ) ) {
          result[0] += -0.032715586883048806;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
            result[0] += -0.005007728271856139;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2656063113060950776) ) ) {
              result[0] += -0.059001277153734336;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0650000000000000161) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6555524765326633529) ) ) {
                  result[0] += -0.028367823927697537;
                } else {
                  result[0] += 0.04516442697846795;
                }
              } else {
                result[0] += -0.047375089763282044;
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5395439842637465011) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1850000000000000255) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4832226418609977259) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1764963302915136534) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04334500000000000852) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6784611311055277483) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3995174958040201285) ) ) {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2250000000000000333) ) ) {
                      result[0] += -0.0023993555042684874;
                    } else {
                      result[0] += 0.09472205040191298;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4005412190101058645) ) ) {
                      result[0] += -0.033487655257712516;
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5029827918844221868) ) ) {
                        result[0] += -0.021913225637338555;
                      } else {
                        result[0] += 0.030237286240757038;
                      }
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6909237625376886127) ) ) {
                    result[0] += 0.11705938702729884;
                  } else {
                    result[0] += 0.013189831482033934;
                  }
                }
              } else {
                result[0] += -0.0453258702698003;
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3250000000000000666) ) ) {
                result[0] += -0.016481352961898562;
              } else {
                result[0] += -0.048214189057694944;
              }
            }
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3763018001168558224) ) ) {
              result[0] += -0.04016135166457757;
            } else {
              result[0] += 0.040057631603197884;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4591620551040981879) ) ) {
            result[0] += -0.03457432754633305;
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2384269498305124635) ) ) {
              result[0] += -0.008352793904785969;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7890731911809046872) ) ) {
                result[0] += -0.0212707983466331;
              } else {
                result[0] += -0.04418856781871684;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6592877443879057164) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002786500000000000348) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3250000000000000666) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3550000000000000377) ) ) {
                  result[0] += 0.02769144462026068;
                } else {
                  result[0] += -0.04082172395762901;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5934571403915865906) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4050000000000000822) ) ) {
                    result[0] += 0.007753985721167267;
                  } else {
                    result[0] += -0.019053941569354374;
                  }
                } else {
                  result[0] += 0.018046608305697886;
                }
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5250000000000001332) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.735388073517588059) ) ) {
                  result[0] += -0.05303031633994174;
                } else {
                  result[0] += 0.021334114851865916;
                }
              } else {
                result[0] += -0.015085111448793919;
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8250000000000000666) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7250000000000000888) ) ) {
                result[0] += -0.002332348475863776;
              } else {
                result[0] += -0.01972148319998242;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.104347816094000123) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8350000000000000755) ) ) {
                  result[0] += 0.09178414136031962;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7473910280653267568) ) ) {
                    if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1725637113259415323) ) ) {
                      result[0] += 0.06587237218368527;
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5778807480402011754) ) ) {
                        result[0] += -0.04617178811455007;
                      } else {
                        result[0] += 0.015888438613448404;
                      }
                    }
                  } else {
                    result[0] += 0.07229465236017718;
                  }
                }
              } else {
                result[0] += -0.0372432965232664;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4550000000000000711) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01359450000000000068) ) ) {
              result[0] += 0.05999541232402806;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6407246092964825612) ) ) {
                result[0] += 0.0022699476742826658;
              } else {
                result[0] += 0.05166291204610835;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009910500000000000906) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5550000000000001599) ) ) {
                result[0] += 0.01829446832606642;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6828368804818342186) ) ) {
                  result[0] += -0.01047929873338963;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5650000000000000577) ) ) {
                    result[0] += 0.03655374335572198;
                  } else {
                    result[0] += 0.002801335601676317;
                  }
                }
              }
            } else {
              result[0] += -0.011099736302726666;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6800585241488680266) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8668343417017452257) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6445926074073893286) ) ) {
          result[0] += 0.013130621368939386;
        } else {
          result[0] += 0.03371283633821545;
        }
      } else {
        result[0] += 0.03085774125193797;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7994052243814134817) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9650000000000000799) ) ) {
          result[0] += 0.05086564267963543;
        } else {
          result[0] += 0.02170052795326895;
        }
      } else {
        result[0] += 0.06624703032779504;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7291204255332855988) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3721486820686056851) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1887226699691260667) ) ) {
        result[0] += -0.06271506921400032;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)2.800000000000000297e-05) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.05580247069824354617) ) ) {
            result[0] += -0.047564398507329166;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6518490842730284562) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.09500000000000001499) ) ) {
                result[0] += -0.05199073259262921;
              } else {
                result[0] += -0.014343625437150289;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883661844891582726) ) ) {
                result[0] += -0.04231883142593653;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9003665952763820757) ) ) {
                  result[0] += 0.07672881008757731;
                } else {
                  result[0] += -0.0558678436390791;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
            result[0] += -0.0047243021206499385;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2656063113060950776) ) ) {
              result[0] += -0.05819114670285627;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0650000000000000161) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.03500000000000001027) ) ) {
                  result[0] += -0.054996838977773375;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6503388817085428153) ) ) {
                    result[0] += -0.010472757226625565;
                  } else {
                    result[0] += 0.05478868899413459;
                  }
                }
              } else {
                result[0] += -0.04613956631233409;
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5395439842637465011) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4850000000000000422) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4705679967383486484) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1764963302915136534) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3457619648241206378) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1996047352047869705) ) ) {
                  result[0] += 0;
                } else {
                  result[0] += 0.12457091832905928;
                }
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6729764489447237485) ) ) {
                  result[0] += -0.022603208346702347;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6277403467108452206) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6909237625376886127) ) ) {
                      result[0] += 0.07562256078227068;
                    } else {
                      result[0] += -0.00688086846778098;
                    }
                  } else {
                    result[0] += -0.008283756628497627;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002122500000000000688) ) ) {
                result[0] += -0.04061925012564413;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3904868333447728546) ) ) {
                  result[0] += -0.0511824095993952;
                } else {
                  result[0] += -0.02051473778504612;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2055020000000000457) ) ) {
              result[0] += -0.011895797179882492;
            } else {
              result[0] += 0.05925627912262117;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004677500000000000234) ) ) {
            result[0] += -0.03975786000248357;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -0.003652058752965383;
            } else {
              result[0] += -0.04027939282002534;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6741462157421617141) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
            result[0] += 0.0024843239197448776;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5825139232263935041) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4250000000000000444) ) ) {
                result[0] += -0.009211161730578338;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
                  result[0] += -0.03143783633609173;
                } else {
                  result[0] += 0.031104117891533993;
                }
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                result[0] += 0.009016400926739759;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001166500000000000219) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9650000000000000799) ) ) {
                    result[0] += -0.025029045087095296;
                  } else {
                    result[0] += 0.06314240186812939;
                  }
                } else {
                  result[0] += -0.004021751600375036;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6050000000000000933) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00657450000000000135) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005489500000000000456) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004332500000000000413) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8123212939698493118) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7074300481310827893) ) ) {
                      result[0] += 0.011872886151688238;
                    } else {
                      result[0] += 0.049858913946181284;
                    }
                  } else {
                    result[0] += -0.038629730873306144;
                  }
                } else {
                  result[0] += -0.025090174752825146;
                }
              } else {
                result[0] += 0.058775760001460634;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4450000000000000622) ) ) {
                result[0] += 0.015645531666013672;
              } else {
                result[0] += -0.005187306958420534;
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8290814278894472755) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.008815500000000002154) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8054659791206031372) ) ) {
                  result[0] += -0.002434064756517952;
                } else {
                  result[0] += -0.06047067276844116;
                }
              } else {
                result[0] += -0.05981492540236926;
              }
            } else {
              result[0] += 0.0381288180442355;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6800585241488680266) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8668343417017452257) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6445926074073893286) ) ) {
          result[0] += 0.012359960713296035;
        } else {
          result[0] += 0.03226253817119139;
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9550000000000000711) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5519124520502908249) ) ) {
            result[0] += 0.012486165107349895;
          } else {
            result[0] += 0.04055356170508272;
          }
        } else {
          result[0] += 0.022389278714605686;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8373354933349520524) ) ) {
        result[0] += 0.05004496008609548;
      } else {
        result[0] += 0.06684927068806448;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7811682765315622889) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4094140003309167386) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2252442705517153365) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1076279909068390134) ) ) {
          result[0] += -0.06567202143447769;
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3321712357788945136) ) ) {
            result[0] += 0.03323459863579232;
          } else {
            result[0] += -0.0538884160673439;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)2.800000000000000297e-05) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03500000000000001027) ) ) {
            result[0] += 0.009684082514876478;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3288621490399925573) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5145936098743719711) ) ) {
                result[0] += -0.05462987817948915;
              } else {
                result[0] += -0.028507188005305575;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883661844891582726) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3321712357788945136) ) ) {
                  result[0] += 0.0502174412471123;
                } else {
                  result[0] += -0.02168260090217032;
                }
              } else {
                result[0] += 0.07611676104470343;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7425707671105529206) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9808239647505231362) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01151050000000000163) ) ) {
                result[0] += -0.04555291937281452;
              } else {
                result[0] += -0.025923340216503016;
              }
            } else {
              result[0] += 0.020516970017789196;
            }
          } else {
            result[0] += -0.054446790910612206;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6095226520848766594) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.515143529846740944) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2792435502835992067) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4450000000000000622) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4350000000000000533) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8254037945979900703) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6732382808793971884) ) ) {
                    result[0] += -0.015001997601201085;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4321942852785685685) ) ) {
                      result[0] += -0.02803562988435904;
                    } else {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2850000000000000866) ) ) {
                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9310018456912946272) ) ) {
                          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6828811456281408399) ) ) {
                            result[0] += 0.0799521008382624;
                          } else {
                            result[0] += -0.0038221374637098567;
                          }
                        } else {
                          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.145614105386054682) ) ) {
                            result[0] += 0.09990030703501519;
                          } else {
                            result[0] += 0.01750891709361742;
                          }
                        }
                      } else {
                        result[0] += -0.023279967281096377;
                      }
                    }
                  }
                } else {
                  result[0] += -0.05822049205690701;
                }
              } else {
                result[0] += 0.07619658215560036;
              }
            } else {
              result[0] += -0.039227090668722535;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.966590843157139501) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003224500000000000369) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9033411549107539518) ) ) {
                  result[0] += -0.039150739061996224;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4747086856097625374) ) ) {
                    result[0] += -0.05413063330305328;
                  } else {
                    result[0] += 0.09294823855411999;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003357500000000000675) ) ) {
                  result[0] += 0.053515468464651834;
                } else {
                  result[0] += -0.018335818560110878;
                }
              }
            } else {
              result[0] += -0.050806781790535493;
            }
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2944793848334646413) ) ) {
            result[0] += -0.0024146168026706106;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3950000000000000733) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4050000000000000822) ) ) {
                result[0] += -0.04674264893259234;
              } else {
                result[0] += -0.004511911049744336;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4550000000000000711) ) ) {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.316132418552224348) ) ) {
                  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3308375782921226249) ) ) {
                    result[0] += 0.08983188437575264;
                  } else {
                    result[0] += -0.0005623491824352648;
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5340979636934674035) ) ) {
                    result[0] += -0.039142985871222086;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.55339496178391967) ) ) {
                      result[0] += 0.07022928401254877;
                    } else {
                      result[0] += -0.002208221926996776;
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001627500000000000257) ) ) {
                  result[0] += -0.024252229668121187;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7683067979899498301) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7608008567839197323) ) ) {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.02448774902434403) ) ) {
                        result[0] += -0.00937678691539189;
                      } else {
                        result[0] += 0.08972810355414029;
                      }
                    } else {
                      result[0] += 0.11734117487804767;
                    }
                  } else {
                    result[0] += -0.03176563558966267;
                  }
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6976830617481789565) ) ) {
          result[0] += -0.0015570457182341342;
        } else {
          result[0] += 0.006740166330255801;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7126859971266824578) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8898401904750864455) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6260154606475681893) ) ) {
          result[0] += 0.014249485939001116;
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003697500000000000699) ) ) {
            result[0] += 0.021162458639071204;
          } else {
            result[0] += 0.043118633314836015;
          }
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8258070345152316305) ) ) {
          result[0] += 0.03350820937525696;
        } else {
          result[0] += -0.037346107883056846;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8373354933349520524) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2929122217587940002) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2669585275879397535) ) ) {
            result[0] += 0.026311788401923514;
          } else {
            result[0] += -0.06943207645786029;
          }
        } else {
          result[0] += 0.05341292739440627;
        }
      } else {
        result[0] += 0.06634613765695753;
      }
    }
  }
}

