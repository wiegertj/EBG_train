
#include "header.h"

void predict_unit10(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6953050394685441615) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1596646965685780961) ) ) {
      result[0] += -0.0407201805693274;
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4744068267591841637) ) ) {
        result[0] += -0.01192141588197991;
      } else {
        if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5797375516240159676) ) ) {
          result[0] += -0.001070942868400678;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.022863724499978227;
          } else {
            result[0] += 0.0037378219253176347;
          }
        }
      }
    }
  } else {
    result[0] += 0.03351537630336818;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7221143281151479743) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1596646965685780961) ) ) {
      result[0] += -0.04051414346381696;
    } else {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5447856234025308941) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4236855092944680212) ) ) {
          result[0] += -0.01352161695605584;
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.008634500000000001549) ) ) {
            result[0] += -0.006044816744120242;
          } else {
            result[0] += 0.003640283002297118;
          }
        }
      } else {
        result[0] += 0.00803761407304852;
      }
    }
  } else {
    result[0] += 0.03537516830539167;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7221143281151479743) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1596646965685780961) ) ) {
      result[0] += -0.04030447167148307;
    } else {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5447856234025308941) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4447155022895915022) ) ) {
          result[0] += -0.012342366577145138;
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.008634500000000001549) ) ) {
            result[0] += -0.005560402953858499;
          } else {
            result[0] += 0.0034802909752857584;
          }
        }
      } else {
        result[0] += 0.007721909786889477;
      }
    }
  } else {
    result[0] += 0.03499117115025623;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7286792202408863828) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1596646965685780961) ) ) {
      result[0] += -0.04009091444596283;
    } else {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5447856234025308941) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 0.005809213116534319;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004746500000000001586) ) ) {
            result[0] += -0.014148706440084712;
          } else {
            result[0] += 0;
          }
        }
      } else {
        result[0] += 0.00750187354099104;
      }
    }
  } else {
    result[0] += 0.035121946279062094;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7286792202408863828) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1596646965685780961) ) ) {
      result[0] += -0.039873232597171404;
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5222727956694942497) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.650000000000000541e-05) ) ) {
          result[0] += 0.001709759468794387;
        } else {
          result[0] += -0.013689794772683134;
        }
      } else {
        if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5797375516240159676) ) ) {
          result[0] += -0.0004663839508432721;
        } else {
          result[0] += 0.008929932341233604;
        }
      }
    }
  } else {
    result[0] += 0.03473952779774608;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7357947538897144923) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1596646965685780961) ) ) {
      result[0] += -0.03965117784486177;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.765966927815004861) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 0.005660928915490395;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003591500000000000508) ) ) {
            result[0] += -0.012012723187384125;
          } else {
            result[0] += -0.0006213360797945448;
          }
        }
      } else {
        result[0] += 0.007079146447610484;
      }
    }
  } else {
    result[0] += 0.03479896234132177;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7357947538897144923) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1596646965685780961) ) ) {
      result[0] += -0.03942452182837171;
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4744068267591841637) ) ) {
        result[0] += -0.010346134631632455;
      } else {
        if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5797375516240159676) ) ) {
          result[0] += -0.0006970317084191957;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.021188998886081764;
          } else {
            result[0] += 0.0033381822986129923;
          }
        }
      }
    }
  } else {
    result[0] += 0.03441525992250035;
  }
}

