
#include "header.h"

void predict_unit4(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7024961766447593847) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4976396106036372058) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2656063113060950776) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1247736973015392964) ) ) {
          result[0] += -0.07812846401846661;
        } else {
          result[0] += -0.0720987502833837;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4094140003309167386) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)2.800000000000000297e-05) ) ) {
            result[0] += -0.05279638039498809;
          } else {
            result[0] += -0.06621505280988965;
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1917993845848007251) ) ) {
            result[0] += -0.03226559636853158;
          } else {
            result[0] += -0.05425439931354727;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6095226520848766594) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2944793848334646413) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5265509790734695938) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1750000000000000167) ) ) {
              result[0] += 0.019591581914283472;
            } else {
              result[0] += -0.03689983453976256;
            }
          } else {
            result[0] += -0.014727755151065568;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5395439842637465011) ) ) {
            result[0] += -0.05009148762766271;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003615500000000000224) ) ) {
              result[0] += -0.037841592886419945;
            } else {
              result[0] += -0.02259451085116113;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6592877443879057164) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002843500000000000541) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3699790940065486589) ) ) {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3037124426228626772) ) ) {
                result[0] += -0.031162752714469413;
              } else {
                result[0] += 0.04432833561394848;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6207300888023185026) ) ) {
                result[0] += -0.05125561983357954;
              } else {
                if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4669321015175124656) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001205500000000000191) ) ) {
                    result[0] += -0.026962458941844746;
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001482500000000000094) ) ) {
                      result[0] += 0.0336007509861325;
                    } else {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6126225748691961348) ) ) {
                        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2252565153835193457) ) ) {
                          result[0] += 0.015657230852723962;
                        } else {
                          result[0] += -0.04104762910993309;
                        }
                      } else {
                        result[0] += 0.02345289914222459;
                      }
                    }
                  }
                } else {
                  result[0] += -0.044056546628469404;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3050000000000000488) ) ) {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3086185049584930229) ) ) {
                result[0] += -0.033710705587249694;
              } else {
                result[0] += 0.046077761152227496;
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8150000000000000577) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7150000000000000799) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0670105000000000145) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6430839056532664522) ) ) {
                      result[0] += -0.004425558420659735;
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4750000000000000333) ) ) {
                        result[0] += 0.08237245525021429;
                      } else {
                        result[0] += 0.014918599883594032;
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4250000000000000444) ) ) {
                      result[0] += 0.014036099132401442;
                    } else {
                      result[0] += -0.058320128083171455;
                    }
                  }
                } else {
                  result[0] += -0.03205776390409936;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6343929365935514486) ) ) {
                  result[0] += -0.013150328963707969;
                } else {
                  result[0] += 0.028742928635138335;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4550000000000000711) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01219250000000000195) ) ) {
              result[0] += 0.07559288500627048;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5692525541959799762) ) ) {
                if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3978122566392368609) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6875734944390267112) ) ) {
                    result[0] += -0.006107619667232129;
                  } else {
                    result[0] += 0.036561345710844524;
                  }
                } else {
                  result[0] += -0.045500696552428055;
                }
              } else {
                result[0] += 0.04223994778706016;
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4650000000000000244) ) ) {
              result[0] += -0.04972937561278181;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0003885000000000000649) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06355808660527756393) ) ) {
                  result[0] += 0.06078842832387151;
                } else {
                  result[0] += 0.0008183467825238718;
                }
              } else {
                result[0] += -0.004421905977154516;
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8898401904750864455) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.79000980692407341) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6380671833187036013) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7638123743065539095) ) ) {
            result[0] += 0.021196950272419683;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.505061141934673441) ) ) {
              if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3229672932059334256) ) ) {
                result[0] += 0.034384732660978745;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05738700000000000745) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6050000000000000933) ) ) {
                    result[0] += -0.06676343373507634;
                  } else {
                    result[0] += 0;
                  }
                } else {
                  result[0] += 0.058608118880917374;
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5235867797738694707) ) ) {
                result[0] += 0.08448663364631989;
              } else {
                result[0] += 0.03700020107725217;
              }
            }
          }
        } else {
          result[0] += 0.043317293978671595;
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6260154606475681893) ) ) {
          result[0] += 0.04552906055973722;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8377147368991872955) ) ) {
            result[0] += 0.05070917259805212;
          } else {
            result[0] += 0.07029841568396811;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7409427245099348136) ) ) {
        result[0] += 0.07037328787972275;
      } else {
        result[0] += 0.0847377081995937;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7024961766447593847) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4591620551040981879) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2656063113060950776) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1247736973015392964) ) ) {
          result[0] += -0.07692906373995095;
        } else {
          result[0] += -0.07066250883971159;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)2.800000000000000297e-05) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883661844891582726) ) ) {
            result[0] += -0.051468262470131164;
          } else {
            result[0] += 0.006203018533663722;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4094140003309167386) ) ) {
            result[0] += -0.06450957070395075;
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1917993845848007251) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3750110022441224822) ) ) {
                result[0] += -0.03199129745008115;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04047250000000000153) ) ) {
                  result[0] += 0.06955743944059456;
                } else {
                  result[0] += -0.013405107139334595;
                }
              }
            } else {
              result[0] += -0.057150465723924376;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5825139232263935041) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2700291939076160941) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.038794232605861678) ) ) {
            result[0] += 0.04548553949500029;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5265509790734695938) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1650000000000000355) ) ) {
                result[0] += 0;
              } else {
                result[0] += -0.036916464806031564;
              }
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2328444889043961574) ) ) {
                result[0] += -0.04492306959340973;
              } else {
                result[0] += -0.0036458625745546635;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.515143529846740944) ) ) {
            result[0] += -0.054293643935609086;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3950000000000000733) ) ) {
                result[0] += -0.023599686758926066;
              } else {
                result[0] += 0.016210244246012005;
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3865950184387632049) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5395439842637465011) ) ) {
                  result[0] += -0.04246743507825802;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.07976950000000000707) ) ) {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0009705000000000001169) ) ) {
                      result[0] += -0.035327382737446435;
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6796249047236181395) ) ) {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5435253867705854836) ) ) {
                          result[0] += 0.020660225521482077;
                        } else {
                          result[0] += -0.022268290415146046;
                        }
                      } else {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3650000000000000466) ) ) {
                          result[0] += 0.0901921630607253;
                        } else {
                          result[0] += 0.0009692824566643487;
                        }
                      }
                    }
                  } else {
                    result[0] += -0.07616781315318351;
                  }
                }
              } else {
                result[0] += -0.04411464311191547;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6304742050590899094) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7050000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5250000000000001332) ) ) {
              result[0] += -0.006367371787200645;
            } else {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4109528373652364119) ) ) {
                result[0] += -0.06721820535536792;
              } else {
                result[0] += 0.002728634071111044;
              }
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4150000000000000355) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3950000000000000733) ) ) {
                result[0] += -0.030147171454263266;
              } else {
                result[0] += 0.04980389964978449;
              }
            } else {
              result[0] += -0.0372485695388471;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4550000000000000711) ) ) {
            result[0] += 0.00715040889647239;
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1725637113259415323) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4650000000000000244) ) ) {
                result[0] += -0.0738784644020156;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9150000000000001465) ) ) {
                  result[0] += 0.003395118785940176;
                } else {
                  result[0] += 0.05132253578992706;
                }
              }
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.08835747683243963535) ) ) {
                result[0] += -0.038145731143858205;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.625000000000000111) ) ) {
                  result[0] += 0.016335670659450848;
                } else {
                  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4153271040333154085) ) ) {
                    result[0] += -0.02860547595819371;
                  } else {
                    result[0] += -0.005009157131184367;
                  }
                }
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8898401904750864455) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.79000980692407341) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7341196086063838111) ) ) {
          result[0] += 0.016532784391466552;
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5894867046835161606) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5245354220245331822) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3623115618844221508) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6550000000000001377) ) ) {
                  result[0] += 0.032442186822140937;
                } else {
                  result[0] += -0.04850630441307572;
                }
              } else {
                result[0] += 0.03718766232331732;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.138279000000000013) ) ) {
                result[0] += 0.017940221166130307;
              } else {
                result[0] += -0.04094637019078244;
              }
            }
          } else {
            result[0] += 0.03568886622102538;
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6445926074073893286) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00101050000000000033) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)2.800000000000000297e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9450000000000000622) ) ) {
                result[0] += 0.02108063739048982;
              } else {
                result[0] += 0.09214434642806418;
              }
            } else {
              result[0] += 0.0043754683467349415;
            }
          } else {
            result[0] += 0.04651693185980582;
          }
        } else {
          result[0] += 0.06533228454982118;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7126859971266824578) ) ) {
        result[0] += 0.06591277893053553;
      } else {
        result[0] += 0.0821921066363526;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7024961766447593847) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4591620551040981879) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2656063113060950776) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1247736973015392964) ) ) {
          result[0] += -0.07583019348265764;
        } else {
          result[0] += -0.06930330287743196;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)2.800000000000000297e-05) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883661844891582726) ) ) {
            result[0] += -0.04966202765102028;
          } else {
            result[0] += 0.005822088040787085;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4094140003309167386) ) ) {
            result[0] += -0.06287406164612884;
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1917993845848007251) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3750110022441224822) ) ) {
                result[0] += -0.030486104529898625;
              } else {
                result[0] += 0.03548607051763413;
              }
            } else {
              result[0] += -0.05532182377218332;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5825139232263935041) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2783343642141558605) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5265509790734695938) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1650000000000000355) ) ) {
              result[0] += 0;
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.038794232605861678) ) ) {
                result[0] += 0.04613373544769464;
              } else {
                result[0] += -0.036395050717714005;
              }
            }
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2328444889043961574) ) ) {
              result[0] += -0.029523605857799347;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2050000000000000433) ) ) {
                result[0] += 0.0683531619291813;
              } else {
                result[0] += -0.008013017951623581;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5395439842637465011) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2450000000000000233) ) ) {
              result[0] += 0.004274225653154589;
            } else {
              result[0] += -0.04905770846294187;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3865950184387632049) ) ) {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.469327283602055445) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5549087542219263147) ) ) {
                  result[0] += -0.028423309061054412;
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3950000000000000733) ) ) {
                    result[0] += -0.010008454187659624;
                  } else {
                    result[0] += 0.0929057949596268;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5435253867705854836) ) ) {
                  result[0] += 0.012764974761938377;
                } else {
                  result[0] += -0.02667994988111893;
                }
              }
            } else {
              result[0] += -0.040152546014061694;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6304742050590899094) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7050000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5250000000000001332) ) ) {
              result[0] += -0.005976152899014949;
            } else {
              result[0] += -0.04190382265886305;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4150000000000000355) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3950000000000000733) ) ) {
                result[0] += -0.02858970640647163;
              } else {
                result[0] += 0.04616604529474949;
              }
            } else {
              result[0] += -0.03541162949770487;
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002037500000000000682) ) ) {
            result[0] += -0.009123816843495941;
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3296315496301309156) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3797425373115578262) ) ) {
                result[0] += -0.006915986334194156;
              } else {
                result[0] += 0.03325945738669344;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5910501547487437835) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2850000000000000866) ) ) {
                  result[0] += 0.04072139068334368;
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4650000000000000244) ) ) {
                    result[0] += -0.04389158290964078;
                  } else {
                    result[0] += -0.008623379156875966;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6014274169849246343) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.008996500000000002759) ) ) {
                    result[0] += 0.08416661854815428;
                  } else {
                    result[0] += 0;
                  }
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5850000000000000755) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06526450000000001694) ) ) {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.621633360905828769) ) ) {
                        result[0] += 0.02978230835399452;
                      } else {
                        result[0] += 0.12088572754740538;
                      }
                    } else {
                      result[0] += -0.010089687303783504;
                    }
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2817916214990286439) ) ) {
                      result[0] += -0.03316108800483891;
                    } else {
                      result[0] += 0.0036600448656457286;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8898401904750864455) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7855725197646558078) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5841461392757277826) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8507017292462312197) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5150000000000001243) ) ) {
              result[0] += 0.028327941207490593;
            } else {
              result[0] += 0.01280100244063854;
            }
          } else {
            result[0] += 0.0799292535741169;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001999500000000000409) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7397377521765559072) ) ) {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2672247508226724966) ) ) {
                result[0] += -0.0458661571046193;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2542665105872564113) ) ) {
                  result[0] += 0.03898355221308859;
                } else {
                  result[0] += -0.0011948479491157718;
                }
              }
            } else {
              result[0] += 0.029931279546449824;
            }
          } else {
            result[0] += 0.03965885825986512;
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6260154606475681893) ) ) {
          result[0] += 0.03999163053267205;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8377147368991872955) ) ) {
            result[0] += 0.04715470362605125;
          } else {
            result[0] += 0.06547131507815036;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7409427245099348136) ) ) {
        result[0] += 0.06547977693744697;
      } else {
        result[0] += 0.08090480630763017;
      }
    }
  }
}

