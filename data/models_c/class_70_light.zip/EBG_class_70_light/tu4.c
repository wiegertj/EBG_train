
#include "header.h"

void predict_unit4(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6658449540838127234) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4471985607798013018) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2268996455050684702) ) ) {
        result[0] += -0.03182783508248595;
      } else {
        result[0] += -0.02582547597122629;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5524193294893345874) ) ) {
        result[0] += -0.017107848567979474;
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3450000000000000289) ) ) {
          result[0] += 0.0010756573471638433;
        } else {
          result[0] += -0.009666598786758799;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6840531608062441205) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7580984751822718026) ) ) {
        result[0] += 0.004563965701732313;
      } else {
        result[0] += 0.016977725098456124;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.733482828522406094) ) ) {
        result[0] += 0.027476609365124367;
      } else {
        result[0] += 0.03476751196819264;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7195042938813859257) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5024430027690397482) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2965188918505100024) ) ) {
        result[0] += -0.030900908288004958;
      } else {
        result[0] += -0.022745153462099293;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6373581005240800401) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3450000000000000289) ) ) {
          result[0] += -0.006025959507087247;
        } else {
          result[0] += -0.013761451282414202;
        }
      } else {
        result[0] += 0.00024186156357575625;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6549621339660968156) ) ) {
      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6179594490196074208) ) ) {
        result[0] += 0.009675933850453228;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9350000000000001643) ) ) {
          result[0] += 0.026769705597353696;
        } else {
          result[0] += 0.01670054551309612;
        }
      }
    } else {
      result[0] += 0.033352222382205275;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7195042938813859257) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5024430027690397482) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2965188918505100024) ) ) {
        result[0] += -0.03067769627930068;
      } else {
        result[0] += -0.022423316950636235;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6320766827776574948) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3450000000000000289) ) ) {
          result[0] += -0.006041711207412963;
        } else {
          result[0] += -0.013758391983854066;
        }
      } else {
        result[0] += -2.2166923349020677e-05;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6549621339660968156) ) ) {
      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6127668930946846837) ) ) {
        result[0] += 0.00911505250360269;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9350000000000001643) ) ) {
          result[0] += 0.02527816148766265;
        } else {
          result[0] += 0.016288730355539606;
        }
      }
    } else {
      result[0] += 0.03302136089971799;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6658449540838127234) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4471985607798013018) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2268996455050684702) ) ) {
        result[0] += -0.03120414237036479;
      } else {
        result[0] += -0.024927862262377646;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5561432885305349627) ) ) {
        result[0] += -0.015995184294368647;
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3450000000000000289) ) ) {
          result[0] += 0.002156877458995061;
        } else {
          result[0] += -0.00884928440763813;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6840531608062441205) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7693651808594642594) ) ) {
        result[0] += 0.004743751525076437;
      } else {
        result[0] += 0.016498957580839562;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.733482828522406094) ) ) {
        result[0] += 0.026185706479662896;
      } else {
        result[0] += 0.033873425858453106;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7195042938813859257) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4519258424761351534) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2721741080702284044) ) ) {
        result[0] += -0.030522899983405065;
      } else {
        result[0] += -0.0238059166824506;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5991184370131029668) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4450000000000000622) ) ) {
          result[0] += -0.010211769888276837;
        } else {
          result[0] += -0.017241022073026552;
        }
      } else {
        result[0] += -0.0016182356555705464;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6549621339660968156) ) ) {
      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6179594490196074208) ) ) {
        result[0] += 0.008910289372465487;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9350000000000001643) ) ) {
          result[0] += 0.025523987072954103;
        } else {
          result[0] += 0.015623465007640894;
        }
      }
    } else {
      result[0] += 0.032398044331972554;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6658449540838127234) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4471985607798013018) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2268996455050684702) ) ) {
        result[0] += -0.03081442238740818;
      } else {
        result[0] += -0.024336653884204775;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5524193294893345874) ) ) {
        result[0] += -0.015645919277073993;
      } else {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.3399990879818117206) ) ) {
          result[0] += -0.0006169398057360189;
        } else {
          result[0] += -0.009385993899404152;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6840531608062441205) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7693651808594642594) ) ) {
        result[0] += 0.004504330201257423;
      } else {
        result[0] += 0.01579862490153109;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.733482828522406094) ) ) {
        result[0] += 0.025378729741938062;
      } else {
        result[0] += 0.03332841957930576;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7195042938813859257) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4519258424761351534) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2721741080702284044) ) ) {
        result[0] += -0.030126300880073238;
      } else {
        result[0] += -0.023202633110197383;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5991184370131029668) ) ) {
        if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.2793434790857622363) ) ) {
          result[0] += -0.00889441757700698;
        } else {
          result[0] += -0.016047508366469773;
        }
      } else {
        result[0] += -0.0015153182478968633;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6549621339660968156) ) ) {
      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.607134570361309911) ) ) {
        result[0] += 0.007804513479971892;
      } else {
        result[0] += 0.017747111724340084;
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.746072903742064919) ) ) {
        result[0] += 0.026883726231349554;
      } else {
        result[0] += 0.03318703428866315;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7195042938813859257) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4519258424761351534) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2268996455050684702) ) ) {
        result[0] += -0.030445473702118926;
      } else {
        result[0] += -0.023630941128592507;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5991184370131029668) ) ) {
        result[0] += -0.012944708251000102;
      } else {
        result[0] += -0.0014749427122133204;
      }
    }
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6549621339660968156) ) ) {
      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6179594490196074208) ) ) {
        result[0] += 0.008199286271317012;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9350000000000001643) ) ) {
          result[0] += 0.02446335768037414;
        } else {
          result[0] += 0.014551517745135092;
        }
      }
    } else {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.746072903742064919) ) ) {
        result[0] += 0.02652890749028037;
      } else {
        result[0] += 0.032934938453822706;
      }
    }
  }
}

