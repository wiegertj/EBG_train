
#include "header.h"

void predict_unit4(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7413080085623182658) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4447155022895915022) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.258569720040409734) ) ) {
        result[0] += -0.047100316666507366;
      } else {
        result[0] += -0.03307906893564606;
      }
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5966361188013137307) ) ) {
        result[0] += -0.018207652337296973;
      } else {
        result[0] += -0.00036210568370907004;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6953050394685441615) ) ) {
      result[0] += 0.02364507959676523;
    } else {
      result[0] += 0.05020583074809121;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5750711537828580022) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4447155022895915022) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2025449053348033213) ) ) {
        result[0] += -0.048029988379679374;
      } else {
        result[0] += -0.03424025861362699;
      }
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5966361188013137307) ) ) {
        result[0] += -0.017585912782158507;
      } else {
        result[0] += 6.746469007692169e-05;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6953050394685441615) ) ) {
      result[0] += 0.024314719775628515;
    } else {
      result[0] += 0.04963644578985166;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7560013597309228617) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4447155022895915022) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2025449053348033213) ) ) {
        result[0] += -0.04765746356899226;
      } else {
        result[0] += -0.03357623469877896;
      }
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6222134205033998944) ) ) {
        result[0] += -0.01565084757329248;
      } else {
        result[0] += 0.001457406780596126;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7017935939707627968) ) ) {
      result[0] += 0.024044303301723836;
    } else {
      result[0] += 0.04929203386526928;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5817230669323919523) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4447155022895915022) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.258569720040409734) ) ) {
        result[0] += -0.04588181225568906;
      } else {
        result[0] += -0.03095834794650588;
      }
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5582897067648240341) ) ) {
        result[0] += -0.019359069623795033;
      } else {
        result[0] += -0.001504074211779761;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7017935939707627968) ) ) {
      result[0] += 0.023613170800517;
    } else {
      result[0] += 0.04877288362918828;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7608501190651052459) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4447155022895915022) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2025449053348033213) ) ) {
        result[0] += -0.04696117314442199;
      } else {
        result[0] += -0.032239375446872234;
      }
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6438205396169394135) ) ) {
        result[0] += -0.013741574526503568;
      } else {
        result[0] += 0.00272019268716926;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7221143281151479743) ) ) {
      result[0] += 0.023844783482510696;
    } else {
      result[0] += 0.04888496970660138;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5878164698418921752) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4236855092944680212) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2025449053348033213) ) ) {
        result[0] += -0.046624609905321406;
      } else {
        result[0] += -0.0326402353757109;
      }
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5582897067648240341) ) ) {
        result[0] += -0.018875441074272158;
      } else {
        result[0] += -0.0011883016642923187;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7221143281151479743) ) ) {
      result[0] += 0.023441339996613117;
    } else {
      result[0] += 0.048419482834222635;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.765966927815004861) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4236855092944680212) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2025449053348033213) ) ) {
        result[0] += -0.04629807783973623;
      } else {
        result[0] += -0.032007658573482874;
      }
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5582897067648240341) ) ) {
        result[0] += -0.018264191653900284;
      } else {
        result[0] += -0.0011414269114867158;
      }
    }
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7221143281151479743) ) ) {
      result[0] += 0.022982967815994664;
    } else {
      result[0] += 0.047971426411739744;
    }
  }
}

