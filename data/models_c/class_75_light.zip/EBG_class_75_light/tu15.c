
#include "header.h"

void predict_unit15(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5443709472300640728) ) ) {
    result[0] += -0.003692447892989169;
  } else {
    result[0] += 0.006624839859920406;
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
    result[0] += 0.014264075614254777;
  } else {
    result[0] += -0.0016586162732274631;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.09241794211233274325) ) ) {
    result[0] += -0.050993296526511106;
  } else {
    result[0] += 0.0004592541720511368;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9297150130940317059) ) ) {
    result[0] += -0.0005086939415370826;
  } else {
    result[0] += 0.0464846445609633;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5923541255337830824) ) ) {
    result[0] += -0.007739444128517737;
  } else {
    result[0] += 0.002972822510542257;
  }
}

