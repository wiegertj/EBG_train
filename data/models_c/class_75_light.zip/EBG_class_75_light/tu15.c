
#include "header.h"

void predict_unit15(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8003917757139223932) ) ) {
    result[0] += -0.0008031599892584777;
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006120500000000000072) ) ) {
      result[0] += 0.07808334834808132;
    } else {
      result[0] += -0.0033114235855592625;
    }
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.04830892724354553247) ) ) {
    result[0] += -0.11861686417990196;
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0.05792104131874195;
    } else {
      result[0] += -0.00014774875698672158;
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)10.50000000000000178) ) ) {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.918998912310483176e-06) ) ) {
      result[0] += -0.07088884729428165;
    } else {
      result[0] += -0.006203230602927589;
    }
  } else {
    result[0] += 0.0010768545580021362;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)242.5000000000000284) ) ) {
    result[0] += 0.00154286121154645;
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6687955381924804987) ) ) {
      result[0] += -0.02588770146780083;
    } else {
      result[0] += 0.0046488045149415645;
    }
  }
  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7150000000000000799) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7550000000000001155) ) ) {
      result[0] += 0.004837114236092578;
    } else {
      result[0] += -0.23863786775715842;
    }
  } else {
    result[0] += -0.003091839326534419;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)968.5000000000001137) ) ) {
    result[0] += -0.00039108196174551796;
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01273923817959535069) ) ) {
      result[0] += -0.016774790342232056;
    } else {
      result[0] += 0.08030679236958488;
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.966590843157139501) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8994935486661771451) ) ) {
      result[0] += -0.00043054192880562025;
    } else {
      result[0] += 0.059970906730364176;
    }
  } else {
    result[0] += -0.01029149551184025;
  }
  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4008331129359999911) ) ) {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03264207041921350638) ) ) {
      result[0] += 0.018596447829779584;
    } else {
      result[0] += -0.028544120633744993;
    }
  } else {
    result[0] += -0.0013023997286460037;
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5509189654985258144) ) ) {
    result[0] += -0.0024188622681837776;
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02603817029276800366) ) ) {
      result[0] += 0.013362788617704617;
    } else {
      result[0] += -0.009488305814834152;
    }
  }
  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)5.950000000000000292e-05) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.457982259388087343) ) ) {
      result[0] += 0.005384532157774729;
    } else {
      result[0] += 0.13817594005060135;
    }
  } else {
    result[0] += -0.001243579152775203;
  }
}

