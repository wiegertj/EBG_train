
#include "header.h"

void predict_unit7(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4008331129359999911) ) ) {
    if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4026472078210281969) ) ) {
      result[0] += 0.01242939345447712;
    } else {
      result[0] += 0.17303952140001305;
    }
  } else {
    result[0] += -0.002631502178840988;
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.08449095111286804294) ) ) {
    result[0] += -0.11405363706149302;
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
      result[0] += 0.022080096535093307;
    } else {
      result[0] += -0.0022748373444181334;
    }
  }
  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.00711478974079350103) ) ) {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0004515897439921500757) ) ) {
      result[0] += 0.014350248124032947;
    } else {
      result[0] += -0.024792900636260613;
    }
  } else {
    result[0] += 0.004919887997929408;
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.394847249023198732) ) ) {
    result[0] += -0.024709472932495462;
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1850000000000000255) ) ) {
      result[0] += 0.08229761182994766;
    } else {
      result[0] += -6.913732519791679e-06;
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.966590843157139501) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8994935486661771451) ) ) {
      result[0] += 0.00074752476680038;
    } else {
      result[0] += 0.05916225150983018;
    }
  } else {
    result[0] += -0.020295966568290025;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5894723629324799541) ) ) {
    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004760500000000000842) ) ) {
      result[0] += -0.015276799343678728;
    } else {
      result[0] += 0.0037302049795062365;
    }
  } else {
    result[0] += 0.008897851680216614;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9192153427456918324) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9450000000000000622) ) ) {
      result[0] += 0.0004843990106121777;
    } else {
      result[0] += -0.07642245074339492;
    }
  } else {
    result[0] += 0.0603258859934566;
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.04830892724354553247) ) ) {
    result[0] += -0.13501176839362705;
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
      result[0] += 0.019326114363158432;
    } else {
      result[0] += -0.0021031829578681935;
    }
  }
  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.211360663335670829) ) ) {
    result[0] += 0.07953433543113878;
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5874282592522120927) ) ) {
      result[0] += -0.011568019303262624;
    } else {
      result[0] += 0.003395178619195552;
    }
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6858099790352598646) ) ) {
    result[0] += -0.0018570965230812872;
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006517000000000001091) ) ) {
      result[0] += 0.053322613317461263;
    } else {
      result[0] += 0.0017180823716483125;
    }
  }
}

