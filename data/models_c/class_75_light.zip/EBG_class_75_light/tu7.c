
#include "header.h"

void predict_unit7(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9012786453690170285) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4312690111265354842) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2287126979501296342) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1264739246323610955) ) ) {
          result[0] += -0.11442985057132378;
        } else {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3750409390474713223) ) ) {
            result[0] += 0.00017716808464769143;
          } else {
            result[0] += -0.09479854908984;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.500000000000000283e-05) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04500000000000000527) ) ) {
            result[0] += 0.03129012741070801;
          } else {
            result[0] += -0.04392814220493928;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.742577338542713683) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2769019423430922888) ) ) {
              result[0] += -0.09057546125567313;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07500000000000002498) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3680411812697468865) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.05500000000000000722) ) ) {
                    result[0] += -0.09082984429607116;
                  } else {
                    result[0] += -0.013799329168627915;
                  }
                } else {
                  result[0] += 0.09157365041198212;
                }
              } else {
                result[0] += -0.06017804841104742;
              }
            }
          } else {
            result[0] += -0.09717648344063264;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6930953257568631676) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5400664745690104684) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1850000000000000255) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05463331189772155372) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
                result[0] += 0.02220593424514448;
              } else {
                result[0] += -0.06602766070200511;
              }
            } else {
              result[0] += 0.044310162562673706;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2657640829265360827) ) ) {
              result[0] += -0.016272767811576792;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002169500000000000421) ) ) {
                result[0] += -0.06316744921701346;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1129321246270776624) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5074134513786895395) ) ) {
                      result[0] += -0.05711053538685575;
                    } else {
                      result[0] += 0.006030863820288591;
                    }
                  } else {
                    result[0] += -0.08391287520740347;
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6947584613372143059) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.689033733718593111) ) ) {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2850000000000000866) ) ) {
                        result[0] += 0.026877476667552188;
                      } else {
                        result[0] += -0.04087390976446307;
                      }
                    } else {
                      result[0] += 0.06792571866513429;
                    }
                  } else {
                    result[0] += -0.05908758254076761;
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2250000000000000333) ) ) {
            result[0] += 0.03208016704619115;
          } else {
            result[0] += -0.011387182288920075;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8097549183589626276) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += 0.04040225124191748;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08005900000000000516) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5550000000000001599) ) ) {
                result[0] += 0.03600772219813616;
              } else {
                if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4163018469253235154) ) ) {
                  result[0] += -0.028221877641237642;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5250000000000001332) ) ) {
                    if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.007306405187673099474) ) ) {
                      result[0] += 0.005884512145248356;
                    } else {
                      result[0] += 0.062289576394228274;
                    }
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02403100000000000375) ) ) {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.166387656578611987) ) ) {
                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9567162861906464144) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7519737796733669821) ) ) {
                            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5910501547487437835) ) ) {
                              if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.04615960390460414203) ) ) {
                                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6539916708591662076) ) ) {
                                  result[0] += 0.002843763145887251;
                                } else {
                                  result[0] += 0.04851796776731169;
                                }
                              } else {
                                result[0] += -0.02552543804402988;
                              }
                            } else {
                              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1507499186893259402) ) ) {
                                result[0] += 0.06848980272562435;
                              } else {
                                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002440500000000000395) ) ) {
                                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6132629351506752036) ) ) {
                                    result[0] += -0.03700302896702464;
                                  } else {
                                    result[0] += 0.007146689101484756;
                                  }
                                } else {
                                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6464622851394602465) ) ) {
                                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6495878606783920262) ) ) {
                                      result[0] += 0.0038528634258508856;
                                    } else {
                                      result[0] += 0.06615100882413225;
                                    }
                                  } else {
                                    result[0] += -0.007149029764989674;
                                  }
                                }
                              }
                            }
                          } else {
                            result[0] += -0.048316033338712545;
                          }
                        } else {
                          result[0] += 0.055367946311780734;
                        }
                      } else {
                        result[0] += -0.029307621514595268;
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7669558640352696077) ) ) {
                        result[0] += -0.06311298764012699;
                      } else {
                        result[0] += -0.004132925331426817;
                      }
                    }
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1345085000000000031) ) ) {
                result[0] += 0.04578326125268182;
              } else {
                result[0] += -0.001605323402369983;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3837516359296482826) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.8384602474436165798) ) ) {
              result[0] += 0.026660173061069867;
            } else {
              result[0] += -0.027919389541299775;
            }
          } else {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6207280235283084702) ) ) {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.316132418552224348) ) ) {
                result[0] += 0.04754089639963312;
              } else {
                if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5310003565476036913) ) ) {
                  result[0] += 0.029401371401234652;
                } else {
                  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5564233291784753677) ) ) {
                    result[0] += -0.021705051960646576;
                  } else {
                    result[0] += 0.009886009967567772;
                  }
                }
              }
            } else {
              result[0] += 0.03419177791292506;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7948589598137713041) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7073687287159498016) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8950000000000001288) ) ) {
          result[0] += 0.04205411019602943;
        } else {
          result[0] += -0.004121776647010451;
        }
      } else {
        result[0] += 0.06104596853707978;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8885612913813883962) ) ) {
        result[0] += 0.08777989195702486;
      } else {
        result[0] += 0.11196271521119754;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9012786453690170285) ) ) {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.389828724245051994) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.187139881547741499) ) ) {
        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3750409390474713223) ) ) {
          if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4627502129294571165) ) ) {
            result[0] += -0.11261196044714918;
          } else {
            result[0] += 0.06339107750360669;
          }
        } else {
          result[0] += -0.109389586577066;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.500000000000000283e-05) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3229140049410521018) ) ) {
            result[0] += -0.056792501351988614;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1430945241565956538) ) ) {
              result[0] += 0.05629922763844201;
            } else {
              result[0] += -0.03254418781586169;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7418777389447237525) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7255694492462312351) ) ) {
              result[0] += -0.06971003582210822;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1350000000000000366) ) ) {
                result[0] += 0.09614589351708197;
              } else {
                result[0] += -0.09731839079419148;
              }
            }
          } else {
            result[0] += -0.1025070901633472;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.625846821573829204) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5074134513786895395) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2416282609350551558) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.435648018856219732) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1974706666691888324) ) ) {
                result[0] += 0.008418998518780734;
              } else {
                result[0] += -0.04242053367904529;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6722423356281408413) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09956041386891252565) ) ) {
                  result[0] += 0.008803238644138948;
                } else {
                  result[0] += -0.04677849245172836;
                }
              } else {
                result[0] += 0.04765306793755008;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005215500000000000518) ) ) {
              result[0] += -0.06394416063764523;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006814500000000000245) ) ) {
                result[0] += 0.014862588664795624;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.639033920871866834) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5499504253266332965) ) ) {
                    result[0] += -0.051058435126431205;
                  } else {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2850000000000000866) ) ) {
                      result[0] += 0.05038494049545411;
                    } else {
                      result[0] += -0.021875965299141247;
                    }
                  }
                } else {
                  result[0] += -0.07469905824507626;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.352076346428185083) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7478339930150754711) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7002474625125628682) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4734952854020100799) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4405029099497487777) ) ) {
                      if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3750409390474713223) ) ) {
                        result[0] += -0.010995109615874708;
                      } else {
                        result[0] += 0.07356604535192414;
                      }
                    } else {
                      if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3103100527046326884) ) ) {
                        result[0] += -0.0039038141475581972;
                      } else {
                        result[0] += -0.0705409184386795;
                      }
                    }
                  } else {
                    result[0] += 0.05557767425385721;
                  }
                } else {
                  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2803498254930153477) ) ) {
                    result[0] += 5.619993116370812e-05;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.544739387236181094) ) ) {
                      result[0] += -0.06581206529266566;
                    } else {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03945373639888280493) ) ) {
                        result[0] += 0.048225696865595934;
                      } else {
                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4868404241646586694) ) ) {
                          result[0] += -0.041362694482395476;
                        } else {
                          result[0] += 0.022726973711399676;
                        }
                      }
                    }
                  }
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3750000000000000555) ) ) {
                  result[0] += 0.005115538180160889;
                } else {
                  result[0] += 0.08896527115459607;
                }
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5553282523088564071) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3354380584391450371) ) ) {
                  result[0] += -0.009240374221877484;
                } else {
                  result[0] += -0.09786071029478807;
                }
              } else {
                result[0] += -0.0052442920914011855;
              }
            }
          } else {
            result[0] += -0.029433570744742014;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.789013814595658558) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.286140606976293066) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3150000000000000577) ) ) {
                result[0] += 0.042716057699647064;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4450000000000000622) ) ) {
                  result[0] += -0.03189795856579079;
                } else {
                  result[0] += 0.001057135173115038;
                }
              }
            } else {
              result[0] += -0.05855918261280311;
            }
          } else {
            result[0] += 0.04588641999855761;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.735388073517588059) ) ) {
            result[0] += 0.012207166313264092;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04325850000000000528) ) ) {
              result[0] += 0.05053209096391864;
            } else {
              result[0] += 0;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7948589598137713041) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7073687287159498016) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9650000000000000799) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9211939213984681185) ) ) {
            result[0] += 0.021990478721310276;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05763600000000000667) ) ) {
              result[0] += 0.08116879339183705;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08460400000000001253) ) ) {
                result[0] += -0.00921917600752568;
              } else {
                result[0] += 0.05326530571793333;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8950000000000001288) ) ) {
            result[0] += 0.027812459527322125;
          } else {
            result[0] += -0.022914014948269203;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.746733706532663466) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6690536170100503943) ) ) {
            result[0] += 0.05601112421698547;
          } else {
            result[0] += 0.10788723576394295;
          }
        } else {
          result[0] += 0.011220124997965163;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8679983746857627969) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9011425554234714363) ) ) {
          result[0] += 0.0915252533358138;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01279200000000000129) ) ) {
            result[0] += -0.027045936202663188;
          } else {
            result[0] += 0.06458292850314279;
          }
        }
      } else {
        result[0] += 0.1088921510801535;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6687753071115941639) ) ) {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.389828724245051994) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.187139881547741499) ) ) {
        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3750409390474713223) ) ) {
          if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4537022967526785355) ) ) {
            result[0] += -0.11223350137602255;
          } else {
            result[0] += 0.07446314975682257;
          }
        } else {
          result[0] += -0.10817232165173477;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.500000000000000283e-05) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3229140049410521018) ) ) {
            result[0] += -0.053137570055045484;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1430945241565956538) ) ) {
              result[0] += 0.04766832194234035;
            } else {
              result[0] += -0.029739360853778412;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.742577338542713683) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9079021320180030719) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.07355385296939205564) ) ) {
                result[0] += 0.008891601369981773;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2769019423430922888) ) ) {
                  result[0] += -0.09535549593444555;
                } else {
                  result[0] += -0.05644447689782024;
                }
              }
            } else {
              result[0] += 0.009394692264446686;
            }
          } else {
            result[0] += -0.10134322643348677;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6595171046238990087) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5234930566607364222) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1850000000000000255) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.564198853668341882) ) ) {
                result[0] += -0.011329147061710303;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06048750000000000654) ) ) {
                  result[0] += 0.08390024059040971;
                } else {
                  result[0] += 0.0019057641064115498;
                }
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3550761912678883081) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4665965687058793443) ) ) {
                  result[0] += -0.06232591415996529;
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2650000000000000688) ) ) {
                    result[0] += 0.022047450005589487;
                  } else {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2657640829265360827) ) ) {
                      result[0] += -0.005273095304453438;
                    } else {
                      result[0] += -0.0666943468013965;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02552250000000000352) ) ) {
                  result[0] += 0.00029464078643833273;
                } else {
                  result[0] += -0.07096599007494037;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00251250000000000041) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4574668247487437833) ) ) {
                result[0] += 0;
              } else {
                result[0] += -0.08415111284503397;
              }
            } else {
              result[0] += -0.03567879393461884;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4150000000000000355) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3950000000000000733) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6850000000000001643) ) ) {
                result[0] += -0.004954217898065196;
              } else {
                result[0] += -0.04499396782126079;
              }
            } else {
              result[0] += 0.02025826336271709;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5891834603033582196) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4412674596193493781) ) ) {
                result[0] += -0.05146429859737593;
              } else {
                result[0] += 0.012896005056000213;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6650000000000001465) ) ) {
                result[0] += 0.0013373748284076547;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6542990130851055186) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6445404660562240595) ) ) {
                    result[0] += -0.025101152349084645;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5926917132914574227) ) ) {
                      result[0] += -0.019770160618464643;
                    } else {
                      result[0] += 0.04525359262112406;
                    }
                  }
                } else {
                  result[0] += -0.06748892398833116;
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8647856135106589681) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
            result[0] += 0.048117745873505376;
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.7808520422368410152) ) ) {
              result[0] += -0.03647730773030873;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.728792159352835367) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3998546246231156065) ) ) {
                  result[0] += -0.05343910258340763;
                } else {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3750409390474713223) ) ) {
                    result[0] += 0.047693878492899515;
                  } else {
                    result[0] += -0.0014082736056455509;
                  }
                }
              } else {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4537022967526785355) ) ) {
                  result[0] += 0.02911970649750042;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.500000000000000283e-05) ) ) {
                    result[0] += 0.04216729962978392;
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001817500000000000322) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7587459355025126806) ) ) {
                        result[0] += -0.00300947255178634;
                      } else {
                        result[0] += -0.04532959988206047;
                      }
                    } else {
                      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6333994641870349662) ) ) {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6650000000000001465) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6541365753517588422) ) ) {
                            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6208328749497488142) ) ) {
                              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1143667719897807217) ) ) {
                                result[0] += 0.0031353040266820127;
                              } else {
                                result[0] += 0.039083933853058986;
                              }
                            } else {
                              result[0] += -0.03918808532596014;
                            }
                          } else {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6413622072216433878) ) ) {
                              result[0] += 0.06852765230741938;
                            } else {
                              result[0] += 0.01913429185403327;
                            }
                          }
                        } else {
                          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9050000000000001377) ) ) {
                            result[0] += -0.020393560685390073;
                          } else {
                            result[0] += 0.006725729794449248;
                          }
                        }
                      } else {
                        result[0] += 0.03764124494513632;
                      }
                    }
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001987500000000000551) ) ) {
            result[0] += -0.028608429951880537;
          } else {
            result[0] += 0.026156425340208418;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8371739120330333739) ) ) {
      if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.8658453235544533166) ) ) {
        result[0] += -0.02282716918292733;
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7570612716642158846) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9150000000000001465) ) ) {
            result[0] += 0.05198830866988756;
          } else {
            result[0] += -0.0062777139249318575;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += 0.07509998715999944;
          } else {
            result[0] += 0.019597066643769347;
          }
        }
      }
    } else {
      result[0] += 0.10451400860966177;
    }
  }
}

