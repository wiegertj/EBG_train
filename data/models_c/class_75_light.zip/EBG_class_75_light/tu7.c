
#include "header.h"

void predict_unit7(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6224479755486952426) ) ) {
    result[0] += -0.0189278275012369;
  } else {
    result[0] += 0.01035211750015867;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7616046585677935798) ) ) {
    result[0] += -0.004422834655464842;
  } else {
    result[0] += 0.04403118101871897;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2573388693305712627) ) ) {
    result[0] += -0.04475508829794146;
  } else {
    result[0] += 0.004160705952337228;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8409680707237645603) ) ) {
    result[0] += -0.0037000047344853113;
  } else {
    result[0] += 0.0495950150419528;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2044245892222342487) ) ) {
    result[0] += -0.048726854579910654;
  } else {
    result[0] += 0.003581159058867134;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8409680707237645603) ) ) {
    result[0] += -0.003499266335834949;
  } else {
    result[0] += 0.0491113146392056;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2044245892222342487) ) ) {
    result[0] += -0.048252797424702454;
  } else {
    result[0] += 0.0033876212112451368;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5794124692327976556) ) ) {
    result[0] += -0.008382144510899428;
  } else {
    result[0] += 0.01913595329933829;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8409680707237645603) ) ) {
    result[0] += -0.0032540256260856657;
  } else {
    result[0] += 0.04843573272756175;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2044245892222342487) ) ) {
    result[0] += -0.04768807194864953;
  } else {
    result[0] += 0.0031948494968788263;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8409680707237645603) ) ) {
    result[0] += -0.003077441425387745;
  } else {
    result[0] += 0.04792998692493979;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1601111865813344692) ) ) {
    result[0] += -0.0520171099470801;
  } else {
    result[0] += 0.0027604149246814153;
  }
}

