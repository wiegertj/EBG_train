
#include "header.h"

void predict_unit12(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.08835747683243963535) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4797597438944724013) ) ) {
      result[0] += 0.004471232815063843;
    } else {
      result[0] += -0.03380030596784144;
    }
  } else {
    result[0] += 0.002890233422968727;
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7537120970940404119) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9450000000000000622) ) ) {
      result[0] += -0.00016409754152547497;
    } else {
      result[0] += -0.09452015462001241;
    }
  } else {
    result[0] += 0.021843767860925577;
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5187759295427522011) ) ) {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3750000000000000555) ) ) {
      result[0] += 0.003912033192833897;
    } else {
      result[0] += -0.054321367125007985;
    }
  } else {
    result[0] += 0.0017579103597617322;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)242.5000000000000284) ) ) {
    result[0] += 0.0017884498980540585;
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6687955381924804987) ) ) {
      result[0] += -0.029279199726850426;
    } else {
      result[0] += 0.00535336251883564;
    }
  }
  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.545000000000000151) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6950000000000000622) ) ) {
      result[0] += 0.007590192273221171;
    } else {
      result[0] += -0.25814749190008407;
    }
  } else {
    result[0] += -0.002638164472149486;
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4506546428194125875) ) ) {
    result[0] += -0.011962930698918826;
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.115000000000000005) ) ) {
      result[0] += 0.20866471523469216;
    } else {
      result[0] += 0.0009186243565891254;
    }
  }
  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.08835747683243963535) ) ) {
    result[0] += -0.005854103182458695;
  } else {
    if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.04908445857219279757) ) ) {
      result[0] += 0.03744214733554249;
    } else {
      result[0] += -0.0011139533930097645;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6722423356281408413) ) ) {
    result[0] += -0.0021933692624105075;
  } else {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6802634857286432579) ) ) {
      result[0] += 0.12480156925109076;
    } else {
      result[0] += -0.001337536630380983;
    }
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.04830892724354553247) ) ) {
    result[0] += -0.12290454023777393;
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)5.950000000000000292e-05) ) ) {
      result[0] += 0.01110592810153913;
    } else {
      result[0] += -0.0013500428956995786;
    }
  }
  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.004881517549305751207) ) ) {
    result[0] += -0.006565731452493811;
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0008825000000000001463) ) ) {
      result[0] += -0.04108504063722205;
    } else {
      result[0] += 0.004253495154128893;
    }
  }
}

