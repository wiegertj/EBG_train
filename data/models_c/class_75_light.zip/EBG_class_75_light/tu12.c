
#include "header.h"

void predict_unit12(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1316017537932669124) ) ) {
    result[0] += -0.04847037825023165;
  } else {
    result[0] += 0.0008174593948800132;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5794124692327976556) ) ) {
    result[0] += -0.0039607930437743355;
  } else {
    result[0] += 0.009942568740357764;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.919952104732480902) ) ) {
    result[0] += -0.0008086647472761152;
  } else {
    result[0] += 0.04789548006692978;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1316017537932669124) ) ) {
    result[0] += -0.04807574148475351;
  } else {
    result[0] += 0.0007728648246365705;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9297150130940317059) ) ) {
    result[0] += -0.0007410476732225281;
  } else {
    result[0] += 0.049209291598694124;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4377968628344893198) ) ) {
    result[0] += -0.016702013287133135;
  } else {
    result[0] += 0.0021336188208653235;
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004890500000000001617) ) ) {
    result[0] += -0.006430185131163337;
  } else {
    result[0] += 0.005435176669401336;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1316017537932669124) ) ) {
    result[0] += -0.047532896841314974;
  } else {
    result[0] += 0.0007151732047944583;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9297150130940317059) ) ) {
    result[0] += -0.0006985365375901026;
  } else {
    result[0] += 0.048818685202222795;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6467849541054230267) ) ) {
    result[0] += -0.0022761757044025862;
  } else {
    result[0] += 0.014348694047259442;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1316017537932669124) ) ) {
    result[0] += -0.04711584815836694;
  } else {
    result[0] += 0.0006773461439602418;
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
    result[0] += 0.017051506403364378;
  } else {
    result[0] += -0.0019140883614745016;
  }
}

