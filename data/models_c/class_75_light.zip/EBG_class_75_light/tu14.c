
#include "header.h"

void predict_unit14(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.008672500000000001388) ) ) {
    result[0] += -0.004615525681758268;
  } else {
    result[0] += 0.005973911742200808;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9297150130940317059) ) ) {
    result[0] += -0.0005715348789095335;
  } else {
    result[0] += 0.04740902094493845;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.09241794211233274325) ) ) {
    result[0] += -0.051469179915836195;
  } else {
    result[0] += 0.0005177931109443762;
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
    result[0] += 0.015421314711624931;
  } else {
    result[0] += -0.0017680244337825509;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5239621953665337672) ) ) {
    result[0] += -0.010996396718301157;
  } else {
    result[0] += 0.002411700216884717;
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004890500000000001617) ) ) {
    result[0] += -0.0054899675761753185;
  } else {
    result[0] += 0.004651448925014917;
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
    result[0] += 0.015084145625519447;
  } else {
    result[0] += -0.0017369732389250132;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2573388693305712627) ) ) {
    result[0] += -0.025289625082952263;
  } else {
    result[0] += 0.0010073844846089847;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9297150130940317059) ) ) {
    result[0] += -0.0005407009601465886;
  } else {
    result[0] += 0.04697070510090712;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.09241794211233274325) ) ) {
    result[0] += -0.05116801625270823;
  } else {
    result[0] += 0.000479312524452182;
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
    result[0] += 0.014604563787839418;
  } else {
    result[0] += -0.0016888411474402555;
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003374500000000000329) ) ) {
    result[0] += -0.0061755398227714515;
  } else {
    result[0] += 0.003963259394682923;
  }
}

