
#include "header.h"

void predict_unit14(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3411690131117683933) ) ) {
    result[0] += -0.0160331306920561;
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.1991589176032774189) ) ) {
      result[0] += 0.06596773028483252;
    } else {
      result[0] += -0.0004843938027058088;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5980109955351072815) ) ) {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04813936719830770594) ) ) {
      result[0] += -0.010072435572036641;
    } else {
      result[0] += 0.054668363577336655;
    }
  } else {
    result[0] += 0.002223216478897135;
  }
  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.545000000000000151) ) ) {
    if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.08835747683243963535) ) ) {
      result[0] += -0.015449337956592417;
    } else {
      result[0] += 0.015577874876723274;
    }
  } else {
    result[0] += -0.002344492436418407;
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4506546428194125875) ) ) {
    result[0] += -0.01085050064532842;
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2750000000000000777) ) ) {
      result[0] += 0.033992714368714635;
    } else {
      result[0] += -0.0009219374632309324;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5980109955351072815) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4150000000000000355) ) ) {
      result[0] += -0.0010224392268094638;
    } else {
      result[0] += -0.04524226799973067;
    }
  } else {
    result[0] += 0.002234623323902684;
  }
  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0004515897439921500757) ) ) {
    result[0] += 0.009472483616978415;
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.000633500000000000057) ) ) {
      result[0] += -0.039077231002614225;
    } else {
      result[0] += 0.00021352123160720766;
    }
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5396268633306868789) ) ) {
    result[0] += -0.007745847063062987;
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2750000000000000777) ) ) {
      result[0] += 0.050338834334244416;
    } else {
      result[0] += 0.00025409208687422703;
    }
  }
  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04858450000000000962) ) ) {
    result[0] += 0.001597617965047067;
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03055521934146935084) ) ) {
      result[0] += -0.03278448368552744;
    } else {
      result[0] += 0.008298936576081118;
    }
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1124.500000000000227) ) ) {
    result[0] += -0.0003502120555151551;
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01273923817959535069) ) ) {
      result[0] += -0.020603519108043943;
    } else {
      result[0] += 0.1037392852788805;
    }
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9200812221382833611) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
      result[0] += 0.00034921329040082087;
    } else {
      result[0] += -0.05149564824341004;
    }
  } else {
    result[0] += 0.05618403083200782;
  }
}

