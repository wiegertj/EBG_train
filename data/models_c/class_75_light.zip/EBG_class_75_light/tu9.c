
#include "header.h"

void predict_unit9(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7428946460663085061) ) ) {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3421306008459473191) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1264739246323610955) ) ) {
        result[0] += -0.10994637639100127;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          result[0] += 0.0043378271530132686;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2235721560236787198) ) ) {
            result[0] += -0.08314072883609876;
          } else {
            result[0] += -0.04774428792882289;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5593705952246232904) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09500000000000001499) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1703653784966202289) ) ) {
            result[0] += 0.09395544456066825;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.07231000000000001315) ) ) {
              result[0] += -0.07333180891707063;
            } else {
              result[0] += 0.046193588156735715;
            }
          }
        } else {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.6821093005801899256) ) ) {
            result[0] += 0.023554632410345493;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4835577767624377743) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3850000000000000644) ) ) {
                result[0] += -0.026156380191418513;
              } else {
                result[0] += -0.05714638588256259;
              }
            } else {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3565411260296964535) ) ) {
                result[0] += -0.011544555696332906;
              } else {
                result[0] += -0.05788948253840972;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8143976568897295376) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3450000000000000289) ) ) {
              result[0] += -0.016922366553250617;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9186477097784532253) ) ) {
                result[0] += 0.015707662802727545;
              } else {
                result[0] += 0.06524786695674693;
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001009500000000000198) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5523590325454214023) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.602193885753768865) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4914057384422110819) ) ) {
                    result[0] += 0.0027297727431620034;
                  } else {
                    result[0] += -0.03861239565620073;
                  }
                } else {
                  result[0] += 0.026960593100577555;
                }
              } else {
                result[0] += -0.0638552235975665;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3150000000000000577) ) ) {
                result[0] += 0.03932840181990913;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4050000000000000822) ) ) {
                  result[0] += -0.0395191854726388;
                } else {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.7808520422368410152) ) ) {
                    result[0] += -0.027543128789789855;
                  } else {
                    if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2044121788183031196) ) ) {
                      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.352076346428185083) ) ) {
                        result[0] += 0.06390883837647551;
                      } else {
                        result[0] += 0.010603981543300273;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4731110269597990081) ) ) {
                        result[0] += -0.05039064592627473;
                      } else {
                        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.0491948752242571466) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5493276582412061071) ) ) {
                            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5357696120088285552) ) ) {
                              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4313293140090834199) ) ) {
                                result[0] += 0.02376736452791964;
                              } else {
                                result[0] += -0.02914201806711165;
                              }
                            } else {
                              result[0] += 0.06040978675811802;
                            }
                          } else {
                            result[0] += 0.10663461825258395;
                          }
                        } else {
                          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5910501547487437835) ) ) {
                            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5826692266582915725) ) ) {
                              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5692513238442212797) ) ) {
                                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02714750000000000149) ) ) {
                                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5288010847236181977) ) ) {
                                    result[0] += 0.025030676930382724;
                                  } else {
                                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5528143519346734314) ) ) {
                                      result[0] += -0.06330262364748569;
                                    } else {
                                      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5292687537313297552) ) ) {
                                        result[0] += -0.051631546426454115;
                                      } else {
                                        result[0] += 0.014488839904804516;
                                      }
                                    }
                                  }
                                } else {
                                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5450375474120604524) ) ) {
                                    result[0] += 0.04444733028598865;
                                  } else {
                                    result[0] += -0.013426289042830289;
                                  }
                                }
                              } else {
                                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5250000000000001332) ) ) {
                                  result[0] += 0.06082556576773525;
                                } else {
                                  result[0] += 0.00048349442993245563;
                                }
                              }
                            } else {
                              result[0] += -0.0803763672654371;
                            }
                          } else {
                            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6062825421608041276) ) ) {
                              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005786500000000000844) ) ) {
                                result[0] += 0.020297583145576645;
                              } else {
                                result[0] += 0.11235808612866505;
                              }
                            } else {
                              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6443906374120603742) ) ) {
                                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6194234758793971674) ) ) {
                                  result[0] += 0.010194432918674293;
                                } else {
                                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7624551761149250817) ) ) {
                                    result[0] += -0.050977218062415126;
                                  } else {
                                    result[0] += 0.001597875930225665;
                                  }
                                }
                              } else {
                                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6464622851394602465) ) ) {
                                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6022841189157331909) ) ) {
                                    result[0] += 0.006157395968085483;
                                  } else {
                                    result[0] += 0.08515275241653524;
                                  }
                                } else {
                                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8687344252564519476) ) ) {
                                    result[0] += -0.02011064557332782;
                                  } else {
                                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.064486481904431292) ) ) {
                                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8550000000000000933) ) ) {
                                        result[0] += 0.046581012086884144;
                                      } else {
                                        result[0] += 0.0026914841287309674;
                                      }
                                    } else {
                                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                                        result[0] += -0.022700787033485745;
                                      } else {
                                        result[0] += 0.041874607523620815;
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9150000000000001465) ) ) {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6687753071115941639) ) ) {
              result[0] += 0.011622485676484372;
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.6505320650523345183) ) ) {
                result[0] += -0.020759797203691702;
              } else {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8131644532706052697) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7969182508153497269) ) ) {
                    result[0] += 0.039407149609256065;
                  } else {
                    result[0] += 0.09026835063536173;
                  }
                } else {
                  result[0] += -0.025405289049731467;
                }
              }
            }
          } else {
            result[0] += -0.022623169448920944;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8679983746857627969) ) ) {
      result[0] += 0.05435419316080825;
    } else {
      result[0] += 0.10001162880146562;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7428946460663085061) ) ) {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2769019423430922888) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1264739246323610955) ) ) {
        result[0] += -0.10914451209339415;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          result[0] += 0.004170407056313738;
        } else {
          result[0] += -0.06799564493240806;
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5593705952246232904) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6413622072216433878) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5681735652491761712) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1520895000000000163) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2669585275879397535) ) ) {
                result[0] += 0.055578450408613;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1350000000000000366) ) ) {
                  result[0] += -0.04816151521995146;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0650000000000000161) ) ) {
                    result[0] += 0.05400863506152593;
                  } else {
                    result[0] += -0.021336780387258603;
                  }
                }
              }
            } else {
              result[0] += 0.08144333558119564;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6481803955276382867) ) ) {
              result[0] += -0.0649445669986682;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001771500000000000288) ) ) {
                result[0] += 0.0016623987628910577;
              } else {
                result[0] += 0.11860189122768049;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8706992593517899337) ) ) {
            result[0] += -0.06097259638473508;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7406984144974875228) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7255694492462312351) ) ) {
                result[0] += -0.025437639495086768;
              } else {
                result[0] += 0.08611136652143314;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01430750000000000251) ) ) {
                result[0] += -0.020177889810857705;
              } else {
                result[0] += -0.07307506233751976;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5564233291784753677) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6075184940276968648) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.260985000000000078) ) ) {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
                result[0] += 0.03685814500364045;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4050764352261307377) ) ) {
                  result[0] += -0.02033013622862974;
                } else {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2044121788183031196) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4574668247487437833) ) ) {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6950000000000000622) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4296048346231156057) ) ) {
                          result[0] += 0.008517730794266098;
                        } else {
                          result[0] += -0.0608265112187592;
                        }
                      } else {
                        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4537022967526785355) ) ) {
                          result[0] += 0.059196721188556636;
                        } else {
                          result[0] += -0.0024532152355108998;
                        }
                      }
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4798028910050251561) ) ) {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005436500000000001227) ) ) {
                          result[0] += 0.0021915530060437343;
                        } else {
                          result[0] += 0.07999542037009642;
                        }
                      } else {
                        result[0] += -0.0037790194777755;
                      }
                    }
                  } else {
                    if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1044543990012605922) ) ) {
                      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3895596163096332609) ) ) {
                        result[0] += -0.07290950540349539;
                      } else {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002979500000000000377) ) ) {
                          result[0] += 0.04365495898880848;
                        } else {
                          result[0] += -0.03386361274946412;
                        }
                      }
                    } else {
                      if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.0491948752242571466) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5493276582412061071) ) ) {
                          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007508000000000000784) ) ) {
                            result[0] += -0.05263727562451051;
                          } else {
                            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.07409325127878772788) ) ) {
                              result[0] += 0.048549216009169685;
                            } else {
                              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5750000000000000666) ) ) {
                                result[0] += 0.025067005353320078;
                              } else {
                                result[0] += -0.037149261441235516;
                              }
                            }
                          }
                        } else {
                          result[0] += 0.09952718250539949;
                        }
                      } else {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                          result[0] += 0.019186681880981063;
                        } else {
                          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0007085000000000000369) ) ) {
                            result[0] += -0.0697696480754152;
                          } else {
                            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.625846821573829204) ) ) {
                              result[0] += -0.022821540530286937;
                            } else {
                              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1027559661512248146) ) ) {
                                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6350000000000001199) ) ) {
                                  result[0] += -0.009926111349735459;
                                } else {
                                  result[0] += -0.058076187108649084;
                                }
                              } else {
                                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1312546181544835266) ) ) {
                                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7182717167126227986) ) ) {
                                    result[0] += 0.014631189836779126;
                                  } else {
                                    result[0] += 0.07944650408984857;
                                  }
                                } else {
                                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7650000000000001243) ) ) {
                                    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4163018469253235154) ) ) {
                                      result[0] += -0.004940851363808281;
                                    } else {
                                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7211604863065327331) ) ) {
                                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01768250000000000377) ) ) {
                                          result[0] += -0.00012361261981752377;
                                        } else {
                                          result[0] += 0.05592422897860014;
                                        }
                                      } else {
                                        result[0] += 0.07819618068998167;
                                      }
                                    }
                                  } else {
                                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5350000000000001421) ) ) {
                                      result[0] += 0.01579260006546638;
                                    } else {
                                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6443906374120603742) ) ) {
                                        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.500042016326493588) ) ) {
                                          result[0] += -0.06925997740245425;
                                        } else {
                                          result[0] += -0.007045662598482721;
                                        }
                                      } else {
                                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01021900000000000065) ) ) {
                                          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8950000000000001288) ) ) {
                                            result[0] += 0.0369918010428351;
                                          } else {
                                            result[0] += -0.010733003667821832;
                                          }
                                        } else {
                                          result[0] += -0.02445032747274518;
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            } else {
              result[0] += 0.05260492691812469;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02552250000000000352) ) ) {
              result[0] += -0.09169474517998481;
            } else {
              result[0] += -0.007702463073647857;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9079518334873196705) ) ) {
            result[0] += 0.008187753970524979;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9150000000000001465) ) ) {
              result[0] += 0.031156279320554134;
            } else {
              result[0] += -0.01777092845726266;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8885612913813883962) ) ) {
      result[0] += 0.05347112849051205;
    } else {
      result[0] += 0.10067662304184702;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7570612716642158846) ) ) {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2634616880679390705) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1264739246323610955) ) ) {
        result[0] += -0.10830702632820409;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          result[0] += 0.002307380863867279;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.500000000000000283e-05) ) ) {
            result[0] += -0.049054774418717986;
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3197884335317744964) ) ) {
              result[0] += 0;
            } else {
              result[0] += -0.08994553332326516;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5400664745690104684) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05500000000000000722) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.05500000000000000722) ) ) {
            result[0] += -0.038633823099724754;
          } else {
            result[0] += 0.06044040307272397;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.389828724245051994) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.500000000000000283e-05) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1650000000000000355) ) ) {
                result[0] += -0.037670901072821256;
              } else {
                result[0] += 0.0048465914399757224;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1250000000000000278) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01768250000000000377) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3229140049410521018) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6022841189157331909) ) ) {
                      result[0] += -0.06484640220681581;
                    } else {
                      result[0] += 0.04423471738471621;
                    }
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1550000000000000266) ) ) {
                      result[0] += -0.01941051169237495;
                    } else {
                      result[0] += 0.12154501886583922;
                    }
                  }
                } else {
                  result[0] += -0.07632670933473577;
                }
              } else {
                result[0] += -0.0712602163813028;
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3850000000000000644) ) ) {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.284601935876013401) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4931526702322118205) ) ) {
                  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2171077366742938664) ) ) {
                    result[0] += 0.0005694526483362158;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5547315393467338041) ) ) {
                      result[0] += -0.059258817556210784;
                    } else {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.639033920871866834) ) ) {
                        result[0] += 0.00864595781658267;
                      } else {
                        result[0] += -0.0636074718486726;
                      }
                    }
                  }
                } else {
                  result[0] += 0.012122503933750138;
                }
              } else {
                result[0] += -0.06174960761880142;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002169500000000000421) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4574668247487437833) ) ) {
                  result[0] += 0;
                } else {
                  result[0] += -0.06850304664455703;
                }
              } else {
                result[0] += -0.014427307931419343;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6448546879214981375) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7128350880906092479) ) ) {
            result[0] += -0.003937349602693277;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5750000000000000666) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8350000000000000755) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6950000000000000622) ) ) {
                  result[0] += 0.009588184666966116;
                } else {
                  result[0] += 0.03643750246210372;
                }
              } else {
                result[0] += -0.017295883190339156;
              }
            } else {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5067109089112920017) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.560138790184518176) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5926917132914574227) ) ) {
                    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4815071486993944827) ) ) {
                      result[0] += -0.05207011334340701;
                    } else {
                      result[0] += -0.005056295118949062;
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7772125154254619916) ) ) {
                      result[0] += 0.038846617117303237;
                    } else {
                      result[0] += -0.011142248328867786;
                    }
                  }
                } else {
                  result[0] += -0.05509071238030727;
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  result[0] += 0.04635958927347235;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001009500000000000198) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6490899135219417859) ) ) {
                      result[0] += -0.002286300956033238;
                    } else {
                      result[0] += -0.045813522985155605;
                    }
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001279500000000000255) ) ) {
                      result[0] += 0.04194738913431208;
                    } else {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001817500000000000322) ) ) {
                        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.03659918966571634041) ) ) {
                          result[0] += 0.02071156832902481;
                        } else {
                          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6301831911055276736) ) ) {
                            result[0] += -0.05984159410398577;
                          } else {
                            result[0] += -0.011253335496119489;
                          }
                        }
                      } else {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0422915000000000027) ) ) {
                          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8773329652735187834) ) ) {
                            result[0] += 0.007337723114186411;
                          } else {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.049143534958799195) ) ) {
                              result[0] += 0.07754697688310422;
                            } else {
                              result[0] += 0.016627749699318198;
                            }
                          }
                        } else {
                          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5068267582412061545) ) ) {
                            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4424293181155778965) ) ) {
                              result[0] += -0.01718968540667951;
                            } else {
                              result[0] += 0.05762483124395147;
                            }
                          } else {
                            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5424744603768845153) ) ) {
                              result[0] += -0.06649924735537412;
                            } else {
                              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9012786453690170285) ) ) {
                                result[0] += -0.02114608270994277;
                              } else {
                                result[0] += 0.04778642586781241;
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9079518334873196705) ) ) {
              result[0] += -0.008845602435861365;
            } else {
              result[0] += 0.05838549193838545;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8365819406938835856) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0005000000000000001188) ) ) {
                result[0] += -0.033866166660026065;
              } else {
                result[0] += 0.020895595991896374;
              }
            } else {
              result[0] += -0.06598265440293076;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8885612913813883962) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9365641052798755473) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.824437516878408494) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9011425554234714363) ) ) {
            result[0] += 0.04770403241676281;
          } else {
            result[0] += -0.03948486425751433;
          }
        } else {
          result[0] += 0.07420197141597293;
        }
      } else {
        result[0] += -0.029937059818697098;
      }
    } else {
      result[0] += 0.09879810818872622;
    }
  }
}

