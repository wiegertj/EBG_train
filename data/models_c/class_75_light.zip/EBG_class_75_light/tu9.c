
#include "header.h"

void predict_unit9(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1601111865813344692) ) ) {
    result[0] += -0.05012495359526578;
  } else {
    result[0] += 0.0020044804276711406;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8744693154915333944) ) ) {
    result[0] += -0.002018382346151249;
  } else {
    result[0] += 0.047361751028874216;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1601111865813344692) ) ) {
    result[0] += -0.04977679865764754;
  } else {
    result[0] += 0.0018967873249713212;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5794124692327976556) ) ) {
    result[0] += -0.00615419754791279;
  } else {
    result[0] += 0.014785278948783006;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1601111865813344692) ) ) {
    result[0] += -0.04938835762950961;
  } else {
    result[0] += 0.0017889140482582396;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8744693154915333944) ) ) {
    result[0] += -0.0018838248581019399;
  } else {
    result[0] += 0.046707886992235645;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1601111865813344692) ) ) {
    result[0] += -0.049017612689462274;
  } else {
    result[0] += 0.0016929375069580218;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8905049116466139392) ) ) {
    result[0] += -0.001714715907925935;
  } else {
    result[0] += 0.04819935367291476;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6276172203355564472) ) ) {
    result[0] += -0.012329235022112289;
  } else {
    result[0] += 0.006504128716865495;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1601111865813344692) ) ) {
    result[0] += -0.04854091864174562;
  } else {
    result[0] += 0.0015853947346480299;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8905049116466139392) ) ) {
    result[0] += -0.001617391292437308;
  } else {
    result[0] += 0.04770143131632841;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1601111865813344692) ) ) {
    result[0] += -0.04814428924056369;
  } else {
    result[0] += 0.001500357340084608;
  }
}

