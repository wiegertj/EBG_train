
#include "header.h"

void predict_unit9(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)5.950000000000000292e-05) ) ) {
    result[0] += 0.015370610873214743;
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.000633500000000000057) ) ) {
      result[0] += -0.051355447871989854;
    } else {
      result[0] += 0.00039533168970608734;
    }
  }
  if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.02295804264238120174) ) ) {
    result[0] += -0.07508964064583734;
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0.17187805244508914;
    } else {
      result[0] += 0;
    }
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1856492240552437833) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3353276241206030739) ) ) {
      result[0] += 0.6323576229684984;
    } else {
      result[0] += -0.0581249448056374;
    }
  } else {
    result[0] += 0.000581192846182935;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7804766498994976098) ) ) {
    result[0] += 0.0015689161515413353;
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0005145000000000000918) ) ) {
      result[0] += 0.061663421484857484;
    } else {
      result[0] += -0.028597169579829534;
    }
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9461509352790128391) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
      result[0] += 0.0004131353937004506;
    } else {
      result[0] += -0.05671765535889034;
    }
  } else {
    result[0] += 0.10103526515805593;
  }
  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.004881517549305751207) ) ) {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0004515897439921500757) ) ) {
      result[0] += 0.011380815723317134;
    } else {
      result[0] += -0.026867754158128622;
    }
  } else {
    result[0] += 0.003140543060797929;
  }
  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4008331129359999911) ) ) {
    if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4026472078210281969) ) ) {
      result[0] += 0.008910209698104805;
    } else {
      result[0] += 0.13719097921091883;
    }
  } else {
    result[0] += -0.0019449739040872302;
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.422825113797481833) ) ) {
    result[0] += -0.016652040647118477;
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09500000000000001499) ) ) {
      result[0] += 0.2961827633832205;
    } else {
      result[0] += 0.0011157646265952366;
    }
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.04830892724354553247) ) ) {
    result[0] += -0.13027492789515185;
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0.0822077236440217;
    } else {
      result[0] += -0.0001122734113471808;
    }
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7786086147706151595) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9450000000000000622) ) ) {
      result[0] += 8.971561854048542e-05;
    } else {
      result[0] += -0.10877366031734488;
    }
  } else {
    result[0] += 0.030307523101610064;
  }
}

