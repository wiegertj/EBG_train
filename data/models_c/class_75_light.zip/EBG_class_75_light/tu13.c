
#include "header.h"

void predict_unit13(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5509189654985258144) ) ) {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7850000000000001421) ) ) {
      result[0] += 0.002591369472332435;
    } else {
      result[0] += -0.018329502332884204;
    }
  } else {
    result[0] += 0.0053575253195831405;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)273.5000000000000568) ) ) {
    result[0] += 0.001556321564086184;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)280.5000000000000568) ) ) {
      result[0] += -0.10352638758604635;
    } else {
      result[0] += -0.00605174767088962;
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)19.50000000000000355) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.422825113797481833) ) ) {
      result[0] += -0.063796517000342;
    } else {
      result[0] += -0.0034707359547874886;
    }
  } else {
    result[0] += 0.0017305910520209532;
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9461509352790128391) ) ) {
    result[0] += -0.00018092539923098092;
  } else {
    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6752850000000001351) ) ) {
      result[0] += 0.11667633230809137;
    } else {
      result[0] += -0.3687510601358887;
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
    if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9146354675577249571) ) ) {
      result[0] += 0.00010641598837669858;
    } else {
      result[0] += 0.12429566678528958;
    }
  } else {
    result[0] += -0.030132996722862525;
  }
  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.211360663335670829) ) ) {
    result[0] += 0.04584675685213155;
  } else {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2877814710301507817) ) ) {
      result[0] += -0.06979261896522124;
    } else {
      result[0] += 1.5618213201290188e-05;
    }
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3550000000000000377) ) ) {
    result[0] += 0.008236229838382118;
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4863601680382418357) ) ) {
      result[0] += -0.06106912864946975;
    } else {
      result[0] += 0.0002109999317232012;
    }
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1438780622129160192) ) ) {
    result[0] += -0.04813688066817619;
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0.14584854770401645;
    } else {
      result[0] += -3.364237519602057e-05;
    }
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6722423356281408413) ) ) {
    result[0] += -0.002035718783821178;
  } else {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6802634857286432579) ) ) {
      result[0] += 0.10425172469992697;
    } else {
      result[0] += -0.0006698277366669603;
    }
  }
  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4008331129359999911) ) ) {
    if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4026472078210281969) ) ) {
      result[0] += 0.005420950499751648;
    } else {
      result[0] += 0.1179242573559044;
    }
  } else {
    result[0] += -0.0013915044976256692;
  }
}

