
#include "header.h"

void predict_unit13(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004890500000000001617) ) ) {
    result[0] += -0.0061057550018917195;
  } else {
    result[0] += 0.005161504913040087;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9297150130940317059) ) ) {
    result[0] += -0.0006494998363250743;
  } else {
    result[0] += 0.04833734590870713;
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
    result[0] += 0.016372825142280542;
  } else {
    result[0] += -0.0018523296573582867;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3872001722105076205) ) ) {
    result[0] += -0.018153149003282562;
  } else {
    result[0] += 0.0016990170610383325;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5443709472300640728) ) ) {
    result[0] += -0.004104581196229976;
  } else {
    result[0] += 0.007326073519052415;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1316017537932669124) ) ) {
    result[0] += -0.046656104514117155;
  } else {
    result[0] += 0.0006375980873189477;
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
    result[0] += 0.016113008052379845;
  } else {
    result[0] += -0.0018301821813682475;
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004890500000000001617) ) ) {
    result[0] += -0.005938981605903435;
  } else {
    result[0] += 0.005028109882504778;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9297150130940317059) ) ) {
    result[0] += -0.0006106660186339607;
  } else {
    result[0] += 0.04788881768976613;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1316017537932669124) ) ) {
    result[0] += -0.046287054224488644;
  } else {
    result[0] += 0.0006078682163992992;
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
    result[0] += 0.015719013189153717;
  } else {
    result[0] += -0.0017932374987824787;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5794124692327976556) ) ) {
    result[0] += -0.0032946150404092565;
  } else {
    result[0] += 0.008412603201051826;
  }
}

