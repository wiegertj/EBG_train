
#include "header.h"

void predict_unit4(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6930953257568631676) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4586286491922050845) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2594714022927627761) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1264739246323610955) ) ) {
          result[0] += -0.12425852181454153;
        } else {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3103100527046326884) ) ) {
            if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4349340187803038549) ) ) {
              result[0] += -0.11219167748927154;
            } else {
              result[0] += -0.027353013755681586;
            }
          } else {
            result[0] += -0.11365683325710635;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += -0.07417022655526291;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.389828724245051994) ) ) {
            result[0] += -0.10213295795868303;
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1898832163732817602) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6409824997738694519) ) ) {
                result[0] += -0.06092037123293989;
              } else {
                result[0] += -0.001602355098066432;
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4650000000000000244) ) ) {
                result[0] += -0.08268140772733784;
              } else {
                result[0] += -0.11871465563160143;
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5593705952246232904) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3070740017980582715) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5234930566607364222) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1750000000000000167) ) ) {
              result[0] += -0.006869529110299005;
            } else {
              result[0] += -0.05277846415707379;
            }
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.00000001800250948e-35) ) ) {
              result[0] += -0.04834318260541503;
            } else {
              result[0] += 0.006763863558213115;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5074134513786895395) ) ) {
            result[0] += -0.0904917998491791;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3250000000000000666) ) ) {
              result[0] += -0.02896226041699482;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7847910031909549611) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7002474625125628682) ) ) {
                  result[0] += -0.07338751730224108;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7472528898492464267) ) ) {
                    result[0] += -0.0007935135511035008;
                  } else {
                    result[0] += -0.07616506321800184;
                  }
                }
              } else {
                result[0] += -0.11372814454495889;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.634410233061354023) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4150000000000000355) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08212050000000001293) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.484933386852080317) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
                  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3151582419271714008) ) ) {
                    result[0] += 0.02853307397966425;
                  } else {
                    result[0] += -0.0296712740129428;
                  }
                } else {
                  result[0] += -0.030047883043156275;
                }
              } else {
                result[0] += 0.04450501185807843;
              }
            } else {
              result[0] += -0.04377428842770266;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5614270723115578621) ) ) {
                result[0] += -0.04790624799235239;
              } else {
                result[0] += 0.017963800885032598;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.609385253452748854) ) ) {
                result[0] += -0.06404032286409027;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.742552040434129812) ) ) {
                  result[0] += -0.026030404477549472;
                } else {
                  result[0] += -0.08363771693640022;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4365950629658605364) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.564198853668341882) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4165540671289910679) ) ) {
                result[0] += -0.02671683586684374;
              } else {
                result[0] += 0.021320072275261375;
              }
            } else {
              result[0] += 0.03185543329700669;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02608100000000000349) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4658559739752448081) ) ) {
                result[0] += 0.011920103477820845;
              } else {
                result[0] += -0.02257541099744705;
              }
            } else {
              result[0] += -0.06545165424270175;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6687753071115941639) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8419751086149712682) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7803107051370604674) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4365950629658605364) ) ) {
            result[0] += 0.05149307384395375;
          } else {
            result[0] += 0.0076049632508171155;
          }
        } else {
          result[0] += 0.03190517918523678;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9181645509592420984) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001771500000000000288) ) ) {
            result[0] += 0.01174714418344873;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004497500000000000629) ) ) {
              result[0] += 0.08064383933288606;
            } else {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6333994641870349662) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.7650000000000001243) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8798139045856544493) ) ) {
                    result[0] += 0.043944189759422575;
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03007150000000000448) ) ) {
                      result[0] += 0.1078990959574381;
                    } else {
                      result[0] += 0.05381937415157148;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01667900000000000285) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5628434130653267031) ) ) {
                      result[0] += 0.03697121916726798;
                    } else {
                      result[0] += -0.021251851224766645;
                    }
                  } else {
                    result[0] += 0.05458734952732786;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1165587384072143268) ) ) {
                  result[0] += 0.04051930440249499;
                } else {
                  result[0] += 0.09094022863351968;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9650000000000000799) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5408295445477387942) ) ) {
              result[0] += 0.0737171244772892;
            } else {
              result[0] += 0.11287431129527037;
            }
          } else {
            result[0] += 0.045300886365652715;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7948589598137713041) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9550000000000000711) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7360390231494754465) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9150000000000001465) ) ) {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.6505320650523345183) ) ) {
                result[0] += 0.03953201413552394;
              } else {
                result[0] += 0.09665816671457608;
              }
            } else {
              result[0] += 0.028105928893683744;
            }
          } else {
            result[0] += 0.10859955507461436;
          }
        } else {
          result[0] += 0.05806897804247231;
        }
      } else {
        result[0] += 0.12671311686843492;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6930953257568631676) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4586286491922050845) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2594714022927627761) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1264739246323610955) ) ) {
          result[0] += -0.12268105966547514;
        } else {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3750409390474713223) ) ) {
            if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4852332858229937984) ) ) {
              result[0] += -0.10599366042062064;
            } else {
              result[0] += -0.006392348987112829;
            }
          } else {
            result[0] += -0.11076978959189462;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += -0.06973183832434407;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.389828724245051994) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0650000000000000161) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.05500000000000000722) ) ) {
                result[0] += -0.10304340680663308;
              } else {
                result[0] += -0.04966472226920409;
              }
            } else {
              result[0] += -0.10272008378296049;
            }
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1898832163732817602) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.590212735175879577) ) ) {
                result[0] += -0.058393113686189366;
              } else {
                result[0] += -0.00558199719196465;
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4650000000000000244) ) ) {
                result[0] += -0.0782863143094532;
              } else {
                result[0] += -0.11598328914613457;
              }
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5891834603033582196) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2766339022102697887) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5234930566607364222) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1850000000000000255) ) ) {
              result[0] += -0.004872552665668035;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2463909746624610153) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6311389315075378592) ) ) {
                  result[0] += -0.04495781572458302;
                } else {
                  result[0] += 0.010842268553103622;
                }
              } else {
                result[0] += -0.06262462376434563;
              }
            }
          } else {
            result[0] += -0.012481548307221198;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002169500000000000421) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.500000000000000283e-05) ) ) {
              result[0] += -0.04451988473452141;
            } else {
              result[0] += -0.08489147582857366;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5074134513786895395) ) ) {
              result[0] += -0.08358814569687611;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
                result[0] += 0;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01039650000000000123) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5789331372495346573) ) ) {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5650000000000000577) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6311389315075378592) ) ) {
                        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3650000000000000466) ) ) {
                          result[0] += -0.014683995655933042;
                        } else {
                          result[0] += -0.07054154506930728;
                        }
                      } else {
                        result[0] += 0.0299726845325833;
                      }
                    } else {
                      result[0] += -0.06525277830561593;
                    }
                  } else {
                    result[0] += 0.00490181368425241;
                  }
                } else {
                  result[0] += -0.06910317562589757;
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6850000000000001643) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7683067979899498301) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6722423356281408413) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3880603600537617104) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4574668247487437833) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4750000000000000333) ) ) {
                    result[0] += -0.005421683013571087;
                  } else {
                    result[0] += -0.04818861074175943;
                  }
                } else {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2044121788183031196) ) ) {
                    result[0] += 0.07309568915400555;
                  } else {
                    if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.08835747683243963535) ) ) {
                      result[0] += -0.07382946584982703;
                    } else {
                      result[0] += -0.0004985445497178094;
                    }
                  }
                }
              } else {
                result[0] += -0.04748644743061678;
              }
            } else {
              result[0] += 0.045253704921036864;
            }
          } else {
            result[0] += -0.05059616870069504;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.625846821573829204) ) ) {
            result[0] += -0.048704461714842086;
          } else {
            result[0] += -0.021614083268685486;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6817186019653541651) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8419751086149712682) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7803107051370604674) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4365950629658605364) ) ) {
            result[0] += 0.04561981397741374;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.500000000000000283e-05) ) ) {
              result[0] += 0.03792268547814058;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7390680933680099374) ) ) {
                result[0] += -0.0017531844860481725;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0006595000000000000384) ) ) {
                  result[0] += -0.021544662999578194;
                } else {
                  result[0] += 0.014798322710516171;
                }
              }
            }
          }
        } else {
          result[0] += 0.028510441440402042;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9433039335395834168) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0009285000000000001802) ) ) {
            result[0] += 0.0012722997715190554;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004497500000000000629) ) ) {
              result[0] += 0.07602996514538206;
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.5708656043828381765) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3271553819095477933) ) ) {
                  result[0] += 0.05241154533570232;
                } else {
                  result[0] += -0.01322074236355929;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8798139045856544493) ) ) {
                  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6047326933819162642) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.7350000000000000977) ) ) {
                      result[0] += 0.042998905531034796;
                    } else {
                      result[0] += -0.00588304516081282;
                    }
                  } else {
                    result[0] += 0.059989251619338005;
                  }
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6393323174634368833) ) ) {
                    result[0] += 0.09141653260351504;
                  } else {
                    result[0] += 0.05411215129014601;
                  }
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.09855101609863538;
          } else {
            result[0] += 0.049078070951171206;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7948589598137713041) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9550000000000000711) ) ) {
          result[0] += 0.0945207245054382;
        } else {
          result[0] += 0.056638314518055316;
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8679983746857627969) ) ) {
          result[0] += 0.11303133463081569;
        } else {
          result[0] += 0.12683755419178208;
        }
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7075621644339633587) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4312690111265354842) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2287126979501296342) ) ) {
        result[0] += -0.11661692622004577;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.500000000000000283e-05) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05500000000000000722) ) ) {
            result[0] += -0.013527244956626081;
          } else {
            result[0] += -0.07191860057505944;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.742577338542713683) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005917000000000001252) ) ) {
              result[0] += -0.0968711181890825;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3950920455282702082) ) ) {
                result[0] += -0.08403165193768362;
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2034189761111596384) ) ) {
                  result[0] += 0.014986849877481731;
                } else {
                  result[0] += -0.06829106790631397;
                }
              }
            }
          } else {
            result[0] += -0.11254188224794501;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5400664745690104684) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3550000000000000377) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1750000000000000167) ) ) {
            if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.007306405187673099474) ) ) {
              result[0] += -0.02678280618318009;
            } else {
              result[0] += 0.04436993557328818;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4665965687058793443) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2286346831266519164) ) ) {
                result[0] += -0.019433085105296524;
              } else {
                result[0] += -0.09018774039990066;
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2657640829265360827) ) ) {
                result[0] += -0.013835705497426689;
              } else {
                result[0] += -0.049257745170745645;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002169500000000000421) ) ) {
            result[0] += -0.08744552338194134;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.103206753861813993) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1129321246270776624) ) ) {
                result[0] += -0.07291671099017753;
              } else {
                result[0] += -0.038818242754257;
              }
            } else {
              result[0] += -0.1021159322342122;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6595171046238990087) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3329079290171987338) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.634410233061354023) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08460400000000001253) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
                  result[0] += 0.04370106182108611;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2933113730839578825) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.564198853668341882) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02552250000000000352) ) ) {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01144700000000000058) ) ) {
                          result[0] += -0.015053414910353417;
                        } else {
                          result[0] += -0.0625408149822606;
                        }
                      } else {
                        result[0] += 0.03038377825106495;
                      }
                    } else {
                      result[0] += -0.06938582916616211;
                    }
                  } else {
                    result[0] += 0.002776037923514333;
                  }
                }
              } else {
                result[0] += -0.04618058583392826;
              }
            } else {
              result[0] += 0.031338387697684024;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5837974670096922614) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3912772649537276659) ) ) {
                result[0] += 0.0040552982300593845;
              } else {
                result[0] += -0.06738740466334715;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002780000000000000353) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                  result[0] += 0.00185732634657608;
                } else {
                  result[0] += -0.04423621176770452;
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01768250000000000377) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4150000000000000355) ) ) {
                    result[0] += 0.040014272853283475;
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003900500000000000321) ) ) {
                      result[0] += 0.017389589861384096;
                    } else {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7150000000000000799) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5705607401507538645) ) ) {
                          result[0] += -0.03324646760139538;
                        } else {
                          result[0] += 0.020927377266168213;
                        }
                      } else {
                        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8050000000000001599) ) ) {
                          result[0] += -0.08708402396608583;
                        } else {
                          result[0] += -0.024667108000316552;
                        }
                      }
                    }
                  }
                } else {
                  result[0] += -0.04276244421103421;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5050000000000001155) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6323035877889447987) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
                result[0] += 0.03559908448569153;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5499504253266332965) ) ) {
                  result[0] += -0.051997983762847144;
                } else {
                  result[0] += 0.01160640681539877;
                }
              }
            } else {
              result[0] += 0.0556168194966405;
            }
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4203101245558852894) ) ) {
              result[0] += -0.05381013986022066;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5127811792069081331) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2610662092258060896) ) ) {
                  if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.171991477868887549) ) ) {
                    result[0] += 0.026041255115154604;
                  } else {
                    result[0] += -0.0429164086288897;
                  }
                } else {
                  result[0] += 0.050402371855907166;
                }
              } else {
                result[0] += -0.017342561807654984;
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6817186019653541651) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.848222830561460639) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7803107051370604674) ) ) {
          result[0] += 0.008809086939873992;
        } else {
          result[0] += 0.02596591264816729;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9433039335395834168) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0009285000000000001802) ) ) {
            result[0] += 0.007761641051260242;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004497500000000000629) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2739990068871500095) ) ) {
                result[0] += 0.05521054457441204;
              } else {
                result[0] += 0.11224180171290825;
              }
            } else {
              result[0] += 0.045318375193340935;
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.0930278136783393;
          } else {
            result[0] += 0.04478769286809607;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7948589598137713041) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9550000000000000711) ) ) {
          result[0] += 0.08949661678271402;
        } else {
          result[0] += 0.05214772003774367;
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8679983746857627969) ) ) {
          result[0] += 0.1092622871292412;
        } else {
          result[0] += 0.12422403107028807;
        }
      }
    }
  }
}

