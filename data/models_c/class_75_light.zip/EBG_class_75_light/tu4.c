
#include "header.h"

void predict_unit4(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7472528898492464267) ) ) {
    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008715500000000002759) ) ) {
      result[0] += -0.007738749429199558;
    } else {
      result[0] += 0.023231343995799337;
    }
  } else {
    result[0] += -0.03436968386890701;
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1325117542492068867) ) ) {
    result[0] += -0.11676235031750389;
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
      result[0] += 0.048621497513911656;
    } else {
      result[0] += -0.0035970854996984552;
    }
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9425832747582749693) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.08449095111286804294) ) ) {
      result[0] += -0.13274887050073908;
    } else {
      result[0] += -0.0002251133341400329;
    }
  } else {
    result[0] += 0.13171637500251115;
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.611969772716791538) ) ) {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
      result[0] += 0.02298610948376519;
    } else {
      result[0] += -0.03434452240760878;
    }
  } else {
    result[0] += 0.008471766369354209;
  }
  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003623500000000000418) ) ) {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
      result[0] += 0.027476052753135704;
    } else {
      result[0] += -0.030253178169909075;
    }
  } else {
    result[0] += 0.01071643743134958;
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9461509352790128391) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.08449095111286804294) ) ) {
      result[0] += -0.13132205502778913;
    } else {
      result[0] += -0.00012465545052134692;
    }
  } else {
    result[0] += 0.1322561587514848;
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6413622072216433878) ) ) {
    result[0] += 0.005995701789372606;
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6027180103729999905) ) ) {
      result[0] += -0.0594801438748697;
    } else {
      result[0] += -0.003018319703680157;
    }
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9461509352790128391) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2912453567552589773) ) ) {
      result[0] += -0.054074754970655746;
    } else {
      result[0] += 0.0011027826646004815;
    }
  } else {
    result[0] += 0.13027945824982542;
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03562712304331070584) ) ) {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
      result[0] += 0.02677989338290743;
    } else {
      result[0] += -0.011129598580923829;
    }
  } else {
    result[0] += 0.01996407916429658;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7804766498994976098) ) ) {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002092500000000000176) ) ) {
      result[0] += -0.014544598908988625;
    } else {
      result[0] += 0.01155600053772804;
    }
  } else {
    result[0] += -0.03523509873399449;
  }
}

