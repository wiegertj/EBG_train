
#include "header.h"

void predict_unit4(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7216251912765565546) ) ) {
    result[0] += -0.012654404514219213;
  } else {
    result[0] += 0.05325885371083647;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4468288327365124712) ) ) {
    result[0] += -0.04577788292926147;
  } else {
    result[0] += 0.014500684938775623;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7216251912765565546) ) ) {
    result[0] += -0.011963706672925423;
  } else {
    result[0] += 0.05241253282016895;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4377968628344893198) ) ) {
    result[0] += -0.045396890870811585;
  } else {
    result[0] += 0.013542357094630244;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7216251912765565546) ) ) {
    result[0] += -0.011309383456567082;
  } else {
    result[0] += 0.05158393594658404;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4116647182239227543) ) ) {
    result[0] += -0.04615427878533028;
  } else {
    result[0] += 0.012353769619154622;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7408532796442338642) ) ) {
    result[0] += -0.010390153449484548;
  } else {
    result[0] += 0.05233383812146031;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4116647182239227543) ) ) {
    result[0] += -0.045303029581454046;
  } else {
    result[0] += 0.011670314103977376;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7546981702242574475) ) ) {
    result[0] += -0.009635766238137056;
  } else {
    result[0] += 0.05268639038568549;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.401955382461930133) ) ) {
    result[0] += -0.04501464425077393;
  } else {
    result[0] += 0.010897884351381037;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7546981702242574475) ) ) {
    result[0] += -0.009109922870242431;
  } else {
    result[0] += 0.05200526159353685;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3872001722105076205) ) ) {
    result[0] += -0.0450175702169666;
  } else {
    result[0] += 0.010113489572202851;
  }
}

