
#include "header.h"

void predict_unit6(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.04830892724354553247) ) ) {
    result[0] += -0.13845913741657834;
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
      result[0] += 0.02563833320674088;
    } else {
      result[0] += -0.0026197718688745217;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5980109955351072815) ) ) {
    result[0] += -0.013454828868238186;
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.545000000000000151) ) ) {
      result[0] += 0.047281360876523855;
    } else {
      result[0] += 0.0015545341962382405;
    }
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5677320766830197263) ) ) {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7150000000000000799) ) ) {
      result[0] += 0.003610553296668803;
    } else {
      result[0] += -0.01909116850625442;
    }
  } else {
    result[0] += 0.012002984750494978;
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9461509352790128391) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3411690131117683933) ) ) {
      result[0] += -0.032699261560886976;
    } else {
      result[0] += 0.0012721862769529333;
    }
  } else {
    result[0] += 0.11929795580656564;
  }
  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.211360663335670829) ) ) {
    result[0] += 0.09296263699292695;
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001794500000000000305) ) ) {
      result[0] += -0.012593110481528147;
    } else {
      result[0] += 0.0041576336731664835;
    }
  }
  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
    result[0] += 0.022011752316368923;
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00171750000000000006) ) ) {
      result[0] += -0.03200499760113724;
    } else {
      result[0] += 0.0038881454630557426;
    }
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.04830892724354553247) ) ) {
    result[0] += -0.13731760868030665;
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0.14044211217294195;
    } else {
      result[0] += -3.3720921855817026e-05;
    }
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9461509352790128391) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
      result[0] += 6.177228182030515e-05;
    } else {
      result[0] += -0.09846189429988575;
    }
  } else {
    result[0] += 0.11584359667979978;
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7348856104110997878) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.978694354183763493) ) ) {
      result[0] += -0.0011860140364548504;
    } else {
      result[0] += -0.1524503818241874;
    }
  } else {
    result[0] += 0.03278297287373694;
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.611969772716791538) ) ) {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5650000000000000577) ) ) {
      result[0] += -0.0017287302115934077;
    } else {
      result[0] += -0.04635181738859232;
    }
  } else {
    result[0] += 0.0046262812948696915;
  }
}

