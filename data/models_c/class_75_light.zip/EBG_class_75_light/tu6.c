
#include "header.h"

void predict_unit6(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7616046585677935798) ) ) {
    result[0] += -0.0060853545565144355;
  } else {
    result[0] += 0.047970414259553125;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3012580068987611992) ) ) {
    result[0] += -0.045757795862923945;
  } else {
    result[0] += 0.006314652548364425;
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8154030078240236401) ) ) {
    result[0] += -0.006014972224910955;
  } else {
    result[0] += 0.045295646414975264;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2961071981692083854) ) ) {
    result[0] += -0.045413959562173936;
  } else {
    result[0] += 0.005929072153740178;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7616046585677935798) ) ) {
    result[0] += -0.005456054277572568;
  } else {
    result[0] += 0.0466884452863421;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2573388693305712627) ) ) {
    result[0] += -0.0474039696796778;
  } else {
    result[0] += 0.005288727401794235;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6422639030651048353) ) ) {
    result[0] += -0.007574508296376805;
  } else {
    result[0] += 0.03132255946965241;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2961071981692083854) ) ) {
    result[0] += -0.044063285407562665;
  } else {
    result[0] += 0.005304765317454201;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7616046585677935798) ) ) {
    result[0] += -0.004979650878121221;
  } else {
    result[0] += 0.04554440593455655;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2573388693305712627) ) ) {
    result[0] += -0.04622404309159023;
  } else {
    result[0] += 0.004738506839952923;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7616046585677935798) ) ) {
    result[0] += -0.004706827541733361;
  } else {
    result[0] += 0.04486630355304073;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2573388693305712627) ) ) {
    result[0] += -0.045615377609894994;
  } else {
    result[0] += 0.0044798329281747675;
  }
}

