
#include "header.h"

void predict_unit6(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6595171046238990087) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3421306008459473191) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.187139881547741499) ) ) {
        result[0] += -0.11268594847477553;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0003835000000000000518) ) ) {
          result[0] += -0.06795024094795139;
        } else {
          result[0] += -0.09141792568754725;
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4981007797820624639) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3550000000000000377) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08500000000000000611) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.07218104077152019682) ) ) {
              result[0] += -0.04275091204701829;
            } else {
              result[0] += 0.06351144627932953;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3150000000000000577) ) ) {
                result[0] += -0.04070804695843164;
              } else {
                result[0] += -0.00034373739327111017;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6277403467108452206) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6784611311055277483) ) ) {
                  result[0] += -0.05370709673853665;
                } else {
                  result[0] += 0.10214128958583847;
                }
              } else {
                result[0] += -0.08284431306100884;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002212500000000000491) ) ) {
            result[0] += -0.09416963116608516;
          } else {
            result[0] += -0.06120073496197838;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1850000000000000255) ) ) {
          result[0] += 0.04153299835334263;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5593705952246232904) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3912772649537276659) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5400664745690104684) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.330342879382321819) ) ) {
                  result[0] += -0.01665156677523124;
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3449735506066585189) ) ) {
                    result[0] += -0.0945092668487582;
                  } else {
                    result[0] += -0.0419098935514594;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5479721254819260867) ) ) {
                  result[0] += 0.014076094368284237;
                } else {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.01414472145045409836) ) ) {
                    result[0] += -0.06472174794974836;
                  } else {
                    result[0] += -0.006639219214392273;
                  }
                }
              }
            } else {
              result[0] += -0.06483773835321045;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4150000000000000355) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04976550000000001112) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2610662092258060896) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5511625663567840672) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
                      result[0] += 0.0276958438645305;
                    } else {
                      result[0] += -0.00800782966976066;
                    }
                  } else {
                    result[0] += -0.050161787971114716;
                  }
                } else {
                  result[0] += 0.04414754499852416;
                }
              } else {
                result[0] += -0.025945235442966688;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4950000000000000511) ) ) {
                  result[0] += -0.022182826190608664;
                } else {
                  result[0] += 0.02881740715336234;
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0008475000000000000545) ) ) {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1464732738946245838) ) ) {
                    result[0] += -0.01907801960482351;
                  } else {
                    result[0] += -0.081946307992574;
                  }
                } else {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4606764386340688189) ) ) {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002126500000000000352) ) ) {
                      result[0] += -0.07607142831650261;
                    } else {
                      result[0] += -0.030194647824927215;
                    }
                  } else {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9150000000000001465) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1786033740413308368) ) ) {
                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500792755494420073) ) ) {
                          result[0] += 0;
                        } else {
                          result[0] += -0.07521199850990795;
                        }
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6311389315075378592) ) ) {
                          result[0] += 0.06130070719477362;
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                            result[0] += -0.026540200089823385;
                          } else {
                            result[0] += 0.034476251261906;
                          }
                        }
                      }
                    } else {
                      result[0] += -0.051263156852683504;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7073687287159498016) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8647856135106589681) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7669558640352696077) ) ) {
          result[0] += 0.0013487767856604418;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5350000000000001421) ) ) {
            result[0] += 0.04875601915905179;
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5564233291784753677) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6950000000000000622) ) ) {
                if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4603009969540775015) ) ) {
                  result[0] += 0.03991696419979137;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5950000000000000844) ) ) {
                    result[0] += -0.03516291088152495;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8241447348397844541) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03449150000000000826) ) ) {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4693077114572864472) ) ) {
                          result[0] += -0.01543436868051919;
                        } else {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04679838077552211234) ) ) {
                            result[0] += 0.061517680684257225;
                          } else {
                            result[0] += 0.0073131319852862775;
                          }
                        }
                      } else {
                        result[0] += -0.041490649750048694;
                      }
                    } else {
                      result[0] += 0.039308418455898074;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8450000000000000844) ) ) {
                  result[0] += -0.0035401650586333604;
                } else {
                  result[0] += -0.06110291508243095;
                }
              }
            } else {
              result[0] += 0.02252135328212076;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8054659791206031372) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6166435351279918597) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8798139045856544493) ) ) {
              result[0] += 0.0066496780870368664;
            } else {
              result[0] += 0.03767635056835154;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8950000000000001288) ) ) {
              result[0] += 0.05111130734278442;
            } else {
              result[0] += 0.00876015254684062;
            }
          }
        } else {
          result[0] += 0.08886306755824872;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8371739120330333739) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9812133206808532071) ) ) {
            result[0] += 0.075041486054608;
          } else {
            result[0] += 0.10414036364975819;
          }
        } else {
          result[0] += 0.042236443409065676;
        }
      } else {
        result[0] += 0.11410100888604698;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8647856135106589681) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.46251079555665775) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2594714022927627761) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1264739246323610955) ) ) {
          result[0] += -0.11607832682428701;
        } else {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3750409390474713223) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001817500000000000322) ) ) {
              result[0] += -0.0935375318233915;
            } else {
              result[0] += 0.06563672119687497;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.500000000000000283e-05) ) ) {
              result[0] += -0.08203955491465194;
            } else {
              result[0] += -0.10648454768585645;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2169523881790832442) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3150000000000000577) ) ) {
              result[0] += -0.04845271590653913;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7106503892964824987) ) ) {
                result[0] += 0.03293758119206589;
              } else {
                result[0] += -0.05961778947271512;
              }
            }
          } else {
            result[0] += -0.09644443096163444;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004886500000000001086) ) ) {
            result[0] += -0.08241007526922162;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.742577338542713683) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7255694492462312351) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3950920455282702082) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07500000000000002498) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3680411812697468865) ) ) {
                      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1509014722221962701) ) ) {
                        result[0] += -0.08441390581427513;
                      } else {
                        result[0] += -0.008026169542442608;
                      }
                    } else {
                      result[0] += 0.029156327017762246;
                    }
                  } else {
                    result[0] += -0.08047653056048083;
                  }
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2034189761111596384) ) ) {
                    result[0] += 0.02920876140456459;
                  } else {
                    result[0] += -0.04322492299393074;
                  }
                }
              } else {
                result[0] += 0.05281960313614241;
              }
            } else {
              result[0] += -0.09466633593052655;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6647067832505478835) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2422035000000000438) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.179099372612799401) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5789331372495346573) ) ) {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2766339022102697887) ) ) {
                result[0] += -0.011871989490140523;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5074134513786895395) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2739990068871500095) ) ) {
                    result[0] += -0.09607539720095844;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6277403467108452206) ) ) {
                      result[0] += 0;
                    } else {
                      result[0] += -0.08740514434828356;
                    }
                  }
                } else {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3366886552868456062) ) ) {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3550000000000000377) ) ) {
                      result[0] += 0.024053199742563747;
                    } else {
                      result[0] += -0.040513072051263914;
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3550761912678883081) ) ) {
                      result[0] += -0.05261754717036672;
                    } else {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6947584613372143059) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7002474625125628682) ) ) {
                          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3196564466213921984) ) ) {
                            result[0] += 0.014876786575232377;
                          } else {
                            result[0] += -0.04659077622641991;
                          }
                        } else {
                          result[0] += 0.07828465393452184;
                        }
                      } else {
                        result[0] += -0.050925359081869785;
                      }
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4150000000000000355) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01632150000000000267) ) ) {
                  result[0] += 0.0387820374706391;
                } else {
                  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3196564466213921984) ) ) {
                    result[0] += 0.01870082740849461;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.187362217115970231) ) ) {
                      result[0] += -0.04912533585357109;
                    } else {
                      result[0] += 0.0003981815628506496;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9250000000000001554) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7382388927638191545) ) ) {
                    result[0] += -0.018551583251045674;
                  } else {
                    result[0] += 0.012254631032764056;
                  }
                } else {
                  result[0] += -0.05476934126692478;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002169500000000000421) ) ) {
              result[0] += -0.015700113093222366;
            } else {
              result[0] += -0.07621049680376328;
            }
          }
        } else {
          result[0] += 0.06659571485558193;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7803107051370604674) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4263038519874545185) ) ) {
            result[0] += 0.028407813750673444;
          } else {
            result[0] += 0.0008326577575353399;
          }
        } else {
          result[0] += 0.016255626010732733;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7886110426559866937) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6817186019653541651) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9650496265483141656) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8450000000000000844) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7218051716834171794) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8865421187835540451) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.7750000000000001332) ) ) {
                    if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1554217706027584134) ) ) {
                      result[0] += 0.059450876979923545;
                    } else {
                      result[0] += 0.0006636612889542569;
                    }
                  } else {
                    result[0] += -0.02543526499596623;
                  }
                } else {
                  result[0] += 0.04604091066927349;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3687216492462311868) ) ) {
                  result[0] += 0.00766226756494043;
                } else {
                  result[0] += 0.0493331839117912;
                }
              }
            } else {
              result[0] += 0.06982524234109562;
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
              result[0] += 0.030500836623612797;
            } else {
              result[0] += -0.034971671883039304;
            }
          }
        } else {
          result[0] += 0.0859886082204009;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9450000000000000622) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9782915297286400858) ) ) {
            result[0] += 0.0621255746762044;
          } else {
            result[0] += 0.09707469622860782;
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7570612716642158846) ) ) {
            result[0] += 0;
          } else {
            result[0] += 0.06162382939378033;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8679983746857627969) ) ) {
        result[0] += 0.09058202062520407;
      } else {
        result[0] += 0.11405074312553587;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8647856135106589681) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4312690111265354842) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2287126979501296342) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1264739246323610955) ) ) {
          result[0] += -0.11523355937007995;
        } else {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3750409390474713223) ) ) {
            result[0] += 0.00019946537936991205;
          } else {
            result[0] += -0.09726456308283296;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.500000000000000283e-05) ) ) {
          result[0] += -0.043880522402576665;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.742577338542713683) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2769019423430922888) ) ) {
              result[0] += -0.0934387125746142;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07500000000000002498) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2888738239382729889) ) ) {
                  result[0] += -0.0528682889436049;
                } else {
                  result[0] += 0.1019718136028349;
                }
              } else {
                result[0] += -0.0639919718541818;
              }
            }
          } else {
            result[0] += -0.09966950141115005;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.625846821573829204) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4975581368341708832) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004405500000000000561) ) ) {
              result[0] += -0.029005584484501502;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3250000000000000666) ) ) {
                result[0] += -0.0154092754472431;
              } else {
                result[0] += 0.031123223707615853;
              }
            }
          } else {
            result[0] += 0.05902607453212106;
          }
        } else {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.07409325127878772788) ) ) {
            result[0] += -0.0632124422892778;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.179099372612799401) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.039291117014028876) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9993516786272610419) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7665928407035177417) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7536081807788946874) ) ) {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3550761912678883081) ) ) {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4665965687058793443) ) ) {
                          result[0] += -0.07156367104698245;
                        } else {
                          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2450000000000000233) ) ) {
                            result[0] += 0.055957392507333545;
                          } else {
                            result[0] += -0.032809486904123664;
                          }
                        }
                      } else {
                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7254919443713668814) ) ) {
                          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3850000000000000644) ) ) {
                            result[0] += 0.02067122584838527;
                          } else {
                            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6975240073869347635) ) ) {
                              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5002086535089875774) ) ) {
                                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6541365753517588422) ) ) {
                                  result[0] += -0.030794452045416587;
                                } else {
                                  result[0] += 0.04402731902377916;
                                }
                              } else {
                                result[0] += -0.0607114788425953;
                              }
                            } else {
                              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002376500000000000574) ) ) {
                                result[0] += -0.024823165807767805;
                              } else {
                                result[0] += 0.06521900657325887;
                              }
                            }
                          }
                        } else {
                          result[0] += -0.04071115971740401;
                        }
                      }
                    } else {
                      result[0] += -0.10490247012308408;
                    }
                  } else {
                    result[0] += 0.0396364843184936;
                  }
                } else {
                  result[0] += -0.09903273098005515;
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002909500000000000194) ) ) {
                  result[0] += -0.015340507577462558;
                } else {
                  result[0] += 0.08564690645711692;
                }
              }
            } else {
              result[0] += -0.057596723573775904;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.728792159352835367) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3150000000000000577) ) ) {
            result[0] += 0.044658585903782445;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3998546246231156065) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3356740245226131347) ) ) {
                result[0] += 0.009194944166688765;
              } else {
                result[0] += -0.05962911956038463;
              }
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3750409390474713223) ) ) {
                result[0] += 0.03643484894106544;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4564975229145729063) ) ) {
                  result[0] += -0.04118060304817472;
                } else {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2108839252750100701) ) ) {
                    result[0] += 0.03528626344458592;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.516715179698492566) ) ) {
                      result[0] += -0.03647442359749427;
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4450000000000000622) ) ) {
                        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6650000000000001465) ) ) {
                          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05352650000000001157) ) ) {
                            result[0] += 0.03674908929864331;
                          } else {
                            result[0] += -0.02345495790981567;
                          }
                        } else {
                          result[0] += 0.05752102938029614;
                        }
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5493276582412061071) ) ) {
                          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.531569796683417195) ) ) {
                            result[0] += 0.012549174028985376;
                          } else {
                            result[0] += -0.06518122490897518;
                          }
                        } else {
                          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5550000000000001599) ) ) {
                            result[0] += 0.04713223154117194;
                          } else {
                            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6277403467108452206) ) ) {
                              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.679632490452261373) ) ) {
                                result[0] += -0.0016370413023756246;
                              } else {
                                result[0] += 0.05057556581061194;
                              }
                            } else {
                              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4034599988722398778) ) ) {
                                result[0] += -0.07080106642852252;
                              } else {
                                if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4603009969540775015) ) ) {
                                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.008907500000000000487) ) ) {
                                    result[0] += 0.03543013075777389;
                                  } else {
                                    result[0] += -0.0228063355656585;
                                  }
                                } else {
                                  result[0] += -0.029182890957921075;
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.500000000000000283e-05) ) ) {
            result[0] += 0.04666825043491995;
          } else {
            result[0] += 0.009847960413041108;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7948589598137713041) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6817186019653541651) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9650496265483141656) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8450000000000000844) ) ) {
            result[0] += 0.0341187412024678;
          } else {
            result[0] += -0.0003344789448075876;
          }
        } else {
          result[0] += 0.08128059860739896;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9550000000000000711) ) ) {
          result[0] += 0.06353638196910434;
        } else {
          result[0] += 0.023710374271116216;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8885612913813883962) ) ) {
        result[0] += 0.09110323764083404;
      } else {
        result[0] += 0.1135725713708467;
      }
    }
  }
}

