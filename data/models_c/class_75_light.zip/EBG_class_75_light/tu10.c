
#include "header.h"

void predict_unit10(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5834132811601008273) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6450000000000001288) ) ) {
      result[0] += -0.0012765287923216762;
    } else {
      result[0] += -0.04456580980993226;
    }
  } else {
    result[0] += 0.0062458273261514164;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1124.500000000000227) ) ) {
    result[0] += -0.00043233306637576423;
  } else {
    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021955000000000086) ) ) {
      result[0] += -0.011201250282393199;
    } else {
      result[0] += 0.15605134124224426;
    }
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)273.5000000000000568) ) ) {
    result[0] += 0.0020520544397956567;
  } else {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)280.5000000000000568) ) ) {
      result[0] += -0.11749007327397007;
    } else {
      result[0] += -0.008217805177030779;
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)19.50000000000000355) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.422825113797481833) ) ) {
      result[0] += -0.07085982743429799;
    } else {
      result[0] += -0.005049083415625214;
    }
  } else {
    result[0] += 0.002265543696487065;
  }
  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.394173313988213314) ) ) {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005406500000000000715) ) ) {
      result[0] += -0.036086616558697465;
    } else {
      result[0] += 0.15788465957565667;
    }
  } else {
    result[0] += -0.00027590364215898796;
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.04830892724354553247) ) ) {
    result[0] += -0.12812899294367736;
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)5.950000000000000292e-05) ) ) {
      result[0] += 0.013323829054865712;
    } else {
      result[0] += -0.0015638435762145905;
    }
  }
  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001794500000000000305) ) ) {
    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)5.950000000000000292e-05) ) ) {
      result[0] += 0.010214414909956174;
    } else {
      result[0] += -0.019928108784082754;
    }
  } else {
    result[0] += 0.0029878110284633106;
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5874282592522120927) ) ) {
    result[0] += -0.008011133662326237;
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.3276803427655177736) ) ) {
      result[0] += 0.06318602662532138;
    } else {
      result[0] += 0.0010211825392681367;
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6277403467108452206) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6043838026813522779) ) ) {
      result[0] += 0.00022007155331640218;
    } else {
      result[0] += 0.11556946271449618;
    }
  } else {
    result[0] += -0.009042323204263212;
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9461509352790128391) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
      result[0] += 0.00030962204301189717;
    } else {
      result[0] += -0.05830818208670112;
    }
  } else {
    result[0] += 0.09442238789623811;
  }
}

