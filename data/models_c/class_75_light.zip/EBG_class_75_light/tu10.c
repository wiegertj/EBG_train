
#include "header.h"

void predict_unit10(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8905049116466139392) ) ) {
    result[0] += -0.001529914864979565;
  } else {
    result[0] += 0.04724831320960331;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1601111865813344692) ) ) {
    result[0] += -0.04773517876507366;
  } else {
    result[0] += 0.0014198550364660338;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8905049116466139392) ) ) {
    result[0] += -0.0014471707652776297;
  } else {
    result[0] += 0.04678258233812933;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5923541255337830824) ) ) {
    result[0] += -0.012690343769426782;
  } else {
    result[0] += 0.005171600655961629;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.919952104732480902) ) ) {
    result[0] += -0.0012490090852423769;
  } else {
    result[0] += 0.05073184699957983;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1316017537932669124) ) ) {
    result[0] += -0.050882283727081194;
  } else {
    result[0] += 0.0012329942752766594;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5794124692327976556) ) ) {
    result[0] += -0.0049719477756698695;
  } else {
    result[0] += 0.012220454074573789;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1316017537932669124) ) ) {
    result[0] += -0.05058200902287663;
  } else {
    result[0] += 0.0011636259476334428;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.919952104732480902) ) ) {
    result[0] += -0.001170588538959294;
  } else {
    result[0] += 0.05034010094803936;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1601111865813344692) ) ) {
    result[0] += -0.04633498012953604;
  } else {
    result[0] += 0.0011969657472346658;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.919952104732480902) ) ) {
    result[0] += -0.0011075186125553745;
  } else {
    result[0] += 0.0500179314212901;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8823707875690468549) ) ) {
    result[0] += -0.0032584572179799004;
  } else {
    result[0] += 0.016267052543813828;
  }
}

