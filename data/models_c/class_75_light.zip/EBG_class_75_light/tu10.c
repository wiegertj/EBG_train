
#include "header.h"

void predict_unit10(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7886110426559866937) ) ) {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2594714022927627761) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1264739246323610955) ) ) {
        result[0] += -0.10742530515295498;
      } else {
        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3103100527046326884) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003179500000000000468) ) ) {
            result[0] += -0.05880653118900536;
          } else {
            result[0] += 0.12472139316679053;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0003835000000000000518) ) ) {
            result[0] += -0.04253586766796358;
          } else {
            result[0] += -0.08724577997941217;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5593705952246232904) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4404146740571510121) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05500000000000000722) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.05500000000000000722) ) ) {
              result[0] += -0.03986092660239018;
            } else {
              result[0] += 0.04686484333653392;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.330941139090062508) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.126853541778489509) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3550000000000000377) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.590212735175879577) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3421306008459473191) ) ) {
                      result[0] += -0.06190492399091602;
                    } else {
                      result[0] += -0.022895276524120153;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6062825421608041276) ) ) {
                      result[0] += 0.09585674533063195;
                    } else {
                      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1430945241565956538) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3087763417305322555) ) ) {
                          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.0855044724911606796) ) ) {
                            result[0] += 0.04294381412949492;
                          } else {
                            result[0] += -0.05362327165827157;
                          }
                        } else {
                          result[0] += 0.12615055698206898;
                        }
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3469080158250638646) ) ) {
                          result[0] += -0.07710584316251679;
                        } else {
                          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1461447167956276272) ) ) {
                            result[0] += 0.03391153552760628;
                          } else {
                            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6277403467108452206) ) ) {
                              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.657009492487437341) ) ) {
                                result[0] += -0.04659760660484317;
                              } else {
                                result[0] += 0.03721796619303304;
                              }
                            } else {
                              result[0] += -0.06691704542683763;
                            }
                          }
                        }
                      }
                    }
                  }
                } else {
                  result[0] += -0.06471558457599765;
                }
              } else {
                result[0] += -0.09504220701460317;
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8430106374371860722) ) ) {
                result[0] += 0.10986129884231774;
              } else {
                result[0] += -0.04289038185334924;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2034189761111596384) ) ) {
            result[0] += 0.058413053668948604;
          } else {
            result[0] += -0.01271887962605349;
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6448546879214981375) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8143976568897295376) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3350000000000000755) ) ) {
                result[0] += -0.020637495908628165;
              } else {
                result[0] += 0.01886111829415051;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0007085000000000000369) ) ) {
                if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.524704885919457964) ) ) {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1464732738946245838) ) ) {
                    result[0] += -0.006937241166672186;
                  } else {
                    result[0] += -0.07889493991604919;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7580745019261865281) ) ) {
                    result[0] += 0.03121857753696846;
                  } else {
                    result[0] += -0.028187664244151554;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3150000000000000577) ) ) {
                  result[0] += 0.03371274218819245;
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3950000000000000733) ) ) {
                    result[0] += -0.038369465051055617;
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.194581012612933923) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8158067323869347964) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7890731911809046872) ) ) {
                          result[0] += 0.0006843533334268866;
                        } else {
                          result[0] += -0.03630317590664185;
                        }
                      } else {
                        result[0] += 0.03219950771849284;
                      }
                    } else {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.394135022639764854) ) ) {
                        result[0] += -0.03799037308767628;
                      } else {
                        result[0] += 0.016291801019661576;
                      }
                    }
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5750000000000000666) ) ) {
              result[0] += 0.043525348704190385;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7894192122613066243) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9299211678646118751) ) ) {
                  result[0] += 0.006634567914523307;
                } else {
                  result[0] += -0.03349536108502416;
                }
              } else {
                result[0] += 0.04171413219993903;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9856199261698411762) ) ) {
              result[0] += 0.03506813069057272;
            } else {
              result[0] += 0.10669094991064206;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9150000000000001465) ) ) {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7145555064862877392) ) ) {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.6505320650523345183) ) ) {
                  result[0] += -0.03246079650169117;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9145426888061906068) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006028500000000000872) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8744234851232283168) ) ) {
                        result[0] += 0.02639963025141253;
                      } else {
                        result[0] += -0.019023421453654352;
                      }
                    } else {
                      result[0] += 0.0544094834502552;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5408295445477387942) ) ) {
                      result[0] += 0.027764551500625897;
                    } else {
                      result[0] += -0.05911075249420792;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8850000000000001199) ) ) {
                  result[0] += 0.06171592187538239;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9489432019355409365) ) ) {
                    result[0] += -0.022622339077647304;
                  } else {
                    result[0] += 0.051281401471869305;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8656623263713588701) ) ) {
                if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7428946460663085061) ) ) {
                  result[0] += -0.049640298026879054;
                } else {
                  result[0] += 0.006417004751645988;
                }
              } else {
                result[0] += 0.05040305865088727;
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8885612913813883962) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9365641052798755473) ) ) {
        result[0] += 0.05901951551660204;
      } else {
        result[0] += -0.0258667519031666;
      }
    } else {
      result[0] += 0.09682557788147267;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7886110426559866937) ) ) {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2594714022927627761) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1264739246323610955) ) ) {
        result[0] += -0.10649071007215771;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          result[0] += 0.006856655634121675;
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01914950000000000332) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1648748129300160736) ) ) {
              result[0] += -0.08970426967673986;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01500000000000000118) ) ) {
                result[0] += 0.06061419112017729;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6495878606783920262) ) ) {
                  result[0] += -0.08117520029784094;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6800105846231156992) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6690536170100503943) ) ) {
                      result[0] += 0.005497170322205925;
                    } else {
                      result[0] += 0.215809219624377;
                    }
                  } else {
                    result[0] += -0.046759966447988674;
                  }
                }
              }
            }
          } else {
            result[0] += -0.1071675839318488;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5074134513786895395) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3850000000000000644) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8066186623115578769) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1520895000000000163) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3516558051256281625) ) ) {
                  result[0] += 0.02321282430708116;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3550761912678883081) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3212986210119083141) ) ) {
                      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.08246602501114344563) ) ) {
                        result[0] += -0.07174631624988996;
                      } else {
                        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2401159284727943655) ) ) {
                          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4835577767624377743) ) ) {
                            result[0] += -0.021179032359397568;
                          } else {
                            result[0] += 0.04807258983867821;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5596867406532665123) ) ) {
                            result[0] += -0.07563995464592985;
                          } else {
                            result[0] += 0.009628427611923432;
                          }
                        }
                      }
                    } else {
                      result[0] += -0.10742617657363217;
                    }
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6413622072216433878) ) ) {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5414516959754441805) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3880603600537617104) ) ) {
                          result[0] += 0.062206413777500774;
                        } else {
                          result[0] += -0.02594434480295294;
                        }
                      } else {
                        result[0] += 0.04636782279306959;
                      }
                    } else {
                      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1050000000000000239) ) ) {
                        result[0] += 0.047251019368559743;
                      } else {
                        result[0] += -0.042262484388024775;
                      }
                    }
                  }
                }
              } else {
                result[0] += 0.062155124344315665;
              }
            } else {
              result[0] += 0.08607168778409892;
            }
          } else {
            result[0] += -0.08078619649746858;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002579500000000000629) ) ) {
            result[0] += -0.0686936431184994;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01570900000000000421) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4750000000000000333) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6357510373366835887) ) ) {
                  result[0] += -0.018880947617543636;
                } else {
                  result[0] += 0.09962568259359339;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4543436058534389699) ) ) {
                  result[0] += -0.09932335894382248;
                } else {
                  result[0] += 0.001978062586003772;
                }
              }
            } else {
              result[0] += -0.06765244053466597;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9012786453690170285) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
            result[0] += 0.03341534238268747;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3133790000000000187) ) ) {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.7808520422368410152) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7150000000000000799) ) ) {
                  result[0] += -0.05616198173522215;
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9250000000000001554) ) ) {
                    result[0] += 0.015397844711532958;
                  } else {
                    result[0] += -0.03480606196662021;
                  }
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7533254900202764892) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3950000000000000733) ) ) {
                      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3150000000000000577) ) ) {
                        result[0] += 0.016581750106119578;
                      } else {
                        result[0] += -0.03968448352366728;
                      }
                    } else {
                      result[0] += 0.051256663280026926;
                    }
                  } else {
                    result[0] += -0.004405732555735845;
                  }
                } else {
                  result[0] += 0.005249364296166045;
                }
              }
            } else {
              result[0] += 0.04619627440602617;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9926756629642237151) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9550000000000000711) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9782915297286400858) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6136635367587940371) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1563578712213921917) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8244779839641466213) ) ) {
                      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6448546879214981375) ) ) {
                        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9650000000000000799) ) ) {
                          result[0] += 0.019697614693385695;
                        } else {
                          result[0] += -0.052459014281503256;
                        }
                      } else {
                        result[0] += 0.03199017046416171;
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.957819238479632129) ) ) {
                        result[0] += -0.09338569539252227;
                      } else {
                        result[0] += 0.011646787781632311;
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.779675844177816324) ) ) {
                      result[0] += -0.06199407817554047;
                    } else {
                      result[0] += 0.0209794024089664;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8412950649051146312) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6722423356281408413) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6532207681155780543) ) ) {
                        result[0] += 0.05080053353262099;
                      } else {
                        result[0] += -0.012901655352750145;
                      }
                    } else {
                      result[0] += 0.09304675037117331;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.810288705703517631) ) ) {
                      result[0] += -0.02612203143580162;
                    } else {
                      result[0] += 0.06250467983371998;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06864850000000001506) ) ) {
                  result[0] += 0.10822679948733699;
                } else {
                  result[0] += -0.0027683431763879836;
                }
              }
            } else {
              result[0] += -0.022471779618549723;
            }
          } else {
            result[0] += 0.07733702661132011;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9192198075050025396) ) ) {
      result[0] += 0.055662674601772634;
    } else {
      result[0] += 0.09895069217764753;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7948589598137713041) ) ) {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2594714022927627761) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1264739246323610955) ) ) {
        result[0] += -0.1054946347827501;
      } else {
        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3103100527046326884) ) ) {
          if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4349340187803038549) ) ) {
            result[0] += -0.07777810248996181;
          } else {
            result[0] += 0.08102841012151309;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0003835000000000000518) ) ) {
            result[0] += -0.03571713597853253;
          } else {
            result[0] += -0.08254454205699746;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4745913233539262865) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3950000000000000733) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8335990401005025641) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.321871344966293327) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3550761912678883081) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3212986210119083141) ) ) {
                  result[0] += -0.022262708996047452;
                } else {
                  result[0] += -0.1148446449595;
                }
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6413622072216433878) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3880603600537617104) ) ) {
                    result[0] += 0.0802148189119877;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6722423356281408413) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4312690111265354842) ) ) {
                        result[0] += -0.033277327510159646;
                      } else {
                        result[0] += 0.03611878488308701;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6830670752763819964) ) ) {
                        result[0] += 0.08745463348520506;
                      } else {
                        result[0] += 0.004588149308388789;
                      }
                    }
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8066186623115578769) ) ) {
                    result[0] += -0.03715779908096872;
                  } else {
                    result[0] += 0.05095634620077851;
                  }
                }
              }
            } else {
              result[0] += 0.09216870600361222;
            }
          } else {
            result[0] += -0.07822098949522147;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003305000000000000212) ) ) {
            result[0] += -0.08011180890938632;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00553950000000000102) ) ) {
              result[0] += 0.05976212734025653;
            } else {
              result[0] += -0.05819512709595696;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6166435351279918597) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
            result[0] += 0.04119250247713081;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3998546246231156065) ) ) {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5512903277935053969) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.569998760738014143) ) ) {
                  result[0] += -0.01640704527169959;
                } else {
                  result[0] += -0.07466001620299885;
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00414650000000000088) ) ) {
                  result[0] += 0.04489050626658847;
                } else {
                  result[0] += -0.0157473713751313;
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2050000000000000433) ) ) {
                result[0] += 0.04129941690779926;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5837974670096922614) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08212050000000001293) ) ) {
                    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2803498254930153477) ) ) {
                      if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2450759342279490716) ) ) {
                        result[0] += -0.04138999346028766;
                      } else {
                        result[0] += 0.012407120242819153;
                      }
                    } else {
                      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4296048346231156057) ) ) {
                        result[0] += 0.04231204964566553;
                      } else {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0007085000000000000369) ) ) {
                          result[0] += -0.055568095465951366;
                        } else {
                          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4868404241646586694) ) ) {
                            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.009014249010710599294) ) ) {
                              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6050000000000000933) ) ) {
                                if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1044543990012605922) ) ) {
                                  result[0] += -0.041298736084767224;
                                } else {
                                  result[0] += 0.018163484338337726;
                                }
                              } else {
                                result[0] += 0.05262757221154218;
                              }
                            } else {
                              result[0] += -0.04117338168577377;
                            }
                          } else {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6947584613372143059) ) ) {
                              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7077536600502513098) ) ) {
                                result[0] += 0.006638214886963263;
                              } else {
                                result[0] += 0.10683855207084375;
                              }
                            } else {
                              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00251250000000000041) ) ) {
                                result[0] += 0.02892935877591474;
                              } else {
                                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5479721254819260867) ) ) {
                                  result[0] += -0.07390894331928365;
                                } else {
                                  result[0] += -0.003395637773427026;
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  } else {
                    result[0] += -0.05957019546736264;
                  }
                } else {
                  result[0] += 0.0013530689731454646;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0006595000000000000384) ) ) {
            result[0] += -0.02003619829077561;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9812133206808532071) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8244779839641466213) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8412950649051146312) ) ) {
                  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6817186019653541651) ) ) {
                    result[0] += 0.014000592353721286;
                  } else {
                    result[0] += 0.036647330624104274;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01081750000000000246) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8097549183589626276) ) ) {
                      result[0] += -0.028729706979995863;
                    } else {
                      result[0] += 0.051253218336380635;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7894192122613066243) ) ) {
                      result[0] += -0.07707111650867594;
                    } else {
                      result[0] += 0.011651060503262896;
                    }
                  }
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9450000000000000622) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.957819238479632129) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9433039335395834168) ) ) {
                      result[0] += 0.01651197220479492;
                    } else {
                      result[0] += -0.08967920284183639;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.969118636771319486) ) ) {
                      result[0] += 0.0932512995606356;
                    } else {
                      result[0] += -0.021566591243661313;
                    }
                  }
                } else {
                  result[0] += -0.0748110606457428;
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8425868168358437993) ) ) {
                result[0] += 0.0876934344650815;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04426400000000000473) ) ) {
                  result[0] += 0.06633569889784648;
                } else {
                  result[0] += -0.016541570972476168;
                }
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9192198075050025396) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9642541403912111564) ) ) {
        result[0] += 0.056587610085784466;
      } else {
        result[0] += -0.04800172683711714;
      }
    } else {
      result[0] += 0.09708068507083091;
    }
  }
}

