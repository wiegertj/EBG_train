
#include "header.h"

void predict_unit8(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6817186019653541651) ) ) {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3421306008459473191) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1264739246323610955) ) ) {
        result[0] += -0.11222565137737031;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.07741213185323393697) ) ) {
            result[0] += 0.07116601258311044;
          } else {
            result[0] += -0.03790420486747714;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2287126979501296342) ) ) {
            result[0] += -0.0900367376883554;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.500000000000000283e-05) ) ) {
              result[0] += -0.03962456291492175;
            } else {
              result[0] += -0.07066805086972065;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5706302127189432083) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6277403467108452206) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5905554680737284956) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1455465000000000508) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                result[0] += -0.010468426078631087;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003305000000000000212) ) ) {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.7382441423073401454) ) ) {
                    result[0] += 0.014652825152566138;
                  } else {
                    result[0] += -0.056376738253107975;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4835577767624377743) ) ) {
                    result[0] += -0.03557341740986886;
                  } else {
                    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2640832024083091256) ) ) {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3050000000000000488) ) ) {
                        result[0] += 0.06457316787327029;
                      } else {
                        result[0] += -0.02556372601820204;
                      }
                    } else {
                      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4050000000000000822) ) ) {
                        result[0] += -0.04461040962456478;
                      } else {
                        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02122450000000000378) ) ) {
                          result[0] += -0.02070130502839931;
                        } else {
                          result[0] += 0.05693983974378749;
                        }
                      }
                    }
                  }
                }
              }
            } else {
              result[0] += 0.08291587716856036;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002268500000000000551) ) ) {
              result[0] += -0.000953421394734641;
            } else {
              result[0] += 0.16542633073705118;
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8706992593517899337) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3547641043686024509) ) ) {
              result[0] += -0.0796231177621342;
            } else {
              result[0] += -0.024684346614980143;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7290383838442212605) ) ) {
              result[0] += 0.05558277169903715;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01632150000000000267) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5350000000000001421) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.435648018856219732) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.264417267085903962) ) ) {
                      result[0] += -0.0768966485156386;
                    } else {
                      result[0] += 0.03342725223205296;
                    }
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.051391296366422923) ) ) {
                      result[0] += 0.09232155582807886;
                    } else {
                      result[0] += -0.014924887434277867;
                    }
                  }
                } else {
                  result[0] += -0.0633976306543918;
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5950000000000000844) ) ) {
                  result[0] += -0.08524797541387436;
                } else {
                  result[0] += -0.005008853349371659;
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8097549183589626276) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6930953257568631676) ) ) {
            result[0] += -0.005869147712781509;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              result[0] += 0.0331927801961448;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.7150000000000000799) ) ) {
                if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3895596163096332609) ) ) {
                  result[0] += 0.03073539828214405;
                } else {
                  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4163018469253235154) ) ) {
                    result[0] += -0.021746104865065258;
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5150000000000001243) ) ) {
                      result[0] += 0.026985046620724318;
                    } else {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002376500000000000574) ) ) {
                          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1296381427427941713) ) ) {
                            result[0] += 0.006734449915729982;
                          } else {
                            result[0] += -0.030079798653537913;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5910501547487437835) ) ) {
                            result[0] += -0.004755483461240111;
                          } else {
                            result[0] += 0.01511531936865561;
                          }
                        }
                      } else {
                        result[0] += 0.016386534258119104;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.024399000074066524;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9650496265483141656) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.5708656043828381765) ) ) {
              if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.6505320650523345183) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9650000000000000799) ) ) {
                  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5512903277935053969) ) ) {
                    result[0] += 0.005127343740546924;
                  } else {
                    result[0] += 0.07554749905847777;
                  }
                } else {
                  result[0] += -0.028212589799096344;
                }
              } else {
                result[0] += -0.0805015536246246;
              }
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4008331129359999911) ) ) {
                result[0] += 0.04890816610920613;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8054659791206031372) ) ) {
                  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6166435351279918597) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6682476845983925662) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8919887641194863548) ) ) {
                        result[0] += 0.005559913585562238;
                      } else {
                        result[0] += 0.058527960228533155;
                      }
                    } else {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01257550000000000161) ) ) {
                        result[0] += -0.062157168737103516;
                      } else {
                        result[0] += 0.006116129714828685;
                      }
                    }
                  } else {
                    result[0] += 0.023229661042825218;
                  }
                } else {
                  result[0] += 0.04808588932272967;
                }
              }
            }
          } else {
            result[0] += 0.07085195370472978;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8425494434324883875) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7428946460663085061) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8131644532706052697) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7969182508153497269) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8706992593517899337) ) ) {
              result[0] += 0.0454023943605154;
            } else {
              result[0] += -0.015438972781911604;
            }
          } else {
            result[0] += 0.08563404634236942;
          }
        } else {
          result[0] += -0.01625610978880862;
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9011425554234714363) ) ) {
          result[0] += 0.06733907470019229;
        } else {
          result[0] += -0.0028034946867618355;
        }
      }
    } else {
      result[0] += 0.10327168523354893;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7073687287159498016) ) ) {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3421306008459473191) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1264739246323610955) ) ) {
        result[0] += -0.11147809445281655;
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3516558051256281625) ) ) {
          result[0] += 0.04434377275664447;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0003835000000000000518) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.08084834963689506437) ) ) {
              result[0] += -0.07185222763417912;
            } else {
              result[0] += -0.03536746836537445;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7418777389447237525) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7342470301758795559) ) ) {
                result[0] += -0.07072380505042522;
              } else {
                result[0] += 0.06333360514421044;
              }
            } else {
              result[0] += -0.10761008578518097;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.609385253452748854) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.488788166690373338) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1350000000000000366) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1659701101988258487) ) ) {
              result[0] += 0.08478523712073154;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4084589752883884817) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01542950000000000051) ) ) {
                  result[0] += 0.01472627700692382;
                } else {
                  result[0] += -0.06925704013635962;
                }
              } else {
                result[0] += 0.012865821672739895;
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3550761912678883081) ) ) {
                result[0] += -0.04155586013951524;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6413622072216433878) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5664498681879840403) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6384764007788945595) ) ) {
                      result[0] += 0.058900450904565284;
                    } else {
                      result[0] += -0.040070131872088015;
                    }
                  } else {
                    result[0] += 0.06325511136374434;
                  }
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0008475000000000000545) ) ) {
                    result[0] += -0.01124655303334148;
                  } else {
                    result[0] += -0.0611270202743221;
                  }
                }
              }
            } else {
              result[0] += -0.059582846806326806;
            }
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.330342879382321819) ) ) {
            result[0] += 1.0638220235058257e-05;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5158858854430460328) ) ) {
              result[0] += -0.05485306279252968;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4296048346231156057) ) ) {
                if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.5496867966949329221) ) ) {
                  result[0] += -0.02195173769148153;
                } else {
                  result[0] += 0.04899885138060126;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4540110673869346969) ) ) {
                  result[0] += -0.06890824722747216;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003380500000000000258) ) ) {
                      result[0] += -0.04372268541759532;
                    } else {
                      result[0] += 0.0378363793489252;
                    }
                  } else {
                    result[0] += -0.021847165638060113;
                  }
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8419751086149712682) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001103500000000000097) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4286491250720794177) ) ) {
                  result[0] += -0.007869537582765542;
                } else {
                  result[0] += 0.042278850771659444;
                }
              } else {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.5708656043828381765) ) ) {
                  result[0] += 0.013633842070553025;
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8550000000000000933) ) ) {
                    result[0] += -0.06162998584360465;
                  } else {
                    result[0] += -0.013039434331001076;
                  }
                }
              }
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.7808520422368410152) ) ) {
                result[0] += -0.023920761688758382;
              } else {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2044121788183031196) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4578754035427136104) ) ) {
                    if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4627502129294571165) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4050764352261307377) ) ) {
                        result[0] += 0.004613071355012035;
                      } else {
                        result[0] += 0.05755041510763609;
                      }
                    } else {
                      result[0] += -0.020650089957687235;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4798028910050251561) ) ) {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006556500000000000695) ) ) {
                        result[0] += 0.015905930870345864;
                      } else {
                        result[0] += 0.08394494457658622;
                      }
                    } else {
                      result[0] += 0.002218167786270868;
                    }
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4975581368341708832) ) ) {
                    if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1341510627350609164) ) ) {
                      result[0] += -0.08007782576923192;
                    } else {
                      result[0] += -0.014482379147514652;
                    }
                  } else {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4365950629658605364) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6883894843299426247) ) ) {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01732650000000000509) ) ) {
                          result[0] += 0.04848814971271874;
                        } else {
                          result[0] += 0;
                        }
                      } else {
                        result[0] += 0.06282231966918563;
                      }
                    } else {
                      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3939024948053188036) ) ) {
                        result[0] += -0.03262720521720367;
                      } else {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8158067323869347964) ) ) {
                          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7295070658487954329) ) ) {
                            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6975240073869347635) ) ) {
                              result[0] += 0.0002623660636911518;
                            } else {
                              result[0] += 0.051537241587839816;
                            }
                          } else {
                            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8687344252564519476) ) ) {
                              result[0] += -0.048638070424107345;
                            } else {
                              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.126853541778489509) ) ) {
                                result[0] += 0.014013731848429127;
                              } else {
                                result[0] += -0.044395041694772805;
                              }
                            }
                          }
                        } else {
                          result[0] += 0.0283876549466375;
                        }
                      }
                    }
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0004535000000000000728) ) ) {
              result[0] += 0.04962867863721521;
            } else {
              result[0] += 0.008106741593731596;
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0006595000000000000384) ) ) {
            result[0] += -0.031757541282623265;
          } else {
            result[0] += 0.021230468052232807;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8425494434324883875) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9011425554234714363) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7948589598137713041) ) ) {
          result[0] += 0.04530595147433589;
        } else {
          result[0] += 0.0792963573777792;
        }
      } else {
        result[0] += -0.0024831258037285218;
      }
    } else {
      result[0] += 0.10128808581163933;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7360390231494754465) ) ) {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3421306008459473191) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1264739246323610955) ) ) {
        result[0] += -0.11072131440502894;
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.07741213185323393697) ) ) {
            result[0] += 0.06854142528922268;
          } else {
            result[0] += -0.028965970577976796;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2287126979501296342) ) ) {
            result[0] += -0.0850874840797003;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.500000000000000283e-05) ) ) {
              result[0] += -0.03341514099698178;
            } else {
              result[0] += -0.06333709047699913;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6595171046238990087) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4745913233539262865) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1350000000000000366) ) ) {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1222989441515451026) ) ) {
                result[0] += 0.08451685952016123;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01732650000000000509) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3762224391645417332) ) ) {
                    result[0] += -0.011518362730775432;
                  } else {
                    result[0] += 0.09088160008017934;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4184709742968573676) ) ) {
                    result[0] += -0.06388341682361605;
                  } else {
                    result[0] += 0.007144342616463383;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3550761912678883081) ) ) {
                result[0] += -0.04015082604526062;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6277403467108452206) ) ) {
                  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1638580212314850182) ) ) {
                    result[0] += -0.03920227550014469;
                  } else {
                    result[0] += 0.04508750014737798;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.435648018856219732) ) ) {
                    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2050000000000000433) ) ) {
                      result[0] += 0.0008415126660744717;
                    } else {
                      result[0] += -0.07601498485533144;
                    }
                  } else {
                    result[0] += 0;
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001407500000000000114) ) ) {
              result[0] += -0.10117539272892577;
            } else {
              result[0] += -0.0491623481938031;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2422035000000000438) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.179099372612799401) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.039291117014028876) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9808239647505231362) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7665928407035177417) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7254919443713668814) ) ) {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5681735652491761712) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6800105846231156992) ) ) {
                          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5250000000000001332) ) ) {
                            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5150000000000001243) ) ) {
                              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8250000000000000666) ) ) {
                                result[0] += -0.011637692527620891;
                              } else {
                                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001771500000000000288) ) ) {
                                  result[0] += -0.018258536483047302;
                                } else {
                                  result[0] += 0.06347522414050656;
                                }
                              }
                            } else {
                              result[0] += 0.04894203114238767;
                            }
                          } else {
                            result[0] += -0.03643073633561818;
                          }
                        } else {
                          result[0] += -0.06542145011647889;
                        }
                      } else {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001734500000000000148) ) ) {
                          result[0] += -0.03144512665362883;
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6975240073869347635) ) ) {
                            result[0] += 0.0067197651754566;
                          } else {
                            result[0] += 0.0980288927288977;
                          }
                        }
                      }
                    } else {
                      result[0] += -0.03512624646602557;
                    }
                  } else {
                    result[0] += 0.061496658332278374;
                  }
                } else {
                  result[0] += -0.07398562018913485;
                }
              } else {
                result[0] += 0.034733658930033155;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002169500000000000421) ) ) {
                result[0] += -0.0007381054227945361;
              } else {
                result[0] += -0.06193761767631425;
              }
            }
          } else {
            result[0] += 0.05210827198963572;
          }
        }
      } else {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6448546879214981375) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-1.143279903388985774) ) ) {
            result[0] += 0.04109540501715047;
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.7808520422368410152) ) ) {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5512903277935053969) ) ) {
                result[0] += -0.05043708570219335;
              } else {
                result[0] += 0.004366668579295256;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9181645509592420984) ) ) {
                result[0] += 0.0037655621453756994;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5499504253266332965) ) ) {
                  if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.07218104077152019682) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4510887735175879709) ) ) {
                      result[0] += -0.00460399633107255;
                    } else {
                      result[0] += 0.0625174641607123;
                    }
                  } else {
                    result[0] += -0.03605924611531178;
                  }
                } else {
                  result[0] += 0.08811526358887495;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9150000000000001465) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9460446167939123852) ) ) {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.6505320650523345183) ) ) {
                result[0] += -0.036058911653305575;
              } else {
                result[0] += 0.029400387440034308;
              }
            } else {
              result[0] += 0.05546776524527086;
            }
          } else {
            result[0] += -0.027536410660883526;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8679983746857627969) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9252741217513053007) ) ) {
        result[0] += 0.1126285912048602;
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7570612716642158846) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9489432019355409365) ) ) {
            result[0] += -0.04292128806027186;
          } else {
            result[0] += 0.04237059538755559;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01458150000000000245) ) ) {
              result[0] += 0.03615329780423496;
            } else {
              result[0] += 0.10991094953581969;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9011425554234714363) ) ) {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7948589598137713041) ) ) {
                result[0] += 0.029065756033196576;
              } else {
                result[0] += 0.07650310666363155;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01279200000000000129) ) ) {
                result[0] += -0.067950768696379;
              } else {
                if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8425494434324883875) ) ) {
                  result[0] += -0.0022080192568738957;
                } else {
                  result[0] += 0.08637786685321681;
                }
              }
            }
          }
        }
      }
    } else {
      result[0] += 0.10192329378750717;
    }
  }
}

