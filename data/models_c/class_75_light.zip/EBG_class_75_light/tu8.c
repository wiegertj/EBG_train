
#include "header.h"

void predict_unit8(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9461509352790128391) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
      result[0] += 0.00016871535515354508;
    } else {
      result[0] += -0.08949687808389842;
    }
  } else {
    result[0] += 0.10829581782268279;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7472528898492464267) ) ) {
    result[0] += 0.0023427386265317375;
  } else {
    if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.4438143055178486174) ) ) {
      result[0] += -0.050856028342915305;
    } else {
      result[0] += 0.00263857347358214;
    }
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.04830892724354553247) ) ) {
    result[0] += -0.1333470715429533;
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0.11583941406973806;
    } else {
      result[0] += -0.00013012227840902962;
    }
  }
  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
    result[0] += 0.016040929870193288;
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0006705000000000001974) ) ) {
      result[0] += -0.05418603796687678;
    } else {
      result[0] += 0.0008699381033530166;
    }
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4639489995477387718) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4578754035427136104) ) ) {
      result[0] += 0.004544858563466859;
    } else {
      result[0] += 0.09812433850766757;
    }
  } else {
    result[0] += -0.0028890377393801605;
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2912453567552589773) ) ) {
    result[0] += -0.031731882714674586;
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05500000000000000722) ) ) {
      result[0] += 0.20866147111943958;
    } else {
      result[0] += 0.0005785087626726674;
    }
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8334476520903483232) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9450000000000000622) ) ) {
      result[0] += 0.00034368028261509833;
    } else {
      result[0] += -0.0852066938999701;
    }
  } else {
    result[0] += 0.04412028040713498;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8003917757139223932) ) ) {
    result[0] += -0.0012852586568349576;
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8850000000000001199) ) ) {
      result[0] += 0.08741978241432029;
    } else {
      result[0] += 0.005014867351421499;
    }
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)19.50000000000000355) ) ) {
    result[0] += -0.011887894768790245;
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03633212927717290736) ) ) {
      result[0] += -0.0020602510100792863;
    } else {
      result[0] += 0.021648276811540752;
    }
  }
  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.211360663335670829) ) ) {
    result[0] += 0.06896798769879656;
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5948062062845668185) ) ) {
      result[0] += -0.003571881980988355;
    } else {
      result[0] += 0.008920150391369452;
    }
  }
}

