
#include "header.h"

void predict_unit8(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8409680707237645603) ) ) {
    result[0] += -0.002910722049535138;
  } else {
    result[0] += 0.047416647904240335;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1601111865813344692) ) ) {
    result[0] += -0.05171671460087803;
  } else {
    result[0] += 0.0026121539328648837;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.552160855807795059) ) ) {
    result[0] += -0.020101688692635476;
  } else {
    result[0] += 0.006488942186541106;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8409680707237645603) ) ) {
    result[0] += -0.0027468457389408464;
  } else {
    result[0] += 0.046823035678371545;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1601111865813344692) ) ) {
    result[0] += -0.051294142507586515;
  } else {
    result[0] += 0.0024271288371371545;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8409680707237645603) ) ) {
    result[0] += -0.0025978637914593765;
  } else {
    result[0] += 0.04628606070376167;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1601111865813344692) ) ) {
    result[0] += -0.05097692817722137;
  } else {
    result[0] += 0.002296829530324674;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8913157355287062433) ) ) {
    result[0] += -0.004796325735926478;
  } else {
    result[0] += 0.023434710361185634;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1601111865813344692) ) ) {
    result[0] += -0.05063712792256843;
  } else {
    result[0] += 0.0021711711943854612;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8409680707237645603) ) ) {
    result[0] += -0.0023953300410134433;
  } else {
    result[0] += 0.04543956087880775;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4468288327365124712) ) ) {
    result[0] += -0.025171120364627923;
  } else {
    result[0] += 0.00411376839856352;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8744693154915333944) ) ) {
    result[0] += -0.002133794429900903;
  } else {
    result[0] += 0.047835931549924736;
  }
}

