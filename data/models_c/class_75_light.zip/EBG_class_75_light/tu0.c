
#include "header.h"

void predict_unit0(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7496545877835433247) ) ) {
    result[0] += -0.5094971278378833;
  } else {
    result[0] += -0.32236908708538714;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7216438171523466005) ) ) {
    result[0] += -0.07093714411551465;
  } else {
    result[0] += 0.10319344739476664;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.763899292613795855) ) ) {
    result[0] += -0.06406930564451116;
  } else {
    result[0] += 0.10285586588709586;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6993194146685618451) ) ) {
    result[0] += -0.06797024384412438;
  } else {
    result[0] += 0.08811039111182792;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7453151484221520739) ) ) {
    result[0] += -0.06165527594459917;
  } else {
    result[0] += 0.08849636620716742;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6993194146685618451) ) ) {
    result[0] += -0.06374963766441882;
  } else {
    result[0] += 0.07869432729711869;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7882210659741740733) ) ) {
    result[0] += -0.05406428958704942;
  } else {
    result[0] += 0.0858931883011127;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6758763504016677137) ) ) {
    result[0] += -0.06212717203026949;
  } else {
    result[0] += 0.06924496539944545;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7689455063939686363) ) ) {
    result[0] += -0.05254937893401771;
  } else {
    result[0] += 0.07619912759314335;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6758763504016677137) ) ) {
    result[0] += -0.05888956436909081;
  } else {
    result[0] += 0.06343808291312486;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8138751446832469538) ) ) {
    result[0] += -0.046255649162431765;
  } else {
    result[0] += 0.07618634470213434;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6442316866273317677) ) ) {
    result[0] += -0.05866014966159545;
  } else {
    result[0] += 0.05629583376526976;
  }
}

