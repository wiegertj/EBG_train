
#include "header.h"

void predict_unit0(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7434398242901157916) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5891834603033582196) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4312690111265354842) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2594714022927627761) ) ) {
          result[0] += -0.6495794807231515;
        } else {
          result[0] += -0.6344310256365537;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5158858854430460328) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2463909746624610153) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1650000000000000355) ) ) {
              result[0] += -0.5554872807608346;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4286491250720794177) ) ) {
                result[0] += -0.6079224347430248;
              } else {
                result[0] += -0.5696105340717835;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005215500000000000518) ) ) {
              result[0] += -0.6326867945717544;
            } else {
              result[0] += -0.6144600037226946;
            }
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2969699150759821382) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5630794848414941711) ) ) {
              result[0] += -0.5710098430714494;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
                result[0] += -0.4802338891981578;
              } else {
                result[0] += -0.5466006693240115;
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002169500000000000421) ) ) {
              result[0] += -0.6234476545070614;
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2044121788183031196) ) ) {
                result[0] += -0.5654154981746817;
              } else {
                result[0] += -0.599960839250735;
              }
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7027407489895624026) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4365950629658605364) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6542990130851055186) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.09893965937729458371) ) ) {
              result[0] += -0.5409178679291633;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.609385253452748854) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.545000000000000151) ) ) {
                  result[0] += -0.5064778047900754;
                } else {
                  result[0] += -0.5807575279301317;
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01667900000000000285) ) ) {
                  result[0] += -0.45053366962919633;
                } else {
                  result[0] += -0.5088414966348388;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5499504253266332965) ) ) {
              result[0] += -0.48006220677682415;
            } else {
              result[0] += -0.4132564362568464;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6595171046238990087) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.625846821573829204) ) ) {
              result[0] += -0.586302956980164;
            } else {
              result[0] += -0.5514204044099974;
            }
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2252565153835193457) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4050764352261307377) ) ) {
                result[0] += -0.5317680937421235;
              } else {
                result[0] += -0.46563624380869395;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7650000000000001243) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3680411812697468865) ) ) {
                  result[0] += -0.5332220282592833;
                } else {
                  result[0] += -0.4733432713653972;
                }
              } else {
                result[0] += -0.5392498746425882;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8350000000000000755) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4296048346231156057) ) ) {
            result[0] += -0.47567822736212717;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4750000000000000333) ) ) {
              result[0] += -0.37880200964533495;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01807250000000000176) ) ) {
                if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4603009969540775015) ) ) {
                  result[0] += -0.37284857456385095;
                } else {
                  result[0] += -0.42688189030262225;
                }
              } else {
                result[0] += -0.4466485788374168;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
            result[0] += -0.4729199778830289;
          } else {
            result[0] += -0.4262309969346092;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8647856135106589681) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7803107051370604674) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.495865834604893696) ) ) {
          result[0] += -0.3599806305857174;
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5357696120088285552) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5364037024921902708) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5424744603768845153) ) ) {
                result[0] += -0.4294239882599596;
              } else {
                result[0] += -0.3745026819233682;
              }
            } else {
              result[0] += -0.4473623689292261;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6550000000000001377) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6325627761016606732) ) ) {
                result[0] += -0.3470505488102026;
              } else {
                result[0] += -0.40742934202226083;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7669558640352696077) ) ) {
                result[0] += -0.44659429920299526;
              } else {
                result[0] += -0.3956639909473397;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8419751086149712682) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7995887825305768581) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9650000000000000799) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6650000000000001465) ) ) {
                result[0] += -0.34796997326480494;
              } else {
                result[0] += -0.3963665871995402;
              }
            } else {
              result[0] += -0.33030451765760127;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5943075033919599237) ) ) {
              result[0] += -0.33281584658396557;
            } else {
              result[0] += -0.30461843611210593;
            }
          }
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6448546879214981375) ) ) {
            result[0] += -0.3026438922742506;
          } else {
            result[0] += -0.2491693299136387;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7073687287159498016) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8919887641194863548) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6920444846418339901) ) ) {
            result[0] += -0.2842750951776615;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
              result[0] += -0.2754815610575794;
            } else {
              result[0] += -0.22153347743406113;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8950000000000001288) ) ) {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6817186019653541651) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9433039335395834168) ) ) {
                result[0] += -0.24329552895395942;
              } else {
                result[0] += -0.2135476713052944;
              }
            } else {
              result[0] += -0.2081570834731934;
            }
          } else {
            result[0] += -0.2691886298523942;
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7948589598137713041) ) ) {
          result[0] += -0.20161140805479222;
        } else {
          result[0] += -0.17972829639978832;
        }
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7390680933680099374) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5891834603033582196) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4312690111265354842) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2594714022927627761) ) ) {
          result[0] += -0.1691075693131168;
        } else {
          result[0] += -0.15418082772742783;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5158858854430460328) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2463909746624610153) ) ) {
            result[0] += -0.1081172230801435;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005215500000000000518) ) ) {
              result[0] += -0.1524751609449992;
            } else {
              result[0] += -0.13474644752487588;
            }
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2969699150759821382) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5630794848414941711) ) ) {
              result[0] += -0.0933480208570787;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
                result[0] += -0.010301031349136916;
              } else {
                result[0] += -0.07060185473728012;
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002169500000000000421) ) ) {
              result[0] += -0.14346271756882312;
            } else {
              result[0] += -0.11573072137991104;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7027407489895624026) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4365950629658605364) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6542990130851055186) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7761411562060303027) ) ) {
              result[0] += -0.04267778693345461;
            } else {
              result[0] += -0.08424370222515867;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5499504253266332965) ) ) {
              result[0] += -0.01014641104718879;
            } else {
              result[0] += 0.04855613315574652;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6495638603084151752) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.625846821573829204) ) ) {
              result[0] += -0.10778826347660828;
            } else {
              result[0] += -0.0774948950555786;
            }
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2252565153835193457) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4050764352261307377) ) ) {
                result[0] += -0.05984712855955096;
              } else {
                result[0] += -0.0022101548022989853;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7850000000000001421) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5499504253266332965) ) ) {
                  result[0] += -0.0810829887354884;
                } else {
                  result[0] += -0.021510074346646944;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6647067832505478835) ) ) {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5061086725526010577) ) ) {
                    result[0] += -0.06518958535306953;
                  } else {
                    result[0] += -0.12316504826050083;
                  }
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8450000000000000844) ) ) {
                    result[0] += -0.09299073182544663;
                  } else {
                    result[0] += -0.048476650912929076;
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4850000000000000422) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.52572947701005035) ) ) {
            result[0] += 0.035916427912391;
          } else {
            result[0] += 0.09803832504511388;
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4435662465829146028) ) ) {
            result[0] += -0.04239443568621094;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8350000000000000755) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01807250000000000176) ) ) {
                result[0] += 0.05916743408394577;
              } else {
                result[0] += 0;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009307500000000001536) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6150000000000001021) ) ) {
                  result[0] += 0.046767276287000496;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.728792159352835367) ) ) {
                    result[0] += -0.024436344597754615;
                  } else {
                    result[0] += 0.03752669222956992;
                  }
                }
              } else {
                result[0] += -0.03781140265500627;
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8647856135106589681) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7803107051370604674) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5127811792069081331) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5485006052512563235) ) ) {
            result[0] += 0.10156337104615315;
          } else {
            result[0] += 0.04905302866352456;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9250000000000001554) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7624551761149250817) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0116525000000000014) ) ) {
                result[0] += 0.03318354307810279;
              } else {
                result[0] += -0.01422597083964404;
              }
            } else {
              result[0] += 0.049110570102016755;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001817500000000000322) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5424744603768845153) ) ) {
                result[0] += 0.07905289198853442;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00123550000000000027) ) ) {
                  result[0] += 0.042666243267236205;
                } else {
                  result[0] += -0.004707593400813919;
                }
              }
            } else {
              result[0] += 0.07622555865817755;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8143976568897295376) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6333994641870349662) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5292687537313297552) ) ) {
              result[0] += 0.13942973565091119;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001518500000000000101) ) ) {
                result[0] += 0.1251700269770978;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006281500000000001492) ) ) {
                  result[0] += 0.06718972663209642;
                } else {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6029117207677894275) ) ) {
                    result[0] += 0.077658404846392;
                  } else {
                    result[0] += 0.15176488521497278;
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.7150000000000000799) ) ) {
              result[0] += 0.16200716549202682;
            } else {
              result[0] += 0.09947852407787904;
            }
          }
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5916281412714844423) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6350000000000001199) ) ) {
              result[0] += 0.15235066974996977;
            } else {
              result[0] += 0.11787176552831466;
            }
          } else {
            result[0] += 0.15714706008897492;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7073687287159498016) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8919887641194863548) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7074086128998665624) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5414516959754441805) ) ) {
              result[0] += 0.15138466827533933;
            } else {
              result[0] += 0.2023611035695915;
            }
          } else {
            result[0] += 0.20347432922653066;
          }
        } else {
          result[0] += 0.20227873266947116;
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.824437516878408494) ) ) {
          result[0] += 0.2286966289925928;
        } else {
          result[0] += 0.24481214477173516;
        }
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.728792159352835367) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5593705952246232904) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.389828724245051994) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2287126979501296342) ) ) {
          result[0] += -0.1603967398708131;
        } else {
          result[0] += -0.14816576497570608;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5074134513786895395) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2093850713229825355) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4404146740571510121) ) ) {
                result[0] += -0.1267015782323982;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1650000000000000355) ) ) {
                  result[0] += -0.04909122281965991;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5414516959754441805) ) ) {
                    result[0] += -0.11405903652707389;
                  } else {
                    result[0] += -0.06310391251815572;
                  }
                }
              }
            } else {
              result[0] += -0.13343732159382668;
            }
          } else {
            result[0] += -0.14611558921227244;
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.284601935876013401) ) ) {
            result[0] += -0.08309154779181029;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2850000000000000866) ) ) {
              result[0] += -0.07943233531648274;
            } else {
              result[0] += -0.1271711874054062;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6647067832505478835) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3423741639027237382) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.25500000000000006) ) ) {
            result[0] += 0.008303666029772724;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5891834603033582196) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.339840807112446186) ) ) {
                result[0] += -0.04130805006881787;
              } else {
                result[0] += -0.09587171617138388;
              }
            } else {
              result[0] += -0.03711563625135241;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.625846821573829204) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5837974670096922614) ) ) {
              result[0] += -0.12558530772050838;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002317500000000000549) ) ) {
                result[0] += -0.11312059088592338;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7250000000000000888) ) ) {
                  result[0] += -0.05675439763223095;
                } else {
                  result[0] += -0.11413399136329318;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4365950629658605364) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5750000000000000666) ) ) {
                result[0] += -0.04265926115514099;
              } else {
                result[0] += 0.016347197811026247;
              }
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2263427529174017738) ) ) {
                result[0] += -0.03362211767103685;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1165587384072143268) ) ) {
                  result[0] += -0.1021827787744619;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001186500000000000271) ) ) {
                    result[0] += -0.09625131842314948;
                  } else {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007810500000000000602) ) ) {
                      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4603009969540775015) ) ) {
                        result[0] += -0.020034737203861494;
                      } else {
                        result[0] += -0.08378252544281599;
                      }
                    } else {
                      result[0] += -0.08786345183909411;
                    }
                  }
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7027407489895624026) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5150000000000001243) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5499504253266332965) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
                result[0] += 0.022575727111334955;
              } else {
                result[0] += -0.07056103564722417;
              }
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4509994370153290189) ) ) {
                result[0] += 0.053247103964501115;
              } else {
                result[0] += -0.011344319356961471;
              }
            }
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.392100875596731957) ) ) {
              result[0] += -0.009329466515453253;
            } else {
              result[0] += -0.05408347333464927;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6150000000000001021) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4850000000000000422) ) ) {
              result[0] += 0.055050213272211504;
            } else {
              result[0] += 0.01916079582426089;
            }
          } else {
            result[0] += -0.013868898892538428;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8608151046952775554) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7803107051370604674) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.495865834604893696) ) ) {
          result[0] += 0.07985216701024565;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0003835000000000000518) ) ) {
            result[0] += 0.08411995107688056;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7434398242901157916) ) ) {
              result[0] += 0.0115727665920306;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0007465000000000000932) ) ) {
                result[0] += 0.00022784470680884788;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007348500000000000865) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003584500000000000446) ) ) {
                    result[0] += 0.04541965866882154;
                  } else {
                    result[0] += 0.09031558386683236;
                  }
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6350000000000001199) ) ) {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5085715304020100858) ) ) {
                      result[0] += 0.011865041213841816;
                    } else {
                      result[0] += 0.060317551115042695;
                    }
                  } else {
                    result[0] += -0.0067386259466600835;
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8097549183589626276) ) ) {
          result[0] += 0.09231653059024385;
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5916281412714844423) ) ) {
            result[0] += 0.10729313890820853;
          } else {
            result[0] += 0.13357945050713485;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6817186019653541651) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8865421187835540451) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6257191263660338842) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.316132418552224348) ) ) {
              result[0] += 0.16322813720325122;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5051269755902706438) ) ) {
                result[0] += 0.09893562980702088;
              } else {
                result[0] += 0.1531611314683937;
              }
            }
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1885260224547289643) ) ) {
              result[0] += 0.12838183894117822;
            } else {
              result[0] += 0.18077033700144546;
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += 0.17823001211273018;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8450000000000000844) ) ) {
              result[0] += 0.17097425341530273;
            } else {
              result[0] += 0.11905322542267735;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7948589598137713041) ) ) {
          result[0] += 0.19598801401567212;
        } else {
          result[0] += 0.21476155608669587;
        }
      }
    }
  }
}

