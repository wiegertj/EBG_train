
#include "header.h"

void predict_unit0(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7529515601458559582) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5980109955351072815) ) ) {
      result[0] += -0.701069367782183;
    } else {
      result[0] += -0.5352493997039756;
    }
  } else {
    result[0] += -0.17577887893060207;
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7299022586947819802) ) ) {
    result[0] += -0.16953153636807936;
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6836319796734399157) ) ) {
      result[0] += 0.10708699339969098;
    } else {
      result[0] += 0.29389480163654086;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6970349770515457122) ) ) {
    result[0] += -0.1625125053886569;
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8509499269513369768) ) ) {
      result[0] += 0.07224681161047374;
    } else {
      result[0] += 0.24691654981490588;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7029198246082887236) ) ) {
    result[0] += -0.1490021421646683;
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6963312867293579567) ) ) {
      result[0] += 0.07443636568911745;
    } else {
      result[0] += 0.22418021446553868;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6592974275513777682) ) ) {
    result[0] += -0.14800747865367717;
  } else {
    if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.6517768074121382815) ) ) {
      result[0] += 0.060398551763286734;
    } else {
      result[0] += 0.20536769632973007;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6362738295916482434) ) ) {
    result[0] += -0.14340226354519123;
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8347011650282363249) ) ) {
      result[0] += 0.027629242861552838;
    } else {
      result[0] += 0.17926505123380918;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6312057726826117987) ) ) {
    result[0] += -0.13574336320467328;
  } else {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7317970066810598473) ) ) {
      result[0] += 0.04161759401865759;
    } else {
      result[0] += 0.18023970326110544;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.768757329094374664) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5187759295427522011) ) ) {
      result[0] += -0.14907913297434444;
    } else {
      result[0] += -0.00887329458495117;
    }
  } else {
    result[0] += 0.13784666659277328;
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5588608841523275972) ) ) {
    result[0] += -0.13512456971564482;
  } else {
    if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7602047080052889427) ) ) {
      result[0] += 0.024276967237744335;
    } else {
      result[0] += 0.16696154084444279;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7978340359715182517) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4506546428194125875) ) ) {
      result[0] += -0.14507633367473405;
    } else {
      result[0] += -0.015113735421084533;
    }
  } else {
    result[0] += 0.12802671440128618;
  }
}

