
#include "header.h"

void predict_unit3(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5230913149931778472) ) ) {
    result[0] += -0.045227439992647805;
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8814820726865898459) ) ) {
      result[0] += 0.006221960920857311;
    } else {
      result[0] += 0.1251528329287948;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8068863789163954747) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7472528898492464267) ) ) {
      result[0] += -0.002835178941533429;
    } else {
      result[0] += -0.06357942352715033;
    }
  } else {
    result[0] += 0.03226176010480077;
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1363214700350516562) ) ) {
    result[0] += -0.12895481929391572;
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8814820726865898459) ) ) {
      result[0] += -0.0002516165331558306;
    } else {
      result[0] += 0.12127025736855312;
    }
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1363214700350516562) ) ) {
    result[0] += -0.12652903173955618;
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8930431178516781143) ) ) {
      result[0] += -0.00014070376229828694;
    } else {
      result[0] += 0.12151288795427649;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8003917757139223932) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6413622072216433878) ) ) {
      result[0] += 0.004495409155530703;
    } else {
      result[0] += -0.03654039179453044;
    }
  } else {
    result[0] += 0.06389591171582387;
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1363214700350516562) ) ) {
    result[0] += -0.12337996204393448;
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
      result[0] += 0.05867308383597663;
    } else {
      result[0] += -0.003622085702025341;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5874282592522120927) ) ) {
    result[0] += -0.026581385404769602;
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9200812221382833611) ) ) {
      result[0] += 0.007446088225686496;
    } else {
      result[0] += 0.12611794833808568;
    }
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.422825113797481833) ) ) {
    result[0] += -0.04449111557420336;
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1850000000000000255) ) ) {
      result[0] += 0.13315974552389587;
    } else {
      result[0] += 0.0028954599307620217;
    }
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8930431178516781143) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1325117542492068867) ) ) {
      result[0] += -0.11996668356387523;
    } else {
      result[0] += -0.00021208011997022079;
    }
  } else {
    result[0] += 0.11298090160487435;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6457015457363293187) ) ) {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
      result[0] += 0.037894001324174816;
    } else {
      result[0] += -0.01496148046572327;
    }
  } else {
    result[0] += 0.024439958677844865;
  }
}

