
#include "header.h"

void predict_unit3(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7027407489895624026) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4981007797820624639) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2594714022927627761) ) ) {
        result[0] += -0.1263050402369944;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4312690111265354842) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += -0.08959854770656722;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.742577338542713683) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005917000000000001252) ) ) {
                result[0] += -0.11340628079656295;
              } else {
                result[0] += -0.09467084607399236;
              }
            } else {
              result[0] += -0.12366426980478475;
            }
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2463909746624610153) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1650000000000000355) ) ) {
              result[0] += -0.019807447387187208;
            } else {
              result[0] += -0.06550592960302688;
            }
          } else {
            result[0] += -0.09540470436864784;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5891834603033582196) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2969699150759821382) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5593705952246232904) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7472528898492464267) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6541365753517588422) ) ) {
                result[0] += -0.05389976029594702;
              } else {
                result[0] += 0.004159128609948459;
              }
            } else {
              result[0] += -0.09040480996983354;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
              result[0] += 0.011251109823877432;
            } else {
              result[0] += -0.03871533093500168;
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002169500000000000421) ) ) {
            result[0] += -0.09338403932796989;
          } else {
            result[0] += -0.0653435161699294;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4150000000000000355) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01349650000000000155) ) ) {
            result[0] += 0.04253229396565689;
          } else {
            result[0] += -0.014539308927358857;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6445404660562240595) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              result[0] += -0.009095657594648417;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06355808660527756393) ) ) {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3103100527046326884) ) ) {
                  result[0] += -0.06371708198321609;
                } else {
                  result[0] += -0.019061269071374353;
                }
              } else {
                if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3763935284854271202) ) ) {
                  result[0] += -0.11001235720908491;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.625846821573829204) ) ) {
                    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7850000000000001421) ) ) {
                      result[0] += -0.052773318131408495;
                    } else {
                      result[0] += -0.1029457339218334;
                    }
                  } else {
                    result[0] += -0.03267223246815829;
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4550000000000000711) ) ) {
              result[0] += 0.023566148937667435;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                result[0] += 0.011846613118410067;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.126853541778489509) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6800105846231156992) ) ) {
                    result[0] += -0.030369286923142044;
                  } else {
                    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4603009969540775015) ) ) {
                      result[0] += 0.035970674768359356;
                    } else {
                      result[0] += -0.031327609848823615;
                    }
                  }
                } else {
                  result[0] += -0.0642197088040934;
                }
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8919887641194863548) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7995887825305768581) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 0.06822710542650678;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7390680933680099374) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4146383914824121053) ) ) {
              result[0] += -0.035781082433895744;
            } else {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4317182746541440297) ) ) {
                result[0] += 0.028136680915018055;
              } else {
                result[0] += 0;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4643511832914573034) ) ) {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.6821093005801899256) ) ) {
                result[0] += 0;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9450000000000000622) ) ) {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4681662240485218729) ) ) {
                    result[0] += 0.07443608141400226;
                  } else {
                    result[0] += 0.022105317507075496;
                  }
                } else {
                  result[0] += 0.09343476528649193;
                }
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001009500000000000198) ) ) {
                result[0] += -0.011465580921071694;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6532207681155780543) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6433440886629894218) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6194234758793971674) ) ) {
                      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6650000000000001465) ) ) {
                        if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1185261981962025396) ) ) {
                          result[0] += -0.00854128350380135;
                        } else {
                          result[0] += 0.03395691847539785;
                        }
                      } else {
                        result[0] += -0.017056661403808872;
                      }
                    } else {
                      result[0] += -0.03578166791590665;
                    }
                  } else {
                    result[0] += 0.053988828543891684;
                  }
                } else {
                  result[0] += 0.03666314351973826;
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7074086128998665624) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7418777389447237525) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4019174527716188883) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001322500000000000108) ) ) {
                result[0] += 0.024295813209694473;
              } else {
                if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6166435351279918597) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9650000000000000799) ) ) {
                    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5817208213385774984) ) ) {
                      result[0] += 0.05233563679702037;
                    } else {
                      result[0] += 0.08733809691884656;
                    }
                  } else {
                    result[0] += 0.015406883090955678;
                  }
                } else {
                  result[0] += 0.0769546428792347;
                }
              }
            } else {
              result[0] += 0.031118775874994252;
            }
          } else {
            result[0] += 0.07774875503417808;
          }
        } else {
          result[0] += 0.09359321643638445;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7570612716642158846) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6817186019653541651) ) ) {
          result[0] += 0.09097001015359343;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9150000000000001465) ) ) {
            result[0] += 0.11655603308583874;
          } else {
            result[0] += 0.07984597908480999;
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8425494434324883875) ) ) {
          result[0] += 0.12681178814515162;
        } else {
          result[0] += 0.14046084971914993;
        }
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6930953257568631676) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.46251079555665775) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2594714022927627761) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1264739246323610955) ) ) {
          result[0] += -0.12807420400314345;
        } else {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3103100527046326884) ) ) {
            if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4349340187803038549) ) ) {
              result[0] += -0.11736729752133351;
            } else {
              result[0] += -0.036014008841021114;
            }
          } else {
            result[0] += -0.11907896678022144;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += -0.08305326829632852;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.389828724245051994) ) ) {
            result[0] += -0.10912115235843191;
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1898832163732817602) ) ) {
              result[0] += -0.057541896423290155;
            } else {
              result[0] += -0.09799554111547838;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5891834603033582196) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2766339022102697887) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5234930566607364222) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1850000000000000255) ) ) {
              result[0] += -0.001702990346076859;
            } else {
              result[0] += -0.06438460167319988;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7322331166582916051) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5835479980653267562) ) ) {
                result[0] += -0.024935821491818912;
              } else {
                result[0] += 0.022204659390700078;
              }
            } else {
              result[0] += -0.06155698966836365;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5158858854430460328) ) ) {
            result[0] += -0.09839668295772466;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
              result[0] += -0.00534099905252017;
            } else {
              result[0] += -0.06911581996323557;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4365950629658605364) ) ) {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.09893965937729458371) ) ) {
            if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2252565153835193457) ) ) {
              result[0] += -0.011969612295995297;
            } else {
              result[0] += -0.08102592516286859;
            }
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.03659918966571634041) ) ) {
              result[0] += 0.04994911255982945;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.609385253452748854) ) ) {
                result[0] += -0.04141197207133164;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.564198853668341882) ) ) {
                  result[0] += -0.03693107683130856;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02838850000000000401) ) ) {
                    result[0] += 0.061400096733483504;
                  } else {
                    result[0] += -0.005456494375981672;
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.625846821573829204) ) ) {
            result[0] += -0.05281529694301571;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02608100000000000349) ) ) {
              result[0] += -0.024096974928111862;
            } else {
              result[0] += -0.07591419951739606;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9012786453690170285) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7995887825305768581) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.500000000000000283e-05) ) ) {
          result[0] += 0.06282990511152328;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7390680933680099374) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5550000000000001599) ) ) {
              result[0] += 0.0472334557159676;
            } else {
              result[0] += -0.0013864119779591903;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4724621976130653489) ) ) {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5768620831300835805) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6450000000000001288) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4305635934924623709) ) ) {
                    result[0] += 0.01993843796794243;
                  } else {
                    result[0] += 0.07142351105034134;
                  }
                } else {
                  result[0] += -0.007086728542873883;
                }
              } else {
                result[0] += 0.07451462331362309;
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += -0.023160845168299082;
              } else {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.0491948752242571466) ) ) {
                  result[0] += 0.04969059410811869;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5910501547487437835) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02782800000000000204) ) ) {
                      result[0] += -0.02297841002504521;
                    } else {
                      result[0] += 0.03210304551279165;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6208328749497488142) ) ) {
                      result[0] += 0.06896454402365243;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7580745019261865281) ) ) {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6131529108977389342) ) ) {
                          result[0] += -0.04777287300268664;
                        } else {
                          result[0] += 0.01976250557965957;
                        }
                      } else {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6413622072216433878) ) ) {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6650804020351760437) ) ) {
                            result[0] += 0.021319402964819514;
                          } else {
                            result[0] += 0.08403332720508287;
                          }
                        } else {
                          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8706992593517899337) ) ) {
                            result[0] += -0.024786283281469677;
                          } else {
                            result[0] += 0.03365316358276409;
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7074086128998665624) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8419751086149712682) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5943075033919599237) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.7450000000000001066) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00381250000000000035) ) ) {
                  result[0] += 0.0700885881884271;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6350000000000001199) ) ) {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.046377500000000009) ) ) {
                      result[0] += 0.07580829646419951;
                    } else {
                      result[0] += 0.02111038086584043;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8192051011800424165) ) ) {
                      result[0] += -0.014154898285266742;
                    } else {
                      result[0] += 0.03260346799597964;
                    }
                  }
                }
              } else {
                result[0] += 0.0023110053235925903;
              }
            } else {
              result[0] += 0.05682888872809548;
            }
          } else {
            result[0] += 0.05951144090698181;
          }
        } else {
          result[0] += 0.08386827626256362;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7886110426559866937) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6868768085026044634) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += 0.09571580145338242;
          } else {
            result[0] += 0.0651652530133873;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9550000000000000711) ) ) {
            result[0] += 0.11164770037093104;
          } else {
            result[0] += 0.07460678616940492;
          }
        }
      } else {
        result[0] += 0.1339480658441828;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6930953257568631676) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4586286491922050845) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2594714022927627761) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1264739246323610955) ) ) {
          result[0] += -0.12604255861643443;
        } else {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3750409390474713223) ) ) {
            if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4852332858229937984) ) ) {
              result[0] += -0.1118825252233121;
            } else {
              result[0] += -0.012766504445286098;
            }
          } else {
            result[0] += -0.1159842035874948;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6413622072216433878) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5414516959754441805) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.09816500000000001613) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.09398444484757340067) ) ) {
                result[0] += -0.043087638130080076;
              } else {
                result[0] += -0.09369767080853873;
              }
            } else {
              result[0] += -0.04061585325739763;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007961500000000001562) ) ) {
              result[0] += -0.06449982273604057;
            } else {
              result[0] += 0.010625322640987391;
            }
          }
        } else {
          result[0] += -0.10449010130678811;
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5593705952246232904) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3070740017980582715) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06355808660527756393) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5072261056783921029) ) ) {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2401159284727943655) ) ) {
                result[0] += -0.025698783398622357;
              } else {
                result[0] += -0.07325515407703333;
              }
            } else {
              result[0] += -0.08425064813189359;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.051391296366422923) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02657550000000000537) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5834277574120604326) ) ) {
                  result[0] += -0.07005197858298981;
                } else {
                  result[0] += -0.022175033702202748;
                }
              } else {
                result[0] += 0.038286589996184395;
              }
            } else {
              result[0] += -0.08665446250250292;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5074134513786895395) ) ) {
            result[0] += -0.09483938201926148;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
              result[0] += -0.01637216682578395;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7519737796733669821) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7002474625125628682) ) ) {
                  result[0] += -0.07389455229501131;
                } else {
                  result[0] += -0.00022470912701048418;
                }
              } else {
                result[0] += -0.10587675325814341;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
          if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.01203636722120469786) ) ) {
            if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.08835747683243963535) ) ) {
              result[0] += -0.003263615959771181;
            } else {
              result[0] += 0.05300428109462093;
            }
          } else {
            result[0] += -0.027845556535138365;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6203306867821644088) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.352076346428185083) ) ) {
              result[0] += -0.023613177694599707;
            } else {
              result[0] += -0.05757251655392167;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7587459355025126806) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.679632490452261373) ) ) {
                result[0] += -0.022510752303730657;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6464622851394602465) ) ) {
                  result[0] += 0.04626876858901277;
                } else {
                  result[0] += -0.009135386017278296;
                }
              }
            } else {
              result[0] += -0.04514324323708345;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9012786453690170285) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7995887825305768581) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7669558640352696077) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3950000000000000733) ) ) {
            result[0] += 0.054378774461456295;
          } else {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4163018469253235154) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5499504253266332965) ) ) {
                result[0] += -0.03945130318980332;
              } else {
                result[0] += 0.019036674513727182;
              }
            } else {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4317182746541440297) ) ) {
                result[0] += 0.04422039148926644;
              } else {
                if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6129810513206679357) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6550000000000001377) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7434398242901157916) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5910501547487437835) ) ) {
                        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7550000000000001155) ) ) {
                          result[0] += -0.05847175319004261;
                        } else {
                          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8350000000000000755) ) ) {
                            result[0] += 0.03577336072647847;
                          } else {
                            result[0] += -0.013939540448994729;
                          }
                        }
                      } else {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.52031910737473408) ) ) {
                          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.569998760738014143) ) ) {
                            result[0] += 0.0705304452510793;
                          } else {
                            result[0] += 0.01355792590439672;
                          }
                        } else {
                          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8025985781909549255) ) ) {
                            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003305000000000000212) ) ) {
                              result[0] += 0.004902258028474734;
                            } else {
                              result[0] += -0.04888751080530506;
                            }
                          } else {
                            result[0] += 0.028922443584656916;
                          }
                        }
                      }
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01700800000000000575) ) ) {
                        result[0] += 0.03853129799032945;
                      } else {
                        result[0] += -0.007100940123354103;
                      }
                    }
                  } else {
                    result[0] += -0.024231241636004475;
                  }
                } else {
                  result[0] += 0.03906629031550945;
                }
              }
            }
          }
        } else {
          result[0] += 0.026118196171743702;
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7074086128998665624) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0009655000000000001038) ) ) {
            result[0] += 0.016805217487539485;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8419751086149712682) ) ) {
              result[0] += 0.03883761335202324;
            } else {
              result[0] += 0.05672925879920015;
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
            result[0] += 0.03848445108234292;
          } else {
            result[0] += 0.08590794870858284;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7886110426559866937) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7073687287159498016) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8950000000000001288) ) ) {
            result[0] += 0.08658734350884147;
          } else {
            result[0] += 0.041349867697709326;
          }
        } else {
          result[0] += 0.1052299793265762;
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8679983746857627969) ) ) {
          result[0] += 0.12082329957603798;
        } else {
          result[0] += 0.13299659134457478;
        }
      }
    }
  }
}

