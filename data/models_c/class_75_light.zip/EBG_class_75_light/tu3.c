
#include "header.h"

void predict_unit3(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5028791398618117636) ) ) {
    result[0] += -0.04835007246226194;
  } else {
    result[0] += 0.021998162452243175;
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7540043477323260523) ) ) {
    result[0] += -0.018632205014478355;
  } else {
    result[0] += 0.05534135191815939;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5028791398618117636) ) ) {
    result[0] += -0.047221252206459306;
  } else {
    result[0] += 0.020772413836587462;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6610591887588558313) ) ) {
    result[0] += -0.018302600610160813;
  } else {
    result[0] += 0.05218976094725202;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4711767397245928968) ) ) {
    result[0] += -0.048126331993950534;
  } else {
    result[0] += 0.01887463080636426;
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7540043477323260523) ) ) {
    result[0] += -0.01674915587319723;
  } else {
    result[0] += 0.05306142730255465;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4711767397245928968) ) ) {
    result[0] += -0.04709417708003286;
  } else {
    result[0] += 0.017822624374628546;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7015220019489404324) ) ) {
    result[0] += -0.015322322184651956;
  } else {
    result[0] += 0.05409597051360098;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4468288327365124712) ) ) {
    result[0] += -0.047853804866120064;
  } else {
    result[0] += 0.01628910335861019;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7216251912765565546) ) ) {
    result[0] += -0.01408890683471794;
  } else {
    result[0] += 0.05480895096695891;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4468288327365124712) ) ) {
    result[0] += -0.04691431706763624;
  } else {
    result[0] += 0.015386607015340493;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7216251912765565546) ) ) {
    result[0] += -0.013328232635754654;
  } else {
    result[0] += 0.05393142651089456;
  }
}

