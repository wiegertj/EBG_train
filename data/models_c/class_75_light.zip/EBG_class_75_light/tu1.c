
#include "header.h"

void predict_unit1(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5396268633306868789) ) ) {
    result[0] += -0.12755565165969254;
  } else {
    if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.794284308754609536) ) ) {
      result[0] += 0.018366804371977526;
    } else {
      result[0] += 0.15918488500203865;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6367019547837469151) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.422825113797481833) ) ) {
      result[0] += -0.13852612396769803;
    } else {
      result[0] += -0.013093105246902796;
    }
  } else {
    result[0] += 0.11584059294715736;
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5396268633306868789) ) ) {
    result[0] += -0.11611605863684998;
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.722387243692831027) ) ) {
      result[0] += 0.012081160374765827;
    } else {
      result[0] += 0.14936616383111412;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8347011650282363249) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3810610080862693594) ) ) {
      result[0] += -0.13520436351839968;
    } else {
      result[0] += -0.011408689512868287;
    }
  } else {
    result[0] += 0.10901522030345634;
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5009159589331361184) ) ) {
    result[0] += -0.11287308959734393;
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7348856104110997878) ) ) {
      result[0] += 0.007011019296649601;
    } else {
      result[0] += 0.14336301373598884;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7602047080052889427) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3550309857149810955) ) ) {
      result[0] += -0.13050646254707335;
    } else {
      result[0] += -0.003056271977111305;
    }
  } else {
    result[0] += 0.12778808467870534;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.8003917757139223932) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3810610080862693594) ) ) {
      result[0] += -0.12302856196071313;
    } else {
      result[0] += -0.00014498477014435193;
    }
  } else {
    result[0] += 0.1329548694306639;
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7348856104110997878) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2912453567552589773) ) ) {
      result[0] += -0.13360971261867635;
    } else {
      result[0] += -0.0025830202326990316;
    }
  } else {
    result[0] += 0.1306002464195057;
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5009159589331361184) ) ) {
    result[0] += -0.0930360800522632;
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7786086147706151595) ) ) {
      result[0] += 0.0070624285758900465;
    } else {
      result[0] += 0.13603796753179712;
    }
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2958123449781245862) ) ) {
    result[0] += -0.1269002874605025;
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7786086147706151595) ) ) {
      result[0] += 0.0002056339510448488;
    } else {
      result[0] += 0.13244449884645748;
    }
  }
}

