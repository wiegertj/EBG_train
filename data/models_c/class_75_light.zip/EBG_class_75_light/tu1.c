
#include "header.h"

void predict_unit1(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.728792159352835367) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5593705952246232904) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.389828724245051994) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2594714022927627761) ) ) {
          result[0] += -0.15226198889104373;
        } else {
          result[0] += -0.13865111429807134;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4981007797820624639) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2013534728327875667) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4404146740571510121) ) ) {
              result[0] += -0.11928567803401012;
            } else {
              result[0] += -0.08635304426542433;
            }
          } else {
            result[0] += -0.13231608834920686;
          }
        } else {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.284601935876013401) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7472528898492464267) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6541365753517588422) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02838850000000000401) ) ) {
                  result[0] += -0.09189115559445199;
                } else {
                  result[0] += -0.05208296347877461;
                }
              } else {
                result[0] += -0.02178148203149587;
              }
            } else {
              result[0] += -0.11823887699941027;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001734500000000000148) ) ) {
              result[0] += -0.13308258155537703;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5234930566607364222) ) ) {
                result[0] += -0.12909673866974955;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3350000000000000755) ) ) {
                  result[0] += -0.07243932104499155;
                } else {
                  result[0] += -0.10871293244401536;
                }
              }
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6595171046238990087) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3329079290171987338) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.25500000000000006) ) ) {
            result[0] += 0.006985009340769483;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5891834603033582196) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3547641043686024509) ) ) {
                result[0] += -0.045487245246623106;
              } else {
                result[0] += -0.10457765567196713;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08005900000000000516) ) ) {
                result[0] += -0.011543252896600865;
              } else {
                result[0] += -0.06453396203217401;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6203306867821644088) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002655500000000000308) ) ) {
              result[0] += -0.11210791062611551;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
                result[0] += -0.041101273591273565;
              } else {
                result[0] += -0.08994700478334305;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4365950629658605364) ) ) {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3623310406803024741) ) ) {
                result[0] += -0.05954799289608473;
              } else {
                result[0] += 0.011801119736010598;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6650000000000001465) ) ) {
                result[0] += -0.034841362047243606;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6542990130851055186) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6495638603084151752) ) ) {
                    result[0] += -0.07137166207000499;
                  } else {
                    result[0] += -0.02191970422148536;
                  }
                } else {
                  result[0] += -0.11109452319351934;
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7027407489895624026) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4550000000000000711) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03293100000000000888) ) ) {
              result[0] += 0.042340252690969644;
            } else {
              result[0] += -0.016152758424561344;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5127811792069081331) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01003050000000000296) ) ) {
                result[0] += -0.013786982457253131;
              } else {
                result[0] += -0.05344457928267875;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6745659887144164202) ) ) {
                result[0] += -0.0822669923936548;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.639033920871866834) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003037500000000000703) ) ) {
                    result[0] += -0.010931952627080398;
                  } else {
                    result[0] += -0.0774470000091085;
                  }
                } else {
                  result[0] += -0.07308956038855516;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6150000000000001021) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4724621976130653489) ) ) {
              result[0] += -0.003284930990150892;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4650000000000000244) ) ) {
                result[0] += 0.06575278658121864;
              } else {
                result[0] += 0.025314405759418894;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.560138790184518176) ) ) {
              result[0] += 0.01441264363271141;
            } else {
              result[0] += -0.03145333744629239;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8647856135106589681) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7803107051370604674) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.495865834604893696) ) ) {
          result[0] += 0.07005139915352025;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7533254900202764892) ) ) {
            result[0] += 0.02046068841380149;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.008435500000000002024) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002376500000000000574) ) ) {
                result[0] += 0.035995314029945005;
              } else {
                result[0] += 0.08150568138603012;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6150000000000001021) ) ) {
                result[0] += 0.044403892436765895;
              } else {
                result[0] += -0.007182613538626737;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8419751086149712682) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5862686645821703069) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6850000000000001643) ) ) {
              result[0] += 0.12105327381641502;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7995887825305768581) ) ) {
                result[0] += 0.056965435178916606;
              } else {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6182447245866452556) ) ) {
                  result[0] += 0.0932597689287261;
                } else {
                  result[0] += 0.058610682571914076;
                }
              }
            }
          } else {
            result[0] += 0.10019808333156253;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004497500000000000629) ) ) {
            result[0] += 0.14439051240236983;
          } else {
            result[0] += 0.10841820216625016;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7073687287159498016) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8919887641194863548) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
            result[0] += 0.1233922390697678;
          } else {
            result[0] += 0.15835299318514562;
          }
        } else {
          result[0] += 0.1577916280510656;
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8371739120330333739) ) ) {
          result[0] += 0.18136453264370822;
        } else {
          result[0] += 0.19537971493110384;
        }
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7075621644339633587) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5234930566607364222) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3421306008459473191) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.187139881547741499) ) ) {
          result[0] += -0.14748313320923326;
        } else {
          result[0] += -0.1369574169661927;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4586286491922050845) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1260227966266611876) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1050000000000000239) ) ) {
              result[0] += -0.04874234121420339;
            } else {
              result[0] += -0.11251706747652733;
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3650000000000000466) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.389828724245051994) ) ) {
                result[0] += -0.13146011737369565;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1850000000000000255) ) ) {
                  result[0] += -0.09831035575775882;
                } else {
                  result[0] += -0.12430242514316837;
                }
              }
            } else {
              result[0] += -0.13922390172364016;
            }
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2507409690028430949) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.52031910737473408) ) ) {
              result[0] += -0.08778003453592186;
            } else {
              result[0] += -0.02071852293056922;
            }
          } else {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.284601935876013401) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5074134513786895395) ) ) {
                result[0] += -0.11321102533030092;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2650000000000000688) ) ) {
                  result[0] += -0.03881986865754411;
                } else {
                  result[0] += -0.10066676212843993;
                }
              }
            } else {
              result[0] += -0.12800935637671335;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.625846821573829204) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3423741639027237382) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5593705952246232904) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5050000000000001155) ) ) {
              result[0] += -0.06823326132081832;
            } else {
              result[0] += -0.10182273706216843;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4251092621105527214) ) ) {
              result[0] += -0.006082767806278609;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4550000000000000711) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.339840807112446186) ) ) {
                  result[0] += -0.028375557781703833;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5042218989698493692) ) ) {
                    result[0] += -0.0366418136293117;
                  } else {
                    result[0] += -0.08480247663833197;
                  }
                }
              } else {
                result[0] += -0.0049886165500237795;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5837974670096922614) ) ) {
            result[0] += -0.11380184369401929;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002317500000000000549) ) ) {
              result[0] += -0.09721991956593624;
            } else {
              result[0] += -0.06092624263697523;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4550000000000000711) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5596867406532665123) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6883894843299426247) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
                result[0] += 0.01513947633906911;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5012509875628141653) ) ) {
                  result[0] += -0.025312006807117548;
                } else {
                  result[0] += -0.07865874618143638;
                }
              }
            } else {
              result[0] += 0.02418096721284876;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0561510000000000134) ) ) {
              result[0] += 0.06214499931548406;
            } else {
              result[0] += 0.0002972307060300088;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6647067832505478835) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2263427529174017738) ) ) {
              result[0] += -0.024782417499449445;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1165587384072143268) ) ) {
                result[0] += -0.08608010629679529;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00643350000000000085) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002780000000000000353) ) ) {
                    result[0] += -0.05718069271054712;
                  } else {
                    result[0] += -0.00311492577302558;
                  }
                } else {
                  result[0] += -0.08472071455506795;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7027407489895624026) ) ) {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.392100875596731957) ) ) {
                result[0] += -0.002302777606312944;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5493276582412061071) ) ) {
                  result[0] += -0.06290262354020996;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5150000000000001243) ) ) {
                    result[0] += 0.013699018630291073;
                  } else {
                    result[0] += -0.03893781676550685;
                  }
                }
              }
            } else {
              result[0] += 0.001953554715989955;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8647856135106589681) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7803107051370604674) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7434398242901157916) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8350000000000000755) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3366886552868456062) ) ) {
              result[0] += -0.010098740168192092;
            } else {
              result[0] += 0.04669318828250322;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01102400000000000081) ) ) {
              result[0] += 0.007252263603762269;
            } else {
              result[0] += -0.034498172643792034;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6550000000000001377) ) ) {
            result[0] += 0.048556211543901946;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7669558640352696077) ) ) {
              result[0] += 0.0006157979875754991;
            } else {
              result[0] += 0.04113358723273547;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8419751086149712682) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9450000000000000622) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6850000000000001643) ) ) {
              result[0] += 0.10706308436105455;
            } else {
              result[0] += 0.06545432374404044;
            }
          } else {
            result[0] += 0.08797118071968978;
          }
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6448546879214981375) ) ) {
            result[0] += 0.09776281412119342;
          } else {
            result[0] += 0.1349646243453983;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7428946460663085061) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6817186019653541651) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9433039335395834168) ) ) {
            result[0] += 0.1260483756842793;
          } else {
            result[0] += 0.1543158455051737;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9150000000000001465) ) ) {
            result[0] += 0.1622154065244763;
          } else {
            result[0] += 0.1070479160522023;
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8425494434324883875) ) ) {
          result[0] += 0.16941822288553895;
        } else {
          result[0] += 0.1802963199318594;
        }
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7027407489895624026) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5158858854430460328) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3421306008459473191) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2287126979501296342) ) ) {
          result[0] += -0.14155746018876725;
        } else {
          result[0] += -0.12930204764318706;
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4404146740571510121) ) ) {
            if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1260227966266611876) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1050000000000000239) ) ) {
                result[0] += -0.04045237800339973;
              } else {
                result[0] += -0.10307057367704883;
              }
            } else {
              result[0] += -0.11819194327374004;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2507409690028430949) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1650000000000000355) ) ) {
                result[0] += -0.016591012935319158;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.393589025605817211) ) ) {
                  result[0] += -0.09752586943702873;
                } else {
                  result[0] += -0.0403204963981847;
                }
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4931526702322118205) ) ) {
                result[0] += -0.11400823659957365;
              } else {
                result[0] += -0.07738847044495259;
              }
            }
          }
        } else {
          result[0] += -0.12547564522205282;
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5891834603033582196) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3635699203206635977) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5630794848414941711) ) ) {
            result[0] += -0.06790140300094533;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3208732935673461184) ) ) {
              result[0] += -0.005122275440513019;
            } else {
              result[0] += -0.051219229772261184;
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002169500000000000421) ) ) {
            result[0] += -0.11648967259784088;
          } else {
            result[0] += -0.08570220617770095;
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6850000000000001643) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6542990130851055186) ) ) {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3565411260296964535) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4868404241646586694) ) ) {
                result[0] += -0.029615549253834632;
              } else {
                result[0] += 0.008238483221820043;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003380500000000000258) ) ) {
                result[0] += -0.08170019119290493;
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4263038519874545185) ) ) {
                  result[0] += -0.06597126158716839;
                } else {
                  result[0] += -0.007395722270467809;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4424293181155778965) ) ) {
              result[0] += -0.03879102779113157;
            } else {
              result[0] += 0.011774581869703472;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.625846821573829204) ) ) {
            result[0] += -0.08603307708304285;
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4681662240485218729) ) ) {
              result[0] += -0.000313129989346038;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4450000000000000622) ) ) {
                result[0] += -0.0004158205314208942;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01039650000000000123) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6745659887144164202) ) ) {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001059500000000000329) ) ) {
                      result[0] += -0.07771979394843498;
                    } else {
                      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8950000000000001288) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6800105846231156992) ) ) {
                          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001859500000000000259) ) ) {
                            result[0] += -0.011823750909811359;
                          } else {
                            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8150000000000000577) ) ) {
                              result[0] += -0.08519016003757732;
                            } else {
                              result[0] += -0.026574726775212516;
                            }
                          }
                        } else {
                          result[0] += 0.010480867107673006;
                        }
                      } else {
                        result[0] += -0.073032213245488;
                      }
                    }
                  } else {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5233996415371392485) ) ) {
                      result[0] += 0.005859731114039266;
                    } else {
                      result[0] += -0.0442570797096256;
                    }
                  }
                } else {
                  result[0] += -0.07668948724222195;
                }
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8647856135106589681) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7803107051370604674) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 0.0788928448748487;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7390680933680099374) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4850000000000000422) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.52572947701005035) ) ) {
                result[0] += 0.01763448001283101;
              } else {
                result[0] += 0.06739742068599237;
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4435662465829146028) ) ) {
                result[0] += -0.040514338280610504;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6277403467108452206) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5943075033919599237) ) ) {
                    result[0] += -0.000656731983765634;
                  } else {
                    result[0] += 0.048079062681364734;
                  }
                } else {
                  result[0] += -0.016056351948197507;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5364037024921902708) ) ) {
              result[0] += 0.05033405848294871;
            } else {
              if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5672261264448897888) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.008435500000000002024) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002376500000000000574) ) ) {
                    result[0] += -0.01394190795688795;
                  } else {
                    result[0] += 0.04731902899040039;
                  }
                } else {
                  result[0] += -0.01095739459015704;
                }
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001817500000000000322) ) ) {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5395652629899497787) ) ) {
                    result[0] += 0.059782463095194624;
                  } else {
                    result[0] += 0.007635979883635328;
                  }
                } else {
                  result[0] += 0.06071074010525109;
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8097549183589626276) ) ) {
          result[0] += 0.062202595083739785;
        } else {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6333994641870349662) ) ) {
            result[0] += 0.07853551451602973;
          } else {
            result[0] += 0.10669797170086419;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7428946460663085061) ) ) {
        if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6817186019653541651) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9433039335395834168) ) ) {
            result[0] += 0.1141320705804593;
          } else {
            result[0] += 0.14127092698012303;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9150000000000001465) ) ) {
            result[0] += 0.1495826927177502;
          } else {
            result[0] += 0.09728957127342858;
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8425494434324883875) ) ) {
          result[0] += 0.15725200528724065;
        } else {
          result[0] += 0.16858921289476203;
        }
      }
    }
  }
}

