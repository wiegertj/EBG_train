
#include "header.h"

void predict_unit1(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8138751446832469538) ) ) {
    result[0] += -0.043707699757079985;
  } else {
    result[0] += 0.0712938601277151;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6224479755486952426) ) ) {
    result[0] += -0.05763697480249719;
  } else {
    result[0] += 0.05118147739040019;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5794124692327976556) ) ) {
    result[0] += -0.04188176413835386;
  } else {
    result[0] += 0.06663478098551393;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5973923879226185063) ) ) {
    result[0] += -0.05707951120086548;
  } else {
    result[0] += 0.046276863494624336;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8445896003085130443) ) ) {
    result[0] += -0.03794001943658569;
  } else {
    result[0] += 0.06682289384595042;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5973923879226185063) ) ) {
    result[0] += -0.05500914405539207;
  } else {
    result[0] += 0.04332548834584885;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8662563339863759149) ) ) {
    result[0] += -0.034799629784318636;
  } else {
    result[0] += 0.06607387661267113;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5973923879226185063) ) ) {
    result[0] += -0.05308819466572664;
  } else {
    result[0] += 0.040670487357887336;
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6802240065506315325) ) ) {
    result[0] += -0.032392334709877894;
  } else {
    result[0] += 0.0645464990434502;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.552160855807795059) ) ) {
    result[0] += -0.054820645692489185;
  } else {
    result[0] += 0.03585949504679538;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8662563339863759149) ) ) {
    result[0] += -0.03138827640047098;
  } else {
    result[0] += 0.06094634048082876;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.552160855807795059) ) ) {
    result[0] += -0.05320995165062976;
  } else {
    result[0] += 0.033740149026414264;
  }
}

