
#include "header.h"

void predict_unit11(union Entry* data, double* result) {
  unsigned int tmp;
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1316017537932669124) ) ) {
    result[0] += -0.04999620515854093;
  } else {
    result[0] += 0.0010477986286322198;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.919952104732480902) ) ) {
    result[0] += -0.0010311211204334504;
  } else {
    result[0] += 0.04957793322383364;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5365485968632662805) ) ) {
    result[0] += -0.014033745039534452;
  } else {
    result[0] += 0.003577814220762257;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1316017537932669124) ) ) {
    result[0] += -0.0495983767940642;
  } else {
    result[0] += 0.0009778727979758252;
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004890500000000001617) ) ) {
    result[0] += -0.007536475295430161;
  } else {
    result[0] += 0.006390334140455285;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.919952104732480902) ) ) {
    result[0] += -0.0009704092660864527;
  } else {
    result[0] += 0.04916949534799073;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1316017537932669124) ) ) {
    result[0] += -0.0492440589634376;
  } else {
    result[0] += 0.0009217898250481504;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.919952104732480902) ) ) {
    result[0] += -0.0009181824926320758;
  } else {
    result[0] += 0.04881054013646265;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6630547558875972136) ) ) {
    result[0] += -0.008063568041683799;
  } else {
    result[0] += 0.005344055377157875;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1316017537932669124) ) ) {
    result[0] += -0.04885153600352599;
  } else {
    result[0] += 0.0008670097309626576;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.919952104732480902) ) ) {
    result[0] += -0.0008665931024318371;
  } else {
    result[0] += 0.048399067156429776;
  }
  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004890500000000001617) ) ) {
    result[0] += -0.0069209230808697985;
  } else {
    result[0] += 0.0058641975669331435;
  }
}

