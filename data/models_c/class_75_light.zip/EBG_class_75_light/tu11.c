
#include "header.h"

void predict_unit11(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5948062062845668185) ) ) {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7850000000000001421) ) ) {
      result[0] += 0.003001326773467279;
    } else {
      result[0] += -0.013541919615940678;
    }
  } else {
    result[0] += 0.007924524687085053;
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3411690131117683933) ) ) {
    result[0] += -0.019454512771432456;
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09500000000000001499) ) ) {
      result[0] += 0.13923082871717044;
    } else {
      result[0] += 0.00022521870411962498;
    }
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)273.5000000000000568) ) ) {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)121.5000000000000142) ) ) {
      result[0] += -0.0021903011212331337;
    } else {
      result[0] += 0.014934895170324232;
    }
  } else {
    result[0] += -0.01063872257058297;
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.611969772716791538) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4150000000000000355) ) ) {
      result[0] += 1.216366433347018e-05;
    } else {
      result[0] += -0.041690291544139675;
    }
  } else {
    result[0] += 0.002841297345011357;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1124.500000000000227) ) ) {
    result[0] += -0.0004007610918287916;
  } else {
    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1021955000000000086) ) ) {
      result[0] += -0.007513869037989102;
    } else {
      result[0] += 0.1378136618285361;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.9192153427456918324) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.9938780866868420771) ) ) {
      result[0] += -8.10208921968317e-05;
    } else {
      result[0] += -0.10403381043857725;
    }
  } else {
    result[0] += 0.04383959788068516;
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.04830892724354553247) ) ) {
    result[0] += -0.1257731644694143;
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += 0.06983101298812204;
    } else {
      result[0] += -0.00013865735685547224;
    }
  }
  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.211360663335670829) ) ) {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006771500000000000609) ) ) {
      result[0] += 0.010466313706534617;
    } else {
      result[0] += 0.14418512871288544;
    }
  } else {
    result[0] += -0.0003440281068243407;
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1813705331849104485) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3353276241206030739) ) ) {
      result[0] += 0.48698420430708533;
    } else {
      result[0] += -0.051817509140162005;
    }
  } else {
    result[0] += 0.00043768995357528563;
  }
  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)10.50000000000000178) ) ) {
    result[0] += -0.013369549201392623;
  } else {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4639489995477387718) ) ) {
      result[0] += 0.012474504231454773;
    } else {
      result[0] += -0.0012143365476290269;
    }
  }
}

