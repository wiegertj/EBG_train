
#include "header.h"

void predict_unit2(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6863037615079420339) ) ) {
    result[0] += -0.028982632122392302;
  } else {
    result[0] += 0.06065476359379745;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5484011904177562569) ) ) {
    result[0] += -0.05199227538900095;
  } else {
    result[0] += 0.03159657260640688;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6422639030651048353) ) ) {
    result[0] += -0.027123384690903692;
  } else {
    result[0] += 0.059535227838022904;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8774509497879694475) ) ) {
    result[0] += -0.026828411919288062;
  } else {
    result[0] += 0.0567623851884703;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5280272099274750941) ) ) {
    result[0] += -0.05159755510462694;
  } else {
    result[0] += 0.028670326118320363;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6467849541054230267) ) ) {
    result[0] += -0.02450042513483209;
  } else {
    result[0] += 0.05733644771397601;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5280272099274750941) ) ) {
    result[0] += -0.05028020616874331;
  } else {
    result[0] += 0.027051874212355057;
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7003980199300247067) ) ) {
    result[0] += -0.023361338229018626;
  } else {
    result[0] += 0.05536973092737719;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5280272099274750941) ) ) {
    result[0] += -0.04899506154435715;
  } else {
    result[0] += 0.02552943224111812;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8913157355287062433) ) ) {
    result[0] += -0.02237052751255199;
  } else {
    result[0] += 0.05343266086872044;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5028791398618117636) ) ) {
    result[0] += -0.049496405863571534;
  } else {
    result[0] += 0.023294358848146388;
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7540043477323260523) ) ) {
    result[0] += -0.019685712316857572;
  } else {
    result[0] += 0.05658599344728949;
  }
}

