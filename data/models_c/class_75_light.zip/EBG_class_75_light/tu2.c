
#include "header.h"

void predict_unit2(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.6674657914882159426) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2912453567552589773) ) ) {
      result[0] += -0.12434533853362623;
    } else {
      result[0] += -0.008433148783005986;
    }
  } else {
    result[0] += 0.07727053653184801;
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7917299789982236158) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.270852290728793077) ) ) {
      result[0] += -0.12384217317282642;
    } else {
      result[0] += -0.0009735146076503783;
    }
  } else {
    result[0] += 0.12959767641814401;
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7917299789982236158) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.270852290728793077) ) ) {
      result[0] += -0.1201913993216664;
    } else {
      result[0] += -0.000833365490785614;
    }
  } else {
    result[0] += 0.1260117134671049;
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.7917299789982236158) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2573229687990142289) ) ) {
      result[0] += -0.11892691442929433;
    } else {
      result[0] += -0.000901972538581688;
    }
  } else {
    result[0] += 0.12226624723587314;
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8062666376159767223) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1993557109787759685) ) ) {
      result[0] += -0.12746015412036427;
    } else {
      result[0] += -0.0013860993324665814;
    }
  } else {
    result[0] += 0.12115708654570721;
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.4506546428194125875) ) ) {
    result[0] += -0.07279819856606491;
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8586077905304051461) ) ) {
      result[0] += 0.005098562783523735;
    } else {
      result[0] += 0.13007047153425474;
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7921663942018305482) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1856492240552437833) ) ) {
      result[0] += -0.12584735569174527;
    } else {
      result[0] += -0.012161620324771529;
    }
  } else {
    result[0] += 0.04122463410178526;
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8586077905304051461) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1856492240552437833) ) ) {
      result[0] += -0.12281769355187669;
    } else {
      result[0] += -0.0008332417372478652;
    }
  } else {
    result[0] += 0.1261562545944684;
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8814820726865898459) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1363214700350516562) ) ) {
      result[0] += -0.134060676577405;
    } else {
      result[0] += -0.000997417752556537;
    }
  } else {
    result[0] += 0.13059836507933253;
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.8814820726865898459) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.1993557109787759685) ) ) {
      result[0] += -0.11262217176680603;
    } else {
      result[0] += -0.00017440032038191282;
    }
  } else {
    result[0] += 0.12797547029818604;
  }
}

