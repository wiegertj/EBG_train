
#include "header.h"

void predict_unit2(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7027407489895624026) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5158858854430460328) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2769019423430922888) ) ) {
        result[0] += -0.1358047847558457;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4312690111265354842) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += -0.10425458259599255;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.742577338542713683) ) ) {
              result[0] += -0.1173743358844362;
            } else {
              result[0] += -0.13529507287598652;
            }
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2463909746624610153) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1650000000000000355) ) ) {
              result[0] += -0.03777635419923834;
            } else {
              result[0] += -0.07900093326168947;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005215500000000000518) ) ) {
              result[0] += -0.1169374181962923;
            } else {
              result[0] += -0.09498739179290341;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5891834603033582196) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3105417596138859149) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3950000000000000733) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3150000000000000577) ) ) {
                result[0] += -0.023783572110430046;
              } else {
                result[0] += -0.07855413383908062;
              }
            } else {
              result[0] += 0.008088117476576133;
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5150000000000001243) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005665500000000001264) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5835479980653267562) ) ) {
                  result[0] += -0.053948726097064886;
                } else {
                  result[0] += -0.016141265095042368;
                }
              } else {
                result[0] += -0.08064320224230545;
              }
            } else {
              result[0] += -0.10817033473846892;
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002169500000000000421) ) ) {
            result[0] += -0.10877363199054912;
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2108839252750100701) ) ) {
              result[0] += -0.043358878334269706;
            } else {
              result[0] += -0.08715747719787333;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6850000000000001643) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6542990130851055186) ) ) {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3565411260296964535) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04976550000000001112) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2610662092258060896) ) ) {
                  result[0] += -0.022053637620058943;
                } else {
                  result[0] += 0.03796407103456617;
                }
              } else {
                result[0] += -0.04026185888504463;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003380500000000000258) ) ) {
                result[0] += -0.07531024198065259;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4750000000000000333) ) ) {
                  result[0] += -0.04640823013870419;
                } else {
                  result[0] += 0.006344522002656124;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6263671874874373602) ) ) {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2263427529174017738) ) ) {
                result[0] += 0.016843484737073568;
              } else {
                result[0] += -0.021483713037640916;
              }
            } else {
              result[0] += 0.040494656646769066;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.625846821573829204) ) ) {
            result[0] += -0.07961377442347192;
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4681662240485218729) ) ) {
              result[0] += -0.0002779449300883114;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4450000000000000622) ) ) {
                result[0] += -0.0003691392834401486;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.126853541778489509) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9383188669749497057) ) ) {
                    result[0] += -0.044036147984206575;
                  } else {
                    result[0] += -0.0013107713000920823;
                  }
                } else {
                  result[0] += -0.07598014181888074;
                }
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8865421187835540451) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7803107051370604674) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 0.06938398115736537;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4850000000000000422) ) ) {
            result[0] += 0.042617981805459754;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7533254900202764892) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001059500000000000329) ) ) {
                result[0] += -0.026263382297517256;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002169500000000000421) ) ) {
                  result[0] += 0.029772745202158356;
                } else {
                  result[0] += 0.004211345986622273;
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5364037024921902708) ) ) {
                result[0] += 0.055278203513395775;
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5766663624209816819) ) ) {
                  result[0] += -0.00860708453029226;
                } else {
                  result[0] += 0.034827473160488884;
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7074086128998665624) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8192051011800424165) ) ) {
            result[0] += 0.057931219677163553;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7406984144974875228) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001771500000000000288) ) ) {
                result[0] += 0.04099851271681342;
              } else {
                if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6166435351279918597) ) ) {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2044121788183031196) ) ) {
                    result[0] += 0.08641839374506617;
                  } else {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.592415239094613133) ) ) {
                      result[0] += 0.09356526468962892;
                    } else {
                      result[0] += 0.04940984708125465;
                    }
                  }
                } else {
                  result[0] += 0.09933538657032137;
                }
              }
            } else {
              result[0] += 0.10790412949499918;
            }
          }
        } else {
          result[0] += 0.12047802145074578;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7570612716642158846) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6817186019653541651) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8450000000000000844) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.5708656043828381765) ) ) {
              result[0] += 0.09112268017775764;
            } else {
              result[0] += 0.12416862860569573;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9460446167939123852) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01212050000000000106) ) ) {
                result[0] += 0.10486250443028393;
              } else {
                result[0] += 0.042733838470779405;
              }
            } else {
              result[0] += 0.11995962739506791;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9150000000000001465) ) ) {
            result[0] += 0.13944191699257633;
          } else {
            result[0] += 0.10245707729491954;
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8425494434324883875) ) ) {
          result[0] += 0.14848583393888587;
        } else {
          result[0] += 0.1593306173727389;
        }
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7075621644339633587) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5074134513786895395) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2634616880679390705) ) ) {
        result[0] += -0.13244452554510255;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4312690111265354842) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += -0.09940701160131107;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.742577338542713683) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005917000000000001252) ) ) {
                result[0] += -0.12139401334484813;
              } else {
                result[0] += -0.10489720950676555;
              }
            } else {
              result[0] += -0.1304343924884942;
            }
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2416282609350551558) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6722423356281408413) ) ) {
              result[0] += -0.07410326020136374;
            } else {
              result[0] += -0.02904330728730028;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005215500000000000518) ) ) {
              result[0] += -0.11356060775643614;
            } else {
              result[0] += -0.0913222624204559;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5891834603033582196) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2969699150759821382) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5630794848414941711) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01570900000000000421) ) ) {
                result[0] += -0.0773924227597775;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05897350000000000508) ) ) {
                  result[0] += 0.007482455502094426;
                } else {
                  result[0] += -0.05519607502063392;
                }
              }
            } else {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.284601935876013401) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5835479980653267562) ) ) {
                  result[0] += -0.0758243087559404;
                } else {
                  result[0] += -0.039376665504390104;
                }
              } else {
                result[0] += -0.10294962666468038;
              }
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
              result[0] += 0.010617411974277888;
            } else {
              result[0] += -0.042363064008517075;
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002169500000000000421) ) ) {
            result[0] += -0.10334004501708471;
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3366886552868456062) ) ) {
              result[0] += -0.03026450153537711;
            } else {
              result[0] += -0.07879464579125474;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6595171046238990087) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6650000000000001465) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4734952854020100799) ) ) {
              result[0] += -0.04431849721388093;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.52572947701005035) ) ) {
                result[0] += 0.02209978426712343;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.609385253452748854) ) ) {
                  result[0] += -0.056888193777137844;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06509550000000001446) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.187362217115970231) ) ) {
                      result[0] += -0.027206675503861646;
                    } else {
                      result[0] += 0.039263231615044164;
                    }
                  } else {
                    result[0] += -0.05040691080858671;
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.625846821573829204) ) ) {
              result[0] += -0.07408100345226877;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6542990130851055186) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1786033740413308368) ) ) {
                  if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.05751864358971629093) ) ) {
                    result[0] += -0.03669720623022307;
                  } else {
                    result[0] += -0.0863275103549612;
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6301831911055276736) ) ) {
                    result[0] += 0.016673795121584026;
                  } else {
                    result[0] += -0.03587613994407933;
                  }
                }
              } else {
                result[0] += -0.08552465888716747;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4263038519874545185) ) ) {
            result[0] += 0.025238693978326388;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.625000000000000111) ) ) {
              result[0] += 0.0020503808238302276;
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3268792007278615852) ) ) {
                result[0] += 0.0019246558735503277;
              } else {
                result[0] += -0.029753976071508863;
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8865421187835540451) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7995887825305768581) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7669558640352696077) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5127811792069081331) ) ) {
            result[0] += 0.03161765762869003;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01188250000000000244) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.5950000000000000844) ) ) {
                result[0] += 0.056198269633742415;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.728792159352835367) ) ) {
                  result[0] += -0.011564735007462464;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6550000000000001377) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7739162128956639242) ) ) {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2933113730839578825) ) ) {
                        result[0] += 0.03417650978151129;
                      } else {
                        result[0] += -0.0043161060217423676;
                      }
                    } else {
                      result[0] += 0.06737040982356447;
                    }
                  } else {
                    result[0] += -0.006158977424900645;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5750608109547740154) ) ) {
                result[0] += -0.051736897678744204;
              } else {
                result[0] += 0.0019016347137834299;
              }
            }
          }
        } else {
          result[0] += 0.040378888689879974;
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7074086128998665624) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001322500000000000108) ) ) {
            result[0] += 0.03799167866035813;
          } else {
            if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6333994641870349662) ) ) {
              result[0] += 0.06520999899097862;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004321500000000001555) ) ) {
                result[0] += 0.08095701579123253;
              } else {
                result[0] += 0.12743283396877167;
              }
            }
          }
        } else {
          result[0] += 0.110671885911028;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7570612716642158846) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6817186019653541651) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9650496265483141656) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8450000000000000844) ) ) {
              result[0] += 0.10858252088086483;
            } else {
              result[0] += 0.07381056982184718;
            }
          } else {
            result[0] += 0.138406335294403;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9150000000000001465) ) ) {
            result[0] += 0.1305720427218418;
          } else {
            result[0] += 0.09420978918107811;
          }
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8425494434324883875) ) ) {
          result[0] += 0.14018152236646386;
        } else {
          result[0] += 0.1518353674420798;
        }
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7027407489895624026) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4981007797820624639) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2594714022927627761) ) ) {
        result[0] += -0.12927166307862334;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.389828724245051994) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += -0.09459116776774627;
          } else {
            result[0] += -0.11705898202803972;
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1850000000000000255) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.657009492487437341) ) ) {
                result[0] += -0.0740343985544731;
              } else {
                result[0] += -0.005455096671797032;
              }
            } else {
              result[0] += -0.09188855928557356;
            }
          } else {
            result[0] += -0.11119099590127697;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5891834603033582196) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2969699150759821382) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5400664745690104684) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.330342879382321819) ) ) {
              result[0] += -0.04991992078719128;
            } else {
              result[0] += -0.10448485533902474;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
              result[0] += 0.008146284699469946;
            } else {
              result[0] += -0.039463134794830025;
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002169500000000000421) ) ) {
            result[0] += -0.09849763117970581;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3950000000000000733) ) ) {
              result[0] += -0.1132112204128762;
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3268792007278615852) ) ) {
                result[0] += -0.012799206827028307;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5789331372495346573) ) ) {
                  result[0] += -0.07699509158484927;
                } else {
                  result[0] += -0.03194762395836831;
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4365950629658605364) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.634410233061354023) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04976550000000001112) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6481803955276382867) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.367985472071854447) ) ) {
                  result[0] += 0.0146684243945854;
                } else {
                  result[0] += -0.03617591364272178;
                }
              } else {
                result[0] += 0.017675042200613517;
              }
            } else {
              result[0] += -0.05168688799871516;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.564198853668341882) ) ) {
              if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.03659918966571634041) ) ) {
                result[0] += 0.00598800580781207;
              } else {
                result[0] += -0.04312934555841102;
              }
            } else {
              result[0] += 0.03375823495856818;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6495638603084151752) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002780000000000000353) ) ) {
              result[0] += -0.0621003888633625;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4950000000000000511) ) ) {
                result[0] += -0.061097517381895824;
              } else {
                result[0] += -0.0018875802724946994;
              }
            }
          } else {
            result[0] += -0.024726293825922774;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8865421187835540451) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7995887825305768581) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 0.07685872900602941;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7669558640352696077) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5550000000000001599) ) ) {
              result[0] += 0.04931412161964403;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001059500000000000329) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2157356523887877797) ) ) {
                  result[0] += 0.010846762482451856;
                } else {
                  result[0] += -0.04804639187437873;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3998546246231156065) ) ) {
                  result[0] += -0.02460164498351639;
                } else {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2450759342279490716) ) ) {
                    result[0] += 0.04777229739244296;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5140962685175880509) ) ) {
                      result[0] += -0.02767457060389418;
                    } else {
                      if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.0491948752242571466) ) ) {
                        result[0] += 0.054764986647240395;
                      } else {
                        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1143667719897807217) ) ) {
                          result[0] += -0.012618763265416567;
                        } else {
                          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7750000000000001332) ) ) {
                            result[0] += 0.05027028755206518;
                          } else {
                            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
                              result[0] += 0.00139796891221692;
                            } else {
                              result[0] += 0.03526713717988981;
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.7150000000000000799) ) ) {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5768620831300835805) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5364037024921902708) ) ) {
                  result[0] += 0.054694267432103844;
                } else {
                  result[0] += 0.011233345274521146;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4914057384422110819) ) ) {
                  result[0] += 0.09705183669346279;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5961089558040202352) ) ) {
                    result[0] += 0.003025467931618102;
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7077536600502513098) ) ) {
                      result[0] += 0.09845621478785932;
                    } else {
                      result[0] += 0.02156261967073477;
                    }
                  }
                }
              }
            } else {
              result[0] += -0.005758003755632978;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7074086128998665624) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7418777389447237525) ) ) {
            result[0] += 0.056293125944338974;
          } else {
            result[0] += 0.08506867087259905;
          }
        } else {
          result[0] += 0.10200484467650665;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7428946460663085061) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9150000000000001465) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6687753071115941639) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9550000000000000711) ) ) {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.5708656043828381765) ) ) {
                result[0] += 0.06867471341104049;
              } else {
                result[0] += 0.11084289483021692;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8450000000000000844) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05226250000000001034) ) ) {
                  result[0] += 0.10273217134413104;
                } else {
                  result[0] += 0.05164925335138521;
                }
              } else {
                result[0] += 0.044002251672752;
              }
            }
          } else {
            result[0] += 0.11999640372813598;
          }
        } else {
          result[0] += 0.06728397003714935;
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8371739120330333739) ) ) {
          result[0] += 0.13144257577282248;
        } else {
          result[0] += 0.14549379404138615;
        }
      }
    }
  }
}

