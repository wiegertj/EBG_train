
#include "header.h"

void predict_unit5(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.5894723629324799541) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6413622072216433878) ) ) {
      result[0] += -0.000954543099097758;
    } else {
      result[0] += -0.03375626540238111;
    }
  } else {
    result[0] += 0.013636877771111031;
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.04830892724354553247) ) ) {
    result[0] += -0.14081921319624463;
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
      result[0] += 0.032824213215987504;
    } else {
      result[0] += -0.003088411161045936;
    }
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9461509352790128391) ) ) {
    if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.211360663335670829) ) ) {
      result[0] += 0.12227271522265261;
    } else {
      result[0] += -0.0016582646230160003;
    }
  } else {
    result[0] += 0.12755091355016618;
  }
  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002764500000000000464) ) ) {
    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
      result[0] += 0.02228236386528501;
    } else {
      result[0] += -0.028162933871450916;
    }
  } else {
    result[0] += 0.007470216893937502;
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.5230913149931778472) ) ) {
    result[0] += -0.021584446604160607;
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3450000000000000289) ) ) {
      result[0] += 0.04809197693633993;
    } else {
      result[0] += 0.0009026276170651038;
    }
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.5677320766830197263) ) ) {
    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004760500000000000842) ) ) {
      result[0] += -0.020081052643127692;
    } else {
      result[0] += 0.005305143912049961;
    }
  } else {
    result[0] += 0.01421644529680145;
  }
  if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.04830892724354553247) ) ) {
    result[0] += -0.14008066426936694;
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
      result[0] += 0.027964523593639826;
    } else {
      result[0] += -0.0026977969145831953;
    }
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9461509352790128391) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.04830892724354553247) ) ) {
      result[0] += -0.139368153013405;
    } else {
      result[0] += -0.00017648370808207383;
    }
  } else {
    result[0] += 0.12480579028942583;
  }
  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.211360663335670829) ) ) {
    result[0] += 0.10771386223135158;
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.00711478974079350103) ) ) {
      result[0] += -0.013092399852026647;
    } else {
      result[0] += 0.0054086929446545765;
    }
  }
  if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)0.9200812221382833611) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7804766498994976098) ) ) {
      result[0] += 0.0017436764601238696;
    } else {
      result[0] += -0.027859942608367643;
    }
  } else {
    result[0] += 0.10030680578732251;
  }
}

