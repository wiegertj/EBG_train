
#include "header.h"

void predict_unit5(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8154030078240236401) ) ) {
    result[0] += -0.008815432374392139;
  } else {
    result[0] += 0.05018579897527327;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3617902288292713098) ) ) {
    result[0] += -0.04561033711138568;
  } else {
    result[0] += 0.009261052597032684;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7616046585677935798) ) ) {
    result[0] += -0.008084739740753905;
  } else {
    result[0] += 0.05123155765953661;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3012580068987611992) ) ) {
    result[0] += -0.04875066949546237;
  } else {
    result[0] += 0.008101423588452792;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7616046585677935798) ) ) {
    result[0] += -0.0076450717972604675;
  } else {
    result[0] += 0.050597195079294464;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3012580068987611992) ) ) {
    result[0] += -0.04811387607325633;
  } else {
    result[0] += 0.007658749295110022;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7616046585677935798) ) ) {
    result[0] += -0.0072287153094115954;
  } else {
    result[0] += 0.049962761231793086;
  }
  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5923541255337830824) ) ) {
    result[0] += -0.026367761261899627;
  } else {
    result[0] += 0.013121599389817372;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3012580068987611992) ) ) {
    result[0] += -0.047157100575962715;
  } else {
    result[0] += 0.0070657899740765575;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7616046585677935798) ) ) {
    result[0] += -0.0067993352184243586;
  } else {
    result[0] += 0.04918049421094;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)0.7616046585677935798) ) ) {
    result[0] += -0.00643755858331249;
  } else {
    result[0] += 0.04861821089151901;
  }
  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3012580068987611992) ) ) {
    result[0] += -0.04642062944978163;
  } else {
    result[0] += 0.006680926201016023;
  }
}

