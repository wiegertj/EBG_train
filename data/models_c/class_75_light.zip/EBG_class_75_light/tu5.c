
#include "header.h"

void predict_unit5(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6930953257568631676) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4312690111265354842) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2594714022927627761) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1264739246323610955) ) ) {
          result[0] += -0.12006213907809338;
        } else {
          if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3103100527046326884) ) ) {
            if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4349340187803038549) ) ) {
              result[0] += -0.10493558916710116;
            } else {
              result[0] += -0.008765202636987523;
            }
          } else {
            result[0] += -0.1061884467348358;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += -0.062201378132007115;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.742577338542713683) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005917000000000001252) ) ) {
              result[0] += -0.09221139015547895;
            } else {
              result[0] += -0.06670021922041328;
            }
          } else {
            result[0] += -0.10805143604991102;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5400664745690104684) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3850000000000000644) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1292340000000000433) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.657009492487437341) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3516558051256281625) ) ) {
                result[0] += 0.0058484251214556355;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.500000000000000283e-05) ) ) {
                  result[0] += -0.03250113247952498;
                } else {
                  result[0] += -0.0632006321209795;
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2650000000000000688) ) ) {
                result[0] += 0.05341797015951351;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6269974968039345731) ) ) {
                  result[0] += 0.013254797276622229;
                } else {
                  result[0] += -0.05741273068351538;
                }
              }
            }
          } else {
            result[0] += 0.023157512078839163;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002169500000000000421) ) ) {
            result[0] += -0.08952321115968902;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6947584613372143059) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6425364825628142595) ) ) {
                result[0] += -0.056700706200163174;
              } else {
                result[0] += 0.01117395282654974;
              }
            } else {
              result[0] += -0.07747443419708701;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.609385253452748854) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.352076346428185083) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04976550000000001112) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
                result[0] += 0.07669044831718942;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5350000000000001421) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4795545749445469519) ) ) {
                    result[0] += -0.016984534638879712;
                  } else {
                    result[0] += 0.028336014964040108;
                  }
                } else {
                  result[0] += -0.04224728076507552;
                }
              }
            } else {
              result[0] += -0.04408450663029064;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5150000000000001243) ) ) {
              result[0] += -0.09632036589748451;
            } else {
              result[0] += -0.04309257309610915;
            }
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4365950629658605364) ) ) {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.09893965937729458371) ) ) {
              if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3197884335317744964) ) ) {
                result[0] += -0.0047842801151028475;
              } else {
                result[0] += -0.06175053649382018;
              }
            } else {
              if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3714483662730325153) ) ) {
                result[0] += 0.0026247701653728016;
              } else {
                result[0] += 0.06734568599179462;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02608100000000000349) ) ) {
              result[0] += -0.01567943153456417;
            } else {
              result[0] += -0.06223726660730753;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6817186019653541651) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.848222830561460639) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7669558640352696077) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5550000000000001599) ) ) {
            result[0] += 0.03285420575024313;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6650000000000001465) ) ) {
              result[0] += -0.02247712404516384;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7250000000000000888) ) ) {
                result[0] += 0.0345222302334564;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.06684000000000002439) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01144700000000000058) ) ) {
                    result[0] += 0.006275950042089633;
                  } else {
                    result[0] += -0.023430331050845892;
                  }
                } else {
                  result[0] += 0.038372472121387315;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5910501547487437835) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5511625663567840672) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5424744603768845153) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5332735673366835183) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9050000000000001377) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.6650000000000001465) ) ) {
                      result[0] += 0.026633478127904193;
                    } else {
                      result[0] += -0.036708426489521315;
                    }
                  } else {
                    if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.6505320650523345183) ) ) {
                      result[0] += 0.00027002737146258215;
                    } else {
                      result[0] += 0.04139499015990941;
                    }
                  }
                } else {
                  result[0] += -0.018317531631381796;
                }
              } else {
                result[0] += 0.05939820200394;
              }
            } else {
              result[0] += -0.011827480757546157;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2391447551626999235) ) ) {
              result[0] += 0.07315370900841212;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.7750000000000001332) ) ) {
                result[0] += 0.06274383575081369;
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5766663624209816819) ) ) {
                  result[0] += -0.038962779920712724;
                } else {
                  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6300365147534743304) ) ) {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003245500000000000555) ) ) {
                      result[0] += 0.06790938167398786;
                    } else {
                      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006814500000000000245) ) ) {
                        result[0] += -0.008255038701405933;
                      } else {
                        result[0] += 0.04264918618375523;
                      }
                    }
                  } else {
                    result[0] += 0.0007380911880199944;
                  }
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9433039335395834168) ) ) {
          result[0] += 0.043494875972503365;
        } else {
          result[0] += 0.07493062574354042;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7948589598137713041) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9550000000000000711) ) ) {
          result[0] += 0.08465392748295687;
        } else {
          result[0] += 0.047917459235568366;
        }
      } else {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8679983746857627969) ) ) {
          result[0] += 0.10563684026888495;
        } else {
          result[0] += 0.12185912452828218;
        }
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.728792159352835367) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4543436058534389699) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2594714022927627761) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1264739246323610955) ) ) {
          result[0] += -0.1189178147582945;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -0.05524497296486625;
          } else {
            result[0] += -0.10416883932500862;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6277403467108452206) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6022841189157331909) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3550761912678883081) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4992188184422110542) ) ) {
                if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1541343396866647342) ) ) {
                  result[0] += -0.0670071827906898;
                } else {
                  if ( LIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.0491948752242571466) ) ) {
                    result[0] += 0.015960596634325582;
                  } else {
                    result[0] += -0.08056825880554311;
                  }
                }
              } else {
                result[0] += -0.08324769273409552;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3880603600537617104) ) ) {
                result[0] += 0.0182306291884564;
              } else {
                result[0] += -0.056516033471918824;
              }
            }
          } else {
            result[0] += 0.032623511094360194;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.500000000000000283e-05) ) ) {
            result[0] += -0.0627689274517976;
          } else {
            result[0] += -0.09634748424653211;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5891834603033582196) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1761715000000000086) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.2766339022102697887) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8168185667587940513) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5234930566607364222) ) ) {
                result[0] += -0.03482572797860422;
              } else {
                result[0] += -0.003222504804489777;
              }
            } else {
              result[0] += -0.11501132125391893;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5115140954869171752) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2327781866895190233) ) ) {
                result[0] += -0.1002024111083199;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6277403467108452206) ) ) {
                  result[0] += -0.01759970802534741;
                } else {
                  result[0] += -0.08602418860305566;
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2750000000000000777) ) ) {
                result[0] += 0;
              } else {
                result[0] += -0.04628501815357796;
              }
            }
          }
        } else {
          result[0] += 0.040722026867161046;
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1985325000000000284) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.126853541778489509) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3998546246231156065) ) ) {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.7983975536720421262) ) ) {
                result[0] += 0.01756199117505597;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6785661817943745566) ) ) {
                  result[0] += -0.03451451279256013;
                } else {
                  result[0] += -0.0889351891799027;
                }
              }
            } else {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2252565153835193457) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4578754035427136104) ) ) {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.4852332858229937984) ) ) {
                    result[0] += 0.04901610496434918;
                  } else {
                    result[0] += -0.022515498843355974;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4798028910050251561) ) ) {
                    result[0] += 0.06856287122231682;
                  } else {
                    result[0] += 0.0040080143190707445;
                  }
                }
              } else {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.08835747683243963535) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001903500000000000244) ) ) {
                    result[0] += 0;
                  } else {
                    result[0] += -0.054490704146433866;
                  }
                } else {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.0491948752242571466) ) ) {
                    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3895596163096332609) ) ) {
                      result[0] += 0.05210476507291009;
                    } else {
                      result[0] += 0.0014484492108085946;
                    }
                  } else {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9383188669749497057) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7587459355025126806) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7075621644339633587) ) ) {
                          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.564198853668341882) ) ) {
                            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5271332674874372737) ) ) {
                              result[0] += 0.0038462048532439765;
                            } else {
                              result[0] += -0.047836889779073355;
                            }
                          } else {
                            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6950000000000000622) ) ) {
                              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5664498681879840403) ) ) {
                                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6194234758793971674) ) ) {
                                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.187362217115970231) ) ) {
                                    result[0] += -0.008640589402739164;
                                  } else {
                                    result[0] += 0.0633714669877827;
                                  }
                                } else {
                                  result[0] += -0.042480689074131966;
                                }
                              } else {
                                result[0] += 0.04841907705836639;
                              }
                            } else {
                              result[0] += -0.01698701247702062;
                            }
                          }
                        } else {
                          result[0] += 0.012842871241758008;
                        }
                      } else {
                        result[0] += -0.06265950430892951;
                      }
                    } else {
                      result[0] += 0.024614225926612245;
                    }
                  }
                }
              }
            }
          } else {
            result[0] += -0.036567584162138615;
          }
        } else {
          result[0] += 0.04265436260183909;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7073687287159498016) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8647856135106589681) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7995887825305768581) ) ) {
          result[0] += 0.010888898488793616;
        } else {
          result[0] += 0.02486717727749925;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8054659791206031372) ) ) {
          if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6166435351279918597) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8865421187835540451) ) ) {
              if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.2450759342279490716) ) ) {
                result[0] += 0.05711095898088189;
              } else {
                result[0] += 0;
              }
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6826887365519117568) ) ) {
                if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.5708656043828381765) ) ) {
                  result[0] += 0;
                } else {
                  result[0] += 0.0738610639348233;
                }
              } else {
                result[0] += 0.002438384762134783;
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.8950000000000001288) ) ) {
              result[0] += 0.059364571595708335;
            } else {
              result[0] += 0.014463899252730512;
            }
          }
        } else {
          result[0] += 0.09821668657054757;
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.8371739120330333739) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9750000000000000888) ) ) {
          if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7886110426559866937) ) ) {
            result[0] += 0.0816509178125046;
          } else {
            result[0] += 0.104283673649568;
          }
        } else {
          result[0] += 0.05145000112768746;
        }
      } else {
        result[0] += 0.11829009143539486;
      }
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6647067832505478835) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3421306008459473191) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.187139881547741499) ) ) {
        result[0] += -0.11406075772107382;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.500000000000000283e-05) ) ) {
          result[0] += -0.07138859613788479;
        } else {
          result[0] += -0.09422114892922068;
        }
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5234930566607364222) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3750000000000000555) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1520895000000000163) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1468286052170324762) ) ) {
              result[0] += 0.040620956866171856;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.389828724245051994) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.1659701101988258487) ) ) {
                  result[0] += -0.025396261118117762;
                } else {
                  if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3539353041941689093) ) ) {
                    result[0] += -0.014314968983309783;
                  } else {
                    result[0] += -0.08616952014671207;
                  }
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3550761912678883081) ) ) {
                  result[0] += -0.050016805497554426;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6277403467108452206) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5664498681879840403) ) ) {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4677590045467516222) ) ) {
                        result[0] += 0.025264243793006985;
                      } else {
                        result[0] += -0.0594978208307538;
                      }
                    } else {
                      result[0] += 0.11586662312553142;
                    }
                  } else {
                    result[0] += -0.049560405996141164;
                  }
                }
              }
            }
          } else {
            result[0] += 0.04014825620407898;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002909500000000000194) ) ) {
            result[0] += -0.0902700178173026;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6413622072216433878) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2076279711322123467) ) ) {
                result[0] += -0.06771767753043653;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4835577767624377743) ) ) {
                  result[0] += -0.06346563653625091;
                } else {
                  result[0] += 0.05546501162530528;
                }
              }
            } else {
              result[0] += -0.0783350957020093;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3450000000000000289) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1985325000000000284) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08942050000000001386) ) ) {
              result[0] += -0.0004278251420490057;
            } else {
              result[0] += -0.052358129673188515;
            }
          } else {
            result[0] += 0.038147514642999716;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5891834603033582196) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4150000000000000355) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.3950000000000000733) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4850000000000000422) ) ) {
                  result[0] += -0.015315108913575924;
                } else {
                  result[0] += -0.056458504100155814;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3912772649537276659) ) ) {
                  result[0] += 0.036364961967738786;
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4113383997604337927) ) ) {
                    result[0] += -0.0840003295769657;
                  } else {
                    result[0] += 0.002459107137813557;
                  }
                }
              }
            } else {
              result[0] += -0.05684626778273516;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              result[0] += 0.010142274597051762;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0007085000000000000369) ) ) {
                result[0] += -0.05954551996199956;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4050000000000000822) ) ) {
                  result[0] += -0.06178351007028063;
                } else {
                  result[0] += -0.015817665214750046;
                }
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.6817186019653541651) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8192051011800424165) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)4.500000000000000283e-05) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5534556445755101084) ) ) {
            result[0] += 0.006446177232100606;
          } else {
            result[0] += 0.07781719473083709;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001103500000000000097) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5523590325454214023) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5776988665075377671) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4914057384422110819) ) ) {
                  result[0] += 0.007418186901325698;
                } else {
                  result[0] += -0.0581329307214494;
                }
              } else {
                result[0] += 0.04228925527238447;
              }
            } else {
              result[0] += -0.056564055156528174;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001279500000000000255) ) ) {
              result[0] += 0.05884122872765566;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7533254900202764892) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4850000000000000422) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6650000000000001465) ) ) {
                    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.3763935284854271202) ) ) {
                      result[0] += 0.029815886908041225;
                    } else {
                      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.4350000000000000533) ) ) {
                        result[0] += -0.047302766599778286;
                      } else {
                        result[0] += 0.015838216194557844;
                      }
                    }
                  } else {
                    result[0] += 0.03819532399422534;
                  }
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3998546246231156065) ) ) {
                    result[0] += -0.044730806193419494;
                  } else {
                    if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.3539353041941689093) ) ) {
                      result[0] += 0.038805853726140704;
                    } else {
                      result[0] += -0.005388240733197616;
                    }
                  }
                }
              } else {
                result[0] += 0.013616258730085882;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9181645509592420984) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8158067323869347964) ) ) {
            result[0] += 0.027524166933366682;
          } else {
            result[0] += 0.06772634261438909;
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5499504253266332965) ) ) {
              result[0] += 0.05135777844615539;
            } else {
              result[0] += 0.10235640418765088;
            }
          } else {
            result[0] += 0.004883728059554667;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.824437516878408494) ) ) {
        if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)0.7428946460663085061) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8131644532706052697) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7969182508153497269) ) ) {
              result[0] += 0.06659350445292903;
            } else {
              result[0] += 0.10325411992570353;
            }
          } else {
            result[0] += 0.01593523287094818;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.9550000000000000711) ) ) {
            result[0] += 0.09406861558853175;
          } else {
            if ( UNLIKELY(  (data[3].missing != -1) && (data[3].fvalue <= (double)-0.1142869088563816388) ) ) {
              result[0] += 0.09333777217388177;
            } else {
              result[0] += 0.0379512276079912;
            }
          }
        }
      } else {
        result[0] += 0.11524651766736195;
      }
    }
  }
}

