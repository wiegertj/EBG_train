
#include "header.h"

void predict_unit1(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4950000000000000511) ) ) {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2250000000000000333) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05500000000000000722) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
          result[0] += -0.010715967199911306;
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
            result[0] += -0.007323584573787927;
          } else {
            result[0] += -0.008709420765973518;
          }
        }
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00431950000000000129) ) ) {
            result[0] += -0.005473379273496839;
          } else {
            result[0] += -0.0028876779703917014;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1350000000000000366) ) ) {
            result[0] += -0.006619778889220136;
          } else {
            result[0] += -0.004798308914777917;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3450000000000000289) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7149244603266332598) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01627850000000000477) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.650000000000000541e-05) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3150000000000000577) ) ) {
                result[0] += -0.0035664627958565324;
              } else {
                result[0] += -0.0008956705676996294;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003250500000000000351) ) ) {
                result[0] += -0.003208669106130524;
              } else {
                result[0] += -0.002302363467684709;
              }
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02085144663384500344) ) ) {
              result[0] += -0.002092831487398977;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1165587384072143268) ) ) {
                result[0] += 0.0016181173537527555;
              } else {
                result[0] += -0.0011114612686261092;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09212750000000001493) ) ) {
            result[0] += -0.004238031827030447;
          } else {
            result[0] += -0.0010102952695951828;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01133450000000000256) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4350000000000000533) ) ) {
            result[0] += -0.0010555201041782358;
          } else {
            result[0] += -0.000134491859837711;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02664459509800340062) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6800105846231156992) ) ) {
              result[0] += 0.0008409371841288379;
            } else {
              result[0] += -0.001488998356675273;
            }
          } else {
            result[0] += 0.0024033449797706526;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7650000000000001243) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6350000000000001199) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01848850000000000146) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
            result[0] += 0.0009289329470156377;
          } else {
            result[0] += 0.002580699004146134;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02359730123255650638) ) ) {
            result[0] += 0.0019362727416559868;
          } else {
            result[0] += 0.004735161860551836;
          }
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.009516766579768852138) ) ) {
          result[0] += 0.0025090421562944916;
        } else {
          result[0] += 0.00416427338436539;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9250000000000001554) ) ) {
        result[0] += 0.005260303796206051;
      } else {
        result[0] += 0.006834727549039942;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4950000000000000511) ) ) {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2250000000000000333) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.04500000000000000527) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
            result[0] += -0.010286527494482264;
          } else {
            result[0] += -0.01044119581176256;
          }
        } else {
          result[0] += -0.007874384229078872;
        }
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00431950000000000129) ) ) {
            result[0] += -0.005399728417909994;
          } else {
            result[0] += -0.0028913340715155137;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1250000000000000278) ) ) {
            result[0] += -0.0067072890328918775;
          } else {
            result[0] += -0.0048970489699652195;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3450000000000000289) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7149244603266332598) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01627850000000000477) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.650000000000000541e-05) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3150000000000000577) ) ) {
                result[0] += -0.0034644239848750343;
              } else {
                result[0] += -0.000870044852532944;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003250500000000000351) ) ) {
                result[0] += -0.003116867004394595;
              } else {
                result[0] += -0.002236491357379021;
              }
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02085144663384500344) ) ) {
              result[0] += -0.0020329542227862808;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1165587384072143268) ) ) {
                result[0] += 0.0015718219680284796;
              } else {
                result[0] += -0.0010796616417144357;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1269590000000000163) ) ) {
            result[0] += -0.004051716479676148;
          } else {
            result[0] += -0.00015673629176719099;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01133450000000000256) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6850000000000001643) ) ) {
            result[0] += -0.0010224733682954207;
          } else {
            result[0] += -4.156519998357591e-05;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02664459509800340062) ) ) {
            result[0] += 0.0001359968147125641;
          } else {
            result[0] += 0.0023345837229873027;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7450000000000001066) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6350000000000001199) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01531350000000000246) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
            result[0] += 0.0008734919757169735;
          } else {
            result[0] += 0.0025068635338336034;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03603979634774020363) ) ) {
            result[0] += 0.002307980345266488;
          } else {
            result[0] += 0.004871521411354285;
          }
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.009516766579768852138) ) ) {
          result[0] += 0.002386611068315088;
        } else {
          result[0] += 0.0038282497199592135;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02447420998234165271) ) ) {
          result[0] += 0.004339056590583356;
        } else {
          result[0] += 0.005529373064670421;
        }
      } else {
        result[0] += 0.006639181566253646;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4950000000000000511) ) ) {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2250000000000000333) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.04500000000000000527) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0007425000000000001044) ) ) {
            result[0] += -0.010158369422795471;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
              result[0] += -0.006553471529999874;
            } else {
              result[0] += -0.009300050007665435;
            }
          }
        } else {
          result[0] += -0.0076490929951761495;
        }
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.008803184144741601005) ) ) {
            result[0] += -0.005122902812637445;
          } else {
            result[0] += -0.00276134457019801;
          }
        } else {
          result[0] += -0.005870311214672326;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3150000000000000577) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7293938685427137081) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01067850000000000223) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.650000000000000541e-05) ) ) {
              result[0] += -0.0023514637919468738;
            } else {
              result[0] += -0.0029718780879781624;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01225471801880190052) ) ) {
              result[0] += -0.002860896810952793;
            } else {
              result[0] += -0.00046629177735612324;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1177750000000000186) ) ) {
            result[0] += -0.004330799830261799;
          } else {
            result[0] += -0.0009418248276900432;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01265500000000000132) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7050000000000000711) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.650000000000000541e-05) ) ) {
              result[0] += -0.00013490112710173554;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001962500000000000269) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5550000000000001599) ) ) {
                  result[0] += -0.0020765870230899236;
                } else {
                  result[0] += -0.0008307823148159435;
                }
              } else {
                result[0] += -0.0009376697528622869;
              }
            }
          } else {
            result[0] += -4.402211646946642e-06;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01559164707745600183) ) ) {
            result[0] += -0.0007347718238702366;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1245513101099625097) ) ) {
              result[0] += 0.0027358491447970474;
            } else {
              result[0] += 0.0005332533502930998;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7750000000000001332) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6350000000000001199) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01531350000000000246) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
            result[0] += 0.0008485008044344387;
          } else {
            result[0] += 0.0024351405441581085;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03603979634774020363) ) ) {
            result[0] += 0.002241947532454515;
          } else {
            result[0] += 0.004732144027952723;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02708729125130565282) ) ) {
          result[0] += 0.0027570290473306626;
        } else {
          result[0] += 0.00469421048777899;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9250000000000001554) ) ) {
        result[0] += 0.0050413178212736255;
      } else {
        result[0] += 0.006449230280711605;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4950000000000000511) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1350000000000000366) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
          result[0] += -0.009606182495696116;
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
            result[0] += -0.007648942883017122;
          } else {
            result[0] += -0.004070970782433849;
          }
        }
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01386900000000000112) ) ) {
            result[0] += -0.005280271350593918;
          } else {
            result[0] += -0.002554971582680742;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2350000000000000144) ) ) {
            result[0] += -0.00657192802099989;
          } else {
            result[0] += -0.004865321649668222;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2750000000000000777) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0008742997306644500989) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3150000000000000577) ) ) {
              result[0] += -0.004940257956134099;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5143309380402011355) ) ) {
                result[0] += 0.00022906161916934367;
              } else {
                result[0] += -0.0030000906671408495;
              }
            }
          } else {
            result[0] += -0.003637631556753741;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0129473293797221032) ) ) {
            result[0] += -0.003800028713694949;
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
              result[0] += -0.00036226891376218046;
            } else {
              result[0] += -0.0020020525288650254;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008486000000000002222) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3950000000000000733) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
              result[0] += -0.00083101808202861;
            } else {
              result[0] += -0.0018852831217230639;
            }
          } else {
            result[0] += -0.0004196241653194318;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.05368089823796016319) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3950000000000000733) ) ) {
              result[0] += -0.0004974103688464632;
            } else {
              result[0] += 0.0021845862607504604;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09212750000000001493) ) ) {
              result[0] += -0.0007996175328875326;
            } else {
              result[0] += 0.0016435667186481648;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7750000000000001332) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6350000000000001199) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.008240561420177351659) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.875000000000000111) ) ) {
            result[0] += 0.00023159148261830072;
          } else {
            result[0] += 0.0011770709434600313;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1498495000000000243) ) ) {
            result[0] += 0.0018964472087112303;
          } else {
            result[0] += 0.005886415802425366;
          }
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01055863010420855265) ) ) {
          result[0] += 0.0023848532241120234;
        } else {
          result[0] += 0.003946852269890146;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9250000000000001554) ) ) {
        result[0] += 0.004897082452588374;
      } else {
        result[0] += 0.0062647136245013585;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4950000000000000511) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1350000000000000366) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
          result[0] += -0.009331343391508373;
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
            result[0] += -0.007430101672068497;
          } else {
            result[0] += -0.003954497671130802;
          }
        }
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01386900000000000112) ) ) {
            result[0] += -0.005129199366638208;
          } else {
            result[0] += -0.0024818721905628294;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2350000000000000144) ) ) {
            result[0] += -0.006383900902955113;
          } else {
            result[0] += -0.004726121645464768;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2750000000000000777) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0008742997306644500989) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3150000000000000577) ) ) {
              result[0] += -0.004798913975658132;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5143309380402011355) ) ) {
                result[0] += 0.0002225080178563865;
              } else {
                result[0] += -0.002914256129663718;
              }
            }
          } else {
            result[0] += -0.003533556561419102;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01163003332820435227) ) ) {
            result[0] += -0.00382667186398981;
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
              result[0] += -0.0004158046519590392;
            } else {
              result[0] += -0.0020704453660346173;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008486000000000002222) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3950000000000000733) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
              result[0] += -0.0008072421163595343;
            } else {
              result[0] += -0.0018313439503043663;
            }
          } else {
            result[0] += -0.00040761844611270456;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.05368089823796016319) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3950000000000000733) ) ) {
              result[0] += -0.00048317913596610765;
            } else {
              result[0] += 0.0021220838326324737;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09212750000000001493) ) ) {
              result[0] += -0.0007767399572709886;
            } else {
              result[0] += 0.0015965432101078642;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7750000000000001332) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6350000000000001199) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03603979634774020363) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5350000000000001421) ) ) {
            result[0] += 0.0003376657569383413;
          } else {
            result[0] += 0.0012890661787231764;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)26.50000000000000355) ) ) {
            result[0] += 0.0021170260051538007;
          } else {
            result[0] += 0.003948606393548169;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02708729125130565282) ) ) {
          result[0] += 0.0025909962242990983;
        } else {
          result[0] += 0.0044469840845109;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9250000000000001554) ) ) {
        result[0] += 0.004756973751238395;
      } else {
        result[0] += 0.0060854761093571165;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4950000000000000511) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1350000000000000366) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
          result[0] += -0.009282619807622579;
        } else {
          result[0] += -0.00725158855806201;
        }
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01359750000000000195) ) ) {
            result[0] += -0.005032348074655929;
          } else {
            result[0] += -0.002567741465114294;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
            result[0] += -0.006640145126244065;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07959200000000000996) ) ) {
              result[0] += -0.005265339160575603;
            } else {
              result[0] += -0.0013833277406932025;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2750000000000000777) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0205299456066139023) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7471533970100503463) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2250000000000000333) ) ) {
              result[0] += -0.00420579421265963;
            } else {
              result[0] += -0.002636639280864402;
            }
          } else {
            result[0] += -0.0043567596270657665;
          }
        } else {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
            result[0] += 0.00024203244287502158;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01738250000000000559) ) ) {
              result[0] += -0.0032988883993368043;
            } else {
              result[0] += -0.0011087188916810318;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01896216239618550223) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3850000000000000644) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
              result[0] += -0.000666201126839484;
            } else {
              result[0] += -0.00181770879175848;
            }
          } else {
            result[0] += -0.0005129182221701522;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.05368089823796016319) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)75.50000000000001421) ) ) {
              result[0] += 0.000857260963202686;
            } else {
              result[0] += 0.0030816236486712442;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3950000000000000733) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00448250000000000124) ) ) {
                result[0] += -0.001827217536369387;
              } else {
                result[0] += -0.0005693747195292386;
              }
            } else {
              result[0] += 0.0005916040959947736;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7750000000000001332) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6350000000000001199) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01848850000000000146) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
            result[0] += 0.0008062758732013464;
          } else {
            result[0] += 0.002294911815024956;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02447420998234165271) ) ) {
            result[0] += 0.0017606866473717357;
          } else {
            result[0] += 0.004167025362216755;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02708729125130565282) ) ) {
          result[0] += 0.002516866143847343;
        } else {
          result[0] += 0.004319752989050064;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
        result[0] += 0.004434957449754265;
      } else {
        result[0] += 0.005911366695633093;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4950000000000000511) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1350000000000000366) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0007425000000000001044) ) ) {
            result[0] += -0.009044432256151555;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
              result[0] += -0.0059717592958857205;
            } else {
              result[0] += -0.007940466377638929;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
            result[0] += -0.007011233412522496;
          } else {
            result[0] += -0.0037008882344805615;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.606193063154585432) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01386900000000000112) ) ) {
            result[0] += -0.005375501582475372;
          } else {
            result[0] += -0.0028186663775224287;
          }
        } else {
          result[0] += -0.006184464266542074;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2650000000000000688) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1177750000000000186) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7293938685427137081) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.29500000000000004) ) ) {
              result[0] += -0.0035640550359372896;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
                result[0] += -0.0012294144893794762;
              } else {
                result[0] += -0.002466683817282116;
              }
            }
          } else {
            result[0] += -0.0040717384615853785;
          }
        } else {
          result[0] += 0.00042478029504741145;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02092750000000000513) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3950000000000000733) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002265000000000000032) ) ) {
              result[0] += -0.0008652632422951812;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003250500000000000351) ) ) {
                result[0] += -0.0019446399836518394;
              } else {
                result[0] += -0.0011721325456513795;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01896216239618550223) ) ) {
              result[0] += -0.0005246135173961827;
            } else {
              result[0] += 0.0005716116768180612;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02937690275817125482) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
              result[0] += 0.001023411840539207;
            } else {
              result[0] += -0.0012833920868979274;
            }
          } else {
            result[0] += 0.002301508118684006;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7750000000000001332) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6650000000000001465) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03603979634774020363) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5650000000000000577) ) ) {
            result[0] += 0.0005431840352748259;
          } else {
            result[0] += 0.0015692246072576755;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01882700000000000345) ) ) {
            result[0] += 0.0019073090049762816;
          } else {
            result[0] += 0.00461333043193401;
          }
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01035297934913455113) ) ) {
          result[0] += 0.002311184656128141;
        } else {
          result[0] += 0.003728855809642658;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9250000000000001554) ) ) {
        result[0] += 0.004493986644948455;
      } else {
        result[0] += 0.005742238665025622;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5250000000000001332) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1350000000000000366) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0007425000000000001044) ) ) {
            result[0] += -0.008785665190224886;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5577388506030152016) ) ) {
              result[0] += -0.0058369659862087;
            } else {
              result[0] += -0.007999391015658688;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.115000000000000005) ) ) {
            result[0] += -0.006835255696178228;
          } else {
            result[0] += -0.004970300744778404;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6413622072216433878) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01386900000000000112) ) ) {
            result[0] += -0.005202728876637604;
          } else {
            result[0] += -0.002736129321447549;
          }
        } else {
          result[0] += -0.006134080715060782;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3450000000000000289) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09212750000000001493) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7293938685427137081) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2650000000000000688) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.29500000000000004) ) ) {
                result[0] += -0.0034951888779675725;
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02085144663384500344) ) ) {
                    result[0] += -0.0017127486217769791;
                  } else {
                    result[0] += 0.0007219230566200106;
                  }
                } else {
                  result[0] += -0.002412943605581709;
                }
              }
            } else {
              result[0] += -0.0011935270523516814;
            }
          } else {
            result[0] += -0.003639972752744643;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4650000000000000244) ) ) {
            result[0] += -0.0008493492736416765;
          } else {
            result[0] += 0.0020139855363167387;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01896216239618550223) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4350000000000000533) ) ) {
            result[0] += -0.0009810274905053336;
          } else {
            result[0] += -9.065337005972528e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004677500000000000234) ) ) {
            result[0] += -0.0005330768938043198;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4450000000000000622) ) ) {
              result[0] += -0.00043804045038140307;
            } else {
              result[0] += 0.0020318842364400167;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7750000000000001332) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6650000000000001465) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01848850000000000146) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
            result[0] += 0.0011353187966046023;
          } else {
            result[0] += 0.002191481065220974;
          }
        } else {
          result[0] += 0.003609952224548882;
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01035297934913455113) ) ) {
          result[0] += 0.00224506016590663;
        } else {
          result[0] += 0.003622170829336839;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02447420998234165271) ) ) {
          result[0] += 0.003814310819830835;
        } else {
          result[0] += 0.004746622800722504;
        }
      } else {
        result[0] += 0.005577949496936743;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5250000000000001332) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1350000000000000366) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0007425000000000001044) ) ) {
            result[0] += -0.008534301617686401;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5577388506030152016) ) ) {
              result[0] += -0.005669966608095421;
            } else {
              result[0] += -0.007770523256611208;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.115000000000000005) ) ) {
            result[0] += -0.006639694602760166;
          } else {
            result[0] += -0.004828097220657288;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6413622072216433878) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01386900000000000112) ) ) {
            result[0] += -0.0050538754330946125;
          } else {
            result[0] += -0.002657846889067633;
          }
        } else {
          result[0] += -0.005958580692081004;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3450000000000000289) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5800027599246232457) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01163003332820435227) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0008742997306644500989) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3150000000000000577) ) ) {
                result[0] += -0.003301158888360511;
              } else {
                result[0] += 2.8405194439187878e-05;
              }
            } else {
              result[0] += -0.0024281381124198298;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1091520000000000129) ) ) {
              result[0] += -0.0008255690248076434;
            } else {
              result[0] += 0.002373109743950843;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09550850000000001006) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
              result[0] += -0.002820343647531929;
            } else {
              result[0] += -0.004211499319813451;
            }
          } else {
            result[0] += -0.0002665445608254914;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01896216239618550223) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4450000000000000622) ) ) {
            result[0] += -0.0009149486544167983;
          } else {
            result[0] += -6.518007366795482e-05;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)39.50000000000000711) ) ) {
              result[0] += 0.0002764718043944672;
            } else {
              result[0] += 0.0022313588933247645;
            }
          } else {
            result[0] += -0.0006669427534780011;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7750000000000001332) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6650000000000001465) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01848850000000000146) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
            result[0] += 0.0011028365903623097;
          } else {
            result[0] += 0.0021287813722805607;
          }
        } else {
          result[0] += 0.0035066691528395874;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02664459509800340062) ) ) {
          result[0] += 0.0024586276972300746;
        } else {
          result[0] += 0.004104323482484111;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02447420998234165271) ) ) {
          result[0] += 0.003705180916324879;
        } else {
          result[0] += 0.004610818847481749;
        }
      } else {
        result[0] += 0.005418360748375134;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5250000000000001332) ) ) {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2250000000000000333) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0007425000000000001044) ) ) {
            result[0] += -0.008290129719794204;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
              result[0] += -0.005471682598027274;
            } else {
              result[0] += -0.007262097027411517;
            }
          }
        } else {
          result[0] += -0.0063402993581571235;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.606193063154585432) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00423900000000000058) ) ) {
            result[0] += -0.005001343645864551;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1177750000000000186) ) ) {
              result[0] += -0.0029547984408892945;
            } else {
              result[0] += 0.0005791523025925195;
            }
          }
        } else {
          result[0] += -0.005583912055611737;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3850000000000000644) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.714147492562814179) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02937690275817125482) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2650000000000000688) ) ) {
              result[0] += -0.0024157526480938774;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
                result[0] += -0.00022933146057593548;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008633000000000001783) ) ) {
                  result[0] += -0.0016064473694881254;
                } else {
                  result[0] += -0.0003804004358592844;
                }
              }
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
              result[0] += 0.0019292455522385722;
            } else {
              result[0] += -0.00046336270172131716;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1269590000000000163) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2650000000000000688) ) ) {
              result[0] += -0.003748386910748703;
            } else {
              result[0] += -0.002120988512988197;
            }
          } else {
            result[0] += 0.0001875330363339996;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01896216239618550223) ) ) {
          result[0] += -0.0002949147633321722;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)80.50000000000001421) ) ) {
              result[0] += 0.000775008588865031;
            } else {
              result[0] += 0.0028699906676310557;
            }
          } else {
            result[0] += -0.00034923131709353766;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7750000000000001332) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6650000000000001465) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.008982725145665402047) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.0005251964808241264;
          } else {
            result[0] += 0.0016881538399457106;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6210224928643216513) ) ) {
            result[0] += 0.002770254687413725;
          } else {
            result[0] += 0.001375341774200547;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02664459509800340062) ) ) {
          result[0] += 0.002388284766087488;
        } else {
          result[0] += 0.003986896128826396;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9250000000000001554) ) ) {
        result[0] += 0.00411880076293195;
      } else {
        result[0] += 0.005263337937293142;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5250000000000001332) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.115000000000000005) ) ) {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0007425000000000001044) ) ) {
            result[0] += -0.008068846725201527;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5577388506030152016) ) ) {
              result[0] += -0.005872184726794024;
            } else {
              result[0] += -0.007626536723706082;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.000873500000000000036) ) ) {
            result[0] += -0.007000023697527076;
          } else {
            result[0] += -0.0028383294039270226;
          }
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6835338731909549326) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03603979634774020363) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.25500000000000006) ) ) {
              result[0] += -0.005131419663634419;
            } else {
              result[0] += -0.0026675304833678726;
            }
          } else {
            result[0] += -0.002223974969426242;
          }
        } else {
          result[0] += -0.006161306261439784;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2650000000000000688) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0133385000000000014) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.29500000000000004) ) ) {
              result[0] += -0.0031199434797156474;
            } else {
              result[0] += -0.001305159905468546;
            }
          } else {
            result[0] += -0.0036650455024154387;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0148413130503959028) ) ) {
            result[0] += -0.003105089346691917;
          } else {
            result[0] += -0.0009234467865839072;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01205124510104085139) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
            result[0] += -0.00047021821088347133;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6750000000000001554) ) ) {
              result[0] += -0.001557218620676907;
            } else {
              result[0] += -0.0002501983670797286;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.05368089823796016319) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)75.50000000000001421) ) ) {
              result[0] += 0.000481902193523003;
            } else {
              result[0] += 0.0025586127169628494;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004677500000000000234) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7650000000000001243) ) ) {
                result[0] += -0.0016765880861500783;
              } else {
                result[0] += 0.0001754127940933471;
              }
            } else {
              result[0] += 0.00012110349259236932;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7750000000000001332) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6650000000000001465) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01848850000000000146) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.0009512016937457129;
          } else {
            result[0] += 0.0016463945016739776;
          }
        } else {
          result[0] += 0.0033581271522063402;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02664459509800340062) ) ) {
          result[0] += 0.00231995439177378;
        } else {
          result[0] += 0.003872828447827502;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9250000000000001554) ) ) {
        result[0] += 0.00400095920490209;
      } else {
        result[0] += 0.005112750429261609;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5350000000000001421) ) ) {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2050000000000000433) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0007425000000000001044) ) ) {
            result[0] += -0.007837991793309887;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5671541132663318052) ) ) {
              result[0] += -0.00531163080912142;
            } else {
              result[0] += -0.007408336567490291;
            }
          }
        } else {
          result[0] += -0.006066246981033558;
        }
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003897500000000000357) ) ) {
            result[0] += -0.004535019775106694;
          } else {
            result[0] += -0.002121893087798308;
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.07500000000000002498) ) ) {
            result[0] += -0.005745880098421156;
          } else {
            result[0] += -0.00416444856839592;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3750000000000000555) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7149244603266332598) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02116634333934230491) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2150000000000000244) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)9.264969488118538537e-06) ) ) {
                result[0] += -0.002140697084585151;
              } else {
                result[0] += -0.0029878194768141555;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
                result[0] += -0.0005421094268312515;
              } else {
                result[0] += -0.0015461374982012868;
              }
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02092750000000000513) ) ) {
              result[0] += -0.0008845571748580723;
            } else {
              result[0] += 0.0008244006041874998;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07959200000000000996) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1950000000000000344) ) ) {
              result[0] += -0.004271171998288352;
            } else {
              result[0] += -0.0024164847686287067;
            }
          } else {
            result[0] += -0.0008077343291456656;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008973500000000000573) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6550000000000001377) ) ) {
            result[0] += -0.0008118747812915888;
          } else {
            result[0] += 0.00013867589012755638;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03739601681999780991) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.04446937286580055632) ) ) {
              result[0] += 0.001748906700086156;
            } else {
              result[0] += -0.00029371344450612486;
            }
          } else {
            result[0] += 0.002568787665194831;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8050000000000001599) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6650000000000001465) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.008982725145665402047) ) ) {
          result[0] += 0.0007908295328797024;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.966590843157139501) ) ) {
            result[0] += 0.002347947159270467;
          } else {
            result[0] += 0.0005776284694874971;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02664459509800340062) ) ) {
          result[0] += 0.002414106064889746;
        } else {
          result[0] += 0.0038765238262816306;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9350000000000001643) ) ) {
        result[0] += 0.0039390741078134195;
      } else {
        result[0] += 0.004966471327387027;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5250000000000001332) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.115000000000000005) ) ) {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0007425000000000001044) ) ) {
            result[0] += -0.007613741770569916;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5577388506030152016) ) ) {
              result[0] += -0.005552208519318362;
            } else {
              result[0] += -0.007196379259096185;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.000873500000000000036) ) ) {
            result[0] += -0.006575498462112012;
          } else {
            result[0] += -0.002626666462765215;
          }
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6835338731909549326) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03603979634774020363) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6731103726130654996) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.25500000000000006) ) ) {
                result[0] += -0.004886035432328571;
              } else {
                result[0] += -0.002634299143141869;
              }
            } else {
              result[0] += -0.001781892597457739;
            }
          } else {
            result[0] += -0.002060089781272736;
          }
        } else {
          result[0] += -0.005824912857574342;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2650000000000000688) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0133385000000000014) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
            result[0] += -0.0023694628330090547;
          } else {
            result[0] += -0.0034776975702795515;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01461911667849610276) ) ) {
            result[0] += -0.0029968457413466357;
          } else {
            result[0] += -0.0008706863262370144;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01205124510104085139) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
            result[0] += -0.00043302856948350605;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5350000000000001421) ) ) {
              result[0] += -0.0017346450098935631;
            } else {
              result[0] += -0.0005008398679304066;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.05368089823796016319) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)75.50000000000001421) ) ) {
              result[0] += 0.000461473236659485;
            } else {
              result[0] += 0.0024747794330990417;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004677500000000000234) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7650000000000001243) ) ) {
                result[0] += -0.0015594826202392888;
              } else {
                result[0] += 0.0001664265133678401;
              }
            } else {
              result[0] += 0.00011914015946591136;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7750000000000001332) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6550000000000001377) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02447420998234165271) ) ) {
          result[0] += 0.000974227631372172;
        } else {
          result[0] += 0.0024081093132796634;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02664459509800340062) ) ) {
          result[0] += 0.002102839456006126;
        } else {
          result[0] += 0.003624658005543393;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9250000000000001554) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02447420998234165271) ) ) {
          result[0] += 0.003254162235310132;
        } else {
          result[0] += 0.0041338892785748454;
        }
      } else {
        result[0] += 0.004824377365378216;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5350000000000001421) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1050000000000000239) ) ) {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0007425000000000001044) ) ) {
          result[0] += -0.007395907686252056;
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5811189422864322385) ) ) {
            result[0] += -0.004250362383777371;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
              result[0] += -0.006990486186603404;
            } else {
              result[0] += -0.0021958072973144367;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6413622072216433878) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03675833313733020691) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2650000000000000688) ) ) {
              result[0] += -0.004805319918510912;
            } else {
              result[0] += -0.0017966968963864691;
            }
          } else {
            result[0] += -0.0016700122330215142;
          }
        } else {
          result[0] += -0.005763870833523875;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2750000000000000777) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0133385000000000014) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5811189422864322385) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.29500000000000004) ) ) {
              result[0] += -0.0030679602886741746;
            } else {
              result[0] += -0.0012687003943613702;
            }
          } else {
            result[0] += -0.00344003188654263;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01559164707745600183) ) ) {
            result[0] += -0.0028477825865593155;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4750000000000000333) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1165587384072143268) ) ) {
                result[0] += -0.0001682307881826645;
              } else {
                result[0] += -0.0016117270679398075;
              }
            } else {
              result[0] += 0.0014420310894393573;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02092750000000000513) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4350000000000000533) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
              result[0] += -0.0007953439986867973;
            } else {
              result[0] += -0.0018083131393201116;
            }
          } else {
            result[0] += 0.00011887090446920836;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03037232950945140467) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.564198853668341882) ) ) {
              result[0] += 0.0010391619464263856;
            } else {
              result[0] += -0.001050068974354826;
            }
          } else {
            result[0] += 0.0023833256894974036;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8050000000000001599) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6850000000000001643) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03603979634774020363) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
            result[0] += 0.0010553833510031348;
          } else {
            result[0] += 0.001957849621105042;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02092750000000000513) ) ) {
            result[0] += 0.001580908377595259;
          } else {
            result[0] += 0.0044040860734121685;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02447420998234165271) ) ) {
          result[0] += 0.0023677102511164565;
        } else {
          result[0] += 0.0037648294190256552;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9350000000000001643) ) ) {
        result[0] += 0.003724654443862611;
      } else {
        result[0] += 0.004686348803672436;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5350000000000001421) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1050000000000000239) ) ) {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0007425000000000001044) ) ) {
          result[0] += -0.007184305976201737;
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5811189422864322385) ) ) {
            result[0] += -0.0041287567625481235;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
              result[0] += -0.006790483848294336;
            } else {
              result[0] += -0.0021329838280712493;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6835338731909549326) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03739601681999780991) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2450000000000000233) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6720057180904523975) ) ) {
                result[0] += -0.00467937689865826;
              } else {
                result[0] += -0.0029324491933444795;
              }
            } else {
              result[0] += -0.0020199228899636682;
            }
          } else {
            result[0] += -0.0019533691462445307;
          }
        } else {
          result[0] += -0.005587133546781445;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2650000000000000688) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1645630000000000426) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7293938685427137081) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005862500000000000523) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2050000000000000433) ) ) {
                result[0] += -0.0038024338713078484;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.503000764270941431e-05) ) ) {
                  result[0] += -0.0015998176457445753;
                } else {
                  result[0] += -0.0025641989873769386;
                }
              }
            } else {
              result[0] += -0.0015977083544355777;
            }
          } else {
            result[0] += -0.003481211730708223;
          }
        } else {
          result[0] += 0.0017951849994806413;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01896216239618550223) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4350000000000000533) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7210440605025126848) ) ) {
              result[0] += -0.0009532908921697624;
            } else {
              result[0] += -0.0020713633970612494;
            }
          } else {
            result[0] += -3.31108036616659e-05;
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5800027599246232457) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5950000000000000844) ) ) {
              result[0] += 0.0005512703069053843;
            } else {
              result[0] += 0.00251234509772189;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3950000000000000733) ) ) {
              result[0] += -0.0008877956387770296;
            } else {
              result[0] += 0.0004238293604329324;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8050000000000001599) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6850000000000001643) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03603979634774020363) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
            result[0] += 0.0010251881496425215;
          } else {
            result[0] += 0.0019018342751296877;
          }
        } else {
          result[0] += 0.002852492741057639;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02447420998234165271) ) ) {
          result[0] += 0.0022999685270044543;
        } else {
          result[0] += 0.003657115210451306;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9350000000000001643) ) ) {
        result[0] += 0.003618089667353448;
      } else {
        result[0] += 0.00455226932853341;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5350000000000001421) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1050000000000000239) ) ) {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0007425000000000001044) ) ) {
          result[0] += -0.006978758328153766;
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5811189422864322385) ) ) {
            result[0] += -0.0040106303569196426;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
              result[0] += -0.006596203706447905;
            } else {
              result[0] += -0.0020719577789808127;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6835338731909549326) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03739601681999780991) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1350000000000000366) ) ) {
              result[0] += -0.004636674366967276;
            } else {
              result[0] += -0.0033425062848361983;
            }
          } else {
            result[0] += -0.0018974819895574324;
          }
        } else {
          result[0] += -0.005427282036604258;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2650000000000000688) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1645630000000000426) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7293938685427137081) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005862500000000000523) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2050000000000000433) ) ) {
                result[0] += -0.0036936437749931473;
              } else {
                result[0] += -0.0021962046380982485;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.008408953333664601418) ) ) {
                result[0] += -0.002797922759377977;
              } else {
                result[0] += -0.0012863073300217187;
              }
            }
          } else {
            result[0] += -0.003381612007927153;
          }
        } else {
          result[0] += 0.0017438235937058105;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02092750000000000513) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3950000000000000733) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7298800263842079028) ) ) {
              result[0] += -0.0009273984640980278;
            } else {
              result[0] += -0.0019703627672354486;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6650000000000001465) ) ) {
              result[0] += -0.000596710359953998;
            } else {
              result[0] += 0.00028898329264850513;
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02664459509800340062) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
              result[0] += 0.0009012222781595969;
            } else {
              result[0] += -0.0011400414204862696;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1245513101099625097) ) ) {
              result[0] += 0.00342386980657701;
            } else {
              result[0] += 0.0008895395788621522;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8050000000000001599) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6650000000000001465) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02620539606947270075) ) ) {
          result[0] += 0.0009691526322035056;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.114862829452247572) ) ) {
            result[0] += 0.0026837882740804535;
          } else {
            result[0] += 5.1630375772871924e-05;
          }
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01035297934913455113) ) ) {
          result[0] += 0.0018887105997698371;
        } else {
          result[0] += 0.0030206964454084096;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9450000000000000622) ) ) {
        result[0] += 0.003519429157356735;
      } else {
        result[0] += 0.004422025954036205;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5550000000000001599) ) ) {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2050000000000000433) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0007425000000000001044) ) ) {
            result[0] += -0.006779091531472372;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5671541132663318052) ) ) {
              result[0] += -0.004466664640466985;
            } else {
              result[0] += -0.006121375573606403;
            }
          }
        } else {
          result[0] += -0.005245995551294918;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00423900000000000058) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.07500000000000002498) ) ) {
            result[0] += -0.005341700597511651;
          } else {
            result[0] += -0.003977565600269514;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.01704648841990550126) ) ) {
            result[0] += -0.0013387176057642195;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
              result[0] += -0.0002805329069972191;
            } else {
              result[0] += -0.0035546400396316907;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3850000000000000644) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7149244603266332598) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02937690275817125482) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2150000000000000244) ) ) {
              result[0] += -0.00238084931643459;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
                result[0] += -0.0003956747732915227;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01205124510104085139) ) ) {
                  result[0] += -0.0015885471639618919;
                } else {
                  result[0] += -0.0006030547607956971;
                }
              }
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
              result[0] += 0.0016954251824058532;
            } else {
              result[0] += -0.00036159432060063157;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1377635000000000109) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1950000000000000344) ) ) {
              result[0] += -0.003575057348205332;
            } else {
              result[0] += -0.0020814590285171716;
            }
          } else {
            result[0] += 0.0004960706070633762;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01133450000000000256) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5850000000000000755) ) ) {
            result[0] += -0.0008354826583073489;
          } else {
            result[0] += 0.00017576347111943297;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6915080527790725684) ) ) {
            result[0] += 0.0017530001277158461;
          } else {
            result[0] += -0.0002909992957405313;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8050000000000001599) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7050000000000000711) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02756847298310730401) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
            result[0] += 0.0009768522124384874;
          } else {
            result[0] += 0.0016902008868477068;
          }
        } else {
          result[0] += 0.0026492817159137717;
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01055863010420855265) ) ) {
          result[0] += 0.001979030787290963;
        } else {
          result[0] += 0.0031541093224135256;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9450000000000000622) ) ) {
        result[0] += 0.0034187360092416013;
      } else {
        result[0] += 0.00429550892685639;
      }
    }
  }
}

