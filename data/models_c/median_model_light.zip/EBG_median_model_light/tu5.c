
#include "header.h"

void predict_unit5(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.875000000000000111) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0014983908385588105;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4737195465326633492) ) ) {
              result[0] += 0.00040683483192068746;
            } else {
              result[0] += -0.0014340386049726751;
            }
          } else {
            result[0] += -0.001604511958110152;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.115000000000000005) ) ) {
            result[0] += -0.0012381006347006915;
          } else {
            result[0] += 0.0010460194574251785;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3850000000000000644) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += -0.0017259649315642797;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1550000000000000266) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
                  result[0] += 0.00012996992940352822;
                } else {
                  result[0] += -0.0008502253612391211;
                }
              } else {
                result[0] += -0.0018788650822694594;
              }
            } else {
              result[0] += 0.0003754443056068725;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2070775000000000254) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7293938685427137081) ) ) {
              result[0] += -0.00029426765167725726;
            } else {
              result[0] += -0.0008100353866747513;
            }
          } else {
            result[0] += 0.0026426668961019232;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03536067803908965468) ) ) {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4589535259190716254) ) ) {
            result[0] += 0.0009288175119769587;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7550000000000001155) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.650000000000000541e-05) ) ) {
                result[0] += 0.0009471532212584166;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.003471267049314800176) ) ) {
                  result[0] += -0.0005470121822633561;
                } else {
                  result[0] += 7.708669143889068e-05;
                }
              }
            } else {
              result[0] += 0.0005186984694417873;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03759900000000000742) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.051391296366422923) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)26.50000000000000355) ) ) {
                result[0] += 7.317861993473897e-05;
              } else {
                result[0] += 0.0009503520595079272;
              }
            } else {
              result[0] += -0.0007033184975708258;
            }
          } else {
            result[0] += 0.0015362348799162922;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05403737693237045669) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.08390973343508316418) ) ) {
          result[0] += 0.0008318444142110789;
        } else {
          result[0] += 0.0005632004582715219;
        }
      } else {
        result[0] += 0.0009432004447525682;
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        result[0] += 0.0010186400196449698;
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04324794178047625809) ) ) {
          result[0] += 0.0009494415576287782;
        } else {
          result[0] += 0.0009494415576287782;
        }
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8950000000000001288) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0014555209059943263;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00279350000000000041) ) ) {
              result[0] += -0.0014106967428363264;
            } else {
              result[0] += -0.0009862968885816284;
            }
          } else {
            result[0] += -0.0015586058315689283;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.115000000000000005) ) ) {
            result[0] += -0.0012026777734873144;
          } else {
            result[0] += 0.0010160921631258578;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6650000000000001465) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1950000000000000344) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += -0.0015754981114242423;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += 0.0010509485327866016;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09856400000000001271) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8170108803768846295) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)45.50000000000000711) ) ) {
                    result[0] += -0.0009601517018244083;
                  } else {
                    result[0] += -0.0003749835177055408;
                  }
                } else {
                  result[0] += -0.0012423348770828854;
                }
              } else {
                result[0] += 0.000801852704056143;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7293938685427137081) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1737935000000000174) ) ) {
              result[0] += -0.00015423526826343958;
            } else {
              result[0] += 0.002311305769947342;
            }
          } else {
            result[0] += -0.0007376704911227428;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7250000000000000888) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.144071500000000019) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3539353041941689093) ) ) {
              result[0] += 0.0009726757931482627;
            } else {
              result[0] += 0.00012185310727502748;
            }
          } else {
            result[0] += 0.0014096563387245643;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02803443610476625408) ) ) {
              result[0] += 0.0008408794642554177;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)27.50000000000000355) ) ) {
                result[0] += 0.0008247085867136663;
              } else {
                result[0] += 0.0015816038912951104;
              }
            }
          } else {
            result[0] += 0.0003118368553788497;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05403737693237045669) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007249500000000001602) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9550000000000000711) ) ) {
            result[0] += 0.0006742211820477155;
          } else {
            result[0] += 0.0008080448066429565;
          }
        } else {
          result[0] += 0.0007441010923145605;
        }
      } else {
        result[0] += 0.0009162148690130455;
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        result[0] += 0.0009894960687972262;
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04324794178047625809) ) ) {
          result[0] += 0.0009222774196068098;
        } else {
          result[0] += 0.0009222774196068098;
        }
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8950000000000001288) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0014138775099721043;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00279350000000000041) ) ) {
              result[0] += -0.0013703357951596184;
            } else {
              result[0] += -0.0009580782956658286;
            }
          } else {
            result[0] += -0.00151401310904652;
          }
        } else {
          result[0] += -0.0011085075941087415;
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6650000000000001465) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.29500000000000004) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1550000000000000266) ) ) {
              result[0] += -0.0016315847134664044;
            } else {
              result[0] += -0.0007372254150980361;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.752860906001682428) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += 0.0011692224493683576;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.144071500000000019) ) ) {
                  result[0] += -0.0005920454395539205;
                } else {
                  result[0] += 0.0012591436012986074;
                }
              }
            } else {
              result[0] += -0.0022716515443703816;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02092750000000000513) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
              result[0] += 0.00044778008260477073;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
                result[0] += -0.0004419171328235694;
              } else {
                result[0] += -0.0018228452819699073;
              }
            }
          } else {
            result[0] += 0.0004341530271342247;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04557577292723340862) ) ) {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3539353041941689093) ) ) {
            result[0] += 0.0009182727448495246;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7550000000000001155) ) ) {
              result[0] += 8.352112700649514e-05;
            } else {
              result[0] += 0.00048334021790512685;
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)96.50000000000001421) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1645630000000000426) ) ) {
              result[0] += 0.0005060047735683621;
            } else {
              result[0] += 0.0014711087326305858;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.04034505340375655474) ) ) {
              result[0] += 0.0017862708208214743;
            } else {
              result[0] += 0.0011061230354854391;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03296628516090911037) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007249500000000001602) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9450000000000000622) ) ) {
            result[0] += 0.0006854445852883306;
          } else {
            result[0] += 0.0007779351212041742;
          }
        } else {
          result[0] += 0.0006421656378112313;
        }
      } else {
        result[0] += 0.0008779638883678222;
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        result[0] += 0.000961185945262994;
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04324794178047625809) ) ) {
          result[0] += 0.0008958904651708633;
        } else {
          result[0] += 0.0008958904651708633;
        }
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8950000000000001288) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.001373425558487107;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00279350000000000041) ) ) {
              result[0] += -0.0013311296003421862;
            } else {
              result[0] += -0.0009306670549736506;
            }
          } else {
            result[0] += -0.001470696213203111;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7562503571356784526) ) ) {
            result[0] += -0.0010263464726664776;
          } else {
            result[0] += -0.0012362850504163646;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4650000000000000244) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1950000000000000344) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += -0.0014828154592807679;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.115000000000000005) ) ) {
              result[0] += -0.000661613102632284;
            } else {
              result[0] += -3.317795479850671e-05;
            }
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5458973873869347182) ) ) {
              result[0] += -3.717228375615357e-05;
            } else {
              result[0] += 0.0012261691929255963;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03241729119215525784) ) ) {
              result[0] += -0.0005814774410997283;
            } else {
              result[0] += 0.00014562469288469;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03507550000000000251) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7250000000000000888) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
              result[0] += 0.0012451051411027734;
            } else {
              result[0] += 8.81544043245071e-05;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01437243042433420173) ) ) {
                result[0] += 0.000563230155989941;
              } else {
                result[0] += 0.0013246884446405575;
              }
            } else {
              result[0] += 0.0002553314582661613;
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03415342701090800376) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5351847540954774995) ) ) {
              result[0] += 0.0014435932015102939;
            } else {
              result[0] += -0.0005086336057681059;
            }
          } else {
            result[0] += 0.0013319730598742282;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03296628516090911037) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007249500000000001602) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9550000000000000711) ) ) {
            result[0] += 0.0006595924914353822;
          } else {
            result[0] += 0.0007626688934928011;
          }
        } else {
          result[0] += 0.0006237928629118084;
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)77.50000000000001421) ) ) {
          result[0] += 0.0007391460485904588;
        } else {
          result[0] += 0.0009802289454077617;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        result[0] += 0.000933685792702674;
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04324794178047625809) ) ) {
          result[0] += 0.0008702584585950742;
        } else {
          result[0] += 0.0008702584585950742;
        }
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8950000000000001288) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0013341309635392946;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00279350000000000041) ) ) {
              result[0] += -0.0012930451201566657;
            } else {
              result[0] += -0.0009040400676349652;
            }
          } else {
            result[0] += -0.0014286186418109225;
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
            result[0] += -0.0008765746639370876;
          } else {
            result[0] += -0.0011688810789591175;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6650000000000001465) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.29500000000000004) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003732500000000000574) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)91.50000000000001421) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4674830972361809223) ) ) {
                result[0] += -0.00021605407388869687;
              } else {
                result[0] += -0.0014317469177676926;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.06536400211476856) ) ) {
                result[0] += -0.00043854787486086503;
              } else {
                result[0] += -0.0015358305434952223;
              }
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7293938685427137081) ) ) {
              result[0] += -0.0002309023818592348;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01225471801880190052) ) ) {
                result[0] += -0.001567834637417331;
              } else {
                result[0] += -0.0005813813203168475;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08936750000000000249) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
              result[0] += -0.00012366727697941284;
            } else {
              result[0] += -0.0014282890551400107;
            }
          } else {
            result[0] += 0.0009059639518928054;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.144071500000000019) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01871178646485605404) ) ) {
              result[0] += 0.0004246626849952258;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)39.50000000000000711) ) ) {
                result[0] += 0.0002634767030087688;
              } else {
                result[0] += 0.001555795694499206;
              }
            }
          } else {
            result[0] += 0.00014980268348339264;
          }
        } else {
          result[0] += 0.0012402826770385666;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05403737693237045669) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007249500000000001602) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9550000000000000711) ) ) {
            result[0] += 0.0006144598336947076;
          } else {
            result[0] += 0.0007408484423850571;
          }
        } else {
          result[0] += 0.0006829187174710084;
        }
      } else {
        result[0] += 0.0008437348051997985;
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07184972061993401271) ) ) {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.9546544174008676498) ) ) {
          result[0] += 0.0008453598003321015;
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01344341525633075199) ) ) {
            result[0] += 0.0008453598003321015;
          } else {
            result[0] += 0.0008453598003321015;
          }
        }
      } else {
        result[0] += 0.0008453598003321015;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8950000000000001288) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0012959606124083901;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4737195465326633492) ) ) {
              result[0] += 0.0005106896059984352;
            } else {
              result[0] += -0.001253713454560192;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
              result[0] += -0.0013877449369945566;
            } else {
              result[0] += -0.0013877449369945566;
            }
          }
        } else {
          result[0] += -0.0010139855913949688;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4650000000000000244) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2750000000000000777) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1650000000000000355) ) ) {
                result[0] += -0.0014129854190932363;
              } else {
                result[0] += -0.0005626937844742124;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05500000000000000722) ) ) {
                  result[0] += -0.000302081335323177;
                } else {
                  result[0] += 0.0014416910183267866;
                }
              } else {
                result[0] += -0.0005500957739786457;
              }
            }
          } else {
            result[0] += -0.0016511928555096094;
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
            result[0] += 0.00013403590707279208;
          } else {
            result[0] += -0.00036674974863421466;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03507550000000000251) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7250000000000000888) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.650000000000000541e-05) ) ) {
              result[0] += 0.0012128230856988474;
            } else {
              result[0] += 7.937786958226894e-05;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01437243042433420173) ) ) {
                result[0] += 0.0005367509898887586;
              } else {
                result[0] += 0.0012726048069838809;
              }
            } else {
              result[0] += 0.0002411261147397475;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04557577292723340862) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5521365942211056144) ) ) {
              result[0] += 0.0012831323640632197;
            } else {
              result[0] += -0.0002694184401068864;
            }
          } else {
            result[0] += 0.0013547330190838247;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05403737693237045669) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.08693186820944626136) ) ) {
          result[0] += 0.0007228702779290262;
        } else {
          result[0] += 0.0004666981356867983;
        }
      } else {
        result[0] += 0.000819595005842766;
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07184972061993401271) ) ) {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.9546544174008676498) ) ) {
          result[0] += 0.0008211735088116469;
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01344341525633075199) ) ) {
            result[0] += 0.0008211735088116469;
          } else {
            result[0] += 0.0008211735088116469;
          }
        }
      } else {
        result[0] += 0.0008211735088116469;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8950000000000001288) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.001258882339750495;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.568345700351758909) ) ) {
              result[0] += -0.0005754389053934912;
            } else {
              result[0] += -0.0012390265289627927;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
              result[0] += -0.0013480406553514023;
            } else {
              result[0] += -0.0013480406553514023;
            }
          }
        } else {
          result[0] += -0.0009849748067546468;
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5350000000000001421) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1950000000000000344) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)75.50000000000001421) ) ) {
                result[0] += -0.0016982315518891129;
              } else {
                result[0] += -0.0009861137414472155;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05500000000000000722) ) ) {
                  result[0] += -0.0002934385926281206;
                } else {
                  result[0] += 0.0014004433043498794;
                }
              } else {
                result[0] += -0.0005468938610983766;
              }
            }
          } else {
            result[0] += -0.00027199219498203343;
          }
        } else {
          result[0] += -0.001444847102478881;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04557577292723340862) ) ) {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3539353041941689093) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)88.50000000000001421) ) ) {
              result[0] += 0.0004441984281913354;
            } else {
              result[0] += 0.0013450009383996569;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7150000000000000799) ) ) {
              result[0] += -1.4556725040662409e-05;
            } else {
              result[0] += 0.00037583025963544743;
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)96.50000000000001421) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1645630000000000426) ) ) {
              result[0] += 0.0004597503219670146;
            } else {
              result[0] += 0.001346959222885391;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.04034505340375655474) ) ) {
              result[0] += 0.0016713677164037445;
            } else {
              result[0] += 0.0010326992311492252;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05403737693237045669) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9650000000000000799) ) ) {
          result[0] += 0.0006087003223640828;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007249500000000001602) ) ) {
            result[0] += 0.0006989705015845148;
          } else {
            result[0] += 0.0006538864782567115;
          }
        }
      } else {
        result[0] += 0.0007961458617833561;
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07184972061993401271) ) ) {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.9546544174008676498) ) ) {
          result[0] += 0.0007976792027597262;
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01344341525633075199) ) ) {
            result[0] += 0.0007976792027597262;
          } else {
            result[0] += 0.0007976792027597262;
          }
        }
      } else {
        result[0] += 0.0007976792027597262;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8950000000000001288) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0012228649004930366;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00279350000000000041) ) ) {
              result[0] += -0.0011906030452313392;
            } else {
              result[0] += -0.0008262093691998205;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
              result[0] += -0.0013094723389269092;
            } else {
              result[0] += -0.0013094723389269092;
            }
          }
        } else {
          result[0] += -0.0009567940394563753;
        }
      }
    } else {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4550000000000000711) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.323165429195979903) ) ) {
            result[0] += 0.0010310141111493794;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02283043124822940403) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.07500000000000002498) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)32.50000000000000711) ) ) {
                  result[0] += -0.0012309487197421694;
                } else {
                  result[0] += -0.0008197332677234468;
                }
              } else {
                result[0] += -0.0005613296498817564;
              }
            } else {
              result[0] += -4.468417700066449e-05;
            }
          }
        } else {
          result[0] += -0.0014345992398385795;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7250000000000000888) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1737935000000000174) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3539353041941689093) ) ) {
              result[0] += 0.0007766237219398941;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7831470153266332224) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03415342701090800376) ) ) {
                  result[0] += -2.396176502769879e-05;
                } else {
                  result[0] += 0.0006783226157157148;
                }
              } else {
                result[0] += -0.0004955228676735076;
              }
            }
          } else {
            result[0] += 0.0016346562655846642;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02803443610476625408) ) ) {
              result[0] += 0.000743788762533879;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)27.50000000000000355) ) ) {
                result[0] += 0.0006809640398116888;
              } else {
                result[0] += 0.0013875399618682354;
              }
            }
          } else {
            result[0] += 0.0002422154539803207;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9650000000000000799) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
          result[0] += 0.0011383770362861285;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.08693186820944626136) ) ) {
            result[0] += 0.0006873285150637932;
          } else {
            result[0] += 0.00042158849752818995;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01504150000000000105) ) ) {
          result[0] += 0.0006789725027337524;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07802786554345496339) ) ) {
            result[0] += 0.0005957105627507425;
          } else {
            result[0] += 0.0008364697210136964;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0416553728637082607) ) ) {
        result[0] += 0.0007748570840238074;
      } else {
        result[0] += 0.0007748570840238074;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0011878779435052095;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.568345700351758909) ) ) {
              if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05227730674148379358) ) ) {
                result[0] += -0.0013846708941639108;
              } else {
                result[0] += 0.0006355195725701197;
              }
            } else {
              result[0] += -0.0011730128634358469;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
              result[0] += -0.001272007487020281;
            } else {
              result[0] += -0.001272007487020281;
            }
          }
        } else {
          result[0] += -0.0009294195421663042;
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6650000000000001465) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.29500000000000004) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003520500000000000625) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)90.50000000000001421) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4674830972361809223) ) ) {
                  result[0] += -0.00017874083815965484;
                } else {
                  result[0] += -0.001300542177113149;
                }
              } else {
                result[0] += -0.0005391052219479193;
              }
            } else {
              result[0] += -0.00030194651723715733;
            }
          } else {
            result[0] += -0.0014743000016403977;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08936750000000000249) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.000726282482777400166) ) ) {
                result[0] += 0.0005268298794291915;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.008408953333664601418) ) ) {
                  result[0] += -0.0007982393318801016;
                } else {
                  result[0] += 4.0973083810862136e-05;
                }
              }
            } else {
              result[0] += -0.001311963599636195;
            }
          } else {
            result[0] += 0.0009124957873758492;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.144071500000000019) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01871178646485605404) ) ) {
              result[0] += 0.0003913327905844826;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)39.50000000000000711) ) ) {
                result[0] += 0.0002671960633442184;
              } else {
                result[0] += 0.0014253229381017405;
              }
            }
          } else {
            result[0] += 0.00013161192459989386;
          }
        } else {
          result[0] += 0.0011168923068262588;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9650000000000000799) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
          result[0] += 0.0011064116142339051;
        } else {
          result[0] += 0.0005269322203264023;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01504150000000000105) ) ) {
          result[0] += 0.0006595466595850242;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07802786554345496339) ) ) {
            result[0] += 0.0005786668976428863;
          } else {
            result[0] += 0.0008125377804216271;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0416553728637082607) ) ) {
        result[0] += 0.0007526879208893321;
      } else {
        result[0] += 0.0007526879208893321;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.001153891986021722;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.568345700351758909) ) ) {
              if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05227730674148379358) ) ) {
                result[0] += -0.0013450545628775382;
              } else {
                result[0] += 0.0006173369459026373;
              }
            } else {
              result[0] += -0.0011394522055228988;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
              result[0] += -0.0012356145287968259;
            } else {
              result[0] += -0.0012356145287968259;
            }
          }
        } else {
          result[0] += -0.0009028282469771889;
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6650000000000001465) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.29500000000000004) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1550000000000000266) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)49.50000000000000711) ) ) {
                  result[0] += -0.0018238123298504711;
                } else {
                  result[0] += -0.0009925739764981552;
                }
              } else {
                result[0] += -0.0016669225545751763;
              }
            } else {
              result[0] += -0.0005930642215068118;
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4629970383791919275) ) ) {
              result[0] += 0.0007086684745791377;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1177750000000000186) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05500000000000000722) ) ) {
                    result[0] += -0.0003099721596058923;
                  } else {
                    result[0] += 0.0012152981724295458;
                  }
                } else {
                  result[0] += -0.0006379908832218068;
                }
              } else {
                result[0] += 0.0007538480670597299;
              }
            }
          }
        } else {
          result[0] += -0.0001118069226666974;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.144071500000000019) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01871178646485605404) ) ) {
              result[0] += 0.000380136505936371;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)41.50000000000000711) ) ) {
                result[0] += 0.00027151052060595167;
              } else {
                result[0] += 0.0013740938825141053;
              }
            }
          } else {
            result[0] += 0.00012784642217750496;
          }
        } else {
          result[0] += 0.0010849372943933983;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9650000000000000799) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
          result[0] += 0.0010747564612056146;
        } else {
          result[0] += 0.0005118563481506393;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01289050000000000092) ) ) {
          result[0] += 0.0006406766023930464;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07802786554345496339) ) ) {
            result[0] += 0.0005690084006888053;
          } else {
            result[0] += 0.000789290548153258;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0416553728637082607) ) ) {
        result[0] += 0.0007311530318735505;
      } else {
        result[0] += 0.0007311530318735505;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0011208783887982974;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00279350000000000041) ) ) {
              result[0] += -0.0011033521292434913;
            } else {
              result[0] += -0.0007364098602578497;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
              result[0] += -0.0012002627966838841;
            } else {
              result[0] += -0.0012002627966838841;
            }
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
            result[0] += -0.0007145074495221638;
          } else {
            result[0] += -0.0009984507886512482;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5250000000000001332) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.29500000000000004) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003520500000000000625) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)90.50000000000001421) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4674830972361809223) ) ) {
                  result[0] += -0.00012563309612788595;
                } else {
                  result[0] += -0.0012404618115686482;
                }
              } else {
                result[0] += -0.0005062999160648815;
              }
            } else {
              result[0] += -0.00028360624662623283;
            }
          } else {
            result[0] += -0.001409111515481991;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09550850000000001006) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
              result[0] += -2.3664783968101746e-05;
            } else {
              result[0] += -0.0006559350545107511;
            }
          } else {
            result[0] += 0.0010236087988262836;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03507550000000000251) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7450000000000001066) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.650000000000000541e-05) ) ) {
              result[0] += 0.0013129906581921757;
            } else {
              result[0] += 0.00013230836772446357;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
              result[0] += 0.0009124669194132073;
            } else {
              result[0] += 0.0002353967733899495;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05067558311325295883) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5521365942211056144) ) ) {
              result[0] += 0.0011445646549752887;
            } else {
              result[0] += -7.253772456749072e-05;
            }
          } else {
            result[0] += 0.0012009456740256887;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9650000000000000799) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
          result[0] += 0.0010440069826120034;
        } else {
          result[0] += 0.0004972118064441328;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007249500000000001602) ) ) {
          result[0] += 0.0006223464297615507;
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02844215559246820318) ) ) {
            result[0] += 0.0005004841168918722;
          } else {
            result[0] += 0.0007667084342598898;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0416553728637082607) ) ) {
        result[0] += 0.0007102342699830379;
      } else {
        result[0] += 0.0007102342699830379;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0010888093319779896;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00279350000000000041) ) ) {
              result[0] += -0.0010717845100627415;
            } else {
              result[0] += -0.0007153406971018337;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
              result[0] += -0.0011659225005279169;
            } else {
              result[0] += -0.0011659225005279169;
            }
          }
        } else {
          result[0] += -0.0008542596731522687;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5750000000000000666) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.29500000000000004) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003520500000000000625) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)72.50000000000001421) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4674830972361809223) ) ) {
                  result[0] += 2.348399010746112e-05;
                } else {
                  result[0] += -0.0012245162096976537;
                }
              } else {
                result[0] += -0.0005443931034293901;
              }
            } else {
              result[0] += -0.00027567474058162055;
            }
          } else {
            result[0] += -0.0013687959221868177;
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5800027599246232457) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02620539606947270075) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
                result[0] += 0.000849063283497233;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.006697829966773901147) ) ) {
                  result[0] += -0.0005593326732263312;
                } else {
                  result[0] += 0.00014605542016630894;
                }
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)97.50000000000001421) ) ) {
                result[0] += 0.0006162475099758172;
              } else {
                result[0] += 0.0023659596682269993;
              }
            }
          } else {
            result[0] += -0.00024808377779878395;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03507550000000000251) ) ) {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3539353041941689093) ) ) {
            result[0] += 0.0007680637640371926;
          } else {
            result[0] += 0.0002497666178120204;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04557577292723340862) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7293938685427137081) ) ) {
              result[0] += 0.0009356782218812647;
            } else {
              result[0] += -0.000834087064178028;
            }
          } else {
            result[0] += 0.001155127211381097;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
          result[0] += 0.0009832402022587612;
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.08693186820944626136) ) ) {
            result[0] += 0.000655102962723463;
          } else {
            result[0] += 0.0003979135003050719;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01471700000000000265) ) ) {
          result[0] += 0.0006045406952435214;
        } else {
          result[0] += 0.000744772409273942;
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0416553728637082607) ) ) {
        result[0] += 0.0006899140074216056;
      } else {
        result[0] += 0.0006899140074216056;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0010576577916479827;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00279350000000000041) ) ) {
              result[0] += -0.001041120060916588;
            } else {
              result[0] += -0.0006948743363525365;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
              result[0] += -0.0011325647024909764;
            } else {
              result[0] += -0.0011325647024909764;
            }
          }
        } else {
          result[0] += -0.0008298187505049969;
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6650000000000001465) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)49.50000000000000711) ) ) {
                result[0] += -0.0017253451279837125;
              } else {
                result[0] += -0.0009123031918323834;
              }
            } else {
              result[0] += -0.00157182385078963;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05500000000000000722) ) ) {
                result[0] += -0.00026775672129929933;
              } else {
                result[0] += 0.001336472924408;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.115000000000000005) ) ) {
                result[0] += -0.000746025331480358;
              } else {
                result[0] += 0.00016336637570323363;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2070775000000000254) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5458973873869347182) ) ) {
                result[0] += -8.507139469098554e-05;
              } else {
                result[0] += 0.0012311296660783256;
              }
            } else {
              result[0] += -0.00041072239789518287;
            }
          } else {
            result[0] += 0.0021945829943191574;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.144071500000000019) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01871178646485605404) ) ) {
              result[0] += 0.0003446788685215407;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)41.50000000000000711) ) ) {
                result[0] += 0.00023486675880952135;
              } else {
                result[0] += 0.0012910331145869244;
              }
            }
          } else {
            result[0] += 0.00011347920288919488;
          }
        } else {
          result[0] += 0.0009873635754400684;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9650000000000000799) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
          result[0] += 0.0009860061273808426;
        } else {
          result[0] += 0.00046681304369360814;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007249500000000001602) ) ) {
          result[0] += 0.0005872443943247949;
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02844215559246820318) ) ) {
            result[0] += 0.00046485652098801687;
          } else {
            result[0] += 0.0007234639881732281;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0416553728637082607) ) ) {
        result[0] += 0.0006701751207357368;
      } else {
        result[0] += 0.0006701751207357368;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0010273975170671122;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00279350000000000041) ) ) {
              result[0] += -0.0010113329415252584;
            } else {
              result[0] += -0.0006749935314425996;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
              result[0] += -0.0011001612926654044;
            } else {
              result[0] += -0.0011001612926654044;
            }
          }
        } else {
          result[0] += -0.00080607709848775;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5750000000000000666) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.29500000000000004) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003520500000000000625) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)72.50000000000001421) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4674830972361809223) ) ) {
                  result[0] += 2.524604564956256e-05;
                } else {
                  result[0] += -0.0011758338429136807;
                }
              } else {
                result[0] += -0.0005189993125153715;
              }
            } else {
              result[0] += -0.0002585247306088475;
            }
          } else {
            result[0] += -0.001317882750258621;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02664459509800340062) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
                result[0] += 0.0005686288412381573;
              } else {
                result[0] += -0.00020541112709830748;
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)89.50000000000001421) ) ) {
                result[0] += 0.0002572724507920569;
              } else {
                result[0] += 0.0015720622132169282;
              }
            }
          } else {
            result[0] += -0.00044388455448747706;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03507550000000000251) ) ) {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3539353041941689093) ) ) {
            result[0] += 0.000736227476473329;
          } else {
            result[0] += 0.0002304542642435507;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05067558311325295883) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7293938685427137081) ) ) {
              result[0] += 0.0008695036108010008;
            } else {
              result[0] += -0.000691322262778763;
            }
          } else {
            result[0] += 0.0011099094705286367;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05403737693237045669) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9650000000000000799) ) ) {
          result[0] += 0.0004953415774999951;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01289050000000000092) ) ) {
            result[0] += 0.0005704429517800788;
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)322.5000000000000568) ) ) {
              result[0] += 0.0004365408974360067;
            } else {
              result[0] += 0.0006152254011779328;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)43.50000000000000711) ) ) {
          result[0] += 0.0006309395159358674;
        } else {
          result[0] += 0.0007027652148040243;
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0416553728637082607) ) ) {
        result[0] += 0.0006510009763850076;
      } else {
        result[0] += 0.0006510009763850076;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.000998003008544924;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00279350000000000041) ) ) {
              result[0] += -0.0009823980509161229;
            } else {
              result[0] += -0.0006556815292401305;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
              result[0] += -0.0010686849653862112;
            } else {
              result[0] += -0.0010686849653862112;
            }
          }
        } else {
          result[0] += -0.0007830147105148076;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3850000000000000644) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02085144663384500344) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4296173751758793902) ) ) {
              result[0] += 0.0003101423662865916;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)45.50000000000000711) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1250000000000000278) ) ) {
                  result[0] += -0.0012201331697565827;
                } else {
                  result[0] += -0.0006607494873816463;
                }
              } else {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7210440605025126848) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)810.5000000000001137) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6010141514957837439) ) ) {
                      result[0] += -0.0004548900101789422;
                    } else {
                      result[0] += 0.0005774081107354684;
                    }
                  } else {
                    result[0] += 0.001830320664381375;
                  }
                } else {
                  result[0] += -0.0007813836668957986;
                }
              }
            }
          } else {
            result[0] += 8.634164619751823e-05;
          }
        } else {
          result[0] += -0.0012222734802025453;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7250000000000000888) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1737935000000000174) ) ) {
            result[0] += 0.00013368725517658376;
          } else {
            result[0] += 0.001335945883775522;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
              result[0] += 0.0006320516206495639;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)27.50000000000000355) ) ) {
                result[0] += 0.000616831799643033;
              } else {
                result[0] += 0.0011861819873383189;
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07959200000000000996) ) ) {
              result[0] += 0.00017863667736328423;
            } else {
              result[0] += 0.0008842658341909291;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9650000000000000799) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
          result[0] += 0.0009411688799191241;
        } else {
          result[0] += 0.00043928517668739587;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007249500000000001602) ) ) {
          result[0] += 0.0005541222093907168;
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02844215559246820318) ) ) {
            result[0] += 0.000439066956912192;
          } else {
            result[0] += 0.0006826586467497958;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0416553728637082607) ) ) {
        result[0] += 0.0006323754167253642;
      } else {
        result[0] += 0.0006323754167253642;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9450000000000000622) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0009694494959536267;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.568345700351758909) ) ) {
                result[0] += -0.0006335605428730767;
              } else {
                result[0] += -0.001013723495893836;
              }
            } else {
              result[0] += -5.6208516246502626e-05;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.001038109196221171;
              } else {
                result[0] += -0.0004094259855318349;
              }
            } else {
              result[0] += -0.001038109196221171;
            }
          }
        } else {
          result[0] += -0.0007606121524018286;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6150000000000001021) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.29500000000000004) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1550000000000000266) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
                result[0] += -0.0011754865503532735;
              } else {
                result[0] += -0.0014221066751810873;
              }
            } else {
              result[0] += -0.00046522060550076397;
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4629970383791919275) ) ) {
              result[0] += 0.0007026572116693141;
            } else {
              result[0] += -0.00041606196432906583;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1737935000000000174) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02085144663384500344) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
                  result[0] += 0.0005636650284359183;
                } else {
                  result[0] += -0.00022980543697348295;
                }
              } else {
                result[0] += 0.00046405038322180745;
              }
            } else {
              result[0] += -0.00044280351783449194;
            }
          } else {
            result[0] += 0.001282353067473678;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05403737693237045669) ) ) {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3539353041941689093) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)69.50000000000001421) ) ) {
              result[0] += 0.00036087426896875386;
            } else {
              result[0] += 0.0011067623154655726;
            }
          } else {
            result[0] += 0.0002787724093420537;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)26.50000000000000355) ) ) {
            result[0] += 0.00034311828376071155;
          } else {
            result[0] += 0.000876221190924345;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05403737693237045669) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.07172822906307056712) ) ) {
          result[0] += 0.0005521142905092535;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01439950000000000084) ) ) {
            result[0] += 0.0004719548486985737;
          } else {
            result[0] += 0.00021713088655582084;
          }
        }
      } else {
        result[0] += 0.0006631273406328464;
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0416553728637082607) ) ) {
        result[0] += 0.000614282746393418;
      } else {
        result[0] += 0.000614282746393418;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9450000000000000622) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0009417129178548316;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8030059940338053481) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += -0.0009800465958544158;
            } else {
              result[0] += -6.310084386591973e-05;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.001008408219619247;
              } else {
                result[0] += -0.00044897479985909924;
              }
            } else {
              result[0] += -0.001008408219619247;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06439350000000000629) ) ) {
            result[0] += -0.000833293821477807;
          } else {
            result[0] += 0.00019893565811540957;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6150000000000001021) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.29500000000000004) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1550000000000000266) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)49.50000000000000711) ) ) {
                  result[0] += -0.0015518242033683992;
                } else {
                  result[0] += -0.000833219436763771;
                }
              } else {
                result[0] += -0.0013814192819485214;
              }
            } else {
              result[0] += -0.00045191034260259454;
            }
          } else {
            result[0] += -0.0003402747855441997;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2070775000000000254) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02085144663384500344) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
                  result[0] += 0.0005475382068242436;
                } else {
                  result[0] += -0.00022323055455129674;
                }
              } else {
                result[0] += 0.0004870814068781712;
              }
            } else {
              result[0] += -0.0004332572421134465;
            }
          } else {
            result[0] += 0.001780550656846866;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02937690275817125482) ) ) {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3539353041941689093) ) ) {
            result[0] += 0.0007426120255397563;
          } else {
            result[0] += 0.00018810963480703135;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)41.50000000000000711) ) ) {
            result[0] += 0.0003043949472230172;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.08693186820944626136) ) ) {
              result[0] += 0.0010298624512130132;
            } else {
              result[0] += 0.00048734898222127206;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05403737693237045669) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007249500000000001602) ) ) {
          result[0] += 0.0005224720664969606;
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)111.5000000000000142) ) ) {
            result[0] += 0.0003887235259307307;
          } else {
            result[0] += 0.0005614466150175591;
          }
        }
      } else {
        result[0] += 0.0006441548378364857;
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0416553728637082607) ) ) {
        result[0] += 0.0005967077190802899;
      } else {
        result[0] += 0.0005967077190802899;
      }
    }
  }
}

