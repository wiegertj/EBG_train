
#include "header.h"

void predict_unit8(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.0002805681784926047;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6750000000000001554) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.00030156470696309943;
              } else {
                result[0] += -0.0001749680401966657;
              }
            } else {
              result[0] += -0.0003025049037035315;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003637500000000000542) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.09500000000000001499) ) ) {
                result[0] += -0.0004211019142490836;
              } else {
                result[0] += -0.00017838769509870303;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007787546829340650199) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8030059940338053481) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6055650374709939943) ) ) {
                    result[0] += -0.00034294452567984484;
                  } else {
                    result[0] += 0.003065197726326757;
                  }
                } else {
                  result[0] += -0.0007819784062733762;
                }
              } else {
                result[0] += 0.000157958908616958;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8950000000000001288) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01287800000000000229) ) ) {
              result[0] += 3.939790094931524e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6915080527790725684) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6722423356281408413) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2795185878002977575) ) ) {
                      result[0] += 0.0010646353511634885;
                    } else {
                      result[0] += 0.00039471145892844154;
                    }
                  } else {
                    result[0] += -0.00024882505740778365;
                  }
                } else {
                  result[0] += 0.0014975999948050656;
                }
              } else {
                result[0] += -0.00023865876234368266;
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0229305563329877532) ) ) {
                result[0] += 0.00022796659637400283;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1604180000000000328) ) ) {
                  result[0] += 0.00031628185377520057;
                } else {
                  result[0] += 0.00017417228157243762;
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05473596564878090848) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2108839252750100701) ) ) {
                  result[0] += 0.00024525213607317324;
                } else {
                  result[0] += 8.583471753591118e-06;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7322719660050253099) ) ) {
                  result[0] += 0.0002041007637180409;
                } else {
                  result[0] += -7.641151825697681e-05;
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
          result[0] += -0.0004435902932089365;
        } else {
          result[0] += -0.0002162531718050909;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 0.00018694655315666455;
        } else {
          result[0] += 0.00018694655315666455;
        }
      } else {
        result[0] += 0.00018694655315666455;
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 0.00018694655315666455;
        } else {
          result[0] += 0.00018694655315666455;
        }
      } else {
        result[0] += 0.00018694655315666455;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.00027061751156180134;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6750000000000001554) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.00029086937446603145;
              } else {
                result[0] += -0.00016876260128735463;
              }
            } else {
              result[0] += -0.0002917762260685234;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003637500000000000542) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.09500000000000001499) ) ) {
                result[0] += -0.00040616705985779415;
              } else {
                result[0] += -0.00017206097427092506;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04853104146385620737) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7322719660050253099) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6055650374709939943) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6161319161557790025) ) ) {
                      result[0] += 0.00010634026849156468;
                    } else {
                      result[0] += -0.0006087820943656863;
                    }
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.606193063154585432) ) ) {
                      result[0] += 0.00916599259714902;
                    } else {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7255694492462312351) ) ) {
                        result[0] += 4.834152260939638e-05;
                      } else {
                        result[0] += 0.00358885233189518;
                      }
                    }
                  }
                } else {
                  result[0] += -0.0004221881392052979;
                }
              } else {
                result[0] += 0.0009325821206802626;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8950000000000001288) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01287800000000000229) ) ) {
              result[0] += 3.800060995136369e-05;
            } else {
              result[0] += 0.00036050051110389936;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0229305563329877532) ) ) {
                result[0] += 0.00021988150388755522;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1604180000000000328) ) ) {
                  result[0] += 0.0003050645610655182;
                } else {
                  result[0] += 0.00016799506514034916;
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01127328256994905228) ) ) {
                result[0] += -1.5470908336697856e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.06355808660527756393) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.020650504707780553) ) ) {
                    result[0] += 0.00019686209990736888;
                  } else {
                    result[0] += 0.00027267583642261303;
                  }
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1149262718553918233) ) ) {
                    result[0] += 9.550192188851132e-06;
                  } else {
                    result[0] += 0.00022569652920430766;
                  }
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
          result[0] += -0.0004278578630909719;
        } else {
          result[0] += -0.00020858350913370935;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 0.00018031628277347995;
        } else {
          result[0] += 0.00018031628277347995;
        }
      } else {
        result[0] += 0.00018031628277347995;
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 0.00018031628277347995;
        } else {
          result[0] += 0.00018031628277347995;
        }
      } else {
        result[0] += 0.00018031628277347995;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.00026101975625803913;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1450000000000000455) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              result[0] += -0.00028055336400029405;
            } else {
              result[0] += -0.00028142805308777605;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8697742174477757215) ) ) {
                result[0] += -6.389813714127417e-05;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7190147863316583843) ) ) {
                  result[0] += -0.00021991532241540736;
                } else {
                  result[0] += 0.0031785759901645796;
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7983409114572864729) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7686690743216081367) ) ) {
                  result[0] += -0.00029866257408596593;
                } else {
                  result[0] += -0.0006129504458292119;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.234671350732867934) ) ) {
                    result[0] += -0.00010837328368162032;
                  } else {
                    result[0] += 0.0026361924859287203;
                  }
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002519500000000000472) ) ) {
                    result[0] += 0.0006058902710230162;
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                      result[0] += -0.00025645248510206475;
                    } else {
                      result[0] += -0.0002510975753863062;
                    }
                  }
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8950000000000001288) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1773295000000000288) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
                result[0] += 0.0015253379031457462;
              } else {
                result[0] += 1.86551032072297e-05;
              }
            } else {
              result[0] += 0.0005590603538510896;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0229305563329877532) ) ) {
                result[0] += 0.00020239436931326706;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1604180000000000328) ) ) {
                  result[0] += 0.0002942451022948777;
                } else {
                  result[0] += 0.00016203693065691937;
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01127328256994905228) ) ) {
                result[0] += -1.492221512137299e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.06355808660527756393) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.020650504707780553) ) ) {
                    result[0] += 0.00018988016347394704;
                  } else {
                    result[0] += 0.00026300508030587276;
                  }
                } else {
                  result[0] += 4.801586621969288e-05;
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
          result[0] += -0.0004126834013533029;
        } else {
          result[0] += -0.00020118585970033847;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 0.0001739211624083713;
        } else {
          result[0] += 0.0001739211624083713;
        }
      } else {
        result[0] += 0.0001739211624083713;
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 0.0001739211624083713;
        } else {
          result[0] += 0.0001739211624083713;
        }
      } else {
        result[0] += 0.0001739211624083713;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.0002517623961723811;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1450000000000000455) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.503765687975615393e-05) ) ) {
                result[0] += -0.0003054585182563334;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5687531224874372571) ) ) {
                  result[0] += 0.00043871718495813364;
                } else {
                  result[0] += -0.0007377751198024047;
                }
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8697742174477757215) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.421180086331658321) ) ) {
                  result[0] += 0.0010619185986939525;
                } else {
                  result[0] += -0.0001510251089887068;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7190147863316583843) ) ) {
                  result[0] += -0.00021211577744172986;
                } else {
                  result[0] += 0.003065844207243553;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                result[0] += -0.00027060322248217126;
              } else {
                result[0] += -0.0002714468897345175;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                result[0] += -0.0007650185391549578;
              } else {
                result[0] += -0.00030304082664218767;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8950000000000001288) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2004855000000000109) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.555096866909547848) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5528143519346734314) ) ) {
                  result[0] += 0.00016538602210662833;
                } else {
                  result[0] += 0.0017802217169157273;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.55780239615577909) ) ) {
                  result[0] += -0.0017814357010548128;
                } else {
                  result[0] += -6.866852527285616e-05;
                }
              }
            } else {
              result[0] += 0.0005702612839984928;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06217080128912850362) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3750409390474713223) ) ) {
                  result[0] += 0.00039260051370496914;
                } else {
                  result[0] += 0.00015481137974671235;
                }
              } else {
                result[0] += 0.00026012186871254264;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08693186820944626136) ) ) {
                result[0] += 0.00018314584929174927;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1149262718553918233) ) ) {
                  result[0] += -1.048279065652017e-05;
                } else {
                  result[0] += 0.00021598901035334506;
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
          result[0] += -0.0003980471190179347;
        } else {
          result[0] += -0.00019405057624866164;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 0.00016775285220070078;
        } else {
          result[0] += 0.00016775285220070078;
        }
      } else {
        result[0] += 0.00016775285220070078;
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 0.00016775285220070078;
        } else {
          result[0] += 0.00016775285220070078;
        }
      } else {
        result[0] += 0.00016775285220070078;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.00024283335880445175;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6750000000000001554) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.00026100597395673614;
              } else {
                result[0] += -0.00013230206705133174;
              }
            } else {
              result[0] += -0.00026181971959832233;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04653956279752540642) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5800027599246232457) ) ) {
                result[0] += -4.745485755487999e-06;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4287309711685468594) ) ) {
                  result[0] += -0.0006709588531040245;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7425707671105529206) ) ) {
                    result[0] += 0.00015324822801876355;
                  } else {
                    result[0] += -0.00031492443508358424;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003637500000000000542) ) ) {
                result[0] += -0.0010676913724554245;
              } else {
                result[0] += 0.0008431061684219934;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08404042173159891049) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006782232836504950395) ) ) {
                result[0] += 5.613897910027924e-05;
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
                  result[0] += 0.00040111214487863553;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4093335132160804135) ) ) {
                    if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4601878067544193374) ) ) {
                      result[0] += 0.00021747130564930245;
                    } else {
                      result[0] += -0.0014898347479352116;
                    }
                  } else {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5470680148669562204) ) ) {
                      result[0] += -0.00022629040056164736;
                    } else {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3539353041941689093) ) ) {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007384500000000001306) ) ) {
                          result[0] += 0.00027168160003851553;
                        } else {
                          result[0] += 0.0005773128194459743;
                        }
                      } else {
                        result[0] += 0.0002638397868495897;
                      }
                    }
                  }
                }
              }
            } else {
              result[0] += 3.483067989209874e-05;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006064500000000001313) ) ) {
              result[0] += -7.397199547995566e-05;
            } else {
              result[0] += 0.00020832871646582306;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
          result[0] += -0.0003839299289452989;
        } else {
          result[0] += -0.00018716835367318954;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 0.0001618033080723896;
        } else {
          result[0] += 0.0001618033080723896;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01657900000000000346) ) ) {
            result[0] += 0.0001618033080723896;
          } else {
            result[0] += -4.0336926062118646e-05;
          }
        } else {
          result[0] += 0.0001618033080723896;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 0.0001618033080723896;
        } else {
          result[0] += 0.0001618033080723896;
        }
      } else {
        result[0] += 0.0001618033080723896;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.00023422099981871932;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6750000000000001554) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.00025174910267594024;
              } else {
                result[0] += -0.00012760982500678605;
              }
            } else {
              result[0] += -0.00025253398791044344;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06772339094926521641) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1773295000000000288) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                    result[0] += -0.00017262517132489357;
                  } else {
                    result[0] += 0.00037377604885864633;
                  }
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.08500000000000000611) ) ) {
                    result[0] += -0.0005752413192850298;
                  } else {
                    result[0] += -0.00013578580251730662;
                  }
                }
              } else {
                result[0] += 0.0013208337629918594;
              }
            } else {
              result[0] += 0.0007799549432889829;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08404042173159891049) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007107894154605750962) ) ) {
                result[0] += 6.190843418135269e-05;
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
                  result[0] += 0.00037296536491918727;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4093335132160804135) ) ) {
                    if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4601878067544193374) ) ) {
                      result[0] += 0.00020346948892310603;
                    } else {
                      result[0] += -0.001436996078067912;
                    }
                  } else {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3539353041941689093) ) ) {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5470680148669562204) ) ) {
                        result[0] += -0.00018128286526848385;
                      } else {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007384500000000001306) ) ) {
                          result[0] += 0.00026204610563663517;
                        } else {
                          result[0] += 0.0005555947840428996;
                        }
                      }
                    } else {
                      result[0] += 0.00025012069951703625;
                    }
                  }
                }
              }
            } else {
              result[0] += 3.3595370540761946e-05;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006064500000000001313) ) ) {
              result[0] += -7.134849521993741e-05;
            } else {
              result[0] += 0.00020094010354182503;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
          result[0] += -0.00037031342094276235;
        } else {
          result[0] += -0.00018053021688449523;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 0.00015606477123766916;
        } else {
          result[0] += 0.00015606477123766916;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01657900000000000346) ) ) {
            result[0] += 0.00015606477123766916;
          } else {
            result[0] += -3.890633147932323e-05;
          }
        } else {
          result[0] += 0.00015606477123766916;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 0.00015606477123766916;
        } else {
          result[0] += 0.00015606477123766916;
        }
      } else {
        result[0] += 0.00015606477123766916;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.00022591408785914638;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6750000000000001554) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.0002428205367768573;
              } else {
                result[0] += -0.00012308399861919343;
              }
            } else {
              result[0] += -0.00024357758517116925;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7425707671105529206) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9112103514676580529) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8440161800932387548) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7412676365326634764) ) ) {
                    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1604180000000000328) ) ) {
                      result[0] += -0.00011045494538293978;
                    } else {
                      result[0] += 0.0016161453323004058;
                    }
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0007535000000000001549) ) ) {
                      result[0] += 0.00018814605839361214;
                    } else {
                      result[0] += 0.00404026917435834;
                    }
                  }
                } else {
                  result[0] += -0.0018932243723018554;
                }
              } else {
                result[0] += 0.0017300281776953283;
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9310018456912946272) ) ) {
                result[0] += -0.0008402212385045933;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9567162861906464144) ) ) {
                  result[0] += 0.002543166367840058;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.013855723816631915) ) ) {
                    result[0] += -0.001058876948323928;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.051391296366422923) ) ) {
                      result[0] += 0.0009074460298385526;
                    } else {
                      result[0] += -0.00018544344687176733;
                    }
                  }
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08404042173159891049) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007384500000000001306) ) ) {
                result[0] += 0.0001743021703291134;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
                  result[0] += 0.00022914125043129154;
                } else {
                  result[0] += 0.0003439803456526395;
                }
              }
            } else {
              result[0] += 3.2403872828998796e-05;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006064500000000001313) ) ) {
              result[0] += -6.881804035594641e-05;
            } else {
              result[0] += 0.00019381353610952056;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
          result[0] += -0.00035717983775594014;
        } else {
          result[0] += -0.00017412750910482215;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 0.00015052975808485465;
        } else {
          result[0] += 0.00015052975808485465;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01657900000000000346) ) ) {
            result[0] += 0.00015052975808485465;
          } else {
            result[0] += -3.7526474547115626e-05;
          }
        } else {
          result[0] += 0.00015052975808485465;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 0.00015052975808485465;
        } else {
          result[0] += 0.00015052975808485465;
        }
      } else {
        result[0] += 0.00015052975808485465;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.00021790178990240618;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1450000000000000455) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7478339930150754711) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.578971790991679312e-05) ) ) {
                result[0] += -0.0002811025201833452;
              } else {
                result[0] += -0.0006848117515512379;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6055650374709939943) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6077784371608041525) ) ) {
                  result[0] += 9.634031964911932e-05;
                } else {
                  result[0] += -0.0006916507661385983;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.606193063154585432) ) ) {
                  result[0] += 0.005659515807593974;
                } else {
                  result[0] += 0.0002721177404678762;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                result[0] += -0.00023420863253879675;
              } else {
                result[0] += -0.00023493883135785476;
              }
            } else {
              result[0] += -0.0003178284598035293;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8950000000000001288) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2004855000000000109) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.555096866909547848) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5528143519346734314) ) ) {
                  result[0] += 0.00015363079662539448;
                } else {
                  result[0] += 0.001713508098672877;
                }
              } else {
                result[0] += -7.773608139376497e-05;
              }
            } else {
              result[0] += 0.0005154374412267817;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06217080128912850362) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3750409390474713223) ) ) {
                  result[0] += 0.00034118103099559457;
                } else {
                  result[0] += 0.00014574477257243865;
                }
              } else {
                result[0] += 0.00023055077975251022;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01127328256994905228) ) ) {
                result[0] += -2.0763041334845568e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.06355808660527756393) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.020650504707780553) ) ) {
                    result[0] += 0.00015526137912246358;
                  } else {
                    result[0] += 0.00024360578736547846;
                  }
                } else {
                  result[0] += 4.002496367118263e-05;
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
          result[0] += -0.00034451205191150444;
        } else {
          result[0] += -0.00016795188057880178;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 0.00014519105041699274;
        } else {
          result[0] += 0.00014519105041699274;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01657900000000000346) ) ) {
            result[0] += 0.00014519105041699274;
          } else {
            result[0] += -3.619555579748401e-05;
          }
        } else {
          result[0] += 0.00014519105041699274;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 0.00014519105041699274;
        } else {
          result[0] += 0.00014519105041699274;
        }
      } else {
        result[0] += 0.00014519105041699274;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.0002101736571305641;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6750000000000001554) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                  result[0] += -0.00023066117900565617;
                } else {
                  result[0] += -0.0002259021591987565;
                }
              } else {
                result[0] += -0.00012385551783885282;
              }
            } else {
              result[0] += -0.00022660646069303325;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02207100000000000381) ) ) {
              result[0] += -0.00017796964374423158;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01043419202401875238) ) ) {
                result[0] += -0.000661943597160298;
              } else {
                result[0] += 0.000301683379559396;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08404042173159891049) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007107894154605750962) ) ) {
                result[0] += 4.824951544411754e-05;
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
                  result[0] += 0.00034652469978390846;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4093335132160804135) ) ) {
                    if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4601878067544193374) ) ) {
                      result[0] += 0.0001797603000597058;
                    } else {
                      result[0] += -0.0013996068336446792;
                    }
                  } else {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3539353041941689093) ) ) {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5470680148669562204) ) ) {
                        result[0] += -0.00018654180699346638;
                      } else {
                        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007384500000000001306) ) ) {
                          result[0] += 0.00024329442302606558;
                        } else {
                          result[0] += 0.0005171216873880593;
                        }
                      }
                    } else {
                      result[0] += 0.00022926512193903692;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4781247323869347032) ) ) {
                result[0] += -0.0002549521938501786;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.194581012612933923) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8158067323869347964) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                      result[0] += 7.873505886934524e-05;
                    } else {
                      result[0] += -0.0006245160734937197;
                    }
                  } else {
                    result[0] += 0.0008313761587807781;
                  }
                } else {
                  result[0] += -0.00036794214354155837;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006064500000000001313) ) ) {
              result[0] += -7.049700409568188e-05;
            } else {
              result[0] += 0.00018552018994525736;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
          result[0] += -0.00033229354338128864;
        } else {
          result[0] += -0.00016199527768455814;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 0.0001400416860386263;
        } else {
          result[0] += 0.0001400416860386263;
        }
      } else {
        result[0] += 0.0001400416860386263;
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 0.0001400416860386263;
        } else {
          result[0] += 0.0001400416860386263;
        }
      } else {
        result[0] += 0.0001400416860386263;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.00020271961130479983;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6750000000000001554) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                  result[0] += -0.00022248052010669203;
                } else {
                  result[0] += -0.00021789028430541256;
                }
              } else {
                result[0] += -0.00011946284218982483;
              }
            } else {
              result[0] += -0.0002185696069527436;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
                result[0] += -0.00015041673783974842;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07500000000000002498) ) ) {
                  result[0] += 0.0002568727359681555;
                } else {
                  result[0] += 0.001920428961819409;
                }
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.08500000000000000611) ) ) {
                result[0] += -0.0005160890610588561;
              } else {
                result[0] += -8.830000598626147e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08404042173159891049) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007384500000000001306) ) ) {
                result[0] += 0.00015866993376644652;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
                  if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4601878067544193374) ) ) {
                    if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5261805248634544574) ) ) {
                      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
                        result[0] += 0.0004991595729394938;
                      } else {
                        result[0] += 0.00018840200397711684;
                      }
                    } else {
                      result[0] += 0.0006724401087894477;
                    }
                  } else {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3750409390474713223) ) ) {
                      result[0] += -0.0015769493309189414;
                    } else {
                      result[0] += 0.00015783574235524422;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4814085394974874643) ) ) {
                    result[0] += 0.0004468992834888315;
                  } else {
                    result[0] += -0.00031935142746774745;
                  }
                }
              }
            } else {
              result[0] += 2.7042674767029516e-05;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006064500000000001313) ) ) {
              result[0] += -6.799674832489428e-05;
            } else {
              result[0] += 0.00017894050714230216;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
          result[0] += -0.0003205083780385596;
        } else {
          result[0] += -0.00015624993243099964;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 0.00013507494967641458;
        } else {
          result[0] += 0.00013507494967641458;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01657900000000000346) ) ) {
            result[0] += 0.00013507494967641458;
          } else {
            result[0] += -3.987857594479534e-05;
          }
        } else {
          result[0] += 0.00013507494967641458;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 0.00013507494967641458;
        } else {
          result[0] += 0.00013507494967641458;
        }
      } else {
        result[0] += 0.00013507494967641458;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.00019552993162240084;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01881166515770610337) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.966590843157139501) ) ) {
                result[0] += -0.0002145899975033529;
              } else {
                result[0] += 0.00017238939269921885;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7990273242713569202) ) ) {
                  result[0] += -0.00021130320875005574;
                } else {
                  result[0] += -0.00021016255959254617;
                }
              } else {
                result[0] += -0.00021081778929591451;
              }
            }
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
              result[0] += 0.0005301910259571926;
            } else {
              result[0] += -9.181124222293559e-05;
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.03945373639888280493) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8950000000000001288) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4564975229145729063) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.316132418552224348) ) ) {
                  result[0] += 0.00030555256479344146;
                } else {
                  result[0] += -0.0009098592954189595;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4737195465326633492) ) ) {
                  result[0] += 0.0010332439528025373;
                } else {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.244955337349149066) ) ) {
                    result[0] += -0.0010670624631663446;
                  } else {
                    result[0] += 0.0005383116056689557;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
                result[0] += 0.0002249573491826662;
              } else {
                result[0] += 0.0001368288494438085;
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1513805188710139749) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004657500000000001049) ) ) {
                result[0] += -0.0002309689599010951;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8099155601256282644) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7789937396482412568) ) ) {
                    result[0] += 7.731536582194899e-05;
                  } else {
                    result[0] += -0.0005760541854503266;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
                    result[0] += 0.001465916243981122;
                  } else {
                    result[0] += -0.0001869164455502046;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02563650000000000304) ) ) {
                result[0] += 0.0001535616786685432;
              } else {
                result[0] += 0.00030262081841764905;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
          result[0] += -0.00030914118687836264;
        } else {
          result[0] += -0.00015070835232760106;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 0.00013028436422176038;
        } else {
          result[0] += 0.00013028436422176038;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          result[0] += 0.00013028436422176038;
        } else {
          result[0] += 0.00013028436422176038;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 0.00013028436422176038;
        } else {
          result[0] += 0.00013028436422176038;
        }
      } else {
        result[0] += 0.00013028436422176038;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.00018859524203988806;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
              result[0] += -0.00014218594371217632;
            } else {
              result[0] += -0.00020270890735348568;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              result[0] += -0.00020380910210197328;
            } else {
              result[0] += -0.00020334089859632573;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8950000000000001288) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00877850000000000158) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07500000000000002498) ) ) {
                result[0] += -0.0002927304415190621;
              } else {
                result[0] += -4.192162429634595e-05;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01000276686157755036) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01063150000000000206) ) ) {
                  result[0] += 0.0006960144647587943;
                } else {
                  result[0] += -0.0005796529075407951;
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1513805188710139749) ) ) {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.316132418552224348) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4575776583165829803) ) ) {
                      result[0] += 0.000577556750399803;
                    } else {
                      result[0] += 0.002015227023039604;
                    }
                  } else {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.244955337349149066) ) ) {
                      result[0] += -0.001019194325315884;
                    } else {
                      result[0] += 0.00017978273964475527;
                    }
                  }
                } else {
                  result[0] += 0.0007096609792435363;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0229305563329877532) ) ) {
                result[0] += 0.00013976267210872635;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1604180000000000328) ) ) {
                  if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.01778816268138619719) ) ) {
                    result[0] += 0.00022649586728859793;
                  } else {
                    result[0] += 0.0002462229361767992;
                  }
                } else {
                  result[0] += 9.659447726808054e-05;
                }
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.07274795227358500649) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05831812793683335133) ) ) {
                  result[0] += 0.00011850684505782286;
                } else {
                  result[0] += 0.00013197605995550992;
                }
              } else {
                result[0] += 9.43847425659181e-06;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
          result[0] += -0.0002981771459748398;
        } else {
          result[0] += -0.00014536331061346507;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 0.00012566368228403033;
        } else {
          result[0] += 0.00012566368228403033;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01657900000000000346) ) ) {
            result[0] += 0.00012566368228403033;
          } else {
            result[0] += -4.308491920365857e-05;
          }
        } else {
          result[0] += 0.00012566368228403033;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 0.00012566368228403033;
        } else {
          result[0] += 0.00012566368228403033;
        }
      } else {
        result[0] += 0.00012566368228403033;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.00018190649904574046;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
              result[0] += -0.00013714315883285293;
            } else {
              result[0] += -0.00019551960729879405;
            }
          } else {
            result[0] += -0.00019612918425932147;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8950000000000001288) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.555096866909547848) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5528143519346734314) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008332142139858200389) ) ) {
                  result[0] += -8.706825526131836e-05;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05463331189772155372) ) ) {
                    result[0] += 0.0003545907756096245;
                  } else {
                    result[0] += -0.0005353563814061936;
                  }
                }
              } else {
                result[0] += 0.001955636827740872;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1513805188710139749) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1076318469022627677) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5674119023366835934) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.564198853668341882) ) ) {
                      result[0] += -0.0005261557342878749;
                    } else {
                      result[0] += 0.001394314390284604;
                    }
                  } else {
                    result[0] += -0.000944764416871236;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.55780239615577909) ) ) {
                    result[0] += -0.00312606109684165;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5814822343216081713) ) ) {
                      result[0] += 0.0007337313066073693;
                    } else {
                      result[0] += -0.00011563583734760979;
                    }
                  }
                }
              } else {
                result[0] += 0.0008601010836961622;
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08666957264163686891) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3750409390474713223) ) ) {
                  result[0] += 0.000268858263780032;
                } else {
                  result[0] += 0.0001485263584365021;
                }
              } else {
                result[0] += 0.00020096033333926437;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05701962466675345592) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2108839252750100701) ) ) {
                  result[0] += 0.00015436875766719333;
                } else {
                  result[0] += -1.2602684537136672e-05;
                }
              } else {
                result[0] += 0.0001272953801203528;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
          result[0] += -0.00028760195714938515;
        } else {
          result[0] += -0.00014020783683292147;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 0.00012120687804334579;
        } else {
          result[0] += 0.00012120687804334579;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01657900000000000346) ) ) {
            result[0] += 0.00012120687804334579;
          } else {
            result[0] += -4.1556863944363607e-05;
          }
        } else {
          result[0] += 0.00012120687804334579;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 0.00012120687804334579;
        } else {
          result[0] += 0.00012120687804334579;
        }
      } else {
        result[0] += 0.00012120687804334579;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.0001754549798667742;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
              result[0] += -0.00013227922200752994;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                result[0] += -0.00019285569771121917;
              } else {
                result[0] += -0.00018858528388006378;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              result[0] += -0.00018962483964627078;
            } else {
              result[0] += -0.00018917324150608404;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8950000000000001288) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02063185379234615258) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3278371989949749321) ) ) {
                result[0] += 0.001043173269676582;
              } else {
                result[0] += -0.00011515133626133937;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02162700000000000386) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01704648841990550126) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3998546246231156065) ) ) {
                    result[0] += -0.0010463137920213412;
                  } else {
                    result[0] += 0.000518468449206553;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.564198853668341882) ) ) {
                    result[0] += -0.0012973142663552679;
                  } else {
                    result[0] += -0.00014221921381782617;
                  }
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1513805188710139749) ) ) {
                  result[0] += 0.0003405194804893915;
                } else {
                  result[0] += 0.0006719160902829884;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0229305563329877532) ) ) {
                result[0] += 0.00012953817645076497;
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3650556104053715445) ) ) {
                  result[0] += 0.0002098861607072091;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09558100876864131235) ) ) {
                    result[0] += 0.000197028599927122;
                  } else {
                    result[0] += 0.00021499493301218035;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05701962466675345592) ) ) {
                result[0] += 5.226581309368716e-05;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7322719660050253099) ) ) {
                  result[0] += 0.00012278070587535102;
                } else {
                  result[0] += -0.00012427549882030488;
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
          result[0] += -0.0002774018293244253;
        } else {
          result[0] += -0.00013523520774537298;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 0.00011690813939232601;
        } else {
          result[0] += 0.00011690813939232601;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01657900000000000346) ) ) {
            result[0] += 0.00011690813939232601;
          } else {
            result[0] += -4.008300288848509e-05;
          }
        } else {
          result[0] += 0.00011690813939232601;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 0.00011690813939232601;
        } else {
          result[0] += 0.00011690813939232601;
        }
      } else {
        result[0] += 0.00011690813939232601;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.00016923227109279576;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
              result[0] += -0.00012758779018823185;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                result[0] += -0.00018601585285089902;
              } else {
                result[0] += -0.00018189689406328716;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                result[0] += -0.00018294003522064992;
              } else {
                result[0] += -0.00018289958081162794;
              }
            } else {
              result[0] += -0.0001824639991088851;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8950000000000001288) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02063185379234615258) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.146109394227906586) ) ) {
                result[0] += 0.002673679612143202;
              } else {
                result[0] += -9.755684948129833e-05;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02162700000000000386) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01704648841990550126) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3998546246231156065) ) ) {
                    result[0] += -0.0010092050931466226;
                  } else {
                    result[0] += 0.0005000803808236642;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.564198853668341882) ) ) {
                    result[0] += -0.0012513035525300684;
                  } else {
                    result[0] += -0.00013717524897667637;
                  }
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1513805188710139749) ) ) {
                  result[0] += 0.00032844257300827594;
                } else {
                  result[0] += 0.0006480858282205736;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08666957264163686891) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3750409390474713223) ) ) {
                  result[0] += 0.00025187905274246864;
                } else {
                  result[0] += 0.0001362708620525642;
                }
              } else {
                result[0] += 0.00018640368620364696;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.07274795227358500649) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05831812793683335133) ) ) {
                  result[0] += 0.00010780739659778066;
                } else {
                  result[0] += 0.00011842614964499539;
                }
              } else {
                result[0] += 3.7903469258639476e-06;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
          result[0] += -0.00026756346053850947;
        } else {
          result[0] += -0.00013043893855753397;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 0.00011276186035653741;
        } else {
          result[0] += 0.00011276186035653741;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01657900000000000346) ) ) {
            result[0] += 0.00011276186035653741;
          } else {
            result[0] += -3.8661413977466376e-05;
          }
        } else {
          result[0] += 0.00011276186035653741;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 0.00011276186035653741;
        } else {
          result[0] += 0.00011276186035653741;
        }
      } else {
        result[0] += 0.00011276186035653741;
      }
    }
  }
}

