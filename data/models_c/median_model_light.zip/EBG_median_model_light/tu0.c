
#include "header.h"

void predict_unit0(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4650000000000000244) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2450000000000000233) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.115000000000000005) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08500000000000000611) ) ) {
          result[0] += 0.5942641575616918;
        } else {
          result[0] += 0.5997001806840565;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0133385000000000014) ) ) {
          result[0] += 0.60284735235249;
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01559164707745600183) ) ) {
            result[0] += 0.6035626178656215;
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01778816268138619719) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2250000000000000333) ) ) {
                result[0] += 0.6071389488419339;
              } else {
                result[0] += 0.6111444391261251;
              }
            } else {
              result[0] += 0.6057084169630071;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01265500000000000132) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3850000000000000644) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.29500000000000004) ) ) {
              result[0] += 0.6048500974945856;
            } else {
              result[0] += 0.6082833753682717;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003250500000000000351) ) ) {
              result[0] += 0.6059945231682597;
            } else {
              result[0] += 0.6068528426366813;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4350000000000000533) ) ) {
            result[0] += 0.6082833753682717;
          } else {
            result[0] += 0.6097139080998621;
          }
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3450000000000000289) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.09274867639439776656) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07554750000000000354) ) ) {
              result[0] += 0.6094278001892821;
            } else {
              result[0] += 0.6128610780629682;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09212750000000001493) ) ) {
              result[0] += 0.6065667364314287;
            } else {
              result[0] += 0.6097139080998621;
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01751223853061240412) ) ) {
            result[0] += 0.6094278001892821;
          } else {
            result[0] += 0.6128610780629682;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6150000000000001021) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5250000000000001332) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01184520638735680163) ) ) {
          result[0] += 0.6100000143051147;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01221850000000000193) ) ) {
            result[0] += 0.6111444391261251;
          } else {
            result[0] += 0.6142916107945586;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01871178646485605404) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.6114305470367052;
          } else {
            result[0] += 0.6128610780629682;
          }
        } else {
          result[0] += 0.6145777169998112;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7350000000000000977) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8850000000000001199) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01055863010420855265) ) ) {
            result[0] += 0.6131471859735482;
          } else {
            result[0] += 0.6171526762577395;
          }
        } else {
          result[0] += 0.6151499311156439;
        }
      } else {
        result[0] += 0.6208720603366782;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4450000000000000622) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2150000000000000244) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.07500000000000002498) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08500000000000000611) ) ) {
          result[0] += -0.015285643688140381;
        } else {
          result[0] += -0.010863468177240928;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1560895000000000199) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5531655541959800138) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01413701125100120214) ) ) {
              result[0] += -0.007234126718506988;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.25500000000000006) ) ) {
                result[0] += -0.00506805987419927;
              } else {
                result[0] += -0.0020354878775951523;
              }
            }
          } else {
            result[0] += -0.008378552392181098;
          }
        } else {
          result[0] += -0.0004698929576179975;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0131020000000000008) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3150000000000000577) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)7.626034349605784223e-05) ) ) {
            result[0] += -0.004373062107989837;
          } else {
            result[0] += -0.00448766177981921;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.650000000000000541e-05) ) ) {
            result[0] += -0.0014223470477155696;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3950000000000000733) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00448250000000000124) ) ) {
                result[0] += -0.003032571972208857;
              } else {
                result[0] += -0.001647060550720772;
              }
            } else {
              result[0] += -0.0013814185795506444;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3350000000000000755) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1245513101099625097) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
              result[0] += -0.0015938535567435262;
            } else {
              result[0] += 0.0023584297456681193;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09212750000000001493) ) ) {
              result[0] += -0.003621156627522809;
            } else {
              result[0] += -0.0008501346372103894;
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01871178646485605404) ) ) {
            result[0] += -0.0008419489045449862;
          } else {
            result[0] += 0.002779206870314073;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5850000000000000755) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01184520638735680163) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5250000000000001332) ) ) {
          result[0] += 0;
        } else {
          result[0] += 0.0013691400537383237;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008633000000000001783) ) ) {
          result[0] += 0.0011116820855108385;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5250000000000001332) ) ) {
            result[0] += 0.0033104925179818275;
          } else {
            result[0] += 0.005108988342364195;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6950000000000000622) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8850000000000001199) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01321089953182515153) ) ) {
            result[0] += 0.0025340290844358855;
          } else {
            result[0] += 0.0061633705919603475;
          }
        } else {
          result[0] += 0.004209739601904523;
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8250000000000000666) ) ) {
          result[0] += 0.00706261933242002;
        } else {
          result[0] += 0.010847095956827417;
        }
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4450000000000000622) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2050000000000000433) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.07500000000000002498) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08500000000000000611) ) ) {
          result[0] += -0.014848311520022221;
        } else {
          result[0] += -0.010552657315221323;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1377635000000000109) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01413701125100120214) ) ) {
              result[0] += -0.007027153666747264;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.25500000000000006) ) ) {
                result[0] += -0.005096613205111722;
              } else {
                result[0] += -0.0019772512508067384;
              }
            }
          } else {
            result[0] += -0.00833490016557445;
          }
        } else {
          result[0] += -0.0015151205699977064;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0131020000000000008) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3150000000000000577) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0001725283487249000298) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2650000000000000688) ) ) {
              result[0] += -0.00554789978183311;
            } else {
              result[0] += -0.0026868351713159595;
            }
          } else {
            result[0] += -0.004575794700472118;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.650000000000000541e-05) ) ) {
            result[0] += -0.0013816527772690756;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3950000000000000733) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00448250000000000124) ) ) {
                result[0] += -0.0029458081235519988;
              } else {
                result[0] += -0.0015999370813815348;
              }
            } else {
              result[0] += -0.0013418952990922408;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3350000000000000755) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09212750000000001493) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1245513101099625097) ) ) {
              result[0] += -0.0010824539270240748;
            } else {
              result[0] += -0.003517552990586099;
            }
          } else {
            result[0] += 0.0008908272023293839;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01871178646485605404) ) ) {
            result[0] += -0.0008178602009626129;
          } else {
            result[0] += 0.002699691961354998;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5850000000000000755) ) ) {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01531350000000000246) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5250000000000001332) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5950000000000000844) ) ) {
            result[0] += -0.0008583203210852699;
          } else {
            result[0] += 0.0005722124105051802;
          }
        } else {
          result[0] += 0.00163653848479736;
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01871178646485605404) ) ) {
          result[0] += 0.0017852444508801059;
        } else {
          result[0] += 0.005218522324566186;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7250000000000000888) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8850000000000001199) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01321089953182515153) ) ) {
            result[0] += 0.0026985209239723134;
          } else {
            result[0] += 0.006273138771880773;
          }
        } else {
          result[0] += 0.0045960230667056136;
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8250000000000000666) ) ) {
          result[0] += 0.007211751968801845;
        } else {
          result[0] += 0.01053675351463994;
        }
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4650000000000000244) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2050000000000000433) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.07500000000000002498) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04500000000000000527) ) ) {
          result[0] += -0.014995704651962314;
        } else {
          result[0] += -0.010822951790147695;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1377635000000000109) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01413701125100120214) ) ) {
              result[0] += -0.006826102248077702;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.25500000000000006) ) ) {
                result[0] += -0.004950795799673933;
              } else {
                result[0] += -0.0019206808116370387;
              }
            }
          } else {
            result[0] += -0.008096433272401529;
          }
        } else {
          result[0] += -0.0014717719889790599;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0131020000000000008) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3350000000000000755) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2650000000000000688) ) ) {
              result[0] += -0.0052336426350928405;
            } else {
              result[0] += -0.002609963076504577;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003182500000000000433) ) ) {
              result[0] += -0.004685963157191619;
            } else {
              result[0] += -0.0037490655476854185;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4350000000000000533) ) ) {
            result[0] += -0.001741657194493787;
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05740595745564833902) ) ) {
              result[0] += 0.0010729784970669486;
            } else {
              result[0] += -0.0006922123036422226;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3350000000000000755) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09212750000000001493) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1245513101099625097) ) ) {
              result[0] += -0.0010514842189468965;
            } else {
              result[0] += -0.003416913520817673;
            }
          } else {
            result[0] += 0.0008653400589835264;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01871178646485605404) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5477977269597991139) ) ) {
              result[0] += 0.0012082844513009834;
            } else {
              result[0] += -0.0016527793065524172;
            }
          } else {
            result[0] += 0.0026224520254518346;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6350000000000001199) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5250000000000001332) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01184520638735680163) ) ) {
          result[0] += -1.637136774976101e-05;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01067850000000000223) ) ) {
            result[0] += 0.0008183270360476213;
          } else {
            result[0] += 0.003861660845430706;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02403426826619565679) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9550000000000000711) ) ) {
            result[0] += 0.0017283924659132863;
          } else {
            result[0] += 0.0027642620544399135;
          }
        } else {
          result[0] += 0.004589457929094187;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8050000000000001599) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8850000000000001199) ) ) {
          result[0] += 0.006433206662620602;
        } else {
          result[0] += 0.00573860016540451;
        }
      } else {
        result[0] += 0.00994918396551395;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4650000000000000244) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2050000000000000433) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.0650000000000000161) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08500000000000000611) ) ) {
          result[0] += -0.014280561302493264;
        } else {
          result[0] += -0.010227193922957178;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1377635000000000109) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.09274867639439776656) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0129473293797221032) ) ) {
              result[0] += -0.006937373455679288;
            } else {
              result[0] += -0.003940598751402643;
            }
          } else {
            result[0] += -0.008036688603662964;
          }
        } else {
          result[0] += -0.0014949526837717989;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01265500000000000132) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3150000000000000577) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0008742997306644500989) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3150000000000000577) ) ) {
              result[0] += -0.005713417827977804;
            } else {
              result[0] += -0.0025352903421242963;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007389500000000001102) ) ) {
              result[0] += -0.004551894715648236;
            } else {
              result[0] += -0.0029766606981746486;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4350000000000000533) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.650000000000000541e-05) ) ) {
              result[0] += -0.0015374705927516123;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003250500000000000351) ) ) {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5550000000000001599) ) ) {
                  result[0] += -0.0029703118015361046;
                } else {
                  result[0] += -0.0015397790699456545;
                }
              } else {
                result[0] += -0.001524796138511349;
              }
            }
          } else {
            result[0] += -0.0003062931913236593;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3450000000000000289) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1245513101099625097) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
              result[0] += -0.0015936129847854907;
            } else {
              result[0] += 0.002249685761753347;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01413701125100120214) ) ) {
              result[0] += -0.004864807021104657;
            } else {
              result[0] += -0.0020204816385337686;
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01871178646485605404) ) ) {
            result[0] += -0.00046106739889380564;
          } else {
            result[0] += 0.0027462640897633677;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6350000000000001199) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5250000000000001332) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01184520638735680163) ) ) {
          result[0] += -1.5902972312895604e-05;
        } else {
          result[0] += 0.0020976669386536836;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02403426826619565679) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9550000000000000711) ) ) {
            result[0] += 0.0016789420377927218;
          } else {
            result[0] += 0.0026851747263444067;
          }
        } else {
          result[0] += 0.004458150564643772;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8050000000000001599) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8850000000000001199) ) ) {
          result[0] += 0.006249148452504209;
        } else {
          result[0] += 0.0055744150971468506;
        }
      } else {
        result[0] += 0.009664531367074767;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4650000000000000244) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2050000000000000433) ) ) {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08500000000000000611) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.03500000000000001027) ) ) {
          result[0] += -0.014158091717532885;
        } else {
          result[0] += -0.009195965424452803;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1377635000000000109) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.09274867639439776656) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01437243042433420173) ) ) {
              result[0] += -0.006914490082369603;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.25500000000000006) ) ) {
                result[0] += -0.004682301267295005;
              } else {
                result[0] += -0.0017438105621978795;
              }
            }
          } else {
            result[0] += -0.008217947916362859;
          }
        } else {
          result[0] += -0.0019236054321596274;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01265500000000000132) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3350000000000000755) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2650000000000000688) ) ) {
              result[0] += -0.005002273764806081;
            } else {
              result[0] += -0.0024627540430484187;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003250500000000000351) ) ) {
              result[0] += -0.004421662059068353;
            } else {
              result[0] += -0.0034637097704567515;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4350000000000000533) ) ) {
            result[0] += -0.0016482018485937467;
          } else {
            result[0] += -0.0002975299446999433;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3450000000000000289) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.0141436144428988015) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
              if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.08689530881909278415) ) ) {
                result[0] += -0.0024063390060168263;
              } else {
                result[0] += 0.0014501553876047689;
              }
            } else {
              result[0] += 0.0028066473572845143;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01413701125100120214) ) ) {
              result[0] += -0.004610500010054458;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4950000000000000511) ) ) {
                result[0] += -0.0021695392124689633;
              } else {
                result[0] += -0.0002716076567425123;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01871178646485605404) ) ) {
            result[0] += -0.00044787596192715103;
          } else {
            result[0] += 0.002667691695096526;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6550000000000001377) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5350000000000001421) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01118954037485280113) ) ) {
          result[0] += -1.5447977972910848e-05;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03676400000000001195) ) ) {
            result[0] += 0.0012661842070876591;
          } else {
            result[0] += 0.004898716791829036;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02447420998234165271) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.0017857022556299542;
          } else {
            result[0] += 0.003164191131904209;
          }
        } else {
          result[0] += 0.004681459459965714;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8150000000000000577) ) ) {
        result[0] += 0.005823427762016355;
      } else {
        result[0] += 0.00967412906913046;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4650000000000000244) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1850000000000000255) ) ) {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08500000000000000611) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.03500000000000001027) ) ) {
          result[0] += -0.013753019541733809;
        } else {
          result[0] += -0.009015529265329348;
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.09274867639439776656) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01413701125100120214) ) ) {
            result[0] += -0.007002769099750079;
          } else {
            result[0] += -0.003653242013827411;
          }
        } else {
          result[0] += -0.00825805285918303;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008486000000000002222) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3150000000000000577) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3150000000000000577) ) ) {
              result[0] += -0.005734642641970336;
            } else {
              result[0] += -0.002420556463045179;
            }
          } else {
            result[0] += -0.0043851980389687725;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4350000000000000533) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.650000000000000541e-05) ) ) {
              result[0] += -0.0014463264404926672;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7050000000000000711) ) ) {
                result[0] += -0.002265960723579079;
              } else {
                result[0] += -0.0008767851315279904;
              }
            }
          } else {
            result[0] += -0.0004490322441842993;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3250000000000000666) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.05368089823796016319) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
              result[0] += -0.001934078911169729;
            } else {
              result[0] += 0.0014440757066092249;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04324794178047625809) ) ) {
              result[0] += -0.003566142638709569;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06779550000000000853) ) ) {
                result[0] += -0.0023306844442172246;
              } else {
                result[0] += 0.0011778120311036477;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01840935775314125541) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.006042761789401149275) ) ) {
              result[0] += 0.00112596001056764;
            } else {
              result[0] += -0.0015794867615280242;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1165587384072143268) ) ) {
              result[0] += 0.0032508455130147306;
            } else {
              result[0] += 0.0006758862550864204;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6350000000000001199) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5350000000000001421) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01118954037485280113) ) ) {
          result[0] += -1.5006001315743098e-05;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03676400000000001195) ) ) {
            result[0] += 0.0012299578566754574;
          } else {
            result[0] += 0.004758561330974637;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02447420998234165271) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9050000000000001377) ) ) {
            result[0] += 0.0016635338827009807;
          } else {
            result[0] += 0.0022363726643933146;
          }
        } else {
          result[0] += 0.004265871807548375;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7750000000000001332) ) ) {
        result[0] += 0.00503704692243695;
      } else {
        result[0] += 0.009111239764207668;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4450000000000000622) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1850000000000000255) ) ) {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08500000000000000611) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.03500000000000001027) ) ) {
          result[0] += -0.013359536743294351;
        } else {
          result[0] += -0.008757589132693764;
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.09274867639439776656) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01391911106985315068) ) ) {
            result[0] += -0.006802415339338885;
          } else {
            result[0] += -0.003601318630632011;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1050000000000000239) ) ) {
            result[0] += -0.009177091592438657;
          } else {
            result[0] += -0.006681295358506491;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0131020000000000008) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3150000000000000577) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3150000000000000577) ) ) {
              result[0] += -0.005549720057548349;
            } else {
              result[0] += -0.0023230393660092653;
            }
          } else {
            result[0] += -0.004120900607439826;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)9.765598692199240846e-06) ) ) {
            result[0] += -0.001045651916921918;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3950000000000000733) ) ) {
              result[0] += -0.002242902485721385;
            } else {
              result[0] += -0.0010976320611913995;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3250000000000000666) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01413701125100120214) ) ) {
            result[0] += -0.003998794921817113;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.0141436144428988015) ) ) {
              result[0] += 0.0008364973614613956;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0416553728637082607) ) ) {
                result[0] += -0.002252995619021496;
              } else {
                result[0] += -0.0007387751407375449;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01871178646485605404) ) ) {
            result[0] += -0.0007742063103944427;
          } else {
            result[0] += 0.0022995163958702564;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6550000000000001377) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5550000000000001599) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01531350000000000246) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5850000000000000755) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.031144198390351605e-05) ) ) {
              result[0] += 0.0009128296654907872;
            } else {
              result[0] += -0.001379668375018079;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.004621314935084650834) ) ) {
              result[0] += 0.0002409239600979109;
            } else {
              result[0] += 0.0009883247636634815;
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02085144663384500344) ) ) {
            result[0] += 0.0013212072995539804;
          } else {
            result[0] += 0.004336309603396873;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02447420998234165271) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9550000000000000711) ) ) {
            result[0] += 0.0019429067581348395;
          } else {
            result[0] += 0.003009677503150207;
          }
        } else {
          result[0] += 0.004720494708174011;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8350000000000000755) ) ) {
        result[0] += 0.005671769664460747;
      } else {
        result[0] += 0.009136667497449498;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4650000000000000244) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1850000000000000255) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.0650000000000000161) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03500000000000001027) ) ) {
          result[0] += -0.013263418214330547;
        } else {
          result[0] += -0.009772848525384223;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09856400000000001271) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7293938685427137081) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.25500000000000006) ) ) {
              result[0] += -0.006900902613330988;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
                result[0] += -0.005267303718418604;
              } else {
                result[0] += -0.002280398739913329;
              }
            }
          } else {
            result[0] += -0.008206778106929382;
          }
        } else {
          result[0] += -0.0023467202174500376;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3450000000000000289) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02812450000000000366) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7149244603266332598) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2750000000000000777) ) ) {
              result[0] += -0.0038633928182571667;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.054643202733792936e-05) ) ) {
                result[0] += -0.0010407754603638918;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007698000000000000849) ) ) {
                  result[0] += -0.002997407372680903;
                } else {
                  result[0] += -0.0013269100011044956;
                }
              }
            }
          } else {
            result[0] += -0.004797367930929413;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03472639088202265217) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6037488751507539275) ) ) {
              result[0] += -0.0009293854102765249;
            } else {
              result[0] += -0.0033864227326771677;
            }
          } else {
            result[0] += 0.00060792995816818;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01265500000000000132) ) ) {
          result[0] += -0.0012006974896401938;
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01871178646485605404) ) ) {
            result[0] += -0.00039989747353635154;
          } else {
            result[0] += 0.0023742938846218484;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6650000000000001465) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5650000000000000577) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01531350000000000246) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5950000000000000844) ) ) {
            result[0] += -0.0005394729600833307;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.004923558837848901124) ) ) {
              result[0] += 0.0002427392687320009;
            } else {
              result[0] += 0.0011664913538807886;
            }
          }
        } else {
          result[0] += 0.003632301179819399;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02447420998234165271) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9550000000000000711) ) ) {
            result[0] += 0.0021029834591013044;
          } else {
            result[0] += 0.002961785001657115;
          }
        } else {
          result[0] += 0.004671816974307541;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8350000000000000755) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01437243042433420173) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.0039539648640597135;
          } else {
            result[0] += 0.00473066074260199;
          }
        } else {
          result[0] += 0.006378289065934865;
        }
      } else {
        result[0] += 0.008875261521518338;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4450000000000000622) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1350000000000000366) ) ) {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03500000000000001027) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05500000000000000722) ) ) {
          result[0] += -0.01288394322703698;
        } else {
          result[0] += -0.007093648812855722;
        }
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01391911106985315068) ) ) {
            result[0] += -0.007504136959580472;
          } else {
            result[0] += -0.00483440681627553;
          }
        } else {
          result[0] += -0.008992315519098393;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2650000000000000688) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0104785000000000017) ) ) {
          result[0] += -0.0050856828056066354;
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01413701125100120214) ) ) {
            result[0] += -0.0052308593586518565;
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
              result[0] += -0.00024689883648185314;
            } else {
              result[0] += -0.002776532540032363;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.009518500000000000918) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.650000000000000541e-05) ) ) {
            result[0] += -0.001583210610722792;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3950000000000000733) ) ) {
              result[0] += -0.0025968774882275964;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6450000000000001288) ) ) {
                result[0] += -0.001604087774365273;
              } else {
                result[0] += -0.00021373063308787382;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.05368089823796016319) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3950000000000000733) ) ) {
              result[0] += -0.0007618939459301643;
            } else {
              result[0] += 0.0024519035665820977;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01812749873457050395) ) ) {
              result[0] += -0.001984043978004171;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6550000000000001377) ) ) {
                result[0] += -0.0006442011634706007;
              } else {
                result[0] += 0.0015492033269058321;
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6550000000000001377) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5350000000000001421) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01531350000000000246) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5950000000000000844) ) ) {
            result[0] += -0.0007770606459802415;
          } else {
            result[0] += 0.0005609031647482329;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02803443610476625408) ) ) {
            result[0] += 0.0013286890891084228;
          } else {
            result[0] += 0.004463482031508815;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01871178646485605404) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.0015001835605769041;
          } else {
            result[0] += 0.002701181537997476;
          }
        } else {
          result[0] += 0.003967068774441019;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8250000000000000666) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01437243042433420173) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.0036902060171533535;
          } else {
            result[0] += 0.004390830006147354;
          }
        } else {
          result[0] += 0.006026261175091214;
        }
      } else {
        result[0] += 0.008621334539900105;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4650000000000000244) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1850000000000000255) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05500000000000000722) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03500000000000001027) ) ) {
          result[0] += -0.012515325264957761;
        } else {
          result[0] += -0.009416327598413127;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1377635000000000109) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01559164707745600183) ) ) {
              result[0] += -0.006014329688882094;
            } else {
              result[0] += -0.0034259749507670394;
            }
          } else {
            result[0] += -0.007151068290045747;
          }
        } else {
          result[0] += -0.0009848046309184275;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3450000000000000289) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02812450000000000366) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7149244603266332598) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2750000000000000777) ) ) {
              result[0] += -0.0036541786903161676;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.054643202733792936e-05) ) ) {
                result[0] += -0.0009657015190243781;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007698000000000000849) ) ) {
                  result[0] += -0.002837351258773843;
                } else {
                  result[0] += -0.0012428285301548138;
                }
              }
            }
          } else {
            result[0] += -0.004584392692359329;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03472639088202265217) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.03091333598004935429) ) ) {
              result[0] += -0.0004838053269502253;
            } else {
              result[0] += -0.0029372209754250827;
            }
          } else {
            result[0] += 0.000655083615463041;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01265500000000000132) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7050000000000000711) ) ) {
            result[0] += -0.001362964477075832;
          } else {
            result[0] += -0.0002329524326901826;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01751223853061240412) ) ) {
            result[0] += -0.000585621352964593;
          } else {
            result[0] += 0.0022523319385332917;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6850000000000001643) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5750000000000000666) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01531350000000000246) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5950000000000000844) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.242456489623170593e-05) ) ) {
              result[0] += 0.0014041883455831296;
            } else {
              result[0] += -0.0008492667422760981;
            }
          } else {
            result[0] += 0.0008309615670984174;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03603979634774020363) ) ) {
            result[0] += 0.002354270158210622;
          } else {
            result[0] += 0.005256932613662421;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02447420998234165271) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.002153977844093133;
          } else {
            result[0] += 0.0030476537441082876;
          }
        } else {
          result[0] += 0.0046250084078308905;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8350000000000000755) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01055863010420855265) ) ) {
          result[0] += 0.004231137461028;
        } else {
          result[0] += 0.005961833587788127;
        }
      } else {
        result[0] += 0.008374672573722533;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4450000000000000622) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1350000000000000366) ) ) {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03500000000000001027) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001962500000000000269) ) ) {
            result[0] += -0.012729466644988238;
          } else {
            result[0] += -0.007131530866486879;
          }
        } else {
          result[0] += -0.012157253701568215;
        }
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5671541132663318052) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01386900000000000112) ) ) {
            result[0] += -0.007183067328263073;
          } else {
            result[0] += -0.004037407086979735;
          }
        } else {
          result[0] += -0.008571021880876146;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2650000000000000688) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.009337000000000003283) ) ) {
          result[0] += -0.004799024198648042;
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0129473293797221032) ) ) {
            result[0] += -0.004965555026285833;
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
              result[0] += -0.0004910169780756147;
            } else {
              result[0] += -0.002750923447107128;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0131020000000000008) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
            result[0] += -0.0014802432473685827;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4950000000000000511) ) ) {
              result[0] += -0.002622696545536878;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.05721739154190200877) ) ) {
                result[0] += -0.0006610942072933908;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3750000000000000555) ) ) {
                  result[0] += -0.002689016367849616;
                } else {
                  result[0] += -0.001059269356967756;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1245513101099625097) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02803443610476625408) ) ) {
              result[0] += 0.00042702934312335074;
            } else {
              result[0] += 0.0034925245292015852;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6550000000000001377) ) ) {
              result[0] += -0.0014271849624423857;
            } else {
              result[0] += 0.0012723839060805398;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6950000000000000622) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5650000000000000577) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01531350000000000246) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5850000000000000755) ) ) {
            result[0] += -0.0007305303658502687;
          } else {
            result[0] += 0.0007442778274726248;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01926987714285620379) ) ) {
            result[0] += 0.0012451560442961291;
          } else {
            result[0] += 0.004002950636813859;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02581470935451520357) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.0021069032127866605;
          } else {
            result[0] += 0.002960458396187256;
          }
        } else {
          result[0] += 0.004595933912516469;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8850000000000001199) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01437243042433420173) ) ) {
          result[0] += 0.004701789892501433;
        } else {
          result[0] += 0.006138921131908809;
        }
      } else {
        result[0] += 0.008135067766187512;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4850000000000000422) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1950000000000000344) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05500000000000000722) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
          result[0] += -0.012095533269279772;
        } else {
          result[0] += -0.009007441510057574;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008973500000000000573) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1350000000000000366) ) ) {
            result[0] += -0.007430542316402;
          } else {
            result[0] += -0.005263851702878504;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1245513101099625097) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01247021903101905131) ) ) {
              result[0] += -0.004428104252363253;
            } else {
              result[0] += -0.002127518026742798;
            }
          } else {
            result[0] += -0.005451049597759459;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3450000000000000289) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02812450000000000366) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7149244603266332598) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008486000000000002222) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3150000000000000577) ) ) {
                  result[0] += -0.004666287480278011;
                } else {
                  result[0] += -0.0009670951729058699;
                }
              } else {
                result[0] += -0.0030717301742190953;
              }
            } else {
              result[0] += -0.0016178677832036595;
            }
          } else {
            result[0] += -0.004187961753645791;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6210224928643216513) ) ) {
            result[0] += 0.0004148117569825004;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04324794178047625809) ) ) {
              result[0] += -0.0029244586020453446;
            } else {
              result[0] += 0.00034451480093874195;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01265500000000000132) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4350000000000000533) ) ) {
            result[0] += -0.0012804977708896577;
          } else {
            result[0] += -0.00024147727021563248;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01751223853061240412) ) ) {
            result[0] += -0.000295012174887736;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1245513101099625097) ) ) {
              result[0] += 0.0033618137730634435;
            } else {
              result[0] += 0.0009498739730113325;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6950000000000000622) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5750000000000000666) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01531350000000000246) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5350000000000001421) ) ) {
            result[0] += -0.0007701928147492;
          } else {
            result[0] += 0.000930487188177207;
          }
        } else {
          result[0] += 0.00349838267059188;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01840935775314125541) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.0019484313378460647;
          } else {
            result[0] += 0.002875757763656306;
          }
        } else {
          result[0] += 0.00428644405789735;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8850000000000001199) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01437243042433420173) ) ) {
          result[0] += 0.004567268637808109;
        } else {
          result[0] += 0.005963282621467335;
        }
      } else {
        result[0] += 0.007902318207414579;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4850000000000000422) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1350000000000000366) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.03500000000000001027) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
          result[0] += -0.011749472226832236;
        } else {
          result[0] += -0.009008698155697206;
        }
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01386900000000000112) ) ) {
            result[0] += -0.006433682888038539;
          } else {
            result[0] += -0.0032064202786123296;
          }
        } else {
          result[0] += -0.007554392897227664;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3350000000000000755) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.009337000000000003283) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.29500000000000004) ) ) {
              result[0] += -0.005924778010705804;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7255694492462312351) ) ) {
                result[0] += -0.0014750176852483424;
              } else {
                result[0] += -0.0039639132724548455;
              }
            }
          } else {
            result[0] += -0.0038119917514001503;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0129473293797221032) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7562503571356784526) ) ) {
              result[0] += -0.0032181205118420727;
            } else {
              result[0] += -0.00648184083266705;
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
              result[0] += 7.07102284191812e-05;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4850000000000000422) ) ) {
                result[0] += -0.0024226999956898625;
              } else {
                result[0] += -0.0002724918706354452;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01265500000000000132) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4350000000000000533) ) ) {
            result[0] += -0.0012792367058394461;
          } else {
            result[0] += -0.00023456844908325276;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1245513101099625097) ) ) {
            result[0] += 0.00269341769269266;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03739601681999780991) ) ) {
              result[0] += -0.0008056993761808036;
            } else {
              result[0] += 0.0016974904214282775;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6950000000000000622) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5750000000000000666) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01531350000000000246) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5850000000000000755) ) ) {
            result[0] += -0.0005738261178180535;
          } else {
            result[0] += 0.0009302944925164941;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02116634333934230491) ) ) {
            result[0] += 0.00138820270059599;
          } else {
            result[0] += 0.004270856585117833;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01840935775314125541) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
            result[0] += 0.0018939265733411974;
          } else {
            result[0] += 0.0028627858777818477;
          }
        } else {
          result[0] += 0.004163806116597442;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8850000000000001199) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7750000000000001332) ) ) {
          result[0] += 0.00443114712450978;
        } else {
          result[0] += 0.005786070734773139;
        }
      } else {
        result[0] += 0.007676227764295745;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4850000000000000422) ) ) {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2250000000000000333) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05500000000000000722) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
          result[0] += -0.0114133122149911;
        } else {
          result[0] += -0.008634200028021554;
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.09274867639439776656) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00431950000000000129) ) ) {
            result[0] += -0.006070482111128659;
          } else {
            result[0] += -0.0031146825172885116;
          }
        } else {
          result[0] += -0.0065441025243347835;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3150000000000000577) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01627850000000000477) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7149244603266332598) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.650000000000000541e-05) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3150000000000000577) ) ) {
                result[0] += -0.004280026781732348;
              } else {
                result[0] += -0.001307735078715405;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003250500000000000351) ) ) {
                result[0] += -0.003733101899001313;
              } else {
                result[0] += -0.002753855667934725;
              }
            }
          } else {
            result[0] += -0.004923830829197002;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1165587384072143268) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01559164707745600183) ) ) {
              result[0] += -0.0024447047914798303;
            } else {
              result[0] += 0.0013255293685681426;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04324794178047625809) ) ) {
              result[0] += -0.003330440221649732;
            } else {
              result[0] += -0.0004909868339115225;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01265500000000000132) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3950000000000000733) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
              result[0] += -0.0006361703901123932;
            } else {
              result[0] += -0.0018636599090611585;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01896216239618550223) ) ) {
              result[0] += -0.0007690945433682059;
            } else {
              result[0] += 0.0005133709559095007;
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01205124510104085139) ) ) {
            result[0] += -0.0014511129042975124;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1245513101099625097) ) ) {
              result[0] += 0.0029024634729330526;
            } else {
              result[0] += 0.00037353492856551226;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6950000000000000622) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5750000000000000666) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01531350000000000246) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5350000000000001421) ) ) {
            result[0] += -0.0007317395624188741;
          } else {
            result[0] += 0.0008772490188586512;
          }
        } else {
          result[0] += 0.003277906065190159;
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.009516766579768852138) ) ) {
          result[0] += 0.0018384989888872016;
        } else {
          result[0] += 0.003650461723826875;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8550000000000000933) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01055863010420855265) ) ) {
          result[0] += 0.003956661640626073;
        } else {
          result[0] += 0.005389637604306414;
        }
      } else {
        result[0] += 0.007456605915218305;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4950000000000000511) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1350000000000000366) ) ) {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04500000000000000527) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5577388506030152016) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001962500000000000269) ) ) {
            result[0] += -0.011356505047569935;
          } else {
            result[0] += -0.0063817931047810755;
          }
        } else {
          result[0] += -0.01080066348714671;
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6800105846231156992) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1350000000000000366) ) ) {
            result[0] += -0.006981627725278198;
          } else {
            result[0] += -0.005237576874806701;
          }
        } else {
          result[0] += -0.007896339260907851;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3350000000000000755) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008311500000000001179) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002265000000000000032) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.29500000000000004) ) ) {
              result[0] += -0.005656639765984484;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.3850000000000000644) ) ) {
                result[0] += -0.0014218202764430196;
              } else {
                result[0] += -0.0030605257504910245;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2150000000000000244) ) ) {
              result[0] += -0.004450018319346636;
            } else {
              result[0] += -0.003056381638018332;
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0129473293797221032) ) ) {
            result[0] += -0.003664940846098597;
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
              result[0] += 5.754059228598157e-05;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4950000000000000511) ) ) {
                result[0] += -0.0023571251337250777;
              } else {
                result[0] += -2.2571354803585083e-05;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01265500000000000132) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4350000000000000533) ) ) {
            result[0] += -0.0012009512474449899;
          } else {
            result[0] += -0.0001507625002338757;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1245513101099625097) ) ) {
            result[0] += 0.0025333159074735355;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03739601681999780991) ) ) {
              result[0] += -0.0007933348713738637;
            } else {
              result[0] += 0.0017112945784004718;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6950000000000000622) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5750000000000000666) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01531350000000000246) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5850000000000000755) ) ) {
            result[0] += -0.00040825702599264996;
          } else {
            result[0] += 0.0009272743321245491;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02149820807722475566) ) ) {
            result[0] += 0.0013917764778839312;
          } else {
            result[0] += 0.004144570052358676;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03536067803908965468) ) ) {
          result[0] += 0.002317249300101312;
        } else {
          result[0] += 0.004512895202669761;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8250000000000000666) ) ) {
        result[0] += 0.004701779309006081;
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9450000000000000622) ) ) {
          result[0] += 0.005812734857925859;
        } else {
          result[0] += 0.0072432675895163084;
        }
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4950000000000000511) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1350000000000000366) ) ) {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03500000000000001027) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001962500000000000269) ) ) {
            result[0] += -0.011031588081295758;
          } else {
            result[0] += -0.005898055206017903;
          }
        } else {
          result[0] += -0.010491649507996241;
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6800105846231156992) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01386900000000000112) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.09500000000000001499) ) ) {
              result[0] += -0.007707129604614477;
            } else {
              result[0] += -0.005884814340801579;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1245513101099625097) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01667338205697885267) ) ) {
                result[0] += -0.004171291997216224;
              } else {
                result[0] += -0.0021322824915461103;
              }
            } else {
              result[0] += -0.005360821875369941;
            }
          }
        } else {
          result[0] += -0.007800854242689807;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3350000000000000755) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008311500000000001179) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002265000000000000032) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2750000000000000777) ) ) {
              result[0] += -0.005708322634310497;
            } else {
              result[0] += -0.0021626494038243173;
            }
          } else {
            result[0] += -0.0034912716973320465;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0129473293797221032) ) ) {
            result[0] += -0.0035600845143045584;
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
              result[0] += 5.5894318665278725e-05;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4950000000000000511) ) ) {
                result[0] += -0.0022896862566787936;
              } else {
                result[0] += -2.1925573720694993e-05;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01265500000000000132) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4450000000000000622) ) ) {
            result[0] += -0.001110127473122797;
          } else {
            result[0] += -6.92159174141261e-05;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1245513101099625097) ) ) {
            result[0] += 0.002460836098252076;
          } else {
            result[0] += 9.943947162748046e-05;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6950000000000000622) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6150000000000001021) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01531350000000000246) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.0007372818721681582;
          } else {
            result[0] += 0.0018884700424282573;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02359730123255650638) ) ) {
            result[0] += 0.0019827297722225415;
          } else {
            result[0] += 0.0045980895420514286;
          }
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.009516766579768852138) ) ) {
          result[0] += 0.0019157292338670912;
        } else {
          result[0] += 0.0037541962911579727;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8550000000000000933) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01055863010420855265) ) ) {
          result[0] += 0.0037089380360281476;
        } else {
          result[0] += 0.005098055431738229;
        }
      } else {
        result[0] += 0.007036033011515455;
      }
    }
  }
}

