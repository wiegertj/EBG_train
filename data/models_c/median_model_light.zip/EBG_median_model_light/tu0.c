
#include "header.h"

void predict_unit0(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4450000000000000622) ) ) {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2050000000000000433) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07500000000000002498) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.04500000000000000527) ) ) {
          result[0] += 0.5801389912852534;
        } else {
          result[0] += 0.5854589104322218;
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1604180000000000328) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.555096866909547848) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0142099505541319511) ) ) {
              result[0] += 0.5911334907851898;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3050000000000000488) ) ) {
                result[0] += 0.593616119491431;
              } else {
                result[0] += 0.5982267170191297;
              }
            }
          } else {
            result[0] += 0.5893601850194347;
          }
        } else {
          result[0] += 0.5982267170191297;
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01308450000000000064) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3450000000000000289) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.000584175175977650024) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3050000000000000488) ) ) {
              result[0] += 0.5925521356091886;
            } else {
              result[0] += 0.5971627320799144;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003226000000000000135) ) ) {
              result[0] += 0.5943254424319169;
            } else {
              result[0] += 0.5953894263141591;
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.29500000000000004) ) ) {
            result[0] += 0.596098749254645;
          } else {
            result[0] += 0.598404047490008;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2273413669989351737) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4250000000000000444) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0758825000000000055) ) ) {
              result[0] += 0.5980493865482515;
            } else {
              result[0] += 0.602482652548099;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0240756843176193544) ) ) {
              result[0] += 0.6014186676088837;
            } else {
              result[0] += 0.605674603137853;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02661305910200095423) ) ) {
            result[0] += 0.5952120958432809;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3550000000000000377) ) ) {
              result[0] += 0.5982267170191297;
            } else {
              result[0] += 0.602482652548099;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5850000000000000755) ) ) {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0119121105025029022) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4950000000000000511) ) ) {
          result[0] += 0.5996453607861555;
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8050000000000001599) ) ) {
            result[0] += 0.6010640066671272;
          } else {
            result[0] += 0.6021279916063426;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01044150000000000113) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4950000000000000511) ) ) {
            result[0] += 0.6007093457253708;
          } else {
            result[0] += 0.6028373134898555;
          }
        } else {
          result[0] += 0.605674603137853;
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6950000000000000622) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8850000000000001199) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01620974339269775494) ) ) {
            result[0] += 0.6039012963151248;
          } else {
            result[0] += 0.6081572318440941;
          }
        } else {
          result[0] += 0.605674603137853;
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8450000000000000844) ) ) {
          result[0] += 0.6099305386668223;
        } else {
          result[0] += 0.6141864741957916;
        }
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4450000000000000622) ) ) {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2050000000000000433) ) ) {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1350000000000000366) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
          result[0] += -0.018447316089643007;
        } else {
          result[0] += -0.011542767713964074;
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1604180000000000328) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5671541132663318052) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0142099505541319511) ) ) {
              result[0] += -0.008197409461645398;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3450000000000000289) ) ) {
                result[0] += -0.005802829982873295;
              } else {
                result[0] += 6.289232675599033e-05;
              }
            }
          } else {
            result[0] += -0.010262484936860801;
          }
        } else {
          result[0] += -0.002015994634242393;
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009152500000000002647) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3450000000000000289) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.000584175175977650024) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3050000000000000488) ) ) {
              result[0] += -0.0071837404752888015;
            } else {
              result[0] += -0.002736664009144537;
            }
          } else {
            result[0] += -0.005156400426116385;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.29500000000000004) ) ) {
            result[0] += -0.004117573482073801;
          } else {
            result[0] += -0.0017167037211504666;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2273413669989351737) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4650000000000000244) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0296135000000000044) ) ) {
              result[0] += -0.0020587862125504104;
            } else {
              result[0] += 0.0006212726560439055;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02528885254406800301) ) ) {
              result[0] += 0.0012979164164686765;
            } else {
              result[0] += 0.005118662998587656;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02616152934301940389) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3450000000000000289) ) ) {
              result[0] += -0.0055047721426945825;
            } else {
              result[0] += -0.002312821552940586;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3550000000000000377) ) ) {
              result[0] += -0.0020650754377286606;
            } else {
              result[0] += 0.0016852554813132506;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6150000000000001021) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5250000000000001332) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01332150000000000174) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6650000000000001465) ) ) {
            result[0] += -0.00034208453037242874;
          } else {
            result[0] += 0.0010262474741998396;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7342470301758795559) ) ) {
            result[0] += 0.005118662998587656;
          } else {
            result[0] += -0.0002012553556509914;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01620974339269775494) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8050000000000001599) ) ) {
            result[0] += 0.0019896047355896502;
          } else {
            result[0] += 0.002736661970172052;
          }
        } else {
          result[0] += 0.0055739516181696;
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7350000000000000977) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8850000000000001199) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01043419202401875238) ) ) {
            result[0] += 0.004117572500074301;
          } else {
            result[0] += 0.00857722741657507;
          }
        } else {
          result[0] += 0.00653730887955941;
        }
      } else {
        result[0] += 0.013328650948076297;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4650000000000000244) ) ) {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2150000000000000244) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1050000000000000239) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.03500000000000001027) ) ) {
          result[0] += -0.01885704503215528;
        } else {
          result[0] += -0.013016480076292998;
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.09856950000000001821) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5531655541959800138) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0142099505541319511) ) ) {
              result[0] += -0.007433371242685311;
            } else {
              result[0] += -0.0050512242305008745;
            }
          } else {
            result[0] += -0.009189192448991646;
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.243144592614154248) ) ) {
            result[0] += 0.0007868772215084026;
          } else {
            result[0] += -0.004476205677199845;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01044150000000000113) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3950000000000000733) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.000584175175977650024) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2650000000000000688) ) ) {
              result[0] += -0.005864977133839865;
            } else {
              result[0] += -0.002365142884699018;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3150000000000000577) ) ) {
              result[0] += -0.005290448421790979;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003226000000000000135) ) ) {
                result[0] += -0.003429125709968363;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.06355808660527756393) ) ) {
                  result[0] += -0.0004249265054307656;
                } else {
                  result[0] += -0.0032622161534283135;
                }
              }
            }
          }
        } else {
          result[0] += -0.0009464970037272634;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2273413669989351737) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5350000000000001421) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1014535000000000159) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3197884335317744964) ) ) {
                result[0] += 0.0018204521251750855;
              } else {
                result[0] += -0.0012764471537010775;
              }
            } else {
              result[0] += 0.005291784783253575;
            }
          } else {
            result[0] += 0.0041595896577850955;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02661305910200095423) ) ) {
            result[0] += -0.004041561153933794;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3550000000000000377) ) ) {
              result[0] += -0.0016371742661705887;
            } else {
              result[0] += 0.0019801490504047577;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6150000000000001021) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5250000000000001332) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01000276686157755036) ) ) {
          result[0] += 0.00024279314036555966;
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01262450000000000204) ) ) {
            result[0] += 0.001330148502940889;
          } else {
            result[0] += 0.005291784783253575;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02483316262871755262) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9150000000000001465) ) ) {
            result[0] += 0.0023743297789521932;
          } else {
            result[0] += 0.003248297372135936;
          }
        } else {
          result[0] += 0.006085587020133484;
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7650000000000001243) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8850000000000001199) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01043419202401875238) ) ) {
            result[0] += 0.003971538146742409;
          } else {
            result[0] += 0.00862768731290062;
          }
        } else {
          result[0] += 0.0066601167878258425;
        }
      } else {
        result[0] += 0.012855935307500758;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4450000000000000622) ) ) {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1850000000000000255) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0650000000000000161) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.03500000000000001027) ) ) {
          result[0] += -0.018188258659366102;
        } else {
          result[0] += -0.013618819810055947;
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5674119023366835934) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01792322003581395262) ) ) {
            result[0] += -0.007997708191194173;
          } else {
            result[0] += -0.004669168144147326;
          }
        } else {
          result[0] += -0.010281932197389059;
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009152500000000002647) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3350000000000000755) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.000584175175977650024) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3150000000000000577) ) ) {
              result[0] += -0.007075613928099957;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3550000000000000377) ) ) {
                result[0] += -0.0014917377336071166;
              } else {
                result[0] += -0.004204902869123102;
              }
            }
          } else {
            result[0] += -0.005190658122563689;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.29500000000000004) ) ) {
            result[0] += -0.0034952592838311167;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
              result[0] += -0.0007824158500942199;
            } else {
              result[0] += -0.0016222503033555063;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3250000000000000666) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2273413669989351737) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02884459794480960168) ) ) {
              result[0] += -0.0022008229646455573;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3450000000000000289) ) ) {
                result[0] += -0.0016742912886241218;
              } else {
                result[0] += 0.0029297077025272344;
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04557577292723340862) ) ) {
              result[0] += -0.0048115397223208916;
            } else {
              result[0] += -0.0012244490923338247;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01761323773984950145) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3966559369710560001) ) ) {
              result[0] += -0.00031414937977714095;
            } else {
              result[0] += -0.003506099969531137;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2273413669989351737) ) ) {
              result[0] += 0.003958173049494047;
            } else {
              result[0] += 0.000548857730394378;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6150000000000001021) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5250000000000001332) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0110643527143887508) ) ) {
          result[0] += 1.6100006477140698e-05;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1529448915625084837) ) ) {
            result[0] += 0.004227950187862553;
          } else {
            result[0] += 0.0010368470431138918;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02483316262871755262) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9150000000000001465) ) ) {
            result[0] += 0.0022901214951005573;
          } else {
            result[0] += 0.0031330928417576615;
          }
        } else {
          result[0] += 0.005869754811929713;
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7350000000000000977) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8850000000000001199) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01278116174711865262) ) ) {
            result[0] += 0.004185344008234452;
          } else {
            result[0] += 0.008258804323571843;
          }
        } else {
          result[0] += 0.006069247291585538;
        }
      } else {
        result[0] += 0.0123999850603409;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4450000000000000622) ) ) {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2050000000000000433) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0650000000000000161) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.03500000000000001027) ) ) {
          result[0] += -0.0175431915496781;
        } else {
          result[0] += -0.013135813003480178;
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3050000000000000488) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01704648841990550126) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01302823237808665123) ) ) {
              result[0] += -0.008580033078506862;
            } else {
              result[0] += -0.004766211242142121;
            }
          } else {
            result[0] += -0.00981178050719835;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01561050000000000111) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              result[0] += -0.004952014461519481;
            } else {
              result[0] += -0.00743464316776058;
            }
          } else {
            result[0] += -0.0028888077880737037;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01308450000000000064) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3350000000000000755) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.000584175175977650024) ) ) {
            result[0] += -0.004342040592614912;
          } else {
            result[0] += -0.00460179860231984;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.29500000000000004) ) ) {
            result[0] += -0.003371295970681838;
          } else {
            result[0] += -0.001482585774678115;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3892782419974109565) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3950000000000000733) ) ) {
            result[0] += -0.0015746957952067697;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0240756843176193544) ) ) {
              result[0] += 0.00037570875916243;
            } else {
              result[0] += 0.004294557288500591;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0409003745630781082) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01620974339269775494) ) ) {
              result[0] += -0.00515505900196343;
            } else {
              result[0] += -0.0023191293069202822;
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5350000000000001421) ) ) {
              result[0] += -0.001181022624097121;
            } else {
              result[0] += 0.0022739073042834473;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6350000000000001199) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5350000000000001421) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00877850000000000158) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5950000000000000844) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001237226668511850168) ) ) {
              result[0] += 0.0014763522850905206;
            } else {
              result[0] += -0.0014031168793851123;
            }
          } else {
            result[0] += 0.0008430099561565294;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02796916660693585244) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6858832018090453841) ) ) {
              result[0] += 0.00291822163653546;
            } else {
              result[0] += -0.0007736575090361934;
            }
          } else {
            result[0] += 0.006200795656069748;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02577363736079425413) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9550000000000000711) ) ) {
            result[0] += 0.0023073809448295097;
          } else {
            result[0] += 0.0037312981674586794;
          }
        } else {
          result[0] += 0.00587740783243621;
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8050000000000001599) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8850000000000001199) ) ) {
          result[0] += 0.007674127897314707;
        } else {
          result[0] += 0.00691797741555526;
        }
      } else {
        result[0] += 0.011960205603007886;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4650000000000000244) ) ) {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2050000000000000433) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.03500000000000001027) ) ) {
          result[0] += -0.0169210024726701;
        } else {
          result[0] += -0.013024598048373645;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1350000000000000366) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.555096866909547848) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0149275149599735011) ) ) {
              result[0] += -0.008709757817412556;
            } else {
              result[0] += -0.005506785426372509;
            }
          } else {
            result[0] += -0.010442154807754789;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1358410000000000173) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08407783631914581002) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01170971943545395279) ) ) {
                result[0] += -0.006334793816343669;
              } else {
                result[0] += -0.0031939058478551376;
              }
            } else {
              result[0] += -0.007525626103303976;
            }
          } else {
            result[0] += 0.0004411196782997585;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01308450000000000064) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3950000000000000733) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.000584175175977650024) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3050000000000000488) ) ) {
              result[0] += -0.005961350990936555;
            } else {
              result[0] += -0.00210583805541578;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2850000000000000866) ) ) {
              result[0] += -0.004971903764318832;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004460500000000000922) ) ) {
                result[0] += -0.0031973913848559483;
              } else {
                result[0] += -0.0018435305174232233;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05463331189772155372) ) ) {
            result[0] += -2.071921896355429e-05;
          } else {
            result[0] += -0.001183711814339476;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2273413669989351737) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4650000000000000244) ) ) {
            result[0] += -0.0007426125422090699;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0240756843176193544) ) ) {
              result[0] += 0.0017252187750118545;
            } else {
              result[0] += 0.0050443630308836815;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02661305910200095423) ) ) {
            result[0] += -0.003908245137316205;
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5250000000000001332) ) ) {
              result[0] += -0.0016808737553387191;
            } else {
              result[0] += 0.0015968313948695235;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6550000000000001377) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5650000000000000577) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0119121105025029022) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8050000000000001599) ) ) {
            result[0] += 0.00026669192125291494;
          } else {
            result[0] += 0.001583792386428875;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00877850000000000158) ) ) {
            result[0] += 0.001551855964695249;
          } else {
            result[0] += 0.004997839818380198;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02483316262871755262) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9550000000000000711) ) ) {
            result[0] += 0.0027713489558296544;
          } else {
            result[0] += 0.004303014010905458;
          }
        } else {
          result[0] += 0.006328436471882961;
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8350000000000000755) ) ) {
        result[0] += 0.007401956295029534;
      } else {
        result[0] += 0.011890684361956328;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4650000000000000244) ) ) {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1850000000000000255) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.03500000000000001027) ) ) {
          result[0] += -0.016320880033106704;
        } else {
          result[0] += -0.012562665986857362;
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.555096866909547848) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01444878842564100048) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3150000000000000577) ) ) {
              result[0] += -0.00810802766435247;
            } else {
              result[0] += -0.004033760187512031;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.07274795227358500649) ) ) {
              result[0] += -0.003761566047203306;
            } else {
              result[0] += -0.007804370345879295;
            }
          }
        } else {
          result[0] += -0.009302381191986706;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3450000000000000289) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03018900000000000403) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5778807480402011754) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2850000000000000866) ) ) {
              result[0] += -0.004975820510169654;
            } else {
              result[0] += -0.002451214237477961;
            }
          } else {
            result[0] += -0.004987299300513051;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3830383354773237436) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02616152934301940389) ) ) {
              result[0] += -0.0018877521585048426;
            } else {
              result[0] += 0.0022497022963081973;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
              result[0] += -0.00380735224823949;
            } else {
              result[0] += -0.0001928698863936808;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01262450000000000204) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2750000000000000777) ) ) {
            result[0] += -0.0041751279671853195;
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.009014249010710599294) ) ) {
              result[0] += -0.0004142123273742189;
            } else {
              result[0] += -0.0014856292937029253;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01761323773984950145) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4036106884780860105) ) ) {
              result[0] += 0.0005533456191590639;
            } else {
              result[0] += -0.0030603118745396595;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2273413669989351737) ) ) {
              result[0] += 0.00429015846559174;
            } else {
              result[0] += 0.0013058915018109509;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6550000000000001377) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5650000000000000577) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01043419202401875238) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8050000000000001599) ) ) {
            result[0] += 5.5833594612765546e-05;
          } else {
            result[0] += 0.0015406092996032448;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01989400000000000543) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5950000000000000844) ) ) {
              result[0] += -0.0002154239260083321;
            } else {
              result[0] += 0.0021762496560577727;
            }
          } else {
            result[0] += 0.005266306288617878;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02577363736079425413) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.0026796870403835186;
          } else {
            result[0] += 0.004046215010078074;
          }
        } else {
          result[0] += 0.006103991333939011;
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8450000000000000844) ) ) {
        result[0] += 0.007212419777269476;
      } else {
        result[0] += 0.011468967828382092;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4350000000000000533) ) ) {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1550000000000000266) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
          result[0] += -0.01609670288486031;
        } else {
          result[0] += -0.012117116866961555;
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.555096866909547848) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01444878842564100048) ) ) {
            result[0] += -0.007877282047082313;
          } else {
            result[0] += -0.0047710488966533;
          }
        } else {
          result[0] += -0.009422668429916292;
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2650000000000000688) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009323500000000001925) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.000584175175977650024) ) ) {
            result[0] += -0.006135171044967733;
          } else {
            result[0] += -0.005717187978777003;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01444878842564100048) ) ) {
            result[0] += -0.005549404738917216;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1534042965400678749) ) ) {
              result[0] += -0.0010370478468085804;
            } else {
              result[0] += -0.00347307498420222;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01308450000000000064) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
            result[0] += -0.001796303905748381;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3950000000000000733) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005259500000000001153) ) ) {
                result[0] += -0.0030693017853171208;
              } else {
                result[0] += -0.0017224515356903977;
              }
            } else {
              result[0] += -0.0010628016544300507;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6299505656030152112) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0229305563329877532) ) ) {
              result[0] += 7.831617014384908e-05;
            } else {
              result[0] += 0.0034135862752179206;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
              result[0] += -0.002770225550997438;
            } else {
              result[0] += 0.0015258272578243825;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6350000000000001199) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5350000000000001421) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01065347450249755183) ) ) {
          result[0] += 4.8544475074076854e-05;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5531655541959800138) ) ) {
            result[0] += 0.004165700592550316;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03729562354052295275) ) ) {
              result[0] += 0.0003262292442521915;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01905700000000000102) ) ) {
                result[0] += 0.0007105051682981521;
              } else {
                result[0] += 0.005902030865752798;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02577363736079425413) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9550000000000000711) ) ) {
            result[0] += 0.002098384454394483;
          } else {
            result[0] += 0.003324445701015485;
          }
        } else {
          result[0] += 0.005266233739942179;
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7750000000000001332) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.009602467408789250661) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9450000000000000622) ) ) {
            result[0] += 0.0035207379501739607;
          } else {
            result[0] += 0.004782158869725769;
          }
        } else {
          result[0] += 0.006763357909020648;
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9050000000000001377) ) ) {
          result[0] += 0.0085795792411257;
        } else {
          result[0] += 0.011062207947366799;
        }
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4850000000000000422) ) ) {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1850000000000000255) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.03500000000000001027) ) ) {
          result[0] += -0.015171153887927015;
        } else {
          result[0] += -0.011687369649181718;
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5674119023366835934) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005959500000000000387) ) ) {
            result[0] += -0.007553299649812869;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1211830000000000129) ) ) {
              result[0] += -0.004726198522023363;
            } else {
              result[0] += 0.000478535468204489;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.115000000000000005) ) ) {
            result[0] += -0.009797805277290204;
          } else {
            result[0] += -0.007470854322726288;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3450000000000000289) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03018900000000000403) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7149244603266332598) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2750000000000000777) ) ) {
              result[0] += -0.004293649110741242;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                result[0] += -0.0011887250004991386;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007696500000000001084) ) ) {
                  result[0] += -0.003093694842810058;
                } else {
                  result[0] += -0.0012394974410258098;
                }
              }
            }
          } else {
            result[0] += -0.005286336580904028;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02661305910200095423) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6025283427889448484) ) ) {
              result[0] += -0.0017236915545124163;
            } else {
              result[0] += -0.0047315244473113294;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1405997886577425304) ) ) {
              result[0] += 0.0035224615164547186;
            } else {
              result[0] += -0.0010571735340418938;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01287800000000000229) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4050000000000000822) ) ) {
            result[0] += -0.0016812210561815012;
          } else {
            result[0] += -0.0003821927689202377;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01761323773984950145) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6858832018090453841) ) ) {
              result[0] += 0.0005820202262383189;
            } else {
              result[0] += -0.0028560139779283374;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2273413669989351737) ) ) {
              result[0] += 0.004295592404439165;
            } else {
              result[0] += 0.0012980817023649784;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6850000000000001643) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5650000000000000577) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.008624500000000001956) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8050000000000001599) ) ) {
            result[0] += 0.0006679177795917707;
          } else {
            result[0] += 0.0015098245562151006;
          }
        } else {
          result[0] += 0.003996895822543724;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02577363736079425413) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.0028226723205172816;
          } else {
            result[0] += 0.003894265310656329;
          }
        } else {
          result[0] += 0.0059344468478653226;
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01000276686157755036) ) ) {
          result[0] += 0.005899107773998753;
        } else {
          result[0] += 0.007780735882234359;
        }
      } else {
        result[0] += 0.010669874264356364;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4850000000000000422) ) ) {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1350000000000000366) ) ) {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.08500000000000000611) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02500000000000000486) ) ) {
          result[0] += -0.014633091802248603;
        } else {
          result[0] += -0.010022495265462042;
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.555096866909547848) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01650738594486505367) ) ) {
            result[0] += -0.007380452872709589;
          } else {
            result[0] += -0.004417699201518478;
          }
        } else {
          result[0] += -0.009333859811540888;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3450000000000000289) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009152500000000002647) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2350000000000000144) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.29500000000000004) ) ) {
                result[0] += -0.008106832995438604;
              } else {
                result[0] += -0.003580413581780703;
              }
            } else {
              result[0] += -0.00575175010580047;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0009293908214454501713) ) ) {
              result[0] += -0.002560964686978721;
            } else {
              result[0] += -0.003692595235254153;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01302823237808665123) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7584510713567840234) ) ) {
              result[0] += -0.003793477530871183;
            } else {
              result[0] += -0.007476977729830431;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09341808925382111273) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3650000000000000466) ) ) {
                result[0] += -0.0016641791802438552;
              } else {
                result[0] += 0.0018944714369892276;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1773295000000000288) ) ) {
                result[0] += -0.0030079878255837257;
              } else {
                result[0] += 0.0018324207032480617;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01287800000000000229) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4050000000000000822) ) ) {
            result[0] += -0.0016215946550087231;
          } else {
            result[0] += -0.00036863787125750343;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01761323773984950145) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6858832018090453841) ) ) {
              result[0] += 0.0005613782223966716;
            } else {
              result[0] += -0.0027547222206208252;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1250629713251516228) ) ) {
              result[0] += 0.004626273915568286;
            } else {
              result[0] += 0.001400269688170667;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6850000000000001643) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5650000000000000577) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0119121105025029022) ) ) {
          result[0] += 0.000946760381808452;
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1304295000000000038) ) ) {
            result[0] += 0.002686592830554381;
          } else {
            result[0] += 0.00749723566371877;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02577363736079425413) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.0027225630626992025;
          } else {
            result[0] += 0.0037561507986873834;
          }
        } else {
          result[0] += 0.0057239749963569715;
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.009795390075261452625) ) ) {
          result[0] += 0.005689889262607515;
        } else {
          result[0] += 0.007504783307510332;
        }
      } else {
        result[0] += 0.01029145513796581;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4850000000000000422) ) ) {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2250000000000000333) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
          result[0] += -0.014468773967432659;
        } else {
          result[0] += -0.010941828034436002;
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5072261056783921029) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01278116174711865262) ) ) {
            result[0] += -0.006501251058864608;
          } else {
            result[0] += -0.0038358730799918804;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1350000000000000366) ) ) {
            result[0] += -0.008957417271894731;
          } else {
            result[0] += -0.006131589066992139;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3450000000000000289) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5792515097236182742) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02095879431033080206) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.000210500000000000048) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3150000000000000577) ) ) {
                result[0] += -0.004178929702712798;
              } else {
                result[0] += -0.000475633882463649;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009152500000000002647) ) ) {
                result[0] += -0.0038509813829623696;
              } else {
                result[0] += -0.0018296353713075668;
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02668150000000000382) ) ) {
              result[0] += -0.0011192515030517588;
            } else {
              result[0] += 0.0022631618334424783;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.09229200000000001292) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.25500000000000006) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7425707671105529206) ) ) {
                result[0] += -0.005570141980965976;
              } else {
                result[0] += -0.007057287792737406;
              }
            } else {
              result[0] += -0.0033286097542328365;
            }
          } else {
            result[0] += -0.0012712048530817363;
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01287800000000000229) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4050000000000000822) ) ) {
            result[0] += -0.0014883659601849174;
          } else {
            result[0] += -0.00033504956574949995;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01148539754569130079) ) ) {
            result[0] += -0.002013983666647734;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2273413669989351737) ) ) {
              result[0] += 0.0037283568368984676;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0366913419685883091) ) ) {
                result[0] += -0.0005265664352340952;
              } else {
                result[0] += 0.0027733918663415034;
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6950000000000000622) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5650000000000000577) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.008624500000000001956) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.8050000000000001599) ) ) {
            result[0] += 0.0005706448344093699;
          } else {
            result[0] += 0.0014034168581286562;
          }
        } else {
          result[0] += 0.0037531554701467984;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02577363736079425413) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.0027026007748346148;
          } else {
            result[0] += 0.003622934673678415;
          }
        } else {
          result[0] += 0.0055983530229799456;
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8650000000000001021) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01043419202401875238) ) ) {
          result[0] += 0.005666919232016248;
        } else {
          result[0] += 0.007325759554198763;
        }
      } else {
        result[0] += 0.009926457072749011;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4850000000000000422) ) ) {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1550000000000000266) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5271332674874372737) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001350500000000000355) ) ) {
              result[0] += -0.014310283849978777;
            } else {
              result[0] += -0.008635703298828267;
            }
          } else {
            result[0] += -0.013955622577918271;
          }
        } else {
          result[0] += -0.01053180452909529;
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.555096866909547848) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01332150000000000174) ) ) {
            result[0] += -0.007004494625603131;
          } else {
            result[0] += -0.0033385094051918626;
          }
        } else {
          result[0] += -0.008178120249080064;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3450000000000000289) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009152500000000002647) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.000210500000000000048) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3150000000000000577) ) ) {
              result[0] += -0.00622157636770672;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3550000000000000377) ) ) {
                result[0] += -0.0003651188993613204;
              } else {
                result[0] += -0.0030362527085438964;
              }
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2250000000000000333) ) ) {
              result[0] += -0.005267685858987071;
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.05751864358971629093) ) ) {
                result[0] += -0.002239998279764654;
              } else {
                result[0] += -0.0038569447119316505;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01302823237808665123) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7584510713567840234) ) ) {
              result[0] += -0.0033637071869164472;
            } else {
              result[0] += -0.0069943345579343685;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.09341808925382111273) ) ) {
              result[0] += 0.00023154315352518813;
            } else {
              result[0] += -0.0021278819178289186;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01287800000000000229) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.29500000000000004) ) ) {
            result[0] += -0.002711473528843538;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4050000000000000822) ) ) {
              result[0] += -0.001371874991938022;
            } else {
              result[0] += -0.0003166894891090067;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01761323773984950145) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6858832018090453841) ) ) {
              result[0] += 0.0005552188595678218;
            } else {
              result[0] += -0.002635858927126873;
            }
          } else {
            result[0] += 0.0029062432959556816;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6950000000000000622) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5650000000000000577) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.008624500000000001956) ) ) {
          result[0] += 0.001008996452675928;
        } else {
          result[0] += 0.0036200455778432512;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02577363736079425413) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.0026067499898247267;
          } else {
            result[0] += 0.0034944432088105156;
          }
        } else {
          result[0] += 0.00539980111808458;
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8850000000000001199) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7750000000000001332) ) ) {
          result[0] += 0.0055764224044681145;
        } else {
          result[0] += 0.007225141032334605;
        }
      } else {
        result[0] += 0.009574404075632498;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4850000000000000422) ) ) {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1350000000000000366) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03500000000000001027) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
          result[0] += -0.013460670681267155;
        } else {
          result[0] += -0.010656376358823282;
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.555096866909547848) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01387300000000000165) ) ) {
            result[0] += -0.0073551365148040275;
          } else {
            result[0] += -0.0034595634994047694;
          }
        } else {
          result[0] += -0.008658932879344492;
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2650000000000000688) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1413595000000000268) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5800027599246232457) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01302823237808665123) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.000584175175977650024) ) ) {
                result[0] += -0.004088917103606958;
              } else {
                result[0] += -0.004480835180203243;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2250000000000000333) ) ) {
                result[0] += -0.003770329657981466;
              } else {
                result[0] += -0.0012557844479558833;
              }
            }
          } else {
            result[0] += -0.005515621181754649;
          }
        } else {
          result[0] += 0.0017649093277390152;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0184998371148766029) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4050000000000000822) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.000210500000000000048) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.25500000000000006) ) ) {
                result[0] += -0.005668702181112317;
              } else {
                result[0] += -0.0007272815062198909;
              }
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.009014249010710599294) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006186000000000001393) ) ) {
                  result[0] += -0.0019720487491179657;
                } else {
                  result[0] += 0.00022899783174356995;
                }
              } else {
                result[0] += -0.0028708811625626795;
              }
            }
          } else {
            result[0] += -0.00045915913137761603;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004460500000000000922) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4850000000000000422) ) ) {
              result[0] += -0.0027486713013135547;
            } else {
              result[0] += -0.0006059030060297072;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3650000000000000466) ) ) {
              result[0] += -6.0911185103752096e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1250629713251516228) ) ) {
                result[0] += 0.003890038423772754;
              } else {
                result[0] += 0.0008230668189354133;
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6950000000000000622) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5750000000000000666) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0119121105025029022) ) ) {
          result[0] += 0.0008407170654090142;
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1469960000000000155) ) ) {
            result[0] += 0.0025298572556552183;
          } else {
            result[0] += 0.007679160735416444;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0170586839503055511) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.0024112069513188145;
          } else {
            result[0] += 0.0033705088386823726;
          }
        } else {
          result[0] += 0.004982257970708547;
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8850000000000001199) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01043419202401875238) ) ) {
          result[0] += 0.005378648293695984;
        } else {
          result[0] += 0.006968893255672586;
        }
      } else {
        result[0] += 0.009234837035174075;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4850000000000000422) ) ) {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2250000000000000333) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5271332674874372737) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001350500000000000355) ) ) {
              result[0] += -0.013325355621925302;
            } else {
              result[0] += -0.007852030470941285;
            }
          } else {
            result[0] += -0.012983272811935906;
          }
        } else {
          result[0] += -0.009873142611507348;
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05463331189772155372) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01302823237808665123) ) ) {
            result[0] += -0.0062535933255346305;
          } else {
            result[0] += -0.003404786245712802;
          }
        } else {
          result[0] += -0.007445236094827079;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3150000000000000577) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5800027599246232457) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
              result[0] += -0.0017822018413172882;
            } else {
              result[0] += -0.0035616423179269945;
            }
          } else {
            result[0] += -0.0004165265706925251;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0956005000000000188) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -0.004096921375942805;
            } else {
              result[0] += -0.005788349330011249;
            }
          } else {
            result[0] += -0.001111231563322933;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02261952378991480619) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.555096866909547848) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5150000000000001243) ) ) {
              result[0] += -0.0012532789645195712;
            } else {
              result[0] += 0.00038032014339453525;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.000210500000000000048) ) ) {
              result[0] += -0.0006736197606007501;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4050000000000000822) ) ) {
                result[0] += -0.002423479818916588;
              } else {
                result[0] += -0.0008187265347269138;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004460500000000000922) ) ) {
            result[0] += -0.0007887958636647242;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2145423861003193655) ) ) {
              result[0] += 0.003254966480350428;
            } else {
              result[0] += 0.0005406220285474845;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6950000000000000622) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5850000000000000755) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01868100000000000316) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5850000000000000755) ) ) {
            result[0] += -0.0005218572177286162;
          } else {
            result[0] += 0.0014077424469634812;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02366047096071570086) ) ) {
            result[0] += 0.0016467625390045194;
          } else {
            result[0] += 0.005913334643349741;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0170586839503055511) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.0023256907769517933;
          } else {
            result[0] += 0.003250969940788643;
          }
        } else {
          result[0] += 0.004820225968353795;
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8850000000000001199) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7750000000000001332) ) ) {
          result[0] += 0.005187888464851342;
        } else {
          result[0] += 0.00673281699135373;
        }
      } else {
        result[0] += 0.008907313122836717;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4850000000000000422) ) ) {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2250000000000000333) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04500000000000000527) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5271332674874372737) ) ) {
            result[0] += -0.01262056736370026;
          } else {
            result[0] += -0.01287746766860521;
          }
        } else {
          result[0] += -0.009742423155096873;
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.555096866909547848) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.00421750000000000163) ) ) {
            result[0] += -0.0067100139566723185;
          } else {
            result[0] += -0.00363259713845712;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1450000000000000455) ) ) {
            result[0] += -0.008108771823785657;
          } else {
            result[0] += -0.0051312259290376755;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3250000000000000666) ) ) {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5792515097236182742) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02095879431033080206) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3150000000000000577) ) ) {
                result[0] += -0.003552353100006124;
              } else {
                result[0] += -0.0002812136836084636;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.006186000000000001393) ) ) {
                result[0] += -0.003702388788932629;
              } else {
                result[0] += -0.0019756895821454244;
              }
            }
          } else {
            result[0] += 7.4645699384257e-05;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.09229200000000001292) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += -0.0039054582946883598;
            } else {
              result[0] += -0.005575722415027147;
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4450000000000000622) ) ) {
              result[0] += -0.002862310240210524;
            } else {
              result[0] += 0.001921015280465451;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01262450000000000204) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4050000000000000822) ) ) {
            result[0] += -0.001452113458069264;
          } else {
            result[0] += -0.0002809373406811466;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7003595884880823297) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01148539754569130079) ) ) {
              result[0] += -0.0011479671990495227;
            } else {
              result[0] += 0.0028747835649159705;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0366913419685883091) ) ) {
              result[0] += -0.002037812292576006;
            } else {
              result[0] += 0.0009525821956948143;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6950000000000000622) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.5850000000000000755) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01868100000000000316) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5850000000000000755) ) ) {
            result[0] += -0.0005033489628475673;
          } else {
            result[0] += 0.0013578152731501573;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02528885254406800301) ) ) {
            result[0] += 0.0015883582480125883;
          } else {
            result[0] += 0.005777021462557288;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04014449846134480332) ) ) {
          result[0] += 0.002958454886363464;
        } else {
          result[0] += 0.0054725628028530066;
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8550000000000000933) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01043419202401875238) ) ) {
          result[0] += 0.004649233206757083;
        } else {
          result[0] += 0.006307111900842196;
        }
      } else {
        result[0] += 0.008591405215496973;
      }
    }
  }
}

