
#include "header.h"

void predict_unit4(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7450000000000001066) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.04500000000000000527) ) ) {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
            result[0] += -0.002454360492265968;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7102898410050252354) ) ) {
                result[0] += -0.002165489832358045;
              } else {
                result[0] += -0.0026281866239529204;
              }
            } else {
              result[0] += -0.001937852006736422;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8030059940338053481) ) ) {
              result[0] += -0.0020426929450996774;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003897500000000000357) ) ) {
                result[0] += -0.002403428692626016;
              } else {
                result[0] += -0.0026733979792757747;
              }
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7210440605025126848) ) ) {
              result[0] += -0.0009228916554909946;
            } else {
              result[0] += -0.0019137161295130307;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
          result[0] += -0.0010962323088005805;
        } else {
          result[0] += -0.0021091907115953893;
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4950000000000000511) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1650000000000000355) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01668250000000000288) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
              result[0] += -0.0015286577131399008;
            } else {
              result[0] += -0.002840549509049629;
            }
          } else {
            result[0] += -0.00034805188915107367;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.01704648841990550126) ) ) {
            result[0] += -0.00017339422777752473;
          } else {
            result[0] += -0.0008107344608516075;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1737935000000000174) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.05368089823796016319) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01225471801880190052) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9750000000000000888) ) ) {
                result[0] += 2.760692651957107e-05;
              } else {
                result[0] += 0.001058585157035679;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)25.50000000000000355) ) ) {
                result[0] += 0.0003550261504610957;
              } else {
                result[0] += 0.0016967125322561061;
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5650000000000000577) ) ) {
              result[0] += -0.00024142447993122948;
            } else {
              result[0] += 0.00037019734715656826;
            }
          }
        } else {
          result[0] += 0.002517395179986976;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9550000000000000711) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8950000000000001288) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02687100000000000252) ) ) {
          result[0] += 0.0008829289991388418;
        } else {
          result[0] += 0.0018992394125293807;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03358130704046471265) ) ) {
          result[0] += 0.001151284774660314;
        } else {
          result[0] += 0.001487041062519136;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        result[0] += 0.0013776561974379918;
      } else {
        result[0] += 0.0015551829261054833;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7450000000000001066) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.04500000000000000527) ) ) {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          result[0] += -0.0023841396486217435;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6754021834779359024) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.568345700351758909) ) ) {
                result[0] += -0.0015282444031453988;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  result[0] += -0.002389640237137244;
                } else {
                  result[0] += -0.0016285766505818278;
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01244450000000000243) ) ) {
                result[0] += -0.0013424702321633002;
              } else {
                result[0] += 0.0004570755843868248;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.002552992502074739;
              } else {
                result[0] += -0.001779456541713557;
              }
            } else {
              result[0] += -0.0018614848491275522;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
          result[0] += -0.0010648683922949971;
        } else {
          result[0] += -0.0020488453989807582;
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6350000000000001199) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.29500000000000004) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1650000000000000355) ) ) {
              result[0] += -0.0028015669806580996;
            } else {
              result[0] += -0.0010522655793567264;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
              result[0] += 0.0010219512819109983;
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01363135066340469791) ) ) {
                result[0] += -0.0003833786564090986;
              } else {
                result[0] += -0.0011265002703243392;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5800027599246232457) ) ) {
            result[0] += 3.29832658931314e-05;
          } else {
            result[0] += -0.0006348725327880272;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.144071500000000019) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.009516766579768852138) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
                result[0] += 0.001963386542134452;
              } else {
                result[0] += 0.00014036213915787413;
              }
            } else {
              result[0] += 0.0012920334571912653;
            }
          } else {
            result[0] += 0.0001222279457909955;
          }
        } else {
          result[0] += 0.002349680019944087;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9550000000000000711) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8950000000000001288) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02687100000000000252) ) ) {
          result[0] += 0.0008576678285028027;
        } else {
          result[0] += 0.0018449009425896847;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03358130704046471265) ) ) {
          result[0] += 0.0011183457714429182;
        } else {
          result[0] += 0.0014444958543996496;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        result[0] += 0.0013382405611691416;
      } else {
        result[0] += 0.0015106881351257789;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7650000000000001243) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.04500000000000000527) ) ) {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
            result[0] += -0.00231592786880398;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7586658169597990664) ) ) {
              result[0] += -0.002035164610208701;
            } else {
              result[0] += -0.002479949732735034;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8030059940338053481) ) ) {
              result[0] += -0.0019158810214439086;
            } else {
              result[0] += -0.0025238675618937108;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7210440605025126848) ) ) {
              result[0] += -0.0008608142345973378;
            } else {
              result[0] += -0.0018057051838992935;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
          result[0] += -0.0010344018177585131;
        } else {
          result[0] += -0.0019902266048523586;
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6350000000000001199) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.29500000000000004) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003977500000000001) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)91.50000000000001421) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4674830972361809223) ) ) {
                result[0] += -0.0005971480763481107;
              } else {
                result[0] += -0.0021326703442248423;
              }
            } else {
              result[0] += -0.0010646198778272572;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
              result[0] += 0.0012447461262132234;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.247314011309283543) ) ) {
                result[0] += -0.0006297787699130229;
              } else {
                result[0] += -0.0020608212187960507;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5800027599246232457) ) ) {
            result[0] += 3.159479822734925e-05;
          } else {
            result[0] += -0.0006150088915718835;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.144071500000000019) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.009516766579768852138) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
                result[0] += 0.0018489895146646652;
              } else {
                result[0] += 0.00015207171103064432;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)49.50000000000000711) ) ) {
                result[0] += 0.0006812218108207788;
              } else {
                result[0] += 0.0017270681310559326;
              }
            }
          } else {
            result[0] += 0.00013752386083538728;
          }
        } else {
          result[0] += 0.0022845522227011;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9550000000000000711) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8950000000000001288) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03420850000000000973) ) ) {
          result[0] += 0.0008485048497030628;
        } else {
          result[0] += 0.0018125456489334819;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03358130704046471265) ) ) {
          result[0] += 0.0010863491744458051;
        } else {
          result[0] += 0.0014031678922456952;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        result[0] += 0.0012999526317878062;
      } else {
        result[0] += 0.0014674663689401956;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7650000000000001243) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0022496676721951094;
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6204478727889447542) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4737195465326633492) ) ) {
              result[0] += 0.00047530505264473073;
            } else {
              result[0] += -0.001985679338017694;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += -0.002408996764344011;
            } else {
              result[0] += -0.001572808714144625;
            }
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7473910280653267568) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1350000000000000366) ) ) {
              result[0] += -0.0016493802991890839;
            } else {
              result[0] += 0.0009099022497525454;
            }
          } else {
            result[0] += -0.0019974913185936477;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3350000000000000755) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1550000000000000266) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05963150000000001089) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003182500000000000433) ) ) {
                  result[0] += -0.0011727336343286192;
                } else {
                  result[0] += 0.00022143137296663665;
                }
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)42.50000000000000711) ) ) {
                  result[0] += -0.0018716329268697064;
                } else {
                  result[0] += -0.001270777185972223;
                }
              }
            } else {
              result[0] += -0.002581001947671587;
            }
          } else {
            result[0] += 0.00021552141617030962;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1269590000000000163) ) ) {
              result[0] += -0.0005816184063600374;
            } else {
              result[0] += 0.0012789811990140578;
            }
          } else {
            result[0] += -0.0017075887119396753;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5550000000000001599) ) ) {
          result[0] += 1.7903926558519005e-05;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007548500000000000522) ) ) {
            result[0] += 0.00032172559754104667;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0416553728637082607) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7293938685427137081) ) ) {
                result[0] += 0.0012027260339309653;
              } else {
                result[0] += -0.0005349129416192397;
              }
            } else {
              result[0] += 0.002015542766300328;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9650000000000000799) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8950000000000001288) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2070775000000000254) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
            result[0] += 0.0019627297332148507;
          } else {
            result[0] += 0.0007330973453436236;
          }
        } else {
          result[0] += 0.002013195486204044;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05403737693237045669) ) ) {
          result[0] += 0.0011477182422996962;
        } else {
          result[0] += 0.0014175813570011051;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        result[0] += 0.001382766290066547;
      } else {
        result[0] += 0.0014254812054846945;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7750000000000001332) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.00218530322273527;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8030059940338053481) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4737195465326633492) ) ) {
              result[0] += 0.00026636431513872295;
            } else {
              result[0] += -0.002078249991292776;
            }
          } else {
            result[0] += -0.002340073806342733;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
            result[0] += -0.0016289702194140995;
          } else {
            result[0] += -0.0019403417979728355;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.25500000000000006) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01163003332820435227) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1650000000000000355) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
                result[0] += -0.0023073560641922765;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
                  result[0] += 0.00021396086498591814;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.115000000000000005) ) ) {
                    result[0] += -0.0014584308486784972;
                  } else {
                    result[0] += -0.00012906416696390374;
                  }
                }
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.000726282482777400166) ) ) {
                result[0] += -0.00047383722274851745;
              } else {
                result[0] += -0.0012719327425119152;
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1645630000000000426) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
                result[0] += 0.00012230522534631983;
              } else {
                result[0] += -0.0008399340859756902;
              }
            } else {
              result[0] += 0.0014266284370598576;
            }
          }
        } else {
          result[0] += -0.002344439858333796;
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5750000000000000666) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02664459509800340062) ) ) {
            result[0] += -0.00021850933671181872;
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)90.50000000000001421) ) ) {
              result[0] += 0.0001667289009918942;
            } else {
              result[0] += 0.001372365122624823;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01627850000000000477) ) ) {
            result[0] += 0.0004826660936071257;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06116598190050365896) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.05368089823796016319) ) ) {
                result[0] += 0.0019873278901984515;
              } else {
                result[0] += 0.0003926599544395807;
              }
            } else {
              result[0] += 0.0023118922253519505;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9650000000000000799) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03264450000000000685) ) ) {
          result[0] += 0.0008254526238992466;
        } else {
          result[0] += 0.0017062811885320127;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05403737693237045669) ) ) {
          result[0] += 0.0011148812798835762;
        } else {
          result[0] += 0.001359036517947416;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        result[0] += 0.001343204450737224;
      } else {
        result[0] += 0.0013846972647540865;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7750000000000001332) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0021227802818704422;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8030059940338053481) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5492268452512564236) ) ) {
              if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05227730674148379358) ) ) {
                result[0] += -0.002155514158960047;
              } else {
                result[0] += 0.0006975916833592261;
              }
            } else {
              result[0] += -0.002053064964208475;
            }
          } else {
            result[0] += -0.0022731227788188872;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
            result[0] += -0.0015823643261726513;
          } else {
            result[0] += -0.0018848273621590442;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.29500000000000004) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003732500000000000574) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1550000000000000266) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
              result[0] += -0.002333806025077657;
            } else {
              result[0] += -0.0009635235908751363;
            }
          } else {
            result[0] += -0.0010124929929653565;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.247314011309283543) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1560895000000000199) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += 0.001583486149576253;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.01704648841990550126) ) ) {
                  result[0] += -0.00020335568842584653;
                } else {
                  result[0] += -0.0009587140017546297;
                }
              }
            } else {
              result[0] += 0.0014682495840717025;
            }
          } else {
            result[0] += -0.0017945529089209741;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5550000000000001599) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5800027599246232457) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02620539606947270075) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
                result[0] += 0.0009306415632110088;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.006697829966773901147) ) ) {
                  result[0] += -0.000726237378269719;
                } else {
                  result[0] += 0.0001147121037476868;
                }
              }
            } else {
              result[0] += 0.0014530390564914107;
            }
          } else {
            result[0] += -0.000380692747422082;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01289050000000000092) ) ) {
            result[0] += 0.0003695628783709561;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0129473293797221032) ) ) {
              result[0] += -1.7535207005102937e-05;
            } else {
              result[0] += 0.001687252140663462;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9650000000000000799) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03264450000000000685) ) ) {
          result[0] += 0.0008018358895926139;
        } else {
          result[0] += 0.001657463378381244;
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02018554870724895492) ) ) {
          result[0] += 0.0009542479158474521;
        } else {
          result[0] += 0.0012506630361984892;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        result[0] += 0.0013047745012596868;
      } else {
        result[0] += 0.0013450801789880458;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7750000000000001332) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0020620461628467752;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8030059940338053481) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5492268452512564236) ) ) {
              result[0] += -0.0013171532937981349;
            } else {
              result[0] += -0.0019943254455854318;
            }
          } else {
            result[0] += -0.0022080872635640773;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
            result[0] += -0.0015370918577286281;
          } else {
            result[0] += -0.00183090123031672;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.29500000000000004) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003732500000000000574) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1550000000000000266) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
              result[0] += -0.002267034322836139;
            } else {
              result[0] += -0.0009359565567595001;
            }
          } else {
            result[0] += -0.0009835249125330267;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1245513101099625097) ) ) {
            result[0] += -0.00019049520578503257;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02180250462562445188) ) ) {
              result[0] += -0.001188357445131236;
            } else {
              result[0] += -0.0003982896313879714;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6750000000000001554) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1737935000000000174) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
              result[0] += 0.000402699127534633;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.008408953333664601418) ) ) {
                result[0] += -0.001047735481477812;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002599500000000000682) ) ) {
                  result[0] += -0.0009779441856471458;
                } else {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7269841738944724518) ) ) {
                    result[0] += 0.00041117699419197784;
                  } else {
                    result[0] += -0.0006734837984154123;
                  }
                }
              }
            }
          } else {
            result[0] += 0.002605541004127064;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.144071500000000019) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01055863010420855265) ) ) {
                result[0] += 0.0004014344160390333;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)49.50000000000000711) ) ) {
                  result[0] += 0.000638219457158018;
                } else {
                  result[0] += 0.0017999634128261902;
                }
              }
            } else {
              result[0] += 0.0001339140821734438;
            }
          } else {
            result[0] += 0.0020778663098904456;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9650000000000000799) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03264450000000000685) ) ) {
          result[0] += 0.000778894845353662;
        } else {
          result[0] += 0.0016100422774035785;
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0248788155435312533) ) ) {
          result[0] += 0.000926946264803239;
        } else {
          result[0] += 0.0012315561435276992;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        result[0] += 0.0012674440575320275;
      } else {
        result[0] += 0.0013065965637101358;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7750000000000001332) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.002003049686312575;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8030059940338053481) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5492268452512564236) ) ) {
              result[0] += -0.0012794686847968375;
            } else {
              result[0] += -0.0019372665026422702;
            }
          } else {
            result[0] += -0.002144912456531397;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
            result[0] += -0.0014931146639347687;
          } else {
            result[0] += -0.001778517960040319;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4550000000000000711) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1650000000000000355) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += -0.0021623825021161005;
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
              result[0] += -0.00011212966211708623;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += 0.0008238733362734885;
              } else {
                result[0] += -0.0011133106669150216;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.323165429195979903) ) ) {
            result[0] += 0.0009982904825904702;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.503000764270941431e-05) ) ) {
              result[0] += -0.00017332282044305578;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01205124510104085139) ) ) {
                result[0] += -0.0010692764130681824;
              } else {
                result[0] += -0.00038403319962368226;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.144071500000000019) ) ) {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3539353041941689093) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002478500000000000234) ) ) {
              result[0] += 0.00035268373345837673;
            } else {
              result[0] += 0.0017504617349082031;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4950000000000000511) ) ) {
              result[0] += -0.0002126386949227466;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
                result[0] += 0.0015726924130421995;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.009516766579768852138) ) ) {
                  result[0] += -9.825296969376494e-05;
                } else {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8170108803768846295) ) ) {
                    result[0] += 0.0006322524892061986;
                  } else {
                    result[0] += -0.0010683801890903795;
                  }
                }
              }
            }
          }
        } else {
          result[0] += 0.0020543949584961403;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9650000000000000799) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02812450000000000366) ) ) {
          result[0] += 0.0007432502969436672;
        } else {
          result[0] += 0.0015581424767078821;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03241729119215525784) ) ) {
          result[0] += 0.0009259297703689031;
        } else {
          result[0] += 0.0012491357040312046;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01504150000000000105) ) ) {
          result[0] += 0.001111175516785316;
        } else {
          result[0] += 0.0012761951158697714;
        }
      } else {
        result[0] += 0.001269213989595417;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8650000000000001021) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0019457411371905558;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8030059940338053481) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.568345700351758909) ) ) {
              result[0] += -0.0011299043342444415;
            } else {
              result[0] += -0.0018828206381384322;
            }
          } else {
            result[0] += -0.002083545121653225;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
            result[0] += -0.0014503956861442397;
          } else {
            result[0] += -0.0017276334090609582;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6350000000000001199) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1650000000000000355) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06779550000000000853) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)45.50000000000000711) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01359750000000000195) ) ) {
                  result[0] += -0.0016325975682923647;
                } else {
                  result[0] += -0.0004002540920999844;
                }
              } else {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.714147492562814179) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6010141514957837439) ) ) {
                    result[0] += -0.0008975460670309648;
                  } else {
                    result[0] += 0.0008984013898508786;
                  }
                } else {
                  result[0] += -0.001318624906690882;
                }
              }
            } else {
              result[0] += -0.0022289814776317624;
            }
          } else {
            result[0] += 0.00021877660766508173;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1840395000000000225) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
              result[0] += -0.0003097426126678888;
            } else {
              result[0] += -0.001225248778953449;
            }
          } else {
            result[0] += 0.0024454170618450886;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6950000000000000622) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.144071500000000019) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3539353041941689093) ) ) {
              result[0] += 0.0011524233955756066;
            } else {
              result[0] += 0.0001453003349050001;
            }
          } else {
            result[0] += 0.0018935205726380209;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1377635000000000109) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
              result[0] += 0.001052410879696496;
            } else {
              result[0] += 0.0004487424212738468;
            }
          } else {
            result[0] += 0.001859970457275141;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03358130704046471265) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9450000000000000622) ) ) {
          result[0] += 0.0008994383198116232;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007249500000000001602) ) ) {
            result[0] += 0.0010658995710940461;
          } else {
            result[0] += 0.0008739342811244149;
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)14.50000000000000178) ) ) {
          result[0] += 0.0009132840053634864;
        } else {
          result[0] += 0.00121564796043469;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        result[0] += 0.0013096555032119993;
      } else {
        result[0] += 0.0012329009551429431;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8650000000000001021) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0018900722227839972;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8030059940338053481) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.568345700351758909) ) ) {
              result[0] += -0.0010975770392778175;
            } else {
              result[0] += -0.0018289519199703144;
            }
          } else {
            result[0] += -0.0020239335459803216;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
            result[0] += -0.0014088989259820996;
          } else {
            result[0] += -0.0016782046980486636;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6350000000000001199) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1950000000000000344) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.09500000000000001499) ) ) {
              result[0] += -0.0021177373230487706;
            } else {
              result[0] += -0.0017623084686364033;
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01363135066340469791) ) ) {
              result[0] += -0.00016963066403954884;
            } else {
              result[0] += -0.0009454026337219335;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1957540000000000113) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7293938685427137081) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.009164000000000000271) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.000726282482777400166) ) ) {
                  result[0] += 9.600529933629471e-05;
                } else {
                  result[0] += -0.0006457802391211128;
                }
              } else {
                result[0] += 0.00014162782873021492;
              }
            } else {
              result[0] += -0.000976308259922964;
            }
          } else {
            result[0] += 0.0024763895064631412;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7250000000000000888) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.144071500000000019) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3539353041941689093) ) ) {
              result[0] += 0.0010991902006059946;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
                result[0] += 0.0002728794174111603;
              } else {
                result[0] += -0.00028157263358700367;
              }
            }
          } else {
            result[0] += 0.0019271351614326352;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0195721650588623515) ) ) {
            result[0] += 0.0005919054612259343;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
              result[0] += 0.0020141009946740237;
            } else {
              result[0] += 0.0006077360266338912;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03358130704046471265) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9450000000000000622) ) ) {
          result[0] += 0.000873704806816225;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007249500000000001602) ) ) {
            result[0] += 0.0010354034938641126;
          } else {
            result[0] += 0.000848930455197644;
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)14.50000000000000178) ) ) {
          result[0] += 0.0008871543583350694;
        } else {
          result[0] += 0.0011808674847771407;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        result[0] += 0.0012721854108565175;
      } else {
        result[0] += 0.0011976268601301206;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8650000000000001021) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0018359960320815172;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8030059940338053481) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.568345700351758909) ) ) {
              result[0] += -0.0010661746491621496;
            } else {
              result[0] += -0.0017766244207257076;
            }
          } else {
            result[0] += -0.001966027496104424;
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
            result[0] += -0.0012383846598876744;
          } else {
            result[0] += -0.0015802720332238162;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6350000000000001199) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1550000000000000266) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0501585000000000017) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
                result[0] += -0.00030728162441527194;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)40.50000000000000711) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01359750000000000195) ) ) {
                    result[0] += -0.0018097689772541832;
                  } else {
                    result[0] += -0.00019692824082559118;
                  }
                } else {
                  result[0] += -0.0010693616977427705;
                }
              }
            } else {
              result[0] += -0.0022231312187779863;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03675833313733020691) ) ) {
              result[0] += -0.00043914389590966993;
            } else {
              result[0] += 0.0010775050214648018;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1840395000000000225) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
              result[0] += -0.00031048844310509194;
            } else {
              result[0] += -0.0012177967145789994;
            }
          } else {
            result[0] += 0.0023046009875278216;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.144071500000000019) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7250000000000000888) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3539353041941689093) ) ) {
              result[0] += 0.0010677416568997046;
            } else {
              result[0] += 0.0001652274512578611;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9250000000000001554) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02844215559246820318) ) ) {
                result[0] += 0.0010161529829537908;
              } else {
                result[0] += 0.002276938535681589;
              }
            } else {
              result[0] += 0.000590348305214117;
            }
          }
        } else {
          result[0] += 0.001782015373397004;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9450000000000000622) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9750000000000000888) ) ) {
          result[0] += 0.0016592009274014326;
        } else {
          result[0] += 0.000848707546298065;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007249500000000001602) ) ) {
          result[0] += 0.0010057799291594064;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05403737693237045669) ) ) {
            result[0] += 0.0009042838654235164;
          } else {
            result[0] += 0.0011628181810660713;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        result[0] += 0.0012357873621168473;
      } else {
        result[0] += 0.0011633619798265434;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8650000000000001021) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0017834669962261596;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8030059940338053481) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.568345700351758909) ) ) {
              result[0] += -0.0010356707017704892;
            } else {
              result[0] += -0.0017257940451327926;
            }
          } else {
            result[0] += -0.001909778175827623;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
            result[0] += -0.0013282514371744508;
          } else {
            result[0] += -0.0015849775678915205;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6350000000000001199) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1950000000000000344) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += -0.0019015815306852252;
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
              result[0] += -0.00015509666012101793;
            } else {
              result[0] += -0.000880763049087152;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1840395000000000225) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.323165429195979903) ) ) {
                result[0] += 0.001272112158689511;
              } else {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8155157533417086713) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03241729119215525784) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.000726282482777400166) ) ) {
                      result[0] += -1.907424452992909e-05;
                    } else {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.008602824692653651684) ) ) {
                        result[0] += -0.0009866917430297432;
                      } else {
                        result[0] += -0.00029212532472862535;
                      }
                    }
                  } else {
                    result[0] += 0.0003082712830272119;
                  }
                } else {
                  result[0] += 0.0018748482521835075;
                }
              }
            } else {
              result[0] += -0.0013731734208757879;
            }
          } else {
            result[0] += 0.002128325629519307;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.144071500000000019) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6350000000000001199) ) ) {
            result[0] += 0.00015803415105172805;
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.009516766579768852138) ) ) {
                result[0] += 0.0005649502083317344;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)16.50000000000000355) ) ) {
                  result[0] += 0.0001381114698430935;
                } else {
                  result[0] += 0.0014224887883692162;
                }
              }
            } else {
              result[0] += 0.0003847158017968793;
            }
          }
        } else {
          result[0] += 0.0017310307591558488;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04088342693368870323) ) ) {
        result[0] += 0.0008784117182291675;
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)43.50000000000000711) ) ) {
          result[0] += 0.0009445573148934382;
        } else {
          result[0] += 0.001167895522482005;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        result[0] += 0.0009994983243973021;
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04324794178047625809) ) ) {
          result[0] += 0.0011300774399456;
        } else {
          result[0] += 0.0011300774399456;
        }
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8650000000000001021) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0017324408501154845;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8030059940338053481) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4737195465326633492) ) ) {
              result[0] += 0.000470382802625233;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00279350000000000041) ) ) {
                result[0] += -0.001720085093400862;
              } else {
                result[0] += -0.001367167183712129;
              }
            }
          } else {
            result[0] += -0.0018551381850428418;
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
            result[0] += -0.0011649515384569164;
          } else {
            result[0] += -0.0014970572925636816;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6350000000000001199) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1650000000000000355) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01882700000000000345) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1250000000000000278) ) ) {
                  result[0] += -0.0017732793029362425;
                } else {
                  result[0] += -0.0011304459910954545;
                }
              } else {
                result[0] += -0.000977766185014222;
              }
            } else {
              result[0] += -0.00013897559153905204;
            }
          } else {
            result[0] += -0.0020499764911540014;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007249500000000001602) ) ) {
            result[0] += -0.0005017428382443819;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.008408953333664601418) ) ) {
              result[0] += -0.0010170280630033726;
            } else {
              result[0] += 0.00023535393747445253;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.144071500000000019) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6850000000000001643) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01075889670750075112) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9750000000000000888) ) ) {
                  result[0] += -0.00011203166205731984;
                } else {
                  result[0] += 0.0009501265150568065;
                }
              } else {
                result[0] += 0.0006054250168749078;
              }
            } else {
              result[0] += -0.00032509568571667866;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
              result[0] += 0.0009453346925465925;
            } else {
              result[0] += 0.00038704062794338556;
            }
          }
        } else {
          result[0] += 0.0016815048477565012;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04088342693368870323) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.07172822906307056712) ) ) {
          result[0] += 0.0009654134232541744;
        } else {
          result[0] += 0.000620748844165539;
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)77.50000000000001421) ) ) {
          result[0] += 0.0010144925530067856;
        } else {
          result[0] += 0.0012183949918421198;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        result[0] += 0.0009709020298507879;
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04324794178047625809) ) ) {
          result[0] += 0.001097745192312725;
        } else {
          result[0] += 0.001097745192312725;
        }
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8650000000000001021) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.001682874595100309;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8030059940338053481) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4737195465326633492) ) ) {
              result[0] += 0.0004569248459232069;
            } else {
              result[0] += -0.0016020467841256962;
            }
          } else {
            result[0] += -0.0018020614797907724;
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
            result[0] += -0.0011316215202738266;
          } else {
            result[0] += -0.0014542255136140026;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6650000000000001465) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.29500000000000004) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1550000000000000266) ) ) {
              result[0] += -0.001921782455303592;
            } else {
              result[0] += -0.0008329078041737689;
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
              result[0] += -0.00018042724231534426;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += 0.0008913784541609142;
              } else {
                result[0] += -0.0008941685115977389;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02092750000000000513) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
              result[0] += 0.000438015823523995;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002599500000000000682) ) ) {
                result[0] += -0.0008522745296425849;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.008408953333664601418) ) ) {
                  result[0] += -0.0010205363493403347;
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)34.50000000000000711) ) ) {
                    result[0] += -0.0006880054513375345;
                  } else {
                    result[0] += 0.00040548893997716524;
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02664459509800340062) ) ) {
              result[0] += -0.00023563221244568962;
            } else {
              result[0] += 0.0014008917247363998;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.144071500000000019) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02844215559246820318) ) ) {
              result[0] += 0.0005686743086498995;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)39.50000000000000711) ) ) {
                result[0] += 0.00046031964676676427;
              } else {
                result[0] += 0.0019640514749624223;
              }
            }
          } else {
            result[0] += 0.0001707242630550213;
          }
        } else {
          result[0] += 0.0016216155517741096;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04088342693368870323) ) ) {
        result[0] += 0.0008269850642388563;
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)77.50000000000001421) ) ) {
          result[0] += 0.0009854672638663345;
        } else {
          result[0] += 0.0011835359218364508;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01504150000000000105) ) ) {
          result[0] += 0.0009341139775751593;
        } else {
          result[0] += 0.001144056254549582;
        }
      } else {
        result[0] += 0.0010663379912297963;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8650000000000001021) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.001634726462750658;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8030059940338053481) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4737195465326633492) ) ) {
              result[0] += 0.0004438519300806314;
            } else {
              result[0] += -0.0015562111878091335;
            }
          } else {
            result[0] += -0.0017505033334596122;
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
            result[0] += -0.0010992450955024907;
          } else {
            result[0] += -0.0014126191796069501;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6650000000000001465) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1950000000000000344) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)75.50000000000001421) ) ) {
              result[0] += -0.0021009662013725863;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.06536400211476856) ) ) {
                result[0] += -0.0011481377773377112;
              } else {
                result[0] += -0.002010616329561084;
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += 0.0010928314693331611;
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
                result[0] += -0.00014483491556846362;
              } else {
                result[0] += -0.0008839386677518551;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1840395000000000225) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7293938685427137081) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.323165429195979903) ) ) {
                result[0] += 0.001272123133958119;
              } else {
                result[0] += -0.00023347377271880717;
              }
            } else {
              result[0] += -0.0008721956358591012;
            }
          } else {
            result[0] += 0.002174205893479927;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.144071500000000019) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02844215559246820318) ) ) {
              result[0] += 0.0005524041682862373;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)32.50000000000000711) ) ) {
                result[0] += 0.0003625471893446577;
              } else {
                result[0] += 0.0018965046819456055;
              }
            }
          } else {
            result[0] += 0.00016583973129204833;
          }
        } else {
          result[0] += 0.0015752200803382731;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04088342693368870323) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.07172822906307056712) ) ) {
          result[0] += 0.0009141317413924405;
        } else {
          result[0] += 0.0005793282391888647;
        }
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)77.50000000000001421) ) ) {
          result[0] += 0.0009572724070510802;
        } else {
          result[0] += 0.0011496741924057153;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01504150000000000105) ) ) {
          result[0] += 0.0009073883715478925;
        } else {
          result[0] += 0.0011113240639752644;
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04324794178047625809) ) ) {
          result[0] += 0.0010358293705157655;
        } else {
          result[0] += 0.0010358293705157655;
        }
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8650000000000001021) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0015879558796583963;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8030059940338053481) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4737195465326633492) ) ) {
              result[0] += 0.0004311530388290844;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00279350000000000041) ) ) {
                result[0] += -0.0015805125380597524;
              } else {
                result[0] += -0.0012376918383911412;
              }
            }
          } else {
            result[0] += -0.0017004202990948945;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.115000000000000005) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
              result[0] += -0.001175775878742242;
            } else {
              result[0] += -0.0014147762701142135;
            }
          } else {
            result[0] += 0.0011085443830216029;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3850000000000000644) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            result[0] += -0.001829078906963556;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
              result[0] += -4.94381023665299e-05;
            } else {
              result[0] += -0.000844638576894955;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2070775000000000254) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
              result[0] += -8.537497114651126e-05;
            } else {
              result[0] += -0.0006373671123803614;
            }
          } else {
            result[0] += 0.0027135643335671725;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1645630000000000426) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6350000000000001199) ) ) {
            result[0] += 0.00010324383794350072;
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0133385000000000014) ) ) {
                result[0] += 0.0006123080294564294;
              } else {
                result[0] += 0.0015664984039956526;
              }
            } else {
              result[0] += 0.00035835404689583234;
            }
          }
        } else {
          result[0] += 0.0016084646877788167;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9550000000000000711) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9750000000000000888) ) ) {
          result[0] += 0.0014759120194448561;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08188550000000001383) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.08693186820944626136) ) ) {
              result[0] += 0.0008435985739137349;
            } else {
              result[0] += 0.0004472408776390734;
            }
          } else {
            result[0] += 0.0012064905217704803;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007249500000000001602) ) ) {
          result[0] += 0.0008766807097598515;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05502768819289250574) ) ) {
            result[0] += 0.0007952842287315136;
          } else {
            result[0] += 0.0011183234878470766;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        result[0] += 0.001079528362577535;
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04324794178047625809) ) ) {
          result[0] += 0.0010061936212041695;
        } else {
          result[0] += 0.0010061936212041695;
        }
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.875000000000000111) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.001542523433246879;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4737195465326633492) ) ) {
              result[0] += 0.00041881747108271893;
            } else {
              result[0] += -0.0014762758123098298;
            }
          } else {
            result[0] += -0.001651770172787667;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.115000000000000005) ) ) {
            result[0] += -0.0012745668170132051;
          } else {
            result[0] += 0.0010768282100966648;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6650000000000001465) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.29500000000000004) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1550000000000000266) ) ) {
              result[0] += -0.0017749630595884102;
            } else {
              result[0] += -0.000783759057825935;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += 0.0010857305098985423;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.144071500000000019) ) ) {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
                  result[0] += -0.0002247815349499271;
                } else {
                  result[0] += -0.0008619415311415241;
                }
              } else {
                result[0] += 0.0012779056306222057;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7293938685427137081) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02092750000000000513) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
                result[0] += 0.0005904481575041491;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002599500000000000682) ) ) {
                  result[0] += -0.0007849677827512075;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.008408953333664601418) ) ) {
                    result[0] += -0.0007783350940109478;
                  } else {
                    result[0] += 0.0002511126707207492;
                  }
                }
              }
            } else {
              result[0] += 0.0007495806877878597;
            }
          } else {
            result[0] += -0.0007361173043489361;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.144071500000000019) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7250000000000000888) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3539353041941689093) ) ) {
              result[0] += 0.0010286810964227275;
            } else {
              result[0] += 0.00012453677933355723;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9250000000000001554) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01437243042433420173) ) ) {
                result[0] += 0.0005725971405424342;
              } else {
                result[0] += 0.001947496830499115;
              }
            } else {
              result[0] += 0.0005059387465774177;
            }
          }
        } else {
          result[0] += 0.0014795822119616435;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05403737693237045669) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.08390973343508316418) ) ) {
          result[0] += 0.0008563449993929947;
        } else {
          result[0] += 0.000579788585289797;
        }
      } else {
        result[0] += 0.000970980835466855;
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        result[0] += 0.0010486423567943849;
      } else {
        result[0] += 0.0009774057698787274;
      }
    }
  }
}

