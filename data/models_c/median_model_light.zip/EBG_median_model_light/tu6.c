
#include "header.h"

void predict_unit6(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9450000000000000622) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0009147699012234897;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8030059940338053481) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00279350000000000041) ) ) {
              result[0] += -0.0009197324577420404;
            } else {
              result[0] += -0.0005925386821525787;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.0009795570071985083;
              } else {
                result[0] += -0.0004361293399845413;
              }
            } else {
              result[0] += -0.0009795570071985083;
            }
          }
        } else {
          result[0] += -0.0007150094699401075;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6150000000000001021) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.29500000000000004) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1550000000000000266) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
                result[0] += -0.0011106229892501637;
              } else {
                result[0] += -0.00134189598139406;
              }
            } else {
              result[0] += -0.00043898089494846966;
            }
          } else {
            result[0] += -0.00033053930349620107;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2070775000000000254) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02085144663384500344) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
                  result[0] += 0.0005318727840260032;
                } else {
                  result[0] += -0.00021684378377448676;
                }
              } else {
                result[0] += 0.0004731456922909383;
              }
            } else {
              result[0] += -0.0004208614717479902;
            }
          } else {
            result[0] += 0.0017296079490950668;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03507550000000000251) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8950000000000001288) ) ) {
            result[0] += 0.0003000861231599184;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
              result[0] += 0.0009328700968508656;
            } else {
              result[0] += 0.0003183384923869275;
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04557577292723340862) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5521365942211056144) ) ) {
              result[0] += 0.0010178835680583307;
            } else {
              result[0] += -0.00015723511237498907;
            }
          } else {
            result[0] += 0.000950453699927212;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05403737693237045669) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007249500000000001602) ) ) {
            result[0] += 0.0005075238022115938;
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)121.5000000000000142) ) ) {
              result[0] += 0.00026421877786890805;
            } else {
              result[0] += 0.0005453832636508949;
            }
          }
        } else {
          result[0] += 0.000600087952107423;
        }
      } else {
        result[0] += 0.0006257251506357156;
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0416553728637082607) ) ) {
        result[0] += 0.0005796355246838782;
      } else {
        result[0] += 0.0005796355246838782;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9450000000000000622) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0008885977417519395;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8030059940338053481) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00279350000000000041) ) ) {
              result[0] += -0.0008934183163136982;
            } else {
              result[0] += -0.0005755857666034142;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.0009515312466552452;
              } else {
                result[0] += -0.0004236513970384181;
              }
            } else {
              result[0] += -0.0009515312466552452;
            }
          }
        } else {
          result[0] += -0.0006945525858144796;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6150000000000001021) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2350000000000000144) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09856400000000001271) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
                result[0] += 2.2982453771537247e-05;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)45.50000000000000711) ) ) {
                  result[0] += -0.0009460791688264657;
                } else {
                  result[0] += -0.0004448149305376332;
                }
              }
            } else {
              result[0] += 0.0005896349653164997;
            }
          } else {
            result[0] += -0.0012333794500595091;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007100500000000000908) ) ) {
            result[0] += -0.00013250447141924316;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.008408953333664601418) ) ) {
              result[0] += -0.000695003728531712;
            } else {
              result[0] += 0.0004511295585115437;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03507550000000000251) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8950000000000001288) ) ) {
            result[0] += 0.00029150046477737233;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
              result[0] += 0.0009061800790569202;
            } else {
              result[0] += 0.0003092306218967196;
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04557577292723340862) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5521365942211056144) ) ) {
              result[0] += 0.00098876125978052;
            } else {
              result[0] += -0.00015273651395138438;
            }
          } else {
            result[0] += 0.0009232606038584094;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02756847298310730401) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007249500000000001602) ) ) {
          result[0] += 0.0004930032174510711;
        } else {
          result[0] += 0.00026618811281572556;
        }
      } else {
        result[0] += 0.0005568718204210641;
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04250871378122500488) ) ) {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0005630517768286941;
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01075889670750075112) ) ) {
            result[0] += 0.0005630517768286941;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01154850000000000147) ) ) {
              result[0] += 0.0005630517768286941;
            } else {
              result[0] += 0.0005630517768286941;
            }
          }
        }
      } else {
        result[0] += 0.0005630517768286941;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9450000000000000622) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0008631743847174699;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8030059940338053481) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00279350000000000041) ) ) {
              result[0] += -0.000867857039518198;
            } else {
              result[0] += -0.000559117884950388;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.0009243073212765069;
              } else {
                result[0] += -0.0004115304561233261;
              }
            } else {
              result[0] += -0.0009243073212765069;
            }
          }
        } else {
          result[0] += -0.0006746809863958705;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6150000000000001021) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.25500000000000006) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01882700000000000345) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)45.50000000000000711) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
                  result[0] += -6.590133900521464e-05;
                } else {
                  result[0] += -0.0010191679731106284;
                }
              } else {
                result[0] += -0.0003949900020770778;
              }
            } else {
              result[0] += 4.4545002108275754e-05;
            }
          } else {
            result[0] += -0.001150307374980973;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04407393373669900999) ) ) {
            result[0] += -5.065779422861549e-05;
          } else {
            result[0] += 0.000661299633439117;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03507550000000000251) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8950000000000001288) ) ) {
            result[0] += 0.00028316044764303144;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
              result[0] += 0.0008802536799621313;
            } else {
              result[0] += 0.0003003833334814117;
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04557577292723340862) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5521365942211056144) ) ) {
              result[0] += 0.0009604721596082737;
            } else {
              result[0] += -0.00014836662334291684;
            }
          } else {
            result[0] += 0.0008968455198841085;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02756847298310730401) ) ) {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007249500000000001602) ) ) {
          result[0] += 0.0004788980760271363;
        } else {
          result[0] += 0.00025857229846861255;
        }
      } else {
        result[0] += 0.0005409393568914051;
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04250871378122500488) ) ) {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0005469425007427726;
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01075889670750075112) ) ) {
            result[0] += 0.0005469425007427726;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01154850000000000147) ) ) {
              result[0] += 0.0005469425007427726;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)107.5000000000000142) ) ) {
                result[0] += 0.0005469425007427726;
              } else {
                result[0] += 0.0005469425007427726;
              }
            }
          }
        }
      } else {
        result[0] += 0.0005469425007427726;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9450000000000000622) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0008384784063972743;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8030059940338053481) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00279350000000000041) ) ) {
              result[0] += -0.0008430270874106805;
            } else {
              result[0] += -0.0005431211600595212;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.0008978622900387991;
              } else {
                result[0] += -0.0003997563031798875;
              }
            } else {
              result[0] += -0.0008978622900387991;
            }
          }
        } else {
          result[0] += -0.0006553779263096584;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6150000000000001021) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2850000000000000866) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.027057242659878707e-06) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.80526473097989959) ) ) {
              result[0] += -0.0009043291389942387;
            } else {
              result[0] += -0.0017851844294352408;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
              result[0] += 0.00010708022198641147;
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1185261981962025396) ) ) {
                result[0] += -0.0018048585009153904;
              } else {
                result[0] += -0.00044187682676869453;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2070775000000000254) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5826692266582915725) ) ) {
              result[0] += 0.00014259330587273228;
            } else {
              result[0] += -0.0002164524275731675;
            }
          } else {
            result[0] += 0.0016543293685103554;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0131020000000000008) ) ) {
          result[0] += 0.0002564338096671405;
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02937690275817125482) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2846413682100536469) ) ) {
              result[0] += 0.001306184075372868;
            } else {
              result[0] += 0.00013783934481466625;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)37.50000000000000711) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06997050552869731044) ) ) {
                result[0] += -0.00016411953264676562;
              } else {
                result[0] += 0.0008168315960376811;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.05368089823796016319) ) ) {
                result[0] += 0.0010066454877051528;
              } else {
                result[0] += 0.0006211719021774196;
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.07172822906307056712) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02989549209881260314) ) ) {
          result[0] += 0.0004651964918367968;
        } else {
          result[0] += 0.0006224942036157673;
        }
      } else {
        result[0] += 0.0003453405159912113;
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04250871378122500488) ) ) {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
          result[0] += 0.0005312941214814291;
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01075889670750075112) ) ) {
            result[0] += 0.0005312941214814291;
          } else {
            result[0] += 0.0005312941214814291;
          }
        }
      } else {
        result[0] += 0.0005312941214814291;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9650000000000000799) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0008144889960151335;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8030059940338053481) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4737195465326633492) ) ) {
              result[0] += 0.0007251654919424239;
            } else {
              result[0] += -0.0007879880779523875;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.000872173868276171;
              } else {
                result[0] += -0.0003883190163795808;
              }
            } else {
              result[0] += -0.000872173868276171;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06439350000000000629) ) ) {
            result[0] += -0.0007310704147659706;
          } else {
            result[0] += 0.0002716263107269898;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6750000000000001554) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2750000000000000777) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.007360548858857050326) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01439950000000000084) ) ) {
                result[0] += -0.0006081085906016675;
              } else {
                result[0] += -0.0017441089600701354;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01154850000000000147) ) ) {
                result[0] += -0.00041659079390594;
              } else {
                result[0] += 0.00014457331213036073;
              }
            }
          } else {
            result[0] += -0.0011012275271708553;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1737935000000000174) ) ) {
            result[0] += 3.423710501072347e-05;
          } else {
            result[0] += 0.0012813206654318878;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02447420998234165271) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2669585275879397535) ) ) {
            result[0] += 0.001122748610308546;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)86.50000000000001421) ) ) {
              result[0] += 5.526090259519253e-05;
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2185860198827210554) ) ) {
                result[0] += 0.0005964908294582873;
              } else {
                result[0] += 0.0002590468653996066;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)41.50000000000000711) ) ) {
            result[0] += 0.00027114872763305654;
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01778816268138619719) ) ) {
              result[0] += 0.0008198062009266992;
            } else {
              result[0] += 0.0004432266560369424;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007249500000000001602) ) ) {
        result[0] += 0.000451886918846173;
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02708729125130565282) ) ) {
          result[0] += 0.00033936863390028463;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)23.50000000000000355) ) ) {
            result[0] += 0.00034458470501456983;
          } else {
            result[0] += 0.0005608644243839456;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04324794178047625809) ) ) {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.6250640499379888082) ) ) {
          result[0] += 0.0005160934524879348;
        } else {
          result[0] += 0.0005160934524879348;
        }
      } else {
        result[0] += 0.0005160934524879348;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9650000000000000799) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0007911859382046175;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8030059940338053481) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += -0.0008286370570614013;
            } else {
              result[0] += 2.620593185359087e-05;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.0008472204089014009;
              } else {
                result[0] += -0.00037720895776382525;
              }
            } else {
              result[0] += -0.0008472204089014009;
            }
          }
        } else {
          result[0] += -0.0006236417704399808;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6750000000000001554) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2750000000000000777) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.007360548858857050326) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01439950000000000084) ) ) {
                result[0] += -0.0005907102098854241;
              } else {
                result[0] += -0.0016942088728704328;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01154850000000000147) ) ) {
                result[0] += -0.0004046718614204011;
              } else {
                result[0] += 0.00014043697601420172;
              }
            }
          } else {
            result[0] += -0.0010697206942317436;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1737935000000000174) ) ) {
            result[0] += 3.325755925721084e-05;
          } else {
            result[0] += 0.001244661251140903;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02447420998234165271) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2669585275879397535) ) ) {
            result[0] += 0.0010906260452392797;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)86.50000000000001421) ) ) {
              result[0] += 5.3679852373350334e-05;
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2185860198827210554) ) ) {
                result[0] += 0.0005794248404144622;
              } else {
                result[0] += 0.00025163536676724575;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)41.50000000000000711) ) ) {
            result[0] += 0.0002633909868824836;
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01778816268138619719) ) ) {
              result[0] += 0.0007963510144391221;
            } else {
              result[0] += 0.0004305456542808452;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01289050000000000092) ) ) {
        result[0] += 0.0004441416533136922;
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07802786554345496339) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)44.50000000000000711) ) ) {
            result[0] += 0.00016559931504757182;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1245513101099625097) ) ) {
              result[0] += 0.0005727466796436448;
            } else {
              result[0] += 0.00023158440516340463;
            }
          }
        } else {
          result[0] += 0.0005448177298684577;
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04324794178047625809) ) ) {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.6250640499379888082) ) ) {
          result[0] += 0.000501327684481498;
        } else {
          result[0] += 0.000501327684481498;
        }
      } else {
        result[0] += 0.000501327684481498;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9650000000000000799) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.000768549595974026;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8030059940338053481) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += -0.000804929214059089;
            } else {
              result[0] += 2.5456163166781706e-05;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
              result[0] += -0.0008229808841644559;
            } else {
              result[0] += -0.0008229808841644559;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06439350000000000629) ) ) {
            result[0] += -0.0006923112215504515;
          } else {
            result[0] += 0.0002816977010686888;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6750000000000001554) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2350000000000000144) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += 0.0008935321749313917;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09856400000000001271) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
                  result[0] += 8.063537400545095e-08;
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)45.50000000000000711) ) ) {
                    result[0] += -0.0008985345901966251;
                  } else {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
                      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.036113539341048927e-06) ) ) {
                        result[0] += -0.0005174521317241137;
                      } else {
                        result[0] += -0.0019288343433198829;
                      }
                    } else {
                      result[0] += -0.0003010677811540715;
                    }
                  }
                }
              } else {
                result[0] += 0.0005573655705175058;
              }
            }
          } else {
            result[0] += -0.0010876399748893635;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007100500000000000908) ) ) {
            result[0] += -9.64787195492278e-05;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.008408953333664601418) ) ) {
              result[0] += -0.0006786796237511428;
            } else {
              result[0] += 0.0004942123378785928;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02447420998234165271) ) ) {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2883407947516276049) ) ) {
            result[0] += 0.0004841874782430979;
          } else {
            result[0] += 0.00015390042067395054;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)41.50000000000000711) ) ) {
            result[0] += 0.0002558552001203304;
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01778816268138619719) ) ) {
              result[0] += 0.0007735668960314718;
            } else {
              result[0] += 0.00041822746419987637;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007249500000000001602) ) ) {
        result[0] += 0.0004262509609399627;
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02708729125130565282) ) ) {
          result[0] += 0.0003196582743937555;
        } else {
          result[0] += 0.0005292301416782752;
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04324794178047625809) ) ) {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.6250640499379888082) ) ) {
          result[0] += 0.0004869843746631443;
        } else {
          result[0] += 0.0004869843746631443;
        }
      } else {
        result[0] += 0.0004869843746631443;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9650000000000000799) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0007465608941587118;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8030059940338053481) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += -0.0007818996678032628;
            } else {
              result[0] += 2.4727845847810402e-05;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
              result[0] += -0.0007994348679328536;
            } else {
              result[0] += -0.0007994348679328536;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06439350000000000629) ) ) {
            result[0] += -0.0006725037490154154;
          } else {
            result[0] += 0.0002736381473543852;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6750000000000001554) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2750000000000000777) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02085144663384500344) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4296173751758793902) ) ) {
                result[0] += 0.0003816798121611223;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)45.50000000000000711) ) ) {
                  result[0] += -0.0008032921273290566;
                } else {
                  result[0] += -0.0003994932153742859;
                }
              }
            } else {
              result[0] += 7.253378164273924e-05;
            }
          } else {
            result[0] += -0.0010079972079272976;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007100500000000000908) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
              result[0] += 0.0004674191250677413;
            } else {
              result[0] += -0.00015040356829585413;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.008408953333664601418) ) ) {
              result[0] += -0.0006135726487641368;
            } else {
              result[0] += 0.0004939587668759056;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02447420998234165271) ) ) {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3539353041941689093) ) ) {
            result[0] += 0.0004977828096541909;
          } else {
            result[0] += 0.00016079267415332042;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)41.50000000000000711) ) ) {
            result[0] += 0.0002485350170992043;
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01778816268138619719) ) ) {
              result[0] += 0.0007514346460112544;
            } else {
              result[0] += 0.0004062617055169767;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007249500000000001602) ) ) {
        result[0] += 0.0004140556448176229;
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1117617829768308563) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)35.50000000000000711) ) ) {
            result[0] += 0.00027281557806807917;
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4516066347997827468) ) ) {
              result[0] += 0.0005702427820818471;
            } else {
              result[0] += 0.0004187704115434626;
            }
          }
        } else {
          result[0] += 0.0005140885244840176;
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04324794178047625809) ) ) {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.6250640499379888082) ) ) {
          result[0] += 0.00047305143623044217;
        } else {
          result[0] += 0.00047305143623044217;
        }
      } else {
        result[0] += 0.00047305143623044217;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9650000000000000799) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0007252013033468457;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7586658169597990664) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01075889670750075112) ) ) {
              result[0] += -0.0006175019599609342;
            } else {
              result[0] += -7.733927712009335e-06;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += -0.0007765625184789941;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.599834298791339877e-06) ) ) {
                result[0] += -0.0012786904959475485;
              } else {
                result[0] += -0.0004630290227670365;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -0.0007765625184789941;
          } else {
            result[0] += -0.0008943223201006291;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6750000000000001554) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2750000000000000777) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6152470170603016042) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.006369601946274350453) ) ) {
              result[0] += -0.00048171243421913284;
            } else {
              result[0] += 0.00012543589854791508;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07959200000000000996) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8155157533417086713) ) ) {
                  result[0] += -0.0006180652678657928;
                } else {
                  result[0] += 0.001169418581000283;
                }
              } else {
                result[0] += -0.0010163612755442221;
              }
            } else {
              result[0] += 0.0002697254761844737;
            }
          }
        } else {
          result[0] += 5.884392623683751e-05;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)109.5000000000000142) ) ) {
            result[0] += 0.00018919758850464264;
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01778816268138619719) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01871178646485605404) ) ) {
                result[0] += 0.0004550663894951849;
              } else {
                result[0] += 0.0008400570159864842;
              }
            } else {
              result[0] += 0.00035115453829919553;
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04557577292723340862) ) ) {
            result[0] += 0.0004572177223692549;
          } else {
            result[0] += 0.0007062719490699904;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01289050000000000092) ) ) {
        result[0] += 0.00040598496970231163;
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08260095417535827378) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)34.50000000000000711) ) ) {
            result[0] += 1.7221535052771555e-05;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1405997886577425304) ) ) {
              result[0] += 0.0005211900542647262;
            } else {
              result[0] += 0.00022759241526400673;
            }
          }
        } else {
          result[0] += 0.0005014350985406488;
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04324794178047625809) ) ) {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.6250640499379888082) ) ) {
          result[0] += 0.00045951712819220224;
        } else {
          result[0] += 0.00045951712819220224;
        }
      } else {
        result[0] += 0.00045951712819220224;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9650000000000000799) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0007044528242650742;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7586658169597990664) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01075889670750075112) ) ) {
              result[0] += -0.0005998348288621991;
            } else {
              result[0] += -7.512655030049238e-06;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += -0.0007543445617599575;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.599834298791339877e-06) ) ) {
                result[0] += -0.001242106332509361;
              } else {
                result[0] += -0.0004497814624706092;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -0.0007543445617599575;
          } else {
            result[0] += -0.0008687351791711616;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6750000000000001554) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2750000000000000777) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
            result[0] += 9.145793373048421e-05;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07959200000000000996) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8155157533417086713) ) ) {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)45.50000000000000711) ) ) {
                    result[0] += -0.000786574388954601;
                  } else {
                    result[0] += -0.00036390108927289764;
                  }
                } else {
                  result[0] += 0.0011359607578362305;
                }
              } else {
                result[0] += -0.0009872825210413968;
              }
            } else {
              result[0] += 0.0003707905318177662;
            }
          }
        } else {
          result[0] += 5.716036338748989e-05;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)109.5000000000000142) ) ) {
            result[0] += 0.00018378452293334;
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01778816268138619719) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01871178646485605404) ) ) {
                result[0] += 0.00044204664529494186;
              } else {
                result[0] += 0.0008160224405613574;
              }
            } else {
              result[0] += 0.0003411077794768603;
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04557577292723340862) ) ) {
            result[0] += 0.0004441364271418288;
          } else {
            result[0] += 0.0006860650510767132;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01289050000000000092) ) ) {
        result[0] += 0.0003943694767178017;
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08260095417535827378) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)34.50000000000000711) ) ) {
            result[0] += 1.6728815778619972e-05;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1405997886577425304) ) ) {
              result[0] += 0.0005062784691798221;
            } else {
              result[0] += 0.00022108084882654634;
            }
          }
        } else {
          result[0] += 0.0004870887155364804;
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04324794178047625809) ) ) {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.6250640499379888082) ) ) {
          result[0] += 0.0004463700454746017;
        } else {
          result[0] += 0.0004463700454746017;
        }
      } else {
        result[0] += 0.0004463700454746017;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9650000000000000799) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0006842979726109149;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.0006135030770484003;
              } else {
                result[0] += 0.00017624228785406546;
              }
            } else {
              result[0] += -0.000732762275175678;
            }
          } else {
            result[0] += -0.000732762275175678;
          }
        } else {
          result[0] += -0.0005494489544791277;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6750000000000001554) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2850000000000000866) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.027057242659878707e-06) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.80526473097989959) ) ) {
              result[0] += -0.0007986179282943996;
            } else {
              result[0] += -0.0015789728869623878;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)45.50000000000000711) ) ) {
              result[0] += -0.0005570135723539322;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.435405567110552727) ) ) {
                result[0] += 0.0008613092351187757;
              } else {
                result[0] += -0.00018482437430391546;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.05368089823796016319) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.009516766579768852138) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
                result[0] += 0.0007513216540279942;
              } else {
                result[0] += -0.0003719393569985033;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)22.50000000000000355) ) ) {
                result[0] += -0.00016569873965306252;
              } else {
                result[0] += 0.0008977941695502362;
              }
            }
          } else {
            result[0] += -0.000110437762256346;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)109.5000000000000142) ) ) {
            result[0] += 0.000178526328674674;
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01778816268138619719) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01871178646485605404) ) ) {
                result[0] += 0.0004293994044105968;
              } else {
                result[0] += 0.0007926755099089931;
              }
            } else {
              result[0] += 0.0003313484649328275;
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04557577292723340862) ) ) {
            result[0] += 0.0004314293962450612;
          } else {
            result[0] += 0.0006664362855252654;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007249500000000001602) ) ) {
        result[0] += 0.0003793105853997024;
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
          result[0] += 0.0002756326921371433;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)22.50000000000000355) ) ) {
            result[0] += 0.00026100599557979306;
          } else {
            result[0] += 0.0004731527918437976;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04324794178047625809) ) ) {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.6250640499379888082) ) ) {
          result[0] += 0.00043359910931037;
        } else {
          result[0] += 0.00043359910931037;
        }
      } else {
        result[0] += 0.00043359910931037;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9650000000000000799) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0006647197643191054;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7593447680904524821) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.32337995336020553) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.000595950356580311;
              } else {
                result[0] += 3.3539901920494844e-05;
              }
            } else {
              result[0] += -0.0010405652551178349;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
              result[0] += -0.0007117974717918067;
            } else {
              result[0] += -0.0007117974717918067;
            }
          }
        } else {
          result[0] += -0.0005337288639526784;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6750000000000001554) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2850000000000000866) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += 0.0008510285882074473;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.027057242659878707e-06) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.80526473097989959) ) ) {
                result[0] += -0.0008104451777460645;
              } else {
                result[0] += -0.0015642607662445793;
              }
            } else {
              result[0] += -0.00031715952594783516;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02092750000000000513) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
              result[0] += 0.0004717945334263657;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.004621314935084650834) ) ) {
                result[0] += -0.0005525411761936536;
              } else {
                result[0] += -3.836417497098105e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02664459509800340062) ) ) {
              result[0] += -9.80484616315321e-05;
            } else {
              result[0] += 0.000929624659925846;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)109.5000000000000142) ) ) {
            result[0] += 0.00017341857476006203;
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01778816268138619719) ) ) {
              result[0] += 0.0006123549988512314;
            } else {
              result[0] += 0.0003218683707000834;
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04557577292723340862) ) ) {
            result[0] += 0.00041908592173399716;
          } else {
            result[0] += 0.0006473691116719633;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007249500000000001602) ) ) {
        result[0] += 0.00036845826383003594;
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
          result[0] += 0.00026774666225734756;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)33.50000000000000711) ) ) {
            result[0] += 0.00028638786375266806;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.07172822906307056712) ) ) {
              result[0] += 0.000486303368206697;
            } else {
              result[0] += 0.00027480243678644056;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04324794178047625809) ) ) {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.6250640499379888082) ) ) {
          result[0] += 0.00042119355790294405;
        } else {
          result[0] += 0.00042119355790294405;
        }
      } else {
        result[0] += 0.00042119355790294405;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9650000000000000799) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0006457017012494937;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7593447680904524821) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.32337995336020553) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.0005788998308156503;
              } else {
                result[0] += 3.2580303599048865e-05;
              }
            } else {
              result[0] += -0.0010107940090798163;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
              result[0] += -0.0006914324850139678;
            } else {
              result[0] += -0.0006914324850139678;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06439350000000000629) ) ) {
            result[0] += -0.0005869142254855806;
          } else {
            result[0] += 0.00031648912393915233;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6150000000000001021) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01205124510104085139) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4578754035427136104) ) ) {
            result[0] += 0.00014980433767630897;
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8324892801256282837) ) ) {
              result[0] += -0.0004043433852773231;
            } else {
              result[0] += -0.0009300775377967049;
            }
          }
        } else {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5458973873869347182) ) ) {
              result[0] += 0.000348728595882571;
            } else {
              result[0] += 0.0021040592998921737;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02182250000000000509) ) ) {
              result[0] += -0.0003281829787050933;
            } else {
              result[0] += 0.00027317154072870764;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01439950000000000084) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8950000000000001288) ) ) {
            result[0] += 0.00015692684388859645;
          } else {
            result[0] += 0.00025232206272330303;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02447420998234165271) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6285027855690678011) ) ) {
              result[0] += 0.00042285735408915015;
            } else {
              result[0] += -0.0009261295630606442;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.08693186820944626136) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
                result[0] += 0.0004814094295027055;
              } else {
                result[0] += 0.0007303244607998196;
              }
            } else {
              result[0] += 0.0004003188650535772;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007249500000000001602) ) ) {
        result[0] += 0.00035791643421072706;
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
          result[0] += 0.00026008625680106525;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)22.50000000000000355) ) ) {
            result[0] += 0.00024534470265680263;
          } else {
            result[0] += 0.00044969832844537496;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04324794178047625809) ) ) {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.6250640499379888082) ) ) {
          result[0] += 0.0004091429373577322;
        } else {
          result[0] += 0.0004091429373577322;
        }
      } else {
        result[0] += 0.0004091429373577322;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9650000000000000799) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0006272277572844044;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.0005623371316386263;
              } else {
                result[0] += 0.00016930813991367875;
              }
            } else {
              result[0] += -0.0006716501537004949;
            }
          } else {
            result[0] += -0.0006716501537004949;
          }
        } else {
          result[0] += -0.0005065864331170874;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6150000000000001021) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02180250462562445188) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.07500000000000002498) ) ) {
            result[0] += -0.0005867556960841915;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.323165429195979903) ) ) {
              result[0] += 0.0010207648356757256;
            } else {
              result[0] += -0.00023350570726183038;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.752860906001682428) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02182250000000000509) ) ) {
              result[0] += -9.2820717555276e-05;
            } else {
              result[0] += 0.0006714174378492238;
            }
          } else {
            result[0] += -0.001541543007816036;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01439950000000000084) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8650000000000001021) ) ) {
            result[0] += 0.00013738518537827934;
          } else {
            result[0] += 0.0002582299345335168;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02447420998234165271) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6285027855690678011) ) ) {
              result[0] += 0.00041075913125722456;
            } else {
              result[0] += -0.000899632396305026;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.08693186820944626136) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4213441621608040588) ) ) {
                  result[0] += -0.00023208763846695117;
                } else {
                  result[0] += 0.0007028684716805997;
                }
              } else {
                result[0] += 0.0007094294048644842;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1167934537543566104) ) ) {
                result[0] += 0.0002514979243725122;
              } else {
                result[0] += 0.0007032868236330252;
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1165587384072143268) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)64.50000000000001421) ) ) {
          result[0] += 0.00034767621316593564;
        } else {
          result[0] += 0.0004514766914231431;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1117617829768308563) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01504150000000000105) ) ) {
            result[0] += 0.00028708521852188003;
          } else {
            result[0] += 0.00012280099231518914;
          }
        } else {
          result[0] += 0.00043683216794925564;
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04324794178047625809) ) ) {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.6250640499379888082) ) ) {
          result[0] += 0.00039743709287283746;
        } else {
          result[0] += 0.00039743709287283746;
        }
      } else {
        result[0] += 0.00039743709287283746;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9650000000000000799) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0006092823648237712;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.0005462483020145473;
              } else {
                result[0] += 0.0001644641243511578;
              }
            } else {
              result[0] += -0.0006524338077011025;
            }
          } else {
            result[0] += -0.0006524338077011025;
          }
        } else {
          result[0] += -0.0004920926670935971;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6150000000000001021) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01205124510104085139) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.323165429195979903) ) ) {
            result[0] += 0.0009236207243203799;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1650000000000000355) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += 0.000792097328298219;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
                  result[0] += -0.0009293194255134597;
                } else {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
                    result[0] += -0.00046073734314176724;
                  } else {
                    result[0] += -0.001039394345908243;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.000726282482777400166) ) ) {
                result[0] += 0.0001685995987377841;
              } else {
                result[0] += -0.0004045809027710648;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)44.50000000000000711) ) ) {
            result[0] += -0.0002206094956221815;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
              result[0] += 0.0002993862351717817;
            } else {
              result[0] += -0.0012501480811779816;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2846413682100536469) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)61.50000000000000711) ) ) {
              result[0] += 0.0002867074606730938;
            } else {
              result[0] += 0.0006172403729822732;
            }
          } else {
            result[0] += 0.0001749107105112571;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04557577292723340862) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.564198853668341882) ) ) {
              result[0] += 0.000677720697606771;
            } else {
              result[0] += -0.00033114293436760334;
            }
          } else {
            result[0] += 0.0006089782110615047;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1165587384072143268) ) ) {
        result[0] += 0.00042083374760182264;
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1117617829768308563) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01504150000000000105) ) ) {
            result[0] += 0.00027887152444315175;
          } else {
            result[0] += 0.00011928757637327892;
          }
        } else {
          result[0] += 0.0004243341166397641;
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04324794178047625809) ) ) {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.6250640499379888082) ) ) {
          result[0] += 0.000386066160181823;
        } else {
          result[0] += 0.000386066160181823;
        }
      } else {
        result[0] += 0.000386066160181823;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9650000000000000799) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0005918504016666503;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.568345700351758909) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.03091333598004935429) ) ) {
                result[0] += -0.0007777643180512326;
              } else {
                result[0] += 0.0013195698291167104;
              }
            } else {
              result[0] += -0.0005968805856799006;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.0006337672538093035;
              } else {
                result[0] += -0.0001263477724981272;
              }
            } else {
              result[0] += -0.0006337672538093035;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06439350000000000629) ) ) {
            result[0] += -0.000541549373273407;
          } else {
            result[0] += 0.0003360070210901099;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7250000000000000888) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4550000000000000711) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.323165429195979903) ) ) {
            result[0] += 0.0009904331656894099;
          } else {
            result[0] += -0.0003526499392651148;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1737935000000000174) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3539353041941689093) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002478500000000000234) ) ) {
                result[0] += 1.040438462523142e-05;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)11.50000000000000178) ) ) {
                  result[0] += -0.0009860558428960462;
                } else {
                  result[0] += 0.0015842366262058761;
                }
              }
            } else {
              result[0] += -1.0586647608891687e-05;
            }
          } else {
            result[0] += 0.0010759853351565098;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02664459509800340062) ) ) {
            result[0] += 0.0004674707768384157;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
              result[0] += 0.0007971955620526489;
            } else {
              result[0] += 0.0006518438948684318;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07959200000000000996) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2118170036735003703) ) ) {
              result[0] += 0.0003333080080496907;
            } else {
              result[0] += 4.9991260984572654e-05;
            }
          } else {
            result[0] += 0.00044807308673770784;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1165587384072143268) ) ) {
        result[0] += 0.00040879342146241446;
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1117617829768308563) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01504150000000000105) ) ) {
            result[0] += 0.00027089282947293127;
          } else {
            result[0] += 0.00011587468153749585;
          }
        } else {
          result[0] += 0.00041219364267460417;
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04324794178047625809) ) ) {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.6250640499379888082) ) ) {
          result[0] += 0.00037502055724131055;
        } else {
          result[0] += 0.00037502055724131055;
        }
      } else {
        result[0] += 0.00037502055724131055;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9650000000000000799) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -0.0005749171782680635;
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
            result[0] += -0.0005487982806038022;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.0006156347621167384;
              } else {
                result[0] += -0.00012273288087754223;
              }
            } else {
              result[0] += -0.0006156347621167384;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06439350000000000629) ) ) {
            result[0] += -0.0005260552948826851;
          } else {
            result[0] += 0.00032639364254784573;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7550000000000001155) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4550000000000000711) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.323165429195979903) ) ) {
            result[0] += 0.000962096231206033;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += 0.0008169826308211317;
            } else {
              result[0] += -0.00037130179087646706;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1737935000000000174) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3539353041941689093) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.005491500000000000721) ) ) {
                result[0] += 0.00014176685546095393;
              } else {
                result[0] += 0.0013743565296446558;
              }
            } else {
              result[0] += 1.358535496197047e-06;
            }
          } else {
            result[0] += 0.0010428125052578592;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02664459509800340062) ) ) {
            result[0] += 0.0005000025473889971;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)25.50000000000000355) ) ) {
                result[0] += 0.0002807682681913325;
              } else {
                result[0] += 0.0008170122224793565;
              }
            } else {
              result[0] += 0.0006331942187649285;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07959200000000000996) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2185860198827210554) ) ) {
              result[0] += 0.00033807397698035977;
            } else {
              result[0] += 5.966491425822006e-05;
            }
          } else {
            result[0] += 0.00043947205847749715;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1165587384072143268) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)64.50000000000001421) ) ) {
          result[0] += 0.000313992800730841;
        } else {
          result[0] += 0.0004148234800620704;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1117617829768308563) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01504150000000000105) ) ) {
            result[0] += 0.0002631424101344925;
          } else {
            result[0] += 0.00011255943183387246;
          }
        } else {
          result[0] += 0.00040040051553431335;
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04324794178047625809) ) ) {
        if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.6250640499379888082) ) ) {
          result[0] += 0.00036429097615638383;
        } else {
          result[0] += 0.00036429097615638383;
        }
      } else {
        result[0] += 0.00036429097615638383;
      }
    }
  }
}

