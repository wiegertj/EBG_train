
#include "header.h"

void predict_unit6(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9650000000000000799) ) ) {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -0.0008289224564749177;
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
            result[0] += -0.0007463371320897799;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7601236426381910993) ) ) {
                result[0] += -0.0007469098904631102;
              } else {
                result[0] += -0.00089095548549024;
              }
            } else {
              result[0] += -0.0009722009033598626;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6047319804020101497) ) ) {
            result[0] += -0.00010650379532775501;
          } else {
            result[0] += -0.0007347176151199894;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7250000000000000888) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2250000000000000333) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.723113719091885043) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01691750000000000545) ) ) {
              result[0] += -0.0006283391780274916;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0149275149599735011) ) ) {
                result[0] += -0.0006041063356507643;
              } else {
                result[0] += 0.00036364351119916945;
              }
            }
          } else {
            result[0] += -0.001727357448904362;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03940025850376690369) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3750409390474713223) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001886500000000000373) ) ) {
                result[0] += -2.6962699002019742e-05;
              } else {
                result[0] += 0.001546583224126611;
              }
            } else {
              result[0] += -0.00010360446438847595;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005584000000000001289) ) ) {
              result[0] += -0.00021320307513712265;
            } else {
              result[0] += 0.0010019502622707227;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.07274795227358500649) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01910124190761275029) ) ) {
            result[0] += 0.000335009044924328;
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8950000000000001288) ) ) {
                result[0] += 0.0011486217440509555;
              } else {
                result[0] += 0.000884485807640649;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8950000000000001288) ) ) {
                result[0] += -1.7211474604481385e-05;
              } else {
                result[0] += 0.0005385873904126507;
              }
            }
          }
        } else {
          result[0] += 0.0002738581816120351;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08404042173159891049) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01332150000000000174) ) ) {
          result[0] += 0.00048225776064495803;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1250629713251516228) ) ) {
            result[0] += 0.000615564548433029;
          } else {
            result[0] += 0.0002735343929137581;
          }
        }
      } else {
        result[0] += 0.0005849496972764546;
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6269304705026225166) ) ) {
          result[0] += 0.0005523227791002954;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01798150000000000096) ) ) {
            result[0] += 0.0005523227791002954;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0173600348455768029) ) ) {
              result[0] += 0.0002866462238658366;
            } else {
              result[0] += 0.0005523227791002954;
            }
          }
        }
      } else {
        result[0] += 0.0005523227791002954;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9650000000000000799) ) ) {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -0.000799523786532515;
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
            result[0] += -0.0007198674438328412;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7601236426381910993) ) ) {
                result[0] += -0.0007204198886843906;
              } else {
                result[0] += -0.0008593567442006278;
              }
            } else {
              result[0] += -0.000937720701680772;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05574000000000000482) ) ) {
            result[0] += -0.0007086600261391852;
          } else {
            result[0] += 0.00030857066008189147;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7250000000000000888) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3150000000000000577) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1650000000000000355) ) ) {
                result[0] += -0.0011043429142729726;
              } else {
                result[0] += -0.00021745721458230218;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
                result[0] += 0.000382039056259761;
              } else {
                result[0] += -0.00034821042142392863;
              }
            }
          } else {
            result[0] += -0.0024808482489025005;
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05463331189772155372) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.009795390075261452625) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.000584175175977650024) ) ) {
                result[0] += 0.0011294840476779766;
              } else {
                result[0] += -0.0002878416717864312;
              }
            } else {
              result[0] += 0.0007932592320309468;
            }
          } else {
            result[0] += -9.869062203410117e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.07274795227358500649) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01910124190761275029) ) ) {
            result[0] += 0.00032312757125629225;
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8950000000000001288) ) ) {
                result[0] += 0.0011078845782542624;
              } else {
                result[0] += 0.0008531165207737606;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8950000000000001288) ) ) {
                result[0] += -1.6601050243112977e-05;
              } else {
                result[0] += 0.0005194857810857455;
              }
            }
          }
        } else {
          result[0] += 0.0002641454922894681;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0773654251422162681) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01332150000000000174) ) ) {
          result[0] += 0.0004706564219123169;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1250629713251516228) ) ) {
            result[0] += 0.0005937328573667916;
          } else {
            result[0] += 0.00022809230351657266;
          }
        }
      } else {
        result[0] += 0.0005642037964400019;
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6269304705026225166) ) ) {
          result[0] += 0.000532734028720081;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01798150000000000096) ) ) {
            result[0] += 0.000532734028720081;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0173600348455768029) ) ) {
              result[0] += 0.00027647999219984257;
            } else {
              result[0] += 0.000532734028720081;
            }
          }
        }
      } else {
        result[0] += 0.000532734028720081;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9650000000000000799) ) ) {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -0.0007711677735812834;
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.564706444988914313) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7601236426381910993) ) ) {
              result[0] += -0.0006555371982279728;
            } else {
              result[0] += -0.0008288786879141933;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
              result[0] += -0.0008288786879141933;
            } else {
              result[0] += -0.0009044633792478558;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6047319804020101497) ) ) {
            result[0] += -9.090228161361336e-05;
          } else {
            result[0] += -0.0006835265989445138;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7250000000000000888) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.2850000000000000866) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.723113719091885043) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += 0.0010249403711178973;
            } else {
              result[0] += -0.0004945559528993933;
            }
          } else {
            result[0] += -0.0015561828911029166;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02162700000000000386) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
              result[0] += 0.0007209788563123503;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004718492901569751492) ) ) {
                result[0] += -0.0005718023025501173;
              } else {
                result[0] += -1.2776308193440961e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02661305910200095423) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2795185878002977575) ) ) {
                result[0] += 0.0025030845127947767;
              } else {
                result[0] += -0.0005569798271399745;
              }
            } else {
              result[0] += 0.0011291274071540225;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.07274795227358500649) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01910124190761275029) ) ) {
            result[0] += 0.00031166748745418136;
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8950000000000001288) ) ) {
                result[0] += 0.0010685922019940215;
              } else {
                result[0] += 0.000822859781050123;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8950000000000001288) ) ) {
                result[0] += -1.6012275270275312e-05;
              } else {
                result[0] += 0.0005010616318802123;
              }
            }
          }
        } else {
          result[0] += 0.0002547772744496286;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08404042173159891049) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01332150000000000174) ) ) {
          result[0] += 0.00044846158427452876;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1250629713251516228) ) ) {
            result[0] += 0.000572675451850341;
          } else {
            result[0] += 0.0002438230630606723;
          }
        }
      } else {
        result[0] += 0.0005441936723780648;
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6269304705026225166) ) ) {
          result[0] += 0.0005138400154681875;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01798150000000000096) ) ) {
            result[0] += 0.0005138400154681875;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0173600348455768029) ) ) {
              result[0] += 0.00026667431740738206;
            } else {
              result[0] += 0.0005138400154681875;
            }
          }
        }
      } else {
        result[0] += 0.0005138400154681875;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9650000000000000799) ) ) {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -0.0007438174386149152;
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.564706444988914313) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7601236426381910993) ) ) {
              result[0] += -0.0006322878320476577;
            } else {
              result[0] += -0.0007994815702731676;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009505000000000001295) ) ) {
              result[0] += -0.0007994815702731676;
            } else {
              result[0] += -0.0010820584713060544;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05574000000000000482) ) ) {
            result[0] += -0.0006592845570957767;
          } else {
            result[0] += 0.00032180086788769483;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7150000000000000799) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.2250000000000000333) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.723113719091885043) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01359050000000000188) ) ) {
              result[0] += -0.0005910069183275333;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0149275149599735011) ) ) {
                result[0] += -0.0005494573096037661;
              } else {
                result[0] += 0.0003647361135935039;
              }
            }
          } else {
            result[0] += -0.0015984149248364993;
          }
        } else {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3539353041941689093) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001886500000000000373) ) ) {
              result[0] += -9.053510736825453e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4592177672613065309) ) ) {
                result[0] += 0.0009044057852980312;
              } else {
                result[0] += 0.003799995854916266;
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03940025850376690369) ) ) {
              result[0] += -0.00010973057525420685;
            } else {
              result[0] += 0.0004937322026364243;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03160800000000000415) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2177889902755587859) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008332142139858200389) ) ) {
              result[0] += 0.00020482542826643897;
            } else {
              result[0] += 0.0006740208592050589;
            }
          } else {
            result[0] += 0.0002168353489933474;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03409611752714010457) ) ) {
            result[0] += 0.00027879826831257634;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1529448915625084837) ) ) {
              result[0] += 0.0008071898336036849;
            } else {
              result[0] += 0.00049605209362266;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08404042173159891049) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01332150000000000174) ) ) {
          result[0] += 0.0004325563883241145;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1250629713251516228) ) ) {
            result[0] += 0.000552364870973257;
          } else {
            result[0] += 0.00023517560309710685;
          }
        }
      } else {
        result[0] += 0.0005248932299373799;
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6269304705026225166) ) ) {
          result[0] += 0.0004956160997086982;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01798150000000000096) ) ) {
            result[0] += 0.0004956160997086982;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0173600348455768029) ) ) {
              result[0] += 0.0002572164119322258;
            } else {
              result[0] += 0.0004956160997086982;
            }
          }
        }
      } else {
        result[0] += 0.0004956160997086982;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9650000000000000799) ) ) {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -0.0007174371141292738;
      } else {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.564706444988914313) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7601236426381910993) ) ) {
              result[0] += -0.0006098630308641841;
            } else {
              result[0] += -0.0007711270545691937;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009505000000000001295) ) ) {
              result[0] += -0.0007711270545691937;
            } else {
              result[0] += -0.0010436820470605495;
            }
          }
        } else {
          result[0] += -0.0005208964921551573;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7150000000000000799) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3350000000000000755) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8158067323869347964) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7760221401809592745) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1413595000000000268) ) ) {
                  result[0] += -0.0002830997997417356;
                } else {
                  result[0] += 0.0023516930071961774;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9112103514676580529) ) ) {
                  result[0] += -0.0015371411780857242;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7412676365326634764) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.145614105386054682) ) ) {
                      result[0] += 0.0018553206213917466;
                    } else {
                      result[0] += -0.004094099369923273;
                    }
                  } else {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.314196657149456993) ) ) {
                      result[0] += -0.0011480128695709711;
                    } else {
                      result[0] += 0.000987977329179784;
                    }
                  }
                }
              }
            } else {
              result[0] += 0.000757609045493125;
            }
          } else {
            result[0] += -0.0009967391257450758;
          }
        } else {
          result[0] += 0.0001381022123361422;
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03160800000000000415) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2177889902755587859) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008332142139858200389) ) ) {
              result[0] += 0.00019756106341013832;
            } else {
              result[0] += 0.0006501159491386432;
            }
          } else {
            result[0] += 0.00020914503875129066;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0229305563329877532) ) ) {
            result[0] += -0.0001422041271671569;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1529448915625084837) ) ) {
              result[0] += 0.0007825628732506848;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05585367585607920599) ) ) {
                result[0] += -9.027079939504795e-05;
              } else {
                result[0] += 0.0006372543783403269;
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08404042173159891049) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
          result[0] += 0.0005052992817366486;
        } else {
          result[0] += 0.0002435045056347103;
        }
      } else {
        result[0] += 0.0005062772994587259;
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6269304705026225166) ) ) {
          result[0] += 0.00047803851567817255;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01798150000000000096) ) ) {
            result[0] += 0.00047803851567817255;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0173600348455768029) ) ) {
              result[0] += 0.0002480939417432509;
            } else {
              result[0] += 0.00047803851567817255;
            }
          }
        }
      } else {
        result[0] += 0.00047803851567817255;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9650000000000000799) ) ) {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -0.0006919923976084895;
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.564706444988914313) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7584510713567840234) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02120250000000000259) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.966590843157139501) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6802634857286432579) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6055650374709939943) ) ) {
                    result[0] += -0.0007368926617659988;
                  } else {
                    result[0] += 0.0017349368632600367;
                  }
                } else {
                  result[0] += -0.0007770552505450843;
                }
              } else {
                result[0] += 0.0003988254608588096;
              }
            } else {
              result[0] += 0.000266791935429539;
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += -0.0007437781637485203;
            } else {
              result[0] += -0.0005840819285372662;
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -0.0007437781637485203;
          } else {
            result[0] += -0.0008570835164899603;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7150000000000000799) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.3150000000000000577) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
            result[0] += -0.00040936622683414477;
          } else {
            result[0] += -0.0022456303200215286;
          }
        } else {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3539353041941689093) ) ) {
            result[0] += 0.0007105474163376287;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.000210500000000000048) ) ) {
              result[0] += 0.0008138970356840598;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01376440091032050082) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
                  result[0] += -0.0005001664012342613;
                } else {
                  result[0] += 0.0005968229744994034;
                }
              } else {
                result[0] += 0.00016902389103000629;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03160800000000000415) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8950000000000001288) ) ) {
            result[0] += 0.0002541070435910427;
          } else {
            if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.01778816268138619719) ) ) {
              result[0] += 0.0004857632780337415;
            } else {
              result[0] += 0.0002017274740366291;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03409611752714010457) ) ) {
            result[0] += 0.0002614775133634577;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1529448915625084837) ) ) {
              result[0] += 0.0007508074606159773;
            } else {
              result[0] += 0.0004628731269458338;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08404042173159891049) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
          result[0] += 0.000487378272732885;
        } else {
          result[0] += 0.00023486834366959013;
        }
      } else {
        result[0] += 0.0004883216039532456;
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6269304705026225166) ) ) {
          result[0] += 0.0004610843404927833;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01798150000000000096) ) ) {
            result[0] += 0.0004610843404927833;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0173600348455768029) ) ) {
              result[0] += 0.00023929501024966114;
            } else {
              result[0] += 0.0004610843404927833;
            }
          }
        }
      } else {
        result[0] += 0.0004610843404927833;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9650000000000000799) ) ) {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -0.000667450106660724;
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.564706444988914313) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7584510713567840234) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01905700000000000102) ) ) {
              result[0] += -0.0006000065960433451;
            } else {
              result[0] += 0.00025698404560660517;
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += -0.0007173992321903176;
            } else {
              result[0] += -0.0005633668040979893;
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -0.0007173992321903176;
          } else {
            result[0] += -0.0008266860827884829;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.795000000000000151) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3350000000000000755) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8158067323869347964) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7760221401809592745) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1413595000000000268) ) ) {
                  result[0] += -0.00026545388091808253;
                } else {
                  result[0] += 0.0022725495680116998;
                }
              } else {
                result[0] += -0.0008970310876006123;
              }
            } else {
              result[0] += 0.0007422135041378751;
            }
          } else {
            result[0] += -0.0009448010867586605;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005372500000000001406) ) ) {
            result[0] += -2.6267905870312784e-05;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7003595884880823297) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.168924500000000033) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3539353041941689093) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4575776583165829803) ) ) {
                    result[0] += 0.0011334268991475193;
                  } else {
                    result[0] += 0.0038059746035973476;
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6055650374709939943) ) ) {
                    result[0] += 0.0002654643123702122;
                  } else {
                    result[0] += 0.002502764680490616;
                  }
                }
              } else {
                result[0] += 0.0014629753890999272;
              }
            } else {
              result[0] += -0.00035960622511132183;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9050000000000001377) ) ) {
            result[0] += 0.0008468228151103996;
          } else {
            result[0] += 0.0007142620724928916;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05311250000000000693) ) ) {
            result[0] += 0.00019980867573565953;
          } else {
            result[0] += 0.0005248812336335755;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08404042173159891049) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
          result[0] += 0.00047009285252831446;
        } else {
          result[0] += 0.0002265384729301429;
        }
      } else {
        result[0] += 0.00047100272744286857;
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6269304705026225166) ) ) {
          result[0] += 0.00044473146425463443;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01798150000000000096) ) ) {
            result[0] += 0.00044473146425463443;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0173600348455768029) ) ) {
              result[0] += 0.00023080814278667717;
            } else {
              result[0] += 0.00044473146425463443;
            }
          }
        }
      } else {
        result[0] += 0.00044473146425463443;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9650000000000000799) ) ) {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -0.0006437782357450952;
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7478339930150754711) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.0005867123653490819;
              } else {
                result[0] += 0.00016850376589174135;
              }
            } else {
              result[0] += -0.0006919558591952292;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05574000000000000482) ) ) {
              result[0] += -0.0005376029715458705;
            } else {
              result[0] += 0.0004067629922747918;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009505000000000001295) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.0006919558591952292;
              } else {
                result[0] += -0.0005268953329561323;
              }
            } else {
              result[0] += -0.0006919558591952292;
            }
          } else {
            result[0] += -0.00095484438143618;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.7150000000000000799) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3350000000000000755) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.723113719091885043) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.09856950000000001821) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4389499174623116007) ) ) {
                result[0] += 0.00040357064833878187;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  result[0] += 0.0010026973328450476;
                } else {
                  result[0] += -0.00045965194501495837;
                }
              }
            } else {
              result[0] += 0.0006729709790131462;
            }
          } else {
            result[0] += -0.001354190860277272;
          }
        } else {
          result[0] += 0.0001254903521222525;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05378344711570890585) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2177889902755587859) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008332142139858200389) ) ) {
              result[0] += 0.00017938309619843615;
            } else {
              result[0] += 0.0006949799348869278;
            }
          } else {
            result[0] += 0.00017713079490910038;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0480970000000000078) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9750000000000000888) ) ) {
              result[0] += 0.0009329130615122951;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8950000000000001288) ) ) {
                result[0] += -0.0001183197210936874;
              } else {
                result[0] += 0.0002797609703549528;
              }
            }
          } else {
            result[0] += 0.0006671252084909733;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08404042173159891049) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
          result[0] += 0.00045342047924923395;
        } else {
          result[0] += 0.00021850403045255243;
        }
      } else {
        result[0] += 0.0004542980844236067;
      }
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6269304705026225166) ) ) {
          result[0] += 0.0004289585612182955;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01798150000000000096) ) ) {
            result[0] += 0.0004289585612182955;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0173600348455768029) ) ) {
              result[0] += 0.00022262227165144535;
            } else {
              result[0] += 0.0004289585612182955;
            }
          }
        }
      } else {
        result[0] += 0.0004289585612182955;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -0.0006209459144333307;
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7478339930150754711) ) ) {
              result[0] += -0.0005158868689868334;
            } else {
              result[0] += -0.0006674148641235052;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05574000000000000482) ) ) {
              result[0] += -0.0005185362757445001;
            } else {
              result[0] += 0.0003923366839256071;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009505000000000001295) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              result[0] += -0.0006674148641235052;
            } else {
              result[0] += -0.0006674148641235052;
            }
          } else {
            result[0] += -0.0009209797483852484;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8250000000000000666) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3350000000000000755) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8158067323869347964) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7760221401809592745) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003504500000000000236) ) ) {
                  result[0] += -0.00046219543369652427;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7292744312814071206) ) ) {
                    result[0] += 2.8416333539338578e-05;
                  } else {
                    result[0] += 0.0033205842291534624;
                  }
                }
              } else {
                result[0] += -0.0008577047241033175;
              }
            } else {
              result[0] += 0.0007234360005697696;
            }
          } else {
            result[0] += -0.0008703963687758466;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005372500000000001406) ) ) {
            result[0] += -2.432096205908213e-05;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7003595884880823297) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.168924500000000033) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3539353041941689093) ) ) {
                  result[0] += 0.0015532856272644946;
                } else {
                  result[0] += 0.00040229070115330856;
                }
              } else {
                result[0] += 0.001360241436845798;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05585367585607920599) ) ) {
                result[0] += -0.0005888884366715587;
              } else {
                result[0] += 0.000809075193699421;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05378344711570890585) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2795185878002977575) ) ) {
            result[0] += 0.0005478589814005637;
          } else {
            result[0] += 0.0002279608653809045;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
            result[0] += 0.000668590678706974;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8950000000000001288) ) ) {
              result[0] += 6.487508286606508e-05;
            } else {
              result[0] += 0.00037718636957077595;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
      result[0] += 0.0004381858904118367;
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6269304705026225166) ) ) {
          result[0] += 0.0004137450619799556;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01798150000000000096) ) ) {
            result[0] += 0.0004137450619799556;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0173600348455768029) ) ) {
              result[0] += 0.00021472672166967458;
            } else {
              result[0] += 0.0004137450619799556;
            }
          }
        }
      } else {
        result[0] += 0.0004137450619799556;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -0.0005989233671517185;
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7584510713567840234) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02366047096071570086) ) ) {
              result[0] += -0.0005062503637864101;
            } else {
              result[0] += 0.00048550819179373286;
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += -0.0006437442431242126;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                result[0] += -0.0012485979157097018;
              } else {
                result[0] += -0.0003091368965293277;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009505000000000001295) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.0006437442431242126;
              } else {
                result[0] += -0.0004845377746362575;
              }
            } else {
              result[0] += -0.0006437442431242126;
            }
          } else {
            result[0] += -0.0008883161627447327;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8250000000000000666) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3350000000000000755) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.723113719091885043) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.09856950000000001821) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += 0.0010342008198985693;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4389499174623116007) ) ) {
                  result[0] += 0.0003934084890112835;
                } else {
                  result[0] += -0.00042837405079673707;
                }
              }
            } else {
              result[0] += 0.000659540030395639;
            }
          } else {
            result[0] += -0.0012752933648672224;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01332150000000000174) ) ) {
            result[0] += 2.7610843688051827e-05;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7425707671105529206) ) ) {
              result[0] += 0.0007985147634152503;
            } else {
              result[0] += -0.0004596654144126512;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05378344711570890585) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2795185878002977575) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01351316588546045208) ) ) {
              result[0] += 0.00032850076258159684;
            } else {
              result[0] += 0.0006278700869633749;
            }
          } else {
            result[0] += 0.0002198759761505926;
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
            result[0] += 0.0006448783561171621;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8950000000000001288) ) ) {
              result[0] += 6.257421487320763e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7322719660050253099) ) ) {
                result[0] += 0.0004463570249166764;
              } else {
                result[0] += 7.358942099342515e-07;
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
      result[0] += 0.00042264513353522913;
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6269304705026225166) ) ) {
          result[0] += 0.0003990711266529097;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01798150000000000096) ) ) {
            result[0] += 0.0003990711266529097;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0173600348455768029) ) ) {
              result[0] += 0.00020711119627417972;
            } else {
              result[0] += 0.0003990711266529097;
            }
          }
        }
      } else {
        result[0] += 0.0003990711266529097;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -0.0005776818743508552;
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7584510713567840234) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0270604707267506038) ) ) {
              result[0] += -0.0004835125504781081;
            } else {
              result[0] += 0.0006518819691549102;
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += -0.0006209131273990913;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                result[0] += -0.0012043149822121315;
              } else {
                result[0] += -0.00029817300778787304;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009505000000000001295) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.0006209131273990913;
              } else {
                result[0] += -0.00046735309590076394;
              }
            } else {
              result[0] += -0.0006209131273990913;
            }
          } else {
            result[0] += -0.0008568110280134427;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.795000000000000151) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5350000000000001421) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.003572500000000000588) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.09500000000000001499) ) ) {
                result[0] += -0.0007504064305671016;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001074448343160400252) ) ) {
                  result[0] += -3.648945189760324e-05;
                } else {
                  result[0] += -0.0006404518085399583;
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007787546829340650199) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8030059940338053481) ) ) {
                  result[0] += -0.00028198705784187835;
                } else {
                  result[0] += -0.0013142847728441214;
                }
              } else {
                result[0] += 0.00010416766929206234;
              }
            }
          } else {
            result[0] += -0.0020075762919942956;
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02162700000000000386) ) ) {
              result[0] += 9.533621484499875e-05;
            } else {
              result[0] += 0.0008047739083716627;
            }
          } else {
            result[0] += -0.00037554992256642883;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05701962466675345592) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1494199460089949139) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01278116174711865262) ) ) {
              result[0] += 0.00024859632722009777;
            } else {
              result[0] += 0.0005628972868287573;
            }
          } else {
            result[0] += 0.00019283204298410742;
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.06355808660527756393) ) ) {
            result[0] += 0.0005112229874658185;
          } else {
            result[0] += 0.000347978474129335;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
      result[0] += 0.0004076555471312088;
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6269304705026225166) ) ) {
          result[0] += 0.00038491761899441917;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01798150000000000096) ) ) {
            result[0] += 0.00038491761899441917;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0173600348455768029) ) ) {
              result[0] += 0.0001997657640771404;
            } else {
              result[0] += 0.00038491761899441917;
            }
          }
        }
      } else {
        result[0] += 0.00038491761899441917;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -0.0005571937350525526;
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.564706444988914313) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7584510713567840234) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02366047096071570086) ) ) {
              result[0] += -0.0004707814346795214;
            } else {
              result[0] += 0.00044879650251386223;
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.0005988917429466322;
              } else {
                result[0] += -0.00013867254466318462;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.746990491767992958e-06) ) ) {
                result[0] += -0.0011616025929021474;
              } else {
                result[0] += -0.0002991602058522823;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009505000000000001295) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.906142995150753916) ) ) {
                result[0] += -0.0005988917429466322;
              } else {
                result[0] += -0.0005647581048899959;
              }
            } else {
              result[0] += -0.0004987152162824679;
            }
          } else {
            result[0] += -0.0008264232584231515;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.795000000000000151) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.3850000000000000644) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5072261056783921029) ) ) {
            result[0] += 0.00014504113634910396;
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1044543990012605922) ) ) {
              result[0] += -0.0017888124460500336;
            } else {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.05751864358971629093) ) ) {
                result[0] += 0.0010409010829981137;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                  result[0] += -0.0003840973758782529;
                } else {
                  result[0] += -0.0018647010327958484;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1773295000000000288) ) ) {
            result[0] += 0.00012025551014708298;
          } else {
            result[0] += 0.0009478706494779137;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0526089167981486569) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1523979577405769892) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01351316588546045208) ) ) {
              result[0] += 0.00020904895116148137;
            } else {
              result[0] += 0.0004479080914366114;
            }
          } else {
            result[0] += 3.778586637369588e-05;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7003595884880823297) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8950000000000001288) ) ) {
                result[0] += 0.0007466541448748918;
              } else {
                result[0] += 0.0005873191666040768;
              }
            } else {
              result[0] += 0.00032726098330724596;
            }
          } else {
            result[0] += 0.00015287051897265962;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
      result[0] += 0.00039319758331724154;
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6269304705026225166) ) ) {
          result[0] += 0.0003712660814501782;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01798150000000000096) ) ) {
            result[0] += 0.0003712660814501782;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0173600348455768029) ) ) {
              result[0] += 0.0001926808459186079;
            } else {
              result[0] += 0.0003712660814501782;
            }
          }
        }
      } else {
        result[0] += 0.0003712660814501782;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -0.0005374322307250604;
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.564706444988914313) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7584510713567840234) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5814822343216081713) ) ) {
              result[0] += -4.320746211136065e-05;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4725173572200235816) ) ) {
                result[0] += -0.0010180878282922531;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6858832018090453841) ) ) {
                  result[0] += 0.0006486679864632141;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8932219825431284566) ) ) {
                    result[0] += -0.0006179807800188744;
                  } else {
                    result[0] += 5.021600964003602e-05;
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.0005776513717338744;
              } else {
                result[0] += -0.00013375436644424366;
              }
            } else {
              result[0] += -0.0004422475392763362;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009505000000000001295) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += -0.0005776513717338744;
            } else {
              result[0] += -0.00048102771858685454;
            }
          } else {
            result[0] += -0.0007971132253587471;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.795000000000000151) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4550000000000000711) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3278371989949749321) ) ) {
              result[0] += 0.0014369671440260976;
            } else {
              result[0] += -0.0003218912535190604;
            }
          } else {
            result[0] += -0.001860244978670122;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005372500000000001406) ) ) {
            result[0] += -5.166465708700919e-05;
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3539353041941689093) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4575776583165829803) ) ) {
                result[0] += 0.0009893438300668978;
              } else {
                result[0] += 0.0036964694644817902;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07954367714673930834) ) ) {
                result[0] += 7.981339726264841e-05;
              } else {
                result[0] += 0.0012982818734787694;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0526089167981486569) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.04446937286580055632) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01910124190761275029) ) ) {
              result[0] += 0.0002730754446138312;
            } else {
              result[0] += 0.0004924720690778648;
            }
          } else {
            result[0] += 5.5409740362938814e-05;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03389850000000000502) ) ) {
            result[0] += 0.00027349404196102314;
          } else {
            result[0] += 0.0004957636695051249;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
      result[0] += 0.0003792523874985013;
    } else {
      if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6269304705026225166) ) ) {
          result[0] += 0.0003580987110838593;
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01798150000000000096) ) ) {
            result[0] += 0.0003580987110838593;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0173600348455768029) ) ) {
              result[0] += 0.00018584720237434512;
            } else {
              result[0] += 0.0003580987110838593;
            }
          }
        }
      } else {
        result[0] += 0.0003580987110838593;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9750000000000000888) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.0005183715904394954;
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7789937396482412568) ) ) {
              result[0] += -0.000535521520220978;
            } else {
              result[0] += -0.0005571643142452898;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02528885254406800301) ) ) {
              result[0] += -0.00044684618670365697;
            } else {
              result[0] += 0.0017021932518433269;
            }
          }
        } else {
          result[0] += -0.0005591697996418408;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.795000000000000151) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1450000000000000455) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              result[0] += -0.000738879845356024;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.07500000000000002498) ) ) {
                    result[0] += 0.00018814926924396296;
                  } else {
                    result[0] += 0.0020792890021184007;
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1750000000000000167) ) ) {
                    result[0] += -0.00048783241831625647;
                  } else {
                    result[0] += 0.0008971404754228341;
                  }
                }
              } else {
                result[0] += -0.0016793513971775744;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1773295000000000288) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
                result[0] += 0.0022532851366380714;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0119121105025029022) ) ) {
                  result[0] += -0.00015326867926490411;
                } else {
                  result[0] += 0.00011924127909690241;
                }
              }
            } else {
              result[0] += 0.0010983207401017298;
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9050000000000001377) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.01537695356895864805) ) ) {
                result[0] += 0.0008312385414110682;
              } else {
                result[0] += 0.00044891578112360393;
              }
            } else {
              result[0] += 0.0005740344366086598;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08720350000000000323) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9050000000000001377) ) ) {
                result[0] += -5.073946728851754e-07;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08693186820944626136) ) ) {
                  result[0] += 0.0003347237403907344;
                } else {
                  result[0] += 4.8071171491027285e-05;
                }
              }
            } else {
              result[0] += 0.0004687224615155644;
            }
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06364359169843836206) ) ) {
      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 0.0003453983363603619;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02979533478473985267) ) ) {
            result[0] += 0.0003453983363603619;
          } else {
            result[0] += 0.0003453983363603619;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01210357511382575101) ) ) {
          result[0] += 8.290207024050845e-05;
        } else {
          result[0] += 0.0003453983363603619;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08407783631914581002) ) ) {
          result[0] += 0.0003453983363603619;
        } else {
          result[0] += 0.0003453983363603619;
        }
      } else {
        result[0] += 0.0003453983363603619;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9750000000000000888) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.0004999869572620369;
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7789937396482412568) ) ) {
              result[0] += -0.0005165286454387194;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02483316262871755262) ) ) {
                result[0] += -0.0005374038533599138;
              } else {
                result[0] += -4.7661934334059174e-05;
              }
            }
          } else {
            result[0] += -0.000343296082263788;
          }
        } else {
          result[0] += -0.000539338211954691;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.795000000000000151) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1450000000000000455) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
              result[0] += -0.0007126746381849083;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
                  result[0] += 0.00033412439725679814;
                } else {
                  result[0] += -0.0003614513798057205;
                }
              } else {
                result[0] += -0.0016197913055703442;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1773295000000000288) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05463331189772155372) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.000584175175977650024) ) ) {
                    result[0] += 0.000536708343918778;
                  } else {
                    result[0] += -0.00029392207542886347;
                  }
                } else {
                  result[0] += 0.0005746642983653072;
                }
              } else {
                result[0] += -0.00014297560680031002;
              }
            } else {
              result[0] += 0.0010593675561495661;
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9850000000000000977) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9050000000000001377) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6915080527790725684) ) ) {
                result[0] += 0.0007432186006220992;
              } else {
                result[0] += -0.00029487473357876434;
              }
            } else {
              result[0] += 0.00055367565780419;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.08720350000000000323) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8950000000000001288) ) ) {
                result[0] += -2.1123276733889867e-05;
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2795185878002977575) ) ) {
                  result[0] += 0.00042692709061738226;
                } else {
                  result[0] += 0.00016164892532997944;
                }
              }
            } else {
              result[0] += 0.00045209869069955143;
            }
          }
        }
      }
    }
  } else {
    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06364359169843836206) ) ) {
      if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 0.00033314839475243887;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02979533478473985267) ) ) {
            result[0] += 0.00033314839475243887;
          } else {
            result[0] += 0.00033314839475243887;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01210357511382575101) ) ) {
          result[0] += 7.99618548059939e-05;
        } else {
          result[0] += 0.00033314839475243887;
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
        result[0] += 0.0003535518321717144;
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.08693186820944626136) ) ) {
            result[0] += 0.00033314839475243887;
          } else {
            result[0] += 0.00033314839475243887;
          }
        } else {
          result[0] += 0.00033314839475243887;
        }
      }
    }
  }
}

