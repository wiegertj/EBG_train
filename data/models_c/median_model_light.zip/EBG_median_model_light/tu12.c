
#include "header.h"

void predict_unit12(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -4.7362259348383804e-05;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.242456489623170593e-05) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)46.50000000000000711) ) ) {
              result[0] += -5.897704957967585e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)461.5000000000000568) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
                    result[0] += -6.70540098267475e-05;
                  } else {
                    result[0] += 6.680349153215961e-05;
                  }
                } else {
                  result[0] += -6.70540098267475e-05;
                }
              } else {
                result[0] += -5.041093575854996e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4213441621608040588) ) ) {
              result[0] += 0.0007446500373094629;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4543227793467337072) ) ) {
                result[0] += -0.001058545811511932;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.828053558455352334) ) ) {
                  result[0] += -9.036049465575683e-06;
                } else {
                  result[0] += -0.0007149516101548449;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.163639685692610809) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2575587311557789305) ) ) {
              result[0] += 0.00030527962894730113;
            } else {
              result[0] += 1.9005814571531444e-05;
            }
          } else {
            result[0] += 9.015926618209202e-05;
          }
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
          result[0] += -5.071613335166839e-05;
        } else {
          result[0] += -7.259273969860708e-05;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 3.0010659523117894e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 3.0010659523117894e-05;
            } else {
              result[0] += 3.0010659523117894e-05;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 3.0010659523117894e-05;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 3.0010659523117894e-05;
              } else {
                result[0] += 3.0010659523117894e-05;
              }
            }
          }
        } else {
          result[0] += -1.0057954470185185e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 3.0010659523117894e-05;
            } else {
              result[0] += 3.0010659523117894e-05;
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.6250640499379888082) ) ) {
              result[0] += 3.0010659523117894e-05;
            } else {
              result[0] += 3.0010659523117894e-05;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 3.0010659523117894e-05;
          } else {
            result[0] += 3.0010659523117894e-05;
          }
        }
      } else {
        result[0] += 3.0010659523117894e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -4.600719442665769e-05;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.242456489623170593e-05) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)46.50000000000000711) ) ) {
              result[0] += -5.728967798524941e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
                result[0] += -6.513555116731268e-05;
              } else {
                result[0] += -4.89686462297644e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4213441621608040588) ) ) {
              result[0] += 0.000723345117349927;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4543227793467337072) ) ) {
                result[0] += -0.0010282601301074851;
              } else {
                result[0] += -2.2505635068736198e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.163639685692610809) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
              result[0] += 0.0002959878141599608;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.007016451597998800589) ) ) {
                result[0] += -0.0001753803652333766;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)14.50000000000000178) ) ) {
                  result[0] += -0.00011777541251811528;
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3296315496301309156) ) ) {
                    result[0] += 9.591172503660001e-05;
                  } else {
                    result[0] += 2.7769759828277e-05;
                  }
                }
              }
            }
          } else {
            result[0] += 8.757975117050423e-05;
          }
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
          result[0] += -4.926511192203351e-05;
        } else {
          result[0] += -7.051581438949098e-05;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 2.9152035112940894e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 2.9152035112940894e-05;
            } else {
              result[0] += 2.9152035112940894e-05;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 2.9152035112940894e-05;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 2.9152035112940894e-05;
              } else {
                result[0] += 2.9152035112940894e-05;
              }
            }
          }
        } else {
          result[0] += -9.770189877138555e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 2.9152035112940894e-05;
            } else {
              result[0] += 2.9152035112940894e-05;
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.6250640499379888082) ) ) {
              result[0] += 2.9152035112940894e-05;
            } else {
              result[0] += 2.9152035112940894e-05;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 2.9152035112940894e-05;
          } else {
            result[0] += 2.9152035112940894e-05;
          }
        }
      } else {
        result[0] += 2.9152035112940894e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -4.4690898790167435e-05;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.242456489623170593e-05) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)46.50000000000000711) ) ) {
              result[0] += -5.5650583185236536e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)461.5000000000000568) ) ) {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
                    result[0] += -6.327198085292197e-05;
                  } else {
                    result[0] += 6.675577067781198e-05;
                  }
                } else {
                  result[0] += -6.327198085292197e-05;
                }
              } else {
                result[0] += -4.7567621538727685e-05;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.828053558455352334) ) ) {
              result[0] += -2.740087460255494e-06;
            } else {
              result[0] += -0.0006938524806364522;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.163639685692610809) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
              result[0] += 0.0002875194110528308;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.007016451597998800589) ) ) {
                result[0] += -0.00017036261937080705;
              } else {
                result[0] += 3.01332222278552e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9250000000000001554) ) ) {
              result[0] += 0.0009529925865415592;
            } else {
              result[0] += 3.8941140841203336e-05;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
          result[0] += -4.7855605155487395e-05;
        } else {
          result[0] += -6.849831125892271e-05;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 2.8317976503366717e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 2.8317976503366717e-05;
            } else {
              result[0] += 2.8317976503366717e-05;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 2.8317976503366717e-05;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 2.8317976503366717e-05;
              } else {
                result[0] += 2.8317976503366717e-05;
              }
            }
          }
        } else {
          result[0] += -9.49065841552217e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 2.8317976503366717e-05;
            } else {
              result[0] += 2.8317976503366717e-05;
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.6250640499379888082) ) ) {
              result[0] += 2.8317976503366717e-05;
            } else {
              result[0] += 2.8317976503366717e-05;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 2.8317976503366717e-05;
          } else {
            result[0] += 2.8317976503366717e-05;
          }
        }
      } else {
        result[0] += 2.8317976503366717e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -4.34122632245473e-05;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2750000000000000777) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.676837902221867901e-06) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6010141514957837439) ) ) {
                result[0] += -0.0003012249007819762;
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6731103726130654996) ) ) {
                  result[0] += 0.0013356370684887932;
                } else {
                  result[0] += 2.5948102000214132e-05;
                }
              }
            } else {
              result[0] += -4.62074044225548e-05;
            }
          } else {
            result[0] += -3.115686600340071e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.650000000000000541e-05) ) ) {
            result[0] += 0.0005374284183090792;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001999500000000000409) ) ) {
              result[0] += -0.0001320951417536601;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)25.50000000000000355) ) ) {
                result[0] += -7.480745364580896e-05;
              } else {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3539353041941689093) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
                    result[0] += 0.00018103762123834302;
                  } else {
                    result[0] += -2.7755546716102668e-05;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.008408953333664601418) ) ) {
                    if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05227730674148379358) ) ) {
                      result[0] += -0.0006197087072167012;
                    } else {
                      result[0] += -2.8609483150467056e-05;
                    }
                  } else {
                    result[0] += 4.705783548507624e-05;
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
          result[0] += -4.648642529062544e-05;
        } else {
          result[0] += -6.653853019987972e-05;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 2.750778085092258e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 2.750778085092258e-05;
            } else {
              result[0] += 2.750778085092258e-05;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 2.750778085092258e-05;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 2.750778085092258e-05;
              } else {
                result[0] += 2.750778085092258e-05;
              }
            }
          }
        } else {
          result[0] += -9.219124530097316e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 2.750778085092258e-05;
            } else {
              result[0] += 2.750778085092258e-05;
            }
          } else {
            result[0] += 2.750778085092258e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 2.750778085092258e-05;
          } else {
            result[0] += 2.750778085092258e-05;
          }
        }
      } else {
        result[0] += 2.750778085092258e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += 1.1269914765607565e-06;
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4892818374874372545) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4795364038944723295) ) ) {
            result[0] += 4.6763608547477864e-05;
          } else {
            result[0] += -0.0004744601495830773;
          }
        } else {
          result[0] += 0.0003202968880173029;
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5510720942211057016) ) ) {
          result[0] += -2.626722312706645e-05;
        } else {
          result[0] += -4.217021025077309e-05;
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5085295226130653878) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1031.500000000000227) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
                result[0] += -0.0006846177126460071;
              } else {
                result[0] += -0.0003913217377070242;
              }
            } else {
              result[0] += 0.0005843876366171571;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02180250462562445188) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9993516786272610419) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7683067979899498301) ) ) {
                    result[0] += -7.258087881059951e-05;
                  } else {
                    result[0] += -0.0003426302083464138;
                  }
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7562503571356784526) ) ) {
                    result[0] += 0.0004320013667648814;
                  } else {
                    result[0] += 3.178949323039411e-05;
                  }
                }
              } else {
                result[0] += -4.488465729752903e-05;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02747750000000000539) ) ) {
                result[0] += -5.893100090184764e-06;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1245513101099625097) ) ) {
                  result[0] += 0.00020838954750361733;
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5792515097236182742) ) ) {
                    result[0] += -0.000606750109231896;
                  } else {
                    result[0] += 9.404328956250059e-05;
                  }
                }
              }
            }
          }
        } else {
          result[0] += -4.515641854866628e-05;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 2.672076542094847e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            result[0] += 2.672076542094847e-05;
          } else {
            result[0] += 2.672076542094847e-05;
          }
        } else {
          result[0] += -8.955359405035586e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 2.672076542094847e-05;
            } else {
              result[0] += 2.672076542094847e-05;
            }
          } else {
            result[0] += 2.672076542094847e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 2.672076542094847e-05;
          } else {
            result[0] += 2.672076542094847e-05;
          }
        }
      } else {
        result[0] += 2.672076542094847e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += 1.0947475203394305e-06;
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4892818374874372545) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4795364038944723295) ) ) {
            result[0] += 4.5425671412977434e-05;
          } else {
            result[0] += -0.0004608855373432392;
          }
        } else {
          result[0] += 0.0003111329865594404;
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5510720942211057016) ) ) {
          result[0] += -2.5515700857218136e-05;
        } else {
          result[0] += -4.0963693217193535e-05;
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5085295226130653878) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1031.500000000000227) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
                result[0] += -0.0006650303563846627;
              } else {
                result[0] += -0.00038012576928889575;
              }
            } else {
              result[0] += 0.0005676679277610934;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9079021320180030719) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1737935000000000174) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6010141514957837439) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5932867452288201893) ) ) {
                        result[0] += -1.7420335961319012e-05;
                      } else {
                        result[0] += -0.0009783509897966813;
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.606193063154585432) ) ) {
                        result[0] += 0.0029667155939824405;
                      } else {
                        result[0] += 8.766795592899589e-05;
                      }
                    }
                  } else {
                    result[0] += 0.00014580642172042042;
                  }
                } else {
                  result[0] += -0.0005588790947160518;
                }
              } else {
                result[0] += 0.00021223605868616715;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.130629626450776108e-06) ) ) {
                result[0] += -4.5457955899103296e-05;
              } else {
                result[0] += -3.914608796884836e-05;
              }
            }
          }
        } else {
          result[0] += -4.386446416118691e-05;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 2.5956267012261727e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            result[0] += 2.5956267012261727e-05;
          } else {
            result[0] += 2.5956267012261727e-05;
          }
        } else {
          result[0] += -8.699140771078415e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 2.5956267012261727e-05;
            } else {
              result[0] += 2.5956267012261727e-05;
            }
          } else {
            result[0] += 2.5956267012261727e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 2.5956267012261727e-05;
          } else {
            result[0] += 2.5956267012261727e-05;
          }
        }
      } else {
        result[0] += 2.5956267012261727e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += 1.0634260845935908e-06;
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4892818374874372545) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4795364038944723295) ) ) {
            result[0] += 4.4126013526625536e-05;
          } else {
            result[0] += -0.00044769930355335896;
          }
        } else {
          result[0] += 0.0003022312702587596;
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5510720942211057016) ) ) {
          result[0] += -2.4785680126354226e-05;
        } else {
          result[0] += -3.9791695417539084e-05;
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5085295226130653878) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1031.500000000000227) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
                result[0] += -0.0006460034070748505;
              } else {
                result[0] += -0.0003692501247800755;
              }
            } else {
              result[0] += 0.0005514265806066053;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9079021320180030719) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1737935000000000174) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6010141514957837439) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5932867452288201893) ) ) {
                        result[0] += -1.692192886438956e-05;
                      } else {
                        result[0] += -0.000950359734192555;
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.606193063154585432) ) ) {
                        result[0] += 0.002881835938969094;
                      } else {
                        result[0] += 8.515971891764525e-05;
                      }
                    }
                  } else {
                    result[0] += 0.00014163480554006718;
                  }
                } else {
                  result[0] += -0.0005428892017684802;
                }
              } else {
                result[0] += 0.00020616384755840883;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.130629626450776108e-06) ) ) {
                result[0] += -4.415737433268886e-05;
              } else {
                result[0] += -3.802609303281282e-05;
              }
            }
          }
        } else {
          result[0] += -4.2609473425674936e-05;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 2.5213641398297685e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            result[0] += 2.5213641398297685e-05;
          } else {
            result[0] += 2.5213641398297685e-05;
          }
        } else {
          result[0] += -8.450252718223597e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 2.5213641398297685e-05;
            } else {
              result[0] += 2.5213641398297685e-05;
            }
          } else {
            result[0] += 2.5213641398297685e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 2.5213641398297685e-05;
          } else {
            result[0] += 2.5213641398297685e-05;
          }
        }
      } else {
        result[0] += 2.5213641398297685e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += 1.0330007754147809e-06;
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4892818374874372545) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4795364038944723295) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4754075198241206057) ) ) {
              result[0] += 3.113116383490943e-05;
            } else {
              result[0] += 0.0009846679984968003;
            }
          } else {
            result[0] += -0.00043489033645438774;
          }
        } else {
          result[0] += 0.0002935842378280669;
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5510720942211057016) ) ) {
          result[0] += -2.407654576151543e-05;
        } else {
          result[0] += -3.8653229234165244e-05;
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5085295226130653878) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1031.500000000000227) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
                result[0] += -0.0006275208311106495;
              } else {
                result[0] += -0.0003586856395060103;
              }
            } else {
              result[0] += 0.0005356499089155226;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02180250462562445188) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1250000000000000278) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)99.50000000000001421) ) ) {
                  result[0] += -5.108192551830953e-05;
                } else {
                  result[0] += -2.2924300787063774e-05;
                }
              } else {
                result[0] += -7.748481986406478e-06;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02747750000000000539) ) ) {
                result[0] += -4.9908778291252456e-06;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1245513101099625097) ) ) {
                  result[0] += 0.0002034099419965458;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2150000000000000244) ) ) {
                    result[0] += 0.00020174610540214658;
                  } else {
                    result[0] += -5.102853239728135e-06;
                  }
                }
              }
            }
          }
        } else {
          result[0] += -4.139038878810213e-05;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 2.4492262784230945e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 2.4492262784230945e-05;
            } else {
              result[0] += 2.4492262784230945e-05;
            }
          } else {
            result[0] += 2.4492262784230945e-05;
          }
        } else {
          result[0] += -8.208485513779947e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 2.4492262784230945e-05;
            } else {
              result[0] += 2.4492262784230945e-05;
            }
          } else {
            result[0] += 2.4492262784230945e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 2.4492262784230945e-05;
          } else {
            result[0] += 2.4492262784230945e-05;
          }
        }
      } else {
        result[0] += 2.4492262784230945e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += 1.0034459540413975e-06;
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4892818374874372545) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4795364038944723295) ) ) {
            result[0] += 4.1904976246918914e-05;
          } else {
            result[0] += -0.0004224478422019019;
          }
        } else {
          result[0] += 0.0002851846025968548;
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5510720942211057016) ) ) {
          result[0] += -2.3387700190239348e-05;
        } else {
          result[0] += -3.754733530580803e-05;
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5085295226130653878) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1031.500000000000227) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
                result[0] += -0.0006095670536179911;
              } else {
                result[0] += -0.0003484234109994197;
              }
            } else {
              result[0] += 0.0005203246180218146;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7293938685427137081) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6010141514957837439) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1560895000000000199) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5932867452288201893) ) ) {
                    result[0] += -1.7129543832893938e-05;
                  } else {
                    result[0] += -0.00091924523238366;
                  }
                } else {
                  result[0] += 0.00016914635759230455;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.606193063154585432) ) ) {
                  result[0] += 0.002799530741808482;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9079021320180030719) ) ) {
                    result[0] += 2.9626251376407714e-05;
                  } else {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0131020000000000008) ) ) {
                      result[0] += 0.0001500842924635771;
                    } else {
                      result[0] += 0.00019449327955585718;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.735388073517588059) ) ) {
                result[0] += -0.0010555284575587069;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6413622072216433878) ) ) {
                  result[0] += 0.0010199313329912808;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.676837902221867901e-06) ) ) {
                    result[0] += -4.038064642769049e-05;
                  } else {
                    result[0] += -3.4698558016660676e-05;
                  }
                }
              }
            }
          }
        } else {
          result[0] += -4.020618295174612e-05;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 2.3791523279629266e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          result[0] += 2.3791523279629266e-05;
        } else {
          result[0] += -7.973635425694819e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            result[0] += 2.3791523279629266e-05;
          } else {
            result[0] += 2.3791523279629266e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 2.3791523279629266e-05;
          } else {
            result[0] += 2.3791523279629266e-05;
          }
        }
      } else {
        result[0] += 2.3791523279629266e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
          result[0] += 9.747367152534255e-07;
        } else {
          result[0] += -2.2718562936998884e-05;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4960533228876460865) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5528143519346734314) ) ) {
            result[0] += 2.6448814347348508e-05;
          } else {
            result[0] += 0.0010973372976150874;
          }
        } else {
          result[0] += -0.0005806187262444555;
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -3.647308171915084e-05;
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.32337995336020553) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.115000000000000005) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)45.50000000000000711) ) ) {
                  result[0] += -4.8707643971022686e-05;
                } else {
                  result[0] += -3.994299125208892e-05;
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)49.50000000000000711) ) ) {
                  result[0] += -3.632731675614788e-05;
                } else {
                  result[0] += -3.9225329974387554e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1129321246270776624) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
                  result[0] += -0.00027875333713974274;
                } else {
                  result[0] += 0.00012149611537779912;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1245513101099625097) ) ) {
                  result[0] += 0.0005286327815261158;
                } else {
                  result[0] += 8.185069606522505e-06;
                }
              }
            }
          } else {
            result[0] += 0.00014924648610823064;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
            result[0] += -3.9055858011509225e-05;
          } else {
            result[0] += -5.8534259209345644e-05;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 2.3110832386201867e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 2.3110832386201867e-05;
            } else {
              result[0] += 2.3110832386201867e-05;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 2.3110832386201867e-05;
            } else {
              result[0] += 2.3110832386201867e-05;
            }
          }
        } else {
          result[0] += -7.745504550773318e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 2.3110832386201867e-05;
            } else {
              result[0] += 2.3110832386201867e-05;
            }
          } else {
            result[0] += 2.3110832386201867e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 2.3110832386201867e-05;
          } else {
            result[0] += 2.3110832386201867e-05;
          }
        }
      } else {
        result[0] += 2.3110832386201867e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += 9.468488663853352e-07;
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4892818374874372545) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4795364038944723295) ) ) {
            result[0] += 3.994933001771502e-05;
          } else {
            result[0] += -0.0004111180534826543;
          }
        } else {
          result[0] += 0.0002762685686586825;
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5510720942211057016) ) ) {
          result[0] += -2.2068570134047753e-05;
        } else {
          result[0] += -3.542956322352067e-05;
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5085295226130653878) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
              result[0] += -0.0005815850527204488;
            } else {
              result[0] += -0.0002013309011293899;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02180250462562445188) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9993516786272610419) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7683067979899498301) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7640286906783920751) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8412950649051146312) ) ) {
                        result[0] += -4.208813041071794e-05;
                      } else {
                        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7392963230402010977) ) ) {
                          result[0] += -5.113463187979653e-05;
                        } else {
                          result[0] += -0.0003314138555478621;
                        }
                      }
                    } else {
                      result[0] += 0.000572901654321952;
                    }
                  } else {
                    result[0] += -0.0003278279678604913;
                  }
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.750591121697756835e-06) ) ) {
                    result[0] += -5.121360606897917e-05;
                  } else {
                    result[0] += 0.00019572548477837798;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  result[0] += -3.7297459988873874e-05;
                } else {
                  result[0] += -0.0001904397831630612;
                }
              }
            } else {
              result[0] += 4.638365690978085e-05;
            }
          }
        } else {
          result[0] += -3.793844461300508e-05;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 2.2449616500194175e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            result[0] += 2.2449616500194175e-05;
          } else {
            result[0] += 2.2449616500194175e-05;
          }
        } else {
          result[0] += -7.523900647948007e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 2.2449616500194175e-05;
            } else {
              result[0] += 2.2449616500194175e-05;
            }
          } else {
            result[0] += 2.2449616500194175e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 2.2449616500194175e-05;
          } else {
            result[0] += 2.2449616500194175e-05;
          }
        }
      } else {
        result[0] += 2.2449616500194175e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += 9.197589069394208e-07;
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4892818374874372545) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4795364038944723295) ) ) {
            result[0] += 3.880635380631267e-05;
          } else {
            result[0] += -0.0003993556996459227;
          }
        } else {
          result[0] += 0.0002683643459396778;
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5510720942211057016) ) ) {
          result[0] += -2.143717404626122e-05;
        } else {
          result[0] += -3.441590046805273e-05;
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5085295226130653878) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
              result[0] += -0.0005649455276052135;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1031.500000000000227) ) ) {
                result[0] += -0.00032502357943032313;
              } else {
                result[0] += 0.0004574173120046138;
              }
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9079021320180030719) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2070775000000000254) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6010141514957837439) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5932867452288201893) ) ) {
                        result[0] += -1.550536282429535e-05;
                      } else {
                        result[0] += -0.0008968556649357879;
                      }
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.606193063154585432) ) ) {
                        result[0] += 0.002717873107104108;
                      } else {
                        result[0] += 7.967674622141593e-05;
                      }
                    }
                  } else {
                    result[0] += 0.00017598688580548497;
                  }
                } else {
                  result[0] += -0.0005147736886231014;
                }
              } else {
                result[0] += 0.00018481233478745854;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.130629626450776108e-06) ) ) {
                result[0] += -4.02579880776177e-05;
              } else {
                result[0] += -3.3000198698664594e-05;
              }
            }
          }
        } else {
          result[0] += -3.685300113570427e-05;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 2.1807318429025623e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            result[0] += 2.1807318429025623e-05;
          } else {
            result[0] += 2.1807318429025623e-05;
          }
        } else {
          result[0] += -7.308636976345022e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 2.1807318429025623e-05;
            } else {
              result[0] += 2.1807318429025623e-05;
            }
          } else {
            result[0] += 2.1807318429025623e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 2.1807318429025623e-05;
          } else {
            result[0] += 2.1807318429025623e-05;
          }
        }
      } else {
        result[0] += 2.1807318429025623e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          result[0] += 8.934440087824111e-07;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4892818374874372545) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4795364038944723295) ) ) {
                result[0] += 7.053248682189445e-05;
              } else {
                result[0] += -0.0004460053934655207;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.005566725998003100966) ) ) {
                result[0] += -8.522492680948316e-05;
              } else {
                result[0] += 0.0003923321504458579;
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02472850000000000395) ) ) {
              result[0] += 1.4473990552638806e-06;
            } else {
              result[0] += -5.825126006795932e-05;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5510720942211057016) ) ) {
            result[0] += -2.082384260957128e-05;
          } else {
            result[0] += -3.343123926068011e-05;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5085295226130653878) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)288.5000000000000568) ) ) {
                result[0] += -0.0005847691895416495;
              } else {
                result[0] += 0.000676968155448997;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.32337995336020553) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05826200000000000823) ) ) {
                    result[0] += -5.151959063127136e-05;
                  } else {
                    result[0] += 0.00023163040811984313;
                  }
                } else {
                  result[0] += -3.58841562628239e-05;
                }
              } else {
                result[0] += 0.00013836178036358477;
              }
            }
          } else {
            result[0] += 7.62660393105054e-06;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
        result[0] += -3.579861289945071e-05;
      } else {
        result[0] += -5.471972442070422e-05;
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 2.118339692176079e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 2.118339692176079e-05;
            } else {
              result[0] += 2.118339692176079e-05;
            }
          } else {
            result[0] += 2.118339692176079e-05;
          }
        } else {
          result[0] += -7.099532137828931e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 2.118339692176079e-05;
            } else {
              result[0] += 2.118339692176079e-05;
            }
          } else {
            result[0] += 2.118339692176079e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 2.118339692176079e-05;
          } else {
            result[0] += 2.118339692176079e-05;
          }
        }
      } else {
        result[0] += 2.118339692176079e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
          result[0] += 8.67881996908722e-07;
        } else {
          result[0] += -2.022805898260755e-05;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4960533228876460865) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5528143519346734314) ) ) {
            result[0] += 2.4074854965020754e-05;
          } else {
            result[0] += 0.001067079937576185;
          }
        } else {
          result[0] += -0.0005144732403856233;
        }
      }
    } else {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        result[0] += -3.247474984832428e-05;
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9189305784170854752) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.115000000000000005) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04770400000000000335) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4840806222471906728) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)117.5000000000000142) ) ) {
                    result[0] += -0.0003363218862332344;
                  } else {
                    result[0] += -4.6681846184849874e-05;
                  }
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6852090990703517681) ) ) {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
                      result[0] += 0.0007806586467277903;
                    } else {
                      result[0] += 5.691200571471736e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
                      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7683067979899498301) ) ) {
                        result[0] += -5.67132442884756e-05;
                      } else {
                        result[0] += -0.00022947546324853513;
                      }
                    } else {
                      result[0] += 3.778253090035374e-05;
                    }
                  }
                }
              } else {
                result[0] += -3.4857487306011334e-05;
              }
            } else {
              result[0] += 7.963057646678665e-05;
            }
          } else {
            result[0] += -5.000684265657119e-06;
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -3.4774391393680144e-05;
          } else {
            result[0] += -0.00041133645359382265;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 2.0577326213000907e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 2.0577326213000907e-05;
            } else {
              result[0] += 2.0577326213000907e-05;
            }
          } else {
            result[0] += 2.0577326213000907e-05;
          }
        } else {
          result[0] += -6.896409924216928e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 2.0577326213000907e-05;
            } else {
              result[0] += 2.0577326213000907e-05;
            }
          } else {
            result[0] += 2.0577326213000907e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 2.0577326213000907e-05;
          } else {
            result[0] += 2.0577326213000907e-05;
          }
        }
      } else {
        result[0] += 2.0577326213000907e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
            result[0] += 8.430513307540741e-07;
          } else {
            result[0] += -1.9649321111166162e-05;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5528143519346734314) ) ) {
            result[0] += 2.338605776852749e-05;
          } else {
            result[0] += 0.0010365500892965441;
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          result[0] += -3.154562621767979e-05;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2070775000000000254) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1129321246270776624) ) ) {
              result[0] += -0.00020217636748334766;
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.115000000000000005) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)46.50000000000000711) ) ) {
                  result[0] += -4.187975855766493e-05;
                } else {
                  result[0] += -3.0157084261409363e-05;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1245513101099625097) ) ) {
                  result[0] += 0.000515080913081184;
                } else {
                  result[0] += -1.4029786252895432e-06;
                }
              }
            }
          } else {
            result[0] += 0.000155511546321918;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)60.50000000000000711) ) ) {
            result[0] += -3.154562621767979e-05;
          } else {
            result[0] += -3.3779473528691115e-05;
          }
        } else {
          result[0] += -0.00011470912317472862;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.508252903391186006) ) ) {
          result[0] += 3.785845923792316e-05;
        } else {
          result[0] += -0.00038927092434381296;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 1.9988595579839955e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 1.9988595579839955e-05;
            } else {
              result[0] += 1.9988595579839955e-05;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 1.9988595579839955e-05;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 1.9988595579839955e-05;
              } else {
                result[0] += 1.9988595579839955e-05;
              }
            }
          }
        } else {
          result[0] += -6.699099168717676e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 1.9988595579839955e-05;
            } else {
              result[0] += 1.9988595579839955e-05;
            }
          } else {
            result[0] += 1.9988595579839955e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 1.9988595579839955e-05;
          } else {
            result[0] += 1.9988595579839955e-05;
          }
        }
      } else {
        result[0] += 1.9988595579839955e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
            result[0] += 8.189310860436917e-07;
          } else {
            result[0] += -1.9087141305139202e-05;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5528143519346734314) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.007190624686192600631) ) ) {
              result[0] += -5.957701707950274e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
                result[0] += 7.459601632329068e-05;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0159540000000000029) ) ) {
                  result[0] += 2.4375322899355216e-05;
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)40.50000000000000711) ) ) {
                    result[0] += 2.0761458906608108e-06;
                  } else {
                    result[0] += -4.558993493979973e-05;
                  }
                }
              }
            }
          } else {
            result[0] += 0.001006893719753738;
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          result[0] += -3.064308541600413e-05;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2070775000000000254) ) ) {
            result[0] += -3.293911737631203e-05;
          } else {
            result[0] += 0.0001510622602396368;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)60.50000000000000711) ) ) {
            result[0] += -3.064308541600413e-05;
          } else {
            result[0] += -3.281302090833766e-05;
          }
        } else {
          result[0] += -0.00011142722085092522;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.508252903391186006) ) ) {
          result[0] += 3.677530419401881e-05;
        } else {
          result[0] += -0.0003781336310245447;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 1.9416708911478824e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 1.9416708911478824e-05;
            } else {
              result[0] += 1.9416708911478824e-05;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 1.9416708911478824e-05;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 1.9416708911478824e-05;
              } else {
                result[0] += 1.9416708911478824e-05;
              }
            }
          }
        } else {
          result[0] += -6.507433601753601e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 1.9416708911478824e-05;
            } else {
              result[0] += 1.9416708911478824e-05;
            }
          } else {
            result[0] += 1.9416708911478824e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 1.9416708911478824e-05;
          } else {
            result[0] += 1.9416708911478824e-05;
          }
        }
      } else {
        result[0] += 1.9416708911478824e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          result[0] += 7.955009371598463e-07;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4892818374874372545) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4795364038944723295) ) ) {
                result[0] += 6.50899415144776e-05;
              } else {
                result[0] += -0.0004367370180415731;
              }
            } else {
              result[0] += 0.00030735924017615565;
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02472850000000000395) ) ) {
              result[0] += 1.12181562569655e-06;
            } else {
              result[0] += -5.6638183668350144e-05;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5510720942211057016) ) ) {
            result[0] += -1.8541045827548652e-05;
          } else {
            result[0] += -2.9766366891339788e-05;
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.516715179698492566) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1031.500000000000227) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007548500000000000522) ) ) {
                result[0] += -4.4869721320139544e-05;
              } else {
                result[0] += -0.00047779788623520736;
              }
            } else {
              result[0] += 0.0004893832143769202;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.028975360347832879) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5528143519346734314) ) ) {
                  result[0] += 5.7593197498903654e-05;
                } else {
                  result[0] += 0.0009780858381552614;
                }
              } else {
                result[0] += -2.570671857735189e-05;
              }
            } else {
              result[0] += 0.00013402395205523571;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9189305784170854752) ) ) {
          result[0] += -3.127604815328898e-05;
        } else {
          result[0] += -3.1874219123530674e-05;
        }
      } else {
        result[0] += -0.00015327253750157236;
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 1.8861184291173513e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 1.8861184291173513e-05;
            } else {
              result[0] += 1.8861184291173513e-05;
            }
          } else {
            result[0] += 1.8861184291173513e-05;
          }
        } else {
          result[0] += -6.321251710817243e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 1.8861184291173513e-05;
            } else {
              result[0] += 1.8861184291173513e-05;
            }
          } else {
            result[0] += 1.8861184291173513e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 1.8861184291173513e-05;
          } else {
            result[0] += 1.8861184291173513e-05;
          }
        }
      } else {
        result[0] += 1.8861184291173513e-05;
      }
    }
  }
}

