
#include "header.h"

void predict_unit3(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6350000000000001199) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.0650000000000000161) ) ) {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002265000000000000032) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
            result[0] += -0.00402023642362227;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += -0.004249008274629477;
            } else {
              result[0] += -0.0032560095751497345;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4992188184422110542) ) ) {
              result[0] += -0.003007435837833632;
            } else {
              result[0] += -0.004024319299236334;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
              result[0] += -0.00023523337581816492;
            } else {
              result[0] += -0.002368693316034981;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6413622072216433878) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06439350000000000629) ) ) {
            result[0] += -0.0028520681861297728;
          } else {
            result[0] += -0.0002667439967946871;
          }
        } else {
          result[0] += -0.003365342784558097;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2650000000000000688) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0195721650588623515) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5046554252763820747) ) ) {
            result[0] += -0.0010433985988093763;
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8342136590201005841) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)46.50000000000000711) ) ) {
                result[0] += -0.0026750013418122983;
              } else {
                result[0] += -0.0017341342623773983;
              }
            } else {
              result[0] += -0.0028132857417056028;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01359750000000000195) ) ) {
            result[0] += -0.0017226282224559967;
          } else {
            result[0] += -0.00019396445349715698;
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6550000000000001377) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006979000000000000828) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
              result[0] += 2.2746925146657452e-05;
            } else {
              result[0] += -0.000885005946795299;
            }
          } else {
            result[0] += 0.0001677145343229249;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.144071500000000019) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7593447680904524821) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01840935775314125541) ) ) {
                result[0] += 0.00019744936549856396;
              } else {
                result[0] += 0.0010770655295093338;
              }
            } else {
              result[0] += -0.00028348493888860594;
            }
          } else {
            result[0] += 0.0033956600407716118;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7650000000000001243) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04423300000000000148) ) ) {
          result[0] += 0.0011587399897341627;
        } else {
          result[0] += 0.0029400799515296254;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02447420998234165271) ) ) {
          result[0] += 0.0015787255005200623;
        } else {
          result[0] += 0.002190990689419391;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
        result[0] += 0.0022612795861282112;
      } else {
        result[0] += 0.0025473857913808013;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6350000000000001199) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.0650000000000000161) ) ) {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
            result[0] += -0.003905214855191073;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += -0.00417073859706749;
            } else {
              result[0] += -0.003162853031927513;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4992188184422110542) ) ) {
              result[0] += -0.0029213911502647006;
            } else {
              result[0] += -0.003909180917088889;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
              result[0] += -0.00029107548739039016;
            } else {
              result[0] += -0.002298940660718618;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7473910280653267568) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4814085394974874643) ) ) {
            result[0] += -0.001346576763480411;
          } else {
            result[0] += -0.00283648785959597;
          }
        } else {
          result[0] += -0.0034568104974221628;
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4950000000000000511) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2750000000000000777) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00423900000000000058) ) ) {
            result[0] += -0.0023174815259567588;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
              result[0] += 0.0014500383511019432;
            } else {
              result[0] += -0.0013054191697669715;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0002265000000000000032) ) ) {
            result[0] += -3.362633064069284e-05;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003250500000000000351) ) ) {
              result[0] += -0.0014699591682721413;
            } else {
              result[0] += -0.000632110734494616;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01882700000000000345) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4450000000000000622) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
              result[0] += -0.00013270315047291857;
            } else {
              result[0] += -0.0014504434050160804;
            }
          } else {
            result[0] += 0.00031045649533433976;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03139221484724531025) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5826692266582915725) ) ) {
              result[0] += 0.001285272065027447;
            } else {
              result[0] += -0.000650888654845587;
            }
          } else {
            result[0] += 0.0023572850334886634;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8950000000000001288) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7650000000000001243) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04423300000000000148) ) ) {
          result[0] += 0.0011255876879839378;
        } else {
          result[0] += 0.002855962359501701;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02530977052884725645) ) ) {
          result[0] += 0.0014787828446989899;
        } else {
          result[0] += 0.0021278882211150205;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03358130704046471265) ) ) {
          result[0] += 0.0019833352208118655;
        } else {
          result[0] += 0.002332756304827086;
        }
      } else {
        result[0] += 0.002474503433666136;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6350000000000001199) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.0650000000000000161) ) ) {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
            result[0] += -0.0037934841283448727;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += -0.004051411063957138;
            } else {
              result[0] += -0.0030723617577546663;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3172900446231167737) ) ) {
              result[0] += -0.002989052498060559;
            } else {
              result[0] += -0.0037990463096383696;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
              result[0] += -0.00028274762913439467;
            } else {
              result[0] += -0.0022331664791375616;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6413622072216433878) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06130050000000000082) ) ) {
            result[0] += -0.0027070591359983805;
          } else {
            result[0] += -0.00030070247116242523;
          }
        } else {
          result[0] += -0.00317015655969812;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2650000000000000688) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1645630000000000426) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.29500000000000004) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00423900000000000058) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)91.50000000000001421) ) ) {
                  result[0] += -0.002672689680519196;
                } else {
                  result[0] += -0.0016514376283103664;
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.05500000000000000722) ) ) {
                  result[0] += 0.0005404375738543659;
                } else {
                  result[0] += -0.001400194570254074;
                }
              }
            } else {
              result[0] += -0.0008783206703298801;
            }
          } else {
            result[0] += -0.003127228870612803;
          }
        } else {
          result[0] += 0.00135376703278211;
        }
      } else {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4350000000000000533) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.05368089823796016319) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01225471801880190052) ) ) {
              result[0] += -0.00038600042028613473;
            } else {
              result[0] += 0.0008161793847474938;
            }
          } else {
            result[0] += -0.0006665729173939475;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1840395000000000225) ) ) {
            result[0] += 0.0003815195122552844;
          } else {
            result[0] += 0.0035773947904013553;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8950000000000001288) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7450000000000001066) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04423300000000000148) ) ) {
          result[0] += 0.0009787182352880687;
        } else {
          result[0] += 0.002862458797225391;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03119100000000000344) ) ) {
          result[0] += 0.0014472351730453682;
        } else {
          result[0] += 0.002805888806124507;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03358130704046471265) ) ) {
          result[0] += 0.0019265907153190594;
        } else {
          result[0] += 0.0022660146357619568;
        }
      } else {
        result[0] += 0.002403706287419642;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6950000000000000622) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1750000000000000167) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.858234205283420677e-05) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)3.500000000000000444) ) ) {
              result[0] += -0.0036849500899740796;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7586658169597990664) ) ) {
                result[0] += -0.0033473816383269702;
              } else {
                result[0] += -0.003935497568870701;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4737195465326633492) ) ) {
              result[0] += -0.0013198657608783527;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6214144784636018715) ) ) {
                result[0] += -0.003006594199165612;
              } else {
                result[0] += -0.003688643542661696;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7473910280653267568) ) ) {
            result[0] += -0.0029458401623480347;
          } else {
            result[0] += -0.003439548963540561;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += -0.0034367585949095568;
        } else {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
            result[0] += -0.0007856095474152977;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
              result[0] += -0.0007118726478223682;
            } else {
              result[0] += -0.002105550281819696;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4350000000000000533) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5800027599246232457) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02620539606947270075) ) ) {
            result[0] += -0.0005763246696843793;
          } else {
            result[0] += 0.0010037813681835386;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1737935000000000174) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2650000000000000688) ) ) {
              result[0] += -0.0016281395992686408;
            } else {
              result[0] += -0.0007219194636297529;
            }
          } else {
            result[0] += 0.0017136369444598924;
          }
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.009516766579768852138) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.650000000000000541e-05) ) ) {
            result[0] += 0.0014268974879987249;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6850000000000001643) ) ) {
              result[0] += -0.0008995319462611715;
            } else {
              result[0] += 0.000155481396646996;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.05368089823796016319) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)37.50000000000000711) ) ) {
              result[0] += 0.0008502803645979291;
            } else {
              result[0] += 0.0022043711443688616;
            }
          } else {
            result[0] += 0.0004453391003108004;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9150000000000001465) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7750000000000001332) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02007650000000000406) ) ) {
          result[0] += 0.0010869602658593709;
        } else {
          result[0] += 0.0025099868478765815;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03358130704046471265) ) ) {
          result[0] += 0.0015145070493074839;
        } else {
          result[0] += 0.0021922683544568604;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
        result[0] += 0.0020650090965460763;
      } else {
        result[0] += 0.002334934693390398;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6350000000000001199) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.0650000000000000161) ) ) {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
            result[0] += -0.0035795212807505647;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += -0.003822900433968666;
            } else {
              result[0] += -0.002888688740415598;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3172900446231167737) ) ) {
              result[0] += -0.0028454983903690636;
            } else {
              result[0] += -0.0035848186523599647;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
              result[0] += -0.0001896848527715452;
            } else {
              result[0] += -0.0020862160749687726;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7473910280653267568) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2050000000000000433) ) ) {
            result[0] += -0.0025316705589703697;
          } else {
            result[0] += 0.00016525220616581674;
          }
        } else {
          result[0] += -0.0031744057762704905;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2650000000000000688) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01896216239618550223) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8324892801256282837) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1550000000000000266) ) ) {
              result[0] += -0.001956031891161199;
            } else {
              result[0] += -0.0011948353321463803;
            }
          } else {
            result[0] += -0.002699816102554301;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1840395000000000225) ) ) {
            result[0] += -0.0008214738192728312;
          } else {
            result[0] += 0.0016867877020825973;
          }
        }
      } else {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6750000000000001554) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02092750000000000513) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
              result[0] += 0.00011615376103839269;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00279350000000000041) ) ) {
                result[0] += -0.0009956245451333571;
              } else {
                result[0] += -0.00029509369287963525;
              }
            }
          } else {
            result[0] += 0.0005119304076717934;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02085144663384500344) ) ) {
            result[0] += 0.0001663299260867025;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5800027599246232457) ) ) {
              result[0] += 0.0019996256208235866;
            } else {
              result[0] += 0.00038912557100007853;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7450000000000001066) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04423300000000000148) ) ) {
          result[0] += 0.0009312306122859409;
        } else {
          result[0] += 0.002715873656527254;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03119100000000000344) ) ) {
          result[0] += 0.0013892783695774486;
        } else {
          result[0] += 0.0026628882919015892;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03358130704046471265) ) ) {
          result[0] += 0.0018281386790938343;
        } else {
          result[0] += 0.002144363684205194;
        }
      } else {
        result[0] += 0.0022681306992172897;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6950000000000000622) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.0650000000000000161) ) ) {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
            result[0] += -0.003477108858056824;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += -0.003713524776037785;
            } else {
              result[0] += -0.002806041484229414;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.639650859467608468) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
              if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05740595745564833902) ) ) {
                result[0] += -0.0022550182699799678;
              } else {
                result[0] += 0.001817876928410791;
              }
            } else {
              result[0] += -0.0024140930029127915;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += -0.0037666515491469646;
            } else {
              result[0] += -0.0023126345000097667;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6413622072216433878) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2050000000000000433) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03603979634774020363) ) ) {
              result[0] += -0.002502906112125467;
            } else {
              result[0] += -0.0002583478817820659;
            }
          } else {
            result[0] += 0.00035652276243042144;
          }
        } else {
          result[0] += -0.0029226473087044682;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3850000000000000644) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1850000000000000255) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00423900000000000058) ) ) {
            result[0] += -0.002136815363485045;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.247314011309283543) ) ) {
              result[0] += -0.0009387597439662412;
            } else {
              result[0] += -0.0024576703564026907;
            }
          }
        } else {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02989549209881260314) ) ) {
              result[0] += -0.0004042506042617497;
            } else {
              result[0] += 0.0017996177914567776;
            }
          } else {
            result[0] += -0.0009257383088151652;
          }
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.009723928609266600451) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += -0.00014223819278831774;
          } else {
            result[0] += 0.0010229973047301366;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.05368089823796016319) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)37.50000000000000711) ) ) {
              result[0] += 0.0007756441512232239;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02844215559246820318) ) ) {
                result[0] += 0.0015207278539888453;
              } else {
                result[0] += 0.0029371815606629675;
              }
            }
          } else {
            result[0] += 0.000316045601905902;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9150000000000001465) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7750000000000001332) ) ) {
        result[0] += 0.0013289974347547376;
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03358130704046471265) ) ) {
          result[0] += 0.0014314278673705052;
        } else {
          result[0] += 0.0020830120500587744;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
        result[0] += 0.001941035159935834;
      } else {
        result[0] += 0.0022032380105938033;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7050000000000000711) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.0650000000000000161) ) ) {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
            result[0] += -0.0033776265211201938;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += -0.0036072784265350055;
            } else {
              result[0] += -0.002725758819582476;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8030059940338053481) ) ) {
              result[0] += -0.002789148805492389;
            } else {
              result[0] += -0.0036588852082494504;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
              result[0] += -0.00020105126324081147;
            } else {
              result[0] += -0.0019603621103970507;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6413622072216433878) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06439350000000000629) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4814085394974874643) ) ) {
              result[0] += -0.0011916245072377202;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6010141514957837439) ) ) {
                result[0] += -0.0026692902569803887;
              } else {
                result[0] += -0.00016275709172277537;
              }
            }
          } else {
            result[0] += -2.5604811208543146e-05;
          }
        } else {
          result[0] += -0.0028390284758808217;
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5350000000000001421) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1850000000000000255) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01221850000000000193) ) ) {
              result[0] += -0.0018756336962635627;
            } else {
              result[0] += -0.000669444785152991;
            }
          } else {
            result[0] += -0.003237553938036313;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.01704648841990550126) ) ) {
            result[0] += -0.00020475253332037603;
          } else {
            result[0] += -0.0009638132317586906;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.144071500000000019) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01321089953182515153) ) ) {
              result[0] += 0.00035511624923636407;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)44.50000000000000711) ) ) {
                result[0] += 0.0008086519012549022;
              } else {
                result[0] += 0.0021602116967185518;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4750000000000000333) ) ) {
              result[0] += -0.0004306406155641877;
            } else {
              result[0] += 0.0003175888115705999;
            }
          }
        } else {
          result[0] += 0.00304866019965161;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9450000000000000622) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8550000000000000933) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03119100000000000344) ) ) {
          result[0] += 0.001184100210786737;
        } else {
          result[0] += 0.002648316178404947;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03358130704046471265) ) ) {
          result[0] += 0.001534375805741085;
        } else {
          result[0] += 0.002031118746518766;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        result[0] += 0.0019052091884056866;
      } else {
        result[0] += 0.002140201943829998;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7050000000000000711) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.0650000000000000161) ) ) {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
            result[0] += -0.003280990438289023;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += -0.0035040718539190016;
            } else {
              result[0] += -0.0026477730939790402;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8030059940338053481) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
                result[0] += -0.0024887988742111926;
              } else {
                result[0] += -0.0027093494513273724;
              }
            } else {
              result[0] += -0.0035542021321771813;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6650804020351760437) ) ) {
              result[0] += -0.001042232199341495;
            } else {
              result[0] += -0.0021903812988939616;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7473910280653267568) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4814085394974874643) ) ) {
            result[0] += -0.0010025055454676141;
          } else {
            result[0] += -0.002394768114209838;
          }
        } else {
          result[0] += -0.0029187386939269516;
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5350000000000001421) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1850000000000000255) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01221850000000000193) ) ) {
              result[0] += -0.0018219706011582606;
            } else {
              result[0] += -0.0006502915361764028;
            }
          } else {
            result[0] += -0.0031449254225476616;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.007100500000000000908) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.000726282482777400166) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2850000000000000866) ) ) {
                result[0] += -0.0018368249988383837;
              } else {
                result[0] += 0.000283631481741519;
              }
            } else {
              result[0] += -0.001043192315817894;
            }
          } else {
            result[0] += -0.00017251113235743705;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.144071500000000019) ) ) {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3539353041941689093) ) ) {
            result[0] += 0.0015367598854277701;
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4850000000000000422) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8030059940338053481) ) ) {
                result[0] += 1.6454977792306604e-05;
              } else {
                result[0] += -0.0009579342630915425;
              }
            } else {
              result[0] += 0.0004344845782242623;
            }
          }
        } else {
          result[0] += 0.0029614360563854905;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9450000000000000622) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8650000000000001021) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03119100000000000344) ) ) {
          result[0] += 0.0011236098313777304;
        } else {
          result[0] += 0.0025693841105491667;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03358130704046471265) ) ) {
          result[0] += 0.001539624757196878;
        } else {
          result[0] += 0.001973007123400816;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        result[0] += 0.0018506999193108862;
      } else {
        result[0] += 0.002078969379771732;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7050000000000000711) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05500000000000000722) ) ) {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
            result[0] += -0.0031871191763895206;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += -0.0034038180882038425;
            } else {
              result[0] += -0.0025720185905050907;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8030059940338053481) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
                result[0] += -0.0024175927261499697;
              } else {
                result[0] += -0.0026318332083798764;
              }
            } else {
              result[0] += -0.003452514106726135;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.714147492562814179) ) ) {
              result[0] += -0.0012569898759246785;
            } else {
              result[0] += -0.0024138195959820994;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7473910280653267568) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4992188184422110542) ) ) {
            result[0] += -0.0009966531738114035;
          } else {
            result[0] += -0.0024101619929337522;
          }
        } else {
          result[0] += -0.002902045871923826;
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4950000000000000511) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1850000000000000255) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02085144663384500344) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8371684470603016903) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
                result[0] += 0.000490814429457362;
              } else {
                result[0] += -0.0017573276696725476;
              }
            } else {
              result[0] += -0.0032244712229872606;
            }
          } else {
            result[0] += -0.0006504974741790519;
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.323165429195979903) ) ) {
            result[0] += 0.0008505600511095582;
          } else {
            result[0] += -0.0007448864705487186;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02085144663384500344) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5050000000000001155) ) ) {
            result[0] += -0.0003058837400752486;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
              result[0] += 0.0017484726108548342;
            } else {
              result[0] += 0.00032112215731060776;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01882700000000000345) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
              result[0] += 0.0006273544833888621;
            } else {
              result[0] += -0.0005417185721202694;
            }
          } else {
            result[0] += 0.0019170646510549233;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9450000000000000622) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8650000000000001021) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03119100000000000344) ) ) {
          result[0] += 0.0010914626262157683;
        } else {
          result[0] += 0.002495872366672352;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03358130704046471265) ) ) {
          result[0] += 0.0014955750955083947;
        } else {
          result[0] += 0.0019165581114655881;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        result[0] += 0.0017977501957165641;
      } else {
        result[0] += 0.0020194887190382723;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7450000000000001066) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.0650000000000000161) ) ) {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
            result[0] += -0.0030959336321037525;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += -0.0033064326476712367;
            } else {
              result[0] += -0.002498431472450093;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.639650859467608468) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
              if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05740595745564833902) ) ) {
                result[0] += -0.002098161983987706;
              } else {
                result[0] += 0.0018457251037975598;
              }
            } else {
              result[0] += -0.0021937062778107468;
            }
          } else {
            result[0] += -0.0030676289698478017;
          }
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7473910280653267568) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1550000000000000266) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01667338205697885267) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)45.50000000000000711) ) ) {
                result[0] += -0.002820952050820329;
              } else {
                result[0] += -0.002118776232365379;
              }
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.08377477200961473691) ) ) {
                result[0] += 0.001037837478361474;
              } else {
                result[0] += -0.0017519434056529049;
              }
            }
          } else {
            result[0] += -0.000650203569665304;
          }
        } else {
          result[0] += -0.002760307334111532;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3850000000000000644) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1850000000000000255) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01896216239618550223) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8371684470603016903) ) ) {
              result[0] += -0.0016037545780653532;
            } else {
              result[0] += -0.0031322170124512836;
            }
          } else {
            result[0] += -0.0007625125396554096;
          }
        } else {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02989549209881260314) ) ) {
              result[0] += -0.0003314644230823648;
            } else {
              result[0] += 0.0017128988496984733;
            }
          } else {
            result[0] += -0.0008439107631524969;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.144071500000000019) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5650000000000000577) ) ) {
            result[0] += 8.047180312585996e-05;
          } else {
            result[0] += 0.0007732929419558857;
          }
        } else {
          result[0] += 0.0029554541895370065;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9450000000000000622) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8650000000000001021) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01871178646485605404) ) ) {
          result[0] += 0.0010410256505366485;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)25.50000000000000355) ) ) {
            result[0] += 0.0009004709494231782;
          } else {
            result[0] += 0.0018833952732434127;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04088342693368870323) ) ) {
          result[0] += 0.0014759512162587987;
        } else {
          result[0] += 0.00186172414233009;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        result[0] += 0.001746315398015661;
      } else {
        result[0] += 0.0019617098385405936;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7450000000000001066) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05500000000000000722) ) ) {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
            result[0] += -0.003007356965310953;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += -0.003211833467679579;
            } else {
              result[0] += -0.002426949729513157;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.639650859467608468) ) ) {
              result[0] += -0.002493771397644821;
            } else {
              result[0] += -0.0032659685894882145;
            }
          } else {
            result[0] += -0.0015881783675523663;
          }
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7149244603266332598) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.115000000000000005) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)45.50000000000000711) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008486000000000002222) ) ) {
                result[0] += -0.0028739486522449983;
              } else {
                result[0] += -0.0013457596492245276;
              }
            } else {
              result[0] += -0.001800959680486705;
            }
          } else {
            result[0] += -0.0011311678651469948;
          }
        } else {
          result[0] += -0.0026287826155988706;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3850000000000000644) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.29500000000000004) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006229000000000001029) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1650000000000000355) ) ) {
              result[0] += -0.0020757941432832166;
            } else {
              result[0] += -0.0012201679378248244;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
              result[0] += 0.0014637577448951026;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.247314011309283543) ) ) {
                result[0] += -0.0007950141650973331;
              } else {
                result[0] += -0.002281638467997501;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5800027599246232457) ) ) {
            result[0] += -3.267306738214281e-05;
          } else {
            result[0] += -0.0008489012544694047;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.144071500000000019) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5650000000000000577) ) ) {
            result[0] += 7.816945270794988e-05;
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3539353041941689093) ) ) {
              result[0] += 0.0016526239140396343;
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02664459509800340062) ) ) {
                result[0] += 0.00035264185224682845;
              } else {
                result[0] += 0.0010832192785076495;
              }
            }
          }
        } else {
          result[0] += 0.002870896730600099;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9450000000000000622) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8650000000000001021) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02687100000000000252) ) ) {
          result[0] += 0.0010618972963237143;
        } else {
          result[0] += 0.0023206540719233055;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04088342693368870323) ) ) {
          result[0] += 0.0014337232958249416;
        } else {
          result[0] += 0.00180845900857358;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        result[0] += 0.0016963521831969849;
      } else {
        result[0] += 0.0019055840492437175;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7450000000000001066) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05500000000000000722) ) ) {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
            result[0] += -0.00292131453433599;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7586658169597990664) ) ) {
              result[0] += -0.0025645542658503323;
            } else {
              result[0] += -0.0031199408315098253;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.639650859467608468) ) ) {
              result[0] += -0.002422422982466909;
            } else {
              result[0] += -0.0031725271124142147;
            }
          } else {
            result[0] += -0.0015427395556180722;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6413622072216433878) ) ) {
          result[0] += -0.00198978672001827;
        } else {
          result[0] += -0.0025334580919083357;
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5350000000000001421) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.29500000000000004) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003977500000000001) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)90.50000000000001421) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4674830972361809223) ) ) {
                result[0] += -0.0008212709466788404;
              } else {
                result[0] += -0.0024301728693848297;
              }
            } else {
              result[0] += -0.0013341074451378723;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
              result[0] += 0.001412204873040103;
            } else {
              result[0] += -0.0009502153002416154;
            }
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.000726282482777400166) ) ) {
            result[0] += 0.000265729670700996;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.004396500000000000234) ) ) {
              result[0] += -0.0012180809103792237;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.008408953333664601418) ) ) {
                result[0] += -0.0013972496403077178;
              } else {
                result[0] += 7.363673302545804e-05;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.144071500000000019) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01321089953182515153) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9050000000000001377) ) ) {
                result[0] += 6.729007735395293e-05;
              } else {
                result[0] += 0.0010074661183777326;
              }
            } else {
              result[0] += 0.0015744391543021576;
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4750000000000000333) ) ) {
              result[0] += -0.00039616695409996054;
            } else {
              result[0] += 0.0002883868423171733;
            }
          }
        } else {
          result[0] += 0.0027446311179095315;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9450000000000000622) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.875000000000000111) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02687100000000000252) ) ) {
          result[0] += 0.001034387574252076;
        } else {
          result[0] += 0.0022527040869548226;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04088342693368870323) ) ) {
          result[0] += 0.001392703543550387;
        } else {
          result[0] += 0.001756717824799556;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        result[0] += 0.001647818448320965;
      } else {
        result[0] += 0.001851064055137502;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7450000000000001066) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05500000000000000722) ) ) {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
            result[0] += -0.0028377338330504115;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7102898410050252354) ) ) {
                result[0] += -0.0024911807069591756;
              } else {
                result[0] += -0.0030306773031899023;
              }
            } else {
              result[0] += -0.0022841395666571137;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.639650859467608468) ) ) {
              result[0] += -0.0023531158916674892;
            } else {
              result[0] += -0.0030817590565316725;
            }
          } else {
            result[0] += -0.0014986007775289578;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6413622072216433878) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05826200000000000823) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1550000000000000266) ) ) {
              result[0] += -0.002182291139476393;
            } else {
              result[0] += -0.0006057666297521264;
            }
          } else {
            result[0] += 8.727558601991515e-05;
          }
        } else {
          result[0] += -0.0024609742146980873;
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5350000000000001421) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1850000000000000255) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02085144663384500344) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8371684470603016903) ) ) {
              result[0] += -0.0015386947649499935;
            } else {
              result[0] += -0.0029670515493909803;
            }
          } else {
            result[0] += -0.0005537572451399267;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.01704648841990550126) ) ) {
            result[0] += -0.00013280441004865436;
          } else {
            result[0] += -0.0008500646024288802;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.144071500000000019) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01321089953182515153) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9050000000000001377) ) ) {
                result[0] += 6.536486464963772e-05;
              } else {
                result[0] += 0.0009786418600838157;
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)89.50000000000001421) ) ) {
                result[0] += 0.0009555789494804416;
              } else {
                result[0] += 0.002422007228819253;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4750000000000000333) ) ) {
              result[0] += -0.000384832360902049;
            } else {
              result[0] += 0.0002801359079384559;
            }
          }
        } else {
          result[0] += 0.0026661054436252847;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9450000000000000622) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8950000000000001288) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02687100000000000252) ) ) {
          result[0] += 0.0010295285172420019;
        } else {
          result[0] += 0.0021674943077248654;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03945037468542575421) ) ) {
          result[0] += 0.001412454711780337;
        } else {
          result[0] += 0.001759671863556072;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        result[0] += 0.0016006732950404113;
      } else {
        result[0] += 0.00179810391338129;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7450000000000001066) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05500000000000000722) ) ) {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
            result[0] += -0.0027565444297730684;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7102898410050252354) ) ) {
                result[0] += -0.0024199064131200567;
              } else {
                result[0] += -0.0029439676622410632;
              }
            } else {
              result[0] += -0.002218788853965461;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8030059940338053481) ) ) {
              result[0] += -0.0022746423367628163;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003897500000000000357) ) ) {
                result[0] += -0.002707481461818417;
              } else {
                result[0] += -0.002993587933528429;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
              result[0] += 7.907372268652747e-06;
            } else {
              result[0] += -0.0016333735780082223;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6413622072216433878) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05826200000000000823) ) ) {
            result[0] += -0.0020329859934599113;
          } else {
            result[0] += 8.477857496584496e-05;
          }
        } else {
          result[0] += -0.0023905641481706407;
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.5350000000000001421) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1850000000000000255) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00423900000000000058) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
              result[0] += -0.0016918642404499193;
            } else {
              result[0] += -0.003132507410765765;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
              result[0] += 0.0013926252195153243;
            } else {
              result[0] += -0.0009413282094837406;
            }
          }
        } else {
          result[0] += -0.0005476527005589287;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.144071500000000019) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01321089953182515153) ) ) {
              result[0] += 0.0003585430818674895;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)89.50000000000001421) ) ) {
                result[0] += 0.0009282392167017314;
              } else {
                result[0] += 0.0023527120330010228;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.4750000000000000333) ) ) {
              result[0] += -0.0003738220577581981;
            } else {
              result[0] += 0.0002721210381373558;
            }
          }
        } else {
          result[0] += 0.0025898264397520663;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9450000000000000622) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.875000000000000111) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.06679007938737886729) ) ) {
          result[0] += 0.0011093401134544222;
        } else {
          result[0] += 0.0018941161592126881;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04088342693368870323) ) ) {
          result[0] += 0.001312446148654407;
        } else {
          result[0] += 0.0016760844238447598;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        result[0] += 0.0015548769951363385;
      } else {
        result[0] += 0.0017466589955888571;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7450000000000001066) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.04500000000000000527) ) ) {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
            result[0] += -0.0026776779079188385;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6903617355527639221) ) ) {
              result[0] += -0.0021553078674987946;
            } else {
              result[0] += -0.0027275208109188184;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.639650859467608468) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += -0.002220712730841732;
            } else {
              result[0] += -0.0010428367625292519;
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003977500000000001) ) ) {
                result[0] += -0.0026300186632608755;
              } else {
                result[0] += -0.002907939443472488;
              }
            } else {
              result[0] += -0.0018391017193862462;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5623076833668342323) ) ) {
          result[0] += -0.0012155392173487966;
        } else {
          result[0] += -0.0023036961361450215;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3350000000000000755) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1550000000000000266) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01668250000000000288) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
              result[0] += -0.0016849645460243476;
            } else {
              result[0] += -0.0031766499428126276;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02180250462562445188) ) ) {
              result[0] += -0.0008277169216623098;
            } else {
              result[0] += 0.00040532563922556853;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.01704648841990550126) ) ) {
            result[0] += -0.0001963061335052729;
          } else {
            result[0] += -0.000928707926894567;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5550000000000001599) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0224959460313973042) ) ) {
            result[0] += -0.0001568178133456702;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)90.50000000000001421) ) ) {
                result[0] += 0.0003775151824103251;
              } else {
                result[0] += 0.002105748373411845;
              }
            } else {
              result[0] += -0.00041760013306825115;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0159540000000000029) ) ) {
            result[0] += 0.00044247990253966135;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02620539606947270075) ) ) {
              result[0] += 0.0008729262575800051;
            } else {
              result[0] += 0.002175875585118496;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9550000000000000711) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8950000000000001288) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03264450000000000685) ) ) {
          result[0] += 0.0009840954380598344;
        } else {
          result[0] += 0.0020720474570887016;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03358130704046471265) ) ) {
          result[0] += 0.0012625123492593236;
        } else {
          result[0] += 0.0016081577767102547;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        result[0] += 0.0015103909570398455;
      } else {
        result[0] += 0.0016966859502210233;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7450000000000001066) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.04500000000000000527) ) ) {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
            result[0] += -0.0026010678083454187;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7586658169597990664) ) ) {
              result[0] += -0.0022890065686797054;
            } else {
              result[0] += -0.002781702702974181;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.639650859467608468) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
              if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05740595745564833902) ) ) {
                result[0] += -0.0019176773061343867;
              } else {
                result[0] += 0.0019629013077173078;
              }
            } else {
              result[0] += -0.0018985817409703175;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.508252903391186006) ) ) {
              result[0] += -0.0025376205980342645;
            } else {
              result[0] += -0.0031108478839110497;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01369138287730510203) ) ) {
            result[0] += -0.0015857532178611736;
          } else {
            result[0] += 0.00035700998998992764;
          }
        } else {
          result[0] += -0.0022352657968866233;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3850000000000000644) ) ) {
        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1550000000000000266) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01704150000000000456) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
              result[0] += -0.0016367566188248677;
            } else {
              result[0] += -0.0030857639300815734;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02180250462562445188) ) ) {
              result[0] += -0.0007985215819579409;
            } else {
              result[0] += 0.00041915535727372964;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.01704648841990550126) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02937690275817125482) ) ) {
              result[0] += -0.00030326985622270434;
            } else {
              result[0] += 0.0014629336306403193;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
              result[0] += -0.0007749162203179919;
            } else {
              result[0] += -0.001672596382952718;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1645630000000000426) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6150000000000001021) ) ) {
            result[0] += 0.00013288711899098402;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += 0.0012452262814707973;
            } else {
              result[0] += 0.00040152010677294714;
            }
          }
        } else {
          result[0] += 0.002583341616780367;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9650000000000000799) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9050000000000001377) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03264450000000000685) ) ) {
          result[0] += 0.0009855995305542691;
        } else {
          result[0] += 0.002012764837047298;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05403737693237045669) ) ) {
          result[0] += 0.001336635135534215;
        } else {
          result[0] += 0.0016058398604330286;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        result[0] += 0.0015871838385089695;
      } else {
        result[0] += 0.0016481426660542287;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7450000000000001066) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.04500000000000000527) ) ) {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
            result[0] += -0.0025266495733496214;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6903617355527639221) ) ) {
              result[0] += -0.002028153152406175;
            } else {
              result[0] += -0.0025839947128293993;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8030059940338053481) ) ) {
              result[0] += -0.0021028570474809815;
            } else {
              result[0] += -0.0027521384429940116;
            }
          } else {
            result[0] += -0.001358564345306962;
          }
        }
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
          result[0] += -0.0011285199969813186;
        } else {
          result[0] += -0.0021713133944090456;
        }
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3350000000000000755) ) ) {
        if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.29500000000000004) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.003977500000000001) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)72.50000000000001421) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4674830972361809223) ) ) {
                result[0] += -0.0006009212288814407;
              } else {
                result[0] += -0.0023366111857926605;
              }
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.140339474584314505) ) ) {
                result[0] += -0.0010630768010903536;
              } else {
                result[0] += -0.0027817620899018547;
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
              result[0] += 0.001287022970443516;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.247314011309283543) ) ) {
                result[0] += -0.0007108075879866337;
              } else {
                result[0] += -0.002149915903256451;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5800027599246232457) ) ) {
            result[0] += 3.430995286094001e-05;
          } else {
            result[0] += -0.0008033834619457258;
          }
        }
      } else {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5550000000000001599) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0224959460313973042) ) ) {
            result[0] += -0.0001558601739001346;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
              result[0] += 0.0008680622467973626;
            } else {
              result[0] += -0.0004287836102456889;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0159540000000000029) ) ) {
            result[0] += 0.00040869999131001546;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02620539606947270075) ) ) {
              result[0] += 0.0008243940313862208;
            } else {
              result[0] += 0.0020756055175480087;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9650000000000000799) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8950000000000001288) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03264450000000000685) ) ) {
          result[0] += 0.0009277411890187046;
        } else {
          result[0] += 0.001955178331169182;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05403737693237045669) ) ) {
          result[0] += 0.0012884811818385305;
        } else {
          result[0] += 0.0015870053199408033;
        }
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
        result[0] += 0.0015417734806948732;
      } else {
        result[0] += 0.001600988236694296;
      }
    }
  }
}

