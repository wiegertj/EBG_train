
#include "header.h"

void predict_unit13(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
            result[0] += 7.727411400138561e-07;
          } else {
            result[0] += -1.8010574495338334e-05;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5528143519346734314) ) ) {
            result[0] += 2.0401194093924008e-05;
          } else {
            result[0] += 0.0009501021687113638;
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          result[0] += -2.891473185161359e-05;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2070775000000000254) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1129321246270776624) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.568345700351758909) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)9.765598692199240846e-06) ) ) {
                  result[0] += 0.0015530927171228063;
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.006042761789401149275) ) ) {
                    result[0] += 0.0003405435529268158;
                  } else {
                    result[0] += -0.00023553206377635217;
                  }
                }
              } else {
                result[0] += -0.0003994154127328671;
              }
            } else {
              result[0] += -2.3630475297032935e-05;
            }
          } else {
            result[0] += 0.0001474757569860434;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)60.50000000000000711) ) ) {
            result[0] += -2.8371005505479688e-05;
          } else {
            result[0] += -3.0962277065952666e-05;
          }
        } else {
          result[0] += -0.00010385398928917728;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.508252903391186006) ) ) {
          result[0] += 3.520845268729232e-05;
        } else {
          result[0] += -0.0003629297562925171;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 1.8321553590129798e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 1.8321553590129798e-05;
            } else {
              result[0] += 1.8321553590129798e-05;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 1.8321553590129798e-05;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 1.8321553590129798e-05;
              } else {
                result[0] += 1.8321553590129798e-05;
              }
            }
          }
        } else {
          result[0] += -6.140396604393417e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 1.8321553590129798e-05;
            } else {
              result[0] += 1.8321553590129798e-05;
            }
          } else {
            result[0] += 1.8321553590129798e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 1.8321553590129798e-05;
          } else {
            result[0] += 1.8321553590129798e-05;
          }
        }
      } else {
        result[0] += 1.8321553590129798e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          result[0] += 7.506325154082457e-07;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4892818374874372545) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4795364038944723295) ) ) {
                result[0] += 6.264398474266589e-05;
              } else {
                result[0] += -0.0004248253804117138;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.005566725998003100966) ) ) {
                result[0] += -9.181737520070136e-05;
              } else {
                result[0] += 0.0003682377073035208;
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02472850000000000395) ) ) {
              result[0] += 5.060283747844728e-07;
            } else {
              result[0] += -5.560141992191979e-05;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5510720942211057016) ) ) {
            result[0] += -1.749528029158743e-05;
          } else {
            result[0] += -2.8087462642072053e-05;
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5085295226130653878) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
              result[0] += -0.0004773923133942156;
            } else {
              result[0] += -0.00017898173653401554;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02180250462562445188) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9993516786272610419) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7847910031909549611) ) ) {
                    result[0] += -5.340569646742605e-05;
                  } else {
                    result[0] += -0.00030624819746277645;
                  }
                } else {
                  result[0] += 0.00010747866101717847;
                }
              } else {
                result[0] += -3.0174258804816637e-05;
              }
            } else {
              result[0] += 4.2297731946100096e-05;
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
        result[0] += -3.0076426261407605e-05;
      } else {
        result[0] += -4.798750544192055e-05;
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 1.7797362073020504e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 1.7797362073020504e-05;
            } else {
              result[0] += 1.7797362073020504e-05;
            }
          } else {
            result[0] += 1.7797362073020504e-05;
          }
        } else {
          result[0] += -5.964715879724859e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 1.7797362073020504e-05;
            } else {
              result[0] += 1.7797362073020504e-05;
            }
          } else {
            result[0] += 1.7797362073020504e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 1.7797362073020504e-05;
          } else {
            result[0] += 1.7797362073020504e-05;
          }
        }
      } else {
        result[0] += 1.7797362073020504e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          result[0] += 7.29156432874774e-07;
        } else {
          result[0] += 3.07583762607652e-05;
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5510720942211057016) ) ) {
            result[0] += -1.6994728988818848e-05;
          } else {
            result[0] += -2.7283862140529187e-05;
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5085295226130653878) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
              result[0] += -0.0004637338100482543;
            } else {
              result[0] += -0.00017386095310552988;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9079021320180030719) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6690536170100503943) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6665876335678392328) ) ) {
                      result[0] += -1.3626572682840316e-05;
                    } else {
                      result[0] += -0.0013676326607888513;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
                      result[0] += -0.0003712063792933939;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6285027855690678011) ) ) {
                        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)133.5000000000000284) ) ) {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5043717672569237864) ) ) {
                            result[0] += 0.0011468335941492585;
                          } else {
                            result[0] += 0.00012313663000541416;
                          }
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.574132253996512576) ) ) {
                            result[0] += 0.00011819821876379607;
                          } else {
                            result[0] += 0.0025707975762785332;
                          }
                        }
                      } else {
                        result[0] += 3.174710177373127e-05;
                      }
                    }
                  }
                } else {
                  result[0] += -0.0004935992786745976;
                }
              } else {
                result[0] += 0.00019687679258875848;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.130629626450776108e-06) ) ) {
                result[0] += -3.564835049054239e-05;
              } else {
                result[0] += -2.677118401766251e-05;
              }
            }
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
        result[0] += -2.9215920222244028e-05;
      } else {
        result[0] += -4.6614551824417356e-05;
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 1.728816801479486e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            result[0] += 1.728816801479486e-05;
          } else {
            result[0] += 1.728816801479486e-05;
          }
        } else {
          result[0] += -5.79406149438956e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            result[0] += 1.728816801479486e-05;
          } else {
            result[0] += 1.728816801479486e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 1.728816801479486e-05;
          } else {
            result[0] += 1.728816801479486e-05;
          }
        }
      } else {
        result[0] += 1.728816801479486e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
            result[0] += 7.082947949750277e-07;
          } else {
            result[0] += -1.6508498783084888e-05;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5458973873869347182) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.007190624686192600631) ) ) {
                result[0] += -8.954014298485573e-05;
              } else {
                result[0] += 6.191806866275084e-05;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02472850000000000395) ) ) {
                result[0] += 3.678256909516691e-06;
              } else {
                result[0] += -4.2099943969101106e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)53.50000000000000711) ) ) {
              result[0] += 0.0007483861934540481;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.05368089823796016319) ) ) {
                result[0] += 0.00032738120296514454;
              } else {
                result[0] += -0.00021176083323213871;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          result[0] += -2.6503253169916316e-05;
        } else {
          result[0] += -2.5793537110970197e-05;
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)60.50000000000000711) ) ) {
            result[0] += -2.5676065166415087e-05;
          } else {
            result[0] += -2.8380033818305767e-05;
          }
        } else {
          result[0] += -9.899943188539189e-05;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.508252903391186006) ) ) {
          result[0] += 3.5830362056510445e-05;
        } else {
          result[0] += -0.0003498394747126856;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 1.679354232843387e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 1.679354232843387e-05;
            } else {
              result[0] += 1.679354232843387e-05;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 1.679354232843387e-05;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 1.679354232843387e-05;
              } else {
                result[0] += 1.679354232843387e-05;
              }
            }
          }
        } else {
          result[0] += -5.628289641594513e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 1.679354232843387e-05;
            } else {
              result[0] += 1.679354232843387e-05;
            }
          } else {
            result[0] += 1.679354232843387e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 1.679354232843387e-05;
          } else {
            result[0] += 1.679354232843387e-05;
          }
        }
      } else {
        result[0] += 1.679354232843387e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9189305784170854752) ) ) {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          result[0] += 6.880300220499829e-07;
        } else {
          result[0] += 2.9219386001670503e-05;
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5510720942211057016) ) ) {
            result[0] += -1.603617993852201e-05;
          } else {
            result[0] += -2.5744977927639352e-05;
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5085295226130653878) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.02500000000000000486) ) ) {
              result[0] += -0.00044045695132992823;
            } else {
              result[0] += -0.00016849153588811705;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9079021320180030719) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6690536170100503943) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6665876335678392328) ) ) {
                      result[0] += -1.354965237383495e-05;
                    } else {
                      result[0] += -0.0013277658345908164;
                    }
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
                      result[0] += -0.0003598479545043511;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6285027855690678011) ) ) {
                        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6010141514957837439) ) ) {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5043717672569237864) ) ) {
                            result[0] += 0.0009604970996854742;
                          } else {
                            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7080301875628142172) ) ) {
                              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0416553728637082607) ) ) {
                                result[0] += -0.00043303670128877166;
                              } else {
                                result[0] += 0.00029192844450783186;
                              }
                            } else {
                              result[0] += 0.0014890419521357847;
                            }
                          }
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.606193063154585432) ) ) {
                            result[0] += 0.003635099597008977;
                          } else {
                            result[0] += 0.0006517644240179808;
                          }
                        }
                      } else {
                        result[0] += 3.15767664319471e-05;
                      }
                    }
                  }
                } else {
                  result[0] += -0.0004787391137468527;
                }
              } else {
                result[0] += 0.0001963760966496477;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.130629626450776108e-06) ) ) {
                result[0] += -3.253215799350989e-05;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001440500000000000157) ) ) {
                  result[0] += 8.255898950035433e-05;
                } else {
                  result[0] += -0.00014517853416989052;
                }
              }
            }
          }
        }
      }
    } else {
      result[0] += -2.756806266588017e-05;
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 1.6313068203384758e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          result[0] += 1.6313068203384758e-05;
        } else {
          result[0] += -5.467260628868242e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            result[0] += 1.6313068203384758e-05;
          } else {
            result[0] += 1.6313068203384758e-05;
          }
        } else {
          result[0] += 1.6313068203384758e-05;
        }
      } else {
        result[0] += 1.6313068203384758e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9189305784170854752) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
          result[0] += 6.683450374060745e-07;
        } else {
          result[0] += -2.5008397431262594e-05;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.242456489623170593e-05) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)46.50000000000000711) ) ) {
              result[0] += -3.8264452601196726e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
                result[0] += -3.591906546652903e-05;
              } else {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8789704397738694608) ) ) {
                  result[0] += -2.654829404500563e-05;
                } else {
                  result[0] += -2.5742686160639753e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.508252903391186006) ) ) {
              result[0] += 1.6514531443867028e-06;
            } else {
              result[0] += -0.00029938830663307157;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.163639685692610809) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2575587311557789305) ) ) {
                result[0] += 0.0006582698928460935;
              } else {
                result[0] += 2.6198633557660255e-05;
              }
            } else {
              result[0] += 0.0002246103123341074;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01504150000000000105) ) ) {
              result[0] += 1.876739957025094e-05;
            } else {
              result[0] += -4.248089574426049e-05;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -2.6779322534128907e-05;
      } else {
        result[0] += -0.0003149109245002052;
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 1.5846340754309278e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 1.5846340754309278e-05;
            } else {
              result[0] += 1.5846340754309278e-05;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 1.5846340754309278e-05;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 1.5846340754309278e-05;
              } else {
                result[0] += 1.5846340754309278e-05;
              }
            }
          }
        } else {
          result[0] += -5.310838760533256e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 1.5846340754309278e-05;
            } else {
              result[0] += 1.5846340754309278e-05;
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.6250640499379888082) ) ) {
              result[0] += 1.5846340754309278e-05;
            } else {
              result[0] += 1.5846340754309278e-05;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 1.5846340754309278e-05;
          } else {
            result[0] += 1.5846340754309278e-05;
          }
        }
      } else {
        result[0] += 1.5846340754309278e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9189305784170854752) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
          result[0] += 6.492232529249727e-07;
        } else {
          result[0] += -2.4292890980051735e-05;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.242456489623170593e-05) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)46.50000000000000711) ) ) {
              result[0] += -3.716968182416235e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
                result[0] += -3.489139773478391e-05;
              } else {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8789704397738694608) ) ) {
                  result[0] += -2.5788730154114407e-05;
                } else {
                  result[0] += -2.500617123320148e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.508252903391186006) ) ) {
              result[0] += 1.6042040000971144e-06;
            } else {
              result[0] += -0.000290822613233411;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
            result[0] += 2.651466767626965e-05;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0159540000000000029) ) ) {
              result[0] += 2.7506696750712143e-05;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)40.50000000000000711) ) ) {
                result[0] += -1.4046545010476656e-05;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.04446937286580055632) ) ) {
                  result[0] += -4.659079687825452e-05;
                } else {
                  result[0] += -4.8685747665705124e-05;
                }
              }
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -2.6013148768501183e-05;
      } else {
        result[0] += -0.0003059011189476513;
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 1.5392966679901265e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 1.5392966679901265e-05;
            } else {
              result[0] += 1.5392966679901265e-05;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 1.5392966679901265e-05;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 1.5392966679901265e-05;
              } else {
                result[0] += 1.5392966679901265e-05;
              }
            }
          }
        } else {
          result[0] += -5.158892223164348e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 1.5392966679901265e-05;
            } else {
              result[0] += 1.5392966679901265e-05;
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.6250640499379888082) ) ) {
              result[0] += 1.5392966679901265e-05;
            } else {
              result[0] += 1.5392966679901265e-05;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 1.5392966679901265e-05;
          } else {
            result[0] += 1.5392966679901265e-05;
          }
        }
      } else {
        result[0] += 1.5392966679901265e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9189305784170854752) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
          result[0] += 6.3064855508515e-07;
        } else {
          result[0] += -2.3597855631922608e-05;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.242456489623170593e-05) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)46.50000000000000711) ) ) {
              result[0] += -3.610623314826294e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
                result[0] += -3.389313224257797e-05;
              } else {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8789704397738694608) ) ) {
                  result[0] += -2.5050897878195045e-05;
                } else {
                  result[0] += -2.4290728474959323e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.508252903391186006) ) ) {
              result[0] += 1.5583066844341494e-06;
            } else {
              result[0] += -0.000282501989870861;
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.163639685692610809) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2575587311557789305) ) ) {
                result[0] += 0.0006386777629589212;
              } else {
                result[0] += 2.469047186112815e-05;
              }
            } else {
              result[0] += 0.0002174254639746129;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01504150000000000105) ) ) {
              result[0] += 1.7457658994896056e-05;
            } else {
              result[0] += -4.029115143853206e-05;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -2.526889573064348e-05;
      } else {
        result[0] += -0.0002971490897686028;
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 1.4952563931465322e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 1.4952563931465322e-05;
            } else {
              result[0] += 1.4952563931465322e-05;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 1.4952563931465322e-05;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 1.4952563931465322e-05;
              } else {
                result[0] += 1.4952563931465322e-05;
              }
            }
          }
        } else {
          result[0] += -5.011292974668002e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 1.4952563931465322e-05;
            } else {
              result[0] += 1.4952563931465322e-05;
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.6250640499379888082) ) ) {
              result[0] += 1.4952563931465322e-05;
            } else {
              result[0] += 1.4952563931465322e-05;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 1.4952563931465322e-05;
          } else {
            result[0] += 1.4952563931465322e-05;
          }
        }
      } else {
        result[0] += 1.4952563931465322e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
            result[0] += 6.126052913834312e-07;
          } else {
            result[0] += -1.349168270616725e-05;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5458973873869347182) ) ) {
            result[0] += 5.296723360758699e-06;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)43.50000000000000711) ) ) {
              result[0] += 0.0007626433116440164;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.05368089823796016319) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
                  result[0] += 0.0008573290231056559;
                } else {
                  result[0] += -5.9605820013362784e-05;
                }
              } else {
                result[0] += -0.0001675321816849548;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          result[0] += -2.2922705695354656e-05;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2070775000000000254) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1129321246270776624) ) ) {
              result[0] += -0.00018954096271152368;
            } else {
              result[0] += -1.8658333046954503e-05;
            }
          } else {
            result[0] += 0.0001429757141967097;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)60.50000000000000711) ) ) {
            result[0] += -2.0819448020609037e-05;
          } else {
            result[0] += -2.4545936254333816e-05;
          }
        } else {
          result[0] += -8.811869854029666e-05;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.508252903391186006) ) ) {
          result[0] += 3.600976807548189e-05;
        } else {
          result[0] += -0.00033236012687263227;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 1.4524761390958076e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 1.4524761390958076e-05;
            } else {
              result[0] += 1.4524761390958076e-05;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 1.4524761390958076e-05;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 1.4524761390958076e-05;
              } else {
                result[0] += 1.4524761390958076e-05;
              }
            }
          }
        } else {
          result[0] += -4.867916636284125e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 1.4524761390958076e-05;
            } else {
              result[0] += 1.4524761390958076e-05;
            }
          } else {
            result[0] += 1.4524761390958076e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 1.4524761390958076e-05;
          } else {
            result[0] += 1.4524761390958076e-05;
          }
        }
      } else {
        result[0] += 1.4524761390958076e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
            result[0] += 5.950782571448093e-07;
          } else {
            result[0] += -1.3105676923890111e-05;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5458973873869347182) ) ) {
            result[0] += 5.145180674133102e-06;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)31.50000000000000355) ) ) {
              result[0] += 0.0009179220805887703;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.05368089823796016319) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
                  result[0] += 0.000833149447098039;
                } else {
                  result[0] += -4.794734174971154e-05;
                }
              } else {
                result[0] += -0.00018119845775695076;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          result[0] += -2.226687223584115e-05;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2070775000000000254) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1129321246270776624) ) ) {
              result[0] += -0.00018411807298172157;
            } else {
              result[0] += -1.812450605141785e-05;
            }
          } else {
            result[0] += 0.000138885086392372;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)60.50000000000000711) ) ) {
            result[0] += -2.02237901256824e-05;
          } else {
            result[0] += -2.3843661116982114e-05;
          }
        } else {
          result[0] += -8.559756549084075e-05;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.508252903391186006) ) ) {
          result[0] += 3.4979505283336525e-05;
        } else {
          result[0] += -0.00032285108833642675;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 1.4109198558269612e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 1.4109198558269612e-05;
            } else {
              result[0] += 1.4109198558269612e-05;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 1.4109198558269612e-05;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 1.4109198558269612e-05;
              } else {
                result[0] += 1.4109198558269612e-05;
              }
            }
          }
        } else {
          result[0] += -4.7286423878277013e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 1.4109198558269612e-05;
            } else {
              result[0] += 1.4109198558269612e-05;
            }
          } else {
            result[0] += 1.4109198558269612e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 1.4109198558269612e-05;
          } else {
            result[0] += 1.4109198558269612e-05;
          }
        }
      } else {
        result[0] += 1.4109198558269612e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
            result[0] += 5.780526827099589e-07;
          } else {
            result[0] += -1.2730715017102523e-05;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5458973873869347182) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2203770052010050329) ) ) {
              result[0] += 0.0005612798958477087;
            } else {
              result[0] += 5.779894816729981e-07;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)31.50000000000000355) ) ) {
              result[0] += 0.0008916597352235652;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.05368089823796016319) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
                  result[0] += 0.0008093125016936061;
                } else {
                  result[0] += -4.657553724146349e-05;
                }
              } else {
                result[0] += -0.00017601425249825988;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          result[0] += -2.162980259646013e-05;
        } else {
          result[0] += -2.1174155767650075e-05;
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)60.50000000000000711) ) ) {
            result[0] += -1.9645174389003054e-05;
          } else {
            result[0] += -2.316147852625125e-05;
          }
        } else {
          result[0] += -8.314856369114617e-05;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.508252903391186006) ) ) {
          result[0] += 3.397871897708949e-05;
        } else {
          result[0] += -0.0003136141095527967;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 1.3705525247430683e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 1.3705525247430683e-05;
            } else {
              result[0] += 1.3705525247430683e-05;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 1.3705525247430683e-05;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 1.3705525247430683e-05;
              } else {
                result[0] += 1.3705525247430683e-05;
              }
            }
          }
        } else {
          result[0] += -4.593352865852779e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 1.3705525247430683e-05;
            } else {
              result[0] += 1.3705525247430683e-05;
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.6250640499379888082) ) ) {
              result[0] += 1.3705525247430683e-05;
            } else {
              result[0] += 1.3705525247430683e-05;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 1.3705525247430683e-05;
          } else {
            result[0] += 1.3705525247430683e-05;
          }
        }
      } else {
        result[0] += 1.3705525247430683e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9189305784170854752) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
          result[0] += 5.615142209890298e-07;
        } else {
          result[0] += -2.1010959932162188e-05;
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.007692735115326951138) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01067850000000000223) ) ) {
            result[0] += -2.2287052828697653e-05;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6750000000000001554) ) ) {
              result[0] += -0.0004773285954715485;
            } else {
              result[0] += 4.4939256677966673e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9750000000000000888) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7150000000000000799) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
                result[0] += -0.00014191195892118564;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.828053558455352334) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08030541277720280868) ) ) {
                    result[0] += 0.00012300434866222503;
                  } else {
                    result[0] += 0.0008823709006926969;
                  }
                } else {
                  result[0] += -0.00035151940111899675;
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07149150000000001337) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6690536170100503943) ) ) {
                  result[0] += 0.0002689425670658781;
                } else {
                  result[0] += 0.0005960382152761569;
                }
              } else {
                result[0] += -2.4498446666975672e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008311500000000001179) ) ) {
              result[0] += 3.761013114881349e-05;
            } else {
              result[0] += -3.8590101185686466e-05;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -2.249881362136624e-05;
      } else {
        result[0] += -0.0002916506640741216;
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 1.3313401291520104e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 1.3313401291520104e-05;
            } else {
              result[0] += 1.3313401291520104e-05;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 1.3313401291520104e-05;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 1.3313401291520104e-05;
              } else {
                result[0] += 1.3313401291520104e-05;
              }
            }
          }
        } else {
          result[0] += -4.461934064738746e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 1.3313401291520104e-05;
            } else {
              result[0] += 1.3313401291520104e-05;
            }
          } else {
            result[0] += 1.3313401291520104e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 1.3313401291520104e-05;
          } else {
            result[0] += 1.3313401291520104e-05;
          }
        }
      } else {
        result[0] += 1.3313401291520104e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9189305784170854752) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
          result[0] += 5.454489353717462e-07;
        } else {
          result[0] += -2.0409822757382607e-05;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.242456489623170593e-05) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1850000000000000255) ) ) {
                result[0] += -4.0545296313021394e-05;
              } else {
                result[0] += -0.002406248504788707;
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)125.5000000000000142) ) ) {
                result[0] += -2.084379792511592e-05;
              } else {
                result[0] += 3.918688636319734e-05;
              }
            }
          } else {
            result[0] += -1.2962098984885418e-05;
          }
        } else {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
            result[0] += 0.0002851280262648394;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.007016451597998800589) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8250000000000000666) ) ) {
                result[0] += -0.00038327561378221156;
              } else {
                result[0] += 8.663808964133286e-06;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9750000000000000888) ) ) {
                result[0] += 0.00011241381527692224;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008311500000000001179) ) ) {
                  result[0] += 3.865602086120991e-05;
                } else {
                  result[0] += -3.724146658861068e-05;
                }
              }
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -2.1855107988691272e-05;
      } else {
        result[0] += -0.000283306349640599;
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 1.293249625600873e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 1.293249625600873e-05;
            } else {
              result[0] += 1.293249625600873e-05;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 1.293249625600873e-05;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 1.293249625600873e-05;
              } else {
                result[0] += 1.293249625600873e-05;
              }
            }
          }
        } else {
          result[0] += -4.3342752406671544e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 1.293249625600873e-05;
            } else {
              result[0] += 1.293249625600873e-05;
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.6250640499379888082) ) ) {
              result[0] += 1.293249625600873e-05;
            } else {
              result[0] += 1.293249625600873e-05;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 1.293249625600873e-05;
          } else {
            result[0] += 1.293249625600873e-05;
          }
        }
      } else {
        result[0] += 1.293249625600873e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9189305784170854752) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
          result[0] += 5.298432879832383e-07;
        } else {
          result[0] += -1.982588450659644e-05;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2750000000000000777) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.676837902221867901e-06) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)3.479305098792485241e-06) ) ) {
              result[0] += -2.7926565234817634e-05;
            } else {
              result[0] += -4.946854821204544e-05;
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)109.5000000000000142) ) ) {
              result[0] += -3.752631948390085e-05;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0008742997306644500989) ) ) {
                result[0] += 0.00032690379379457084;
              } else {
                result[0] += -6.789879214840565e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.650000000000000541e-05) ) ) {
            result[0] += 0.0005077341066452848;
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001999500000000000409) ) ) {
              result[0] += -0.00012872792295014174;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9750000000000000888) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7150000000000000799) ) ) {
                  result[0] += 7.309339074050613e-05;
                } else {
                  result[0] += 0.00022735488135123413;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008311500000000001179) ) ) {
                  result[0] += 4.707137460880584e-05;
                } else {
                  result[0] += -3.6683024884020796e-05;
                }
              }
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -2.12298191911664e-05;
      } else {
        result[0] += -0.00027520077144855393;
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 1.2562489160317665e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 1.2562489160317665e-05;
            } else {
              result[0] += 1.2562489160317665e-05;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 1.2562489160317665e-05;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 1.2562489160317665e-05;
              } else {
                result[0] += 1.2562489160317665e-05;
              }
            }
          }
        } else {
          result[0] += -4.210268818234972e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 1.2562489160317665e-05;
            } else {
              result[0] += 1.2562489160317665e-05;
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.6250640499379888082) ) ) {
              result[0] += 1.2562489160317665e-05;
            } else {
              result[0] += 1.2562489160317665e-05;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 1.2562489160317665e-05;
          } else {
            result[0] += 1.2562489160317665e-05;
          }
        }
      } else {
        result[0] += 1.2562489160317665e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9189305784170854752) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
          result[0] += 5.1468412827598e-07;
        } else {
          result[0] += -1.92586531074466e-05;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.242456489623170593e-05) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
              result[0] += -4.0145863829940815e-05;
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)125.5000000000000142) ) ) {
                result[0] += -1.88321161530557e-05;
              } else {
                result[0] += 3.8864721281160144e-05;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.828053558455352334) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.895681724436047322) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02500000000000000486) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05500000000000000722) ) ) {
                      result[0] += 3.0509133796287823e-05;
                    } else {
                      result[0] += 0.0015403467657844618;
                    }
                  } else {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7965276202010050932) ) ) {
                      result[0] += -0.0001945770062131492;
                    } else {
                      result[0] += 0.000495920137490661;
                    }
                  }
                } else {
                  result[0] += -0.0001606491496678207;
                }
              } else {
                result[0] += 5.519966857888395e-05;
              }
            } else {
              result[0] += -0.0003400176969757041;
            }
          }
        } else {
          result[0] += 1.234852982197935e-05;
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -2.0622420311207368e-05;
      } else {
        result[0] += -0.00026732709909946196;
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 1.2203068207327034e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 1.2203068207327034e-05;
            } else {
              result[0] += 1.2203068207327034e-05;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 1.2203068207327034e-05;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 1.2203068207327034e-05;
              } else {
                result[0] += 1.2203068207327034e-05;
              }
            }
          }
        } else {
          result[0] += -4.0898102998948507e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 1.2203068207327034e-05;
            } else {
              result[0] += 1.2203068207327034e-05;
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.6250640499379888082) ) ) {
              result[0] += 1.2203068207327034e-05;
            } else {
              result[0] += 1.2203068207327034e-05;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 1.2203068207327034e-05;
          } else {
            result[0] += 1.2203068207327034e-05;
          }
        }
      } else {
        result[0] += 1.2203068207327034e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9189305784170854752) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
          result[0] += 4.999586819482026e-07;
        } else {
          result[0] += -1.870765056608489e-05;
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.00933301618409165118) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9993516786272610419) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7102898410050252354) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6010141514957837439) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6918289147989949983) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5423446055643508235) ) ) {
                      result[0] += -6.230599929916124e-05;
                    } else {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.750591121697756835e-06) ) ) {
                        result[0] += -0.0011014699197511434;
                      } else {
                        result[0] += -0.00042910112476485425;
                      }
                    }
                  } else {
                    result[0] += 0.0013845712053778862;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.606193063154585432) ) ) {
                    result[0] += 0.0031037466733073917;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.714286561348693172) ) ) {
                      result[0] += 0.0005944886791123412;
                    } else {
                      result[0] += -0.00030042767396717653;
                    }
                  }
                }
              } else {
                result[0] += -8.727123724986458e-05;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.003192522685141000512) ) ) {
                result[0] += 3.993267627998788e-05;
              } else {
                result[0] += 0.0007703021453532676;
              }
            }
          } else {
            result[0] += -2.0429805444680123e-05;
          }
        } else {
          result[0] += 1.7718829564121578e-05;
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -2.0032399506683334e-05;
      } else {
        result[0] += -0.0002596786976169253;
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 1.1853930520638398e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 1.1853930520638398e-05;
            } else {
              result[0] += 1.1853930520638398e-05;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 1.1853930520638398e-05;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 1.1853930520638398e-05;
              } else {
                result[0] += 1.1853930520638398e-05;
              }
            }
          }
        } else {
          result[0] += -3.9727981777777037e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 1.1853930520638398e-05;
            } else {
              result[0] += 1.1853930520638398e-05;
            }
          } else {
            result[0] += 1.1853930520638398e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 1.1853930520638398e-05;
          } else {
            result[0] += 1.1853930520638398e-05;
          }
        }
      } else {
        result[0] += 1.1853930520638398e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9189305784170854752) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
          result[0] += 4.856545401792055e-07;
        } else {
          result[0] += -1.8172412564376743e-05;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2750000000000000777) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.676837902221867901e-06) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)3.479305098792485241e-06) ) ) {
              result[0] += -2.5023083465604844e-05;
            } else {
              result[0] += -4.8047121567544635e-05;
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)109.5000000000000142) ) ) {
              result[0] += -3.573699092062938e-05;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0008742997306644500989) ) ) {
                result[0] += 0.0003204820786559146;
              } else {
                result[0] += -4.5704088942513864e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.650000000000000541e-05) ) ) {
            result[0] += 0.0004939679640956696;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.002612771187363900714) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4589535259190716254) ) ) {
                if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.5412335719706470316) ) ) {
                  result[0] += -0.0003529320387989624;
                } else {
                  result[0] += 0.0006139776788239651;
                }
              } else {
                result[0] += -0.00044676451875139866;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
                result[0] += 3.451874968290019e-05;
              } else {
                result[0] += -1.7237721332454855e-05;
              }
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -1.9459259579598404e-05;
      } else {
        result[0] += -0.00025224912185551804;
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 1.1514781889343068e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 1.1514781889343068e-05;
            } else {
              result[0] += 1.1514781889343068e-05;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 1.1514781889343068e-05;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 1.1514781889343068e-05;
              } else {
                result[0] += 1.1514781889343068e-05;
              }
            }
          }
        } else {
          result[0] += -3.8591338482787755e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 1.1514781889343068e-05;
            } else {
              result[0] += 1.1514781889343068e-05;
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.6250640499379888082) ) ) {
              result[0] += 1.1514781889343068e-05;
            } else {
              result[0] += 1.1514781889343068e-05;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 1.1514781889343068e-05;
          } else {
            result[0] += 1.1514781889343068e-05;
          }
        }
      } else {
        result[0] += 1.1514781889343068e-05;
      }
    }
  }
}

