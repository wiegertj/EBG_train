
#include "header.h"

void predict_unit13(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -1.8700347670719068e-05;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006937836693866150477) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01063150000000000206) ) ) {
              result[0] += -1.9798707398844857e-05;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002339521674937150662) ) ) {
                result[0] += 0.0004355116875684936;
              } else {
                result[0] += -0.00026937386003589374;
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0006235000000000000308) ) ) {
              result[0] += -0.0003498389440296451;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7425707671105529206) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9112103514676580529) ) ) {
                  result[0] += 2.2693732092764677e-05;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7114754460552764614) ) ) {
                    result[0] += -8.873647274374066e-05;
                  } else {
                    result[0] += 0.0017991340229721862;
                  }
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8022705390703518402) ) ) {
                  result[0] += -0.00024796112596594394;
                } else {
                  result[0] += 0.00013195179899073525;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6732382808793971884) ) ) {
            result[0] += -0.0001390839379891133;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.96280210579579717) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -2.0162467824206702e-05;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                  result[0] += 0.0012361988485499516;
                } else {
                  result[0] += -0.0004168189690321757;
                }
              }
            } else {
              result[0] += 1.1472483218633574e-05;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 1.6794858487393838e-06;
        } else {
          result[0] += 4.563953615843796e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 1.246030664865543e-05;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 1.246030664865543e-05;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 1.246030664865543e-05;
            } else {
              result[0] += 1.246030664865543e-05;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 1.220302996599059e-05;
          } else {
            result[0] += -6.756600822516657e-06;
          }
        } else {
          result[0] += 1.246030664865543e-05;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 1.246030664865543e-05;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              result[0] += 1.246030664865543e-05;
            } else {
              result[0] += 1.246030664865543e-05;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 1.246030664865543e-05;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 1.246030664865543e-05;
              } else {
                result[0] += 1.246030664865543e-05;
              }
            }
          }
        }
      } else {
        result[0] += 1.246030664865543e-05;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -1.803711874660767e-05;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9750000000000000888) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01332150000000000174) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8254037945979900703) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8158067323869347964) ) ) {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.146109394227906586) ) ) {
                    result[0] += 0.0009111130547535683;
                  } else {
                    result[0] += -2.1893029446683053e-05;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002769500000000000694) ) ) {
                    result[0] += 0.0002577447385662058;
                  } else {
                    result[0] += 0.0032027527320726817;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  result[0] += -2.0418142767234304e-05;
                } else {
                  result[0] += -0.00031134903401186607;
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01000276686157755036) ) ) {
                result[0] += -0.00021412014443287307;
              } else {
                result[0] += 9.896384563467423e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              result[0] += -7.181599995843584e-05;
            } else {
              result[0] += -6.942653225927761e-06;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6732382808793971884) ) ) {
            result[0] += -0.000134151169241817;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.96280210579579717) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -1.94473831595821e-05;
              } else {
                result[0] += -0.00016309866988480556;
              }
            } else {
              result[0] += 1.1065598660337657e-05;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 1.6199209886558528e-06;
        } else {
          result[0] += 4.402087852723784e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 1.2018387818148642e-05;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 1.2018387818148642e-05;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 1.2018387818148642e-05;
            } else {
              result[0] += 1.2018387818148642e-05;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 1.1770235743244811e-05;
          } else {
            result[0] += -6.516970352909225e-06;
          }
        } else {
          result[0] += 1.2018387818148642e-05;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 1.2018387818148642e-05;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              result[0] += 1.2018387818148642e-05;
            } else {
              result[0] += 1.2018387818148642e-05;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 1.2018387818148642e-05;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 1.2018387818148642e-05;
              } else {
                result[0] += 1.2018387818148642e-05;
              }
            }
          }
        }
      } else {
        result[0] += 1.2018387818148642e-05;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -1.7397411984411263e-05;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4550000000000000711) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.421180086331658321) ) ) {
              result[0] += 0.0004535508844402608;
            } else {
              result[0] += -2.1723130581437094e-05;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9750000000000000888) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                result[0] += 5.8583564067017614e-05;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7894192122613066243) ) ) {
                  result[0] += -0.0011596810012698062;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1469960000000000155) ) ) {
                    result[0] += -0.00024940331738016526;
                  } else {
                    result[0] += 0.0005282086171913938;
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01218550000000000189) ) ) {
                result[0] += 1.1711938046404206e-05;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
                  result[0] += -7.277916452098607e-05;
                } else {
                  result[0] += -1.4290944959006567e-05;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6732382808793971884) ) ) {
            result[0] += -0.00012939334670230068;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.96280210579579717) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -1.875765977920304e-05;
              } else {
                result[0] += -0.00015731419158224066;
              }
            } else {
              result[0] += 1.0673144721866992e-05;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 1.5624686635242738e-06;
        } else {
          result[0] += 4.245962841477206e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 1.159214213745048e-05;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 1.159214213745048e-05;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 1.159214213745048e-05;
            } else {
              result[0] += 1.159214213745048e-05;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 1.1352791055797815e-05;
          } else {
            result[0] += -6.28583864820827e-06;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            result[0] += 1.159214213745048e-05;
          } else {
            result[0] += 1.159214213745048e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 1.159214213745048e-05;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              result[0] += 1.159214213745048e-05;
            } else {
              result[0] += 1.159214213745048e-05;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 1.159214213745048e-05;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 1.159214213745048e-05;
              } else {
                result[0] += 1.159214213745048e-05;
              }
            }
          }
        }
      } else {
        result[0] += 1.159214213745048e-05;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -1.6780393144124642e-05;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1450000000000000455) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  result[0] += -1.6787889458117084e-05;
                } else {
                  result[0] += 0.00021801731773056282;
                }
              } else {
                result[0] += -0.0002656332189678868;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6732382808793971884) ) ) {
                result[0] += -0.00012480426570596635;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                    result[0] += -1.8481127368255203e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8480072969597991506) ) ) {
                      result[0] += 0.0003944558271087758;
                    } else {
                      result[0] += -0.00048373061938969473;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                    result[0] += 2.851467235542601e-05;
                  } else {
                    result[0] += -8.141286003481397e-05;
                  }
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9750000000000000888) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.143279903388985774) ) ) {
                result[0] += 0.0006440505395588051;
              } else {
                result[0] += 2.298301445215343e-05;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
                result[0] += -6.668776934700478e-05;
              } else {
                result[0] += -7.706974270900218e-06;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -1.8092398216516252e-05;
          } else {
            result[0] += -0.0003557837405179556;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 1.507053949909639e-06;
        } else {
          result[0] += 4.095374979863311e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 1.1181013740624771e-05;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 1.1181013740624771e-05;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 1.1181013740624771e-05;
            } else {
              result[0] += 1.1181013740624771e-05;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 1.095015151506953e-05;
          } else {
            result[0] += -6.062904290129518e-06;
          }
        } else {
          result[0] += 1.1181013740624771e-05;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 1.1181013740624771e-05;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              result[0] += 1.1181013740624771e-05;
            } else {
              result[0] += 1.1181013740624771e-05;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 1.1181013740624771e-05;
            } else {
              result[0] += 1.1181013740624771e-05;
            }
          }
        }
      } else {
        result[0] += 1.1181013740624771e-05;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -1.618525757300528e-05;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8643464628140704598) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006937836693866150477) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01063150000000000206) ) ) {
                    result[0] += -1.9560925942156864e-05;
                  } else {
                    result[0] += -0.0003487122763833293;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8158067323869347964) ) ) {
                    result[0] += 8.710495125036678e-06;
                  } else {
                    result[0] += 0.0004682157534360881;
                  }
                }
              } else {
                result[0] += -0.0001523380833317841;
              }
            } else {
              result[0] += 0.0006938571456819816;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
              result[0] += -0.00012037794164364478;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                    result[0] += -1.78256733394509e-05;
                  } else {
                    result[0] += -1.8125086884083648e-05;
                  }
                } else {
                  result[0] += 5.764851809677115e-05;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
                  result[0] += 2.629277935944451e-05;
                } else {
                  result[0] += -0.0009797827724570723;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -1.7450730905564385e-05;
          } else {
            result[0] += -0.00034316546883686016;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 1.4536045816210763e-06;
        } else {
          result[0] += 3.950127886624477e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 1.0784466476142882e-05;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 1.0784466476142882e-05;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 1.0784466476142882e-05;
            } else {
              result[0] += 1.0784466476142882e-05;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 1.0561792039829389e-05;
          } else {
            result[0] += -5.847876550529936e-06;
          }
        } else {
          result[0] += 1.0784466476142882e-05;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 1.0784466476142882e-05;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              result[0] += 1.0784466476142882e-05;
            } else {
              result[0] += 1.0784466476142882e-05;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 1.0784466476142882e-05;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 1.0784466476142882e-05;
              } else {
                result[0] += 1.0784466476142882e-05;
              }
            }
          }
        }
      } else {
        result[0] += 1.0784466476142882e-05;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -1.5611229156227868e-05;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8643464628140704598) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006937836693866150477) ) ) {
                  result[0] += -2.129130077681454e-05;
                } else {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0006235000000000000308) ) ) {
                    result[0] += -0.0004853864858998498;
                  } else {
                    result[0] += 2.092650048968814e-05;
                  }
                }
              } else {
                result[0] += -0.0001469352413692503;
              }
            } else {
              result[0] += 0.0006692487193403562;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
              result[0] += -0.00011610860215708157;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                    result[0] += -1.7193465727129492e-05;
                  } else {
                    result[0] += -1.7482260232663726e-05;
                  }
                } else {
                  result[0] += 5.5603948375011324e-05;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
                  result[0] += 2.5360276281238763e-05;
                } else {
                  result[0] += -0.0009450336712381095;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -1.683182104959537e-05;
          } else {
            result[0] += -0.00033099471839433147;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 1.4020508554696897e-06;
        } else {
          result[0] += 3.810032145385902e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 1.0401983207700237e-05;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 1.0401983207700237e-05;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 1.0401983207700237e-05;
            } else {
              result[0] += 1.0401983207700237e-05;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 1.0187206171447832e-05;
          } else {
            result[0] += -5.640475012266794e-06;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            result[0] += 1.0401983207700237e-05;
          } else {
            result[0] += 1.0401983207700237e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 1.0401983207700237e-05;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              result[0] += 1.0401983207700237e-05;
            } else {
              result[0] += 1.0401983207700237e-05;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 1.0401983207700237e-05;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 1.0401983207700237e-05;
              } else {
                result[0] += 1.0401983207700237e-05;
              }
            }
          }
        }
      } else {
        result[0] += 1.0401983207700237e-05;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -1.5057559304754815e-05;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8643464628140704598) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006937836693866150477) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01063150000000000206) ) ) {
                    result[0] += -1.81120556403064e-05;
                  } else {
                    result[0] += -0.0003355896821557605;
                  }
                } else {
                  result[0] += 1.5759894941074697e-05;
                }
              } else {
                result[0] += -0.00014172401729131676;
              }
            } else {
              result[0] += 0.0006455130585972113;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
              result[0] += -0.00011199067961121907;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                    result[0] += -1.6583680070908476e-05;
                  } else {
                    result[0] += -1.686223215354409e-05;
                  }
                } else {
                  result[0] += 5.363189162470571e-05;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
                  result[0] += 2.446084547656392e-05;
                } else {
                  result[0] += -0.0009115169860908218;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -1.6234861529797857e-05;
          } else {
            result[0] += -0.0003192556173448384;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 1.3523255403688024e-06;
        } else {
          result[0] += 3.6749050576381785e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 1.0033065139815668e-05;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 1.0033065139815668e-05;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 1.0033065139815668e-05;
            } else {
              result[0] += 1.0033065139815668e-05;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 9.825905413422708e-06;
          } else {
            result[0] += -5.440429203507325e-06;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            result[0] += 1.0033065139815668e-05;
          } else {
            result[0] += 1.0033065139815668e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 1.0033065139815668e-05;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              result[0] += 1.0033065139815668e-05;
            } else {
              result[0] += 1.0033065139815668e-05;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 1.0033065139815668e-05;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 1.0033065139815668e-05;
              } else {
                result[0] += 1.0033065139815668e-05;
              }
            }
          }
        }
      } else {
        result[0] += 1.0033065139815668e-05;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -1.452352597910318e-05;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8643464628140704598) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
                result[0] += -2.0910397642330795e-06;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01218550000000000189) ) ) {
                  result[0] += 1.908442820784985e-05;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07954367714673930834) ) ) {
                    result[0] += -4.1015829756911204e-05;
                  } else {
                    result[0] += -2.7122052507566988e-05;
                  }
                }
              }
            } else {
              result[0] += 0.0006226192098361186;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
              result[0] += -0.00010801880383345719;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                    result[0] += -1.5995521150822816e-05;
                  } else {
                    result[0] += -1.6264194069641348e-05;
                  }
                } else {
                  result[0] += 5.1729776091528024e-05;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
                  result[0] += 2.359331399993372e-05;
                } else {
                  result[0] += -0.0008791890079890623;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -1.5659073852739574e-05;
          } else {
            result[0] += -0.000307932856755756;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 1.304363789658063e-06;
        } else {
          result[0] += 3.544570404480618e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 9.67723116734732e-06;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 9.67723116734732e-06;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 9.67723116734732e-06;
            } else {
              result[0] += 9.67723116734732e-06;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 9.477418594326101e-06;
          } else {
            result[0] += -5.247478245008623e-06;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            result[0] += 9.67723116734732e-06;
          } else {
            result[0] += 9.67723116734732e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 9.67723116734732e-06;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              result[0] += 9.67723116734732e-06;
            } else {
              result[0] += 9.67723116734732e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 9.67723116734732e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 9.67723116734732e-06;
              } else {
                result[0] += 9.67723116734732e-06;
              }
            }
          }
        }
      } else {
        result[0] += 9.67723116734732e-06;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -1.4008432747734706e-05;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8643464628140704598) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4550000000000000711) ) ) {
                result[0] += -1.9756862242478895e-05;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                  result[0] += 2.1065092191367512e-05;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7894192122613066243) ) ) {
                    result[0] += -0.0009172145040201662;
                  } else {
                    result[0] += -0.00010477349816842429;
                  }
                }
              }
            } else {
              result[0] += 0.0006005373172455713;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
              result[0] += -0.00010418779511042465;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                    result[0] += -1.5428221950280537e-05;
                  } else {
                    result[0] += -1.5687366080970446e-05;
                  }
                } else {
                  result[0] += 4.9895121231316783e-05;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
                  result[0] += 2.275655050569666e-05;
                } else {
                  result[0] += -0.0008480075780966019;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -1.510370713513596e-05;
          } else {
            result[0] += -0.00029701167064302713;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 1.258103056537076e-06;
        } else {
          result[0] += 3.4188582168146204e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 9.334017248094313e-06;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 9.334017248094313e-06;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 9.334017248094313e-06;
            } else {
              result[0] += 9.334017248094313e-06;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 9.141291253360462e-06;
          } else {
            result[0] += -5.061370509899196e-06;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            result[0] += 9.334017248094313e-06;
          } else {
            result[0] += 9.334017248094313e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 9.334017248094313e-06;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              result[0] += 9.334017248094313e-06;
            } else {
              result[0] += 9.334017248094313e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 9.334017248094313e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 9.334017248094313e-06;
              } else {
                result[0] += 9.334017248094313e-06;
              }
            }
          }
        }
      } else {
        result[0] += 9.334017248094313e-06;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -1.3511607878841246e-05;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8643464628140704598) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
                result[0] += -1.5069587233983395e-06;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01218550000000000189) ) ) {
                  result[0] += 1.7660480178281723e-05;
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07954367714673930834) ) ) {
                    result[0] += -4.030825434474115e-05;
                  } else {
                    result[0] += -2.690723557770939e-05;
                  }
                }
              }
            } else {
              result[0] += 0.0005792385838840958;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
              result[0] += -0.00010049265743312766;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                    result[0] += -1.4881042655798299e-05;
                  } else {
                    result[0] += -1.5130995947579024e-05;
                  }
                } else {
                  result[0] += 4.8125534475212085e-05;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
                  result[0] += 2.1949463772650914e-05;
                } else {
                  result[0] += -0.0008179320327878918;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -1.4568037124625138e-05;
          } else {
            result[0] += -0.000286477816714869;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 1.2134830124982755e-06;
        } else {
          result[0] += 3.2976045536873917e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 9.00297579762969e-06;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 9.00297579762969e-06;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 9.00297579762969e-06;
            } else {
              result[0] += 9.00297579762969e-06;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 8.817085047693226e-06;
          } else {
            result[0] += -4.881863295544804e-06;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            result[0] += 9.00297579762969e-06;
          } else {
            result[0] += 9.00297579762969e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 9.00297579762969e-06;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              result[0] += 9.00297579762969e-06;
            } else {
              result[0] += 9.00297579762969e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 9.00297579762969e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 9.00297579762969e-06;
              } else {
                result[0] += 9.00297579762969e-06;
              }
            }
          }
        }
      } else {
        result[0] += 9.00297579762969e-06;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -1.3032403464340916e-05;
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8643464628140704598) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.4550000000000000711) ) ) {
                result[0] += -1.900271684635988e-05;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9750000000000000888) ) ) {
                  result[0] += 4.006893318796328e-05;
                } else {
                  result[0] += -1.3512585196354474e-05;
                }
              }
            } else {
              result[0] += 0.0005586952341262302;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6732382808793971884) ) ) {
              result[0] += -9.692857198166677e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                    result[0] += -1.4353269692212447e-05;
                  } else {
                    result[0] += -1.4594358108553161e-05;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                    result[0] += 0.0009737546713364311;
                  } else {
                    result[0] += -0.00016835567595907192;
                  }
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  result[0] += 2.238158925736617e-05;
                } else {
                  result[0] += -0.00020705009712588846;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01397330054109465099) ) ) {
            result[0] += 1.1704454686526664e-06;
          } else {
            result[0] += 3.1806512884969544e-06;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
          result[0] += -1.4051365255272201e-05;
        } else {
          result[0] += -2.441377656002041e-05;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 8.68367510562049e-06;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 8.68367510562049e-06;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 8.68367510562049e-06;
            } else {
              result[0] += 8.68367510562049e-06;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 8.504377180813916e-06;
          } else {
            result[0] += -4.708722507033956e-06;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            result[0] += 8.68367510562049e-06;
          } else {
            result[0] += 8.68367510562049e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 8.68367510562049e-06;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              result[0] += 8.68367510562049e-06;
            } else {
              result[0] += 8.68367510562049e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 8.68367510562049e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 8.68367510562049e-06;
              } else {
                result[0] += 8.68367510562049e-06;
              }
            }
          }
        }
      } else {
        result[0] += 8.68367510562049e-06;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -1.2570194574942836e-05;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8643464628140704598) ) ) {
              result[0] += -4.523494873898029e-06;
            } else {
              result[0] += 0.000538880477440401;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
              result[0] += -9.3490890841026e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                    result[0] += -1.3844214792107428e-05;
                  } else {
                    result[0] += -1.4076752735815178e-05;
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9550000000000000711) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += 0.0013885134247790347;
                    } else {
                      result[0] += -4.289298108909772e-05;
                    }
                  } else {
                    result[0] += -0.00038444359320028207;
                  }
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  result[0] += 2.0377212971567615e-05;
                } else {
                  result[0] += -0.0002562924251988029;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -1.3553017736571105e-05;
          } else {
            result[0] += -0.00027545169567403635;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 1.1289342998458388e-06;
        } else {
          result[0] += 3.067845902779636e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 8.375698772823777e-06;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 8.375698772823777e-06;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 8.375698772823777e-06;
            } else {
              result[0] += 8.375698772823777e-06;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 8.202759851169514e-06;
          } else {
            result[0] += -4.541722351889298e-06;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            result[0] += 8.375698772823777e-06;
          } else {
            result[0] += 8.375698772823777e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 8.375698772823777e-06;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                result[0] += 8.375698772823777e-06;
              } else {
                result[0] += 8.375698772823777e-06;
              }
            } else {
              result[0] += 8.375698772823777e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 8.375698772823777e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 8.375698772823777e-06;
              } else {
                result[0] += 8.375698772823777e-06;
              }
            }
          }
        }
      } else {
        result[0] += 8.375698772823777e-06;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -1.2124378445178339e-05;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8643464628140704598) ) ) {
              result[0] += -4.3630640257005e-06;
            } else {
              result[0] += 0.0005197684734514559;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
              result[0] += -9.017513093973819e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                    result[0] += -1.3353214098247939e-05;
                  } else {
                    result[0] += -1.3577504821479579e-05;
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9550000000000000711) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += 0.001339268229927796;
                    } else {
                      result[0] += -4.1371733131542386e-05;
                    }
                  } else {
                    result[0] += -0.00037080886751552803;
                  }
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  result[0] += 1.9654512128059597e-05;
                } else {
                  result[0] += -0.0002472027252415852;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -1.3072344674756136e-05;
          } else {
            result[0] += -0.00026568249057777924;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 1.0888953714652929e-06;
        } else {
          result[0] += 2.95904128731112e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 8.078645168065667e-06;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 8.078645168065667e-06;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 8.078645168065667e-06;
            } else {
              result[0] += 8.078645168065667e-06;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 7.911839720345757e-06;
          } else {
            result[0] += -4.3806450456229706e-06;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            result[0] += 8.078645168065667e-06;
          } else {
            result[0] += 8.078645168065667e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 8.078645168065667e-06;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                result[0] += 8.078645168065667e-06;
              } else {
                result[0] += 8.078645168065667e-06;
              }
            } else {
              result[0] += 8.078645168065667e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 8.078645168065667e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 8.078645168065667e-06;
              } else {
                result[0] += 8.078645168065667e-06;
              }
            }
          }
        }
      } else {
        result[0] += 8.078645168065667e-06;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -1.1694373687335987e-05;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8643464628140704598) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4601878067544193374) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.469327283602055445) ) ) {
                  result[0] += 2.2379688998033798e-05;
                } else {
                  result[0] += 0.0008917250917035664;
                }
              } else {
                result[0] += -1.0810517173651267e-05;
              }
            } else {
              result[0] += 0.000501334298242296;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
              result[0] += -8.697696820352266e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                    result[0] += -1.2879627297844362e-05;
                  } else {
                    result[0] += -1.3095963297576928e-05;
                  }
                } else {
                  result[0] += 1.053252565851776e-05;
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  result[0] += 1.8957442685172257e-05;
                } else {
                  result[0] += -0.00023843540174651974;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -1.2608719225277063e-05;
          } else {
            result[0] += -0.0002562597613599126;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 1.0502764688436257e-06;
        } else {
          result[0] += 2.8540955502616685e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 7.792126904478788e-06;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 7.792126904478788e-06;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 7.792126904478788e-06;
            } else {
              result[0] += 7.792126904478788e-06;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 7.631237400117072e-06;
          } else {
            result[0] += -4.22528052771855e-06;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            result[0] += 7.792126904478788e-06;
          } else {
            result[0] += 7.792126904478788e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 7.792126904478788e-06;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                result[0] += 7.792126904478788e-06;
              } else {
                result[0] += 7.792126904478788e-06;
              }
            } else {
              result[0] += 7.792126904478788e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 7.792126904478788e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 7.792126904478788e-06;
              } else {
                result[0] += 7.792126904478788e-06;
              }
            }
          }
        }
      } else {
        result[0] += 7.792126904478788e-06;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -1.1279619533275365e-05;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8643464628140704598) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9750000000000000888) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01332150000000000174) ) ) {
                  result[0] += -1.5458658621188193e-05;
                } else {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01000276686157755036) ) ) {
                    result[0] += -0.00018731898874972956;
                  } else {
                    result[0] += 8.916760496378768e-05;
                  }
                }
              } else {
                result[0] += -1.2421842577203472e-05;
              }
            } else {
              result[0] += 0.000483553911850656;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
              result[0] += -8.38922319162707e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                    result[0] += -1.2422836787522431e-05;
                  } else {
                    result[0] += -1.2631500186997738e-05;
                  }
                } else {
                  result[0] += 1.0158977755362103e-05;
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  result[0] += 1.8285095596370398e-05;
                } else {
                  result[0] += -0.00022997902126873732;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -1.2161536775332707e-05;
          } else {
            result[0] += -0.0002471712198625855;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 1.0130272291655107e-06;
        } else {
          result[0] += 2.7528718321553393e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 7.5157703343012865e-06;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 7.5157703343012865e-06;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 7.5157703343012865e-06;
            } else {
              result[0] += 7.5157703343012865e-06;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 7.3605869576957794e-06;
          } else {
            result[0] += -4.075426187693062e-06;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            result[0] += 7.5157703343012865e-06;
          } else {
            result[0] += 7.5157703343012865e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 7.5157703343012865e-06;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              result[0] += 7.5157703343012865e-06;
            } else {
              result[0] += 7.5157703343012865e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 7.5157703343012865e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 7.5157703343012865e-06;
              } else {
                result[0] += 7.5157703343012865e-06;
              }
            }
          }
        }
      } else {
        result[0] += 7.5157703343012865e-06;
      }
    }
  }
}

