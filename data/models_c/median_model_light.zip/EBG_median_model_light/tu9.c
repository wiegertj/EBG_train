
#include "header.h"

void predict_unit9(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.0002081479505203986;
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8950000000000001288) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6800105846231156992) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6010141514957837439) ) ) {
                result[0] += -0.000249794129370551;
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6488668789195980446) ) ) {
                  result[0] += 0.00022778371121819465;
                } else {
                  result[0] += 0.0017652344750427801;
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4868404241646586694) ) ) {
                result[0] += -0.0011599560547728893;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.883880929790755059e-06) ) ) {
                  result[0] += -0.00022295265737432203;
                } else {
                  result[0] += -0.00020504196828116712;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05067558311325295883) ) ) {
              result[0] += 1.3392591879005054e-06;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6850000000000001643) ) ) {
                  result[0] += 0.0004975168791068433;
                } else {
                  result[0] += 0.000563827780327483;
                }
              } else {
                result[0] += -9.193739240472248e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08495625534650631805) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2669585275879397535) ) ) {
              result[0] += 0.00025524792886648715;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01611044660174075147) ) ) {
                result[0] += -2.5149851607721044e-06;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)50.50000000000000711) ) ) {
                  result[0] += 3.300982829971757e-05;
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
                    result[0] += 0.00020764356593872113;
                  } else {
                    result[0] += 0.00011269179987009291;
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
              result[0] += 0.00018183907289467138;
            } else {
              result[0] += 0.00016367931841629934;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01531350000000000246) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)54.50000000000000711) ) ) {
              result[0] += -0.0002228896941116686;
            } else {
              result[0] += -0.0002228896941116686;
            }
          } else {
            result[0] += -0.00023349296212074206;
          }
        } else {
          result[0] += -0.0006788606362627538;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 0.00013189103221520305;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          result[0] += 0.00013189103221520305;
        } else {
          result[0] += -4.4202760556336034e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            result[0] += 0.00013189103221520305;
          } else {
            result[0] += 0.00013189103221520305;
          }
        } else {
          result[0] += 0.00013189103221520305;
        }
      } else {
        result[0] += 0.00013189103221520305;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.00020219270281558233;
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8950000000000001288) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02085144663384500344) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1250000000000000278) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)45.50000000000000711) ) ) {
                result[0] += -0.00022362090215103918;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
                  result[0] += -0.00021657383741577045;
                } else {
                  result[0] += -9.92487337013358e-05;
                }
              }
            } else {
              result[0] += -4.319554493486052e-05;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)39.50000000000000711) ) ) {
              result[0] += -7.734155820564753e-05;
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5510720942211057016) ) ) {
                  result[0] += 0.0005038289294738028;
                } else {
                  result[0] += 0.0019764791799053733;
                }
              } else {
                result[0] += 0.00016758499532876475;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08495625534650631805) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2669585275879397535) ) ) {
              result[0] += 0.00024794512026933004;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01611044660174075147) ) ) {
                result[0] += -2.443029806087959e-06;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)50.50000000000000711) ) ) {
                  result[0] += 3.20653957279504e-05;
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
                    result[0] += 0.0002017027490035323;
                  } else {
                    result[0] += 0.00010946761447287948;
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
              result[0] += 0.00017663653922189325;
            } else {
              result[0] += 0.00015899634708322745;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01531350000000000246) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)54.50000000000000711) ) ) {
            result[0] += -0.0002165126755728498;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
              result[0] += -0.0002165126755728498;
            } else {
              result[0] += -0.00022681257721527532;
            }
          }
        } else {
          result[0] += -0.0006594379936862289;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 0.00012811754434313005;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            result[0] += 0.00012811754434313005;
          } else {
            result[0] += 0.00012811754434313005;
          }
        } else {
          result[0] += -4.2938090941808555e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            result[0] += 0.00012811754434313005;
          } else {
            result[0] += 0.00012811754434313005;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 0.00012811754434313005;
          } else {
            result[0] += 0.00012811754434313005;
          }
        }
      } else {
        result[0] += 0.00012811754434313005;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.00019640783860547278;
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8950000000000001288) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02085144663384500344) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1250000000000000278) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)45.50000000000000711) ) ) {
                result[0] += -0.00021722296327652974;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
                  result[0] += -0.00021037751962849955;
                } else {
                  result[0] += -9.640916313576877e-05;
                }
              }
            } else {
              result[0] += -4.1959692411747136e-05;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)39.50000000000000711) ) ) {
              result[0] += -7.512876612271028e-05;
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5510720942211057016) ) ) {
                  result[0] += 0.0004894140574158883;
                } else {
                  result[0] += 0.0019199308301843163;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002201500000000000332) ) ) {
                  result[0] += -0.0005774294979435431;
                } else {
                  result[0] += 0.00022309063711311553;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08495625534650631805) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2070606536698188782) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)50.50000000000000711) ) ) {
                result[0] += 8.492541476494237e-05;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01587740346364930125) ) ) {
                  result[0] += 0.0001447139236330434;
                } else {
                  result[0] += 0.00020089455571467105;
                }
              }
            } else {
              result[0] += 4.9269630142865986e-05;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
              result[0] += 0.00017158285340775176;
            } else {
              result[0] += 0.00015444735859367206;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01531350000000000246) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)54.50000000000000711) ) ) {
            result[0] += -0.00021031810766552615;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
              result[0] += -0.00021031810766552615;
            } else {
              result[0] += -0.00022032332244957745;
            }
          }
        } else {
          result[0] += -0.0006405710454960101;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 0.0001244520184035818;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            result[0] += 0.0001244520184035818;
          } else {
            result[0] += 0.0001244520184035818;
          }
        } else {
          result[0] += -4.170960434422065e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            result[0] += 0.0001244520184035818;
          } else {
            result[0] += 0.0001244520184035818;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 0.0001244520184035818;
          } else {
            result[0] += 0.0001244520184035818;
          }
        }
      } else {
        result[0] += 0.0001244520184035818;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.00019078848310791026;
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8950000000000001288) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)45.50000000000000711) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01882700000000000345) ) ) {
                result[0] += -0.00021716406231820406;
              } else {
                result[0] += 0.00022233749906095909;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.80526473097989959) ) ) {
                  result[0] += -0.00020435848250716223;
                } else {
                  result[0] += -0.0004319482442914891;
                }
              } else {
                result[0] += -3.741607783836847e-05;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08495625534650631805) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
                result[0] += 0.0010670989988520955;
              } else {
                result[0] += 6.904588983544892e-06;
              }
            } else {
              result[0] += 0.0003349452597134414;
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09998752698574815689) ) ) {
              result[0] += 0.00021675779142012858;
            } else {
              result[0] += 0.0001796132082384706;
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08495625534650631805) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.2185860198827210554) ) ) {
                result[0] += 0.00015219889022987328;
              } else {
                result[0] += 1.6103108819032874e-05;
              }
            } else {
              result[0] += 0.00015002851961168551;
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01531350000000000246) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)54.50000000000000711) ) ) {
            result[0] += -0.00020430077035893718;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
              result[0] += -0.00020430077035893718;
            } else {
              result[0] += -0.00021401972946653362;
            }
          }
        } else {
          result[0] += -0.0006222438929157205;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 0.00012089136553573038;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 0.00012089136553573038;
            } else {
              result[0] += 0.00012089136553573038;
            }
          } else {
            result[0] += 0.00012089136553573038;
          }
        } else {
          result[0] += -4.0516265544028165e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 0.00012089136553573038;
            } else {
              result[0] += 0.00012089136553573038;
            }
          } else {
            result[0] += 0.00012089136553573038;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 0.00012089136553573038;
          } else {
            result[0] += 0.00012089136553573038;
          }
        }
      } else {
        result[0] += 0.00012089136553573038;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.00018532990101141056;
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8950000000000001288) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02085144663384500344) ) ) {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += -0.00019750528245201723;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4378622240954774258) ) ) {
                result[0] += 0.00024860996688325977;
              } else {
                if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3763018001168558224) ) ) {
                  result[0] += -0.001218208364935819;
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3715165125194505591) ) ) {
                    result[0] += 0.0018157473032080677;
                  } else {
                    result[0] += -0.00013543727159719758;
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)44.50000000000000711) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0131020000000000008) ) ) {
                result[0] += -0.0003189953052378933;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
                  result[0] += 0.00042086422661006455;
                } else {
                  result[0] += -0.0008793450804097566;
                }
              }
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01470002712569749848) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5510720942211057016) ) ) {
                  result[0] += 0.0004710127997295456;
                } else {
                  result[0] += 0.0019066597211394207;
                }
              } else {
                result[0] += 0.000166996404826453;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09998752698574815689) ) ) {
              result[0] += 0.00021055621058962469;
            } else {
              result[0] += 0.00017447435799544648;
            }
          } else {
            result[0] += 0.00010516613743952611;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01531350000000000246) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)54.50000000000000711) ) ) {
            result[0] += -0.000198455592970784;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
              result[0] += -0.000198455592970784;
            } else {
              result[0] += -0.00020789648636226833;
            }
          }
        } else {
          result[0] += -0.000604441092043275;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 0.00011743258525305747;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            result[0] += 0.00011743258525305747;
          } else {
            result[0] += 0.00011743258525305747;
          }
        } else {
          result[0] += -3.935706893996104e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 0.00011743258525305747;
            } else {
              result[0] += 0.00011743258525305747;
            }
          } else {
            result[0] += 0.00011743258525305747;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 0.00011743258525305747;
          } else {
            result[0] += 0.00011743258525305747;
          }
        }
      } else {
        result[0] += 0.00011743258525305747;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.0001800274924848185;
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8950000000000001288) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.50000000000000025e-06) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)46.50000000000000711) ) ) {
                result[0] += -0.00019891718197953957;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.80526473097989959) ) ) {
                    result[0] += -0.000192860899860114;
                  } else {
                    result[0] += -0.00041571497712361956;
                  }
                } else {
                  result[0] += -9.340041407195669e-05;
                }
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1550000000000000266) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4213441621608040588) ) ) {
                  result[0] += 0.000978343127928325;
                } else {
                  result[0] += -0.00016977826304514894;
                }
              } else {
                result[0] += 0.0008726580187728458;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05067558311325295883) ) ) {
              result[0] += 2.6623732142614966e-06;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6950000000000000622) ) ) {
                  result[0] += 0.0004638344405032124;
                } else {
                  result[0] += 0.0005126787094114306;
                }
              } else {
                result[0] += -0.00010278471107399382;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09998752698574815689) ) ) {
              result[0] += 0.00020453206100413151;
            } else {
              result[0] += 0.00016948253358687584;
            }
          } else {
            result[0] += 0.0001021572661196542;
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01531350000000000246) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)54.50000000000000711) ) ) {
            result[0] += -0.00019277764989427318;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
              result[0] += -0.00019277764989427318;
            } else {
              result[0] += -0.0002019484332099173;
            }
          }
        } else {
          result[0] += -0.0005871476408366314;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 0.00011407276291490473;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            result[0] += 0.00011407276291490473;
          } else {
            result[0] += 0.00011407276291490473;
          }
        } else {
          result[0] += -3.823103770168155e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 0.00011407276291490473;
            } else {
              result[0] += 0.00011407276291490473;
            }
          } else {
            result[0] += 0.00011407276291490473;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 0.00011407276291490473;
          } else {
            result[0] += 0.00011407276291490473;
          }
        }
      } else {
        result[0] += 0.00011407276291490473;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.00017487678930112806;
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8950000000000001288) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)45.50000000000000711) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01882700000000000345) ) ) {
                result[0] += -0.0001996089543000993;
              } else {
                result[0] += 0.00020770888867069944;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.80526473097989959) ) ) {
                  result[0] += -0.00018734302457780035;
                } else {
                  result[0] += -0.00040382110232358603;
                }
              } else {
                result[0] += -3.3451132903057255e-05;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08495625534650631805) ) ) {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
                result[0] += 0.0010340689552229662;
              } else {
                result[0] += 5.2584454476309e-06;
              }
            } else {
              result[0] += 0.00031847742249892084;
            }
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09998752698574815689) ) ) {
              result[0] += 0.00019868026624078697;
            } else {
              result[0] += 0.0001646335285083917;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01096925634721525149) ) ) {
              result[0] += -2.742244347270528e-05;
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01778816268138619719) ) ) {
                result[0] += 0.0001445511264431456;
              } else {
                result[0] += 4.8612253649217645e-05;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01531350000000000246) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)54.50000000000000711) ) ) {
            result[0] += -0.00018726215644741245;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
              result[0] += -0.00018726215644741245;
            } else {
              result[0] += -0.00019617055771146627;
            }
          }
        } else {
          result[0] += -0.0005703489664718892;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 0.00011080906727037703;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 0.00011080906727037703;
            } else {
              result[0] += 0.00011080906727037703;
            }
          } else {
            result[0] += 0.00011080906727037703;
          }
        } else {
          result[0] += -3.7137222946583317e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 0.00011080906727037703;
            } else {
              result[0] += 0.00011080906727037703;
            }
          } else {
            result[0] += 0.00011080906727037703;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 0.00011080906727037703;
          } else {
            result[0] += 0.00011080906727037703;
          }
        }
      } else {
        result[0] += 0.00011080906727037703;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.0001698734510722026;
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02085144663384500344) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)45.50000000000000711) ) ) {
              result[0] += -0.00018962497975649834;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
                result[0] += -0.00018198301928185127;
              } else {
                result[0] += -8.102525459331372e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2669585275879397535) ) ) {
              result[0] += 0.0004025132435879407;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
                result[0] += 0.0002984509445895297;
              } else {
                result[0] += -7.312352491954907e-05;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8950000000000001288) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)44.50000000000000711) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0131020000000000008) ) ) {
                result[0] += -0.0003160397511083994;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9850000000000000977) ) ) {
                  result[0] += 0.000400641453373558;
                } else {
                  result[0] += -0.000860357556212129;
                }
              }
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01470002712569749848) ) ) {
                result[0] += 0.0005114706844608171;
              } else {
                result[0] += 0.00015357213433020092;
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
              result[0] += 0.0001921823459419243;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.07172822906307056712) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)43.50000000000000711) ) ) {
                  result[0] += 5.765781669957409e-05;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05732259783002840309) ) ) {
                    result[0] += 0.00014500844168999807;
                  } else {
                    result[0] += 0.0001401665555218102;
                  }
                }
              } else {
                result[0] += 1.072458673714881e-05;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6735883055778896233) ) ) {
          result[0] += -0.001267872047827605;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)54.50000000000000711) ) ) {
            result[0] += -0.00018190446484106095;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
              result[0] += -0.00018190446484106095;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002413500000000000281) ) ) {
                result[0] += 9.554848073601759e-05;
              } else {
                result[0] += -0.0004894797949463301;
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 0.00010763874807249528;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          result[0] += 0.00010763874807249528;
        } else {
          result[0] += -3.6074702940191063e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            result[0] += 0.00010763874807249528;
          } else {
            result[0] += 0.00010763874807249528;
          }
        } else {
          result[0] += 0.00010763874807249528;
        }
      } else {
        result[0] += 0.00010763874807249528;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.00016501326159122184;
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05732259783002840309) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6750000000000001554) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5811189422864322385) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)902.5000000000001137) ) ) {
                result[0] += -3.9677651501872104e-05;
              } else {
                result[0] += 0.0019671849427353775;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1165587384072143268) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)53.50000000000000711) ) ) {
                  result[0] += -0.0004029029074276765;
                } else {
                  result[0] += -0.0016782914059998851;
                }
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)45.50000000000000711) ) ) {
                  result[0] += -0.00018455505760263163;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.036113539341048927e-06) ) ) {
                      result[0] += -0.00017677636720968696;
                    } else {
                      result[0] += -0.0005017260411514865;
                    }
                  } else {
                    result[0] += -5.677760505346557e-05;
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4589535259190716254) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)111.5000000000000142) ) ) {
                result[0] += 0.00017058304713690986;
              } else {
                result[0] += 0.0002837821436119782;
              }
            } else {
              result[0] += 3.9554840782588775e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)97.50000000000001421) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08495625534650631805) ) ) {
              result[0] += 2.5740197709530904e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.966590843157139501) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)17.50000000000000355) ) ) {
                  result[0] += 0.00014107551671576523;
                } else {
                  result[0] += 0.0001925761473138524;
                }
              } else {
                result[0] += -0.00029096482429885135;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.568345700351758909) ) ) {
              result[0] += 0.00016615286943628553;
            } else {
              result[0] += 0.00016205879556024222;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6735883055778896233) ) ) {
          result[0] += -0.0012315974071984332;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)54.50000000000000711) ) ) {
            result[0] += -0.00017670006026233607;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
              result[0] += -0.00017670006026233607;
            } else {
              result[0] += -0.00025802307521834015;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 0.00010455913376062955;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          result[0] += 0.00010455913376062955;
        } else {
          result[0] += -3.5042582319494187e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            result[0] += 0.00010455913376062955;
          } else {
            result[0] += 0.00010455913376062955;
          }
        } else {
          result[0] += 0.00010455913376062955;
        }
      } else {
        result[0] += 0.00010455913376062955;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.00016029212527977367;
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0129473293797221032) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.435405567110552727) ) ) {
            result[0] += 0.00019619490031382088;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)45.50000000000000711) ) ) {
                result[0] += -0.00018319247954219576;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
                  result[0] += -0.00017171868082623115;
                } else {
                  result[0] += -9.93491972082385e-05;
                }
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.000726282482777400166) ) ) {
                result[0] += 0.0002299467706202754;
              } else {
                result[0] += -0.00015839273799244814;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8950000000000001288) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)44.50000000000000711) ) ) {
              result[0] += -9.361176153183672e-05;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002165500000000000324) ) ) {
                result[0] += -0.00029446249874304177;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.05368089823796016319) ) ) {
                  result[0] += 0.0004915201828539362;
                } else {
                  result[0] += 0.0001388790739746388;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09998752698574815689) ) ) {
                result[0] += 0.00019295642460171665;
              } else {
                result[0] += 0.0001496710539611538;
              }
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)43.50000000000000711) ) ) {
                  result[0] += 7.116315714496904e-05;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05732259783002840309) ) ) {
                    result[0] += 0.00015522317783815386;
                  } else {
                    result[0] += 0.00012745104844775115;
                  }
                }
              } else {
                result[0] += 2.445922441237539e-05;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6735883055778896233) ) ) {
          result[0] += -0.0011963606075367549;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)54.50000000000000711) ) ) {
            result[0] += -0.0001716445570700764;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
              result[0] += -0.0001716445570700764;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002413500000000000281) ) ) {
                result[0] += 0.00010019698413690495;
              } else {
                result[0] += -0.00046809325359071163;
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 0.00010156762920923366;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          result[0] += 0.00010156762920923366;
        } else {
          result[0] += -3.4039991338388176e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            result[0] += 0.00010156762920923366;
          } else {
            result[0] += 0.00010156762920923366;
          }
        } else {
          result[0] += 0.00010156762920923366;
        }
      } else {
        result[0] += 0.00010156762920923366;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.00015570606373659768;
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05732259783002840309) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6750000000000001554) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5811189422864322385) ) ) {
              result[0] += -2.5293548398569056e-07;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1165587384072143268) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)53.50000000000000711) ) ) {
                  result[0] += -0.0003886973011013297;
                } else {
                  result[0] += -0.0016218496388144981;
                }
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)45.50000000000000711) ) ) {
                  result[0] += -0.0001761774378449659;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.036113539341048927e-06) ) ) {
                      result[0] += -0.00016680569812662838;
                    } else {
                      result[0] += -0.00048245835139114265;
                    }
                  } else {
                    result[0] += -5.2654114503745225e-05;
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4589535259190716254) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)111.5000000000000142) ) ) {
                result[0] += 0.00016158715854734792;
              } else {
                result[0] += 0.00027004968945109036;
              }
            } else {
              result[0] += 3.821208761690557e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)97.50000000000001421) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08495625534650631805) ) ) {
              result[0] += 2.341258113813802e-05;
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02424450000000000563) ) ) {
                result[0] += 5.7157782220524426e-05;
              } else {
                result[0] += 0.0001762364275654048;
              }
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.568345700351758909) ) ) {
              result[0] += 0.00015721853615868124;
            } else {
              result[0] += 0.00015306147336718312;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6735883055778896233) ) ) {
          result[0] += -0.0011621319555401661;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)54.50000000000000711) ) ) {
            result[0] += -0.00016673369509915536;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
              result[0] += -0.00016673369509915536;
            } else {
              result[0] += -0.00024537799258821596;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 9.866171354098163e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            result[0] += 9.866171354098163e-05;
          } else {
            result[0] += 9.866171354098163e-05;
          }
        } else {
          result[0] += -3.3066085134747472e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            result[0] += 9.866171354098163e-05;
          } else {
            result[0] += 9.866171354098163e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 9.866171354098163e-05;
          } else {
            result[0] += 9.866171354098163e-05;
          }
        }
      } else {
        result[0] += 9.866171354098163e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.00015125121238507077;
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0129473293797221032) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.435405567110552727) ) ) {
            result[0] += 0.00018327681738120467;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1250000000000000278) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)45.50000000000000711) ) ) {
                result[0] += -0.00017291067340214356;
              } else {
                result[0] += -0.00014295221096625787;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
                result[0] += -4.453169846098821e-05;
              } else {
                result[0] += -0.0006325733669149758;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8950000000000001288) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)111.5000000000000142) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7269841738944724518) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9079021320180030719) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08260095417535827378) ) ) {
                    result[0] += -3.5856918400642066e-05;
                  } else {
                    result[0] += 0.00035879622784181403;
                  }
                } else {
                  result[0] += 0.0023756412532923003;
                }
              } else {
                result[0] += -0.0002799840073293837;
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5521365942211056144) ) ) {
                result[0] += 0.0006244877470301558;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001962500000000000269) ) ) {
                  result[0] += -0.0006453302229572935;
                } else {
                  result[0] += 0.00018583813839087422;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09998752698574815689) ) ) {
                result[0] += 0.00018293769212734563;
              } else {
                result[0] += 0.00014089074398152728;
              }
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)50.50000000000000711) ) ) {
                  result[0] += 9.035598516004658e-05;
                } else {
                  result[0] += 0.00013980681275823736;
                }
              } else {
                result[0] += 2.200861015924619e-05;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6735883055778896233) ) ) {
          result[0] += -0.0011288826074508799;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)54.50000000000000711) ) ) {
            result[0] += -0.00016196333607053034;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
              result[0] += -0.00016196333607053034;
            } else {
              result[0] += -0.00023835756926182783;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 9.583893800247962e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          result[0] += 9.583893800247962e-05;
        } else {
          result[0] += -3.2120043018494446e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            result[0] += 9.583893800247962e-05;
          } else {
            result[0] += 9.583893800247962e-05;
          }
        } else {
          result[0] += 9.583893800247962e-05;
        }
      } else {
        result[0] += 9.583893800247962e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.0001469238172166105;
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0129473293797221032) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.435405567110552727) ) ) {
            result[0] += 0.0001780331489072828;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1250000000000000278) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)45.50000000000000711) ) ) {
                result[0] += -0.00016796358702275864;
              } else {
                result[0] += -0.00013886225560457013;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
                result[0] += -4.325761771991805e-05;
              } else {
                result[0] += -0.0006144750330998685;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8950000000000001288) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)111.5000000000000142) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08260095417535827378) ) ) {
                result[0] += -5.582322126223792e-05;
              } else {
                result[0] += 0.0002936808938384569;
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5521365942211056144) ) ) {
                result[0] += 0.0006066207480379037;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001962500000000000269) ) ) {
                  result[0] += -0.0006268669072267909;
                } else {
                  result[0] += 0.0001805211888636137;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09998752698574815689) ) ) {
                result[0] += 0.00017770372624662613;
              } else {
                result[0] += 0.00013685976852571363;
              }
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)60.50000000000000711) ) ) {
                  result[0] += 9.472988582691968e-05;
                } else {
                  result[0] += 0.0001370602260904681;
                }
              } else {
                result[0] += 2.137892956518221e-05;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6735883055778896233) ) ) {
          result[0] += -0.001096584544749705;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)54.50000000000000711) ) ) {
            result[0] += -0.0001573294601040029;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
              result[0] += -0.0001573294601040029;
            } else {
              result[0] += -0.0002315380047947111;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 9.309692390075876e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            result[0] += 9.309692390075876e-05;
          } else {
            result[0] += 9.309692390075876e-05;
          }
        } else {
          result[0] += -3.1201067780029246e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            result[0] += 9.309692390075876e-05;
          } else {
            result[0] += 9.309692390075876e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 9.309692390075876e-05;
          } else {
            result[0] += 9.309692390075876e-05;
          }
        }
      } else {
        result[0] += 9.309692390075876e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.00014272023162725193;
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02085144663384500344) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8250000000000000666) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5811189422864322385) ) ) {
              result[0] += -4.983535429184288e-05;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6731103726130654996) ) ) {
                  result[0] += -0.0004287772077830815;
                } else {
                  result[0] += -0.0012453278221439517;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.714286561348693172) ) ) {
                  result[0] += 0.00023460225081019297;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7508906866893444443) ) ) {
                    result[0] += -0.0009888005839013875;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.774278571389027559) ) ) {
                      result[0] += 0.0009456098126355862;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9993516786272610419) ) ) {
                        result[0] += -0.0002096028005093812;
                      } else {
                        result[0] += -7.341667238422132e-05;
                      }
                    }
                  }
                }
              }
            }
          } else {
            result[0] += 7.21672588068153e-05;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08495625534650631805) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)111.5000000000000142) ) ) {
              result[0] += 1.537493438700702e-05;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4795364038944723295) ) ) {
                result[0] += 0.00028957740340526797;
              } else {
                result[0] += 0.00014566135670880564;
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)17.50000000000000355) ) ) {
              result[0] += 4.602302286984993e-05;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7760221401809592745) ) ) {
                result[0] += 0.0001537978806838024;
              } else {
                result[0] += 5.8581243876327024e-05;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6735883055778896233) ) ) {
          result[0] += -0.0010652105505454348;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)54.50000000000000711) ) ) {
            result[0] += -0.0001528281623307513;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
              result[0] += -0.0001528281623307513;
            } else {
              result[0] += -0.0002249135524847844;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 9.043336059879203e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            result[0] += 9.043336059879203e-05;
          } else {
            result[0] += 9.043336059879203e-05;
          }
        } else {
          result[0] += -3.030838501844872e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            result[0] += 9.043336059879203e-05;
          } else {
            result[0] += 9.043336059879203e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 9.043336059879203e-05;
          } else {
            result[0] += 9.043336059879203e-05;
          }
        }
      } else {
        result[0] += 9.043336059879203e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.00013863691334473175;
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05732259783002840309) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6750000000000001554) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5811189422864322385) ) ) {
              result[0] += 3.0908529832444572e-06;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1165587384072143268) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)53.50000000000000711) ) ) {
                  result[0] += -0.0003606551476938913;
                } else {
                  result[0] += -0.001560556848128629;
                }
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)45.50000000000000711) ) ) {
                  result[0] += -0.00016032053718232213;
                } else {
                  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.488929482972568159e-06) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.036113539341048927e-06) ) ) {
                      result[0] += -0.0001479735126883132;
                    } else {
                      result[0] += -0.00044832441728424427;
                    }
                  } else {
                    result[0] += -4.710528989154326e-05;
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4589535259190716254) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)111.5000000000000142) ) ) {
                result[0] += 0.00014651873789353175;
              } else {
                result[0] += 0.00024992132867379804;
              }
            } else {
              result[0] += 3.441049764398111e-05;
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)18.50000000000000355) ) ) {
            result[0] += 9.338514680749357e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.09274867639439776656) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9650000000000000799) ) ) {
                result[0] += 0.00024271307149201755;
              } else {
                result[0] += 0.00010967663623726846;
              }
            } else {
              result[0] += 0.00012293693379435678;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6735883055778896233) ) ) {
          result[0] += -0.0010347341866397517;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)54.50000000000000711) ) ) {
            result[0] += -0.00014845564960278042;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
              result[0] += -0.00014845564960278042;
            } else {
              result[0] += -0.00021847863004683437;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 8.784600356838064e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            result[0] += 8.784600356838064e-05;
          } else {
            result[0] += 8.784600356838064e-05;
          }
        } else {
          result[0] += -2.94412424889827e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 8.784600356838064e-05;
            } else {
              result[0] += 8.784600356838064e-05;
            }
          } else {
            result[0] += 8.784600356838064e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 8.784600356838064e-05;
          } else {
            result[0] += 8.784600356838064e-05;
          }
        }
      } else {
        result[0] += 8.784600356838064e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.00013467042144349096;
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0129473293797221032) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.435405567110552727) ) ) {
            result[0] += 0.00016563967070970157;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1250000000000000278) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)45.50000000000000711) ) ) {
                result[0] += -0.00015647066700634523;
              } else {
                result[0] += -0.00012855519990148483;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.000726282482777400166) ) ) {
                result[0] += 0.00020192814275822252;
              } else {
                result[0] += -0.00014870890289734128;
              }
            }
          }
        } else {
          if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)50.50000000000000711) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08495625534650631805) ) ) {
                result[0] += -3.6541550710235865e-05;
              } else {
                result[0] += 0.00014577914221789996;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9650000000000000799) ) ) {
                result[0] += 0.0003328973789181237;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05403737693237045669) ) ) {
                  result[0] += 0.00013237035957906496;
                } else {
                  result[0] += 0.0001040797364925559;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09069971400431196817) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002726500000000000191) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
                  result[0] += -0.0006659272450221164;
                } else {
                  result[0] += -0.00015032175844314;
                }
              } else {
                result[0] += 3.759651372772229e-05;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02812450000000000366) ) ) {
                result[0] += 3.641925396968745e-05;
              } else {
                result[0] += 0.00017993233518681285;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6735883055778896233) ) ) {
          result[0] += -0.0010051297712483185;
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)54.50000000000000711) ) ) {
            result[0] += -0.00014420823729651645;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
              result[0] += -0.00014420823729651645;
            } else {
              result[0] += -0.00021222781490844387;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 8.533267249872617e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            result[0] += 8.533267249872617e-05;
          } else {
            result[0] += 8.533267249872617e-05;
          }
        } else {
          result[0] += -2.859890946901235e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            result[0] += 8.533267249872617e-05;
          } else {
            result[0] += 8.533267249872617e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 8.533267249872617e-05;
          } else {
            result[0] += 8.533267249872617e-05;
          }
        }
      } else {
        result[0] += 8.533267249872617e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.00013081741344507974;
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.4550000000000000711) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -0.0001385483644978494;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += 0.0004720944422308123;
            } else {
              result[0] += -0.00015355792927089688;
            }
          }
        } else {
          result[0] += -0.00014008234620785295;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09069971400431196817) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2669585275879397535) ) ) {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.007016451597998800589) ) ) {
              result[0] += 2.441101846348591e-05;
            } else {
              result[0] += 0.00032903960392093826;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)89.50000000000001421) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3995174958040201285) ) ) {
                  if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3998230401234152409) ) ) {
                    result[0] += -0.00012132345773511258;
                  } else {
                    result[0] += -0.000981956498029363;
                  }
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.08693186820944626136) ) ) {
                    result[0] += 0.00011946388571838272;
                  } else {
                    result[0] += -0.00040917965421818946;
                  }
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0169454538467869037) ) ) {
                  result[0] += 6.0078696717307006e-05;
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4795364038944723295) ) ) {
                    result[0] += 0.0002486552303767563;
                  } else {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5085295226130653878) ) ) {
                      result[0] += -1.2473244127841627e-05;
                    } else {
                      result[0] += 0.000282176972563744;
                    }
                  }
                }
              }
            } else {
              result[0] += -1.4260287560724809e-05;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02812450000000000366) ) ) {
            result[0] += 7.504752594842102e-05;
          } else {
            result[0] += 0.00013516932396793758;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 8.289124945913513e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 8.289124945913513e-05;
            } else {
              result[0] += 8.289124945913513e-05;
            }
          } else {
            result[0] += 8.289124945913513e-05;
          }
        } else {
          result[0] += -2.7780676142416413e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 8.289124945913513e-05;
            } else {
              result[0] += 8.289124945913513e-05;
            }
          } else {
            result[0] += 8.289124945913513e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 8.289124945913513e-05;
          } else {
            result[0] += 8.289124945913513e-05;
          }
        }
      } else {
        result[0] += 8.289124945913513e-05;
      }
    }
  }
}

