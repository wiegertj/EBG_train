
#include "header.h"

void predict_unit9(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.00016323025770469438;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
              result[0] += -0.00012306274529033453;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                result[0] += -0.00017941859080388678;
              } else {
                result[0] += -0.00017544571553585806;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              result[0] += -0.0001764128408676395;
            } else {
              result[0] += -0.00017599270756132006;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8950000000000001288) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.555096866909547848) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5528143519346734314) ) ) {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008332142139858200389) ) ) {
                  result[0] += -7.781318701123343e-05;
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.05463331189772155372) ) ) {
                    result[0] += 0.0003211377635231506;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5361772370603016258) ) ) {
                      result[0] += 0.00041455307893979455;
                    } else {
                      result[0] += -0.000953863993819658;
                    }
                  }
                }
              } else {
                result[0] += 0.0018938218974310233;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1513805188710139749) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1076318469022627677) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5674119023366835934) ) ) {
                    result[0] += 5.478675678601104e-05;
                  } else {
                    result[0] += -0.0009132306760574876;
                  }
                } else {
                  result[0] += -7.591402561937315e-05;
                }
              } else {
                result[0] += 0.0007827812715696217;
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08666957264163686891) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3750409390474713223) ) ) {
                  result[0] += 0.00024294587801769205;
                } else {
                  result[0] += 0.00013143786221650293;
                }
              } else {
                result[0] += 0.0001797926692093058;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.07274795227358500649) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05831812793683335133) ) ) {
                  result[0] += 0.0001039838856708289;
                } else {
                  result[0] += 0.00011422603266328425;
                }
              } else {
                result[0] += 3.6559179966308893e-06;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
          result[0] += -0.00025807402059925414;
        } else {
          result[0] += -0.00012581277446662743;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 0.00010876263378375035;
        } else {
          result[0] += 0.00010876263378375035;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01657900000000000346) ) ) {
            result[0] += 0.00010876263378375035;
          } else {
            result[0] += -3.729024332072799e-05;
          }
        } else {
          result[0] += 0.00010876263378375035;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 0.00010876263378375035;
        } else {
          result[0] += 0.00010876263378375035;
        }
      } else {
        result[0] += 0.00010876263378375035;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.0001574411124916658;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += -0.00016922333533182573;
            } else {
              result[0] += -7.086286903302477e-05;
            }
          } else {
            result[0] += -0.00016975092766809838;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8950000000000001288) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8158067323869347964) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01262450000000000204) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.767254320477387064) ) ) {
                      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
                        result[0] += -5.444673007066544e-05;
                      } else {
                        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.4050000000000000822) ) ) {
                          result[0] += -0.0009941076338414458;
                        } else {
                          result[0] += 0.00016735144448483725;
                        }
                      }
                    } else {
                      result[0] += 0.0008447517164192425;
                    }
                  } else {
                    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01000276686157755036) ) ) {
                      result[0] += -0.0006237365810818413;
                    } else {
                      result[0] += 0.00031715427527423764;
                    }
                  }
                } else {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.292381066124493438) ) ) {
                    result[0] += -0.0009460357119164442;
                  } else {
                    result[0] += 0.00064459273743452;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8168185667587940513) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001574500000000000162) ) ) {
                    result[0] += 0.0011369170082095583;
                  } else {
                    result[0] += 0.004392053659050757;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2004855000000000109) ) ) {
                    result[0] += 2.8928115009693028e-05;
                  } else {
                    result[0] += 0.0016343801571417262;
                  }
                }
              }
            } else {
              result[0] += -0.00034927436399826594;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08666957264163686891) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3750409390474713223) ) ) {
                  result[0] += 0.00023432952841114194;
                } else {
                  result[0] += 0.00012677627017124732;
                }
              } else {
                result[0] += 0.00017341611938988602;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.07274795227358500649) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05831812793683335133) ) ) {
                  result[0] += 0.00010029597987181817;
                } else {
                  result[0] += 0.0001101748775680544;
                }
              } else {
                result[0] += 3.526256741007948e-06;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
          result[0] += -0.0002489211343515211;
        } else {
          result[0] += -0.00012135068250351236;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 0.00010490524429249007;
        } else {
          result[0] += 0.00010490524429249007;
        }
      } else {
        result[0] += 0.00010490524429249007;
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 0.00010490524429249007;
        } else {
          result[0] += 0.00010490524429249007;
        }
      } else {
        result[0] += 0.00010490524429249007;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.000151857285843766;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7568279636683418188) ) ) {
              result[0] += -0.00011269648974272717;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
                result[0] += -0.0001670536116258163;
              } else {
                result[0] += -0.00016322163886056668;
              }
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                result[0] += -0.0001641747719919844;
              } else {
                result[0] += -0.0001641357523442109;
              }
            } else {
              result[0] += -0.00016373051953950992;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8950000000000001288) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02063185379234615258) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.146109394227906586) ) ) {
                result[0] += 0.0025698810487910775;
              } else {
                result[0] += -9.147792957139949e-05;
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01308450000000000064) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8254037945979900703) ) ) {
                  result[0] += -2.1052184624430443e-05;
                } else {
                  result[0] += -0.0007503861285362629;
                }
              } else {
                result[0] += 0.0002981169593119991;
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08666957264163686891) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3750409390474713223) ) ) {
                  result[0] += 0.00022601876736261716;
                } else {
                  result[0] += 0.00012228000674614713;
                }
              } else {
                result[0] += 0.00016726572110255123;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01127328256994905228) ) ) {
                result[0] += -3.7302034952923114e-05;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.07274795227358500649) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.020650504707780553) ) ) {
                    if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.009014249010710599294) ) ) {
                      result[0] += 0.00010626740125797648;
                    } else {
                      result[0] += -0.0001226430112768437;
                    }
                  } else {
                    result[0] += 0.00019303033924896658;
                  }
                } else {
                  result[0] += 3.009496794290319e-05;
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
          result[0] += -0.00024009286553900848;
        } else {
          result[0] += -0.00011704684366510345;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 0.00010118466147066828;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 0.00010118466147066828;
          } else {
            result[0] += 0.00010118466147066828;
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01657900000000000346) ) ) {
            result[0] += 0.00010118466147066828;
          } else {
            result[0] += -3.9688285599829495e-05;
          }
        } else {
          result[0] += 0.00010118466147066828;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 0.00010118466147066828;
        } else {
          result[0] += 0.00010118466147066828;
        }
      } else {
        result[0] += 0.00010118466147066828;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.00014647149590648367;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04853104146385620737) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3539353041941689093) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0008535000000000002003) ) ) {
                result[0] += -0.0002879803760861285;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4636504894974874946) ) ) {
                  if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
                    result[0] += 0.00046135230690307896;
                  } else {
                    if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5724391781153673753) ) ) {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0758825000000000055) ) ) {
                        result[0] += -0.00014969892454586391;
                      } else {
                        result[0] += 0.0005920131661462789;
                      }
                    } else {
                      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4601878067544193374) ) ) {
                        result[0] += 0.000610590015354031;
                      } else {
                        if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3721023948335018816) ) ) {
                          result[0] += -0.0005338605471875131;
                        } else {
                          result[0] += 0.00029126837397310646;
                        }
                      }
                    }
                  }
                } else {
                  result[0] += 0.0013126359141958127;
                }
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9112103514676580529) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5876805463210391656) ) ) {
                    result[0] += -9.31787738482368e-05;
                  } else {
                    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.6285027855690678011) ) ) {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6650804020351760437) ) ) {
                        result[0] += -0.0011314818789013963;
                      } else {
                        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6802634857286432579) ) ) {
                          result[0] += 0.0029867635946623713;
                        } else {
                          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6959555468592965033) ) ) {
                            result[0] += -0.0010518664480556582;
                          } else {
                            result[0] += 0.0013678472076444116;
                          }
                        }
                      }
                    } else {
                      result[0] += -7.677450888366392e-05;
                    }
                  }
                } else {
                  result[0] += -0.0005847050680714716;
                }
              } else {
                result[0] += 0.0005967681368401911;
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8950000000000001288) ) ) {
              result[0] += 0.00023720504065731575;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
                result[0] += 0.00015867521468783456;
              } else {
                result[0] += 0.00010249850800286377;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              result[0] += -0.00015743279932456714;
            } else {
              result[0] += -0.00015792363197621488;
            }
          } else {
            result[0] += -0.00017470558195101804;
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
          result[0] += -0.00023157770123820808;
        } else {
          result[0] += -0.00011289564532582368;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 9.759603331543562e-05;
        } else {
          result[0] += 9.759603331543562e-05;
        }
      } else {
        result[0] += 9.759603331543562e-05;
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 9.759603331543562e-05;
        } else {
          result[0] += 9.759603331543562e-05;
        }
      } else {
        result[0] += 9.759603331543562e-05;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.00014127671908449154;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
            result[0] += -0.00015287895402189765;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7990273242713569202) ) ) {
                result[0] += -0.00015273096093034366;
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01910124190761275029) ) ) {
                  result[0] += -0.00015184926751251576;
                } else {
                  result[0] += 0.0005126953171531311;
                }
              }
            } else {
              result[0] += -0.00015232269223051416;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8950000000000001288) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.555096866909547848) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5528143519346734314) ) ) {
                result[0] += 0.00010256479393586948;
              } else {
                result[0] += 0.0018351354405869607;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1513805188710139749) ) ) {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1076318469022627677) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5674119023366835934) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.564198853668341882) ) ) {
                      result[0] += -0.0005004341779164771;
                    } else {
                      result[0] += 0.001288960857010032;
                    }
                  } else {
                    result[0] += -0.0008783384764171969;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.55780239615577909) ) ) {
                    result[0] += -0.0030256084788677154;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5814822343216081713) ) ) {
                      result[0] += 0.0007170394876370332;
                    } else {
                      result[0] += -9.478671600517949e-05;
                    }
                  }
                }
              } else {
                result[0] += 0.0007254853338374411;
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08666957264163686891) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3750409390474713223) ) ) {
                  result[0] += 0.0002072858996432308;
                } else {
                  result[0] += 0.00012124789869526792;
                }
              } else {
                result[0] += 0.0001557058581537662;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1534042965400678749) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05831812793683335133) ) ) {
                  result[0] += 8.712586483404272e-05;
                } else {
                  result[0] += 9.8863282798352e-05;
                }
              } else {
                result[0] += -6.607955833298142e-06;
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
          result[0] += -0.00022336453684443052;
        } else {
          result[0] += -0.00010889167391819313;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 9.4134679905699e-05;
        } else {
          result[0] += 9.4134679905699e-05;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01657900000000000346) ) ) {
            result[0] += 9.4134679905699e-05;
          } else {
            result[0] += -4.1742049192429353e-05;
          }
        } else {
          result[0] += 9.4134679905699e-05;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 9.4134679905699e-05;
        } else {
          result[0] += 9.4134679905699e-05;
        }
      } else {
        result[0] += 9.4134679905699e-05;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.00013626618088219327;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += -0.00014646376195439587;
            } else {
              result[0] += -6.947246509623361e-05;
            }
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)7.80502810879622084e-06) ) ) {
                result[0] += -0.00014738309114417482;
              } else {
                result[0] += -0.00014731418512061142;
              }
            } else {
              result[0] += -0.00014692039613074795;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8950000000000001288) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008332142139858200389) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9450000000000000622) ) ) {
                result[0] += -0.00017608147681796383;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)3.150000000000000673e-05) ) ) {
                  result[0] += 0.0015984862021236005;
                } else {
                  result[0] += 0.00010825601829242392;
                }
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001841500000000000255) ) ) {
                result[0] += -0.0003980156678951742;
              } else {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3539353041941689093) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4636504894974874946) ) ) {
                    result[0] += 0.0004119364942391514;
                  } else {
                    result[0] += 0.0024454385799055935;
                  }
                } else {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1513805188710139749) ) ) {
                    result[0] += 7.207487769971544e-05;
                  } else {
                    result[0] += 0.0005233136759086027;
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.06949760265420222571) ) ) {
                if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3750409390474713223) ) ) {
                  result[0] += 0.0002209098063343708;
                } else {
                  result[0] += 0.00010801541940613312;
                }
              } else {
                result[0] += 0.00014752533531804264;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1534042965400678749) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05831812793683335133) ) ) {
                  result[0] += 8.403584775983356e-05;
                } else {
                  result[0] += 9.535698495624433e-05;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5628434130653267031) ) ) {
                  result[0] += -0.0008825501682547276;
                } else {
                  result[0] += 1.4103903472019702e-05;
                }
              }
            }
          }
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7441668712814071274) ) ) {
          result[0] += -0.0002154426615903177;
        } else {
          result[0] += -0.00010502970787300904;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 9.079608729903886e-05;
        } else {
          result[0] += 9.079608729903886e-05;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01657900000000000346) ) ) {
            result[0] += 9.079608729903886e-05;
          } else {
            result[0] += -4.0261620332840894e-05;
          }
        } else {
          result[0] += 9.079608729903886e-05;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 9.079608729903886e-05;
        } else {
          result[0] += 9.079608729903886e-05;
        }
      } else {
        result[0] += 9.079608729903886e-05;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.00013143334706912043;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6150000000000001021) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7478339930150754711) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9112103514676580529) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03181986453917805963) ) ) {
                  result[0] += -9.536015997306905e-05;
                } else {
                  result[0] += 0.0003830068623828685;
                }
              } else {
                result[0] += -0.0006045616190656959;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001260500000000000119) ) ) {
                result[0] += 0.00018215750745237462;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7190147863316583843) ) ) {
                  result[0] += 0.0009345759333317194;
                } else {
                  result[0] += 0.003578739677079475;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
              result[0] += -0.00015695914530170502;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.097216905567068856) ) ) {
                result[0] += 0.0005942708219779684;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.180517123172382332) ) ) {
                  result[0] += -0.0004365784500883242;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7954292854522614364) ) ) {
                      result[0] += -0.00019380153263472992;
                    } else {
                      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.09856950000000001821) ) ) {
                        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.459978591867425068) ) ) {
                          result[0] += -8.783236941045791e-05;
                        } else {
                          result[0] += 0.0013504967192819986;
                        }
                      } else {
                        result[0] += 0.0015696219980892664;
                      }
                    }
                  } else {
                    result[0] += -0.0001412692594257384;
                  }
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08404042173159891049) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2177889902755587859) ) ) {
              result[0] += 0.00014347594048479112;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4781247323869347032) ) ) {
                result[0] += -0.00026861199449483195;
              } else {
                result[0] += 5.0672695015252935e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01439850000000000158) ) ) {
              result[0] += 6.063068377855241e-05;
            } else {
              result[0] += 0.00013313634575973368;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6732382808793971884) ) ) {
          result[0] += -0.0007656856827445187;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7894192122613066243) ) ) {
            result[0] += 1.871161458854581e-06;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += -0.00014170969855594335;
            } else {
              result[0] += -0.00024685551352014484;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 8.757590164510392e-05;
        } else {
          result[0] += 8.757590164510392e-05;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          result[0] += 8.757590164510392e-05;
        } else {
          result[0] += 8.757590164510392e-05;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 8.757590164510392e-05;
        } else {
          result[0] += 8.757590164510392e-05;
        }
      } else {
        result[0] += 8.757590164510392e-05;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.00012677191515865892;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0119121105025029022) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4389499174623116007) ) ) {
            result[0] += 0.00025488144368376935;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.966590843157139501) ) ) {
                  result[0] += -0.0001393620748230181;
                } else {
                  result[0] += 0.00021261152764865537;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7983409114572864729) ) ) {
                  result[0] += -0.00013505645532476876;
                } else {
                  result[0] += -0.00013512817998540303;
                }
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02162700000000000386) ) ) {
                result[0] += -0.00010068380317978743;
              } else {
                result[0] += -0.0006357940985981125;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8950000000000001288) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01172600000000000205) ) ) {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.09500000000000001499) ) ) {
                result[0] += -0.00044789005230438933;
              } else {
                result[0] += 9.860499538123784e-06;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1513805188710139749) ) ) {
                result[0] += 0.00020233781969695118;
              } else {
                result[0] += 0.0005009983955765675;
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              result[0] += 0.000151008073390485;
            } else {
              result[0] += 8.72532112422048e-05;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6732382808793971884) ) ) {
          result[0] += -0.0007385297763134681;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7894192122613066243) ) ) {
            result[0] += 1.80479860704846e-06;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.96280210579579717) ) ) {
                result[0] += -0.0001366838042482897;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.578971790991679312e-05) ) ) {
                    result[0] += -0.00013713535172806847;
                  } else {
                    result[0] += 0.00035788729615307514;
                  }
                } else {
                  result[0] += -9.627881650225677e-05;
                }
              }
            } else {
              result[0] += -0.0002381005042804354;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 8.446992350775027e-05;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 8.446992350775027e-05;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 8.446992350775027e-05;
            } else {
              result[0] += 8.446992350775027e-05;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01657900000000000346) ) ) {
            result[0] += 8.446992350775027e-05;
          } else {
            result[0] += -4.193967469003025e-05;
          }
        } else {
          result[0] += 8.446992350775027e-05;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 8.446992350775027e-05;
        } else {
          result[0] += 8.446992350775027e-05;
        }
      } else {
        result[0] += 8.446992350775027e-05;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.00012227580618899144;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6150000000000001021) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7478339930150754711) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9112103514676580529) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03181986453917805963) ) ) {
                  result[0] += -8.70354711496313e-05;
                } else {
                  result[0] += 0.00036566016560162743;
                }
              } else {
                result[0] += -0.0005902962983131292;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.729199597233659459e-06) ) ) {
                result[0] += -0.0001027061280073786;
              } else {
                result[0] += 0.0015177571130113006;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.046799451955306548) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9567162861906464144) ) ) {
                result[0] += -0.00013441944163916934;
              } else {
                result[0] += -0.0003594360463293496;
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.097216905567068856) ) ) {
                result[0] += 0.000576765201590735;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.180517123172382332) ) ) {
                  result[0] += -0.00041920428162845223;
                } else {
                  result[0] += -0.00011188020089174223;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08404042173159891049) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2177889902755587859) ) ) {
              result[0] += 0.00013391774853864524;
            } else {
              result[0] += 2.2169819611304e-05;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01439850000000000158) ) ) {
              result[0] += 5.1685471397310134e-05;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4093335132160804135) ) ) {
                result[0] += -2.8962395901149803e-05;
              } else {
                result[0] += 0.00013948346839513478;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6732382808793971884) ) ) {
          result[0] += -0.0007123369847358242;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7894192122613066243) ) ) {
            result[0] += 1.740789388638859e-06;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.96280210579579717) ) ) {
                result[0] += -0.00013183615895145964;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.578971790991679312e-05) ) ) {
                    result[0] += -0.00013227169179052303;
                  } else {
                    result[0] += 0.00034519441949857276;
                  }
                } else {
                  result[0] += -9.286417967261667e-05;
                }
              }
            } else {
              result[0] += -0.00022965600131905176;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 8.147410238857737e-05;
        } else {
          result[0] += 8.147410238857737e-05;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01657900000000000346) ) ) {
            result[0] += 8.147410238857737e-05;
          } else {
            result[0] += -4.045223681924691e-05;
          }
        } else {
          result[0] += 8.147410238857737e-05;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 8.147410238857737e-05;
        } else {
          result[0] += 8.147410238857737e-05;
        }
      } else {
        result[0] += 8.147410238857737e-05;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.00011793915679553859;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6150000000000001021) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7478339930150754711) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9112103514676580529) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
                result[0] += -4.272328103567694e-05;
              } else {
                result[0] += -0.0005693607742399493;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)8.729199597233659459e-06) ) ) {
                result[0] += -9.906353932521037e-05;
              } else {
                result[0] += 0.0014639281449701832;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9567162861906464144) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9310018456912946272) ) ) {
                  result[0] += -0.0002010734026915504;
                } else {
                  if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                    result[0] += -0.00012965210451646998;
                  } else {
                    result[0] += 0.0023303909127927345;
                  }
                }
              } else {
                result[0] += -0.00042419761787668023;
              }
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.097216905567068856) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8168185667587940513) ) ) {
                  result[0] += 0.0006734694081383762;
                } else {
                  result[0] += -0.0005565378399106786;
                }
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.180517123172382332) ) ) {
                  result[0] += -0.0004043367289185809;
                } else {
                  result[0] += -0.00010791224336638644;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08404042173159891049) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2177889902755587859) ) ) {
              result[0] += 0.0001291682045276647;
            } else {
              result[0] += 2.1383541951258364e-05;
            }
          } else {
            result[0] += 0.00010546398809484359;
          }
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6732382808793971884) ) ) {
          result[0] += -0.0006870731500569182;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7894192122613066243) ) ) {
            result[0] += 1.679050329362475e-06;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.96280210579579717) ) ) {
                result[0] += -0.00012716044086321962;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.578971790991679312e-05) ) ) {
                    result[0] += -0.00012758052703886513;
                  } else {
                    result[0] += 0.00033295171003217184;
                  }
                } else {
                  result[0] += -8.957064678984591e-05;
                }
              }
            } else {
              result[0] += -0.00022151099218058176;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 7.85845314446787e-05;
        } else {
          result[0] += 7.85845314446787e-05;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01657900000000000346) ) ) {
            result[0] += 7.85845314446787e-05;
          } else {
            result[0] += -3.901755261037824e-05;
          }
        } else {
          result[0] += 7.85845314446787e-05;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 7.85845314446787e-05;
        } else {
          result[0] += 7.85845314446787e-05;
        }
      } else {
        result[0] += 7.85845314446787e-05;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.00011375631156455978;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01881166515770610337) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4389499174623116007) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.146109394227906586) ) ) {
              result[0] += 0.0012036071332107762;
            } else {
              result[0] += 0.00017919298607405238;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += -0.0001225208094794612;
            } else {
              result[0] += -9.260860417355521e-05;
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.07274795227358500649) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8950000000000001288) ) ) {
              result[0] += 0.00024304007630240014;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.020650504707780553) ) ) {
                result[0] += 8.144546242312852e-05;
              } else {
                result[0] += 0.00017501549638412325;
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1513805188710139749) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5336217185678392427) ) ) {
                result[0] += -0.0011147714427391733;
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.002965500000000000688) ) ) {
                  result[0] += -0.0003144825718338719;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8099155601256282644) ) ) {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7789937396482412568) ) ) {
                      result[0] += 6.777663968900468e-05;
                    } else {
                      result[0] += -0.0005091247004259844;
                    }
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
                      result[0] += 0.0013206148612180996;
                    } else {
                      result[0] += -0.00011260348552685198;
                    }
                  }
                }
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01798150000000000096) ) ) {
                result[0] += 7.237070674953959e-05;
              } else {
                result[0] += 0.0002553411634676315;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6732382808793971884) ) ) {
          result[0] += -0.0006627053257724745;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7894192122613066243) ) ) {
            result[0] += 1.6195009154649116e-06;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.96280210579579717) ) ) {
                result[0] += -0.00012265055239118336;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.578971790991679312e-05) ) ) {
                    result[0] += -0.0001230557397367529;
                  } else {
                    result[0] += 0.000321143202066758;
                  }
                } else {
                  result[0] += -8.63939227658637e-05;
                }
              }
            } else {
              result[0] += -0.0002136548549787682;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 7.579744239373629e-05;
        } else {
          result[0] += 7.579744239373629e-05;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01657900000000000346) ) ) {
            result[0] += 7.579744239373629e-05;
          } else {
            result[0] += -3.763375109529949e-05;
          }
        } else {
          result[0] += 7.579744239373629e-05;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 7.579744239373629e-05;
        } else {
          result[0] += 7.579744239373629e-05;
        }
      } else {
        result[0] += 7.579744239373629e-05;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.00010972181565794197;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0119121105025029022) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4389499174623116007) ) ) {
            result[0] += 0.00023405382292865837;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += -0.00011817547076794847;
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02162700000000000386) ) ) {
                result[0] += -9.198604295424544e-05;
              } else {
                result[0] += -0.0006115051442029082;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8950000000000001288) ) ) {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01287800000000000229) ) ) {
              result[0] += -6.948654954843011e-05;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1513805188710139749) ) ) {
                result[0] += 0.00019155596473308703;
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9050000000000001377) ) ) {
                  result[0] += 0.001524075026777391;
                } else {
                  result[0] += 4.4598754606772606e-05;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.07274795227358500649) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.020650504707780553) ) ) {
                if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.009014249010710599294) ) ) {
                  result[0] += 8.416140500935004e-05;
                } else {
                  result[0] += -0.00012889523408803118;
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02563650000000000304) ) ) {
                  result[0] += 0.00012888976948671548;
                } else {
                  result[0] += 0.0001839870988410595;
                }
              }
            } else {
              result[0] += 4.183255309508211e-05;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6732382808793971884) ) ) {
          result[0] += -0.0006392017338631545;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7894192122613066243) ) ) {
            result[0] += 1.5620634887028912e-06;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.96280210579579717) ) ) {
                result[0] += -0.00011830061220095654;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.578971790991679312e-05) ) ) {
                    result[0] += -0.00011869142912026465;
                  } else {
                    result[0] += 0.0003097534961563202;
                  }
                } else {
                  result[0] += -8.332986484273284e-05;
                }
              }
            } else {
              result[0] += -0.0002060773445445295;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 7.31092005998204e-05;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 7.31092005998204e-05;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 7.31092005998204e-05;
            } else {
              result[0] += 7.31092005998204e-05;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01657900000000000346) ) ) {
            result[0] += 7.31092005998204e-05;
          } else {
            result[0] += -3.629902766187814e-05;
          }
        } else {
          result[0] += 7.31092005998204e-05;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 7.31092005998204e-05;
        } else {
          result[0] += 7.31092005998204e-05;
        }
      } else {
        result[0] += 7.31092005998204e-05;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.00010583040769955883;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6750000000000001554) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9112103514676580529) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7412676365326634764) ) ) {
                  result[0] += -7.890357562907373e-05;
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0007535000000000001549) ) ) {
                    result[0] += 6.934642513982722e-05;
                  } else {
                    result[0] += 0.003662359590701274;
                  }
                }
              } else {
                result[0] += -0.0004973970515912489;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.001390500000000000243) ) ) {
                result[0] += 0.0001313898001820642;
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7190147863316583843) ) ) {
                  result[0] += 0.0008767195247206918;
                } else {
                  result[0] += 0.003824774719262729;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
              result[0] += -0.0001401296701517462;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.097216905567068856) ) ) {
                result[0] += 0.0003678238353776103;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.180517123172382332) ) ) {
                  result[0] += -0.0003106082725385924;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7954292854522614364) ) ) {
                      result[0] += -0.0001781368982802417;
                    } else {
                      result[0] += 0.0002376313120636268;
                    }
                  } else {
                    result[0] += -0.00011513476041573929;
                  }
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08404042173159891049) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006937836693866150477) ) ) {
                result[0] += 1.26980058444421e-05;
              } else {
                result[0] += 0.00013780296192004383;
              }
            } else {
              result[0] += 2.1550209419787852e-05;
            }
          } else {
            result[0] += 8.198347987931682e-05;
          }
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6732382808793971884) ) ) {
          result[0] += -0.0006165317233529217;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7894192122613066243) ) ) {
            result[0] += 1.5066631450703333e-06;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.96280210579579717) ) ) {
                result[0] += -0.00011410494754630336;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.578971790991679312e-05) ) ) {
                    result[0] += -0.0001144819037027272;
                  } else {
                    result[0] += 0.00029876773901357047;
                  }
                } else {
                  result[0] += -8.037447719009942e-05;
                }
              }
            } else {
              result[0] += -0.00019876857906526543;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 7.051630033346029e-05;
        } else {
          result[0] += 7.051630033346029e-05;
        }
      } else {
        result[0] += 7.051630033346029e-05;
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 7.051630033346029e-05;
        } else {
          result[0] += 7.051630033346029e-05;
        }
      } else {
        result[0] += 7.051630033346029e-05;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -0.00010207701291392315;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.6750000000000001554) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7472528898492464267) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9112103514676580529) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.8036796978107810796) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.5876805463210391656) ) ) {
                  result[0] += -0.00013052916178793314;
                } else {
                  result[0] += 0.00028113840080147844;
                }
              } else {
                result[0] += -0.0004797563040932977;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01218550000000000189) ) ) {
                result[0] += 0.0003078814909376976;
              } else {
                result[0] += 0.0029419141882918273;
              }
            }
          } else {
            if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.02448774902434403) ) ) {
              result[0] += -0.00013515981333371728;
            } else {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.097216905567068856) ) ) {
                result[0] += 0.00035477854815110647;
              } else {
                if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.180517123172382332) ) ) {
                  result[0] += -0.0002995921997872587;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8388933876381911015) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7954292854522614364) ) ) {
                      result[0] += -0.00017181907224452897;
                    } else {
                      result[0] += 0.00022920344953346013;
                    }
                  } else {
                    result[0] += -0.00011105137626572578;
                  }
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.08404042173159891049) ) ) {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.007543500000000000726) ) ) {
                result[0] += 9.88024637105921e-05;
              } else {
                result[0] += 0.00014219328602241188;
              }
            } else {
              result[0] += 2.078590693410681e-05;
            }
          } else {
            result[0] += 7.907584328813176e-05;
          }
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6732382808793971884) ) ) {
          result[0] += -0.0005946657303371784;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7894192122613066243) ) ) {
            result[0] += 1.4532276371162243e-06;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.96280210579579717) ) ) {
                result[0] += -0.00011005808687133206;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.578971790991679312e-05) ) ) {
                    result[0] += -0.00011042167385246224;
                  } else {
                    result[0] += 0.000288171604139809;
                  }
                } else {
                  result[0] += -7.752390569424032e-05;
                }
              }
            } else {
              result[0] += -0.00019171902719800028;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 6.801536019983193e-05;
        } else {
          result[0] += 6.801536019983193e-05;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01657900000000000346) ) ) {
            result[0] += 6.801536019983193e-05;
          } else {
            result[0] += -3.7512581834218645e-05;
          }
        } else {
          result[0] += 6.801536019983193e-05;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 6.801536019983193e-05;
        } else {
          result[0] += 6.801536019983193e-05;
        }
      } else {
        result[0] += 6.801536019983193e-05;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -9.845673650818484e-05;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01881166515770610337) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7847910031909549611) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.966590843157139501) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.08500000000000000611) ) ) {
                  result[0] += -0.0001067538292402792;
                } else {
                  result[0] += 0.0016637691033112747;
                }
              } else {
                result[0] += 0.00026182401002563025;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7983409114572864729) ) ) {
                result[0] += -0.00024082109323037172;
              } else {
                result[0] += -0.00010013705735599194;
              }
            }
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.146109394227906586) ) ) {
              result[0] += 0.0011426884829527843;
            } else {
              result[0] += -5.443320704306864e-05;
            }
          }
        } else {
          if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.07274795227358500649) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.8950000000000001288) ) ) {
              result[0] += 0.0002283066418473065;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.020650504707780553) ) ) {
                result[0] += 6.985987749443655e-05;
              } else {
                result[0] += 0.0001607815662683972;
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.1513805188710139749) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5478500007788945636) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.04460350000000000426) ) ) {
                  result[0] += -0.0011544491453640982;
                } else {
                  result[0] += 0.00023412216343715172;
                }
              } else {
                if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004657500000000001049) ) ) {
                  result[0] += -0.00018218289687220093;
                } else {
                  result[0] += 7.23998311076932e-05;
                }
              }
            } else {
              result[0] += 0.00017574278711361574;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6732382808793971884) ) ) {
          result[0] += -0.000573575239428552;
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.7894192122613066243) ) ) {
            result[0] += 1.4016872797268953e-06;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
              if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.96280210579579717) ) ) {
                result[0] += -0.00010615475267505253;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.496729916098519464) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)2.578971790991679312e-05) ) ) {
                    result[0] += -0.00010650544463377125;
                  } else {
                    result[0] += 0.00027795127314177273;
                  }
                } else {
                  result[0] += -7.477443293192302e-05;
                }
              }
            } else {
              result[0] += -0.00018491949563959533;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 6.560311872910103e-05;
        } else {
          result[0] += 6.560311872910103e-05;
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01657900000000000346) ) ) {
            result[0] += 6.560311872910103e-05;
          } else {
            result[0] += -3.618215580531989e-05;
          }
        } else {
          result[0] += 6.560311872910103e-05;
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 6.560311872910103e-05;
        } else {
          result[0] += 6.560311872910103e-05;
        }
      } else {
        result[0] += 6.560311872910103e-05;
      }
    }
  }
}

