
#include "header.h"

void predict_unit15(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -6.329569722919825e-06;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.039722088301102687) ) ) {
              result[0] += -8.258723025786577e-06;
            } else {
              result[0] += 1.987503369190195e-05;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
              result[0] += -4.70762094021815e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                    result[0] += -6.971637359858827e-06;
                  } else {
                    result[0] += -7.713585363840872e-06;
                  }
                } else {
                  result[0] += 9.859664502248042e-06;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
                  result[0] += 1.0106324516563106e-05;
                } else {
                  result[0] += -0.0006259492196073466;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -6.824458460698734e-06;
          } else {
            result[0] += -0.00015530226209986962;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 5.684612374826808e-07;
        } else {
          result[0] += 1.5447767673800227e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 4.217482000349275e-06;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 4.217482000349275e-06;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 4.217482000349275e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03350035677887956004) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03018900000000000403) ) ) {
                  result[0] += 4.217482000349275e-06;
                } else {
                  result[0] += 4.217482000349275e-06;
                }
              } else {
                result[0] += 4.217482000349275e-06;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 4.130400694181487e-06;
          } else {
            result[0] += -2.2869294597683854e-06;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            result[0] += 4.217482000349275e-06;
          } else {
            result[0] += 4.217482000349275e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 4.217482000349275e-06;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                result[0] += 4.217482000349275e-06;
              } else {
                result[0] += 4.217482000349275e-06;
              }
            } else {
              result[0] += 4.217482000349275e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 4.217482000349275e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 4.217482000349275e-06;
              } else {
                result[0] += 4.217482000349275e-06;
              }
            }
          }
        }
      } else {
        result[0] += 4.217482000349275e-06;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -6.1050843929495675e-06;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5350000000000001421) ) ) {
              result[0] += -1.3109056643996174e-05;
            } else {
              result[0] += 1.1731023657750426e-05;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
              result[0] += -4.5406598533826355e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                    result[0] += -6.724380376892995e-06;
                  } else {
                    result[0] += -7.440014357997373e-06;
                  }
                } else {
                  result[0] += 9.509980378985869e-06;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
                  result[0] += 9.747892317661469e-06;
                } else {
                  result[0] += -0.0006037492244640158;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -6.582421343409233e-06;
          } else {
            result[0] += -0.00014979429219373567;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 5.48300118471775e-07;
        } else {
          result[0] += 1.489989516818581e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 4.067904243894027e-06;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 4.067904243894027e-06;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 4.067904243894027e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03350035677887956004) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03018900000000000403) ) ) {
                  result[0] += 4.067904243894027e-06;
                } else {
                  result[0] += 4.067904243894027e-06;
                }
              } else {
                result[0] += 4.067904243894027e-06;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 3.983911374477022e-06;
          } else {
            result[0] += -2.205820926822763e-06;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            result[0] += 4.067904243894027e-06;
          } else {
            result[0] += 4.067904243894027e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 4.067904243894027e-06;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                result[0] += 4.067904243894027e-06;
              } else {
                result[0] += 4.067904243894027e-06;
              }
            } else {
              result[0] += 4.067904243894027e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 4.067904243894027e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 4.067904243894027e-06;
              } else {
                result[0] += 4.067904243894027e-06;
              }
            }
          }
        }
      } else {
        result[0] += 4.067904243894027e-06;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -5.888560688425838e-06;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.039722088301102687) ) ) {
              result[0] += -7.500890616968328e-06;
            } else {
              result[0] += 1.9299722778208255e-05;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
              result[0] += -4.3796202298236436e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                    result[0] += -6.485892641733623e-06;
                  } else {
                    result[0] += -7.176145856463876e-06;
                  }
                } else {
                  result[0] += 9.172698197599667e-06;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
                  result[0] += 9.40217232100496e-06;
                } else {
                  result[0] += -0.0005823365771900108;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -6.348968345501978e-06;
          } else {
            result[0] += -0.00014448166865330546;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 5.288540362883087e-07;
        } else {
          result[0] += 1.4371453578982525e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 3.923631431293143e-06;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 3.923631431293143e-06;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 3.923631431293143e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03350035677887956004) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03018900000000000403) ) ) {
                  result[0] += 3.923631431293143e-06;
                } else {
                  result[0] += 3.923631431293143e-06;
                }
              } else {
                result[0] += 3.923631431293143e-06;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 3.842617463734589e-06;
          } else {
            result[0] += -2.1275889994903484e-06;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            result[0] += 3.923631431293143e-06;
          } else {
            result[0] += 3.923631431293143e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 3.923631431293143e-06;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                result[0] += 3.923631431293143e-06;
              } else {
                result[0] += 3.923631431293143e-06;
              }
            } else {
              result[0] += 3.923631431293143e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 3.923631431293143e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 3.923631431293143e-06;
              } else {
                result[0] += 3.923631431293143e-06;
              }
            }
          }
        }
      } else {
        result[0] += 3.923631431293143e-06;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -5.679716241321562e-06;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.5350000000000001421) ) ) {
              result[0] += -1.2378101616390697e-05;
            } else {
              result[0] += 1.1538504724532056e-05;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
              result[0] += -4.224292058166672e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                    result[0] += -6.255863143115552e-06;
                  } else {
                    result[0] += -6.921635748980611e-06;
                  }
                } else {
                  result[0] += 8.847378109229943e-06;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
                  result[0] += 9.06871367400161e-06;
                } else {
                  result[0] += -0.0005616833536050184;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -6.123795021500202e-06;
          } else {
            result[0] += -0.00013935746329936914;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 5.10097631344636e-07;
        } else {
          result[0] += 1.3861753766821802e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 3.784475416730162e-06;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 3.784475416730162e-06;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 3.784475416730162e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03350035677887956004) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03018900000000000403) ) ) {
                  result[0] += 3.784475416730162e-06;
                } else {
                  result[0] += 3.784475416730162e-06;
                }
              } else {
                result[0] += 3.784475416730162e-06;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 3.7063347009138745e-06;
          } else {
            result[0] += -2.0521316557040703e-06;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            result[0] += 3.784475416730162e-06;
          } else {
            result[0] += 3.784475416730162e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 3.784475416730162e-06;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                result[0] += 3.784475416730162e-06;
              } else {
                result[0] += 3.784475416730162e-06;
              }
            } else {
              result[0] += 3.784475416730162e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 3.784475416730162e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 3.784475416730162e-06;
              } else {
                result[0] += 3.784475416730162e-06;
              }
            }
          }
        }
      } else {
        result[0] += 3.784475416730162e-06;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -5.478278698110113e-06;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9750000000000000888) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.146109394227906586) ) ) {
                result[0] += 0.0007575377134940371;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01332150000000000174) ) ) {
                  result[0] += -1.1939098280081876e-05;
                } else {
                  result[0] += 5.608497872832861e-05;
                }
              }
            } else {
              result[0] += -1.107378462681208e-05;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
              result[0] += -4.0744727753275016e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                    result[0] += -6.033991900138963e-06;
                  } else {
                    result[0] += -6.676152129546332e-06;
                  }
                } else {
                  result[0] += 8.533595864753866e-06;
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  result[0] += 7.909473371713086e-06;
                } else {
                  result[0] += -0.00010415538124154697;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -5.906607723429383e-06;
          } else {
            result[0] += -0.00013441499366840907;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 4.920064434594926e-07;
        } else {
          result[0] += 1.3370131033440125e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 3.650254727192793e-06;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 3.650254727192793e-06;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 3.650254727192793e-06;
            } else {
              result[0] += 3.650254727192793e-06;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 3.5748853600045173e-06;
          } else {
            result[0] += -1.9793504917320806e-06;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            result[0] += 3.650254727192793e-06;
          } else {
            result[0] += 3.650254727192793e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 3.650254727192793e-06;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                result[0] += 3.650254727192793e-06;
              } else {
                result[0] += 3.650254727192793e-06;
              }
            } else {
              result[0] += 3.650254727192793e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 3.650254727192793e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 3.650254727192793e-06;
              } else {
                result[0] += 3.650254727192793e-06;
              }
            }
          }
        }
      } else {
        result[0] += 3.650254727192793e-06;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -5.2839853645899716e-06;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.039722088301102687) ) ) {
              result[0] += -6.372426146141859e-06;
            } else {
              result[0] += 1.860674585850192e-05;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
              result[0] += -3.929967002350191e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                    result[0] += -5.8199895710650315e-06;
                  } else {
                    result[0] += -6.439374863580513e-06;
                  }
                } else {
                  result[0] += 8.23094226152473e-06;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
                  result[0] += 8.46656311905106e-06;
                } else {
                  result[0] += -0.0005380686318084039;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -5.697123217871653e-06;
          } else {
            result[0] += -0.0001296478142980105;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 4.745568799595336e-07;
        } else {
          result[0] += 1.2895944254847677e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 3.5207943258115396e-06;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 3.5207943258115396e-06;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 3.5207943258115396e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03350035677887956004) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03018900000000000403) ) ) {
                  result[0] += 3.5207943258115396e-06;
                } else {
                  result[0] += 3.5207943258115396e-06;
                }
              } else {
                result[0] += 3.5207943258115396e-06;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 3.448098018247274e-06;
          } else {
            result[0] += -1.9091505938378635e-06;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            result[0] += 3.5207943258115396e-06;
          } else {
            result[0] += 3.5207943258115396e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 3.5207943258115396e-06;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                result[0] += 3.5207943258115396e-06;
              } else {
                result[0] += 3.5207943258115396e-06;
              }
            } else {
              result[0] += 3.5207943258115396e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 3.5207943258115396e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 3.5207943258115396e-06;
              } else {
                result[0] += 3.5207943258115396e-06;
              }
            }
          }
        }
      } else {
        result[0] += 3.5207943258115396e-06;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -5.0965828633057304e-06;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
            result[0] += -2.8606203777891623e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
              result[0] += -3.7905862896138566e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                    result[0] += -5.613577075986073e-06;
                  } else {
                    result[0] += -6.210995170436638e-06;
                  }
                } else {
                  result[0] += 7.939022609726223e-06;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005046500000000001505) ) ) {
                    result[0] += 5.569645022585875e-05;
                  } else {
                    result[0] += 5.073991892683537e-07;
                  }
                } else {
                  result[0] += -0.0005189854208405582;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -5.495068316601794e-06;
          } else {
            result[0] += -0.00012504970832135452;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 4.5772618491218697e-07;
        } else {
          result[0] += 1.2438575045240115e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 3.395925383593141e-06;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 3.395925383593141e-06;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 3.395925383593141e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03350035677887956004) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03018900000000000403) ) ) {
                  result[0] += 3.395925383593141e-06;
                } else {
                  result[0] += 3.395925383593141e-06;
                }
              } else {
                result[0] += 3.395925383593141e-06;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 3.3258073325806846e-06;
          } else {
            result[0] += -1.841440414507881e-06;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            result[0] += 3.395925383593141e-06;
          } else {
            result[0] += 3.395925383593141e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 3.395925383593141e-06;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                result[0] += 3.395925383593141e-06;
              } else {
                result[0] += 3.395925383593141e-06;
              }
            } else {
              result[0] += 3.395925383593141e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 3.395925383593141e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 3.395925383593141e-06;
              } else {
                result[0] += 3.395925383593141e-06;
              }
            }
          }
        }
      } else {
        result[0] += 3.395925383593141e-06;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -4.915826803119337e-06;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
            result[0] += -2.759165249314256e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
              result[0] += -3.65614887107599e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                    result[0] += -5.414485232878132e-06;
                  } else {
                    result[0] += -5.990715220722128e-06;
                  }
                } else {
                  result[0] += 7.657456217664257e-06;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005046500000000001505) ) ) {
                    result[0] += 5.372111279307075e-05;
                  } else {
                    result[0] += 4.89403704675285e-07;
                  }
                } else {
                  result[0] += -0.0005005790174755261;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -5.300179520323152e-06;
          } else {
            result[0] += -0.00012061467935981995;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 4.41492409449698e-07;
        } else {
          result[0] += 1.1997426950563195e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 3.2754850592653283e-06;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 3.2754850592653283e-06;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 3.2754850592653283e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03350035677887956004) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03018900000000000403) ) ) {
                  result[0] += 3.2754850592653283e-06;
                } else {
                  result[0] += 3.2754850592653283e-06;
                }
              } else {
                result[0] += 3.2754850592653283e-06;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 3.2078538240258006e-06;
          } else {
            result[0] += -1.7761316530656262e-06;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            result[0] += 3.2754850592653283e-06;
          } else {
            result[0] += 3.2754850592653283e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 3.2754850592653283e-06;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                result[0] += 3.2754850592653283e-06;
              } else {
                result[0] += 3.2754850592653283e-06;
              }
            } else {
              result[0] += 3.2754850592653283e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 3.2754850592653283e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 3.2754850592653283e-06;
              } else {
                result[0] += 3.2754850592653283e-06;
              }
            }
          }
        }
      } else {
        result[0] += 3.2754850592653283e-06;
      }
    }
  }
}

