
#include "header.h"

void predict_unit10(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.00012707464250152212;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3350000000000000755) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9079021320180030719) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
                result[0] += -9.782013635805357e-05;
              } else {
                result[0] += -0.0006173732943680508;
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6586934769095478259) ) ) {
                result[0] += -0.0012087870812045824;
              } else {
                result[0] += 0.00022767639010031547;
              }
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.130629626450776108e-06) ) ) {
              result[0] += -0.00013611838774648435;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001570360081376600365) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)65.50000000000001421) ) ) {
                  result[0] += -0.0001345844060364808;
                } else {
                  result[0] += 0.00014051639492116888;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.786764172562814168) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7683067979899498301) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01225471801880190052) ) ) {
                        result[0] += -0.0008059602965431864;
                      } else {
                        result[0] += -0.00015945014102758257;
                      }
                    } else {
                      result[0] += 0.001165111512822021;
                    }
                  } else {
                    result[0] += -0.0008840198764155927;
                  }
                } else {
                  result[0] += -2.1059895053734596e-05;
                }
              }
            }
          }
        } else {
          result[0] += -0.00013607449953603168;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08495625534650631805) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2669585275879397535) ) ) {
            result[0] += 0.0002830771069856203;
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)89.50000000000001421) ) ) {
              result[0] += -1.440393521916098e-05;
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3539353041941689093) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02085144663384500344) ) ) {
                  result[0] += 0.00019300440991248212;
                } else {
                  result[0] += 0.000253905239509723;
                }
              } else {
                result[0] += 6.764038719583754e-05;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)14.50000000000000178) ) ) {
            result[0] += -1.2288624774961951e-05;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6915080527790725684) ) ) {
              result[0] += 0.00013606810720801516;
            } else {
              result[0] += 2.7334024232568073e-05;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 8.05196771142872e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          result[0] += 8.05196771142872e-05;
        } else {
          result[0] += -2.6985853001356052e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            result[0] += 8.05196771142872e-05;
          } else {
            result[0] += 8.05196771142872e-05;
          }
        } else {
          result[0] += 8.05196771142872e-05;
        }
      } else {
        result[0] += 8.05196771142872e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.000123438954659266;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.3350000000000000755) ) ) {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
            result[0] += -7.910085331090506e-05;
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.130629626450776108e-06) ) ) {
              result[0] += -0.00013222395249413673;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.001570360081376600365) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)65.50000000000001421) ) ) {
                  result[0] += -0.00013073385899458587;
                } else {
                  result[0] += 0.00013649612983447835;
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.786764172562814168) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7683067979899498301) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01225471801880190052) ) ) {
                        result[0] += -0.000782901250349544;
                      } else {
                        result[0] += -0.00015488816919930796;
                      }
                    } else {
                      result[0] += 0.0011317769176687124;
                    }
                  } else {
                    result[0] += -0.0008587274950739848;
                  }
                } else {
                  result[0] += -2.0457357813425876e-05;
                }
              }
            }
          }
        } else {
          result[0] += -0.00013218131995381636;
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08495625534650631805) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2669585275879397535) ) ) {
            result[0] += 0.00027497808757444015;
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)89.50000000000001421) ) ) {
              result[0] += -1.399182930152148e-05;
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3539353041941689093) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02085144663384500344) ) ) {
                  result[0] += 0.00018748242871460428;
                } else {
                  result[0] += 0.00024664084612486934;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04324794178047625809) ) ) {
                  result[0] += 2.8190956650298196e-05;
                } else {
                  result[0] += 0.00015663918935880755;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)14.50000000000000178) ) ) {
            result[0] += -1.19370392594496e-05;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6915080527790725684) ) ) {
              result[0] += 0.00013217511051444558;
            } else {
              result[0] += 2.655198009200534e-05;
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 7.821595699055457e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            result[0] += 7.821595699055457e-05;
          } else {
            result[0] += 7.821595699055457e-05;
          }
        } else {
          result[0] += -2.6213770265275866e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            result[0] += 7.821595699055457e-05;
          } else {
            result[0] += 7.821595699055457e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 7.821595699055457e-05;
          } else {
            result[0] += 7.821595699055457e-05;
          }
        }
      } else {
        result[0] += 7.821595699055457e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.00011990728620141358;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01163003332820435227) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.435405567110552727) ) ) {
            result[0] += 0.00015279531663572036;
          } else {
            result[0] += -0.0001269069578472113;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08495625534650631805) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)44.50000000000000711) ) ) {
              result[0] += -6.419064484692962e-05;
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01778816268138619719) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3044402794723619077) ) ) {
                  result[0] += 0.00033424658251612774;
                } else {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5510720942211057016) ) ) {
                    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
                      result[0] += 0.0001414246168941621;
                    } else {
                      result[0] += 0.0001589131331543458;
                    }
                  } else {
                    result[0] += 0.0008684097365990229;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001962500000000000269) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.156847194217679814) ) ) {
                    result[0] += -0.000857363650778965;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8036796978107810796) ) ) {
                      result[0] += 0.00014756484133945377;
                    } else {
                      result[0] += -0.0006893879812096213;
                    }
                  }
                } else {
                  result[0] += 7.29998538058498e-05;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)14.50000000000000178) ) ) {
              result[0] += -6.267000790976236e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6915080527790725684) ) ) {
                result[0] += 0.00013235795723835186;
              } else {
                result[0] += 2.5188709044398468e-05;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9189305784170854752) ) ) {
            result[0] += -0.00012844093955721484;
          } else {
            result[0] += -0.00012839952676149083;
          }
        } else {
          result[0] += -0.00037601237354035344;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 7.597814779193724e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 7.597814779193724e-05;
            } else {
              result[0] += 7.597814779193724e-05;
            }
          } else {
            result[0] += 7.597814779193724e-05;
          }
        } else {
          result[0] += -2.546377731642229e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 7.597814779193724e-05;
            } else {
              result[0] += 7.597814779193724e-05;
            }
          } else {
            result[0] += 7.597814779193724e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 7.597814779193724e-05;
          } else {
            result[0] += 7.597814779193724e-05;
          }
        }
      } else {
        result[0] += 7.597814779193724e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.0001164766610659922;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01163003332820435227) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.435405567110552727) ) ) {
            result[0] += 0.00014842374364436263;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02424450000000000563) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9450000000000000622) ) ) {
                result[0] += -0.00012478955015660928;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0001725283487249000298) ) ) {
                  result[0] += 0.0006393108801870468;
                } else {
                  result[0] += 4.5422666541234946e-05;
                }
              }
            } else {
              result[0] += -0.00044729010506608873;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08495625534650631805) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)49.50000000000000711) ) ) {
              result[0] += -4.724224379881748e-05;
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4992188184422110542) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02447420998234165271) ) ) {
                  result[0] += 0.0002048556364373291;
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)111.5000000000000142) ) ) {
                    result[0] += 0.00016809234954408685;
                  } else {
                    result[0] += 0.00024088402969433818;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001962500000000000269) ) ) {
                  result[0] += -0.00033119824947541396;
                } else {
                  result[0] += 0.00010130947922791919;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)14.50000000000000178) ) ) {
              result[0] += -6.087697838517313e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6915080527790725684) ) ) {
                result[0] += 0.0001285711103388893;
              } else {
                result[0] += 2.4468043761128053e-05;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9189305784170854752) ) ) {
            result[0] += -0.00012476616107109378;
          } else {
            result[0] += -0.0001247259331222831;
          }
        } else {
          result[0] += -0.00036525441594860056;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 7.380436376416851e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 7.380436376416851e-05;
            } else {
              result[0] += 7.380436376416851e-05;
            }
          } else {
            result[0] += 7.380436376416851e-05;
          }
        } else {
          result[0] += -2.47352421516888e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 7.380436376416851e-05;
            } else {
              result[0] += 7.380436376416851e-05;
            }
          } else {
            result[0] += 7.380436376416851e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 7.380436376416851e-05;
          } else {
            result[0] += 7.380436376416851e-05;
          }
        }
      } else {
        result[0] += 7.380436376416851e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.00011314418833809023;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01163003332820435227) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.435405567110552727) ) ) {
            result[0] += 0.00014417724418823915;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02424450000000000563) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9450000000000000622) ) ) {
                result[0] += -0.00012121924028664791;
              } else {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0001725283487249000298) ) ) {
                  result[0] += 0.0006210197817525938;
                } else {
                  result[0] += 4.412309462620854e-05;
                }
              }
            } else {
              result[0] += -0.00043449284540092177;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08495625534650631805) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)49.50000000000000711) ) ) {
              result[0] += -4.5890612599711785e-05;
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3197884335317744964) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4573392949246231631) ) ) {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3044402794723619077) ) ) {
                    result[0] += 0.0003060096765895867;
                  } else {
                    result[0] += 0.00012908728266339232;
                  }
                } else {
                  result[0] += 0.0005728789798124851;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002165500000000000324) ) ) {
                  result[0] += -0.00022839496557828485;
                } else {
                  result[0] += 0.00011264951375085078;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)14.50000000000000178) ) ) {
              result[0] += -5.913524859683334e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6915080527790725684) ) ) {
                result[0] += 0.00012489260758237749;
              } else {
                result[0] += 2.376799717846654e-05;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9189305784170854752) ) ) {
            result[0] += -0.00012119652037802071;
          } else {
            result[0] += -0.00012115744337688559;
          }
        } else {
          result[0] += -0.00035480425049266574;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 7.169277310563473e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 7.169277310563473e-05;
            } else {
              result[0] += 7.169277310563473e-05;
            }
          } else {
            result[0] += 7.169277310563473e-05;
          }
        } else {
          result[0] += -2.4027550849993814e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 7.169277310563473e-05;
            } else {
              result[0] += 7.169277310563473e-05;
            }
          } else {
            result[0] += 7.169277310563473e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 7.169277310563473e-05;
          } else {
            result[0] += 7.169277310563473e-05;
          }
        }
      } else {
        result[0] += 7.169277310563473e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.00010990705981374435;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01163003332820435227) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.435405567110552727) ) ) {
            result[0] += 0.00014005223983248088;
          } else {
            result[0] += -0.000116237596709884;
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08495625534650631805) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)49.50000000000000711) ) ) {
              result[0] += -4.457765244481253e-05;
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3197884335317744964) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4573392949246231631) ) ) {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3044402794723619077) ) ) {
                    result[0] += 0.00029725454150607815;
                  } else {
                    result[0] += 0.00012539401188229644;
                  }
                } else {
                  result[0] += 0.0005564885410830315;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002165500000000000324) ) ) {
                  result[0] += -0.00022186043765643452;
                } else {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.3872449054220527542) ) ) {
                    result[0] += 0.00015460613121437569;
                  } else {
                    if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6586934769095478259) ) ) {
                      result[0] += -0.0007918798677268157;
                    } else {
                      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7293938685427137081) ) ) {
                        result[0] += 0.000234742404645499;
                      } else {
                        result[0] += -1.961921697455419e-05;
                      }
                    }
                  }
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)14.50000000000000178) ) ) {
              result[0] += -5.7443350826044065e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6915080527790725684) ) ) {
                result[0] += 0.0001213193491727021;
              } else {
                result[0] += 2.3087979382032502e-05;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9189305784170854752) ) ) {
            result[0] += -0.0001177290094176272;
          } else {
            result[0] += -0.00011769105043480903;
          }
        } else {
          result[0] += -0.00034465307104015195;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 6.964159642375264e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 6.964159642375264e-05;
            } else {
              result[0] += 6.964159642375264e-05;
            }
          } else {
            result[0] += 6.964159642375264e-05;
          }
        } else {
          result[0] += -2.334010705487361e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 6.964159642375264e-05;
            } else {
              result[0] += 6.964159642375264e-05;
            }
          } else {
            result[0] += 6.964159642375264e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 6.964159642375264e-05;
          } else {
            result[0] += 6.964159642375264e-05;
          }
        }
      } else {
        result[0] += 6.964159642375264e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.00010676254763352588;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01163003332820435227) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.435405567110552727) ) ) {
            result[0] += 0.000136045254523562;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02424450000000000563) ) ) {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9450000000000000622) ) ) {
                result[0] += -0.00011442544635314508;
              } else {
                result[0] += 0.00010310008978645527;
              }
            } else {
              result[0] += -0.0004187360906831691;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08495625534650631805) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)44.50000000000000711) ) ) {
              result[0] += -5.841412204616179e-05;
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3197884335317744964) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                  result[0] += 8.044972791743788e-05;
                } else {
                  result[0] += 0.0002457951904275666;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002165500000000000324) ) ) {
                  result[0] += -0.0002179268692624461;
                } else {
                  result[0] += 0.00011181041537223337;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)14.50000000000000178) ) ) {
              result[0] += -5.579985934650571e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6915080527790725684) ) ) {
                result[0] += 0.00011784832400092306;
              } else {
                result[0] += 2.242741733527711e-05;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9189305784170854752) ) ) {
            result[0] += -0.00011436070619210056;
          } else {
            result[0] += -0.00011432383324037104;
          }
        } else {
          result[0] += -0.0003347923234078152;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 6.764910523551174e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 6.764910523551174e-05;
            } else {
              result[0] += 6.764910523551174e-05;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 6.764910523551174e-05;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 6.764910523551174e-05;
              } else {
                result[0] += 6.764910523551174e-05;
              }
            }
          }
        } else {
          result[0] += -2.2672331472068015e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 6.764910523551174e-05;
            } else {
              result[0] += 6.764910523551174e-05;
            }
          } else {
            result[0] += 6.764910523551174e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 6.764910523551174e-05;
          } else {
            result[0] += 6.764910523551174e-05;
          }
        }
      } else {
        result[0] += 6.764910523551174e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.00010370800198383148;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05732259783002840309) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.00933301618409165118) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8155157533417086713) ) ) {
                result[0] += -0.00010473541194210805;
              } else {
                result[0] += 0.00017734948677555464;
              }
            } else {
              result[0] += -0.00013369894825020394;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3044402794723619077) ) ) {
              result[0] += 0.00028924212850695637;
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)49.50000000000000711) ) ) {
                result[0] += -5.7812957549162176e-05;
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02620539606947270075) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4914057384422110819) ) ) {
                      result[0] += 8.432706124010251e-05;
                    } else {
                      result[0] += 0.0013187522932541751;
                    }
                  } else {
                    result[0] += 0.00021675621179062784;
                  }
                } else {
                  result[0] += 3.1916703601303845e-05;
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)18.50000000000000355) ) ) {
            result[0] += 6.387194181150089e-06;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.09274867639439776656) ) ) {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9650000000000000799) ) ) {
                result[0] += 0.0002003143032545097;
              } else {
                result[0] += 7.218701073361375e-05;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
                result[0] += 4.711088042135435e-05;
              } else {
                result[0] += 0.00015076420585597865;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9189305784170854752) ) ) {
            result[0] += -0.00011108877230387842;
          } else {
            result[0] += -0.00011105295431118457;
          }
        } else {
          result[0] += -0.00032521369815313554;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 6.571362051092374e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 6.571362051092374e-05;
            } else {
              result[0] += 6.571362051092374e-05;
            }
          } else {
            result[0] += 6.571362051092374e-05;
          }
        } else {
          result[0] += -2.2023661381272867e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 6.571362051092374e-05;
            } else {
              result[0] += 6.571362051092374e-05;
            }
          } else {
            result[0] += 6.571362051092374e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 6.571362051092374e-05;
          } else {
            result[0] += 6.571362051092374e-05;
          }
        }
      } else {
        result[0] += 6.571362051092374e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -0.00010074084886394156;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05732259783002840309) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6750000000000001554) ) ) {
            result[0] += -0.00010090864231360434;
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.4589535259190716254) ) ) {
              if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.5724391781153673753) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)171.5000000000000284) ) ) {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3044402794723619077) ) ) {
                    result[0] += 0.00017199213042048717;
                  } else {
                    result[0] += -0.00018313452863009082;
                  }
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01587740346364930125) ) ) {
                    result[0] += 0.000135149459644461;
                  } else {
                    result[0] += 0.0002514359251138886;
                  }
                }
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4086612272110553001) ) ) {
                  result[0] += 7.582430858833232e-05;
                } else {
                  result[0] += 0.00039891386776893324;
                }
              }
            } else {
              result[0] += 3.256295263096816e-05;
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)18.50000000000000355) ) ) {
            result[0] += 6.2044524179370185e-06;
          } else {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.194581012612933923) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1545146459385556281) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.09274867639439776656) ) ) {
                  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9650000000000000799) ) ) {
                    result[0] += 0.00017974165981677145;
                  } else {
                    result[0] += 7.049693373885246e-05;
                  }
                } else {
                  result[0] += 9.091035268151852e-05;
                }
              } else {
                result[0] += 0.00015529903496802136;
              }
            } else {
              result[0] += -0.0005556356932244287;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9189305784170854752) ) ) {
            result[0] += -0.00010791045056379144;
          } else {
            result[0] += -0.00010787565734707183;
          }
        } else {
          result[0] += -0.00031590912357212623;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 6.383351125813396e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 6.383351125813396e-05;
            } else {
              result[0] += 6.383351125813396e-05;
            }
          } else {
            result[0] += 6.383351125813396e-05;
          }
        } else {
          result[0] += -2.13935501619958e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 6.383351125813396e-05;
            } else {
              result[0] += 6.383351125813396e-05;
            }
          } else {
            result[0] += 6.383351125813396e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 6.383351125813396e-05;
          } else {
            result[0] += 6.383351125813396e-05;
          }
        }
      } else {
        result[0] += 6.383351125813396e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -9.785858791696463e-05;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01163003332820435227) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2575587311557789305) ) ) {
            result[0] += 0.0008680214958045334;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1550000000000000266) ) ) {
              result[0] += -0.00010528854972127992;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.000726282482777400166) ) ) {
                result[0] += 0.00030283871767740057;
              } else {
                result[0] += -0.00011179184182332024;
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08495625534650631805) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)44.50000000000000711) ) ) {
              result[0] += -5.427543743330208e-05;
            } else {
              if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3197884335317744964) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)83.50000000000001421) ) ) {
                  result[0] += 7.049913182495121e-05;
                } else {
                  result[0] += 0.00022881681640900232;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001999500000000000409) ) ) {
                  result[0] += -0.00023847790514322078;
                } else {
                  result[0] += 0.00010169635707248695;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)14.50000000000000178) ) ) {
              result[0] += -5.7805940884868296e-06;
            } else {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6915080527790725684) ) ) {
                result[0] += 0.00010971602617944626;
              } else {
                result[0] += 3.546699205540275e-05;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9189305784170854752) ) ) {
            result[0] += -0.00010482306266763854;
          } else {
            result[0] += -0.00010478926490738868;
          }
        } else {
          result[0] += -0.00030687075889748066;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 6.200719314901922e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 6.200719314901922e-05;
            } else {
              result[0] += 6.200719314901922e-05;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 6.200719314901922e-05;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 6.200719314901922e-05;
              } else {
                result[0] += 6.200719314901922e-05;
              }
            }
          }
        } else {
          result[0] += -2.078146683288006e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 6.200719314901922e-05;
            } else {
              result[0] += 6.200719314901922e-05;
            }
          } else {
            result[0] += 6.200719314901922e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 6.200719314901922e-05;
          } else {
            result[0] += 6.200719314901922e-05;
          }
        }
      } else {
        result[0] += 6.200719314901922e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -9.505879032283961e-05;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01139456194549710172) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.435405567110552727) ) ) {
            result[0] += 0.00013598520388303042;
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01439950000000000084) ) ) {
              result[0] += -9.179238284042968e-05;
            } else {
              result[0] += -0.0004017695021922729;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08495625534650631805) ) ) {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01051018765715429869) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)51.50000000000000711) ) ) {
                result[0] += -1.4790016717410741e-05;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02803443610476625408) ) ) {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3044402794723619077) ) ) {
                    result[0] += 0.0006259840644819515;
                  } else {
                    result[0] += 0.00015058686453715706;
                  }
                } else {
                  result[0] += 0.00014391718331636014;
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5112063776130654214) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5046554252763820747) ) ) {
                  result[0] += -0.00010865864580123442;
                } else {
                  result[0] += -0.0011616283185997853;
                }
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002726500000000000191) ) ) {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
                    result[0] += -0.0005783611579752492;
                  } else {
                    result[0] += -4.241472554763512e-05;
                  }
                } else {
                  result[0] += 4.122428750904725e-05;
                }
              }
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)14.50000000000000178) ) ) {
              result[0] += -5.615207546884978e-06;
            } else {
              result[0] += 9.647085240438208e-05;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9189305784170854752) ) ) {
            result[0] += -0.00010182400693923687;
          } else {
            result[0] += -0.00010179117615480231;
          }
        } else {
          result[0] += -0.0002980909876913243;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 6.02331271841164e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 6.02331271841164e-05;
            } else {
              result[0] += 6.02331271841164e-05;
            }
          } else {
            result[0] += 6.02331271841164e-05;
          }
        } else {
          result[0] += -2.018689560433751e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 6.02331271841164e-05;
            } else {
              result[0] += 6.02331271841164e-05;
            }
          } else {
            result[0] += 6.02331271841164e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 6.02331271841164e-05;
          } else {
            result[0] += 6.02331271841164e-05;
          }
        }
      } else {
        result[0] += 6.02331271841164e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -9.233909675162075e-05;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8388933876381911015) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08495625534650631805) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.00933301618409165118) ) ) {
            result[0] += -9.370714509343654e-05;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.04034505340375655474) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)51.50000000000000711) ) ) {
                result[0] += -5.043791621316366e-06;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.02889650778201160314) ) ) {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.3044402794723619077) ) ) {
                    result[0] += 0.0005464033185797845;
                  } else {
                    result[0] += 0.000125383997974366;
                  }
                } else {
                  result[0] += 0.00013801929543803132;
                }
              }
            } else {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5085295226130653878) ) ) {
                result[0] += -0.0011251630624880625;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.0144392355375913) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7683067979899498301) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
                      result[0] += -1.530609421651287e-05;
                    } else {
                      result[0] += 0.0010590023689935448;
                    }
                  } else {
                    result[0] += -0.0007729717003101886;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.051391296366422923) ) ) {
                    result[0] += 0.0019156159226403648;
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.2150000000000000244) ) ) {
                      result[0] += 8.264727670171883e-05;
                    } else {
                      result[0] += -8.643951117006547e-05;
                    }
                  }
                }
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)14.50000000000000178) ) ) {
            result[0] += -5.4545528213766655e-06;
          } else {
            result[0] += 9.37107588222616e-05;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9189305784170854752) ) ) {
            result[0] += -9.891075613804457e-05;
          } else {
            result[0] += -9.887886466362078e-05;
          }
        } else {
          result[0] += -0.000289562411427004;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 5.850981839572821e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 5.850981839572821e-05;
            } else {
              result[0] += 5.850981839572821e-05;
            }
          } else {
            result[0] += 5.850981839572821e-05;
          }
        } else {
          result[0] += -1.960933544382378e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 5.850981839572821e-05;
            } else {
              result[0] += 5.850981839572821e-05;
            }
          } else {
            result[0] += 5.850981839572821e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 5.850981839572821e-05;
          } else {
            result[0] += 5.850981839572821e-05;
          }
        }
      } else {
        result[0] += 5.850981839572821e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -8.969721537532053e-05;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04855099859271875401) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9079021320180030719) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8440161800932387548) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)45.50000000000000711) ) ) {
                result[0] += -0.00011779943976523358;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0129473293797221032) ) ) {
                  result[0] += -9.165709683215834e-06;
                } else {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3296315496301309156) ) ) {
                    result[0] += 0.00018172452336892773;
                  } else {
                    result[0] += 0.00010586059945791124;
                  }
                }
              }
            } else {
              result[0] += -0.0006130992620832835;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6586934769095478259) ) ) {
              result[0] += -0.001092971418377834;
            } else {
              result[0] += 0.00033345372849030497;
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)25.50000000000000355) ) ) {
            result[0] += 2.52422422648668e-05;
          } else {
            result[0] += 8.691628536488861e-05;
          }
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9052692260301508087) ) ) {
          if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.130629626450776108e-06) ) ) {
            result[0] += -9.608085532950881e-05;
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.049143534958799195) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9766759383227824332) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7640286906783920751) ) ) {
                  result[0] += -0.0003197281124435708;
                } else {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7683067979899498301) ) ) {
                    result[0] += 0.000818348121607119;
                  } else {
                    result[0] += -0.00012344854769346595;
                  }
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)410.5000000000000568) ) ) {
                  result[0] += -0.00034497796323511044;
                } else {
                  result[0] += -0.0017289832165458452;
                }
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.051391296366422923) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.003328854385626850345) ) ) {
                  result[0] += 0.00024004191055518917;
                } else {
                  result[0] += 0.002192314661026312;
                }
              } else {
                result[0] += -8.483051491718475e-05;
              }
            }
          }
        } else {
          result[0] += -9.604987629082793e-05;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 5.683581458815188e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            result[0] += 5.683581458815188e-05;
          } else {
            result[0] += 5.683581458815188e-05;
          }
        } else {
          result[0] += -1.904829965362855e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            result[0] += 5.683581458815188e-05;
          } else {
            result[0] += 5.683581458815188e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 5.683581458815188e-05;
          } else {
            result[0] += 5.683581458815188e-05;
          }
        }
      } else {
        result[0] += 5.683581458815188e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -8.713091993663478e-05;
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08495625534650631805) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9079021320180030719) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)45.50000000000000711) ) ) {
                  result[0] += -9.682415812963476e-05;
                } else {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0129473293797221032) ) ) {
                    result[0] += -7.724464063934598e-06;
                  } else {
                    if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.01778816268138619719) ) ) {
                      result[0] += 0.00014064164306191567;
                    } else {
                      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6974685887185930744) ) ) {
                        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6800105846231156992) ) ) {
                          result[0] += 5.485442044106546e-05;
                        } else {
                          result[0] += -0.0009582886535914691;
                        }
                      } else {
                        result[0] += 0.00032946932258188393;
                      }
                    }
                  }
                }
              } else {
                result[0] += -0.0005737734088238615;
              }
            } else {
              result[0] += 0.0004694834614551463;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.599834298791339877e-06) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                result[0] += -0.0001276421628665211;
              } else {
                result[0] += -9.209985357067393e-05;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.025068312450985619) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9567162861906464144) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7640286906783920751) ) ) {
                    result[0] += -0.00032611705545320334;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8458243956458841861) ) ) {
                      result[0] += -0.00044387559785238;
                    } else {
                      result[0] += 0.0006282870396698945;
                    }
                  }
                } else {
                  result[0] += -0.00041477722164068;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.051391296366422923) ) ) {
                  result[0] += 0.0008053870994125591;
                } else {
                  result[0] += -8.915460694408927e-05;
                }
              }
            }
          }
        } else {
          result[0] += 8.928584840709902e-05;
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)54.50000000000000711) ) ) {
          result[0] += -9.330182710802906e-05;
        } else {
          result[0] += -9.333191981634473e-05;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 5.520970511394745e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            result[0] += 5.520970511394745e-05;
          } else {
            result[0] += 5.520970511394745e-05;
          }
        } else {
          result[0] += -1.8503315460863222e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            result[0] += 5.520970511394745e-05;
          } else {
            result[0] += 5.520970511394745e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 5.520970511394745e-05;
          } else {
            result[0] += 5.520970511394745e-05;
          }
        }
      } else {
        result[0] += 5.520970511394745e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -8.463804787292294e-05;
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0129473293797221032) ) ) {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4296173751758793902) ) ) {
              result[0] += 0.00023261734478908673;
            } else {
              result[0] += -9.546081668045064e-05;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0001725283487249000298) ) ) {
              result[0] += 0.00045972639910660576;
            } else {
              result[0] += 3.654442703008054e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1466079245622486649) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.04034505340375655474) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)50.50000000000000711) ) ) {
                if ( LIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.1000116863636408421) ) ) {
                  result[0] += -6.12061269255314e-05;
                } else {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5623076833668342323) ) ) {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5377715594472363136) ) ) {
                      result[0] += 0.00015190248990738865;
                    } else {
                      result[0] += 0.000849305434780943;
                    }
                  } else {
                    result[0] += -0.00037100806111944873;
                  }
                }
              } else {
                result[0] += 0.00012186192277584822;
              }
            } else {
              result[0] += 2.975856075630385e-06;
            }
          } else {
            result[0] += 0.00012922294463723068;
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)54.50000000000000711) ) ) {
          result[0] += -9.063240139256516e-05;
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
              result[0] += -9.063154042068588e-05;
            } else {
              result[0] += -0.00010009279570600144;
            }
          } else {
            result[0] += -0.0005397841542945943;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 5.363011968521021e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 5.363011968521021e-05;
            } else {
              result[0] += 5.363011968521021e-05;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 5.363011968521021e-05;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 5.363011968521021e-05;
              } else {
                result[0] += 5.363011968521021e-05;
              }
            }
          }
        } else {
          result[0] += -1.7973923618883756e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 5.363011968521021e-05;
            } else {
              result[0] += 5.363011968521021e-05;
            }
          } else {
            result[0] += 5.363011968521021e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 5.363011968521021e-05;
          } else {
            result[0] += 5.363011968521021e-05;
          }
        }
      } else {
        result[0] += 5.363011968521021e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -8.221649849386259e-05;
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01184520638735680163) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4378622240954774258) ) ) {
            result[0] += 0.00013426078847770845;
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.3763018001168558224) ) ) {
              result[0] += -0.001097463959097161;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01265500000000000132) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)90.50000000000001421) ) ) {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1950000000000000344) ) ) {
                    result[0] += -0.00010125800599528275;
                  } else {
                    result[0] += -4.323653821359048e-05;
                  }
                } else {
                  result[0] += 2.1495792757650832e-05;
                }
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9194299814036738239) ) ) {
                  if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.05227730674148379358) ) ) {
                    result[0] += -0.0007160644696525856;
                  } else {
                    result[0] += 9.279309933691512e-05;
                  }
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9911809338528255742) ) ) {
                    result[0] += -0.001013681951687036;
                  } else {
                    result[0] += -0.0002635440149743399;
                  }
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1466079245622486649) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.04034505340375655474) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)50.50000000000000711) ) ) {
                result[0] += 1.536082703532979e-05;
              } else {
                result[0] += 0.00011714622727022417;
              }
            } else {
              result[0] += 3.8946992526555065e-06;
            }
          } else {
            result[0] += 0.00012552579247917893;
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)54.50000000000000711) ) ) {
          result[0] += -8.80393496761027e-05;
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
              result[0] += -8.803851333718663e-05;
            } else {
              result[0] += -9.722907597968881e-05;
            }
          } else {
            result[0] += -0.0005243405799623837;
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 5.209572721886269e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 5.209572721886269e-05;
            } else {
              result[0] += 5.209572721886269e-05;
            }
          } else {
            result[0] += 5.209572721886269e-05;
          }
        } else {
          result[0] += -1.7459678020466251e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 5.209572721886269e-05;
            } else {
              result[0] += 5.209572721886269e-05;
            }
          } else {
            result[0] += 5.209572721886269e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 5.209572721886269e-05;
          } else {
            result[0] += 5.209572721886269e-05;
          }
        }
      } else {
        result[0] += 5.209572721886269e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
      result[0] += -7.986423121124228e-05;
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.04855099859271875401) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9079021320180030719) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8440161800932387548) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)45.50000000000000711) ) ) {
                result[0] += -0.00011244621888975092;
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01184520638735680163) ) ) {
                  result[0] += -1.101237332223139e-05;
                } else {
                  result[0] += 0.00010894155367133011;
                }
              }
            } else {
              result[0] += -0.0005793386371388141;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6586934769095478259) ) ) {
              result[0] += -0.0010539194578007094;
            } else {
              result[0] += 0.0003161094282880953;
            }
          }
        } else {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)25.50000000000000355) ) ) {
            result[0] += 2.5733683913640963e-05;
          } else {
            result[0] += 7.794210479423889e-05;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.671614783348539524) ) ) {
            result[0] += -8.402731437116723e-05;
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
              result[0] += -8.551967443833647e-05;
            } else {
              result[0] += -9.582038849147989e-05;
            }
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7664523331407036011) ) ) {
            result[0] += -0.0003609998808237692;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7683067979899498301) ) ) {
              result[0] += 0.00136077397321327;
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.0144392355375913) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)331.5000000000000568) ) ) {
                  result[0] += -0.0004941781301814979;
                } else {
                  result[0] += -0.0017417855530330055;
                }
              } else {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.051391296366422923) ) ) {
                  result[0] += 0.0008558329618000416;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.145614105386054682) ) ) {
                    result[0] += -0.0008675255272206598;
                  } else {
                    result[0] += -4.082303287496048e-05;
                  }
                }
              }
            }
          }
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 5.0605234714971764e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            result[0] += 5.0605234714971764e-05;
          } else {
            result[0] += 5.0605234714971764e-05;
          }
        } else {
          result[0] += -1.6960145321750564e-06;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 5.0605234714971764e-05;
            } else {
              result[0] += 5.0605234714971764e-05;
            }
          } else {
            result[0] += 5.0605234714971764e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 5.0605234714971764e-05;
          } else {
            result[0] += 5.0605234714971764e-05;
          }
        }
      } else {
        result[0] += 5.0605234714971764e-05;
      }
    }
  }
}

