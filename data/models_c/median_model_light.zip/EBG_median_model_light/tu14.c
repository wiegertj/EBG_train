
#include "header.h"

void predict_unit14(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9189305784170854752) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
          result[0] += 4.717596491725822e-07;
        } else {
          result[0] += -1.7652488068630267e-05;
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.00933301618409165118) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9993516786272610419) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7102898410050252354) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7080301875628142172) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6010141514957837439) ) ) {
                    result[0] += -7.909977616468162e-05;
                  } else {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.606193063154585432) ) ) {
                      result[0] += 0.0030057772704623845;
                    } else {
                      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.027057242659878707e-06) ) ) {
                        result[0] += 0.0011677633273217047;
                      } else {
                        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001281500000000000304) ) ) {
                          result[0] += -0.0005603094993568187;
                        } else {
                          result[0] += 0.0005234236898920324;
                        }
                      }
                    }
                  }
                } else {
                  result[0] += 0.0015776925601548937;
                }
              } else {
                result[0] += -8.405842398875505e-05;
              }
            } else {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.003192522685141000512) ) ) {
                result[0] += 3.140235079915926e-05;
              } else {
                result[0] += 0.0007483940643241174;
              }
            }
          } else {
            result[0] += -1.9129368848098226e-05;
          }
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
            result[0] += 3.0047334902787755e-05;
          } else {
            result[0] += -1.7522908388583734e-05;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -1.8902517557113435e-05;
      } else {
        result[0] += -0.00024503211106960225;
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 1.1185336520092985e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 1.1185336520092985e-05;
            } else {
              result[0] += 1.1185336520092985e-05;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 1.1185336520092985e-05;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 1.1185336520092985e-05;
              } else {
                result[0] += 1.1185336520092985e-05;
              }
            }
          }
        } else {
          result[0] += -3.748721528898964e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 1.1185336520092985e-05;
            } else {
              result[0] += 1.1185336520092985e-05;
            }
          } else {
            result[0] += 1.1185336520092985e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 1.1185336520092985e-05;
          } else {
            result[0] += 1.1185336520092985e-05;
          }
        }
      } else {
        result[0] += 1.1185336520092985e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9189305784170854752) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
          result[0] += 4.5826229999892205e-07;
        } else {
          result[0] += -1.714743894951964e-05;
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.007692735115326951138) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01067850000000000223) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9450000000000000622) ) ) {
              result[0] += -2.481764636096701e-05;
            } else {
              result[0] += 0.00011322755361307809;
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6750000000000001554) ) ) {
              result[0] += -0.00045851845028867163;
            } else {
              result[0] += 4.1050841707031997e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.828053558455352334) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9750000000000000888) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7550000000000001155) ) ) {
                  result[0] += -0.00013350458388309322;
                } else {
                  result[0] += 0.0003897009289998058;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.163639685692610809) ) ) {
                  result[0] += 0.00014245202261116261;
                } else {
                  result[0] += 0.00041461392201652984;
                }
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008311500000000001179) ) ) {
                result[0] += 3.315358852860586e-05;
              } else {
                result[0] += -3.641745052049848e-05;
              }
            }
          } else {
            result[0] += -0.00033063373284597926;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -1.836170428455509e-05;
      } else {
        result[0] += -0.00023802158363752713;
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 1.0865316796274084e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 1.0865316796274084e-05;
            } else {
              result[0] += 1.0865316796274084e-05;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 1.0865316796274084e-05;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 1.0865316796274084e-05;
              } else {
                result[0] += 1.0865316796274084e-05;
              }
            }
          }
        } else {
          result[0] += -3.6414681775002256e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 1.0865316796274084e-05;
            } else {
              result[0] += 1.0865316796274084e-05;
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.6250640499379888082) ) ) {
              result[0] += 1.0865316796274084e-05;
            } else {
              result[0] += 1.0865316796274084e-05;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 1.0865316796274084e-05;
          } else {
            result[0] += 1.0865316796274084e-05;
          }
        }
      } else {
        result[0] += 1.0865316796274084e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          result[0] += 4.4515111872880755e-07;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4892818374874372545) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4795364038944723295) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4754075198241206057) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4737195465326633492) ) ) {
                    result[0] += 5.453237614554541e-05;
                  } else {
                    result[0] += -0.0009051965061149787;
                  }
                } else {
                  result[0] += 0.0010668794745895467;
                }
              } else {
                result[0] += -0.00042502164553780955;
              }
            } else {
              result[0] += 0.000289197466146022;
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)71.50000000000001421) ) ) {
              result[0] += 4.956772567891446e-06;
            } else {
              result[0] += -4.0228280517935136e-05;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5510720942211057016) ) ) {
            result[0] += -8.012360694093109e-06;
          } else {
            result[0] += -1.6656839612882906e-05;
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.8150000000000000577) ) ) {
              result[0] += -0.00148600009851376;
            } else {
              result[0] += 3.0847272691948217e-05;
            }
          } else {
            result[0] += -1.076416982742252e-05;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)60.50000000000000711) ) ) {
            result[0] += -1.333788177673283e-05;
          } else {
            result[0] += -1.783636403006915e-05;
          }
        } else {
          result[0] += -4.7347788525547584e-05;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.508252903391186006) ) ) {
          result[0] += 2.493273270239694e-05;
        } else {
          result[0] += -0.00030668592430712493;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 1.0554453044066147e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 1.0554453044066147e-05;
            } else {
              result[0] += 1.0554453044066147e-05;
            }
          } else {
            result[0] += 1.0554453044066147e-05;
          }
        } else {
          result[0] += -3.537283413975058e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 1.0554453044066147e-05;
            } else {
              result[0] += 1.0554453044066147e-05;
            }
          } else {
            result[0] += 1.0554453044066147e-05;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 1.0554453044066147e-05;
          } else {
            result[0] += 1.0554453044066147e-05;
          }
        }
      } else {
        result[0] += 1.0554453044066147e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9189305784170854752) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
          result[0] += 4.3241505684841394e-07;
        } else {
          result[0] += -1.618027664108274e-05;
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.007692735115326951138) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01067850000000000223) ) ) {
            result[0] += -1.656649847387894e-05;
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6750000000000001554) ) ) {
              result[0] += -0.0004431568012203108;
            } else {
              result[0] += 4.0184320404531086e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7550000000000001155) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
                result[0] += -0.00014078273608756316;
              } else {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.828053558455352334) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.08030541277720280868) ) ) {
                    result[0] += 0.00011348308679593898;
                  } else {
                    result[0] += 0.000875698434422426;
                  }
                } else {
                  result[0] += -0.00031388034366995246;
                }
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.07149150000000001337) ) ) {
                result[0] += 0.0003656027361903312;
              } else {
                result[0] += -1.9620753205576707e-05;
              }
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008311500000000001179) ) ) {
              result[0] += 3.260677945639248e-05;
            } else {
              result[0] += -3.546669063715261e-05;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -1.732605410058499e-05;
      } else {
        result[0] += -0.00023192497357107808;
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 1.0252483305189006e-05;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 1.0252483305189006e-05;
            } else {
              result[0] += 1.0252483305189006e-05;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 1.0252483305189006e-05;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 1.0252483305189006e-05;
              } else {
                result[0] += 1.0252483305189006e-05;
              }
            }
          }
        } else {
          result[0] += -3.4360794440124183e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 1.0252483305189006e-05;
            } else {
              result[0] += 1.0252483305189006e-05;
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.6250640499379888082) ) ) {
              result[0] += 1.0252483305189006e-05;
            } else {
              result[0] += 1.0252483305189006e-05;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 1.0252483305189006e-05;
          } else {
            result[0] += 1.0252483305189006e-05;
          }
        }
      } else {
        result[0] += 1.0252483305189006e-05;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9189305784170854752) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
          result[0] += 4.200433819489752e-07;
        } else {
          result[0] += -1.5717348444628283e-05;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1450000000000000455) ) ) {
          if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)99.50000000000001421) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8305107979648241878) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500000000000000118) ) ) {
                result[0] += 1.2733807135480075e-05;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0007835000000000000167) ) ) {
                  result[0] += -0.0005628137092668575;
                } else {
                  result[0] += -8.121408380952235e-05;
                }
              }
            } else {
              result[0] += -1.5434757264753303e-05;
            }
          } else {
            if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.130629626450776108e-06) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.363906689523952442) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)259.5000000000000568) ) ) {
                  result[0] += 4.729243454103272e-05;
                } else {
                  result[0] += -4.1124697704135685e-05;
                }
              } else {
                result[0] += -1.9701931190766768e-05;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)6.935971188705380502e-06) ) ) {
                result[0] += 0.0004819604314545095;
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4578754035427136104) ) ) {
                  result[0] += 0.0012603858005322713;
                } else {
                  result[0] += -3.6335497705528746e-07;
                }
              }
            }
          }
        } else {
          result[0] += 1.1115943575019052e-05;
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -1.68303444687675e-05;
      } else {
        result[0] += -0.00022528944983377702;
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 9.959153116160405e-06;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 9.959153116160405e-06;
            } else {
              result[0] += 9.959153116160405e-06;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 9.959153116160405e-06;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 9.959153116160405e-06;
              } else {
                result[0] += 9.959153116160405e-06;
              }
            }
          }
        } else {
          result[0] += -3.337770985182433e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 9.959153116160405e-06;
            } else {
              result[0] += 9.959153116160405e-06;
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.6250640499379888082) ) ) {
              result[0] += 9.959153116160405e-06;
            } else {
              result[0] += 9.959153116160405e-06;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 9.959153116160405e-06;
          } else {
            result[0] += 9.959153116160405e-06;
          }
        }
      } else {
        result[0] += 9.959153116160405e-06;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9189305784170854752) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
          result[0] += 4.0802566868292105e-07;
        } else {
          result[0] += -1.5267664923764152e-05;
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.007692735115326951138) ) ) {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01067850000000000223) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9450000000000000622) ) ) {
              result[0] += -2.4137357263504282e-05;
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0001725283487249000298) ) ) {
                result[0] += 0.0003985467481267233;
              } else {
                result[0] += 4.896889843670136e-05;
              }
            }
          } else {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.6750000000000001554) ) ) {
              result[0] += -0.00043046740223449053;
            } else {
              result[0] += 3.871658661922534e-05;
            }
          }
        } else {
          if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.9650000000000000799) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.7150000000000000799) ) ) {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006101500000000000153) ) ) {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)488.5000000000000568) ) ) {
                  result[0] += -9.038710793784971e-05;
                } else {
                  result[0] += -0.000945112522300081;
                }
              } else {
                result[0] += 0.0001260179847499666;
              }
            } else {
              result[0] += 0.0002650460279862329;
            }
          } else {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.008311500000000001179) ) ) {
              result[0] += 3.135584402642407e-05;
            } else {
              result[0] += -3.476999998903675e-05;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -1.634881741064221e-05;
      } else {
        result[0] += -0.00021884377272916153;
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 9.674215293862252e-06;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 9.674215293862252e-06;
            } else {
              result[0] += 9.674215293862252e-06;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 9.674215293862252e-06;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 9.674215293862252e-06;
              } else {
                result[0] += 9.674215293862252e-06;
              }
            }
          }
        } else {
          result[0] += -3.242275195054011e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 9.674215293862252e-06;
            } else {
              result[0] += 9.674215293862252e-06;
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.6250640499379888082) ) ) {
              result[0] += 9.674215293862252e-06;
            } else {
              result[0] += 9.674215293862252e-06;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 9.674215293862252e-06;
          } else {
            result[0] += 9.674215293862252e-06;
          }
        }
      } else {
        result[0] += 9.674215293862252e-06;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.555096866909547848) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
            result[0] += 3.963517899785938e-07;
          } else {
            result[0] += -6.4336923628026086e-06;
          }
        } else {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5528143519346734314) ) ) {
            result[0] += 1.241186599859083e-05;
          } else {
            result[0] += 0.0008586530898336378;
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          result[0] += -1.483084713974161e-05;
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.2070775000000000254) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1129321246270776624) ) ) {
              if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.568345700351758909) ) ) {
                if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)9.765598692199240846e-06) ) ) {
                  result[0] += 0.0015370952297332125;
                } else {
                  result[0] += -9.4041748804484e-05;
                }
              } else {
                result[0] += -0.0003836760562111177;
              }
            } else {
              result[0] += -1.1779062884992825e-05;
            }
          } else {
            result[0] += 0.00013194270618540826;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)60.50000000000000711) ) ) {
            result[0] += -1.16068468373395e-05;
          } else {
            result[0] += -1.5881067153588174e-05;
          }
        } else {
          result[0] += -4.4189775276986604e-05;
        }
      } else {
        if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05963150000000001089) ) ) {
          result[0] += -6.8283766413722e-07;
        } else {
          result[0] += -0.00030878543055257613;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 9.397429727246871e-06;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 9.397429727246871e-06;
            } else {
              result[0] += 9.397429727246871e-06;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 9.397429727246871e-06;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 9.397429727246871e-06;
              } else {
                result[0] += 9.397429727246871e-06;
              }
            }
          }
        } else {
          result[0] += -3.1495116013453686e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 9.397429727246871e-06;
            } else {
              result[0] += 9.397429727246871e-06;
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.6250640499379888082) ) ) {
              result[0] += 9.397429727246871e-06;
            } else {
              result[0] += 9.397429727246871e-06;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 9.397429727246871e-06;
          } else {
            result[0] += 9.397429727246871e-06;
          }
        }
      } else {
        result[0] += 9.397429727246871e-06;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1.679442381639573378) ) ) {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          result[0] += 3.850119085064489e-07;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4838161673366834781) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4795364038944723295) ) ) {
                result[0] += 7.219595328437481e-05;
              } else {
                result[0] += -0.0007431590156314394;
              }
            } else {
              if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.004769259728134950423) ) ) {
                result[0] += -0.00014427928555507016;
              } else {
                result[0] += 0.0004997506774820657;
              }
            }
          } else {
            result[0] += -2.227974691334088e-05;
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5577388506030152016) ) ) {
            result[0] += -1.5431588782287019e-06;
          } else {
            result[0] += -1.4406526995495093e-05;
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.7250000000000000888) ) ) {
              result[0] += -0.0014323732892356307;
            } else {
              result[0] += 1.1234774887837985e-05;
            }
          } else {
            result[0] += -8.782161657438971e-06;
          }
        }
      }
    } else {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)2.986788586913651739e-05) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.01500000000000000118) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)60.50000000000000711) ) ) {
            result[0] += -1.1274767430285992e-05;
          } else {
            result[0] += -1.5426699534401977e-05;
          }
        } else {
          result[0] += -4.2925477179711794e-05;
        }
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.508252903391186006) ) ) {
          result[0] += 1.702232421653865e-05;
        } else {
          result[0] += -0.00029680493374916795;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 9.128563174995868e-06;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 9.128563174995868e-06;
            } else {
              result[0] += 9.128563174995868e-06;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 9.128563174995868e-06;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 9.128563174995868e-06;
              } else {
                result[0] += 9.128563174995868e-06;
              }
            }
          }
        } else {
          result[0] += -3.059402034139228e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 9.128563174995868e-06;
            } else {
              result[0] += 9.128563174995868e-06;
            }
          } else {
            result[0] += 9.128563174995868e-06;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 9.128563174995868e-06;
          } else {
            result[0] += 9.128563174995868e-06;
          }
        }
      } else {
        result[0] += 9.128563174995868e-06;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9189305784170854752) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
          result[0] += 3.7399646838934286e-07;
        } else {
          result[0] += -1.399434692545452e-05;
        }
      } else {
        if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.007016451597998800589) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9993516786272610419) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7102898410050252354) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.4725173572200235816) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5811189422864322385) ) ) {
                    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.0005735742057343501095) ) ) {
                      result[0] += 0.00023203436992133927;
                    } else {
                      result[0] += -0.0001329174683630286;
                    }
                  } else {
                    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.1050000000000000239) ) ) {
                      result[0] += -0.00029173278331714845;
                    } else {
                      result[0] += -0.00016001218871510855;
                    }
                  }
                } else {
                  result[0] += 0.0002217355705687092;
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002478500000000000234) ) ) {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7156546188693468924) ) ) {
                    result[0] += -0.0005632601221585742;
                  } else {
                    result[0] += -2.0484405615552734e-05;
                  }
                } else {
                  result[0] += -0.0004204800491300069;
                }
              }
            } else {
              result[0] += 4.7218222733956564e-05;
            }
          } else {
            result[0] += -1.3406837946425233e-05;
          }
        } else {
          result[0] += 1.3355908509152696e-05;
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -1.4985331667144813e-05;
      } else {
        result[0] += -0.00021304999391724127;
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 8.86738906897915e-06;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 8.86738906897915e-06;
            } else {
              result[0] += 8.86738906897915e-06;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 8.86738906897915e-06;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 8.86738906897915e-06;
              } else {
                result[0] += 8.86738906897915e-06;
              }
            }
          }
        } else {
          result[0] += -2.971870560035629e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 8.86738906897915e-06;
            } else {
              result[0] += 8.86738906897915e-06;
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.6250640499379888082) ) ) {
              result[0] += 8.86738906897915e-06;
            } else {
              result[0] += 8.86738906897915e-06;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 8.86738906897915e-06;
          } else {
            result[0] += 8.86738906897915e-06;
          }
        }
      } else {
        result[0] += 8.86738906897915e-06;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9189305784170854752) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
          result[0] += 3.632961871498623e-07;
        } else {
          result[0] += -1.3593959594232383e-05;
        }
      } else {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.2203770052010050329) ) ) {
          result[0] += 0.0005358851620149693;
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.00991443746623210144) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9993516786272610419) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7102898410050252354) ) ) {
                  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6010141514957837439) ) ) {
                    result[0] += -6.8438832581131e-05;
                  } else {
                    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.714286561348693172) ) ) {
                      result[0] += 0.0009090012847723174;
                    } else {
                      result[0] += -0.00032466573182380465;
                    }
                  }
                } else {
                  result[0] += -7.711992922111529e-05;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.003192522685141000512) ) ) {
                  result[0] += 2.5545774156017984e-05;
                } else {
                  result[0] += 0.0007692918148130714;
                }
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -1.1681009474073843e-05;
              } else {
                result[0] += -0.00018029537628996503;
              }
            }
          } else {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1031.500000000000227) ) ) {
              result[0] += 9.648647149318403e-06;
            } else {
              result[0] += 0.00047967783567939664;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -1.4556591620492614e-05;
      } else {
        result[0] += -0.00020695449557524599;
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 8.613687323326672e-06;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 8.613687323326672e-06;
            } else {
              result[0] += 8.613687323326672e-06;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 8.613687323326672e-06;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 8.613687323326672e-06;
              } else {
                result[0] += 8.613687323326672e-06;
              }
            }
          }
        } else {
          result[0] += -2.8868434181153024e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 8.613687323326672e-06;
            } else {
              result[0] += 8.613687323326672e-06;
            }
          } else {
            if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-0.6250640499379888082) ) ) {
              result[0] += 8.613687323326672e-06;
            } else {
              result[0] += 8.613687323326672e-06;
            }
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 8.613687323326672e-06;
          } else {
            result[0] += 8.613687323326672e-06;
          }
        }
      } else {
        result[0] += 8.613687323326672e-06;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9189305784170854752) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
          result[0] += 3.529020478884391e-07;
        } else {
          result[0] += -1.3205027603931624e-05;
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8155157533417086713) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7422817934170855558) ) ) {
                if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7293938685427137081) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6690536170100503943) ) ) {
                    result[0] += -9.718212064539549e-06;
                  } else {
                    result[0] += 0.00014655501426148447;
                  }
                } else {
                  if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.735388073517588059) ) ) {
                    result[0] += -0.001020051955646249;
                  } else {
                    result[0] += -1.8949439780557966e-05;
                  }
                }
              } else {
                result[0] += 0.0004237440445264455;
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)513.5000000000001137) ) ) {
                result[0] += -2.641038210860097e-05;
              } else {
                result[0] += -5.227886174657469e-05;
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001999500000000000409) ) ) {
              result[0] += 0.00014961226639112634;
            } else {
              result[0] += 0.0019206295380198557;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04770400000000000335) ) ) {
            result[0] += -2.431639769771925e-05;
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8352912313316583903) ) ) {
              result[0] += -0.0004970320209118516;
            } else {
              result[0] += 0.00023081802134635818;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -1.414011810431744e-05;
      } else {
        result[0] += -0.00020103339338954342;
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 8.367244148969975e-06;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 8.367244148969975e-06;
            } else {
              result[0] += 8.367244148969975e-06;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 8.367244148969975e-06;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 8.367244148969975e-06;
              } else {
                result[0] += 8.367244148969975e-06;
              }
            }
          }
        } else {
          result[0] += -2.8042489578088956e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 8.367244148969975e-06;
            } else {
              result[0] += 8.367244148969975e-06;
            }
          } else {
            result[0] += 8.367244148969975e-06;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 8.367244148969975e-06;
          } else {
            result[0] += 8.367244148969975e-06;
          }
        }
      } else {
        result[0] += 8.367244148969975e-06;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9189305784170854752) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
          result[0] += 3.4280529168470845e-07;
        } else {
          result[0] += -1.2827223209827613e-05;
        }
      } else {
        if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
          if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8155157533417086713) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7422817934170855558) ) ) {
                result[0] += 5.232365489348331e-07;
              } else {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7425707671105529206) ) ) {
                  result[0] += 0.0012420887680413097;
                } else {
                  result[0] += 0.00014436469240636964;
                }
              }
            } else {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)513.5000000000001137) ) ) {
                if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7608008567839197323) ) ) {
                  result[0] += -0.0002027530751198547;
                } else {
                  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8458243956458841861) ) ) {
                    result[0] += -0.0006014648727494258;
                  } else {
                    result[0] += 2.7213113868606833e-05;
                  }
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.004462442435992651328) ) ) {
                  result[0] += -3.925533106706931e-05;
                } else {
                  result[0] += -0.0010845001013654392;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.001999500000000000409) ) ) {
              result[0] += 0.00014533176252927926;
            } else {
              result[0] += 0.0018656790827331282;
            }
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09550850000000001006) ) ) {
            result[0] += -2.3620689807169777e-05;
          } else {
            result[0] += 0.0002605846675815218;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -1.3735560165235953e-05;
      } else {
        result[0] += -0.00019528169777312542;
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 8.127851873478822e-06;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 8.127851873478822e-06;
            } else {
              result[0] += 8.127851873478822e-06;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 8.127851873478822e-06;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 8.127851873478822e-06;
              } else {
                result[0] += 8.127851873478822e-06;
              }
            }
          }
        } else {
          result[0] += -2.724017578513229e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 8.127851873478822e-06;
            } else {
              result[0] += 8.127851873478822e-06;
            }
          } else {
            result[0] += 8.127851873478822e-06;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 8.127851873478822e-06;
          } else {
            result[0] += 8.127851873478822e-06;
          }
        }
      } else {
        result[0] += 8.127851873478822e-06;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9189305784170854752) ) ) {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          result[0] += 3.329974102167499e-07;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += 6.857483510251778e-05;
          } else {
            result[0] += -2.203740995497004e-05;
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5577388506030152016) ) ) {
            result[0] += 3.5110778221859434e-08;
          } else {
            result[0] += -1.2460228044184584e-05;
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.516715179698492566) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1031.500000000000227) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.00029997103009222743;
              } else {
                if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.002304500000000000558) ) ) {
                  result[0] += 0.00034979074167961524;
                } else {
                  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.2350000000000000144) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05686650000000000732) ) ) {
                      result[0] += -0.0020007850185308033;
                    } else {
                      result[0] += -6.009211530055523e-05;
                    }
                  } else {
                    result[0] += -0.00016859562969882618;
                  }
                }
              }
            } else {
              result[0] += 0.0004478707264894624;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5233231360301507928) ) ) {
                result[0] += 6.679511978754235e-05;
              } else {
                result[0] += 0.00107045588674848;
              }
            } else {
              result[0] += -9.97529709827656e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -1.3342576890868467e-05;
      } else {
        result[0] += -0.0001896945618943025;
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 7.895308766072224e-06;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 7.895308766072224e-06;
            } else {
              result[0] += 7.895308766072224e-06;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 7.895308766072224e-06;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 7.895308766072224e-06;
              } else {
                result[0] += 7.895308766072224e-06;
              }
            }
          }
        } else {
          result[0] += -2.64608167095458e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 7.895308766072224e-06;
            } else {
              result[0] += 7.895308766072224e-06;
            }
          } else {
            result[0] += 7.895308766072224e-06;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 7.895308766072224e-06;
          } else {
            result[0] += 7.895308766072224e-06;
          }
        }
      } else {
        result[0] += 7.895308766072224e-06;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9189305784170854752) ) ) {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          result[0] += 3.234701385912123e-07;
        } else {
          result[0] += 2.10857726676634e-05;
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5577388506030152016) ) ) {
            result[0] += 3.410623611178796e-08;
          } else {
            result[0] += -1.210373284797391e-05;
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.516715179698492566) ) ) {
            if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1031.500000000000227) ) ) {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -0.0002913886645969061;
              } else {
                result[0] += -0.0002697468418392747;
              }
            } else {
              result[0] += 0.0004350568548692407;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5233231360301507928) ) ) {
                result[0] += 6.488406813983989e-05;
              } else {
                result[0] += 0.001039829450376044;
              }
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8280443990703518775) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2.028975360347832879) ) ) {
                  if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.8155157533417086713) ) ) {
                    result[0] += -1.6200975458469672e-05;
                  } else {
                    result[0] += 0.00029357569394366476;
                  }
                } else {
                  result[0] += 0.0002300806163560272;
                }
              } else {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.05151350000000001067) ) ) {
                  result[0] += -2.2659486857971914e-05;
                } else {
                  result[0] += 0.00012322348460500263;
                }
              }
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -1.2960837122559327e-05;
      } else {
        result[0] += -0.00018426727759237742;
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 7.669418867610084e-06;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 7.669418867610084e-06;
            } else {
              result[0] += 7.669418867610084e-06;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 7.669418867610084e-06;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 7.669418867610084e-06;
              } else {
                result[0] += 7.669418867610084e-06;
              }
            }
          }
        } else {
          result[0] += -2.570375560203712e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 7.669418867610084e-06;
            } else {
              result[0] += 7.669418867610084e-06;
            }
          } else {
            result[0] += 7.669418867610084e-06;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 7.669418867610084e-06;
          } else {
            result[0] += 7.669418867610084e-06;
          }
        }
      } else {
        result[0] += 7.669418867610084e-06;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9189305784170854752) ) ) {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          result[0] += 3.14215448378765e-07;
        } else {
          result[0] += 2.0482495052056052e-05;
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5577388506030152016) ) ) {
            result[0] += 3.313043460226376e-08;
          } else {
            result[0] += -1.1757437210268145e-05;
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.516715179698492566) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1807251065509998533) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1075.500000000000227) ) ) {
                result[0] += -0.0002292700150522259;
              } else {
                result[0] += 0.00040426330664012326;
              }
            } else {
              result[0] += -0.00028375002977654325;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9079021320180030719) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)111.5000000000000142) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0131020000000000008) ) ) {
                      result[0] += -9.849395967396041e-05;
                    } else {
                      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1165587384072143268) ) ) {
                        result[0] += 0.0002314171661171825;
                      } else {
                        if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5628434130653267031) ) ) {
                          result[0] += -0.00136280157314666;
                        } else {
                          result[0] += 7.19720511877877e-05;
                        }
                      }
                    }
                  } else {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6731103726130654996) ) ) {
                      result[0] += 3.3454717309692196e-05;
                    } else {
                      result[0] += 0.0002755610826999076;
                    }
                  }
                } else {
                  result[0] += -0.0004526613147979987;
                }
              } else {
                result[0] += 0.0002468076788549691;
              }
            } else {
              result[0] += -1.8516102990640044e-05;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -1.259001917631654e-05;
      } else {
        result[0] += -0.00017899527141018273;
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 7.449991825476533e-06;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 7.449991825476533e-06;
            } else {
              result[0] += 7.449991825476533e-06;
            }
          } else {
            result[0] += 7.449991825476533e-06;
          }
        } else {
          result[0] += -2.4968354503108716e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 7.449991825476533e-06;
            } else {
              result[0] += 7.449991825476533e-06;
            }
          } else {
            result[0] += 7.449991825476533e-06;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 7.449991825476533e-06;
          } else {
            result[0] += 7.449991825476533e-06;
          }
        }
      } else {
        result[0] += 7.449991825476533e-06;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9189305784170854752) ) ) {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          result[0] += 3.052255408485712e-07;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9850000000000000977) ) ) {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4838161673366834781) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.4795364038944723295) ) ) {
                result[0] += 4.922162631473452e-05;
              } else {
                result[0] += -0.0006773426900196;
              }
            } else {
              result[0] += 0.0002508558934603429;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)49.50000000000000711) ) ) {
              result[0] += 1.4239316986284076e-05;
            } else {
              result[0] += -3.366957056803004e-05;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5577388506030152016) ) ) {
            result[0] += 3.218255140604765e-08;
          } else {
            result[0] += -1.1421049315091129e-05;
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.516715179698492566) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1807251065509998533) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1075.500000000000227) ) ) {
                result[0] += -0.00022271045139805843;
              } else {
                result[0] += 0.0003926970715511351;
              }
            } else {
              result[0] += -0.00027563175760838795;
            }
          } else {
            if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5260552395728644859) ) ) {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5233231360301507928) ) ) {
                result[0] += 6.350147559317243e-05;
              } else {
                result[0] += 0.0010128972321800437;
              }
            } else {
              result[0] += -8.511837086644482e-06;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -1.222981057173552e-05;
      } else {
        result[0] += -0.00017387410074012118;
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 7.23684273316755e-06;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 7.23684273316755e-06;
            } else {
              result[0] += 7.23684273316755e-06;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 7.23684273316755e-06;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 7.23684273316755e-06;
              } else {
                result[0] += 7.23684273316755e-06;
              }
            }
          }
        } else {
          result[0] += -2.4253993705925264e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 7.23684273316755e-06;
            } else {
              result[0] += 7.23684273316755e-06;
            }
          } else {
            result[0] += 7.23684273316755e-06;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 7.23684273316755e-06;
          } else {
            result[0] += 7.23684273316755e-06;
          }
        }
      } else {
        result[0] += 7.23684273316755e-06;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.9189305784170854752) ) ) {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5041457217085428821) ) ) {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          result[0] += 2.9649284039657305e-07;
        } else {
          result[0] += 1.8406357697969978e-05;
        }
      } else {
        if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.500000000000000222) ) ) {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5577388506030152016) ) ) {
            result[0] += 3.1261787762104786e-08;
          } else {
            result[0] += -1.1094285695510712e-05;
          }
        } else {
          if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.516715179698492566) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1807251065509998533) ) ) {
              if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1075.500000000000227) ) ) {
                result[0] += -0.00021633856110939013;
              } else {
                result[0] += 0.0003814617539407723;
              }
            } else {
              result[0] += -0.0002677457544660656;
            }
          } else {
            if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.7478339930150754711) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9079021320180030719) ) ) {
                if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8276139213783068049) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)111.5000000000000142) ) ) {
                    if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.0131020000000000008) ) ) {
                      result[0] += -9.66019023094947e-05;
                    } else {
                      result[0] += 7.841724521783664e-05;
                    }
                  } else {
                    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.6731103726130654996) ) ) {
                      result[0] += 3.257967804910876e-05;
                    } else {
                      result[0] += 0.00026792063078560685;
                    }
                  }
                } else {
                  result[0] += -0.0004394668521697692;
                }
              } else {
                result[0] += 0.00023998988045142845;
              }
            } else {
              result[0] += -1.7742816116045587e-05;
            }
          }
        }
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
        result[0] += -1.1879907768678477e-05;
      } else {
        result[0] += -0.00016889945008047872;
      }
    }
  } else {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.03802905541358335417) ) ) {
      if ( UNLIKELY(  (data[5].missing != -1) && (data[5].fvalue <= (double)-1.143279903388985774) ) ) {
        result[0] += 7.029791974468493e-06;
      } else {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5092601713187812074) ) ) {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01176650000000000092) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01986503967995920453) ) ) {
              result[0] += 7.029791974468493e-06;
            } else {
              result[0] += 7.029791974468493e-06;
            }
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)36.50000000000000711) ) ) {
              result[0] += 7.029791974468493e-06;
            } else {
              if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)0.5068267582412061545) ) ) {
                result[0] += 7.029791974468493e-06;
              } else {
                result[0] += 7.029791974468493e-06;
              }
            }
          }
        } else {
          result[0] += -2.3560071234110221e-07;
        }
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.1741693819772918705) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.1534042965400678749) ) ) {
          if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)38.50000000000000711) ) ) {
            if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04651350000000000623) ) ) {
              result[0] += 7.029791974468493e-06;
            } else {
              result[0] += 7.029791974468493e-06;
            }
          } else {
            result[0] += 7.029791974468493e-06;
          }
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02139100000000000376) ) ) {
            result[0] += 7.029791974468493e-06;
          } else {
            result[0] += 7.029791974468493e-06;
          }
        }
      } else {
        result[0] += 7.029791974468493e-06;
      }
    }
  }
}

