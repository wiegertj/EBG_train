
#include "header.h"

void predict_unit14(union Entry* data, double* result) {
  unsigned int tmp;
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -1.0879575103130698e-05;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8526604327889448776) ) ) {
              if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9750000000000000888) ) ) {
                result[0] += 3.037231169369122e-08;
              } else {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
                  result[0] += -6.589275788273613e-05;
                } else {
                  result[0] += -7.120250382251539e-06;
                }
              }
            } else {
              result[0] += 0.0004356834632419752;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
              result[0] += -8.091689928102489e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                    result[0] += -1.1982246867908204e-05;
                  } else {
                    result[0] += -1.2183509784549059e-05;
                  }
                } else {
                  result[0] += 9.798678149953778e-06;
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  result[0] += 1.763659405547959e-05;
                } else {
                  result[0] += -0.00022182255586338575;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -1.1730214155396885e-05;
          } else {
            result[0] += -0.0002384050137413252;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 9.77099075789677e-07;
        } else {
          result[0] += 2.6552381273918814e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 7.249215061615219e-06;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 7.249215061615219e-06;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 7.249215061615219e-06;
            } else {
              result[0] += 7.249215061615219e-06;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 7.099535438507255e-06;
          } else {
            result[0] += -3.930886600868951e-06;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            result[0] += 7.249215061615219e-06;
          } else {
            result[0] += 7.249215061615219e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 7.249215061615219e-06;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                result[0] += 7.249215061615219e-06;
              } else {
                result[0] += 7.249215061615219e-06;
              }
            } else {
              result[0] += 7.249215061615219e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 7.249215061615219e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 7.249215061615219e-06;
              } else {
                result[0] += 7.249215061615219e-06;
              }
            }
          }
        }
      } else {
        result[0] += 7.249215061615219e-06;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -1.0493718699950743e-05;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9750000000000000888) ) ) {
            result[0] += 5.028650323360571e-07;
          } else {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9950000000000001066) ) ) {
              result[0] += -6.35557968974752e-05;
            } else {
              result[0] += -6.867722670813547e-06;
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6732382808793971884) ) ) {
            result[0] += -7.804709017385964e-05;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.96280210579579717) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -1.1314188878708476e-05;
              } else {
                result[0] += -0.00015464074410061042;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                  result[0] += -2.164439364567312e-05;
                } else {
                  result[0] += 0.0003126312232183654;
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  result[0] += 1.8221680329626108e-05;
                } else {
                  result[0] += -0.00015736977538437604;
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 9.424451549002304e-07;
        } else {
          result[0] += 2.5610671120985595e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 6.992113472351011e-06;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 6.992113472351011e-06;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 6.992113472351011e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03350035677887956004) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03018900000000000403) ) ) {
                  result[0] += 6.992113472351011e-06;
                } else {
                  result[0] += 6.992113472351011e-06;
                }
              } else {
                result[0] += 6.992113472351011e-06;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 6.847742405912217e-06;
          } else {
            result[0] += -3.7914732735331267e-06;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            result[0] += 6.992113472351011e-06;
          } else {
            result[0] += 6.992113472351011e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 6.992113472351011e-06;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                result[0] += 6.992113472351011e-06;
              } else {
                result[0] += 6.992113472351011e-06;
              }
            } else {
              result[0] += 6.992113472351011e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 6.992113472351011e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 6.992113472351011e-06;
              } else {
                result[0] += 6.992113472351011e-06;
              }
            }
          }
        }
      } else {
        result[0] += 6.992113472351011e-06;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -1.0121547129355102e-05;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
              if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8643464628140704598) ) ) {
                result[0] += -4.11918071102609e-06;
              } else {
                result[0] += 0.00045093428676875507;
              }
            } else {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                    result[0] += -1.1156012495803338e-05;
                  } else {
                    result[0] += -1.1769242542658792e-05;
                  }
                } else {
                  result[0] += 1.7575427882702733e-05;
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9550000000000000711) ) ) {
                  result[0] += 9.48067837907127e-05;
                } else {
                  result[0] += -0.00043481170511075316;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += -1.0912918407733825e-05;
            } else {
              result[0] += -0.0002244652025843255;
            }
          }
        } else {
          result[0] += -7.527906208382119e-05;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 9.090202744047086e-07;
        } else {
          result[0] += 2.4702359780874057e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 6.7441302809594995e-06;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 6.7441302809594995e-06;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 6.7441302809594995e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03350035677887956004) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03018900000000000403) ) ) {
                  result[0] += 6.7441302809594995e-06;
                } else {
                  result[0] += 6.7441302809594995e-06;
                }
              } else {
                result[0] += 6.7441302809594995e-06;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 6.6048794972422105e-06;
          } else {
            result[0] += -3.657004397109015e-06;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            result[0] += 6.7441302809594995e-06;
          } else {
            result[0] += 6.7441302809594995e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 6.7441302809594995e-06;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                result[0] += 6.7441302809594995e-06;
              } else {
                result[0] += 6.7441302809594995e-06;
              }
            } else {
              result[0] += 6.7441302809594995e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 6.7441302809594995e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 6.7441302809594995e-06;
              } else {
                result[0] += 6.7441302809594995e-06;
              }
            }
          }
        }
      } else {
        result[0] += 6.7441302809594995e-06;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -9.762575043319684e-06;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8643464628140704598) ) ) {
              result[0] += -3.973089320680692e-06;
            } else {
              result[0] += 0.0004349413936351757;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
              result[0] += -7.260920523232827e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                    result[0] += -1.0760351928671186e-05;
                  } else {
                    result[0] += -1.1351833080192167e-05;
                  }
                } else {
                  result[0] += 1.5986093189741055e-05;
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  result[0] += 1.5741507531400787e-05;
                } else {
                  result[0] += -0.0002117365016362713;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -1.0525879446644892e-05;
          } else {
            result[0] += -0.000216504290978197;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 8.767808449991848e-07;
        } else {
          result[0] += 2.3826262727013656e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 6.504942093172707e-06;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 6.504942093172707e-06;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 6.504942093172707e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03350035677887956004) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03018900000000000403) ) ) {
                  result[0] += 6.504942093172707e-06;
                } else {
                  result[0] += 6.504942093172707e-06;
                }
              } else {
                result[0] += 6.504942093172707e-06;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 6.370629995577342e-06;
          } else {
            result[0] += -3.52730461106993e-06;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            result[0] += 6.504942093172707e-06;
          } else {
            result[0] += 6.504942093172707e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 6.504942093172707e-06;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                result[0] += 6.504942093172707e-06;
              } else {
                result[0] += 6.504942093172707e-06;
              }
            } else {
              result[0] += 6.504942093172707e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 6.504942093172707e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 6.504942093172707e-06;
              } else {
                result[0] += 6.504942093172707e-06;
              }
            }
          }
        }
      } else {
        result[0] += 6.504942093172707e-06;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -9.416334307235592e-06;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.4601878067544193374) ) ) {
            if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.5724391781153673753) ) ) {
              result[0] += -2.4445057404220202e-05;
            } else {
              result[0] += 0.000260051085556241;
            }
          } else {
            result[0] += -1.0122587688109749e-05;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6732382808793971884) ) ) {
            result[0] += -7.003403786566883e-05;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.96280210579579717) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -1.0152567258890455e-05;
              } else {
                result[0] += -0.00015034788393524914;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                  result[0] += -2.0056735782670183e-05;
                } else {
                  result[0] += 0.00029761400988294643;
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  result[0] += 1.6393805186779045e-05;
                } else {
                  result[0] += -0.00014764143444748263;
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 8.456848233235651e-07;
        } else {
          result[0] += 2.2981237443404825e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 6.27423698427064e-06;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 6.27423698427064e-06;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 6.27423698427064e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03350035677887956004) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03018900000000000403) ) ) {
                  result[0] += 6.27423698427064e-06;
                } else {
                  result[0] += 6.27423698427064e-06;
                }
              } else {
                result[0] += 6.27423698427064e-06;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 6.144688416722883e-06;
          } else {
            result[0] += -3.402204774243326e-06;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            result[0] += 6.27423698427064e-06;
          } else {
            result[0] += 6.27423698427064e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 6.27423698427064e-06;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                result[0] += 6.27423698427064e-06;
              } else {
                result[0] += 6.27423698427064e-06;
              }
            } else {
              result[0] += 6.27423698427064e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 6.27423698427064e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 6.27423698427064e-06;
              } else {
                result[0] += 6.27423698427064e-06;
              }
            }
          }
        }
      } else {
        result[0] += 6.27423698427064e-06;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -9.082373389415841e-06;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
            result[0] += -1.0667108922997912e-06;
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3750409390474713223) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6130861605291061389) ) ) {
                result[0] += -2.0253276045526556e-05;
              } else {
                result[0] += -7.160732614758188e-05;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02790100000000000566) ) ) {
                result[0] += 1.1183353260368631e-05;
              } else {
                result[0] += -9.841811905590052e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6732382808793971884) ) ) {
            result[0] += -6.755020171445359e-05;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.96280210579579717) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -9.79249500897042e-06;
              } else {
                result[0] += -0.00014501562663925575;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                  result[0] += -1.9345401024164284e-05;
                } else {
                  result[0] += 0.00028705879331420824;
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  result[0] += 1.581238039363767e-05;
                } else {
                  result[0] += -0.00014240516443544423;
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 8.156916571329458e-07;
        } else {
          result[0] += 2.216618193466667e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 6.051714092290993e-06;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 6.051714092290993e-06;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 6.051714092290993e-06;
            } else {
              result[0] += 6.051714092290993e-06;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 5.926760110821672e-06;
          } else {
            result[0] += -3.2815417442421113e-06;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            result[0] += 6.051714092290993e-06;
          } else {
            result[0] += 6.051714092290993e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 6.051714092290993e-06;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                result[0] += 6.051714092290993e-06;
              } else {
                result[0] += 6.051714092290993e-06;
              }
            } else {
              result[0] += 6.051714092290993e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 6.051714092290993e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 6.051714092290993e-06;
              } else {
                result[0] += 6.051714092290993e-06;
              }
            }
          }
        }
      } else {
        result[0] += 6.051714092290993e-06;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -8.76025677225412e-06;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9850000000000000977) ) ) {
            result[0] += -1.0288787872563717e-06;
          } else {
            if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.3750409390474713223) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.6130861605291061389) ) ) {
                result[0] += -1.9534970764898646e-05;
              } else {
                result[0] += -6.906769155278328e-05;
              }
            } else {
              if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02790100000000000566) ) ) {
                result[0] += 1.0786723022181993e-05;
              } else {
                result[0] += -9.492760944803847e-06;
              }
            }
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6732382808793971884) ) ) {
            result[0] += -6.515445761410536e-05;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.96280210579579717) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -9.44519312755486e-06;
              } else {
                result[0] += -0.00013987248386304463;
              }
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)3.011844272517733503e-05) ) ) {
                  result[0] += -1.865929455525354e-05;
                } else {
                  result[0] += 0.0002768779294073495;
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  result[0] += 1.5251576486631515e-05;
                } else {
                  result[0] += -0.00013735460464588974;
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 7.867622324135316e-07;
        } else {
          result[0] += 2.138003328892753e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 5.837083225681735e-06;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 5.837083225681735e-06;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 5.837083225681735e-06;
            } else {
              result[0] += 5.837083225681735e-06;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 5.716560878114078e-06;
          } else {
            result[0] += -3.1651581647080273e-06;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            result[0] += 5.837083225681735e-06;
          } else {
            result[0] += 5.837083225681735e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 5.837083225681735e-06;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                result[0] += 5.837083225681735e-06;
              } else {
                result[0] += 5.837083225681735e-06;
              }
            } else {
              result[0] += 5.837083225681735e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 5.837083225681735e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 5.837083225681735e-06;
              } else {
                result[0] += 5.837083225681735e-06;
              }
            }
          }
        }
      } else {
        result[0] += 5.837083225681735e-06;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -8.44956438426716e-06;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
          if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
            if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.006937836693866150477) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.2646519339949748861) ) ) {
                result[0] += 0.001391978854652765;
              } else {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01063150000000000206) ) ) {
                  result[0] += -1.0515896072715843e-05;
                } else {
                  result[0] += -0.00020044096029255817;
                }
              }
            } else {
              if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.0008935000000000000884) ) ) {
                if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5179236987437186857) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9350000000000001643) ) ) {
                    result[0] += 0.0010811027920765428;
                  } else {
                    result[0] += -7.973896212607246e-05;
                  }
                } else {
                  result[0] += -0.0005170975775861583;
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9650000000000000799) ) ) {
                  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.6850000000000001643) ) ) {
                    result[0] += 3.434234593142282e-05;
                  } else {
                    result[0] += 0.0003062029438640299;
                  }
                } else {
                  result[0] += -7.466938734932032e-06;
                }
              }
            }
          } else {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
              result[0] += -9.1102086991198e-06;
            } else {
              result[0] += -0.00019338958659368015;
            }
          }
        } else {
          result[0] += -6.28436812806724e-05;
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 7.588588223741472e-07;
        } else {
          result[0] += 2.0621766291684246e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 5.630064484861047e-06;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 5.630064484861047e-06;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 5.630064484861047e-06;
            } else {
              result[0] += 5.630064484861047e-06;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 5.513816598298185e-06;
          } else {
            result[0] += -3.0529022601032717e-06;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            result[0] += 5.630064484861047e-06;
          } else {
            result[0] += 5.630064484861047e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 5.630064484861047e-06;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                result[0] += 5.630064484861047e-06;
              } else {
                result[0] += 5.630064484861047e-06;
              }
            } else {
              result[0] += 5.630064484861047e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 5.630064484861047e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 5.630064484861047e-06;
              } else {
                result[0] += 5.630064484861047e-06;
              }
            }
          }
        }
      } else {
        result[0] += 5.630064484861047e-06;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -8.149891052280798e-06;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8643464628140704598) ) ) {
              result[0] += -3.6521248165463527e-06;
            } else {
              result[0] += 0.00042032199605511293;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
              result[0] += -6.061485923645752e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                    result[0] += -8.963407233949547e-06;
                  } else {
                    result[0] += -1.0142937956579033e-05;
                  }
                } else {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.9550000000000000711) ) ) {
                    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8302819890954774573) ) ) {
                      result[0] += 0.0012977998368778857;
                    } else {
                      result[0] += -3.685119178014356e-05;
                    }
                  } else {
                    result[0] += -0.0003226994913602063;
                  }
                }
              } else {
                if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  result[0] += 1.3873032262529587e-05;
                } else {
                  result[0] += -0.00018869580385990283;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -8.787104871301217e-06;
          } else {
            result[0] += -0.0001865308067619166;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 7.31945038246822e-07;
        } else {
          result[0] += 1.989039208882244e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 5.430387897200304e-06;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 5.430387897200304e-06;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 5.430387897200304e-06;
            } else {
              result[0] += 5.430387897200304e-06;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 5.318262873061024e-06;
          } else {
            result[0] += -2.9446276377786807e-06;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            result[0] += 5.430387897200304e-06;
          } else {
            result[0] += 5.430387897200304e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 5.430387897200304e-06;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                result[0] += 5.430387897200304e-06;
              } else {
                result[0] += 5.430387897200304e-06;
              }
            } else {
              result[0] += 5.430387897200304e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 5.430387897200304e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 5.430387897200304e-06;
              } else {
                result[0] += 5.430387897200304e-06;
              }
            }
          }
        }
      } else {
        result[0] += 5.430387897200304e-06;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -7.860845973044476e-06;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8643464628140704598) ) ) {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.555096866909547848) ) ) {
                result[0] += 1.9147170409145197e-05;
              } else {
                result[0] += -1.4185610683803834e-05;
              }
            } else {
              result[0] += 0.00040541480234231953;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
              result[0] += -5.846508488014927e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                    result[0] += -8.6455098856851e-06;
                  } else {
                    result[0] += -9.783207220727313e-06;
                  }
                } else {
                  result[0] += 5.852628846831575e-06;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
                  if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.005046500000000001505) ) ) {
                    result[0] += 6.336023689173423e-05;
                  } else {
                    result[0] += 1.5205879050341796e-06;
                  }
                } else {
                  result[0] += -0.0006994028041918316;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -8.475460285196943e-06;
          } else {
            result[0] += -0.0001799152812935834;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 7.059857818322882e-07;
        } else {
          result[0] += 1.918495689705434e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 5.237793064953663e-06;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 5.237793064953663e-06;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 5.237793064953663e-06;
            } else {
              result[0] += 5.237793064953663e-06;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 5.129644681272905e-06;
          } else {
            result[0] += -2.840193097070405e-06;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            result[0] += 5.237793064953663e-06;
          } else {
            result[0] += 5.237793064953663e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 5.237793064953663e-06;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                result[0] += 5.237793064953663e-06;
              } else {
                result[0] += 5.237793064953663e-06;
              }
            } else {
              result[0] += 5.237793064953663e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 5.237793064953663e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 5.237793064953663e-06;
              } else {
                result[0] += 5.237793064953663e-06;
              }
            }
          }
        }
      } else {
        result[0] += 5.237793064953663e-06;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -7.582052203585758e-06;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9750000000000000888) ) ) {
            if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01332150000000000174) ) ) {
              if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.146109394227906586) ) ) {
                result[0] += 0.0008544765353733515;
              } else {
                result[0] += -1.3203385265957514e-05;
              }
            } else {
              if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01000276686157755036) ) ) {
                result[0] += -0.0001722325882904499;
              } else {
                result[0] += 8.543440724320947e-05;
              }
            }
          } else {
            result[0] += -1.1044683978248545e-05;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6732382808793971884) ) ) {
            result[0] += -5.639155469633035e-05;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.96280210579579717) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -8.174868525873569e-06;
              } else {
                result[0] += -0.0001356080275295579;
              }
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04953562823777350743) ) ) {
                result[0] += 1.0618335501704583e-06;
              } else {
                result[0] += 1.4666585397608405e-06;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 6.809471997285054e-07;
        } else {
          result[0] += 1.8504540760092328e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 5.052028825681437e-06;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 5.052028825681437e-06;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 5.052028825681437e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03350035677887956004) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03018900000000000403) ) ) {
                  result[0] += 5.052028825681437e-06;
                } else {
                  result[0] += 5.052028825681437e-06;
                }
              } else {
                result[0] += 5.052028825681437e-06;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 4.947716046419592e-06;
          } else {
            result[0] += -2.7394624451494507e-06;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            result[0] += 5.052028825681437e-06;
          } else {
            result[0] += 5.052028825681437e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 5.052028825681437e-06;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                result[0] += 5.052028825681437e-06;
              } else {
                result[0] += 5.052028825681437e-06;
              }
            } else {
              result[0] += 5.052028825681437e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 5.052028825681437e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 5.052028825681437e-06;
              } else {
                result[0] += 5.052028825681437e-06;
              }
            }
          }
        }
      } else {
        result[0] += 5.052028825681437e-06;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -7.313146169639944e-06;
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.828053558455352334) ) ) {
            if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.1450000000000000455) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)0.02500000000000000486) ) ) {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03237403661108240877) ) ) {
                    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.063944343817919913) ) ) {
                        result[0] += -1.2735112314097856e-05;
                      } else {
                        if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.180517123172382332) ) ) {
                          result[0] += 9.020590951035224e-05;
                        } else {
                          result[0] += 2.8387864857495164e-06;
                        }
                      }
                    } else {
                      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                        if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                          result[0] += -8.048956191952841e-06;
                        } else {
                          result[0] += 0.00018100936175572172;
                        }
                      } else {
                        result[0] += 1.2306796104717156e-05;
                      }
                    }
                  } else {
                    result[0] += 0.0002174368810185718;
                  }
                } else {
                  result[0] += 0.0001942115877262064;
                }
              } else {
                result[0] += -0.00025752893575103604;
              }
            } else {
              result[0] += 7.406059205332038e-06;
            }
          } else {
            result[0] += -5.439156459942008e-05;
          }
        } else {
          if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.01397330054109465099) ) ) {
            result[0] += 6.567966391825232e-07;
          } else {
            result[0] += 1.784825634893625e-06;
          }
        }
      } else {
        if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.01500000000000000118) ) ) {
          result[0] += -7.884937592361739e-06;
        } else {
          result[0] += 8.31788900021614e-05;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 4.872852924694748e-06;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 4.872852924694748e-06;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 4.872852924694748e-06;
            } else {
              result[0] += 4.872852924694748e-06;
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 4.77223971581558e-06;
          } else {
            result[0] += -2.642304319423272e-06;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            result[0] += 4.872852924694748e-06;
          } else {
            result[0] += 4.872852924694748e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 4.872852924694748e-06;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              result[0] += 4.872852924694748e-06;
            } else {
              result[0] += 4.872852924694748e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 4.872852924694748e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 4.872852924694748e-06;
              } else {
                result[0] += 4.872852924694748e-06;
              }
            }
          }
        }
      } else {
        result[0] += 4.872852924694748e-06;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -7.0537771915136764e-06;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
            if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8643464628140704598) ) ) {
              result[0] += -4.0296953308207465e-06;
            } else {
              result[0] += 0.00039140390125684153;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
              result[0] += -5.2462506407283125e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                    result[0] += -7.763490881392467e-06;
                  } else {
                    result[0] += -8.682496478778376e-06;
                  }
                } else {
                  result[0] += 1.2559117333169715e-05;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
                  result[0] += 1.187032169881237e-05;
                } else {
                  result[0] += -0.0006727206533230229;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -7.605289386448643e-06;
          } else {
            result[0] += -0.00017167492439587655;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 6.335026055081072e-07;
        } else {
          result[0] += 1.7215247804709834e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 4.7000316991474e-06;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 4.7000316991474e-06;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 4.7000316991474e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03350035677887956004) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03018900000000000403) ) ) {
                  result[0] += 4.7000316991474e-06;
                } else {
                  result[0] += 4.7000316991474e-06;
                }
              } else {
                result[0] += 4.7000316991474e-06;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 4.602986851212576e-06;
          } else {
            result[0] += -2.548592016217727e-06;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            result[0] += 4.7000316991474e-06;
          } else {
            result[0] += 4.7000316991474e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 4.7000316991474e-06;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                result[0] += 4.7000316991474e-06;
              } else {
                result[0] += 4.7000316991474e-06;
              }
            } else {
              result[0] += 4.7000316991474e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 4.7000316991474e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 4.7000316991474e-06;
              } else {
                result[0] += 4.7000316991474e-06;
              }
            }
          }
        }
      } else {
        result[0] += 4.7000316991474e-06;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -6.803607026764558e-06;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
        if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.629563023060444982) ) ) {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.555096866909547848) ) ) {
            result[0] += 1.8102063343308806e-05;
          } else {
            result[0] += -1.0639625223820539e-05;
          }
        } else {
          if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6732382808793971884) ) ) {
            result[0] += -5.0601864439905595e-05;
          } else {
            if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.96280210579579717) ) ) {
              if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                result[0] += -7.335559219601091e-06;
              } else {
                result[0] += -0.00012895454083955568;
              }
            } else {
              if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.8796512531658292611) ) ) {
                result[0] += 2.9227056836393557e-06;
              } else {
                if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                    result[0] += -1.63621195772506e-05;
                  } else {
                    result[0] += 0.00025767185081530016;
                  }
                } else {
                  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.004946500000000000376) ) ) {
                    result[0] += 2.738926002397748e-05;
                  } else {
                    result[0] += -8.424744803512863e-05;
                  }
                }
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 6.110347210135958e-07;
        } else {
          result[0] += 1.6604689622537275e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 4.533339773306403e-06;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 4.533339773306403e-06;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 4.533339773306403e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03350035677887956004) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03018900000000000403) ) ) {
                  result[0] += 4.533339773306403e-06;
                } else {
                  result[0] += 4.533339773306403e-06;
                }
              } else {
                result[0] += 4.533339773306403e-06;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 4.439736730370077e-06;
          } else {
            result[0] += -2.4582033255543336e-06;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            result[0] += 4.533339773306403e-06;
          } else {
            result[0] += 4.533339773306403e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 4.533339773306403e-06;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                result[0] += 4.533339773306403e-06;
              } else {
                result[0] += 4.533339773306403e-06;
              }
            } else {
              result[0] += 4.533339773306403e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 4.533339773306403e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 4.533339773306403e-06;
              } else {
                result[0] += 4.533339773306403e-06;
              }
            }
          }
        }
      } else {
        result[0] += 4.533339773306403e-06;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9950000000000001066) ) ) {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.00000001800250948e-35) ) ) {
      result[0] += -6.562309429099898e-06;
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)3.008742468579596707) ) ) {
        if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.9415511571105529276) ) ) {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1.480405183437169869) ) ) {
            if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.9750000000000000888) ) ) {
              result[0] += 1.5164753744932707e-06;
            } else {
              result[0] += -1.1204828926306911e-05;
            }
          } else {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.6148113858542715304) ) ) {
              result[0] += -4.8807212238702974e-05;
            } else {
              if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2.324957058753876815) ) ) {
                if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
                  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)4.133410011512043374e-06) ) ) {
                    result[0] += -7.227986037850634e-06;
                  } else {
                    result[0] += -7.997215637265995e-06;
                  }
                } else {
                  result[0] += 1.022220658958515e-05;
                }
              } else {
                if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)0.05500000000000000722) ) ) {
                  result[0] += 1.047793634825333e-05;
                } else {
                  result[0] += -0.0006489655135787242;
                }
              }
            }
          }
        } else {
          if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)1.00000001800250948e-35) ) ) {
            result[0] += -7.075395337376086e-06;
          } else {
            result[0] += -0.00016101276130163096;
          }
        }
      } else {
        if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)1.50000000000000025e-06) ) ) {
          result[0] += 5.893636853864287e-07;
        } else {
          result[0] += 1.601578557500435e-06;
        }
      }
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.04322155593254120576) ) ) {
      if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1936329823602408184) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-1.038794232605861678) ) ) {
          result[0] += 4.372559764642833e-06;
        } else {
          if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.00940454620688970129) ) ) {
            result[0] += 4.372559764642833e-06;
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.009670500000000002011) ) ) {
              result[0] += 4.372559764642833e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.03350035677887956004) ) ) {
                if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.03018900000000000403) ) ) {
                  result[0] += 4.372559764642833e-06;
                } else {
                  result[0] += 4.372559764642833e-06;
                }
              } else {
                result[0] += 4.372559764642833e-06;
              }
            }
          }
        }
      } else {
        if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.02002946682171335632) ) ) {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01004450000000000308) ) ) {
            result[0] += 4.282276459210027e-06;
          } else {
            result[0] += -2.3710203717629397e-06;
          }
        } else {
          if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.01500650000000000074) ) ) {
            result[0] += 4.372559764642833e-06;
          } else {
            result[0] += 4.372559764642833e-06;
          }
        }
      }
    } else {
      if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.212949140711806123) ) ) {
        if ( UNLIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.2070606536698188782) ) ) {
          result[0] += 4.372559764642833e-06;
        } else {
          if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)0.1567914783388883737) ) ) {
            if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)0.5086085907035177156) ) ) {
              if ( LIKELY(  (data[4].missing != -1) && (data[4].fvalue <= (double)-0.1296381427427941713) ) ) {
                result[0] += 4.372559764642833e-06;
              } else {
                result[0] += 4.372559764642833e-06;
              }
            } else {
              result[0] += 4.372559764642833e-06;
            }
          } else {
            if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)0.02346900000000000375) ) ) {
              result[0] += 4.372559764642833e-06;
            } else {
              if ( LIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)0.09883463041988287123) ) ) {
                result[0] += 4.372559764642833e-06;
              } else {
                result[0] += 4.372559764642833e-06;
              }
            }
          }
        }
      } else {
        result[0] += 4.372559764642833e-06;
      }
    }
  }
}

